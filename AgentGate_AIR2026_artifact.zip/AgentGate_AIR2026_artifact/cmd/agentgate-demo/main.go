// Command agentgate-demo runs the AgentGate supervisor demo: one offline
// process with the gateway, a simulated provider, a scripted agent, the
// approval relay and the signed audit log, plus a local dashboard.
//
//	agentgate-demo [-addr 127.0.0.1:8470] [-runs-dir demo-runs] [-no-browser] [-model ID] [-escalation flag|human|deny]
//	               [-durable=true] [-external-provider] [-witness] [-custody-dir DIR] [-host-label NAME]
//	agentgate-demo -selftest [-runs-dir DIR] [-repeat N] [-escalation flag|human|deny] [-external-provider] [-witness] [-host-label NAME]
//
// -escalation decides what happens to actions a policy rule would escalate:
// "flag" (the default, autonomous) runs them and flags them for audit,
// "human" pauses them until the reviewer decides in the dashboard, "deny"
// denies them.
//
// -durable (default on) keeps the gateway's operation journal in the run
// folder, so completed operations, consumed capabilities and dispatch intents
// survive a restart. -external-provider runs the simulated provider in its
// own process (agentgate-provider, built next to this binary) with its own
// key and journal; -witness starts the head witness (agentgate-witness),
// which countersigns the audit head after every operation. Both keep their
// state under -custody-dir (default <runs-dir>/custody).
//
// -host-label NAME replaces the machine name wherever the evidence records
// where it was made (run.json "host" and every audit entry's location), so an
// evidence bundle can be shared without naming the computer. The default is
// the real host name.
//
// -selftest runs every scenario (with the reviewer's intended decision in
// human mode), one custom request per tool, the verifier and every tamper
// attack headless, prints a PASS/FAIL table and local measurements, writes
// selftest-report.json into the run directory and exits 0 only if everything
// matched the expected outcome for the chosen escalation mode.
package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"flag"
	"fmt"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"time"

	"agentgate/internal/demo"
)

func main() { os.Exit(run()) }

func run() int {
	addr := flag.String("addr", "127.0.0.1:8470", "loopback address for the dashboard (falls back to a free port if busy)")
	runsDir := flag.String("runs-dir", "demo-runs", "directory that receives one evidence folder per run")
	noBrowser := flag.Bool("no-browser", false, "do not open the dashboard in the default browser")
	model := flag.String("model", "", "OpenRouter model id for the optional live LLM (needs OPENROUTER_API_KEY; overrides AGENTGATE_LLM_MODEL)")
	selfTest := flag.Bool("selftest", false, "run every scenario, the verifier and the tamper lab headless, print a PASS/FAIL table and local measurements, then exit (0 = everything matched)")
	repeat := flag.Int("repeat", 1, "with -selftest: run the scenario suite N times in the same run for more measurement samples")
	escalationFlag := flag.String("escalation", "flag", "what happens to actions a policy rule would escalate: flag (run them, flagged for audit), human (wait for the reviewer) or deny")
	durable := flag.Bool("durable", true, "keep the gateway's operation journal (operations.jsonl) in the run folder")
	externalProvider := flag.Bool("external-provider", false, "run the simulated provider in its own process (agentgate-provider next to this binary)")
	witness := flag.Bool("witness", false, "start the head witness process (agentgate-witness next to this binary)")
	custodyDir := flag.String("custody-dir", "", "state directory of the provider and witness processes (default <runs-dir>/custody)")
	hostLabelFlag := flag.String("host-label", "", "name recorded as the host in the evidence instead of this computer's name (default: the real host name)")
	unboundFlags := flag.Bool("unbound-flags", false, "EVALUATION ONLY: the flag-binding ablation (decision values do not commit the flag)")
	flag.Parse()
	log.SetFlags(log.Ltime)
	log.SetPrefix("agentgate-demo: ")

	if flag.NArg() > 0 {
		fmt.Fprintf(os.Stderr, "agentgate-demo: unexpected argument %q (see -help)\n", flag.Arg(0))
		return 2
	}
	if *repeat < 1 || *repeat > 1000 {
		fmt.Fprintln(os.Stderr, "agentgate-demo: -repeat must be between 1 and 1000")
		return 2
	}
	escalation, err := demo.ParseEscalation(*escalationFlag)
	if err != nil {
		fmt.Fprintln(os.Stderr, "agentgate-demo: -"+err.Error())
		return 2
	}
	providerExe, witnessExe, err := custodyExecutables(*externalProvider, *witness)
	if err != nil {
		fmt.Fprintln(os.Stderr, "agentgate-demo:", err)
		return 2
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	if *selfTest {
		return runSelfTest(ctx, stop, demo.SelfTestOptions{
			RunsDir: *runsDir, Repeat: *repeat, Escalation: escalation, Out: os.Stdout, Durable: *durable,
			ProviderExecutable: providerExe, WitnessExecutable: witnessExe, CustodyDir: *custodyDir,
			UnboundFlags: *unboundFlags, HostLabel: *hostLabelFlag,
		})
	}
	if *repeat != 1 {
		fmt.Fprintln(os.Stderr, "agentgate-demo: -repeat only applies together with -selftest; ignoring it.")
	}
	if err := requireLoopback(*addr); err != nil {
		fmt.Fprintln(os.Stderr, "agentgate-demo:", err)
		return 2
	}

	listener, err := net.Listen("tcp", *addr)
	if err != nil {
		fmt.Fprintf(os.Stderr, "agentgate-demo: %s is not available (%v); using a free port instead.\n", *addr, err)
		if listener, err = net.Listen("tcp", "127.0.0.1:0"); err != nil {
			fmt.Fprintln(os.Stderr, "agentgate-demo: cannot listen on loopback:", err)
			return 1
		}
	}
	getenv := func(name string) string {
		if name == "AGENTGATE_LLM_MODEL" && *model != "" {
			return *model
		}
		return os.Getenv(name)
	}
	server, err := demo.New(ctx, demo.Options{
		RunsDir: *runsDir, Getenv: getenv, Escalation: escalation, Durable: *durable,
		ProviderExecutable: providerExe, WitnessExecutable: witnessExe, CustodyDir: *custodyDir,
		UnboundFlags: *unboundFlags, HostLabel: *hostLabelFlag,
	})
	if err != nil {
		_ = listener.Close()
		fmt.Fprintln(os.Stderr, "agentgate-demo: could not start:", err)
		return 1
	}

	bound := listener.Addr().String()
	dashboard := "http://" + bound + "/"
	httpServer := &http.Server{Handler: server.Handler(bound), ReadHeaderTimeout: 10 * time.Second}
	serveDone := make(chan error, 1)
	go func() { serveDone <- httpServer.Serve(listener) }()

	printBanner(dashboard, server)
	if !*noBrowser {
		if err := openBrowser(dashboard); err != nil {
			fmt.Printf("  (Could not open a browser automatically: %v. Open the dashboard address above.)\n\n", err)
		}
	}

	exitCode := 0
	select {
	case <-ctx.Done():
		// Ctrl+C (or closing the console window) is the normal way to stop
		// the demo. Restore the default signal handling so a second Ctrl+C
		// ends the process at once if the shutdown below ever hangs.
		stop()
		fmt.Println("\nStopping: closing the audit log and writing the final provider journal...")
	case err := <-serveDone:
		stop()
		if err != nil && !errors.Is(err, http.ErrServerClosed) {
			fmt.Fprintln(os.Stderr, "agentgate-demo: dashboard server stopped:", err)
			exitCode = 1
		}
	}
	shutdown, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	_ = httpServer.Shutdown(shutdown)
	if err := server.Close(); err != nil {
		fmt.Fprintln(os.Stderr, "agentgate-demo: shutdown:", err)
		exitCode = 1
	}
	dir := displayPath(server.RunDir())
	headSeq, headHash := server.Head()
	fingerprint := keysFingerprint(server)
	fmt.Printf("Stopped. The evidence of this run is kept in %s\n", dir)
	fmt.Printf("  Trust anchor (keys fingerprint)  %s\n", fingerprint)
	fmt.Printf("  Final head (entry #%d)%s %s\n", headSeq, strings.Repeat(" ", max(0, 10-len(fmt.Sprint(headSeq)))), headHash)
	fmt.Println("  Note both values down outside the run folder. Check the evidence at any time with:")
	fmt.Printf("  %s\n", verifyCommandLineFinal(dir, fingerprint, headHash))
	if headFile, keyFile := server.WitnessAnchorFiles(); headFile != "" {
		key, _ := os.ReadFile(keyFile)
		fmt.Println("  Or anchored by the head witness alone (its cosigned head is kept outside the run folder):")
		fmt.Printf("  %s --witness %s --witness-key %s %s\n", verifierCommand(), displayPath(headFile), strings.TrimSpace(string(key)), dir)
	}
	return exitCode
}

// custodyExecutables finds agentgate-provider and agentgate-witness next to
// this binary (scripts/demo.ps1 builds all of them into one folder).
func custodyExecutables(provider, witness bool) (providerExe, witnessExe string, err error) {
	find := func(name string) (string, error) {
		if runtime.GOOS == "windows" {
			name += ".exe"
		}
		self, err := os.Executable()
		if err != nil {
			return "", err
		}
		candidate := filepath.Join(filepath.Dir(self), name)
		if _, err := os.Stat(candidate); err != nil {
			return "", fmt.Errorf("%s was not found next to agentgate-demo (%s); build it with scripts\\demo.ps1 or go build ./cmd/%s", name, candidate, strings.TrimSuffix(name, ".exe"))
		}
		return candidate, nil
	}
	if provider {
		if providerExe, err = find("agentgate-provider"); err != nil {
			return "", "", err
		}
	}
	if witness {
		if witnessExe, err = find("agentgate-witness"); err != nil {
			return "", "", err
		}
	}
	return providerExe, witnessExe, nil
}

// runSelfTest runs the headless rehearsal check and maps its result to the
// process exit code: 0 everything matched, 1 a mismatch, 2 could not run.
func runSelfTest(ctx context.Context, stop context.CancelFunc, options demo.SelfTestOptions) int {
	report, err := demo.RunSelfTest(ctx, options)
	stop()
	if err != nil {
		fmt.Fprintln(os.Stderr, "agentgate-demo: the self-test could not run:", err)
		return 2
	}
	if !report.Passed {
		return 1
	}
	return 0
}

// requireLoopback refuses to expose the dashboard beyond this computer: it
// has no login of its own.
func requireLoopback(address string) error {
	host, _, err := net.SplitHostPort(address)
	if err != nil {
		return fmt.Errorf("invalid -addr %q: %v", address, err)
	}
	if ip := net.ParseIP(host); host != "localhost" && (ip == nil || !ip.IsLoopback()) {
		return fmt.Errorf("-addr must be a loopback address such as 127.0.0.1:8470, got %q", address)
	}
	return nil
}

func printBanner(dashboard string, server *demo.Server) {
	dir := displayPath(server.RunDir())
	llm := "off (to enable: scripts\\demo.ps1 -Llm, or set OPENROUTER_API_KEY)"
	if server.LLMEnabled() {
		llm = "on (model " + server.LLMModel() + ")"
	}
	fingerprint := keysFingerprint(server)
	privacy := ""
	if server.LLMEnabled() {
		privacy = "\n  Live LLM mode sends prompts, the catalog and tool results to OpenRouter."
	}
	fmt.Printf(`
  AgentGate supervisor demo
  Local research prototype. All providers are simulated; no real email, document or money
  leaves this computer.%s

    Dashboard   %s
    Evidence    %s
                (audit.jsonl, head.json, keys.json, run.json, provider-journal.json)
    Trust anchor (keys fingerprint)
                %s
                (SHA-256 of keys.json; note it down outside the run folder)
    Verify      %s
                (the final head hash, for --expect-head, is printed when you stop the demo)
    Escalation  %s
    Custody     %s
    Live LLM    %s
    Stop        press Ctrl+C

`, privacy, dashboard, dir, fingerprint, verifyCommandLine(dir, fingerprint), demo.EscalationSummary(server.Escalation()), demo.CustodySummary(server), llm)
}

// verifyCommandLineFinal is the verifier command pinned to both trust
// anchors: the keys fingerprint and the final head hash.
func verifyCommandLineFinal(dir, fingerprint, headHash string) string {
	command := verifyCommandLine(dir, fingerprint)
	if len(headHash) != sha256.Size*2 {
		return command
	}
	return strings.TrimSuffix(command, " "+dir) + " --expect-head " + headHash + " " + dir
}

// verifyCommandLine is the verifier command for the run directory, pinned to
// the trust anchor when the fingerprint is known.
func verifyCommandLine(dir, fingerprint string) string {
	if len(fingerprint) == sha256.Size*2 {
		return verifierCommand() + " --expect-keys " + fingerprint + " " + dir
	}
	return verifierCommand() + " " + dir
}

// keysFingerprint is the SHA-256 (hex) of this run's keys.json: the value the
// server pinned in memory at startup, or (if it has none) a hash of the file.
func keysFingerprint(server *demo.Server) string {
	if fingerprint := server.KeysSHA256(); fingerprint != "" {
		return fingerprint
	}
	data, err := os.ReadFile(filepath.Join(server.RunDir(), "keys.json"))
	if err != nil {
		return "unavailable (" + err.Error() + ")"
	}
	sum := sha256.Sum256(data)
	return hex.EncodeToString(sum[:])
}

// verifierCommand is how to run the offline verifier from the current
// directory: the agentgate-verify binary built next to this one (as
// scripts/demo.ps1 does), or "go run" as a fallback.
func verifierCommand() string {
	name := "agentgate-verify"
	if runtime.GOOS == "windows" {
		name += ".exe"
	}
	if self, err := os.Executable(); err == nil {
		candidate := filepath.Join(filepath.Dir(self), name)
		if _, err := os.Stat(candidate); err == nil {
			// A ".\dir\tool.exe" style path runs from both PowerShell and cmd.
			if relative, ok := insideWorkingDir(candidate); ok {
				return "." + string(filepath.Separator) + relative
			}
			return candidate
		}
	}
	return "go run ./cmd/agentgate-verify"
}

// displayPath shortens path to one relative to the current directory when it
// lies inside it, so the banner stays readable.
func displayPath(path string) string {
	if relative, ok := insideWorkingDir(path); ok {
		return filepath.ToSlash(relative)
	}
	return path
}

func insideWorkingDir(path string) (string, bool) {
	wd, err := os.Getwd()
	if err != nil {
		return "", false
	}
	absolute, err := filepath.Abs(path)
	if err != nil {
		return "", false
	}
	relative, err := filepath.Rel(wd, absolute)
	if err != nil || relative == ".." || strings.HasPrefix(relative, ".."+string(filepath.Separator)) {
		return "", false
	}
	return relative, true
}

func openBrowser(url string) error {
	var command *exec.Cmd
	switch runtime.GOOS {
	case "windows":
		command = exec.Command("rundll32", "url.dll,FileProtocolHandler", url)
	case "darwin":
		command = exec.Command("open", url)
	default:
		command = exec.Command("xdg-open", url)
	}
	return command.Start()
}
