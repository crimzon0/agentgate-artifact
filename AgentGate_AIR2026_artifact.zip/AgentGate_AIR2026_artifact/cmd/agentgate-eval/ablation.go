package main

import (
	"encoding/csv"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"

	"agentgate/internal/auditverify"
)

// The ablation asks, for every tamper-lab attack, which of the verifier's
// mechanisms detect it. Each base run is a fresh demo run (new keys, new
// operation IDs, new timestamps) with the full scenario suite. Its clean
// evidence and one attacked copy per attack are verified under:
//
//   - cumulative configurations C0..C7, adding one mechanism at a time in
//     the order of auditverify.Mechanisms() (C0 = files only; C7 = every
//     mechanism plus the two trust anchors, i.e. the default verifier run as
//     agentgate-verify --expect-keys K --expect-head H);
//   - leave-one-out configurations L-<m>: every mechanism except m (pinned
//     unless m is the anchors mechanism);
//   - single-mechanism configurations S-<m>: the files mechanism plus m only
//     (pinned when m is the anchors mechanism), which shows what m detects on
//     its own;
//   - the reference configuration R-unpinned: the default verifier without
//     any pin (agentgate-verify DIR), where the anchor checks only warn.
//
// An attack counts as detected when the verdict is FAILED. A clean run that
// fails is a false alarm.

const (
	familyCumulative = "cumulative"
	familyLeaveOut   = "leave-one-out"
	familySingle     = "single"
	familyReference  = "reference"
	targetClean      = "clean"
)

type ablationConfig struct {
	ID       string   `json:"id"`
	Family   string   `json:"family"`
	Label    string   `json:"label"`
	Enabled  []string `json:"enabled_mechanisms"`
	Disabled []string `json:"disabled_mechanisms"`
	// Pinned: the keys fingerprint from startup and the writer's final head
	// hash are passed as trust anchors.
	Pinned bool `json:"pinned"`

	disabled []auditverify.Mechanism
}

func ablationConfigs() []ablationConfig {
	all := auditverify.Mechanisms()
	without := func(skip map[auditverify.Mechanism]bool) (enabled, disabled []auditverify.Mechanism) {
		for _, mechanism := range all {
			if skip[mechanism] {
				disabled = append(disabled, mechanism)
			} else {
				enabled = append(enabled, mechanism)
			}
		}
		return enabled, disabled
	}
	build := func(id, family, label string, skip map[auditverify.Mechanism]bool, pinned bool) ablationConfig {
		enabled, disabled := without(skip)
		return ablationConfig{ID: id, Family: family, Label: label, Enabled: mechanismNames(enabled),
			Disabled: mechanismNames(disabled), Pinned: pinned, disabled: disabled}
	}
	var configs []ablationConfig
	for k := range all {
		skip := map[auditverify.Mechanism]bool{}
		for _, mechanism := range all[k+1:] {
			skip[mechanism] = true
		}
		label := "files only (no protection)"
		if k > 0 {
			label = "+ " + string(all[k])
		}
		configs = append(configs, build(fmt.Sprintf("C%d", k), familyCumulative, label, skip, all[k] == auditverify.MechanismAnchors))
	}
	for _, mechanism := range all {
		configs = append(configs, build("L-"+string(mechanism), familyLeaveOut, "full minus "+string(mechanism),
			map[auditverify.Mechanism]bool{mechanism: true}, mechanism != auditverify.MechanismAnchors))
	}
	for _, mechanism := range all[1:] {
		skip := map[auditverify.Mechanism]bool{}
		for _, other := range all[1:] {
			if other != mechanism {
				skip[other] = true
			}
		}
		configs = append(configs, build("S-"+string(mechanism), familySingle, "files + "+string(mechanism)+" only",
			skip, mechanism == auditverify.MechanismAnchors))
	}
	configs = append(configs, build("R-unpinned", familyReference, "default verifier, no trust anchors", nil, false))
	return configs
}

func (c ablationConfig) options(run baseRun) auditverify.Options {
	options := auditverify.Options{DisableMechanisms: c.disabled}
	if c.Pinned {
		options.ExpectKeysSHA256, options.ExpectHead = run.KeysSHA256, run.HeadHash
	}
	return options
}

// ablationRow is one verification: (run, target, configuration).
type ablationRow struct {
	Run              int      `json:"run"`
	RunID            string   `json:"run_id"`
	Target           string   `json:"target"`
	Config           string   `json:"config"`
	Family           string   `json:"family"`
	Pinned           bool     `json:"pinned"`
	Verdict          string   `json:"verdict"`
	Detected         bool     `json:"detected"`
	FailedChecks     []string `json:"failed_checks"`
	FailedMechanisms []string `json:"failed_mechanisms"`
	Findings         int      `json:"findings"`
	Warnings         int      `json:"warnings"`
	Skipped          int      `json:"checks_skipped"`
	VerifyMS         float64  `json:"verify_ms"`
}

type rateCell struct {
	Detected int     `json:"detected"`
	N        int     `json:"n"`
	Rate     float64 `json:"rate"`
}

func (c rateCell) String() string { return fmt.Sprintf("%d/%d", c.Detected, c.N) }

type tamperDescription struct {
	Kind     string `json:"kind"`
	Title    string `json:"title"`
	Attacker string `json:"attacker"`
	Expected string `json:"expected"`
	// Change is what the attack changed in the first base run.
	Change string `json:"change_in_run_1"`
}

type ablationSummary struct {
	// Detection[target][config]: FAILED verdicts out of N runs. For the
	// "clean" target this is the false-alarm count.
	Detection map[string]map[string]rateCell `json:"detection"`
	// FirstCumulative[tamper]: the first cumulative configuration that
	// detected the attack in every run ("" if none).
	FirstCumulative map[string]string `json:"first_cumulative_config_detecting_all_runs"`
	// LeaveOneOutLost[mechanism][tamper]: runs in which the full pinned
	// verifier (C7) detected the attack but the verifier without mechanism
	// did not.
	LeaveOneOutLost map[string]map[string]int `json:"leave_one_out_lost"`
	// FullFailingChecks[tamper][check]: runs in which check failed under C7.
	FullFailingChecks map[string]map[string]int `json:"full_failing_checks"`
	// FullFiringMechanisms[tamper]: mechanisms with a failing check under C7
	// in every run (independent lines of detection).
	FullFiringMechanisms map[string][]string `json:"full_firing_mechanisms"`
	// SingleSufficient[tamper]: mechanisms whose single-mechanism
	// configuration S-<m> (files + m) detected the attack in every run.
	SingleSufficient map[string][]string `json:"single_mechanism_sufficient"`
	// CleanVerifyMS[config]: verifier runtime on the clean runs (one timed
	// verification per run; quantized to the clock granularity).
	CleanVerifyMS map[string]summary `json:"clean_verify_ms"`
	Problems      []string           `json:"problems"`
}

type ablationResult struct {
	Format      string              `json:"format"`
	Note        string              `json:"note"`
	Environment environment         `json:"environment"`
	Runs        []baseRun           `json:"runs"`
	Mechanisms  map[string][]string `json:"mechanisms"`
	AlwaysOn    []string            `json:"always_evaluated_checks"`
	Configs     []ablationConfig    `json:"configs"`
	Tampers     []tamperDescription `json:"tampers"`
	Targets     []string            `json:"targets"`
	Summary     ablationSummary     `json:"summary"`
	Rows        []ablationRow       `json:"rows"`
	DurationS   float64             `json:"duration_s"`
}

func runAblation(args []string, stdout io.Writer) error {
	flags := flag.NewFlagSet("ablation", flag.ContinueOnError)
	runs := flags.Int("runs", 10, "number of independent base runs")
	out := flags.String("out", "", "output directory for ablation.csv/json/md")
	work := flags.String("work", "", "directory for the base runs and attacked copies (default: temp)")
	if err := flags.Parse(args); err != nil {
		return err
	}
	if *runs < 1 {
		return fmt.Errorf("-runs must be at least 1")
	}
	outDir, workDir, err := prepareDirs(*out, *work, "ablation")
	if err != nil {
		return err
	}
	ctx, cancel := interruptible()
	defer cancel()
	began := time.Now()

	result := ablationResult{
		Format: "agentgate-eval-ablation/v1",
		Note: "Local measurements on one computer. Each base run is a fresh demo run (new keys and IDs) with the same scripted " +
			"scenario suite, so the runs are replications of one workload, not different workloads. The attacks are the tamper " +
			"lab's fixed, hand-written set. Detected means the verifier's verdict was FAILED.",
		Environment: currentEnvironment(append([]string{"ablation"}, args...)),
		Mechanisms:  map[string][]string{},
		AlwaysOn:    []string{auditverify.CheckTime, auditverify.CheckVerifierError},
		Configs:     ablationConfigs(),
		Targets:     []string{targetClean},
	}
	for _, mechanism := range auditverify.Mechanisms() {
		result.Mechanisms[string(mechanism)] = auditverify.MechanismChecks(mechanism)
	}
	for _, info := range auditverify.Tampers() {
		result.Targets = append(result.Targets, string(info.Kind))
		result.Tampers = append(result.Tampers, tamperDescription{Kind: string(info.Kind), Title: info.Title, Attacker: info.Attacker, Expected: info.Expected})
	}

	for index := 1; index <= *runs; index++ {
		fmt.Fprintf(stdout, "run %d/%d: self-test ... ", index, *runs)
		base, err := createBaseRun(ctx, index, filepath.Join(workDir, "runs"), 1)
		if err != nil {
			return fmt.Errorf("base run %d: %w", index, err)
		}
		if !base.HasEarlier {
			return fmt.Errorf("base run %d: no earlier checkpoint for the rollback attack", index)
		}
		fmt.Fprintf(stdout, "%s (%d entries); ", base.RunID, base.Entries)
		dirs := map[string]string{targetClean: base.dir}
		for i, info := range auditverify.Tampers() {
			destination := filepath.Join(workDir, "attacked", base.RunID, string(info.Kind))
			options := auditverify.TamperOptions{}
			if info.Kind == auditverify.TamperRollback {
				options = base.earlier
			}
			change, err := auditverify.ApplyTamperWith(base.dir, destination, info.Kind, options)
			if err != nil {
				return fmt.Errorf("base run %d: apply %s: %w", index, info.Kind, err)
			}
			dirs[string(info.Kind)] = destination
			if index == 1 {
				result.Tampers[i].Change = describeChange(change)
			}
		}
		verified := 0
		for _, target := range result.Targets {
			for _, config := range result.Configs {
				row, err := verifyAblation(base, target, dirs[target], config)
				if err != nil {
					return err
				}
				result.Rows = append(result.Rows, row)
				verified++
			}
		}
		result.Runs = append(result.Runs, base)
		fmt.Fprintf(stdout, "%d verifications\n", verified)
	}
	result.Summary = summarizeAblation(result)
	result.DurationS = round(time.Since(began).Seconds(), 1)

	if err := writeJSON(filepath.Join(outDir, "ablation.json"), result); err != nil {
		return err
	}
	if err := writeAblationCSV(filepath.Join(outDir, "ablation.csv"), result.Rows); err != nil {
		return err
	}
	if err := writeText(filepath.Join(outDir, "ablation.md"), ablationMarkdown(result)); err != nil {
		return err
	}
	fmt.Fprintf(stdout, "wrote %s (ablation.json, ablation.csv, ablation.md); evidence in %s\n", outDir, workDir)
	for _, problem := range result.Summary.Problems {
		fmt.Fprintf(stdout, "PROBLEM: %s\n", problem)
	}
	return nil
}

func describeChange(change auditverify.TamperResult) string {
	where := change.File
	if change.Seq != 0 {
		where += fmt.Sprintf(" seq %d", change.Seq)
	}
	return fmt.Sprintf("%s: %s -> %s", where, change.Before, change.After)
}

func verifyAblation(base baseRun, target, dir string, config ablationConfig) (ablationRow, error) {
	began := time.Now()
	report, err := auditverify.VerifyRun(dir, config.options(base))
	elapsed := time.Since(began)
	if err != nil {
		return ablationRow{}, fmt.Errorf("verify %s of run %d under %s: %w", target, base.Index, config.ID, err)
	}
	row := ablationRow{
		Run: base.Index, RunID: base.RunID, Target: target, Config: config.ID, Family: config.Family, Pinned: config.Pinned,
		Verdict: report.Verdict, Detected: report.Verdict == auditverify.VerdictFailed,
		FailedChecks: failingCheckIDs(report), Findings: report.Counts.Findings, Warnings: report.Counts.Warnings,
		Skipped: report.Counts.ChecksSkipped, VerifyMS: round(ms(elapsed), 3),
	}
	if row.FailedChecks == nil {
		row.FailedChecks = []string{}
	}
	seen := map[string]bool{}
	row.FailedMechanisms = []string{}
	for _, id := range row.FailedChecks {
		name := "always-on"
		if mechanism, ok := auditverify.MechanismOf(id); ok {
			name = string(mechanism)
		}
		if !seen[name] {
			seen[name] = true
			row.FailedMechanisms = append(row.FailedMechanisms, name)
		}
	}
	return row, nil
}

func summarizeAblation(result ablationResult) ablationSummary {
	summary := ablationSummary{
		Detection: map[string]map[string]rateCell{}, FirstCumulative: map[string]string{},
		LeaveOneOutLost: map[string]map[string]int{}, FullFailingChecks: map[string]map[string]int{},
		FullFiringMechanisms: map[string][]string{}, SingleSufficient: map[string][]string{},
		CleanVerifyMS: map[string]summary{}, Problems: []string{},
	}
	cleanMS := map[string][]float64{}
	type key struct {
		run            int
		target, config string
	}
	rows := map[key]ablationRow{}
	for _, row := range result.Rows {
		rows[key{row.Run, row.Target, row.Config}] = row
		if row.Target == targetClean {
			cleanMS[row.Config] = append(cleanMS[row.Config], row.VerifyMS)
		}
		cells := summary.Detection[row.Target]
		if cells == nil {
			cells = map[string]rateCell{}
			summary.Detection[row.Target] = cells
		}
		cell := cells[row.Config]
		cell.N++
		if row.Detected {
			cell.Detected++
		}
		cell.Rate = round(float64(cell.Detected)/float64(cell.N), 4)
		cells[row.Config] = cell
		for _, id := range row.FailedChecks {
			if id == auditverify.CheckTime || id == auditverify.CheckVerifierError {
				summary.Problems = append(summary.Problems, fmt.Sprintf("run %d %s under %s: always-on check %s failed", row.Run, row.Target, row.Config, id))
			}
		}
	}
	for config, values := range cleanMS {
		summary.CleanVerifyMS[config] = summarize("ms", values)
	}
	full := "C" + strconv.Itoa(len(auditverify.Mechanisms())-1)
	for _, target := range result.Targets {
		if target == targetClean {
			for _, config := range result.Configs {
				if cell := summary.Detection[targetClean][config.ID]; cell.Detected > 0 {
					summary.Problems = append(summary.Problems, fmt.Sprintf("false alarm: clean runs FAILED under %s in %s runs", config.ID, cell))
				}
			}
			continue
		}
		if cell := summary.Detection[target][full]; cell.Detected != cell.N {
			summary.Problems = append(summary.Problems, fmt.Sprintf("%s detected in only %s runs by the full pinned verifier %s", target, cell, full))
		}
		for _, config := range result.Configs {
			if config.Family != familyCumulative {
				continue
			}
			if cell := summary.Detection[target][config.ID]; cell.N > 0 && cell.Detected == cell.N {
				summary.FirstCumulative[target] = config.ID
				break
			}
		}
		checks := map[string]int{}
		mechanismRuns := map[string]int{}
		for _, run := range result.Runs {
			row := rows[key{run.Index, target, full}]
			for _, id := range row.FailedChecks {
				checks[id]++
			}
			for _, name := range row.FailedMechanisms {
				mechanismRuns[name]++
			}
		}
		summary.FullFailingChecks[target] = checks
		firing := []string{}
		for _, mechanism := range auditverify.Mechanisms() {
			if mechanismRuns[string(mechanism)] == len(result.Runs) {
				firing = append(firing, string(mechanism))
			}
		}
		summary.FullFiringMechanisms[target] = firing
		sufficient := []string{}
		for _, mechanism := range auditverify.Mechanisms()[1:] {
			if cell := summary.Detection[target]["S-"+string(mechanism)]; cell.N > 0 && cell.Detected == cell.N {
				sufficient = append(sufficient, string(mechanism))
			}
		}
		summary.SingleSufficient[target] = sufficient
	}
	for _, mechanism := range auditverify.Mechanisms() {
		lost := map[string]int{}
		for _, target := range result.Targets {
			if target == targetClean {
				continue
			}
			for _, run := range result.Runs {
				fullRow := rows[key{run.Index, target, full}]
				leaveRow := rows[key{run.Index, target, "L-" + string(mechanism)}]
				if fullRow.Detected && !leaveRow.Detected {
					lost[target]++
				}
			}
		}
		summary.LeaveOneOutLost[string(mechanism)] = lost
	}
	return summary
}

func writeAblationCSV(path string, rows []ablationRow) error {
	file, err := os.Create(path)
	if err != nil {
		return err
	}
	defer file.Close()
	writer := csv.NewWriter(file)
	_ = writer.Write([]string{"run", "run_id", "target", "config", "family", "pinned", "verdict", "detected",
		"failed_checks", "failed_mechanisms", "findings", "warnings", "checks_skipped", "verify_ms"})
	for _, row := range rows {
		_ = writer.Write([]string{
			strconv.Itoa(row.Run), row.RunID, row.Target, row.Config, row.Family, strconv.FormatBool(row.Pinned), row.Verdict,
			strconv.FormatBool(row.Detected), strings.Join(row.FailedChecks, ";"), strings.Join(row.FailedMechanisms, ";"),
			strconv.Itoa(row.Findings), strconv.Itoa(row.Warnings), strconv.Itoa(row.Skipped), strconv.FormatFloat(row.VerifyMS, 'f', 3, 64),
		})
	}
	writer.Flush()
	if err := writer.Error(); err != nil {
		return err
	}
	return file.Close()
}

func ablationMarkdown(result ablationResult) string {
	var b strings.Builder
	n := len(result.Runs)
	summary := result.Summary
	fmt.Fprintf(&b, "# Mechanism ablation of the AgentGate verifier\n\n")
	fmt.Fprintf(&b, "%s\n\n", result.Note)
	fmt.Fprintf(&b, "- Base runs: %d fresh demo runs (self-test, 14 scenarios + 3 custom requests each, all passed); entries per run: %s.\n",
		n, entriesRange(result.Runs))
	fmt.Fprintf(&b, "- Attacked copies: %d attacks x %d runs = %d copies; plus %d clean runs.\n", len(result.Tampers), n, len(result.Tampers)*n, n)
	fmt.Fprintf(&b, "- Configurations: %d (8 cumulative, 8 leave-one-out, 7 single-mechanism, 1 reference); verifications: %d.\n", len(result.Configs), len(result.Rows))
	fmt.Fprintf(&b, "- Always evaluated in every configuration: %s (never failed in this experiment unless listed under Problems).\n",
		strings.Join(result.AlwaysOn, ", "))
	fmt.Fprintf(&b, "- Trust anchors (pinned configurations only): keys.json fingerprint recorded at startup and the final head hash held by the writing process.\n")
	fmt.Fprintf(&b, "- Command: `%s`; Go %s on %s/%s, %d CPUs; total %.0f s.\n\n", result.Environment.Command, result.Environment.GoVersion,
		result.Environment.GOOS, result.Environment.GOARCH, result.Environment.NumCPU, result.DurationS)

	fmt.Fprintf(&b, "## Mechanisms\n\n| Mechanism | Checks |\n|---|---|\n")
	for _, mechanism := range auditverify.Mechanisms() {
		fmt.Fprintf(&b, "| %s | %s |\n", mechanism, strings.Join(result.Mechanisms[string(mechanism)], ", "))
	}

	writeTable := func(title string, family string, includeReference bool) {
		var configs []ablationConfig
		for _, config := range result.Configs {
			if config.Family == family || (includeReference && config.Family == familyReference) {
				configs = append(configs, config)
			}
		}
		fmt.Fprintf(&b, "\n## %s\n\nCells: runs with verdict FAILED / runs. Row \"clean\" = false alarms.\n\n| Target |", title)
		for _, config := range configs {
			fmt.Fprintf(&b, " %s |", config.ID)
		}
		fmt.Fprintf(&b, "\n|---|")
		for range configs {
			fmt.Fprintf(&b, "---|")
		}
		fmt.Fprintf(&b, "\n")
		for _, target := range result.Targets {
			fmt.Fprintf(&b, "| %s |", target)
			for _, config := range configs {
				fmt.Fprintf(&b, " %s |", summary.Detection[target][config.ID])
			}
			fmt.Fprintf(&b, "\n")
		}
		fmt.Fprintf(&b, "\n")
		for _, config := range configs {
			pinned := ""
			if config.Pinned {
				pinned = " (pinned)"
			}
			fmt.Fprintf(&b, "- %s: %s%s\n", config.ID, config.Label, pinned)
		}
	}
	writeTable("Cumulative configurations", familyCumulative, true)
	writeTable("Leave-one-out configurations", familyLeaveOut, false)
	writeTable("Single-mechanism configurations (files + one mechanism)", familySingle, false)

	fmt.Fprintf(&b, "\n## What each mechanism alone is responsible for\n\nRuns in which the full pinned verifier (C7) detected the attack but the verifier without that one mechanism did not.\n\n| Mechanism removed | Attacks no longer detected |\n|---|---|\n")
	for _, mechanism := range auditverify.Mechanisms() {
		lost := summary.LeaveOneOutLost[string(mechanism)]
		var parts []string
		for _, target := range result.Targets {
			if count := lost[target]; count > 0 {
				parts = append(parts, fmt.Sprintf("%s (%d/%d)", target, count, n))
			}
		}
		if len(parts) == 0 {
			parts = []string{"none (every attack is still detected by another mechanism)"}
		}
		fmt.Fprintf(&b, "| %s | %s |\n", mechanism, strings.Join(parts, ", "))
	}

	fmt.Fprintf(&b, "\n## Failing checks under the full pinned verifier (C7)\n\n| Attack | First cumulative config detecting all runs | Mechanisms firing in every run | Sufficient alone (S-configs, all runs) | Failing checks (runs) |\n|---|---|---|---|---|\n")
	for _, target := range result.Targets {
		if target == targetClean {
			continue
		}
		checks := summary.FullFailingChecks[target]
		ids := make([]string, 0, len(checks))
		for id := range checks {
			ids = append(ids, id)
		}
		sort.Strings(ids)
		parts := make([]string, len(ids))
		for i, id := range ids {
			parts[i] = fmt.Sprintf("%s (%d/%d)", id, checks[id], n)
		}
		fmt.Fprintf(&b, "| %s | %s | %s | %s | %s |\n", target, firstNonEmpty(summary.FirstCumulative[target], "none"),
			strings.Join(summary.FullFiringMechanisms[target], ", "), firstNonEmpty(strings.Join(summary.SingleSufficient[target], ", "), "none"),
			strings.Join(parts, ", "))
	}

	fmt.Fprintf(&b, "\n## Verifier runtime per configuration (clean runs)\n\nOne timed verification per clean run and configuration (n = %d each); durations are quantized to the clock granularity (%.3f ms). A switched-off mechanism skips its signature verifications (entries, head, artifacts, provider journal); the other switched-off checks are computed and discarded, so these differences are indicative only.\n\n| Config | Median ms | Min | Max |\n|---|---|---|---|\n",
		n, result.Environment.ClockGranularityMS)
	for _, config := range result.Configs {
		stats := summary.CleanVerifyMS[config.ID]
		fmt.Fprintf(&b, "| %s | %.2f | %.2f | %.2f |\n", config.ID, stats.Median, stats.Min, stats.Max)
	}

	fmt.Fprintf(&b, "\n## Attacks (as applied to run 1)\n\n")
	for _, tamper := range result.Tampers {
		fmt.Fprintf(&b, "- **%s** (%s). Attacker: %s Change: %s\n", tamper.Kind, tamper.Title, tamper.Attacker, tamper.Change)
	}
	fmt.Fprintf(&b, "\n## Problems\n\n")
	if len(summary.Problems) == 0 {
		fmt.Fprintf(&b, "None: no false alarms in any configuration, every attack detected by C7 in every run, and the always-on checks never failed.\n")
	}
	for _, problem := range summary.Problems {
		fmt.Fprintf(&b, "- %s\n", problem)
	}
	return b.String()
}

func entriesRange(runs []baseRun) string {
	values := make([]float64, len(runs))
	for i, run := range runs {
		values[i] = float64(run.Entries)
	}
	sorted := sortedCopy(values)
	return fmt.Sprintf("median %s (min %.0f, max %.0f)", strconv.FormatFloat(percentile(sorted, 0.5), 'f', -1, 64), sorted[0], sorted[len(sorted)-1])
}

func firstNonEmpty(values ...string) string {
	for _, value := range values {
		if value != "" {
			return value
		}
	}
	return ""
}
