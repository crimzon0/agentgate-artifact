package main

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"math"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"agentgate/internal/adapters"
	"agentgate/internal/devcomposition"
	"agentgate/internal/effects"
)

// The baseline experiment (REVISION_CONTRACT R6.8) compares the same workload
// under matched configurations, with identical client transport (JSON-RPC
// tools/call over loopback HTTP with keep-alive) and identical provider
// transport and provider (the adapter's HTTP transport, one fresh TCP
// connection per provider request, to a provider host with its own key):
//
//	direct        no gateway: a minimal tool server normalizes the request
//	              with the gateway's own normalizer
//	              (devcomposition.InspectNormalizedEffect), prepares the
//	              provider request with adapters.Prepare, sends it with
//	              adapters.HTTPTransport and verifies the provider's signed
//	              receipt. No authentication, policy, grant, capability,
//	              effect receipt, journal or audit.
//	policy-only   the gateway (MCP boundary, authentication, normalizer,
//	              policy and delegation grant, capability issue and
//	              consumption, adapter, signed effect receipt) with the audit
//	              sink switched off (Config.Audit nil) and no journal
//	full          policy-only plus the signed, hash-chained audit log
//	              (durable: fsync of every entry, head.json replaced through
//	              a synced temporary file)
//	full+journal  full plus the fsynced operation journal
//	full-flagged  full, with a request above the automatic limit, so the
//	              action is allowed and flagged for audit (sequential only)
//
// Sequential phase: paired, interleaved trials. Each trial sends one call to
// every configuration, in an order rotated from trial to trial; every
// configuration has its own provider host instance, and every block of trials
// starts fresh (providers, gateways, audit logs), so provider state growth
// (the simulator re-hashes its whole state per commit) stays small and equal.
// Concurrent phase: for each client count, each configuration runs alone on a
// fresh provider host and gateway; C clients send back-to-back calls; the
// window records throughput, latencies, process CPU time, Go allocations and
// sampled peak memory.
//
// Every observation is kept (CSV), including warm-up calls (marked) and any
// failed call; summaries use every measured call. Latency is measured on the
// client from just before the request is sent to the moment the whole
// response body has been read, with the high-resolution counter (hrMethod).

type baselineConfig struct {
	Name        string `json:"name"`
	Description string `json:"description"`
	gateway     bool
	audit       bool
	journal     bool
	flagged     bool
}

var baselineConfigs = []baselineConfig{
	{Name: "direct", Description: "no gateway: normalize (gateway normalizer), adapters.Prepare, adapters.HTTPTransport to the provider, verify the provider receipt"},
	{Name: "policy-only", Description: "gateway with policy, grant, capability and signed receipts; audit sink off, no operation journal", gateway: true},
	{Name: "full", Description: "policy-only plus the signed hash-chained audit log, durable (fsync per entry)", gateway: true, audit: true},
	{Name: "full+journal", Description: "full plus the fsynced operation journal", gateway: true, audit: true, journal: true},
	{Name: "full-flagged", Description: "full; the request is above the automatic limit and is flagged for audit", gateway: true, audit: true, flagged: true},
}

func baselineConfigByName(name string) (baselineConfig, bool) {
	for _, config := range baselineConfigs {
		if config.Name == name {
			return config, true
		}
	}
	return baselineConfig{}, false
}

type baselineOptions struct {
	outDir, workDir string
	trials, warmup  int
	block           int
	clients         []int
	loadCalls       int
	workload        string
	sequential      []baselineConfig
	concurrent      []baselineConfig
	sampleInterval  time.Duration
	skipSequential  bool
	skipConcurrent  bool
}

func parseBaselineFlags(args []string, stderr io.Writer) (baselineOptions, error) {
	set := flag.NewFlagSet("baseline", flag.ContinueOnError)
	set.SetOutput(stderr)
	out := set.String("out", "", "directory for baseline.json, the CSV files and baseline.md (required)")
	work := set.String("work", "", "directory for evidence folders and journals (default: a temporary directory)")
	trials := set.Int("trials", 500, "sequential paired trials (one call per configuration each)")
	warmup := set.Int("warmup", 10, "warm-up calls per configuration per block or cell (recorded, not summarized)")
	block := set.Int("block", 50, "sequential trials per block (fresh provider and gateways per block)")
	clients := set.String("clients", "1,2,4,8,16", "client counts of the concurrent phase")
	loadCalls := set.Int("load-calls", 400, "measured calls per configuration and client count in the concurrent phase")
	workload := set.String("workload", "financial", "request: financial (AED 125.00 payment) or message (internal message)")
	sequential := set.String("configs", "direct,policy-only,full,full+journal,full-flagged", "configurations of the sequential phase")
	concurrent := set.String("load-configs", "direct,policy-only,full,full+journal", "configurations of the concurrent phase")
	sample := set.Duration("sample", 5*time.Millisecond, "memory sampling interval in the concurrent phase")
	noSequential := set.Bool("no-sequential", false, "skip the sequential phase")
	noConcurrent := set.Bool("no-concurrent", false, "skip the concurrent phase")
	if err := set.Parse(args); err != nil {
		return baselineOptions{}, err
	}
	if set.NArg() != 0 {
		return baselineOptions{}, fmt.Errorf("unexpected arguments: %v", set.Args())
	}
	options := baselineOptions{outDir: *out, workDir: *work, trials: *trials, warmup: *warmup, block: *block, loadCalls: *loadCalls,
		workload: *workload, sampleInterval: *sample, skipSequential: *noSequential, skipConcurrent: *noConcurrent}
	if options.outDir == "" {
		return baselineOptions{}, errors.New("-out is required")
	}
	if options.trials < 1 || options.warmup < 0 || options.block < 1 || options.loadCalls < 1 || options.sampleInterval <= 0 {
		return baselineOptions{}, errors.New("-trials, -block and -load-calls must be at least 1, -warmup at least 0 and -sample positive")
	}
	if options.workload != "financial" && options.workload != "message" {
		return baselineOptions{}, fmt.Errorf("-workload must be financial or message, not %q", options.workload)
	}
	var err error
	if options.clients, err = parseClientCounts(*clients); err != nil {
		return baselineOptions{}, err
	}
	if options.sequential, err = parseBaselineConfigs(*sequential); err != nil {
		return baselineOptions{}, err
	}
	if options.concurrent, err = parseBaselineConfigs(*concurrent); err != nil {
		return baselineOptions{}, err
	}
	if options.workload == "message" {
		for _, list := range [][]baselineConfig{options.sequential, options.concurrent} {
			for _, config := range list {
				if config.flagged {
					return baselineOptions{}, errors.New("full-flagged needs the financial workload")
				}
			}
		}
	}
	return options, nil
}

func parseClientCounts(text string) ([]int, error) {
	seen := map[int]bool{}
	var out []int
	for _, part := range strings.Split(text, ",") {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}
		value, err := strconv.Atoi(part)
		if err != nil || value < 1 || value > 256 {
			return nil, fmt.Errorf("client count %q must be an integer from 1 to 256", part)
		}
		if seen[value] {
			return nil, fmt.Errorf("client count %d listed twice", value)
		}
		seen[value] = true
		out = append(out, value)
	}
	if len(out) == 0 {
		return nil, errors.New("no client count given")
	}
	sort.Ints(out)
	return out, nil
}

func parseBaselineConfigs(text string) ([]baselineConfig, error) {
	seen := map[string]bool{}
	var out []baselineConfig
	for _, part := range strings.Split(text, ",") {
		name := strings.TrimSpace(part)
		if name == "" {
			continue
		}
		config, ok := baselineConfigByName(name)
		if !ok {
			names := []string{}
			for _, known := range baselineConfigs {
				names = append(names, known.Name)
			}
			return nil, fmt.Errorf("unknown configuration %q (known: %s)", name, strings.Join(names, ", "))
		}
		if seen[name] {
			return nil, fmt.Errorf("configuration %q listed twice", name)
		}
		seen[name] = true
		out = append(out, config)
	}
	if len(out) == 0 {
		return nil, errors.New("no configuration given")
	}
	return out, nil
}

// --- endpoints ----------------------------------------------------------------------

// endpoint is one configuration listening on its own loopback port.
type endpoint struct {
	config   baselineConfig
	url      string
	bearer   string
	client   *http.Client
	server   *http.Server
	done     chan error
	evidence *evidenceRun
	gateway  *gateway
	direct   *directServer
}

func startEndpoint(ctx context.Context, w *world, run runIdentity, provider *providerHost, grant *signedGrant, config baselineConfig, dir string, clients int) (*endpoint, error) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return nil, err
	}
	point := &endpoint{config: config, url: "http://" + listener.Addr().String() + "/mcp", done: make(chan error, 1)}
	var handler http.Handler
	if config.gateway {
		spec := gatewaySpec{Escalation: devcomposition.EscalationFlag, Grant: grant}
		if config.audit {
			if point.evidence, err = newEvidenceRun(filepath.Join(dir, "run"), run.Label+"-"+safeName(config.Name)); err != nil {
				listener.Close()
				return nil, err
			}
			spec.Sink = point.evidence
		}
		if config.journal {
			spec.Journal = filepath.Join(dir, "operations.jsonl")
		}
		if point.gateway, err = buildGateway(ctx, w, run, provider, spec); err != nil {
			listener.Close()
			return nil, err
		}
		if point.evidence != nil {
			if err := point.evidence.begin(w, point.gateway, grant, "baseline "+config.Name); err != nil {
				listener.Close()
				return nil, err
			}
		}
		handler, point.bearer = point.gateway.comp.MCP, point.gateway.bearer
	} else {
		if point.direct, err = newDirectServer(w, run, provider); err != nil {
			listener.Close()
			return nil, err
		}
		handler = point.direct
	}
	point.client = &http.Client{Transport: &http.Transport{
		MaxIdleConns: clients * 2, MaxIdleConnsPerHost: clients * 2, MaxConnsPerHost: 0,
		DisableCompression: true, IdleConnTimeout: time.Minute,
	}}
	point.server = &http.Server{Handler: handler, ReadHeaderTimeout: 10 * time.Second}
	go func() { point.done <- point.server.Serve(listener) }()
	return point, nil
}

// close stops the server, closes the evidence folder and verifies it.
func (point *endpoint) close(provider *providerHost) *verifyOutcome {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	_ = point.server.Shutdown(ctx)
	<-point.done
	point.client.CloseIdleConnections()
	if point.evidence == nil {
		return nil
	}
	if err := point.evidence.finish(provider); err != nil {
		return &verifyOutcome{Error: err.Error()}
	}
	outcome := verifyPinned(point.evidence)
	return &outcome
}

func (point *endpoint) entries() int {
	if point.evidence == nil {
		return 0
	}
	point.evidence.mu.Lock()
	defer point.evidence.mu.Unlock()
	return len(point.evidence.events)
}

func safeName(name string) string { return strings.ReplaceAll(name, "+", "-") }

// workloadCall returns the tool and arguments of one call.
func workloadCall(workload string, config baselineConfig) (string, map[string]any) {
	id := newOperationID()
	if workload == "message" {
		return toolMessage, messageArgs(id, []string{"ops.lead"}, "Dock schedule", "Dock 3 is reserved for the Thursday pickup.")
	}
	if config.flagged {
		// AED 6,000.00: above the AED 5,000.00 automatic limit, within the
		// hard limit: FIN-APPROVAL-LIMIT, flagged for audit in flag mode.
		return toolPayment, paymentArgs(id, "payee.office-supplies", uint64(600_000), "AED", "Printer toner")
	}
	return toolPayment, paymentArgs(id, "payee.office-supplies", uint64(12_500), "AED", "Printer toner")
}

// timedCall sends one tools/call and measures it from just before the
// request is written to the moment the response body has been read.
func (point *endpoint) timedCall(ctx context.Context, tool string, arguments map[string]any) (time.Duration, callResult) {
	body, err := toolCallBody(tool, arguments)
	if err != nil {
		return 0, callResult{Error: err.Error()}
	}
	request, err := http.NewRequestWithContext(ctx, http.MethodPost, point.url, bytes.NewReader(body))
	if err != nil {
		return 0, callResult{Error: err.Error()}
	}
	setToolHeaders(request.Header, tool, point.bearer)
	start := hrTicks()
	response, err := point.client.Do(request)
	if err != nil {
		return hrElapsed(start, hrTicks()), callResult{Error: "transport: " + err.Error()}
	}
	raw, readErr := io.ReadAll(io.LimitReader(response.Body, 8<<20))
	elapsed := hrElapsed(start, hrTicks())
	response.Body.Close()
	if readErr != nil {
		return elapsed, callResult{HTTPStatus: response.StatusCode, Error: "read: " + readErr.Error()}
	}
	return elapsed, parseCallResponse(response.StatusCode, raw)
}

// --- the direct tool server ----------------------------------------------------------

// directServer executes a tools/call without the gateway: the adapter's
// request format and transport, the provider's receipt check, nothing else.
type directServer struct {
	config    devcomposition.Config
	runID     [16]byte
	transport *adapters.HTTPTransport
	receipts  adapters.SignedReceiptVerifier
}

func newDirectServer(w *world, run runIdentity, provider *providerHost) (*directServer, error) {
	secret, err := devcomposition.NewGatewayBearerSecret(randomToken())
	if err != nil {
		return nil, err
	}
	recipients, blobs, payees := w.gatewayInputs()
	transport, err := adapters.NewHTTPTransport(provider.origin)
	if err != nil {
		return nil, err
	}
	return &directServer{
		config: devcomposition.Config{
			Identity: w.identity(), GatewayBearer: secret, SimulatorOrigin: provider.origin, RunID: run.ID, TaskID: worldTask,
			RegistrySnapshotObjectHash: w.registry, InitialStateObjectHash: run.InitialState,
			Recipients: recipients, Blobs: blobs, PayeeDisplayNames: payees,
		},
		runID: run.ID, transport: transport,
		receipts: adapters.SignedReceiptVerifier{
			Resolver: singleKey{kid: provider.kid, public: append(ed25519.PublicKey(nil), provider.public...), role: "SIMULATOR_PROVIDER"},
			Now:      func() uint64 { return uint64(time.Now().Unix()) },
		},
	}, nil
}

var adapterAudiences = map[effects.EffectType]string{
	effects.ExternalMessageSend:    "urn:agentgate:adapter:external-message:v1",
	effects.DocumentRelease:        "urn:agentgate:adapter:document-release:v1",
	effects.FinancialRequestCreate: "urn:agentgate:adapter:financial-request:v1",
}

func (server *directServer) ServeHTTP(writer http.ResponseWriter, request *http.Request) {
	body, err := io.ReadAll(io.LimitReader(request.Body, 1<<20))
	if err != nil {
		http.Error(writer, "read", http.StatusBadRequest)
		return
	}
	var rpc struct {
		ID     any `json:"id"`
		Params struct {
			Name      string         `json:"name"`
			Arguments map[string]any `json:"arguments"`
		} `json:"params"`
	}
	decoder := json.NewDecoder(bytes.NewReader(body))
	decoder.UseNumber()
	if err := decoder.Decode(&rpc); err != nil {
		http.Error(writer, "decode", http.StatusBadRequest)
		return
	}
	structured := server.execute(request.Context(), effects.EffectType(rpc.Params.Name), rpc.Params.Arguments)
	text, _ := json.Marshal(structured)
	isError := structured["status"] != "COMMITTED"
	writer.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(writer).Encode(map[string]any{"jsonrpc": "2.0", "id": rpc.ID, "result": map[string]any{
		"content": []any{map[string]any{"type": "text", "text": string(text)}}, "structuredContent": structured, "isError": isError,
	}})
}

func (server *directServer) execute(ctx context.Context, effectType effects.EffectType, arguments map[string]any) map[string]any {
	rejected := func(reason string, err error) map[string]any {
		return map[string]any{"status": "REJECTED", "reason": reason, "dispatched": false, "message": err.Error()}
	}
	effect, err := devcomposition.InspectNormalizedEffect(ctx, server.config, effectType, arguments)
	if err != nil {
		return rejected("invalid_request", err)
	}
	audience, ok := adapterAudiences[effectType]
	if !ok {
		return rejected("invalid_request", errors.New("unknown tool"))
	}
	prepared, err := adapters.Prepare(effect, server.runID, adapters.AuthorityContext{CapabilityAudience: audience, RegistrySnapshotObjectHash: server.config.RegistrySnapshotObjectHash, RegistryEpoch: 1})
	if err != nil {
		return rejected("invalid_request", err)
	}
	response, err := server.transport.RoundTrip(ctx, adapters.WireRequest{Method: "POST", Path: prepared.Path(), Headers: prepared.Headers(), Body: prepared.BodyBytes()},
		func(context.Context) error { return nil })
	if err != nil {
		return map[string]any{"status": "UNCERTAIN", "reason": "transport_error", "dispatched": true, "message": err.Error()}
	}
	verified, err := server.receipts.VerifySimulatorReceiptDetailed(response.Body, adapters.ExpectedReceipt{
		TenantID: effect.TenantID, OperationID: effect.OperationID, EffectType: effect.EffectType, AdapterID: prepared.AdapterID(),
		EffectDigest: prepared.EffectDigest(), ProviderRequestDigest: prepared.ProviderRequestDigest(), IdempotencyKeyHash: prepared.IdempotencyKeyHash(), RunID: server.runID,
	})
	if err != nil {
		return map[string]any{"status": "UNCERTAIN", "reason": "provider_receipt_invalid", "dispatched": true, "message": err.Error()}
	}
	status := "COMMITTED"
	if verified.Outcome != adapters.Applied {
		status = "REJECTED"
	}
	return map[string]any{
		"status": status, "dispatched": true, "outcome": string(verified.Outcome), "provider_reference": verified.ProviderReference,
		"signed_provider_receipt": base64.StdEncoding.EncodeToString(response.Body), "message": "executed directly (no gateway)",
	}
}

// --- statistics ---------------------------------------------------------------------

// latencyStats describes a latency sample in microseconds. Percentiles use
// linear interpolation between order statistics; every observation counts.
type latencyStats struct {
	N      int     `json:"n"`
	Min    float64 `json:"min_us"`
	P50    float64 `json:"p50_us"`
	P90    float64 `json:"p90_us"`
	P95    float64 `json:"p95_us"`
	P99    float64 `json:"p99_us"`
	Max    float64 `json:"max_us"`
	Mean   float64 `json:"mean_us"`
	StdDev float64 `json:"stddev_us"`
}

func latencySummary(values []float64) latencyStats {
	stats := latencyStats{N: len(values)}
	if len(values) == 0 {
		return stats
	}
	sorted := sortedCopy(values)
	sum := 0.0
	for _, value := range sorted {
		sum += value
	}
	mean := sum / float64(len(sorted))
	variance := 0.0
	for _, value := range sorted {
		variance += (value - mean) * (value - mean)
	}
	if len(sorted) > 1 {
		variance /= float64(len(sorted) - 1)
	}
	stats.Min, stats.Max = round(sorted[0], 1), round(sorted[len(sorted)-1], 1)
	stats.P50, stats.P90 = round(percentile(sorted, 0.50), 1), round(percentile(sorted, 0.90), 1)
	stats.P95, stats.P99 = round(percentile(sorted, 0.95), 1), round(percentile(sorted, 0.99), 1)
	stats.Mean, stats.StdDev = round(mean, 1), round(math.Sqrt(variance), 1)
	return stats
}

// pairedDifference summarizes per-trial differences b - a (microseconds):
// the median with a distribution-free 95% interval from the sign test
// (order statistics k and n-1-k, k = floor((n - 1.96 sqrt(n)) / 2)), the
// mean, and the share of trials in which b took longer.
type pairedDifference struct {
	Compare      string       `json:"compare"` // "b - a"
	N            int          `json:"n"`
	MedianUS     float64      `json:"median_us"`
	CI95LowUS    *float64     `json:"median_ci95_low_us"`
	CI95HighUS   *float64     `json:"median_ci95_high_us"`
	MeanUS       float64      `json:"mean_us"`
	ShareSlower  float64      `json:"share_of_trials_b_slower"`
	Distribution latencyStats `json:"distribution"`
}

func pairedDiff(label string, a, b []float64) pairedDifference {
	n := min(len(a), len(b))
	diffs := make([]float64, 0, n)
	slower := 0
	for index := 0; index < n; index++ {
		diffs = append(diffs, b[index]-a[index])
		if b[index] > a[index] {
			slower++
		}
	}
	out := pairedDifference{Compare: label, N: n, Distribution: latencySummary(diffs)}
	if n == 0 {
		return out
	}
	sorted := sortedCopy(diffs)
	out.MedianUS = round(percentile(sorted, 0.5), 1)
	sum := 0.0
	for _, value := range diffs {
		sum += value
	}
	out.MeanUS = round(sum/float64(n), 1)
	out.ShareSlower = round(float64(slower)/float64(n), 4)
	if k := int(math.Floor((float64(n) - 1.96*math.Sqrt(float64(n))) / 2)); k >= 0 && n-1-k > k {
		low, high := round(sorted[k], 1), round(sorted[n-1-k], 1)
		out.CI95LowUS, out.CI95HighUS = &low, &high
	}
	return out
}

func us(duration time.Duration) float64 { return float64(duration) / float64(time.Microsecond) }

// --- results ------------------------------------------------------------------------

type sequentialObservation struct {
	Block     int     `json:"block"`
	Trial     int     `json:"trial"` // 0 for warm-up calls
	Config    string  `json:"config"`
	Position  int     `json:"position_in_trial"`
	Warmup    bool    `json:"warmup"`
	LatencyUS float64 `json:"latency_us"`
	Status    string  `json:"status"`
}

type sequentialConfigResult struct {
	Config         string       `json:"config"`
	Latency        latencyStats `json:"latency"`
	Failed         int          `json:"calls_not_committed"`
	EntriesPerCall float64      `json:"audit_entries_per_call,omitempty"`
	Evidence       []string     `json:"evidence_assurance,omitempty"`
	EvidenceFails  []string     `json:"evidence_failing_checks,omitempty"`
	Description    string       `json:"description"`
	verify         []verifyOutcome
}

type sequentialResult struct {
	Trials      int                      `json:"trials"`
	Blocks      int                      `json:"blocks"`
	Configs     []sequentialConfigResult `json:"configs"`
	Paired      []pairedDifference       `json:"paired_differences"`
	PhaseUsage  resourceUsage            `json:"phase_resources"`
	ElapsedSecs float64                  `json:"elapsed_s"`
}

type concurrentObservation struct {
	Clients   int     `json:"clients"`
	Config    string  `json:"config"`
	Client    int     `json:"client"`
	Index     int     `json:"index"`
	Warmup    bool    `json:"warmup"`
	StartUS   float64 `json:"start_offset_us"`
	LatencyUS float64 `json:"latency_us"`
	Status    string  `json:"status"`
}

type concurrentCell struct {
	Clients        int           `json:"clients"`
	Config         string        `json:"config"`
	Calls          int           `json:"calls"`
	Failed         int           `json:"calls_not_committed"`
	WallSeconds    float64       `json:"wall_s"`
	Throughput     float64       `json:"throughput_calls_per_s"`
	Latency        latencyStats  `json:"latency"`
	Resources      resourceUsage `json:"resources"`
	CPUPerCallMS   float64       `json:"cpu_ms_per_call"`
	AllocPerCallKB float64       `json:"alloc_kib_per_call"`
	Evidence       string        `json:"evidence_assurance,omitempty"`
	EvidenceFails  []string      `json:"evidence_failing_checks,omitempty"`
}

type baselineResult struct {
	Note        string            `json:"note"`
	Method      []string          `json:"method"`
	Timer       string            `json:"timer"`
	Environment environment       `json:"environment"`
	Workload    string            `json:"workload"`
	Configs     []baselineConfig  `json:"configs"`
	Sequential  *sequentialResult `json:"sequential,omitempty"`
	Concurrent  []concurrentCell  `json:"concurrent,omitempty"`
	Files       map[string]string `json:"files"`
	Errors      []string          `json:"errors"`
}

// --- running ------------------------------------------------------------------------

func runBaseline(args []string, stdout io.Writer) error {
	options, err := parseBaselineFlags(args, stdout)
	if err != nil {
		return err
	}
	outDir, workDir, err := prepareDirs(options.outDir, options.workDir, "baseline")
	if err != nil {
		return err
	}
	ctx, stop := interruptible()
	defer stop()
	w, err := newWorld()
	if err != nil {
		return err
	}
	result := baselineResult{
		Note: "Local measurements on one machine with simulated providers over loopback. They compare matched configurations of this " +
			"prototype under one synthetic workload; they are not a general performance claim, and repeated timing calls are not independent workloads.",
		Method: []string{
			"Identical transport: every configuration is reached by JSON-RPC tools/call over loopback HTTP (keep-alive client, one per configuration) and reaches the provider with the adapter's HTTP transport (one fresh TCP connection per provider request).",
			"Identical provider: a provider host (internal/simulator behind its own loopback listener and key); every configuration has its own instance (same code, same transport, its own state) per sequential block and per concurrent cell, so state growth is equal and each evidence folder's provider journal holds only its own effects.",
			fmt.Sprintf("Sequential: %d paired trials in blocks of %d; in each trial every configuration gets one call, in an order rotated by one position per trial; each block starts fresh (provider, gateways, audit logs, journal) after %d warm-up calls per configuration.", options.trials, options.block, options.warmup),
			fmt.Sprintf("Concurrent: client counts %v; each configuration alone per cell, %d warm-up calls then %d measured calls split over the clients, back to back; CPU time is the whole process (client, server, gateway, provider host), memory peaks are sampled every %s.", options.clients, options.warmup, options.loadCalls, options.sampleInterval),
			"Every observation is kept: raw CSVs hold warm-up calls (marked) and every measured call, failed or not; summaries use every measured call (no outlier removal).",
			"Paired differences: per trial b - a; median with a distribution-free 95% interval (sign test order statistics), mean, and the share of trials in which b was slower.",
		},
		Timer: hrMethod(), Environment: currentEnvironment(append([]string{"baseline"}, args...)), Workload: options.workload,
		Configs: baselineConfigs, Files: map[string]string{}, Errors: []string{},
	}
	if !options.skipSequential {
		sequential, observations, err := runSequentialBaseline(ctx, w, workDir, options, stdout)
		if err != nil {
			return err
		}
		result.Sequential = sequential
		if err := writeText(filepath.Join(outDir, "baseline-sequential.csv"), sequentialCSV(observations)); err != nil {
			return err
		}
		result.Files["sequential_observations"] = "baseline-sequential.csv"
	}
	if !options.skipConcurrent {
		cells, observations, errs := runConcurrentBaseline(ctx, w, workDir, options, stdout)
		result.Concurrent = cells
		result.Errors = append(result.Errors, errs...)
		if err := writeText(filepath.Join(outDir, "baseline-concurrent.csv"), concurrentCSV(observations)); err != nil {
			return err
		}
		result.Files["concurrent_observations"] = "baseline-concurrent.csv"
		if err := writeText(filepath.Join(outDir, "baseline-concurrent-summary.csv"), concurrentSummaryCSV(cells)); err != nil {
			return err
		}
		result.Files["concurrent_summary"] = "baseline-concurrent-summary.csv"
	}
	if ctx.Err() != nil {
		return ctx.Err()
	}
	if err := writeJSON(filepath.Join(outDir, "baseline.json"), result); err != nil {
		return err
	}
	if err := writeText(filepath.Join(outDir, "baseline.md"), baselineMarkdown(result)); err != nil {
		return err
	}
	fmt.Fprintf(stdout, "baseline: results in %s\n", displayPath(outDir))
	return nil
}

func statusOf(result callResult) string {
	if result.Status == "" {
		return "ERROR: " + result.Error
	}
	return result.statusKey()
}

func runSequentialBaseline(ctx context.Context, w *world, workDir string, options baselineOptions, stdout io.Writer) (*sequentialResult, []sequentialObservation, error) {
	began := hrTicks()
	configs := options.sequential
	latencies := map[string][]float64{}
	failed := map[string]int{}
	entries := map[string]int{}
	verifications := map[string][]verifyOutcome{}
	var observations []sequentialObservation
	window := beginResources(options.sampleInterval)
	blocks := (options.trials + options.block - 1) / options.block
	trial := 0
	for block := 1; block <= blocks; block++ {
		if ctx.Err() != nil {
			window.end("")
			return nil, nil, ctx.Err()
		}
		label := fmt.Sprintf("baseline-seq-b%02d", block)
		grant, err := signGrant(label, w.openGrant(time.Now()))
		if err != nil {
			return nil, nil, err
		}
		// One provider host per configuration: the same code, key type and
		// transport, each with its own state, so every configuration's
		// provider sees exactly its own calls (equal state growth, and each
		// evidence folder's provider journal holds only its own effects).
		points := make([]*endpoint, len(configs))
		providers := make([]*providerHost, len(configs))
		for index, config := range configs {
			dir := filepath.Join(workDir, label, safeName(config.Name))
			if err := os.MkdirAll(dir, 0o755); err != nil {
				return nil, nil, err
			}
			run, err := newRunIdentity(label + "-" + safeName(config.Name))
			if err != nil {
				return nil, nil, err
			}
			if providers[index], err = startProviderHost(w, run, nil); err != nil {
				return nil, nil, err
			}
			if points[index], err = startEndpoint(ctx, w, run, providers[index], grant, config, dir, 1); err != nil {
				return nil, nil, fmt.Errorf("start %s: %w", config.Name, err)
			}
		}
		for warm := 0; warm < options.warmup; warm++ {
			for index, point := range points {
				tool, arguments := workloadCall(options.workload, configs[index])
				elapsed, answer := point.timedCall(ctx, tool, arguments)
				observations = append(observations, sequentialObservation{Block: block, Config: configs[index].Name, Position: index, Warmup: true, LatencyUS: round(us(elapsed), 2), Status: statusOf(answer)})
			}
		}
		for local := 0; local < options.block && trial < options.trials; local++ {
			trial++
			for position := 0; position < len(points); position++ {
				index := (position + trial) % len(points)
				tool, arguments := workloadCall(options.workload, configs[index])
				elapsed, answer := points[index].timedCall(ctx, tool, arguments)
				name := configs[index].Name
				latencies[name] = append(latencies[name], us(elapsed))
				if answer.Status != string(devcomposition.StatusCommitted) {
					failed[name]++
				}
				observations = append(observations, sequentialObservation{Block: block, Trial: trial, Config: name, Position: position, LatencyUS: round(us(elapsed), 2), Status: statusOf(answer)})
			}
		}
		for index, point := range points {
			entries[configs[index].Name] += point.entries()
			if outcome := point.close(providers[index]); outcome != nil {
				verifications[configs[index].Name] = append(verifications[configs[index].Name], *outcome)
			}
			providers[index].close()
		}
		fmt.Fprintf(stdout, "baseline sequential: block %d/%d done (%d trials)\n", block, blocks, trial)
	}
	usage := window.end("client, all configuration servers, gateways and the provider host (whole process)")
	result := &sequentialResult{Trials: trial, Blocks: blocks, PhaseUsage: usage}
	for _, config := range configs {
		calls := len(latencies[config.Name])
		row := sequentialConfigResult{Config: config.Name, Description: config.Description, Latency: latencySummary(latencies[config.Name]), Failed: failed[config.Name]}
		if config.audit && calls > 0 {
			// Entries written while serving the warm-up and measured calls,
			// per call (RUN_STARTED / DELEGATION_GRANTED are not gateway
			// events and are not counted).
			row.EntriesPerCall = round(float64(entries[config.Name])/float64(calls+options.warmup*blocks), 2)
		}
		for _, outcome := range verifications[config.Name] {
			row.Evidence = append(row.Evidence, outcome.Assurance)
			row.EvidenceFails = append(row.EvidenceFails, outcome.Failing...)
		}
		result.Configs = append(result.Configs, row)
	}
	pairs := [][2]string{{"direct", "policy-only"}, {"policy-only", "full"}, {"direct", "full"}, {"full", "full+journal"}, {"full", "full-flagged"}, {"direct", "full+journal"}}
	for _, pair := range pairs {
		a, okA := latencies[pair[0]]
		b, okB := latencies[pair[1]]
		if okA && okB {
			result.Paired = append(result.Paired, pairedDiff(pair[1]+" - "+pair[0], a, b))
		}
	}
	result.ElapsedSecs = round(hrElapsed(began, hrTicks()).Seconds(), 2)
	return result, observations, nil
}

func runConcurrentBaseline(ctx context.Context, w *world, workDir string, options baselineOptions, stdout io.Writer) ([]concurrentCell, []concurrentObservation, []string) {
	var cells []concurrentCell
	var observations []concurrentObservation
	var errs []string
	for level, clients := range options.clients {
		for offset := range options.concurrent {
			if ctx.Err() != nil {
				return cells, observations, append(errs, ctx.Err().Error())
			}
			config := options.concurrent[(offset+level)%len(options.concurrent)]
			cell, cellObservations, err := runConcurrentCell(ctx, w, workDir, options, config, clients)
			if err != nil {
				errs = append(errs, fmt.Sprintf("%s with %d clients: %v", config.Name, clients, err))
				continue
			}
			cells = append(cells, cell)
			observations = append(observations, cellObservations...)
			fmt.Fprintf(stdout, "baseline concurrent: %-12s clients=%-2d %7.1f calls/s  p50 %8.0f us  p99 %8.0f us  failed %d\n",
				config.Name, clients, cell.Throughput, cell.Latency.P50, cell.Latency.P99, cell.Failed)
		}
	}
	sort.SliceStable(cells, func(left, right int) bool {
		if cells[left].Clients != cells[right].Clients {
			return cells[left].Clients < cells[right].Clients
		}
		return configIndex(cells[left].Config) < configIndex(cells[right].Config)
	})
	return cells, observations, errs
}

func configIndex(name string) int {
	for index, config := range baselineConfigs {
		if config.Name == name {
			return index
		}
	}
	return len(baselineConfigs)
}

func runConcurrentCell(ctx context.Context, w *world, workDir string, options baselineOptions, config baselineConfig, clients int) (concurrentCell, []concurrentObservation, error) {
	cell := concurrentCell{Clients: clients, Config: config.Name}
	label := fmt.Sprintf("baseline-c%02d-%s", clients, safeName(config.Name))
	dir := filepath.Join(workDir, label)
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return cell, nil, err
	}
	run, err := newRunIdentity(label)
	if err != nil {
		return cell, nil, err
	}
	provider, err := startProviderHost(w, run, nil)
	if err != nil {
		return cell, nil, err
	}
	defer provider.close()
	grant, err := signGrant(label, w.openGrant(time.Now()))
	if err != nil {
		return cell, nil, err
	}
	point, err := startEndpoint(ctx, w, run, provider, grant, config, dir, clients)
	if err != nil {
		return cell, nil, err
	}
	var observations []concurrentObservation
	for index := 0; index < options.warmup; index++ {
		tool, arguments := workloadCall(options.workload, config)
		elapsed, answer := point.timedCall(ctx, tool, arguments)
		observations = append(observations, concurrentObservation{Clients: clients, Config: config.Name, Index: index, Warmup: true, LatencyUS: round(us(elapsed), 2), Status: statusOf(answer)})
	}
	perClient := make([]int, clients)
	for index := 0; index < options.loadCalls; index++ {
		perClient[index%clients]++
	}
	results := make([][]concurrentObservation, clients)
	start := make(chan struct{})
	var wait sync.WaitGroup
	var windowStart int64
	window := beginResources(options.sampleInterval)
	for client := 0; client < clients; client++ {
		wait.Add(1)
		go func() {
			defer wait.Done()
			<-start
			for index := 0; index < perClient[client]; index++ {
				tool, arguments := workloadCall(options.workload, config)
				callStart := hrTicks()
				elapsed, answer := point.timedCall(ctx, tool, arguments)
				results[client] = append(results[client], concurrentObservation{Clients: clients, Config: config.Name, Client: client, Index: index,
					StartUS: round(us(hrElapsed(windowStart, callStart)), 2), LatencyUS: round(us(elapsed), 2), Status: statusOf(answer)})
			}
		}()
	}
	windowStart = hrTicks()
	close(start)
	wait.Wait()
	usage := window.end("client goroutines, the configuration's server, gateway and the provider host (whole process)")
	var latencies []float64
	for _, list := range results {
		for _, observation := range list {
			latencies = append(latencies, observation.LatencyUS)
			if !strings.HasPrefix(observation.Status, "COMMITTED/") {
				cell.Failed++
			}
			observations = append(observations, observation)
		}
	}
	cell.Calls = len(latencies)
	cell.WallSeconds = round(usage.WallMS/1000, 4)
	if usage.WallMS > 0 {
		cell.Throughput = round(float64(cell.Calls)/(usage.WallMS/1000), 2)
	}
	cell.Latency = latencySummary(latencies)
	cell.Resources = usage
	if cell.Calls > 0 {
		cell.CPUPerCallMS = round(usage.CPUTotalMS/float64(cell.Calls), 3)
		cell.AllocPerCallKB = round(float64(usage.AllocBytes)/1024/float64(cell.Calls), 2)
	}
	if outcome := point.close(provider); outcome != nil {
		cell.Evidence = outcome.Assurance
		if outcome.Error != "" {
			cell.Evidence = "error: " + outcome.Error
		}
		cell.EvidenceFails = outcome.Failing
	}
	return cell, observations, nil
}

// --- output -------------------------------------------------------------------------

func sequentialCSV(observations []sequentialObservation) string {
	var b strings.Builder
	b.WriteString(csvLine("block", "trial", "config", "position_in_trial", "warmup", "latency_us", "status"))
	for _, o := range observations {
		b.WriteString(csvLine(fmt.Sprint(o.Block), fmt.Sprint(o.Trial), o.Config, fmt.Sprint(o.Position), boolText(o.Warmup), strconv.FormatFloat(o.LatencyUS, 'f', 2, 64), o.Status))
	}
	return b.String()
}

func concurrentCSV(observations []concurrentObservation) string {
	var b strings.Builder
	b.WriteString(csvLine("clients", "config", "client", "index", "warmup", "start_offset_us", "latency_us", "status"))
	for _, o := range observations {
		b.WriteString(csvLine(fmt.Sprint(o.Clients), o.Config, fmt.Sprint(o.Client), fmt.Sprint(o.Index), boolText(o.Warmup),
			strconv.FormatFloat(o.StartUS, 'f', 2, 64), strconv.FormatFloat(o.LatencyUS, 'f', 2, 64), o.Status))
	}
	return b.String()
}

func concurrentSummaryCSV(cells []concurrentCell) string {
	var b strings.Builder
	b.WriteString(csvLine("clients", "config", "calls", "failed", "wall_s", "throughput_calls_per_s", "p50_us", "p90_us", "p95_us", "p99_us", "max_us", "mean_us",
		"cpu_total_ms", "cpu_ms_per_call", "cpu_utilization_cores", "alloc_kib_per_call", "gc_cycles", "peak_heap_objects_bytes", "peak_go_memory_bytes",
		"peak_working_set_bytes", "evidence"))
	for _, c := range cells {
		b.WriteString(csvLine(fmt.Sprint(c.Clients), c.Config, fmt.Sprint(c.Calls), fmt.Sprint(c.Failed), fmt.Sprint(c.WallSeconds), fmt.Sprint(c.Throughput),
			fmt.Sprint(c.Latency.P50), fmt.Sprint(c.Latency.P90), fmt.Sprint(c.Latency.P95), fmt.Sprint(c.Latency.P99), fmt.Sprint(c.Latency.Max), fmt.Sprint(c.Latency.Mean),
			fmt.Sprint(c.Resources.CPUTotalMS), fmt.Sprint(c.CPUPerCallMS), fmt.Sprint(c.Resources.CPUUtilization), fmt.Sprint(c.AllocPerCallKB), fmt.Sprint(c.Resources.GCCycles),
			fmt.Sprint(c.Resources.PeakHeapObjectsBytes), fmt.Sprint(c.Resources.PeakGoMemoryBytes), fmt.Sprint(c.Resources.PeakWorkingSetBytes), c.Evidence))
	}
	return b.String()
}

func optionalUS(value *float64) string {
	if value == nil {
		return "n/a"
	}
	return fmt.Sprintf("%.0f", *value)
}

func baselineMarkdown(result baselineResult) string {
	var b strings.Builder
	fmt.Fprintf(&b, "# Baselines and load\n\n%s\n\nCommand: `%s`. Workload: %s. Go %s on %s/%s, %d CPUs, GOMAXPROCS %d.  \nTimer: %s. Wall-clock step observed for time.Now: %.4f ms.\n\n",
		result.Note, result.Environment.Command, result.Workload, result.Environment.GoVersion, result.Environment.GOOS, result.Environment.GOARCH,
		result.Environment.NumCPU, result.Environment.GOMAXPROCS, result.Timer, result.Environment.ClockGranularityMS)
	b.WriteString("## Configurations\n\n")
	for _, config := range result.Configs {
		fmt.Fprintf(&b, "- **%s**: %s\n", config.Name, config.Description)
	}
	b.WriteString("\n## Method\n\n")
	for _, line := range result.Method {
		fmt.Fprintf(&b, "- %s\n", line)
	}
	if sequential := result.Sequential; sequential != nil {
		fmt.Fprintf(&b, "\n## Sequential, paired trials (%d trials, %d blocks, %.1f s)\n\nLatency per call in microseconds (all measured calls).\n\n", sequential.Trials, sequential.Blocks, sequential.ElapsedSecs)
		b.WriteString("| config | n | min | p50 | p90 | p95 | p99 | max | mean | not committed | audit entries/call | evidence |\n|---|---|---|---|---|---|---|---|---|---|---|---|\n")
		for _, row := range sequential.Configs {
			evidence := countKeys(countStrings(row.Evidence))
			if len(row.EvidenceFails) > 0 {
				evidence += " (failing: " + strings.Join(uniqueStrings(row.EvidenceFails), ", ") + ")"
			}
			fmt.Fprintf(&b, "| %s | %d | %.0f | %.0f | %.0f | %.0f | %.0f | %.0f | %.0f | %d | %.2f | %s |\n", row.Config, row.Latency.N, row.Latency.Min, row.Latency.P50,
				row.Latency.P90, row.Latency.P95, row.Latency.P99, row.Latency.Max, row.Latency.Mean, row.Failed, row.EntriesPerCall, evidence)
		}
		b.WriteString("\nPaired differences (per trial, microseconds; 95% interval of the median from the sign test):\n\n| difference | n | median | 95% CI | mean | p95 | share of trials slower |\n|---|---|---|---|---|---|---|\n")
		for _, pair := range sequential.Paired {
			fmt.Fprintf(&b, "| %s | %d | %.0f | [%s, %s] | %.0f | %.0f | %.1f%% |\n", pair.Compare, pair.N, pair.MedianUS, optionalUS(pair.CI95LowUS), optionalUS(pair.CI95HighUS),
				pair.MeanUS, pair.Distribution.P95, pair.ShareSlower*100)
		}
		usage := sequential.PhaseUsage
		fmt.Fprintf(&b, "\nWhole sequential phase: CPU %.0f ms (user %.0f, kernel %.0f) over %.0f ms wall; %.1f MiB allocated; peak working set %.1f MiB (sampled).\n",
			usage.CPUTotalMS, usage.CPUUserMS, usage.CPUKernelMS, usage.WallMS, float64(usage.AllocBytes)/(1<<20), float64(usage.PeakWorkingSetBytes)/(1<<20))
	}
	if len(result.Concurrent) > 0 {
		b.WriteString("\n## Concurrent load\n\nEach cell runs one configuration alone; latency in microseconds; CPU is the whole process.\n\n")
		b.WriteString("| clients | config | calls | not committed | calls/s | p50 | p95 | p99 | max | CPU ms/call | CPU cores busy | KiB alloc/call | peak heap MiB | peak working set MiB | evidence |\n|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|\n")
		for _, c := range result.Concurrent {
			fmt.Fprintf(&b, "| %d | %s | %d | %d | %.1f | %.0f | %.0f | %.0f | %.0f | %.3f | %.2f | %.1f | %.1f | %.1f | %s |\n", c.Clients, c.Config, c.Calls, c.Failed,
				c.Throughput, c.Latency.P50, c.Latency.P95, c.Latency.P99, c.Latency.Max, c.CPUPerCallMS, c.Resources.CPUUtilization, c.AllocPerCallKB,
				float64(c.Resources.PeakHeapObjectsBytes)/(1<<20), float64(c.Resources.PeakWorkingSetBytes)/(1<<20), c.Evidence)
		}
		if len(result.Concurrent) > 0 {
			usage := result.Concurrent[0].Resources
			fmt.Fprintf(&b, "\nCPU source: %s (resolution: %s). Memory: %s, sampled every %.0f ms; heap = runtime/metrics /memory/classes/heap/objects:bytes.\n",
				usage.CPUSource, usage.CPUResolutionCaveat, usage.MemorySource, usage.SampleIntervalMS)
		}
	}
	if len(result.Errors) > 0 {
		b.WriteString("\n## Errors\n\n")
		for _, line := range result.Errors {
			fmt.Fprintf(&b, "- %s\n", line)
		}
	}
	b.WriteString("\n## Files\n\n")
	for _, key := range sortedKeys(result.Files) {
		fmt.Fprintf(&b, "- %s: `%s`\n", key, result.Files[key])
	}
	return b.String()
}

func countStrings(values []string) map[string]int {
	out := map[string]int{}
	for _, value := range values {
		out[value]++
	}
	return out
}

func uniqueStrings(values []string) []string {
	seen := map[string]bool{}
	var out []string
	for _, value := range values {
		if !seen[value] {
			seen[value] = true
			out = append(out, value)
		}
	}
	sort.Strings(out)
	return out
}
