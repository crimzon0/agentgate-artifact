//go:build !windows

package main

import (
	"runtime/metrics"
	"time"
)

// Portable fallback of clock_windows.go: Go's monotonic clock for latencies
// and runtime/metrics estimates for CPU and memory (no process working set).

var monotonicBase = time.Now()

func hrTicks() int64 { return int64(time.Since(monotonicBase)) }

func hrElapsed(start, end int64) time.Duration { return time.Duration(end - start) }

func hrMethod() string { return "Go monotonic clock (time.Since)" }

type processSample struct {
	UserCPU          time.Duration
	KernelCPU        time.Duration
	WorkingSet       uint64
	PeakWorkingSet   uint64
	PrivateBytes     uint64
	CPUSource        string
	MemorySource     string
	CPUResolutionMax string
}

func readProcessSample() processSample {
	samples := []metrics.Sample{{Name: "/cpu/classes/user:cpu-seconds"}, {Name: "/cpu/classes/total:cpu-seconds"}, {Name: "/memory/classes/total:bytes"}}
	metrics.Read(samples)
	sample := processSample{CPUSource: "runtime/metrics /cpu/classes (Go runtime estimate)", MemorySource: "runtime/metrics /memory/classes/total:bytes (Go-mapped memory)", CPUResolutionMax: "estimate"}
	if samples[0].Value.Kind() == metrics.KindFloat64 {
		sample.UserCPU = time.Duration(samples[0].Value.Float64() * float64(time.Second))
	}
	if samples[1].Value.Kind() == metrics.KindFloat64 {
		total := time.Duration(samples[1].Value.Float64() * float64(time.Second))
		if total > sample.UserCPU {
			sample.KernelCPU = total - sample.UserCPU
		}
	}
	if samples[2].Value.Kind() == metrics.KindUint64 {
		sample.WorkingSet = samples[2].Value.Uint64()
		sample.PeakWorkingSet = sample.WorkingSet
	}
	return sample
}
