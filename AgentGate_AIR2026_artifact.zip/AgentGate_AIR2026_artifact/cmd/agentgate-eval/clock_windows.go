//go:build windows

package main

import (
	"fmt"
	"time"
	"unsafe"

	"golang.org/x/sys/windows"
)

// High-resolution timing and process statistics on Windows.
//
// Latencies are read from QueryPerformanceCounter (kernel32), whose frequency
// is fixed at boot (typically 10 MHz, i.e. 100 ns ticks) and which is
// monotonic; Go's wall clock on Windows can advance in steps of 0.5 ms or
// more (see environment.clock_granularity_ms). Process CPU time comes from
// GetProcessTimes (user and kernel time, 100 ns units, updated at the
// scheduler tick) and memory from K32GetProcessMemoryInfo (working set).

var (
	kernel32              = windows.NewLazySystemDLL("kernel32.dll")
	procQueryPerfCounter  = kernel32.NewProc("QueryPerformanceCounter")
	procQueryPerfFreq     = kernel32.NewProc("QueryPerformanceFrequency")
	procGetProcessMemInfo = kernel32.NewProc("K32GetProcessMemoryInfo")
	qpcFrequency          int64
)

func init() {
	var frequency int64
	if result, _, _ := procQueryPerfFreq.Call(uintptr(unsafe.Pointer(&frequency))); result != 0 && frequency > 0 {
		qpcFrequency = frequency
	}
}

var monotonicBase = time.Now()

// hrTicks is the current high-resolution counter value.
func hrTicks() int64 {
	if qpcFrequency == 0 {
		return int64(time.Since(monotonicBase))
	}
	var counter int64
	procQueryPerfCounter.Call(uintptr(unsafe.Pointer(&counter)))
	return counter
}

// hrElapsed converts a tick difference to a duration without overflow.
func hrElapsed(start, end int64) time.Duration {
	delta := end - start
	if qpcFrequency == 0 {
		return time.Duration(delta)
	}
	seconds := delta / qpcFrequency
	remainder := delta % qpcFrequency
	return time.Duration(seconds)*time.Second + time.Duration(remainder*int64(time.Second)/qpcFrequency)
}

// hrMethod describes the timer for the results.
func hrMethod() string {
	if qpcFrequency == 0 {
		return "Go monotonic clock (QueryPerformanceFrequency unavailable)"
	}
	return fmt.Sprintf("QueryPerformanceCounter (kernel32 via golang.org/x/sys/windows), frequency %d Hz, tick %.1f ns", qpcFrequency, 1e9/float64(qpcFrequency))
}

// processMemoryCounters is PROCESS_MEMORY_COUNTERS (psapi.h).
type processMemoryCounters struct {
	CB                         uint32
	PageFaultCount             uint32
	PeakWorkingSetSize         uintptr
	WorkingSetSize             uintptr
	QuotaPeakPagedPoolUsage    uintptr
	QuotaPagedPoolUsage        uintptr
	QuotaPeakNonPagedPoolUsage uintptr
	QuotaNonPagedPoolUsage     uintptr
	PagefileUsage              uintptr
	PeakPagefileUsage          uintptr
}

// processSample is one reading of the process's CPU time and memory.
type processSample struct {
	UserCPU          time.Duration
	KernelCPU        time.Duration
	WorkingSet       uint64
	PeakWorkingSet   uint64 // since process start
	PrivateBytes     uint64
	CPUSource        string
	MemorySource     string
	CPUResolutionMax string
}

func filetimeDuration(ft windows.Filetime) time.Duration {
	return time.Duration((int64(ft.HighDateTime)<<32 | int64(ft.LowDateTime)) * 100)
}

func readProcessSample() processSample {
	sample := processSample{CPUSource: "GetProcessTimes (user + kernel)", MemorySource: "K32GetProcessMemoryInfo (working set)", CPUResolutionMax: "scheduler tick (about 15.6 ms on an idle system)"}
	var creation, exit, kernel, user windows.Filetime
	if err := windows.GetProcessTimes(windows.CurrentProcess(), &creation, &exit, &kernel, &user); err == nil {
		sample.UserCPU, sample.KernelCPU = filetimeDuration(user), filetimeDuration(kernel)
	}
	counters := processMemoryCounters{}
	counters.CB = uint32(unsafe.Sizeof(counters))
	if result, _, _ := procGetProcessMemInfo.Call(uintptr(windows.CurrentProcess()), uintptr(unsafe.Pointer(&counters)), uintptr(counters.CB)); result != 0 {
		sample.WorkingSet, sample.PeakWorkingSet, sample.PrivateBytes = uint64(counters.WorkingSetSize), uint64(counters.PeakWorkingSetSize), uint64(counters.PagefileUsage)
	}
	return sample
}
