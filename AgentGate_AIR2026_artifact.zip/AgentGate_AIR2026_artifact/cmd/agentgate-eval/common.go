package main

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"os"
	"os/signal"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"time"

	"agentgate/internal/audit"
	"agentgate/internal/auditverify"
	"agentgate/internal/demo"
)

// --- environment -------------------------------------------------------------

// environment describes where and how the measurements were taken.
type environment struct {
	GoVersion  string `json:"go_version"`
	GOOS       string `json:"goos"`
	GOARCH     string `json:"goarch"`
	NumCPU     int    `json:"num_cpu"`
	GOMAXPROCS int    `json:"gomaxprocs"`
	// ClockGranularityMS is the median observed step of Go's wall clock.
	// On Windows it follows the system timer and is typically 0.5 to 1 ms
	// (or 15.6 ms on an idle system); single durations below it are not
	// resolved, which is why per-entry costs are measured over batches.
	ClockGranularityMS float64 `json:"clock_granularity_ms"`
	StartedAt          string  `json:"started_at"`
	Command            string  `json:"command"`
}

// currentEnvironment describes the machine and the command. args starts with
// the subcommand name; the global -host-label option is restored in front of
// it, so the recorded command line reproduces the run.
func currentEnvironment(args []string) environment {
	command := []string{"agentgate-eval"}
	if hostLabelOption != "" {
		command = append(command, "-host-label", hostLabelOption)
	}
	return environment{
		GoVersion: runtime.Version(), GOOS: runtime.GOOS, GOARCH: runtime.GOARCH,
		NumCPU: runtime.NumCPU(), GOMAXPROCS: runtime.GOMAXPROCS(0),
		ClockGranularityMS: clockGranularityMS(),
		StartedAt:          time.Now().UTC().Format(time.RFC3339),
		Command:            strings.Join(append(command, displayArgs(args)...), " "),
	}
}

// clockGranularityMS is the median of several observed steps of time.Now.
func clockGranularityMS() float64 {
	var steps []float64
	for sample := 0; sample < 11; sample++ {
		start := time.Now()
		limit := start.Add(100 * time.Millisecond)
		for {
			now := time.Now()
			if step := now.Sub(start); step > 0 {
				steps = append(steps, float64(step)/float64(time.Millisecond))
				break
			}
			if now.After(limit) {
				break
			}
		}
	}
	return round(percentile(sortedCopy(steps), 0.5), 4)
}

// --- statistics --------------------------------------------------------------

// summary describes a sample. Quartiles and the median use linear
// interpolation between order statistics; P95 is reported only for samples of
// at least 20 values (nil otherwise), because a 95th percentile of fewer
// values is just the maximum.
type summary struct {
	Unit   string   `json:"unit"`
	N      int      `json:"n"`
	Min    float64  `json:"min"`
	P25    float64  `json:"p25"`
	Median float64  `json:"median"`
	Mean   float64  `json:"mean"`
	P75    float64  `json:"p75"`
	P95    *float64 `json:"p95"`
	Max    float64  `json:"max"`
	StdDev float64  `json:"stddev"`
}

func summarize(unit string, values []float64) summary {
	out := summary{Unit: unit, N: len(values)}
	if len(values) == 0 {
		return out
	}
	sorted := sortedCopy(values)
	sum := 0.0
	for _, value := range sorted {
		sum += value
	}
	mean := sum / float64(len(sorted))
	variance := 0.0
	for _, value := range sorted {
		variance += (value - mean) * (value - mean)
	}
	if len(sorted) > 1 {
		variance /= float64(len(sorted) - 1)
	}
	out.Min, out.Max = round(sorted[0], 4), round(sorted[len(sorted)-1], 4)
	out.P25, out.Median, out.P75 = round(percentile(sorted, 0.25), 4), round(percentile(sorted, 0.5), 4), round(percentile(sorted, 0.75), 4)
	out.Mean, out.StdDev = round(mean, 4), round(math.Sqrt(variance), 4)
	if len(sorted) >= 20 {
		p95 := round(percentile(sorted, 0.95), 4)
		out.P95 = &p95
	}
	return out
}

func sortedCopy(values []float64) []float64 {
	out := append([]float64(nil), values...)
	sort.Float64s(out)
	return out
}

// percentile interpolates linearly between the order statistics of sorted.
func percentile(sorted []float64, q float64) float64 {
	if len(sorted) == 0 {
		return 0
	}
	position := q * float64(len(sorted)-1)
	lower := int(math.Floor(position))
	upper := int(math.Ceil(position))
	if lower == upper {
		return sorted[lower]
	}
	return sorted[lower] + (sorted[upper]-sorted[lower])*(position-float64(lower))
}

func round(value float64, digits int) float64 {
	scale := math.Pow(10, float64(digits))
	return math.Round(value*scale) / scale
}

func ms(duration time.Duration) float64 { return float64(duration) / float64(time.Millisecond) }

// --- files -------------------------------------------------------------------

func writeJSON(path string, value any) error {
	var buffer bytes.Buffer
	encoder := json.NewEncoder(&buffer)
	encoder.SetEscapeHTML(false)
	encoder.SetIndent("", "  ")
	if err := encoder.Encode(value); err != nil {
		return fmt.Errorf("encode %s: %w", filepath.Base(path), err)
	}
	return os.WriteFile(path, buffer.Bytes(), 0o644)
}

func writeText(path, text string) error { return os.WriteFile(path, []byte(text), 0o644) }

// prepareDirs creates the output directory and the work directory (default:
// <temp>/agentgate-eval/<experiment>-<timestamp>).
func prepareDirs(outDir, workDir, experiment string) (string, string, error) {
	if outDir == "" {
		return "", "", errors.New("-out is required")
	}
	if workDir == "" {
		workDir = filepath.Join(os.TempDir(), "agentgate-eval", experiment+"-"+time.Now().Format("20060102-150405"))
	}
	for _, dir := range []string{outDir, workDir} {
		if err := os.MkdirAll(dir, 0o755); err != nil {
			return "", "", err
		}
	}
	if absolute, err := filepath.Abs(workDir); err == nil {
		workRoot = absolute
	}
	return outDir, workDir, nil
}

// workRoot is the absolute work directory of this invocation (set by
// prepareDirs), used to keep local absolute paths out of the results.
var workRoot string

// displayPath shows a path without the local directory layout: paths under
// the work directory as "<work>/...", paths under the current directory
// relative to it, anything else as "<path>/<base name>".
func displayPath(path string) string {
	absolute, err := filepath.Abs(path)
	if err != nil {
		return filepath.Base(path)
	}
	if workRoot != "" {
		if rel, err := filepath.Rel(workRoot, absolute); err == nil && !strings.HasPrefix(rel, "..") {
			return filepath.ToSlash(filepath.Join("<work>", rel))
		}
	}
	if cwd, err := os.Getwd(); err == nil {
		if rel, err := filepath.Rel(cwd, absolute); err == nil && !strings.HasPrefix(rel, "..") {
			return filepath.ToSlash(rel)
		}
	}
	return "<path>/" + filepath.Base(absolute)
}

// displayArgs is the command line with every path argument shown through
// displayPath (flag values that look like paths) and arguments containing
// spaces quoted.
func displayArgs(args []string) []string {
	out := make([]string, len(args))
	for i, arg := range args {
		out[i] = arg
		if i > 0 && (args[i-1] == "-out" || args[i-1] == "-work" || args[i-1] == "--out" || args[i-1] == "--work") {
			out[i] = displayPath(arg)
		}
		if strings.ContainsAny(out[i], " \t") {
			out[i] = `"` + out[i] + `"`
		}
	}
	return out
}

// interruptible returns a context cancelled by Ctrl+C.
func interruptible() (context.Context, context.CancelFunc) {
	return signal.NotifyContext(context.Background(), os.Interrupt)
}

// --- base runs ---------------------------------------------------------------

// baseRun is one fresh demo run created headlessly by the demo self-test and
// closed afterwards. Its evidence folder is never modified; attacks are
// applied to copies.
type baseRun struct {
	Index int    `json:"index"`
	RunID string `json:"run_id"`
	// Dir is the evidence folder for display (relative to the work
	// directory, see displayPath); dir is the real path.
	Dir    string `json:"dir"`
	dir    string
	Repeat int `json:"repeat"`
	// KeysSHA256 is the keys.json fingerprint the demo recorded at startup,
	// before any entry was written (the --expect-keys trust anchor).
	KeysSHA256 string `json:"keys_sha256"`
	// HeadHash is the final log head as the writing process held it in
	// memory after shutdown (the --expect-head trust anchor), checked here
	// against the last line on disk.
	HeadHash    string  `json:"head_hash"`
	HeadSeq     uint64  `json:"head_seq"`
	Entries     int     `json:"entries"`
	LogBytes    int64   `json:"log_bytes"`
	EvidenceKB  float64 `json:"evidence_kb"`
	SelfTest    string  `json:"selftest_summary"`
	SelfTestMS  float64 `json:"selftest_ms"`
	Operations  int     `json:"operations"`
	Effects     int     `json:"effects"`
	HasEarlier  bool    `json:"has_earlier_checkpoint"`
	EarlierSeq  uint64  `json:"earlier_checkpoint_seq,omitempty"`
	ConsoleFile string  `json:"console_file"`

	// earlier is a genuine earlier head.json and provider journal of the
	// same run (what the rollback attack restores).
	earlier auditverify.TamperOptions
	report  demo.SelfTestReport
}

// createBaseRun runs the demo self-test with repeat scenario suites in
// runsDir and returns the closed run. It fails unless every scenario, the
// verifier and every tamper-lab attack matched its expected outcome.
func createBaseRun(ctx context.Context, index int, runsDir string, repeat int) (baseRun, error) {
	if err := os.MkdirAll(runsDir, 0o755); err != nil {
		return baseRun{}, err
	}
	console := filepath.Join(runsDir, fmt.Sprintf("selftest-%02d-repeat%d.txt", index, repeat))
	logFile, err := os.Create(console)
	if err != nil {
		return baseRun{}, err
	}
	defer logFile.Close()
	began := time.Now()
	report, err := demo.RunSelfTest(ctx, demo.SelfTestOptions{
		RunsDir: runsDir, Repeat: repeat, Out: logFile, HostLabel: hostLabelOption,
		Logf: func(format string, args ...any) { fmt.Fprintf(logFile, "agentgate-demo: "+format+"\n", args...) },
	})
	elapsed := time.Since(began)
	if err != nil {
		return baseRun{}, fmt.Errorf("self-test: %w", err)
	}
	if !report.Passed {
		return baseRun{}, fmt.Errorf("self-test did not pass (%s); see %s", report.Summary, console)
	}
	run := baseRun{
		Index: index, RunID: report.RunID, Dir: displayPath(report.RunDir), dir: report.RunDir, Repeat: repeat,
		KeysSHA256: report.KeysSHA256, HeadHash: report.Verifier.AfterShutdownHeadHash,
		SelfTest: report.Summary, SelfTestMS: round(ms(elapsed), 1), ConsoleFile: displayPath(console), report: report,
	}
	entries, err := audit.ReadLog(run.dir)
	if err != nil {
		return baseRun{}, err
	}
	run.Entries = len(entries)
	if len(entries) == 0 || entries[len(entries)-1].EntryHash != run.HeadHash {
		return baseRun{}, fmt.Errorf("run %s: the head held by the writer (%s) is not the last line on disk", run.RunID, run.HeadHash)
	}
	run.HeadSeq = entries[len(entries)-1].Entry.Seq
	for _, entry := range entries {
		if entry.Entry.Stage == "EFFECT_EXECUTED" {
			run.Effects++
		}
	}
	if info, err := os.Stat(filepath.Join(run.dir, audit.LogFile)); err == nil {
		run.LogBytes = info.Size()
	}
	var total int64
	for _, name := range []string{audit.LogFile, audit.HeadFile, audit.KeysFile, audit.RunFile, audit.ProviderJournalFile} {
		if info, err := os.Stat(filepath.Join(run.dir, name)); err == nil {
			total += info.Size()
		}
	}
	run.EvidenceKB = round(float64(total)/1024, 1)
	run.Operations = report.Verifier.Operations
	run.earlier, run.EarlierSeq, run.HasEarlier = earlierCheckpoint(report)
	return run, nil
}

// earlierCheckpoint recovers the genuine earlier head.json and provider
// journal the self-test's rollback attack restored. The tamper lab writes
// them verbatim into its rollback copy (tamper-lab/<run>/rollback-<n>), so
// they are byte-identical to what was on disk at the end of an earlier
// scenario of this run.
func earlierCheckpoint(report demo.SelfTestReport) (auditverify.TamperOptions, uint64, bool) {
	pattern := filepath.Join(filepath.Dir(report.RunDir), "tamper-lab", report.RunID, string(auditverify.TamperRollback)+"-*")
	matches, _ := filepath.Glob(pattern)
	for _, dir := range matches {
		head, headErr := os.ReadFile(filepath.Join(dir, audit.HeadFile))
		journal, journalErr := os.ReadFile(filepath.Join(dir, audit.ProviderJournalFile))
		if headErr != nil || journalErr != nil {
			continue
		}
		var parsed audit.Head
		if json.Unmarshal(head, &parsed) != nil || parsed.Seq == 0 {
			continue
		}
		return auditverify.TamperOptions{EarlierHead: head, EarlierJournal: journal}, parsed.Seq, true
	}
	return auditverify.TamperOptions{}, 0, false
}

func mechanismNames(mechanisms []auditverify.Mechanism) []string {
	out := make([]string, len(mechanisms))
	for i, mechanism := range mechanisms {
		out[i] = string(mechanism)
	}
	return out
}

func failingCheckIDs(report auditverify.Report) []string {
	seen := map[string]bool{}
	var out []string
	for _, check := range report.Failures {
		if !seen[check.ID] {
			seen[check.ID] = true
			out = append(out, check.ID)
		}
	}
	return out
}
