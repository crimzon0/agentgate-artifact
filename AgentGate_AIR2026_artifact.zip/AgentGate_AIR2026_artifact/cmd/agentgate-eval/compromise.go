package main

import (
	"bytes"
	"encoding/csv"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"

	"agentgate/internal/auditverify"
	"agentgate/internal/demo"
	"agentgate/internal/evalattack"
)

// The R6.1 flag-binding ablation and key-compromise study
// (docs/demo/REVISION_CONTRACT.md R6.1, review comment 1).
//
// For each design (bound, unbound) the runner makes one base demo run per
// escalation mode with demo.HeadlessRun and keeps its genuine pins (keys
// fingerprint, final head). For every mutation operator, attacker key set and
// snapshot variant it writes a mutated copy with internal/evalattack (content
// edits and hash recomputation only; nothing is signed), then verifies the
// mutant under a key-compromise SIMULATION (auditverify.Options.
// AssumeCompromised for the key set's roles) across the anchor conditions
// none/keys/head/both and the verifier configurations below.
//
// Snapshot variants (evalattack.Variants): plain (the snapshot is left alone),
// forge-snapshot (the snapshot is rewritten so the forged decision replays,
// the recorded policy hash kept), forge-restate (the policy hash is also
// recomputed and restated in every decision value and capability). The
// strongest attacker of a cell is the one that evades: a cell counts as
// detected only when every applicable variant is detected.
//
// The unmutated base runs are verified too, for real and with every role
// assumed compromised, under every anchor condition and configuration (clean
// controls: any FAILED there is a false alarm).
//
// Results go to results.csv/json (one row per verification), strongest.csv
// (one row per cell and run), controls.csv and compromise.md, and are joined,
// without tuning, against the independent oracle (docs/paper/oracle/
// expected.json) under every reading it offers, for every configuration.

type compromiseOptions struct {
	outDir    string
	workDir   string
	runs      int
	oracle    string
	operators []evalattack.Operator
	keysets   []evalattack.KeySet
	variants  []evalattack.Variant
}

func parseCompromiseFlags(args []string, stderr io.Writer) (compromiseOptions, error) {
	set := flag.NewFlagSet("compromise", flag.ContinueOnError)
	set.SetOutput(stderr)
	out := set.String("out", "", "directory that receives results.csv/json (required)")
	work := set.String("work", "", "work directory for the base runs and mutants (default: a temp folder)")
	runs := set.Int("runs", 1, "how many times to repeat the whole matrix with fresh base runs (deterministic; for stability)")
	oracle := set.String("oracle", filepath.FromSlash("docs/paper/oracle/expected.json"), "the independent oracle to join results against")
	operators := set.String("operators", "all", "comma-separated mutation operators, or all")
	keysets := set.String("keysets", "all", "comma-separated attacker key sets, or all")
	variants := set.String("variants", "all", "comma-separated snapshot variants (plain, forge-snapshot, forge-restate), or all")
	if err := set.Parse(args); err != nil {
		return compromiseOptions{}, err
	}
	if set.NArg() > 0 {
		return compromiseOptions{}, fmt.Errorf("unexpected argument %q", set.Arg(0))
	}
	if *out == "" {
		return compromiseOptions{}, fmt.Errorf("-out is required")
	}
	if *runs < 1 {
		return compromiseOptions{}, fmt.Errorf("-runs must be at least 1")
	}
	options := compromiseOptions{outDir: *out, workDir: *work, runs: *runs, oracle: *oracle}
	var err error
	if options.operators, err = pickList(*operators, evalattack.Operators, "operator"); err != nil {
		return compromiseOptions{}, err
	}
	if options.keysets, err = pickList(*keysets, evalattack.KeySets, "key set"); err != nil {
		return compromiseOptions{}, err
	}
	if options.variants, err = pickList(*variants, evalattack.Variants, "variant"); err != nil {
		return compromiseOptions{}, err
	}
	return options, nil
}

// pickList parses "all" or a comma-separated subset of known, keeping the
// order of known.
func pickList[T ~string](text string, known []T, what string) ([]T, error) {
	if strings.TrimSpace(text) == "" || text == "all" {
		return append([]T(nil), known...), nil
	}
	wanted := map[T]bool{}
	for _, item := range strings.Split(text, ",") {
		name := T(strings.TrimSpace(item))
		found := false
		for _, k := range known {
			if k == name {
				found = true
			}
		}
		if !found {
			return nil, fmt.Errorf("unknown %s %q", what, name)
		}
		wanted[name] = true
	}
	var out []T
	for _, k := range known {
		if wanted[k] {
			out = append(out, k)
		}
	}
	return out, nil
}

// anchor condition names.
var compromiseAnchors = []string{"none", "keys", "head", "both"}

// verifier configuration: a name and the check IDs it disables.
type verifierConfig struct {
	name     string
	disabled []string
}

// verifierConfigs are the verifier configurations every mutant is verified
// under. no-replay stands for a classification that cannot be replayed (an
// external or non-deterministic classifier, human judgement);
// no-snapshot-bound-only keeps the replay but no longer ties the snapshot to
// the policy hash the issuer signed (the oracle's assumption A1: the snapshot
// is protected by the audit key only).
var verifierConfigs = []verifierConfig{
	{"full", nil},
	{"no-replay", []string{auditverify.CheckPolicyReplay}},
	{"no-replay-no-snapshot", []string{auditverify.CheckPolicyReplay, auditverify.CheckPolicySnapshotBound}},
	{"no-snapshot-bound-only", []string{auditverify.CheckPolicySnapshotBound}},
}

// compromiseRow is one verified cell.
type compromiseRow struct {
	Run            int      `json:"run"`
	Design         string   `json:"design"`
	Mode           string   `json:"mode"`
	Operator       string   `json:"operator"`
	KeySet         string   `json:"keyset"`
	Variant        string   `json:"variant"`
	Anchors        string   `json:"anchors,omitempty"`
	VerifierConfig string   `json:"verifier_config,omitempty"`
	Verdict        string   `json:"verdict,omitempty"`
	Assurance      string   `json:"assurance,omitempty"`
	Detected       bool     `json:"detected"`
	Simulated      bool     `json:"simulated"`
	FailingChecks  []string `json:"failing_checks,omitempty"`
	// Applied is false when the operator (or the variant) did not apply to
	// the base run; NotApplicable says why.
	Applied       bool   `json:"applied"`
	NotApplicable string `json:"not_applicable,omitempty"`
	// Unrepaired lists what the engine could not make consistent (from
	// evalattack.Mutant.Unrepaired).
	Unrepaired []string `json:"unrepaired,omitempty"`
}

// controlRow is one verification of an unmutated base run.
type controlRow struct {
	Run            int      `json:"run"`
	Design         string   `json:"design"`
	Mode           string   `json:"mode"`
	Simulation     string   `json:"simulation"` // "real" or "all-roles"
	Anchors        string   `json:"anchors"`
	VerifierConfig string   `json:"verifier_config"`
	Verdict        string   `json:"verdict"`
	Assurance      string   `json:"assurance"`
	FailingChecks  []string `json:"failing_checks,omitempty"`
}

// designPlan says which base run an operator runs against.
type designPlan struct {
	operator evalattack.Operator
	mode     string // "flag" or "human"
}

func operatorPlans(operators []evalattack.Operator) []designPlan {
	plans := []designPlan{}
	for _, op := range operators {
		mode := "flag"
		if op == evalattack.OpRelabelApproved {
			mode = "human"
		}
		plans = append(plans, designPlan{operator: op, mode: mode})
	}
	return plans
}

// baseKey identifies a base run by mode and design.
type baseKey struct {
	mode    string
	unbound bool
}

func (b baseKey) design() string {
	if b.unbound {
		return "unbound"
	}
	return "bound"
}

// anchorOptions sets the anchors of one condition on options.
func anchorOptions(options *auditverify.Options, anchors string, base demo.HeadlessResult) {
	switch anchors {
	case "keys":
		options.ExpectKeysSHA256 = base.KeysSHA256
	case "head":
		options.ExpectHead = base.FinalHead
	case "both":
		options.ExpectKeysSHA256 = base.KeysSHA256
		options.ExpectHead = base.FinalHead
	}
}

func runCompromise(args []string, stdout io.Writer) error {
	opts, err := parseCompromiseFlags(args, stdout)
	if err != nil {
		return err
	}
	outDir, workDir, err := prepareDirs(opts.outDir, opts.workDir, "compromise")
	if err != nil {
		return err
	}
	ctx, cancel := interruptible()
	defer cancel()

	oracle, oracleErr := loadOracle(opts.oracle)
	if oracleErr != nil {
		fmt.Fprintf(stdout, "warning: could not load the oracle %s: %v (results will have no oracle join)\n", displayPath(opts.oracle), oracleErr)
	}

	plans := operatorPlans(opts.operators)
	// Which (mode, unbound) base runs are needed.
	needed := map[baseKey]bool{}
	for _, plan := range plans {
		needed[baseKey{plan.mode, false}] = true
		needed[baseKey{plan.mode, true}] = true
	}
	baseOrder := make([]baseKey, 0, len(needed))
	for key := range needed {
		baseOrder = append(baseOrder, key)
	}
	sort.Slice(baseOrder, func(i, j int) bool {
		if baseOrder[i].mode != baseOrder[j].mode {
			return baseOrder[i].mode < baseOrder[j].mode
		}
		return !baseOrder[i].unbound && baseOrder[j].unbound
	})

	var rows []compromiseRow
	var controls []controlRow
	env := currentEnvironment(append([]string{"compromise"}, args...))
	for run := 1; run <= opts.runs; run++ {
		runsDir := filepath.Join(workDir, fmt.Sprintf("run-%02d", run))
		bases := map[baseKey]demo.HeadlessResult{}
		for _, key := range baseOrder {
			fmt.Fprintf(stdout, "run %d: base %s/%s ...\n", run, key.mode, key.design())
			res, err := demo.HeadlessRun(ctx, demo.HeadlessOptions{
				RunsDir:      filepath.Join(runsDir, key.mode+"-"+key.design()),
				Escalation:   key.mode,
				UnboundFlags: key.unbound,
				HostLabel:    hostLabelOption,
			})
			if err != nil {
				return fmt.Errorf("base run %s/%s: %w", key.mode, key.design(), err)
			}
			bases[key] = res
			// Clean controls: the unmutated base run, for real and with every
			// role assumed compromised.
			for _, simulation := range []string{"real", "all-roles"} {
				for _, anchors := range compromiseAnchors {
					for _, cfg := range verifierConfigs {
						options := auditverify.Options{DisableChecks: cfg.disabled, UnboundFlags: key.unbound}
						if simulation == "all-roles" {
							options.AssumeCompromised = auditverify.CompromiseRoles
						}
						anchorOptions(&options, anchors, res)
						report, err := auditverify.VerifyRun(res.RunDir, options)
						if err != nil {
							return fmt.Errorf("verify base %s/%s: %w", key.mode, key.design(), err)
						}
						controls = append(controls, controlRow{Run: run, Design: key.design(), Mode: key.mode, Simulation: simulation,
							Anchors: anchors, VerifierConfig: cfg.name, Verdict: report.Verdict, Assurance: report.Assurance,
							FailingChecks: failingCheckIDs(report)})
					}
				}
			}
		}
		for _, plan := range plans {
			for _, unbound := range []bool{false, true} {
				key := baseKey{plan.mode, unbound}
				base := bases[key]
				for _, ks := range opts.keysets {
					for _, variant := range opts.variants {
						mutDir := filepath.Join(runsDir, "mutants", fmt.Sprintf("%s-%s-%s-%s", key.design(), plan.operator, ks, variant))
						m, err := evalattack.MutateVariant(base.RunDir, mutDir, plan.operator, ks, variant)
						if err != nil {
							if evalattack.NotApplicable(err) {
								rows = append(rows, compromiseRow{Run: run, Design: key.design(), Mode: plan.mode,
									Operator: string(plan.operator), KeySet: string(ks), Variant: string(variant), Applied: false,
									NotApplicable: err.Error()})
								continue
							}
							return fmt.Errorf("mutate %s/%s/%s/%s: %w", key.design(), plan.operator, ks, variant, err)
						}
						for _, anchors := range compromiseAnchors {
							for _, cfg := range verifierConfigs {
								// UnboundFlags is the design under test (an experimental condition, oracle A8):
								// without it the default verifier refuses every unbound-design run, genuine or not
								// (op.requires_policy: the ablated value shape), and the ablation measures nothing.
								options := auditverify.Options{AssumeCompromised: m.AssumeCompromised, DisableChecks: cfg.disabled, UnboundFlags: key.unbound}
								anchorOptions(&options, anchors, base)
								report, err := auditverify.VerifyRun(mutDir, options)
								if err != nil {
									return fmt.Errorf("verify %s/%s/%s/%s/%s/%s: %w", key.design(), plan.operator, ks, variant, anchors, cfg.name, err)
								}
								rows = append(rows, compromiseRow{
									Run: run, Design: key.design(), Mode: plan.mode, Operator: string(plan.operator),
									KeySet: string(ks), Variant: string(variant), Anchors: anchors, VerifierConfig: cfg.name,
									Verdict: report.Verdict, Assurance: report.Assurance,
									Detected: report.Verdict == auditverify.VerdictFailed, Simulated: report.Simulation != nil,
									FailingChecks: failingCheckIDs(report), Applied: true, Unrepaired: m.Unrepaired,
								})
							}
						}
						// Mutants are large and fully described by the rows; they are not kept.
						_ = os.RemoveAll(mutDir)
					}
				}
			}
		}
	}

	strongest := strongestCells(rows)
	join := joinOracle(strongest, rows, oracle)
	flips := bindingFlips(strongest)
	falseAlarms := 0
	for _, c := range controls {
		if c.Verdict == auditverify.VerdictFailed {
			falseAlarms++
		}
	}
	result := map[string]any{
		"format":      "agentgate-compromise/v2",
		"environment": env,
		"note": "Key-compromise SIMULATION: for each attacker key set the verifier accepted that set's roles' signatures without verification (auditverify.AssumeCompromised). " +
			"The mutation engine edited content and recomputed hashes only; nothing was signed. These are simulation results, not a real verification of signed evidence. " +
			"A cell's strongest attacker is the snapshot variant that evades: the cell is detected only when every applicable variant is detected.",
		"runs":             opts.runs,
		"anchors":          compromiseAnchors,
		"verifier_configs": verifierConfigNames(),
		"keysets":          keySetNames(opts.keysets),
		"operators":        operatorNames(opts.operators),
		"variants":         variantNames(opts.variants),
		"oracle":           join.summary,
		"oracle_plain":     join.plainSummary,
		"binding_flips":    flips,
		"controls":         map[string]any{"verifications": len(controls), "false_alarms": falseAlarms},
	}
	if err := writeResultsJSON(filepath.Join(outDir, "results.json"), result, rows); err != nil {
		return err
	}
	if err := writeResultsCSV(filepath.Join(outDir, "results.csv"), rows); err != nil {
		return err
	}
	if err := writeStrongestCSV(filepath.Join(outDir, "strongest.csv"), strongest); err != nil {
		return err
	}
	if err := writeControlsCSV(filepath.Join(outDir, "controls.csv"), controls); err != nil {
		return err
	}
	if err := writeText(filepath.Join(outDir, "compromise.md"), compromiseMarkdown(rows, strongest, controls, join, flips)); err != nil {
		return err
	}
	printCompromiseSummary(stdout, rows, strongest, controls, join, flips, outDir)
	return nil
}

func verifierConfigNames() []string {
	out := make([]string, len(verifierConfigs))
	for i, c := range verifierConfigs {
		out[i] = c.name
	}
	return out
}

func keySetNames(keysets []evalattack.KeySet) []string {
	out := make([]string, len(keysets))
	for i, k := range keysets {
		out[i] = string(k)
	}
	return out
}

func operatorNames(operators []evalattack.Operator) []string {
	out := make([]string, len(operators))
	for i, o := range operators {
		out[i] = string(o)
	}
	return out
}

func variantNames(variants []evalattack.Variant) []string {
	out := make([]string, len(variants))
	for i, v := range variants {
		out[i] = string(v)
	}
	return out
}

// --- strongest attacker per cell ---------------------------------------------

// cellKey identifies one cell of one run (all variants together).
type cellKey struct {
	Run            int
	Design         string
	Mode           string
	Operator       string
	KeySet         string
	Anchors        string
	VerifierConfig string
}

// strongestCell is the outcome of a cell for the strongest attacker.
type strongestCell struct {
	cellKey
	// Applied variants and the ones the verifier accepted.
	Variants []string
	Evading  []string
	// Detected is true when every applied variant was detected.
	Detected bool
	// PlainDetected is the plain variant's outcome (the attacker who leaves
	// the snapshot alone); PlainApplied says whether it ran.
	PlainDetected bool
	PlainApplied  bool
}

// strongestCells folds the variants of every cell.
func strongestCells(rows []compromiseRow) []strongestCell {
	index := map[cellKey]*strongestCell{}
	var order []cellKey
	for _, r := range rows {
		if !r.Applied {
			continue
		}
		key := cellKey{r.Run, r.Design, r.Mode, r.Operator, r.KeySet, r.Anchors, r.VerifierConfig}
		cell := index[key]
		if cell == nil {
			cell = &strongestCell{cellKey: key, Detected: true}
			index[key] = cell
			order = append(order, key)
		}
		cell.Variants = append(cell.Variants, r.Variant)
		if !r.Detected {
			cell.Detected = false
			cell.Evading = append(cell.Evading, r.Variant)
		}
		if r.Variant == string(evalattack.VariantPlain) {
			cell.PlainApplied, cell.PlainDetected = true, r.Detected
		}
	}
	out := make([]strongestCell, 0, len(order))
	for _, key := range order {
		out = append(out, *index[key])
	}
	return out
}

// flip is one cell (operator, key set, anchors) whose outcome differs
// between the designs for the strongest attacker.
type flip struct {
	Config   string `json:"verifier_config"`
	Operator string `json:"operator"`
	KeySet   string `json:"keyset"`
	Anchors  string `json:"anchors"`
	// Runs counts the runs in which the cell flipped; Reverse is true for
	// bound accepted, unbound detected.
	Runs    int  `json:"runs"`
	Reverse bool `json:"reverse,omitempty"`
}

// bindingFlips lists, per configuration, the cells detected in the bound
// design and accepted in the unbound one (and reverse flips).
func bindingFlips(cells []strongestCell) []flip {
	type pair struct{ bound, unbound *strongestCell }
	type key struct {
		run                               int
		config, operator, keyset, anchors string
	}
	pairs := map[key]*pair{}
	for i := range cells {
		c := &cells[i]
		k := key{c.Run, c.VerifierConfig, c.Operator, c.KeySet, c.Anchors}
		p := pairs[k]
		if p == nil {
			p = &pair{}
			pairs[k] = p
		}
		if c.Design == "bound" {
			p.bound = c
		} else {
			p.unbound = c
		}
	}
	counts := map[flip]int{}
	for k, p := range pairs {
		if p.bound == nil || p.unbound == nil || p.bound.Detected == p.unbound.Detected {
			continue
		}
		f := flip{Config: k.config, Operator: k.operator, KeySet: k.keyset, Anchors: k.anchors, Reverse: !p.bound.Detected}
		counts[f]++
	}
	out := make([]flip, 0, len(counts))
	for f, n := range counts {
		f.Runs = n
		out = append(out, f)
	}
	sort.Slice(out, func(i, j int) bool {
		a, b := out[i], out[j]
		if a.Config != b.Config {
			return configRank(a.Config) < configRank(b.Config)
		}
		if a.Operator != b.Operator {
			return a.Operator < b.Operator
		}
		if a.KeySet != b.KeySet {
			return a.KeySet < b.KeySet
		}
		return a.Anchors < b.Anchors
	})
	return out
}

func configRank(name string) int {
	for i, c := range verifierConfigs {
		if c.name == name {
			return i
		}
	}
	return len(verifierConfigs)
}

// --- output ------------------------------------------------------------------

// writeResultsJSON writes the summary members indented and the rows one per
// line (valid JSON, about half the size of an indented file).
func writeResultsJSON(path string, header map[string]any, rows []compromiseRow) error {
	head, err := json.MarshalIndent(header, "", "  ")
	if err != nil {
		return err
	}
	var b bytes.Buffer
	b.Write(bytes.TrimSuffix(head, []byte("\n}")))
	b.WriteString(",\n  \"rows\": [\n")
	for i, r := range rows {
		line, err := json.Marshal(r)
		if err != nil {
			return err
		}
		b.WriteString("    ")
		b.Write(line)
		if i < len(rows)-1 {
			b.WriteString(",")
		}
		b.WriteString("\n")
	}
	b.WriteString("  ]\n}\n")
	return os.WriteFile(path, b.Bytes(), 0o644)
}

func writeResultsCSV(path string, rows []compromiseRow) error {
	return writeCSV(path, []string{"run", "design", "mode", "operator", "keyset", "variant", "anchors", "verifier_config", "applied", "verdict", "assurance", "detected", "failing_checks", "unrepaired", "not_applicable"},
		len(rows), func(i int) []string {
			r := rows[i]
			return []string{
				strconv.Itoa(r.Run), r.Design, r.Mode, r.Operator, r.KeySet, r.Variant, r.Anchors, r.VerifierConfig,
				strconv.FormatBool(r.Applied), r.Verdict, r.Assurance, strconv.FormatBool(r.Detected),
				strings.Join(r.FailingChecks, " "), strconv.Itoa(len(r.Unrepaired)), r.NotApplicable,
			}
		})
}

func writeStrongestCSV(path string, cells []strongestCell) error {
	return writeCSV(path, []string{"run", "design", "mode", "operator", "keyset", "anchors", "verifier_config", "variants", "detected", "evading_variants", "plain_detected"},
		len(cells), func(i int) []string {
			c := cells[i]
			plain := ""
			if c.PlainApplied {
				plain = strconv.FormatBool(c.PlainDetected)
			}
			return []string{strconv.Itoa(c.Run), c.Design, c.Mode, c.Operator, c.KeySet, c.Anchors, c.VerifierConfig,
				strings.Join(c.Variants, " "), strconv.FormatBool(c.Detected), strings.Join(c.Evading, " "), plain}
		})
}

func writeControlsCSV(path string, controls []controlRow) error {
	return writeCSV(path, []string{"run", "design", "mode", "simulation", "anchors", "verifier_config", "verdict", "assurance", "failing_checks"},
		len(controls), func(i int) []string {
			c := controls[i]
			return []string{strconv.Itoa(c.Run), c.Design, c.Mode, c.Simulation, c.Anchors, c.VerifierConfig, c.Verdict, c.Assurance, strings.Join(c.FailingChecks, " ")}
		})
}

func writeCSV(path string, header []string, n int, row func(int) []string) error {
	file, err := os.Create(path)
	if err != nil {
		return err
	}
	defer file.Close()
	w := csv.NewWriter(file)
	if err := w.Write(header); err != nil {
		return err
	}
	for i := 0; i < n; i++ {
		if err := w.Write(row(i)); err != nil {
			return err
		}
	}
	w.Flush()
	return w.Error()
}

func printCompromiseSummary(stdout io.Writer, rows []compromiseRow, cells []strongestCell, controls []controlRow, join oracleJoin, flips []flip, outDir string) {
	applied, accepted, notApplicable := 0, 0, 0
	for _, r := range rows {
		if !r.Applied {
			notApplicable++
			continue
		}
		applied++
		if !r.Detected {
			accepted++
		}
	}
	falseAlarms := 0
	for _, c := range controls {
		if c.Verdict == auditverify.VerdictFailed {
			falseAlarms++
		}
	}
	fmt.Fprintf(stdout, "\nKey-compromise SIMULATION (not a real verification):\n")
	fmt.Fprintf(stdout, "  %d mutant verifications (%d accepted), %d not-applicable operator/variant rows.\n", applied, accepted, notApplicable)
	fmt.Fprintf(stdout, "  clean controls: %d verifications, %d false alarms.\n", len(controls), falseAlarms)
	for _, cfg := range verifierConfigs {
		total, undetected, flipsN, reverse := 0, 0, 0, 0
		for _, c := range cells {
			if c.VerifierConfig != cfg.name {
				continue
			}
			total++
			if !c.Detected {
				undetected++
			}
		}
		for _, f := range flips {
			if f.Config == cfg.name {
				if f.Reverse {
					reverse++
				} else {
					flipsN++
				}
			}
		}
		fmt.Fprintf(stdout, "  %-23s strongest attacker: %d/%d cells accepted; binding flips %d (reverse %d)\n", cfg.name, undetected, total, flipsN, reverse)
	}
	for _, mapping := range oracleMappings {
		s := join.summary[mapping.config][mapping.reading]
		if s.Total == 0 {
			continue
		}
		fmt.Fprintf(stdout, "  oracle %-38s vs %-23s: %d/%d agree\n", mapping.reading, mapping.config, s.Agree, s.Total)
	}
	fmt.Fprintf(stdout, "  results: %s\n", displayPath(filepath.Join(outDir, "results.json")))
}
