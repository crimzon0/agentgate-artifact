package main

import (
	"encoding/json"
	"fmt"
	"os"
	"sort"
	"strings"

	"agentgate/internal/auditverify"
)

// The oracle readings the runner joins against (docs/paper/oracle/README.md):
// "primary" and the four single-assumption alternatives, plus two readings
// computed here that combine two assumptions (detected when either reading
// says detected; each assumption only adds detection). The verifier checks
// the escalation mode (A3 closed), so the readings with mode_checked are the
// ones that describe it.
var oracleReadings = []string{
	"primary", "no_snapshot_forgery", "snapshot_bound", "mode_checked", "receipt_decision_unchecked",
	"snapshot_bound+mode_checked", "no_snapshot_forgery+mode_checked",
}

// oracleMappings pair a verifier configuration and attacker with the reading
// that describes it (README "Which column to compare against"):
//
//   - full verifier, strongest attacker: the snapshot is bound to the policy
//     hash (snapshot_bound) and the mode is checked;
//   - full verifier, plain attacker: no snapshot forgery, mode checked;
//   - no-snapshot-bound-only, strongest attacker: the snapshot is protected
//     by the audit key only (primary) and the mode is checked.
//
// The no-replay configurations have no oracle reading (the oracle predicts a
// verifier with replay); their agreement with each reading is reported but
// is this runner's mapping, not an oracle claim.
var oracleMappings = []struct{ config, reading string }{
	{"full", "snapshot_bound+mode_checked"},
	{"no-snapshot-bound-only", "mode_checked"},
}

// oracleCell is one cell of docs/paper/oracle/expected.json.
type oracleCell struct {
	Operator     string            `json:"operator"`
	KeySet       string            `json:"keyset"`
	Anchors      string            `json:"anchors"`
	Design       string            `json:"design"`
	Expected     string            `json:"expected"` // detected | undetected
	Alternatives map[string]string `json:"alternatives"`
}

// oracle is the parsed expected.json indexed by join key.
type oracle struct {
	cells map[string]oracleCell
}

func oracleKey(operator, keyset, anchors, design string) string {
	return operator + "|" + keyset + "|" + anchors + "|" + design
}

func loadOracle(path string) (*oracle, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var doc struct {
		Cells []oracleCell `json:"cells"`
	}
	if err := json.Unmarshal(data, &doc); err != nil {
		return nil, err
	}
	if len(doc.Cells) == 0 {
		return nil, fmt.Errorf("the oracle has no cells")
	}
	o := &oracle{cells: map[string]oracleCell{}}
	for _, c := range doc.Cells {
		o.cells[oracleKey(c.Operator, c.KeySet, c.Anchors, c.Design)] = c
	}
	return o, nil
}

// oracleKeySet maps an engine key set name to the oracle's. They match except
// the replacement key set, which is the oracle's "all"; all-stolen and
// audit+issuer+adapter+approval have no oracle cell (extra cases the oracle
// does not predict).
func oracleKeySet(keyset string) (string, bool) {
	switch keyset {
	case "all-replaced":
		return "all", true
	case "all-stolen", "audit+issuer+adapter+approval":
		return "", false
	default:
		return keyset, true
	}
}

// readingValue returns the oracle's detected/undetected label for a cell under
// a reading ("a+b": detected when either says detected).
func readingValue(cell oracleCell, reading string) (string, bool) {
	if first, second, combined := strings.Cut(reading, "+"); combined {
		a, okA := readingValue(cell, first)
		b, okB := readingValue(cell, second)
		if !okA || !okB {
			return "", false
		}
		if a == "detected" || b == "detected" {
			return "detected", true
		}
		return "undetected", true
	}
	if reading == "primary" {
		return cell.Expected, cell.Expected != ""
	}
	v, ok := cell.Alternatives[reading]
	return v, ok
}

// readingStat counts agreements for one reading.
type readingStat struct {
	Agree    int `json:"agree"`
	Disagree int `json:"disagree"`
	Total    int `json:"total"`
}

// disagreement is one cell (all runs together) whose outcome differs from a
// reading.
type disagreement struct {
	Config, Reading                   string
	Operator, KeySet, Anchors, Design string
	Verifier, Oracle                  string
	Runs                              int
}

type oracleJoin struct {
	// summary[config][reading] for the strongest attacker; plainSummary for
	// the plain variant alone.
	summary      map[string]map[string]readingStat
	plainSummary map[string]map[string]readingStat
	disagree     []disagreement // strongest attacker, the mapped readings only
	unmatched    int            // strongest cells (full config) with no oracle cell
}

// joinOracle compares the strongest attacker's outcome of every cell, and the
// plain variant's, with every oracle reading, for every configuration.
func joinOracle(cells []strongestCell, rows []compromiseRow, o *oracle) oracleJoin {
	join := oracleJoin{summary: map[string]map[string]readingStat{}, plainSummary: map[string]map[string]readingStat{}}
	for _, cfg := range verifierConfigs {
		join.summary[cfg.name] = map[string]readingStat{}
		join.plainSummary[cfg.name] = map[string]readingStat{}
	}
	if o == nil {
		return join
	}
	mapped := map[string]string{}
	for _, m := range oracleMappings {
		mapped[m.config] = m.reading
	}
	disagreements := map[disagreement]int{}
	count := func(into map[string]map[string]readingStat, config, reading string, agree bool) {
		stat := into[config][reading]
		stat.Total++
		if agree {
			stat.Agree++
		} else {
			stat.Disagree++
		}
		into[config][reading] = stat
	}
	for _, c := range cells {
		oks, ok := oracleKeySet(c.KeySet)
		if !ok {
			continue
		}
		cell, found := o.cells[oracleKey(c.Operator, oks, c.Anchors, c.Design)]
		if !found {
			if c.VerifierConfig == "full" {
				join.unmatched++
			}
			continue
		}
		for _, reading := range oracleReadings {
			label, has := readingValue(cell, reading)
			if !has {
				continue
			}
			oracleDetected := label == "detected"
			count(join.summary, c.VerifierConfig, reading, c.Detected == oracleDetected)
			if c.PlainApplied {
				count(join.plainSummary, c.VerifierConfig, reading, c.PlainDetected == oracleDetected)
			}
			if c.Detected != oracleDetected && mapped[c.VerifierConfig] == reading {
				disagreements[disagreement{Config: c.VerifierConfig, Reading: reading, Operator: c.Operator, KeySet: c.KeySet,
					Anchors: c.Anchors, Design: c.Design, Verifier: detectedWord(c.Detected), Oracle: label}]++
			}
		}
	}
	for d, n := range disagreements {
		d.Runs = n
		join.disagree = append(join.disagree, d)
	}
	sort.Slice(join.disagree, func(i, j int) bool {
		a, b := join.disagree[i], join.disagree[j]
		return fmt.Sprint(configRank(a.Config), a.Operator, a.KeySet, a.Anchors, a.Design) < fmt.Sprint(configRank(b.Config), b.Operator, b.KeySet, b.Anchors, b.Design)
	})
	return join
}

func detectedWord(detected bool) string {
	if detected {
		return "detected"
	}
	return "undetected"
}

// compromiseMarkdown is a short human summary, de-duplicated per cell.
func compromiseMarkdown(rows []compromiseRow, cells []strongestCell, controls []controlRow, join oracleJoin, flips []flip) string {
	var b strings.Builder
	b.WriteString("# Key-compromise simulation results (R6.1)\n\n")
	b.WriteString("**Simulation, not a real verification.** For each attacker key set the verifier accepted that\n")
	b.WriteString("set's roles' signatures without verification (`auditverify.AssumeCompromised`). The mutation\n")
	b.WriteString("engine edited content and recomputed hashes only; nothing was signed. A cell's strongest\n")
	b.WriteString("attacker is the snapshot variant that evades (plain, forge-snapshot, forge-restate): the cell is\n")
	b.WriteString("detected only when every applicable variant is detected.\n\n")

	falseAlarms := 0
	for _, c := range controls {
		if c.Verdict == auditverify.VerdictFailed {
			falseAlarms++
		}
	}
	fmt.Fprintf(&b, "Clean controls (unmutated base runs, real and all roles simulated, every anchor condition and configuration): %d verifications, **%d false alarms**.\n\n", len(controls), falseAlarms)

	// Not-applicable operator/variant combinations, once each.
	na := map[string]bool{}
	for _, r := range rows {
		if !r.Applied {
			na[fmt.Sprintf("%s / %s: %s", r.Operator, r.Variant, r.NotApplicable)] = true
		}
	}
	if len(na) > 0 {
		b.WriteString("## Not applicable\n\n")
		for _, line := range sortedSet(na) {
			fmt.Fprintf(&b, "- %s\n", line)
		}
		b.WriteString("\n")
	}
	unrepaired := map[string]bool{}
	for _, r := range rows {
		for _, u := range r.Unrepaired {
			unrepaired[fmt.Sprintf("%s/%s (%s): %s", r.Design, r.Operator, r.Variant, stripOperationIDs(u))] = true
		}
	}
	if len(unrepaired) > 0 {
		b.WriteString("## Consequences the engine could not repair\n\n")
		b.WriteString("(Operation IDs differ per run and are omitted.)\n\n")
		for _, line := range sortedSet(unrepaired) {
			fmt.Fprintf(&b, "- %s\n", line)
		}
		b.WriteString("\n")
	}

	b.WriteString("## Accepted cells per configuration (strongest attacker; all runs)\n\n")
	b.WriteString("| configuration | cells | accepted | binding flips | reverse flips |\n|---|---|---|---|---|\n")
	for _, cfg := range verifierConfigs {
		total, accepted, flipped, reverse := 0, 0, 0, 0
		for _, c := range cells {
			if c.VerifierConfig == cfg.name {
				total++
				if !c.Detected {
					accepted++
				}
			}
		}
		for _, f := range flips {
			if f.Config == cfg.name {
				if f.Reverse {
					reverse += f.Runs
				} else {
					flipped += f.Runs
				}
			}
		}
		fmt.Fprintf(&b, "| %s | %d | %d | %d | %d |\n", cfg.name, total, accepted, flipped, reverse)
	}
	b.WriteString("\nFlip counts are cell x run. A binding flip is a cell detected in the bound design and accepted in the unbound one.\n\n")

	b.WriteString("## Accepted (operator, key set, anchors) per configuration and design\n\n")
	type acceptKey struct{ config, design, operator, anchors string }
	accepted := map[acceptKey]map[string]bool{}
	for _, c := range cells {
		if c.Detected {
			continue
		}
		k := acceptKey{c.VerifierConfig, c.Design, c.Operator, c.Anchors}
		if accepted[k] == nil {
			accepted[k] = map[string]bool{}
		}
		accepted[k][c.KeySet+" ["+strings.Join(c.Evading, ",")+"]"] = true
	}
	keys := make([]acceptKey, 0, len(accepted))
	for k := range accepted {
		keys = append(keys, k)
	}
	sort.Slice(keys, func(i, j int) bool {
		a, c := keys[i], keys[j]
		return fmt.Sprint(configRank(a.config), a.design, a.operator, a.anchors) < fmt.Sprint(configRank(c.config), c.design, c.operator, c.anchors)
	})
	if len(keys) == 0 {
		b.WriteString("None.\n\n")
	} else {
		b.WriteString("| configuration | design | operator | anchors | accepted key sets [evading variants] |\n|---|---|---|---|---|\n")
		for _, k := range keys {
			fmt.Fprintf(&b, "| %s | %s | %s | %s | %s |\n", k.config, k.design, k.operator, k.anchors, strings.Join(sortedSet(accepted[k]), "; "))
		}
		b.WriteString("\n")
	}

	if len(flips) > 0 {
		b.WriteString("## Binding flips (strongest attacker)\n\n| configuration | operator | key set | anchors | runs | reverse |\n|---|---|---|---|---|---|\n")
		for _, f := range flips {
			fmt.Fprintf(&b, "| %s | %s | %s | %s | %d | %t |\n", f.Config, f.Operator, f.KeySet, f.Anchors, f.Runs, f.Reverse)
		}
		b.WriteString("\n")
	}

	b.WriteString("## Oracle agreement (cells x runs; strongest attacker / plain variant)\n\n")
	b.WriteString("| configuration | reading | strongest agree/total | plain agree/total |\n|---|---|---|---|\n")
	for _, cfg := range verifierConfigs {
		for _, reading := range oracleReadings {
			s, p := join.summary[cfg.name][reading], join.plainSummary[cfg.name][reading]
			if s.Total == 0 && p.Total == 0 {
				continue
			}
			fmt.Fprintf(&b, "| %s | %s | %d/%d | %d/%d |\n", cfg.name, reading, s.Agree, s.Total, p.Agree, p.Total)
		}
	}
	b.WriteString("\nThe readings that describe a configuration: full verifier + strongest attacker = `snapshot_bound+mode_checked`;\n")
	b.WriteString("full verifier + plain attacker = `no_snapshot_forgery+mode_checked`; no-snapshot-bound-only + strongest\n")
	b.WriteString("attacker = `mode_checked` (the primary reading with the escalation mode checked). The no-replay\n")
	b.WriteString("configurations have no oracle reading. Readings joined with `+` are computed here (detected when\n")
	b.WriteString("either single-assumption reading says detected), not by the oracle.\n")
	if join.unmatched > 0 {
		fmt.Fprintf(&b, "\n%d full-configuration cells had no oracle prediction (key sets all-stolen and audit+issuer+adapter+approval are not in the oracle).\n", join.unmatched)
	}
	if len(join.disagree) > 0 {
		b.WriteString("\n## Disagreements with the mapped reading (strongest attacker; one line per cell)\n\n")
		b.WriteString("| configuration | reading | operator | key set | anchors | design | verifier | oracle | runs |\n|---|---|---|---|---|---|---|---|---|\n")
		for _, d := range join.disagree {
			fmt.Fprintf(&b, "| %s | %s | %s | %s | %s | %s | %s | %s | %d |\n", d.Config, d.Reading, d.Operator, d.KeySet, d.Anchors, d.Design, d.Verifier, d.Oracle, d.Runs)
		}
	}
	return b.String()
}

func sortedSet(set map[string]bool) []string {
	out := make([]string, 0, len(set))
	for k := range set {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}

// stripOperationIDs removes "operation XXXXXXXX:" prefixes that differ per run.
func stripOperationIDs(text string) string {
	for {
		i := strings.Index(text, "operation ")
		if i < 0 {
			return text
		}
		rest := text[i+len("operation "):]
		j := strings.Index(rest, ":")
		if j < 0 || j > 16 {
			return text
		}
		text = text[:i] + "an operation" + rest[j:]
	}
}
