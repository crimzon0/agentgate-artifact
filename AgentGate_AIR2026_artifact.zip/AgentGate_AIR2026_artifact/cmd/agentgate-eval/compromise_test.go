package main

import (
	"bytes"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"agentgate/internal/evalattack"
)

func TestParseCompromiseFlags(t *testing.T) {
	opts, err := parseCompromiseFlags([]string{"-out", "x"}, &bytes.Buffer{})
	if err != nil {
		t.Fatal(err)
	}
	if len(opts.operators) != len(evalattack.Operators) || len(opts.keysets) != len(evalattack.KeySets) || len(opts.variants) != len(evalattack.Variants) || opts.runs != 1 {
		t.Fatalf("defaults: %+v", opts)
	}
	opts, err = parseCompromiseFlags([]string{"-out", "x", "-operators", "change-amount, strip-flag", "-keysets", "audit", "-variants", "plain,forge-restate"}, &bytes.Buffer{})
	if err != nil {
		t.Fatal(err)
	}
	// The known order is kept, whatever order the flag names them in.
	if len(opts.operators) != 2 || opts.operators[0] != evalattack.OpStripFlag || opts.operators[1] != evalattack.OpChangeAmount {
		t.Fatalf("operators %v", opts.operators)
	}
	if len(opts.keysets) != 1 || len(opts.variants) != 2 {
		t.Fatalf("keysets %v variants %v", opts.keysets, opts.variants)
	}
	for _, bad := range [][]string{
		{"-out", "x", "-operators", "strip"},
		{"-out", "x", "-keysets", "everything"},
		{"-out", "x", "-variants", "forge"},
		{"-runs", "1"},
		{"-out", "x", "-runs", "0"},
	} {
		if _, err := parseCompromiseFlags(bad, &bytes.Buffer{}); err == nil {
			t.Errorf("%v: expected an error", bad)
		}
	}
	if len(verifierConfigs) != 4 || verifierConfigs[3].name != "no-snapshot-bound-only" || len(verifierConfigs[3].disabled) != 1 || verifierConfigs[3].disabled[0] != "policy.snapshot_bound" {
		t.Fatalf("verifier configurations %+v", verifierConfigs)
	}
}

// A cell is detected only when every applied variant is; a binding flip is a
// cell detected bound and accepted unbound.
func TestStrongestCellsAndFlips(t *testing.T) {
	row := func(design, variant string, detected bool) compromiseRow {
		return compromiseRow{Run: 1, Design: design, Mode: "flag", Operator: "strip-flag", KeySet: "audit", Variant: variant,
			Anchors: "none", VerifierConfig: "no-snapshot-bound-only", Detected: detected, Applied: true}
	}
	rows := []compromiseRow{
		row("bound", "plain", true), row("bound", "forge-snapshot", true), row("bound", "forge-restate", true),
		row("unbound", "plain", true), row("unbound", "forge-snapshot", false), row("unbound", "forge-restate", true),
		{Run: 1, Design: "unbound", Operator: "change-rules", Variant: "forge-snapshot", Applied: false, NotApplicable: "no lever"},
	}
	cells := strongestCells(rows)
	if len(cells) != 2 {
		t.Fatalf("cells %+v", cells)
	}
	for _, c := range cells {
		switch c.Design {
		case "bound":
			if !c.Detected || !c.PlainDetected || len(c.Evading) != 0 {
				t.Fatalf("bound %+v", c)
			}
		case "unbound":
			if c.Detected || !c.PlainDetected || strings.Join(c.Evading, ",") != "forge-snapshot" {
				t.Fatalf("unbound %+v", c)
			}
		}
	}
	flips := bindingFlips(cells)
	if len(flips) != 1 || flips[0].Reverse || flips[0].Runs != 1 || flips[0].Operator != "strip-flag" {
		t.Fatalf("flips %+v", flips)
	}
}

func TestOracleReadingCombinations(t *testing.T) {
	cell := oracleCell{Expected: "undetected", Alternatives: map[string]string{"snapshot_bound": "undetected", "mode_checked": "detected"}}
	for reading, want := range map[string]string{
		"primary": "undetected", "snapshot_bound": "undetected", "mode_checked": "detected",
		"snapshot_bound+mode_checked": "detected",
	} {
		if got, ok := readingValue(cell, reading); !ok || got != want {
			t.Errorf("%s: %q %t, want %q", reading, got, ok, want)
		}
	}
	if _, ok := readingValue(cell, "no_snapshot_forgery+mode_checked"); ok {
		t.Error("a combination with a missing reading must be absent")
	}
	for keyset, want := range map[string]string{"all-replaced": "all", "audit": "audit"} {
		if got, ok := oracleKeySet(keyset); !ok || got != want {
			t.Errorf("%s -> %q", keyset, got)
		}
	}
	for _, keyset := range []string{"all-stolen", "audit+issuer+adapter+approval"} {
		if _, ok := oracleKeySet(keyset); ok {
			t.Errorf("%s has no oracle cell", keyset)
		}
	}
}

// A reduced compromise run on real gateway evidence: the snapshot-forging
// attacker defeats the full verifier with audit+issuer+adapter (strip-flag,
// both designs), change-amount needs the provider key too, the
// no-replay configuration shows the binding flip for the audit key, and the
// clean controls raise no false alarm.
func TestCompromiseSmoke(t *testing.T) {
	if testing.Short() {
		t.Skip("runs the real gateway")
	}
	out, work := t.TempDir(), t.TempDir()
	var stdout bytes.Buffer
	err := runCompromise([]string{"-out", out, "-work", work, "-runs", "1",
		"-operators", "strip-flag,change-amount", "-keysets", "audit,audit+issuer+adapter,audit+issuer+adapter+provider",
		"-oracle", filepath.Join("..", "..", "docs", "paper", "oracle", "expected.json")}, &stdout)
	if err != nil {
		t.Fatalf("%v\n%s", err, stdout.String())
	}
	for _, name := range []string{"results.json", "results.csv", "strongest.csv", "controls.csv", "compromise.md"} {
		if _, err := os.Stat(filepath.Join(out, name)); err != nil {
			t.Fatalf("%s: %v", name, err)
		}
	}
	data, err := os.ReadFile(filepath.Join(out, "results.json"))
	if err != nil {
		t.Fatal(err)
	}
	var doc struct {
		Controls struct {
			Verifications int `json:"verifications"`
			FalseAlarms   int `json:"false_alarms"`
		} `json:"controls"`
		Rows []compromiseRow `json:"rows"`
	}
	if err := json.Unmarshal(data, &doc); err != nil {
		t.Fatal(err)
	}
	if doc.Controls.Verifications == 0 || doc.Controls.FalseAlarms != 0 {
		t.Fatalf("controls %+v", doc.Controls)
	}
	cells := strongestCells(doc.Rows)
	outcome := func(config, design, operator, keyset string) bool {
		t.Helper()
		for _, c := range cells {
			if c.Run == 1 && c.VerifierConfig == config && c.Design == design && c.Operator == operator && c.KeySet == keyset && c.Anchors == "none" {
				return c.Detected
			}
		}
		t.Fatalf("no cell %s/%s/%s/%s", config, design, operator, keyset)
		return false
	}
	for _, design := range []string{"bound", "unbound"} {
		if outcome("full", design, "strip-flag", "audit+issuer+adapter") {
			t.Errorf("%s: the snapshot-forging attacker with audit+issuer+adapter should defeat the full verifier", design)
		}
		if !outcome("full", design, "strip-flag", "audit") {
			t.Errorf("%s: the audit key alone must not defeat the full verifier", design)
		}
		if outcome("full", design, "change-amount", "audit+issuer+adapter+provider") || !outcome("full", design, "change-amount", "audit+issuer+adapter") {
			t.Errorf("%s: change-amount should need exactly the provider key on top of audit+issuer+adapter", design)
		}
	}
	if !outcome("no-replay", "bound", "strip-flag", "audit") || outcome("no-replay", "unbound", "strip-flag", "audit") {
		t.Error("no-replay: strip-flag with the audit key should flip between the designs")
	}
	if !outcome("no-snapshot-bound-only", "bound", "strip-flag", "audit") || outcome("no-snapshot-bound-only", "unbound", "strip-flag", "audit") {
		t.Error("no-snapshot-bound-only: strip-flag with the audit key should flip between the designs (forge-snapshot)")
	}
	if !strings.Contains(stdout.String(), "SIMULATION") {
		t.Errorf("summary does not say SIMULATION:\n%s", stdout.String())
	}
}
