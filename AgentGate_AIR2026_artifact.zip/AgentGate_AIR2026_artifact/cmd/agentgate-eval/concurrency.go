package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"

	"agentgate/internal/devcomposition"
	"agentgate/internal/effects"
)

// The concurrency experiment (REVISION_CONTRACT R6.4) releases N calls at
// once (a start barrier, then N goroutines through the real MCP boundary of
// one gateway) and records every status and the provider's committed
// effects. Scenarios:
//
//	exact-payment      N identical tools/call for one payment operation ID
//	exact-message      N identical tools/call for one message operation ID
//	conflicting-reuse  one operation ID, N payments with different amounts
//	cross-tool-reuse   one operation ID, half payments and half messages
//	lost-response      one payment whose provider response is lost
//	                   (FaultProviderResponseLost armed once), N exact retries
//	budget-race        N payments with fresh IDs, USD 500.00 each, against a
//	                   grant budget of USD 3,000.00 (reservation at PRE)
//	count-race         N document releases with fresh IDs against a grant
//	                   MaxCounts of 3 releases
//
// Each repetition uses a fresh provider host, gateway (with its operation
// journal) and evidence folder, verified afterwards with pinned anchors.

type concurrencyOptions struct {
	outDir, workDir string
	repeat, calls   int
	escalation      devcomposition.Escalation
}

func parseConcurrencyFlags(args []string, stderr io.Writer) (concurrencyOptions, error) {
	set := flag.NewFlagSet("concurrency", flag.ContinueOnError)
	set.SetOutput(stderr)
	out := set.String("out", "", "directory for concurrency.json, .csv and .md (required)")
	work := set.String("work", "", "directory for evidence folders (default: a temporary directory)")
	repeat := set.Int("repeat", 20, "repetitions of every scenario (each on a fresh gateway)")
	calls := set.Int("n", 8, "simultaneous calls per scenario (at least 2)")
	escalation := set.String("escalation", "flag", "escalation mode: flag or deny")
	if err := set.Parse(args); err != nil {
		return concurrencyOptions{}, err
	}
	if set.NArg() != 0 {
		return concurrencyOptions{}, fmt.Errorf("unexpected arguments: %v", set.Args())
	}
	options := concurrencyOptions{outDir: *out, workDir: *work, repeat: *repeat, calls: *calls}
	if options.outDir == "" {
		return concurrencyOptions{}, errors.New("-out is required")
	}
	if options.repeat < 1 || options.calls < 2 {
		return concurrencyOptions{}, errors.New("-repeat must be at least 1 and -n at least 2")
	}
	mode, err := parseAutonomousEscalation(*escalation)
	if err != nil {
		return concurrencyOptions{}, err
	}
	options.escalation = mode
	return options, nil
}

const (
	raceBudgetUSD     = 300_000 // USD 3,000.00
	raceAmountUSD     = 50_000  // USD 500.00
	raceReleaseLimit  = 3
	concurrencyGrantA = 1_000_000_000_000
)

var concurrencyScenarios = []string{"exact-payment", "exact-message", "conflicting-reuse", "cross-tool-reuse", "lost-response", "budget-race", "count-race"}

// raceCall is one call of a scenario.
type raceCall struct {
	OperationID string     `json:"operation_id"`
	Tool        string     `json:"tool"`
	Amount      uint64     `json:"amount_minor,omitempty"`
	Result      callResult `json:"result"`
	Rules       []string   `json:"policy_rules,omitempty"`
	ElapsedMS   float64    `json:"elapsed_ms"`
}

type raceScenario struct {
	Scenario       string         `json:"scenario"`
	Repeat         int            `json:"repeat"`
	Calls          []raceCall     `json:"calls"`
	StatusCounts   map[string]int `json:"status_counts"`
	Pattern        string         `json:"pattern"`
	Effects        int            `json:"provider_effects"`
	MaxPerID       int            `json:"max_effects_per_operation_id"`
	References     int            `json:"distinct_provider_references_in_committed_answers"`
	RejectedEffect int            `json:"rejected_while_effect_exists"`
	CommittedNone  int            `json:"committed_without_effect"`
	Invariant      string         `json:"invariant"`
	Holds          bool           `json:"invariant_holds"`
	Detail         string         `json:"detail"`
}

type concurrencyRepetition struct {
	Repeat    int             `json:"repeat"`
	Scenarios []raceScenario  `json:"scenarios"`
	Evidence  verifyOutcome   `json:"evidence"`
	Delegated json.RawMessage `json:"delegation_status,omitempty"`
	Error     string          `json:"error,omitempty"`
}

type concurrencySummaryRow struct {
	Scenario      string         `json:"scenario"`
	Repetitions   int            `json:"repetitions"`
	InvariantHeld int            `json:"invariant_held"`
	Patterns      map[string]int `json:"outcome_patterns"`
	MaxEffects    int            `json:"max_effects_in_a_repetition"`
	MaxPerID      int            `json:"max_effects_per_operation_id"`
	Rejected      int            `json:"rejected_while_effect_exists"`
	CommittedNone int            `json:"committed_without_effect"`
	Invariant     string         `json:"invariant"`
}

type concurrencyResult struct {
	Note        string                  `json:"note"`
	Method      []string                `json:"method"`
	Environment environment             `json:"environment"`
	Calls       int                     `json:"simultaneous_calls"`
	Summary     []concurrencySummaryRow `json:"summary"`
	Evidence    map[string]int          `json:"evidence_assurance_counts"`
	Repetitions []concurrencyRepetition `json:"repetitions"`
}

func runConcurrency(args []string, stdout io.Writer) error {
	options, err := parseConcurrencyFlags(args, stdout)
	if err != nil {
		return err
	}
	outDir, workDir, err := prepareDirs(options.outDir, options.workDir, "concurrency")
	if err != nil {
		return err
	}
	ctx, stop := interruptible()
	defer stop()
	w, err := newWorld()
	if err != nil {
		return err
	}
	result := concurrencyResult{
		Note: "Local races inside one gateway process on one machine: the start barrier releases the goroutines together, but the " +
			"interleaving is whatever the Go scheduler produced in each repetition. Holding invariants here do not prove them for all interleavings.",
		Method: []string{
			fmt.Sprintf("%d goroutines per scenario wait on one start barrier and then each send one JSON-RPC tools/call through the gateway's MCP handler (in process).", options.calls),
			"Provider: provider host with its own key, reached over loopback HTTP; every count of effects is read from its own signed journal.",
			fmt.Sprintf("Grant: AED budget %s, USD budget %s, %d document releases; everything else unbounded.", formatMinor(concurrencyGrantA, "AED"), formatMinor(raceBudgetUSD, "USD"), raceReleaseLimit),
			"Pattern: the sorted multiset of STATUS/reason answers of one scenario; identical patterns in every repetition mean the answers were deterministic up to which caller won.",
		},
		Environment: currentEnvironment(append([]string{"concurrency"}, args...)), Calls: options.calls, Evidence: map[string]int{},
	}
	for repeat := 1; repeat <= options.repeat; repeat++ {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		repetition := runConcurrencyRepetition(ctx, w, workDir, options, repeat)
		result.Repetitions = append(result.Repetitions, repetition)
		result.Evidence[repetition.Evidence.Assurance+map[bool]string{true: " (error)", false: ""}[repetition.Evidence.Error != ""]]++
		line := []string{}
		for _, scenario := range repetition.Scenarios {
			line = append(line, fmt.Sprintf("%s %s", scenario.Scenario, map[bool]string{true: "ok", false: "VIOLATED"}[scenario.Holds]))
		}
		fmt.Fprintf(stdout, "concurrency r%02d: %s; evidence %s %s\n", repeat, strings.Join(line, ", "), repetition.Evidence.Assurance, repetition.Error)
	}
	result.Summary = summarizeConcurrency(result.Repetitions)
	if err := writeJSON(filepath.Join(outDir, "concurrency.json"), result); err != nil {
		return err
	}
	if err := writeText(filepath.Join(outDir, "concurrency.csv"), concurrencyCSV(result.Repetitions)); err != nil {
		return err
	}
	if err := writeText(filepath.Join(outDir, "concurrency.md"), concurrencyMarkdown(result)); err != nil {
		return err
	}
	fmt.Fprintf(stdout, "concurrency: %d repetitions x %d scenarios; results in %s\n", options.repeat, len(concurrencyScenarios), displayPath(outDir))
	return nil
}

func runConcurrencyRepetition(ctx context.Context, w *world, workDir string, options concurrencyOptions, repeat int) (repetition concurrencyRepetition) {
	repetition = concurrencyRepetition{Repeat: repeat}
	label := fmt.Sprintf("concurrency-r%02d", repeat)
	dir := filepath.Join(workDir, label)
	if err := os.MkdirAll(dir, 0o755); err != nil {
		repetition.Error = err.Error()
		return repetition
	}
	run, err := newRunIdentity(label)
	if err != nil {
		repetition.Error = err.Error()
		return repetition
	}
	provider, err := startProviderHost(w, run, nil)
	if err != nil {
		repetition.Error = err.Error()
		return repetition
	}
	defer provider.close()
	spec := w.openGrant(time.Now())
	spec.Budgets = map[string]uint64{"AED": concurrencyGrantA, "USD": raceBudgetUSD}
	spec.MaxCounts[string(effects.DocumentRelease)] = raceReleaseLimit
	grant, err := signGrant(label, spec)
	if err != nil {
		repetition.Error = err.Error()
		return repetition
	}
	evidence, err := newEvidenceRun(filepath.Join(dir, "run"), label)
	if err != nil {
		repetition.Error = err.Error()
		return repetition
	}
	plan := devcomposition.NewFaultPlan()
	lostID := newOperationID()
	plan.Arm(devcomposition.FaultProviderResponseLost, lostID)
	g, err := buildGateway(ctx, w, run, provider, gatewaySpec{Escalation: options.escalation, Faults: plan, Journal: filepath.Join(dir, "operations.jsonl"), Sink: evidence, Grant: grant})
	if err != nil {
		_ = evidence.finish(nil)
		repetition.Error = err.Error()
		return repetition
	}
	if err := evidence.begin(w, g, grant, "concurrency repetition "+label); err != nil {
		repetition.Error = err.Error()
		return repetition
	}
	caller := g.caller()
	brochure := w.document("brochure")
	n := options.calls
	type planned struct {
		tool   string
		id     [16]byte
		amount uint64
		args   map[string]any
	}
	scenarioCalls := map[string][]planned{}
	{
		id := newOperationID()
		for i := 0; i < n; i++ {
			scenarioCalls["exact-payment"] = append(scenarioCalls["exact-payment"], planned{toolPayment, id, 125_000, paymentArgs(id, "payee.office-supplies", uint64(125_000), "AED", "Toner cartridges")})
		}
	}
	{
		id := newOperationID()
		for i := 0; i < n; i++ {
			scenarioCalls["exact-message"] = append(scenarioCalls["exact-message"], planned{toolMessage, id, 0, messageArgs(id, []string{"ops.lead"}, "Gate change", "The Thursday pickup moves to gate 4.")})
		}
	}
	{
		id := newOperationID()
		for i := 0; i < n; i++ {
			amount := uint64(100_000 + i)
			scenarioCalls["conflicting-reuse"] = append(scenarioCalls["conflicting-reuse"], planned{toolPayment, id, amount, paymentArgs(id, "payee.office-supplies", amount, "AED", "Pallet wrap")})
		}
	}
	{
		id := newOperationID()
		for i := 0; i < n; i++ {
			if i%2 == 0 {
				scenarioCalls["cross-tool-reuse"] = append(scenarioCalls["cross-tool-reuse"], planned{toolPayment, id, 90_000, paymentArgs(id, "payee.carrier", uint64(90_000), "AED", "Fuel surcharge")})
			} else {
				scenarioCalls["cross-tool-reuse"] = append(scenarioCalls["cross-tool-reuse"], planned{toolMessage, id, 0, messageArgs(id, []string{"finance.manager"}, "Fuel surcharge", "The carrier fuel surcharge is AED 900.00 this week.")})
			}
		}
	}
	for i := 0; i < n; i++ {
		scenarioCalls["lost-response"] = append(scenarioCalls["lost-response"], planned{toolPayment, lostID, 75_000, paymentArgs(lostID, "payee.it-services", uint64(75_000), "AED", "Laptop repair")})
	}
	for i := 0; i < n; i++ {
		id := newOperationID()
		scenarioCalls["budget-race"] = append(scenarioCalls["budget-race"], planned{toolPayment, id, raceAmountUSD, paymentArgs(id, "payee.carrier", uint64(raceAmountUSD), "USD", "Linehaul deposit")})
	}
	for i := 0; i < n; i++ {
		id := newOperationID()
		scenarioCalls["count-race"] = append(scenarioCalls["count-race"], planned{toolDocument, id, 0, documentArgs(id, brochure.SHA256, []string{"ops.lead"}, "view")})
	}
	type finished struct {
		name  string
		calls []raceCall
	}
	var completed []finished
	for _, name := range concurrencyScenarios {
		planCalls := scenarioCalls[name]
		calls := make([]raceCall, len(planCalls))
		start := make(chan struct{})
		var wait sync.WaitGroup
		for index, call := range planCalls {
			wait.Add(1)
			go func() {
				defer wait.Done()
				<-start
				began := hrTicks()
				result := caller.call(ctx, call.tool, call.args)
				calls[index] = raceCall{OperationID: opText(call.id), Tool: call.tool, Amount: call.amount, Result: result, ElapsedMS: round(ms(hrElapsed(began, hrTicks())), 3)}
			}()
		}
		close(start)
		wait.Wait()
		completed = append(completed, finished{name, calls})
	}
	if status, ok := g.comp.DelegationStatus(); ok {
		if raw, err := json.Marshal(status); err == nil {
			repetition.Delegated = raw
		}
	}
	if err := evidence.finish(provider); err != nil {
		repetition.Error = err.Error()
	}
	commits, err := provider.commits()
	if err != nil {
		repetition.Error = err.Error()
		return repetition
	}
	perOperation := commitsByOperation(commits)
	for _, item := range completed {
		for index := range item.calls {
			rules, _, _ := evidence.policyRules(item.calls[index].OperationID)
			if item.name == "budget-race" || item.name == "count-race" {
				item.calls[index].Rules = rules
			}
		}
		repetition.Scenarios = append(repetition.Scenarios, assessRace(item.name, repeat, item.calls, perOperation))
	}
	repetition.Evidence = verifyPinned(evidence)
	return repetition
}

func assessRace(name string, repeat int, calls []raceCall, perOperation map[string]int) raceScenario {
	scenario := raceScenario{Scenario: name, Repeat: repeat, Calls: calls, StatusCounts: map[string]int{}}
	ids := map[string]bool{}
	references := map[string]bool{}
	for _, call := range calls {
		scenario.StatusCounts[call.Result.statusKey()]++
		ids[call.OperationID] = true
		if call.Result.Status == string(devcomposition.StatusCommitted) {
			if call.Result.ProviderReference != "" {
				references[call.Result.ProviderReference] = true
			}
			if perOperation[call.OperationID] == 0 {
				scenario.CommittedNone++
			}
		}
		if call.Result.Status == string(devcomposition.StatusRejected) && perOperation[call.OperationID] > 0 && name != "conflicting-reuse" && name != "cross-tool-reuse" {
			scenario.RejectedEffect++
		}
	}
	for id := range ids {
		scenario.Effects += perOperation[id]
		scenario.MaxPerID = max(scenario.MaxPerID, perOperation[id])
	}
	scenario.References = len(references)
	keys := make([]string, 0, len(scenario.StatusCounts))
	for key := range scenario.StatusCounts {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	parts := make([]string, len(keys))
	for index, key := range keys {
		parts[index] = fmt.Sprintf("%dx %s", scenario.StatusCounts[key], key)
	}
	scenario.Pattern = strings.Join(parts, " + ")
	committed := scenario.StatusCounts[string(devcomposition.StatusCommitted)+"/"] + scenario.StatusCounts[string(devcomposition.StatusCommitted)+"/reconciled"]
	conflicts := scenario.StatusCounts[string(devcomposition.StatusRejected)+"/operation_id_conflict"]
	base := scenario.MaxPerID <= 1 && scenario.CommittedNone == 0 && scenario.RejectedEffect == 0
	switch name {
	case "exact-payment", "exact-message":
		scenario.Invariant = "exactly 1 effect; every answer COMMITTED with the same provider reference"
		scenario.Holds = base && scenario.Effects == 1 && committed == len(calls) && scenario.References == 1
	case "conflicting-reuse":
		// A REJECTED conflict for the operation ID that holds the winner's
		// effect is correct here: the conflicting request itself has none.
		scenario.Invariant = "at most 1 effect; every other caller REJECTED operation_id_conflict"
		scenario.Holds = base && scenario.Effects <= 1 && conflicts == len(calls)-committed && committed == scenario.Effects
	case "cross-tool-reuse":
		// The callers of the winning request send identical calls (exact
		// retries of each other) and must all see COMMITTED; every caller of
		// the other tool must see the conflict.
		scenario.Invariant = "exactly 1 effect; all callers of the winning tool COMMITTED (same reference), all callers of the other tool REJECTED operation_id_conflict"
		byTool := map[string]map[string]int{}
		for _, call := range calls {
			if byTool[call.Tool] == nil {
				byTool[call.Tool] = map[string]int{}
			}
			byTool[call.Tool][call.Result.statusKey()]++
		}
		winners, losers := 0, 0
		for _, counts := range byTool {
			total := 0
			for _, count := range counts {
				total += count
			}
			switch {
			case counts[string(devcomposition.StatusCommitted)+"/"] == total:
				winners++
			case counts[string(devcomposition.StatusRejected)+"/operation_id_conflict"] == total:
				losers++
			}
		}
		scenario.Holds = base && scenario.Effects == 1 && winners == 1 && losers == len(byTool)-1 && scenario.References == 1
	case "lost-response":
		scenario.Invariant = "exactly 1 effect; no REJECTED; the answers that are not UNCERTAIN are COMMITTED (reconciled)"
		uncertain := scenario.StatusCounts[string(devcomposition.StatusUncertain)+"/provider_response_lost"]
		scenario.Holds = base && scenario.Effects == 1 && uncertain+committed == len(calls)
	case "budget-race":
		limit := raceBudgetUSD / raceAmountUSD
		scenario.Invariant = fmt.Sprintf("committed USD total <= budget (at most %d of %d payments); COMMITTED answers == effects", limit, len(calls))
		scenario.Holds = base && scenario.Effects <= limit && committed == scenario.Effects
		scenario.Detail = fmt.Sprintf("%d committed = %s of %s", scenario.Effects, formatMinor(uint64(scenario.Effects*raceAmountUSD), "USD"), formatMinor(raceBudgetUSD, "USD"))
	case "count-race":
		scenario.Invariant = fmt.Sprintf("at most %d releases committed; COMMITTED answers == effects", raceReleaseLimit)
		scenario.Holds = base && scenario.Effects <= raceReleaseLimit && committed == scenario.Effects
		scenario.Detail = fmt.Sprintf("%d of %d releases committed", scenario.Effects, len(calls))
	}
	return scenario
}

func summarizeConcurrency(repetitions []concurrencyRepetition) []concurrencySummaryRow {
	rows := map[string]*concurrencySummaryRow{}
	for _, name := range concurrencyScenarios {
		rows[name] = &concurrencySummaryRow{Scenario: name, Patterns: map[string]int{}}
	}
	for _, repetition := range repetitions {
		for _, scenario := range repetition.Scenarios {
			row := rows[scenario.Scenario]
			row.Repetitions++
			row.InvariantHeld += b2i(scenario.Holds)
			row.Patterns[scenario.Pattern]++
			row.MaxEffects = max(row.MaxEffects, scenario.Effects)
			row.MaxPerID = max(row.MaxPerID, scenario.MaxPerID)
			row.Rejected += scenario.RejectedEffect
			row.CommittedNone += scenario.CommittedNone
			row.Invariant = scenario.Invariant
		}
	}
	out := make([]concurrencySummaryRow, 0, len(rows))
	for _, name := range concurrencyScenarios {
		out = append(out, *rows[name])
	}
	return out
}

func concurrencyCSV(repetitions []concurrencyRepetition) string {
	var b strings.Builder
	b.WriteString(csvLine("repeat", "scenario", "calls", "pattern", "provider_effects", "max_effects_per_operation_id", "distinct_references",
		"rejected_while_effect_exists", "committed_without_effect", "invariant_holds", "detail", "evidence_verdict", "evidence_assurance", "evidence_failing_checks", "error"))
	for _, repetition := range repetitions {
		if len(repetition.Scenarios) == 0 {
			b.WriteString(csvLine(fmt.Sprint(repetition.Repeat), "", "", "", "", "", "", "", "", "", "", "", "", "", repetition.Error))
		}
		for _, scenario := range repetition.Scenarios {
			b.WriteString(csvLine(fmt.Sprint(repetition.Repeat), scenario.Scenario, fmt.Sprint(len(scenario.Calls)), scenario.Pattern, fmt.Sprint(scenario.Effects),
				fmt.Sprint(scenario.MaxPerID), fmt.Sprint(scenario.References), fmt.Sprint(scenario.RejectedEffect), fmt.Sprint(scenario.CommittedNone),
				boolText(scenario.Holds), scenario.Detail, repetition.Evidence.Verdict, repetition.Evidence.Assurance, strings.Join(repetition.Evidence.Failing, " "), repetition.Error))
		}
	}
	return b.String()
}

func concurrencyMarkdown(result concurrencyResult) string {
	var b strings.Builder
	fmt.Fprintf(&b, "# Concurrency: simultaneous retries, conflicting reuse, racing reservations\n\n%s\n\n", result.Note)
	fmt.Fprintf(&b, "Command: `%s`. Go %s on %s/%s, %d CPUs, GOMAXPROCS %d.\n\n## Method\n\n", result.Environment.Command,
		result.Environment.GoVersion, result.Environment.GOOS, result.Environment.GOARCH, result.Environment.NumCPU, result.Environment.GOMAXPROCS)
	for _, line := range result.Method {
		fmt.Fprintf(&b, "- %s\n", line)
	}
	b.WriteString("\n## Results\n\n| scenario | invariant | held | max effects | max effects per ID | REJECTED with effect | COMMITTED without effect | answer patterns (repetitions) |\n|---|---|---|---|---|---|---|---|\n")
	for _, row := range result.Summary {
		patterns := make([]string, 0, len(row.Patterns))
		for pattern, count := range row.Patterns {
			patterns = append(patterns, fmt.Sprintf("%s (%d)", pattern, count))
		}
		sort.Strings(patterns)
		fmt.Fprintf(&b, "| %s | %s | %d / %d | %d | %d | %d | %d | %s |\n", row.Scenario, row.Invariant, row.InvariantHeld, row.Repetitions,
			row.MaxEffects, row.MaxPerID, row.Rejected, row.CommittedNone, strings.Join(patterns, "; "))
	}
	b.WriteString("\n## Evidence\n\nOne evidence folder per repetition, verified with the keys fingerprint and final head pinned:\n\n")
	keys := make([]string, 0, len(result.Evidence))
	for key := range result.Evidence {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	for _, key := range keys {
		fmt.Fprintf(&b, "- %s: %d\n", key, result.Evidence[key])
	}
	failed := false
	for _, repetition := range result.Repetitions {
		if repetition.Evidence.Verdict == "VERIFIED" && repetition.Error == "" {
			continue
		}
		if !failed {
			b.WriteString("\nFolders that did not verify (kept as found; see the JSON for every finding):\n\n| repetition | verdict | failing checks | error |\n|---|---|---|---|\n")
			failed = true
		}
		fmt.Fprintf(&b, "| %d | %s | %s | %s |\n", repetition.Repeat, repetition.Evidence.Verdict, strings.Join(repetition.Evidence.Failing, ", "), repetition.Error+repetition.Evidence.Error)
	}
	return b.String()
}

// formatMinor renders minor units as "AED 1,234.56".
func formatMinor(amount uint64, currency string) string {
	whole := fmt.Sprintf("%d", amount/100)
	var grouped strings.Builder
	for index, digit := range whole {
		if index > 0 && (len(whole)-index)%3 == 0 {
			grouped.WriteByte(',')
		}
		grouped.WriteRune(digit)
	}
	return fmt.Sprintf("%s %s.%02d", currency, grouped.String(), amount%100)
}
