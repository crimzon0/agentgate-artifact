package main

import (
	"encoding/base64"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"time"

	"agentgate/internal/audit"
)

// The cost experiment measures what the evidence costs:
//
//  (a) audit.Append per entry in three write modes (audit.WriteMode):
//      durable (the default: write + fsync of the log + head.json replaced
//      through a synced temporary file), no-sync (the same writes without
//      either fsync) and sign-only (entry and head built, hashed and signed,
//      nothing written). The appended events are the real events of a
//      self-test run, replayed in order. Windows' clock advances in steps of
//      about a millisecond, so each measurement times a whole batch of
//      appends and divides by the batch size.
//  (b) gateway call latency (agent MCP tools/call at the gateway, request
//      received to response complete) by outcome, from a self-test with
//      -repeat scenario suites in one run (demo self-test metrics).
//  (c) the share of (b) spent on audit appends is not measured by switching
//      the recorder off (the gateway fails closed without it); it is
//      estimated as gateway-written entries per call times the per-entry
//      cost from (a), and labeled as an estimate.

type appendMode struct {
	Name        string `json:"name"`
	Description string `json:"description"`
	mode        audit.WriteMode
}

var appendModes = []appendMode{
	{"durable", "default: write line, fsync audit.jsonl, replace head.json via a synced temporary file and rename", audit.WriteDurable},
	{"no-fsync", "same writes as durable, both fsync calls skipped (experiment only)", audit.WriteNoSync},
	{"sign-only", "entry and head encoded, hashed and Ed25519-signed; nothing written (experiment only)", audit.WriteNone},
}

type appendBatch struct {
	Mode        string  `json:"mode"`
	Batch       int     `json:"batch"`
	Appends     int     `json:"appends"`
	TotalMS     float64 `json:"total_ms"`
	PerEntryUS  float64 `json:"per_entry_us"`
	BytesPerApp float64 `json:"log_bytes_per_entry"`
}

type appendModeResult struct {
	appendMode
	PerEntryUS summary `json:"per_entry_us"`
	// EntriesPerSecond is derived from the median per-entry cost.
	EntriesPerSecond float64 `json:"entries_per_second"`
	LogBytesPerEntry float64 `json:"log_bytes_per_entry"`
}

type latencyClass struct {
	Outcome string    `json:"outcome"`
	Stats   summary   `json:"latency_ms"`
	Samples []float64 `json:"samples_ms"`
	// GatewayEntries is the median number of audit entries the gateway
	// itself wrote during one call of this class (from the audit log).
	GatewayEntries *float64 `json:"gateway_entries_per_call_median,omitempty"`
	// EstimatedAppendMS = GatewayEntries x durable per-entry median (a).
	EstimatedAppendMS *float64 `json:"estimated_append_ms,omitempty"`
	// EstimatedShare = EstimatedAppendMS / median latency.
	EstimatedShare *float64 `json:"estimated_append_share_of_median,omitempty"`
	// EstimatedFsyncMS = GatewayEntries x (durable - no-fsync) medians.
	EstimatedFsyncMS *float64 `json:"estimated_fsync_ms,omitempty"`
}

type costResult struct {
	Format      string      `json:"format"`
	Note        string      `json:"note"`
	Environment environment `json:"environment"`
	Run         baseRun     `json:"run"`
	Append      struct {
		Description    string             `json:"description"`
		CorpusEntries  int                `json:"corpus_entries"`
		CorpusBytes    float64            `json:"corpus_mean_line_bytes"`
		AppendsPerBat  int                `json:"appends_per_batch"`
		Batches        int                `json:"batches"`
		Modes          []appendModeResult `json:"modes"`
		FsyncUS        float64            `json:"fsync_cost_us_per_entry"`
		WriteUS        float64            `json:"write_cost_us_per_entry"`
		BatchesRaw     []appendBatch      `json:"batches_raw"`
		DerivedComment string             `json:"derived_comment"`
	} `json:"append_cost"`
	Latency struct {
		Description string         `json:"description"`
		All         summary        `json:"all_ms"`
		Classes     []latencyClass `json:"by_outcome"`
		Matched     bool           `json:"calls_matched_to_audit_segments"`
		MatchNote   string         `json:"match_note"`
	} `json:"gateway_latency"`
	DurationS float64 `json:"duration_s"`
}

func runCost(args []string, stdout io.Writer) error {
	flags := flag.NewFlagSet("cost", flag.ContinueOnError)
	perBatch := flags.Int("n", 2000, "audit appends per timed batch")
	batches := flags.Int("batches", 5, "timed batches per write mode")
	repeat := flags.Int("repeat", 20, "scenario suites in the self-test used for gateway latency")
	out := flags.String("out", "", "output directory for cost.json/md")
	work := flags.String("work", "", "directory for the run and the scratch logs (default: temp)")
	if err := flags.Parse(args); err != nil {
		return err
	}
	if *perBatch < 10 || *batches < 1 || *repeat < 1 {
		return fmt.Errorf("-n must be at least 10, -batches and -repeat at least 1")
	}
	outDir, workDir, err := prepareDirs(*out, *work, "cost")
	if err != nil {
		return err
	}
	ctx, cancel := interruptible()
	defer cancel()
	began := time.Now()

	result := costResult{
		Format: "agentgate-eval-cost/v1",
		Note: "Local measurements on one computer under normal desktop load; absolute values depend on the disk, the file system, " +
			"antivirus scanning and the Windows timer. Gateway latencies are quantized to the clock granularity.",
		Environment: currentEnvironment(append([]string{"cost"}, args...)),
	}

	fmt.Fprintf(stdout, "self-test with %d suites ... ", *repeat)
	run, err := createBaseRun(ctx, 1, filepath.Join(workDir, "runs"), *repeat)
	if err != nil {
		return err
	}
	result.Run = run
	fmt.Fprintf(stdout, "%s, %d entries\n", run.RunID, run.Entries)

	// (a) append cost.
	entries, err := audit.ReadLog(run.dir)
	if err != nil {
		return err
	}
	events := make([]audit.Event, 0, len(entries))
	for _, stored := range entries {
		event, err := eventFromEntry(stored.Entry)
		if err != nil {
			return err
		}
		events = append(events, event)
	}
	a := &result.Append
	a.Description = "Per-entry cost of audit.Append, from timed batches of consecutive appends of the run's own events " +
		"(replayed in order) into a fresh log per batch; per-entry = batch time / appends."
	a.CorpusEntries, a.AppendsPerBat, a.Batches = len(events), *perBatch, *batches
	a.CorpusBytes = round(float64(run.LogBytes)/float64(max(1, run.Entries)), 1)
	scratch := filepath.Join(workDir, "append")
	for _, mode := range appendModes { // warm-up, discarded
		if _, err := timeAppends(filepath.Join(scratch, "warmup-"+mode.Name), mode, events, 100, 0); err != nil {
			return err
		}
	}
	perMode := map[string][]float64{}
	bytesPerMode := map[string]float64{}
	for batch := 1; batch <= *batches; batch++ {
		// Rotate the order of the modes so that none always runs first.
		for offset := range appendModes {
			mode := appendModes[(batch+offset)%len(appendModes)]
			measured, err := timeAppends(filepath.Join(scratch, fmt.Sprintf("%s-%d", mode.Name, batch)), mode, events, *perBatch, batch)
			if err != nil {
				return err
			}
			a.BatchesRaw = append(a.BatchesRaw, measured)
			perMode[mode.Name] = append(perMode[mode.Name], measured.PerEntryUS)
			bytesPerMode[mode.Name] = measured.BytesPerApp
			fmt.Fprintf(stdout, "append batch %d %-9s %8.1f us/entry\n", batch, mode.Name, measured.PerEntryUS)
		}
	}
	medians := map[string]float64{}
	for _, mode := range appendModes {
		stats := summarize("us", perMode[mode.Name])
		medians[mode.Name] = stats.Median
		result.Append.Modes = append(result.Append.Modes, appendModeResult{
			appendMode: mode, PerEntryUS: stats, EntriesPerSecond: round(1e6/stats.Median, 0), LogBytesPerEntry: bytesPerMode[mode.Name],
		})
	}
	a.FsyncUS = round(medians["durable"]-medians["no-fsync"], 1)
	a.WriteUS = round(medians["no-fsync"]-medians["sign-only"], 1)
	a.DerivedComment = "fsync cost = durable median - no-fsync median; write cost = no-fsync median - sign-only median (differences of medians)."
	_ = os.RemoveAll(scratch)

	// (b) gateway latency by outcome, (c) estimated append share.
	l := &result.Latency
	l.Description = "Wall-clock time of each agent MCP tools/call at the gateway's MCP handler (request received to response complete), " +
		"from the demo self-test's own timer. Includes the gateway's audit appends and, for applied calls, the loopback HTTP round trip " +
		"to the simulated provider. Outcome is the result kind the agent received; (resumed) marks the call that resumes after a human decision; " +
		"applied (duplicate) is a repeated identical call (replay scenario) answered with the original result, with no new effect and no " +
		"EFFECT_EXECUTED entry (identified from the matched audit segment)."
	samples := run.report.Metrics.GatewayCalls.Samples
	segments := gatewaySegments(entries)
	l.Matched = len(segments) == len(samples)
	byOutcome := map[string][]float64{}
	var all []float64
	var order []string
	keys := make([]string, len(samples))
	for i, sample := range samples {
		key := sample.Result
		if sample.Resumed {
			key += " (resumed)"
		}
		if l.Matched && sample.Result == "applied" && !segments[i].executed {
			key = "applied (duplicate)"
		}
		keys[i] = key
		if _, seen := byOutcome[key]; !seen {
			order = append(order, key)
		}
		byOutcome[key] = append(byOutcome[key], sample.MS)
		all = append(all, sample.MS)
	}
	sort.Strings(order)
	l.All = summarize("ms", all)
	l.MatchNote = fmt.Sprintf("%d timed gateway calls, %d agent call segments (AGENT_PROPOSED..AGENT_RECEIVED) in the audit log; "+
		"calls are sequential in the self-test, so the i-th call is matched with the i-th segment when the counts agree.", len(samples), len(segments))
	gatewayEntries := map[string][]float64{}
	if l.Matched {
		for i, key := range keys {
			gatewayEntries[key] = append(gatewayEntries[key], float64(segments[i].gatewayEntries))
		}
	}
	for _, key := range order {
		class := latencyClass{Outcome: key, Stats: summarize("ms", byOutcome[key]), Samples: byOutcome[key]}
		if counts := gatewayEntries[key]; len(counts) > 0 {
			entriesPerCall := percentile(sortedCopy(counts), 0.5)
			appendMS := round(entriesPerCall*medians["durable"]/1000, 3)
			share := 0.0
			if class.Stats.Median > 0 {
				share = round(appendMS/class.Stats.Median, 3)
			}
			fsyncMS := round(entriesPerCall*(medians["durable"]-medians["no-fsync"])/1000, 3)
			class.GatewayEntries, class.EstimatedAppendMS, class.EstimatedShare, class.EstimatedFsyncMS = &entriesPerCall, &appendMS, &share, &fsyncMS
		}
		l.Classes = append(l.Classes, class)
	}
	result.DurationS = round(time.Since(began).Seconds(), 1)

	if err := writeJSON(filepath.Join(outDir, "cost.json"), result); err != nil {
		return err
	}
	if err := writeText(filepath.Join(outDir, "cost.md"), costMarkdown(result)); err != nil {
		return err
	}
	fmt.Fprintf(stdout, "wrote %s (cost.json, cost.md)\n", outDir)
	return nil
}

// eventFromEntry turns a stored entry back into the event that produced it.
func eventFromEntry(entry audit.Entry) (audit.Event, error) {
	artifacts := make(map[string][]byte, len(entry.Artifacts))
	for name, text := range entry.Artifacts {
		raw, err := base64.StdEncoding.DecodeString(text)
		if err != nil {
			return audit.Event{}, fmt.Errorf("entry %d artifact %s: %w", entry.Seq, name, err)
		}
		artifacts[name] = raw
	}
	return audit.Event{
		Stage: entry.Stage, Actor: entry.Actor, Component: entry.Component, Location: entry.Location,
		Outcome: entry.Outcome, Summary: entry.Summary, OperationID: entry.OperationID, EffectType: entry.EffectType,
		EffectDigest: entry.EffectDigest, Details: entry.Details, Artifacts: artifacts,
	}, nil
}

// timeAppends appends n events (cycling through events) to a fresh log in
// dir with the given mode and returns the batch timing.
func timeAppends(dir string, mode appendMode, events []audit.Event, n, batch int) (appendBatch, error) {
	runtime.GC()
	log, err := audit.Create(audit.Options{Dir: dir, RunID: "eval-cost", WriteMode: mode.mode})
	if err != nil {
		return appendBatch{}, err
	}
	began := time.Now()
	for i := 0; i < n; i++ {
		if _, err := log.Append(events[i%len(events)]); err != nil {
			log.Close()
			return appendBatch{}, fmt.Errorf("%s append %d: %w", mode.Name, i+1, err)
		}
	}
	elapsed := time.Since(began)
	if err := log.Close(); err != nil {
		return appendBatch{}, err
	}
	var size int64
	if info, err := os.Stat(filepath.Join(dir, audit.LogFile)); err == nil {
		size = info.Size()
	}
	_ = os.RemoveAll(dir)
	return appendBatch{
		Mode: mode.Name, Batch: batch, Appends: n, TotalMS: round(ms(elapsed), 3),
		PerEntryUS: round(float64(elapsed)/float64(time.Microsecond)/float64(n), 2), BytesPerApp: round(float64(size)/float64(n), 1),
	}, nil
}

// callSegment is one agent call in the audit log.
type callSegment struct {
	gatewayEntries int  // entries written by gateway components inside the timed call
	executed       bool // the call recorded an EFFECT_EXECUTED entry
}

// gatewaySegments returns, for each agent call in log order (AGENT_PROPOSED
// to the next AGENT_RECEIVED of the same operation), the entries written by
// gateway components inside the timed gateway call. MCP_REJECTED is
// excluded: the demo's agent session records it after the call has returned
// (internal/demo/agent.go), outside the timed handler.
func gatewaySegments(entries []audit.StoredEntry) []callSegment {
	open := map[string]*callSegment{}
	var out []callSegment
	for _, stored := range entries {
		entry := stored.Entry
		switch {
		case entry.Stage == "AGENT_PROPOSED":
			open[entry.OperationID] = &callSegment{}
		case entry.Stage == "AGENT_RECEIVED":
			if segment, ok := open[entry.OperationID]; ok {
				out = append(out, *segment)
				delete(open, entry.OperationID)
			}
		case entry.Stage == "MCP_REJECTED":
			// recorded after the call returned; not part of the timed call
		case strings.HasPrefix(entry.Component, "gateway/"):
			if segment, ok := open[entry.OperationID]; ok {
				segment.gatewayEntries++
				segment.executed = segment.executed || entry.Stage == "EFFECT_EXECUTED"
			}
		}
	}
	return out
}

func costMarkdown(result costResult) string {
	var b strings.Builder
	a, l := result.Append, result.Latency
	fmt.Fprintf(&b, "# Cost of evidence\n\n%s\n\n", result.Note)
	fmt.Fprintf(&b, "- Command: `%s`; Go %s on %s/%s, %d CPUs; clock granularity %.3f ms; total %.0f s.\n",
		result.Environment.Command, result.Environment.GoVersion, result.Environment.GOOS, result.Environment.GOARCH,
		result.Environment.NumCPU, result.Environment.ClockGranularityMS, result.DurationS)
	fmt.Fprintf(&b, "- Source run: %s (self-test, %d suites, %s), %d entries, %d bytes of audit.jsonl.\n\n",
		result.Run.RunID, result.Run.Repeat, result.Run.SelfTest, result.Run.Entries, result.Run.LogBytes)

	fmt.Fprintf(&b, "## (a) audit.Append cost per entry\n\n%s Corpus: %d real entries, mean %.0f bytes per line. %d batches x %d appends per mode.\n\n",
		a.Description, a.CorpusEntries, a.CorpusBytes, a.Batches, a.AppendsPerBat)
	fmt.Fprintf(&b, "| Mode | What it does | Median us/entry | Min | Max | Entries/s (from median) |\n|---|---|---|---|---|---|\n")
	for _, mode := range a.Modes {
		fmt.Fprintf(&b, "| %s | %s | %.1f | %.1f | %.1f | %.0f |\n", mode.Name, mode.Description, mode.PerEntryUS.Median,
			mode.PerEntryUS.Min, mode.PerEntryUS.Max, mode.EntriesPerSecond)
	}
	fmt.Fprintf(&b, "\nDerived: fsync = %.1f us/entry, file writes (line + head replace) = %.1f us/entry. %s\n\n", a.FsyncUS, a.WriteUS, a.DerivedComment)

	fmt.Fprintf(&b, "## (b) Gateway call latency by outcome\n\n%s\n\n", l.Description)
	fmt.Fprintf(&b, "| Outcome | n | Median ms | p95 ms | Mean ms | Max ms | Gateway entries/call | Est. append ms (share of median) | Est. fsync ms |\n|---|---|---|---|---|---|---|---|---|\n")
	row := func(name string, stats summary, class *latencyClass) {
		p95 := "n<20"
		if stats.P95 != nil {
			p95 = fmt.Sprintf("%.2f", *stats.P95)
		}
		entriesText, appendText, fsyncText := "-", "-", "-"
		if class != nil && class.GatewayEntries != nil {
			entriesText = fmt.Sprintf("%.0f", *class.GatewayEntries)
			appendText = fmt.Sprintf("%.2f (%.0f%%)", *class.EstimatedAppendMS, *class.EstimatedShare*100)
			fsyncText = fmt.Sprintf("%.2f", *class.EstimatedFsyncMS)
		}
		fmt.Fprintf(&b, "| %s | %d | %.2f | %s | %.2f | %.2f | %s | %s | %s |\n", name, stats.N, stats.Median, p95, stats.Mean, stats.Max, entriesText, appendText, fsyncText)
	}
	for i := range l.Classes {
		row(l.Classes[i].Outcome, l.Classes[i].Stats, &l.Classes[i])
	}
	row("all calls", l.All, nil)
	fmt.Fprintf(&b, "\n%s\n\n(c) The append share is an estimate (gateway entries per call x durable per-entry median from (a)), not a measurement with the recorder switched off: the gateway fails closed without its recorder.\n", l.MatchNote)
	return b.String()
}
