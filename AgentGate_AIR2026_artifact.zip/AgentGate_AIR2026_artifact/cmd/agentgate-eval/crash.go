package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"agentgate/internal/auditverify"
	"agentgate/internal/devcomposition"
)

// The crash experiment (REVISION_CONTRACT R6.3) injects a failure at every
// lifecycle fault point (devcomposition.AllFaultPoints, plus a fault-free
// control) into one financial and one message operation, and then
//
//   - retries either with the same operation ID (an exact retry) or with a
//     fresh operation ID for identical content (a new operation), and
//   - does so either in the same gateway process ("none") or after a gateway
//     restart on the same operation journal ("journal"): the first gateway is
//     abandoned without any shutdown, as if its process had died, and a new
//     one (new per-run keys, empty memory) is built on the journal file.
//
// The provider is a provider host with its own key and state that survives
// the restart. For every operation the experiment records the statuses the
// agent saw, the provider's own journal of committed effects (duplicates),
// whether any REJECTED was answered while an effect exists, the operation's
// state after the retry and after an explicit Composition.Reconcile, which
// evidence folder accounts for each effect (EFFECT_EXECUTED or RECONCILED
// committed), and the verifier's verdict and assurance on every folder (with
// the keys fingerprint and final head pinned). A restart opens a second
// evidence folder (segment): the audit log cannot be reopened and the
// restarted gateway has new keys. The second segment's run.json and
// RUN_STARTED name the first one ("continues": run ID, relative folder, final
// head, keys fingerprint; internal/audit continuation.go), so verifying it
// follows the chain back and checks both segments as one run; segment 1 is
// also verified on its own.
//
// head_replace is emulated by the composition when the audit sink cannot
// write an entry without replacing the head (the harness sink cannot): the
// entry and head are written and the step is then treated as failed
// (internal/devcomposition/faults.go).

type crashOptions struct {
	outDir, workDir string
	escalation      devcomposition.Escalation
	points          []string
	repeat          int
}

const crashNone = "none"

func parseCrashFlags(args []string, stderr io.Writer) (crashOptions, error) {
	set := flag.NewFlagSet("crash", flag.ContinueOnError)
	set.SetOutput(stderr)
	out := set.String("out", "", "directory for crash.json, crash.csv and crash.md (required)")
	work := set.String("work", "", "directory for evidence folders and journals (default: a temporary directory)")
	escalation := set.String("escalation", "flag", "escalation mode of the gateway: flag or deny")
	points := set.String("points", "all", "comma-separated fault points, or all ("+crashNone+" is the fault-free control)")
	repeat := set.Int("repeat", 1, "repetitions of the whole schedule matrix")
	if err := set.Parse(args); err != nil {
		return crashOptions{}, err
	}
	if set.NArg() != 0 {
		return crashOptions{}, fmt.Errorf("unexpected arguments: %v", set.Args())
	}
	options := crashOptions{outDir: *out, workDir: *work, repeat: *repeat}
	if options.outDir == "" {
		return crashOptions{}, errors.New("-out is required")
	}
	if options.repeat < 1 {
		return crashOptions{}, errors.New("-repeat must be at least 1")
	}
	mode, err := parseAutonomousEscalation(*escalation)
	if err != nil {
		return crashOptions{}, err
	}
	options.escalation = mode
	if options.points, err = parseFaultPoints(*points); err != nil {
		return crashOptions{}, err
	}
	return options, nil
}

func parseAutonomousEscalation(text string) (devcomposition.Escalation, error) {
	switch devcomposition.Escalation(text) {
	case devcomposition.EscalationFlag, devcomposition.EscalationDeny:
		return devcomposition.Escalation(text), nil
	}
	return "", fmt.Errorf("-escalation must be flag or deny (human mode needs a reviewer), not %q", text)
}

// parseFaultPoints accepts "all" or a comma-separated subset of none and the
// fault points; the result keeps lifecycle order.
func parseFaultPoints(text string) ([]string, error) {
	known := append([]string{crashNone}, faultPointNames()...)
	if strings.TrimSpace(text) == "all" {
		return known, nil
	}
	wanted := map[string]bool{}
	for _, part := range strings.Split(text, ",") {
		name := strings.TrimSpace(part)
		if name == "" {
			continue
		}
		found := false
		for _, point := range known {
			found = found || point == name
		}
		if !found {
			return nil, fmt.Errorf("unknown fault point %q (known: %s)", name, strings.Join(known, ", "))
		}
		if wanted[name] {
			return nil, fmt.Errorf("fault point %q listed twice", name)
		}
		wanted[name] = true
	}
	var out []string
	for _, point := range known {
		if wanted[point] {
			out = append(out, point)
		}
	}
	if len(out) == 0 {
		return nil, errors.New("no fault point selected")
	}
	return out, nil
}

func faultPointNames() []string {
	var names []string
	for _, point := range devcomposition.AllFaultPoints() {
		names = append(names, string(point))
	}
	return names
}

// crashCell is one operation of one schedule.
type crashCell struct {
	Point            string     `json:"fault_point"`
	Retry            string     `json:"retry"`   // same-id | fresh-id
	Restart          string     `json:"restart"` // none | journal
	Effect           string     `json:"effect"`  // financial | message
	Repeat           int        `json:"repeat"`
	OperationID      string     `json:"operation_id"`
	FreshOperationID string     `json:"fresh_operation_id,omitempty"`
	FaultFired       bool       `json:"fault_fired"`
	First            callResult `json:"first_call"`
	RetryCall        callResult `json:"retry_call"`

	EffectsOriginal  int  `json:"provider_effects_original_id"`
	EffectsFresh     int  `json:"provider_effects_fresh_id"`
	EffectsContent   int  `json:"provider_effects_for_content"`
	DuplicatePerID   bool `json:"duplicate_effect_per_operation_id"`
	BusinessDup      bool `json:"business_duplicate"`
	RejectedEffect   bool `json:"rejected_while_effect_exists"`
	CommittedNoEffct bool `json:"committed_without_effect"`

	StateAfterRetry     string `json:"original_state_after_retry"`
	StateAfterReconcile string `json:"original_state_after_reconcile"`
	UnresolvedRetry     bool   `json:"unresolved_after_retry"`
	UnresolvedReconcile bool   `json:"unresolved_after_reconcile"`

	EvidencedIn []string            `json:"effect_evidenced_in"`
	EvidenceGap bool                `json:"evidence_gap"`
	Stages      map[string][]string `json:"stages_by_segment"`
	Note        string              `json:"note,omitempty"`
}

type crashSchedule struct {
	Label       string          `json:"label"`
	Point       string          `json:"fault_point"`
	Retry       string          `json:"retry"`
	Restart     string          `json:"restart"`
	Repeat      int             `json:"repeat"`
	FaultsFired []string        `json:"faults_fired"`
	Commits     int             `json:"provider_commits"`
	Segments    []verifyOutcome `json:"evidence_segments"`
	Cells       []crashCell     `json:"operations"`
	Error       string          `json:"error,omitempty"`
	ElapsedMS   float64         `json:"elapsed_ms"`
}

type crashTotals struct {
	Operations             int `json:"operations"`
	DuplicatePerID         int `json:"duplicate_effects_per_operation_id"`
	BusinessDuplicates     int `json:"business_duplicates"`
	RejectedWithEffect     int `json:"rejected_while_effect_exists"`
	CommittedWithoutEffect int `json:"committed_without_effect"`
	UnresolvedAfterRetry   int `json:"unresolved_after_retry"`
	UnresolvedAfterRecon   int `json:"unresolved_after_reconcile"`
	EvidenceGaps           int `json:"evidence_gaps"`
	SegmentsVerified       int `json:"segments_verified"`
	SegmentsFailed         int `json:"segments_failed"`
	SegmentsAnchored       int `json:"segments_anchored"`
	// SegmentsWithMissing keeps its old meaning: evidence folders whose
	// report lists at least one Missing entry of any kind. Since the verifier
	// reports head freshness (2026-10-10), every folder verified with pinned
	// keys and head lists the freshness gap, so this count equals the number
	// of folders; read SegmentsMissingByKind instead.
	SegmentsWithMissing int `json:"segments_with_missing_items"`
	// SegmentsMissingByKind counts, per Missing kind (auditverify.MissingKinds:
	// unresolved, freshness, issuer_only, other), the folders whose report
	// lists at least one entry of that kind.
	SegmentsMissingByKind map[string]int `json:"segments_with_missing_items_by_kind"`
	ScheduleErrors        int            `json:"schedule_errors"`
}

type crashResult struct {
	Note        string          `json:"note"`
	Method      []string        `json:"method"`
	Environment environment     `json:"environment"`
	Escalation  string          `json:"escalation"`
	Totals      crashTotals     `json:"totals"`
	Schedules   []crashSchedule `json:"schedules"`
}

func runCrash(args []string, stdout io.Writer) error {
	options, err := parseCrashFlags(args, stdout)
	if err != nil {
		return err
	}
	outDir, workDir, err := prepareDirs(options.outDir, options.workDir, "crash")
	if err != nil {
		return err
	}
	ctx, stop := interruptible()
	defer stop()
	w, err := newWorld()
	if err != nil {
		return err
	}
	result := crashResult{
		Note: "Local fault-injection runs of one gateway build on one machine. Statuses, provider effects and verifier verdicts are " +
			"observations of these schedules only; they are not a proof of crash safety for other schedules.",
		Method: []string{
			"Provider: in-process provider host with its own Ed25519 key and simulator state, reached over loopback HTTP by the gateway's adapter transport (Config.ExternalProvider); it survives gateway restarts.",
			"Faults: devcomposition.FaultPlan armed once per (point, operation) before the first call; head_replace is emulated (entry and head written, step treated as failed) because the harness sink has no head-less write.",
			"Restart: the first gateway is abandoned without shutdown; a new composition (new per-run keys, empty memory) is built on the same operation journal and the same provider; a second evidence folder is opened because the audit log cannot be reopened. It continues the first: run.json and RUN_STARTED carry \"continues\" (previous run ID, relative folder, final head and keys fingerprint as the harness pinned them), so the verifier checks segment 2 together with segment 1.",
			"Retry: same-id repeats the identical tools/call; fresh-id sends identical content with a new operation ID.",
			"After the retry: Composition.Reconcile is called once, then every evidence folder is closed and verified with the keys fingerprint and final head pinned.",
		},
		Environment: currentEnvironment(append([]string{"crash"}, args...)), Escalation: string(options.escalation),
	}
	for repeat := 1; repeat <= options.repeat; repeat++ {
		for _, point := range options.points {
			for _, retry := range []string{"same-id", "fresh-id"} {
				for _, restart := range []string{"none", "journal"} {
					if ctx.Err() != nil {
						return ctx.Err()
					}
					schedule := runCrashSchedule(ctx, w, workDir, options.escalation, point, retry, restart, repeat)
					fmt.Fprintf(stdout, "crash %-27s %-8s restart=%-7s r%d: %s\n", point, retry, restart, repeat, scheduleLine(schedule))
					result.Schedules = append(result.Schedules, schedule)
				}
			}
		}
	}
	result.Totals = crashTotalsOf(result.Schedules)
	if err := writeJSON(filepath.Join(outDir, "crash.json"), result); err != nil {
		return err
	}
	if err := writeText(filepath.Join(outDir, "crash.csv"), crashCSV(result.Schedules)); err != nil {
		return err
	}
	if err := writeText(filepath.Join(outDir, "crash.md"), crashMarkdown(result)); err != nil {
		return err
	}
	fmt.Fprintf(stdout, "crash: %d schedules, %d operations; results in %s\n", len(result.Schedules), result.Totals.Operations, displayPath(outDir))
	return nil
}

func scheduleLine(schedule crashSchedule) string {
	if schedule.Error != "" {
		return "ERROR " + schedule.Error
	}
	parts := []string{}
	for _, cell := range schedule.Cells {
		parts = append(parts, fmt.Sprintf("%s %s -> %s (effects %d+%d)", cell.Effect, cell.First.statusKey(), cell.RetryCall.statusKey(), cell.EffectsOriginal, cell.EffectsFresh))
	}
	verdicts := []string{}
	for _, segment := range schedule.Segments {
		verdicts = append(verdicts, segment.Assurance)
	}
	return strings.Join(parts, "; ") + "; evidence " + strings.Join(verdicts, "/")
}

// crashOperation is one operation of a schedule while it runs.
type crashOperation struct {
	effect  string
	tool    string
	id      [16]byte
	fresh   [16]byte
	args    func(id [16]byte) map[string]any
	first   callResult
	retried callResult
}

func runCrashSchedule(ctx context.Context, w *world, workDir string, escalation devcomposition.Escalation, point, retry, restart string, repeat int) (schedule crashSchedule) {
	began := hrTicks()
	label := fmt.Sprintf("crash-%s-%s-%s-r%d", strings.ReplaceAll(point, "_", "-"), retry, restart, repeat)
	schedule = crashSchedule{Label: label, Point: point, Retry: retry, Restart: restart, Repeat: repeat, FaultsFired: []string{}, Segments: []verifyOutcome{}}
	defer func() { schedule.ElapsedMS = round(ms(hrElapsed(began, hrTicks())), 2) }()
	fail := func(err error) crashSchedule {
		schedule.Error = err.Error()
		return schedule
	}
	dir := filepath.Join(workDir, label)
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return fail(err)
	}
	run, err := newRunIdentity(label)
	if err != nil {
		return fail(err)
	}
	provider, err := startProviderHost(w, run, nil)
	if err != nil {
		return fail(err)
	}
	defer provider.close()
	grant, err := signGrant(label, w.openGrant(time.Now()))
	if err != nil {
		return fail(err)
	}
	operations := []*crashOperation{
		{effect: "financial", tool: toolPayment, id: newOperationID(), args: func(id [16]byte) map[string]any {
			return paymentArgs(id, "payee.office-supplies", 40_000, "AED", "Courier charges (crash schedule)")
		}},
		{effect: "message", tool: toolMessage, id: newOperationID(), args: func(id [16]byte) map[string]any {
			return messageArgs(id, []string{"ops.lead"}, "Dock schedule", "Dock 3 is reserved for the Thursday pickup.")
		}},
	}
	plan := devcomposition.NewFaultPlan()
	if point != crashNone {
		for _, operation := range operations {
			plan.Arm(devcomposition.FaultPoint(point), operation.id)
		}
	}
	journal := filepath.Join(dir, "operations.jsonl")
	segments := []*evidenceRun{}
	segmentNames := []string{}
	openSegment := func(faults devcomposition.FaultInjector) (*gateway, error) {
		name := fmt.Sprintf("segment-%d", len(segments)+1)
		evidence, err := newEvidenceRun(filepath.Join(dir, name), label+"-"+name)
		if err != nil {
			return nil, err
		}
		if len(segments) > 0 {
			// A restart: the new segment names the closed one it continues
			// (run.json and RUN_STARTED "continues"), so the verifier
			// follows the chain back instead of judging restored
			// operations without their history.
			if err := evidence.continueFrom(segments[len(segments)-1]); err != nil {
				_ = evidence.finish(nil)
				return nil, err
			}
		}
		g, err := buildGateway(ctx, w, run, provider, gatewaySpec{Escalation: escalation, Faults: faults, Journal: journal, Sink: evidence, Grant: grant})
		if err != nil {
			_ = evidence.finish(nil)
			return nil, err
		}
		if err := evidence.begin(w, g, grant, "crash schedule "+label+", "+name); err != nil {
			return nil, err
		}
		segments, segmentNames = append(segments, evidence), append(segmentNames, name)
		return g, nil
	}
	closeSegments := func() {
		for _, segment := range segments {
			_ = segment.finish(provider)
		}
	}
	g, err := openSegment(plan)
	if err != nil {
		return fail(err)
	}
	caller := g.caller()
	for _, operation := range operations {
		operation.first = caller.call(ctx, operation.tool, operation.args(operation.id))
	}
	if restart == "journal" {
		// The first gateway's process "dies": its evidence folder ends here.
		if err := segments[0].finish(provider); err != nil {
			closeSegments()
			return fail(fmt.Errorf("close segment 1: %w", err))
		}
		if g, err = openSegment(nil); err != nil {
			closeSegments()
			return fail(fmt.Errorf("restart on the journal: %w", err))
		}
		caller = g.caller()
	}
	for _, operation := range operations {
		target := operation.id
		if retry == "fresh-id" {
			operation.fresh = newOperationID()
			target = operation.fresh
		}
		operation.retried = caller.call(ctx, operation.tool, operation.args(target))
	}
	afterRetry := g.operationStates()
	_, reconcileErr := g.comp.Reconcile(ctx)
	afterReconcile := g.operationStates()
	closeSegments()
	for _, fired := range plan.Fired() {
		schedule.FaultsFired = append(schedule.FaultsFired, string(fired.Point)+"@"+opText(fired.OperationID))
	}
	commits, err := provider.commits()
	if err != nil {
		return fail(err)
	}
	schedule.Commits = len(commits)
	perOperation := commitsByOperation(commits)
	for _, segment := range segments {
		schedule.Segments = append(schedule.Segments, verifyPinned(segment))
	}
	fired := map[string]bool{}
	for _, item := range plan.Fired() {
		fired[opText(item.OperationID)] = true
	}
	for _, operation := range operations {
		original, fresh := opText(operation.id), opText(operation.fresh)
		cell := crashCell{
			Point: point, Retry: retry, Restart: restart, Effect: operation.effect, Repeat: repeat,
			OperationID: original, FreshOperationID: fresh, FaultFired: fired[original],
			First: operation.first, RetryCall: operation.retried,
			EffectsOriginal: perOperation[original], Stages: map[string][]string{}, EvidencedIn: []string{},
		}
		if fresh != "" {
			cell.EffectsFresh = perOperation[fresh]
		}
		cell.EffectsContent = cell.EffectsOriginal + cell.EffectsFresh
		cell.DuplicatePerID = cell.EffectsOriginal > 1 || cell.EffectsFresh > 1
		cell.BusinessDup = cell.EffectsContent > 1
		retriedID := original
		if fresh != "" {
			retriedID = fresh
		}
		answers := []struct {
			id     string
			answer callResult
		}{{original, operation.first}, {retriedID, operation.retried}}
		for _, item := range answers {
			if item.answer.Status == string(devcomposition.StatusRejected) && perOperation[item.id] > 0 {
				cell.RejectedEffect = true
			}
			if item.answer.Status == string(devcomposition.StatusCommitted) && perOperation[item.id] == 0 {
				cell.CommittedNoEffct = true
			}
		}
		cell.StateAfterRetry = stateText(afterRetry[original])
		cell.StateAfterReconcile = stateText(afterReconcile[original])
		cell.UnresolvedRetry = unresolved(afterRetry[original])
		cell.UnresolvedReconcile = unresolved(afterReconcile[original])
		for index, segment := range segments {
			stages := segment.stagesFor(original)
			if fresh != "" {
				stages = append(stages, prefixAll("fresh:", segment.stagesFor(fresh))...)
			}
			cell.Stages[segmentNames[index]] = stages
		}
		for _, id := range []string{original, fresh} {
			if id == "" || perOperation[id] == 0 {
				continue
			}
			evidenced := false
			for index, segment := range segments {
				if segment.evidencesEffect(id) {
					evidenced = true
					cell.EvidencedIn = append(cell.EvidencedIn, segmentNames[index]+map[bool]string{true: "(fresh)", false: ""}[id == fresh])
				}
			}
			if !evidenced {
				cell.EvidenceGap = true
			}
		}
		notes := []string{}
		if point == string(devcomposition.FaultHeadReplace) {
			notes = append(notes, "head_replace emulated by the composition (entry and head written)")
		}
		if reconcileErr != nil {
			notes = append(notes, "Reconcile: "+reconcileErr.Error())
		}
		cell.Note = strings.Join(notes, "; ")
		schedule.Cells = append(schedule.Cells, cell)
	}
	return schedule
}

func prefixAll(prefix string, values []string) []string {
	out := make([]string, len(values))
	for index, value := range values {
		out[index] = prefix + value
	}
	return out
}

func stateText(state devcomposition.OperationState) string {
	if state.OperationID == [16]byte{} {
		return "unknown"
	}
	status := string(state.Status)
	if status == "" {
		status = "UNDECIDED"
	}
	if state.Reason != "" {
		status += "/" + state.Reason
	}
	return status
}

func unresolved(state devcomposition.OperationState) bool {
	return state.Status == devcomposition.StatusUncertain || state.Status == devcomposition.StatusReconciliationRequired
}

func crashTotalsOf(schedules []crashSchedule) crashTotals {
	totals := crashTotals{SegmentsMissingByKind: missingByKind(nil)}
	for _, schedule := range schedules {
		if schedule.Error != "" {
			totals.ScheduleErrors++
		}
		for _, segment := range schedule.Segments {
			totals.SegmentsWithMissing += b2i(len(segment.Missing) > 0)
			for kind, count := range segment.MissingByKind {
				totals.SegmentsMissingByKind[kind] += b2i(count > 0)
			}
			switch {
			case segment.Verdict == auditverify.VerdictVerified && segment.Assurance == auditverify.AssuranceAnchored:
				totals.SegmentsVerified++
				totals.SegmentsAnchored++
			case segment.Verdict == auditverify.VerdictVerified:
				totals.SegmentsVerified++
			default:
				totals.SegmentsFailed++
			}
		}
		for _, cell := range schedule.Cells {
			totals.Operations++
			totals.DuplicatePerID += b2i(cell.DuplicatePerID)
			totals.BusinessDuplicates += b2i(cell.BusinessDup)
			totals.RejectedWithEffect += b2i(cell.RejectedEffect)
			totals.CommittedWithoutEffect += b2i(cell.CommittedNoEffct)
			totals.UnresolvedAfterRetry += b2i(cell.UnresolvedRetry)
			totals.UnresolvedAfterRecon += b2i(cell.UnresolvedReconcile)
			totals.EvidenceGaps += b2i(cell.EvidenceGap)
		}
	}
	return totals
}

func b2i(value bool) int {
	if value {
		return 1
	}
	return 0
}

func segmentField(schedule crashSchedule, index int, field func(verifyOutcome) string) string {
	if index >= len(schedule.Segments) {
		return ""
	}
	return field(schedule.Segments[index])
}

func crashCSV(schedules []crashSchedule) string {
	var b strings.Builder
	b.WriteString(csvLine("fault_point", "retry", "restart", "effect", "repeat", "operation_id", "fresh_operation_id", "fault_fired",
		"first_status", "first_reason", "first_dispatched", "retry_status", "retry_reason", "retry_dispatched",
		"effects_original_id", "effects_fresh_id", "effects_for_content", "duplicate_per_operation_id", "business_duplicate",
		"rejected_while_effect_exists", "committed_without_effect", "original_state_after_retry", "original_state_after_reconcile",
		"unresolved_after_retry", "unresolved_after_reconcile", "effect_evidenced_in", "evidence_gap",
		"segment1_verdict", "segment1_assurance", "segment1_failing_checks", "segment2_verdict", "segment2_assurance", "segment2_failing_checks",
		"schedule_error", "note", "segment1_missing_kinds", "segment2_missing_kinds"))
	verdict := func(v verifyOutcome) string { return v.Verdict }
	assurance := func(v verifyOutcome) string { return v.Assurance }
	failing := func(v verifyOutcome) string { return strings.Join(v.Failing, " ") }
	missingKinds := func(v verifyOutcome) string { return missingKindsText(v.MissingByKind) }
	for _, schedule := range schedules {
		if len(schedule.Cells) == 0 {
			b.WriteString(csvLine(schedule.Point, schedule.Retry, schedule.Restart, "", fmt.Sprint(schedule.Repeat), "", "", "",
				"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", schedule.Error, "", "", ""))
			continue
		}
		for _, cell := range schedule.Cells {
			b.WriteString(csvLine(cell.Point, cell.Retry, cell.Restart, cell.Effect, fmt.Sprint(cell.Repeat), cell.OperationID, cell.FreshOperationID, boolText(cell.FaultFired),
				cell.First.Status, cell.First.Reason, boolText(cell.First.Dispatched), cell.RetryCall.Status, cell.RetryCall.Reason, boolText(cell.RetryCall.Dispatched),
				fmt.Sprint(cell.EffectsOriginal), fmt.Sprint(cell.EffectsFresh), fmt.Sprint(cell.EffectsContent), boolText(cell.DuplicatePerID), boolText(cell.BusinessDup),
				boolText(cell.RejectedEffect), boolText(cell.CommittedNoEffct), cell.StateAfterRetry, cell.StateAfterReconcile,
				boolText(cell.UnresolvedRetry), boolText(cell.UnresolvedReconcile), strings.Join(cell.EvidencedIn, " "), boolText(cell.EvidenceGap),
				segmentField(schedule, 0, verdict), segmentField(schedule, 0, assurance), segmentField(schedule, 0, failing),
				segmentField(schedule, 1, verdict), segmentField(schedule, 1, assurance), segmentField(schedule, 1, failing),
				schedule.Error, cell.Note, segmentField(schedule, 0, missingKinds), segmentField(schedule, 1, missingKinds)))
		}
	}
	return b.String()
}

func crashMarkdown(result crashResult) string {
	var b strings.Builder
	t := result.Totals
	fmt.Fprintf(&b, "# Crash and response-loss schedules\n\n%s\n\n", result.Note)
	fmt.Fprintf(&b, "Command: `%s`  \nEscalation mode: %s. Go %s on %s/%s, %d CPUs.\n\n", result.Environment.Command, result.Escalation,
		result.Environment.GoVersion, result.Environment.GOOS, result.Environment.GOARCH, result.Environment.NumCPU)
	b.WriteString("## Method\n\n")
	for _, line := range result.Method {
		fmt.Fprintf(&b, "- %s\n", line)
	}
	b.WriteString("\n## Totals\n\n| measure | count |\n|---|---|\n")
	rows := []struct {
		name  string
		value int
	}{
		{"operations (schedules x 2)", t.Operations},
		{"more than one provider effect for one operation ID", t.DuplicatePerID},
		{"identical content committed twice (fresh-ID retries; one effect per operation ID, not per intent)", t.BusinessDuplicates},
		{"REJECTED answered while the provider holds an effect for that operation ID", t.RejectedWithEffect},
		{"COMMITTED answered while the provider holds no effect for that operation ID", t.CommittedWithoutEffect},
		{"original operation still UNCERTAIN / RECONCILIATION_REQUIRED after the retry", t.UnresolvedAfterRetry},
		{"... and after an explicit Composition.Reconcile", t.UnresolvedAfterRecon},
		{"provider effect not accounted for by EFFECT_EXECUTED or RECONCILED(committed) in any evidence folder", t.EvidenceGaps},
		{"evidence folders verified (VERIFIED)", t.SegmentsVerified},
		{"... of which ANCHORED", t.SegmentsAnchored},
		{"evidence folders FAILED", t.SegmentsFailed},
		{"evidence folders whose report lists any missing item (every pinned folder lists the head-freshness gap)", t.SegmentsWithMissing},
		{"... listing an operation left UNCERTAIN / RECONCILIATION_REQUIRED", t.SegmentsMissingByKind[auditverify.MissingKindUnresolved]},
		{"... listing the head-freshness gap (pinned head, not the witness's fresh status)", t.SegmentsMissingByKind[auditverify.MissingKindFreshness]},
		{"... listing an executed operation classified on the issuer key alone (RECONCILED without an adapter receipt)", t.SegmentsMissingByKind[auditverify.MissingKindIssuerOnly]},
		{"... listing another gap", t.SegmentsMissingByKind[auditverify.MissingKindOther]},
		{"schedules that could not run", t.ScheduleErrors},
	}
	for _, row := range rows {
		fmt.Fprintf(&b, "| %s | %d |\n", row.name, row.value)
	}
	b.WriteString("\n## Per operation\n\nStatuses are `STATUS/reason`. Effects: provider commits for the original / fresh operation ID. " +
		"Folders: assurance of each evidence folder (segment 2 exists only after a restart), failing checks in parentheses, and the kinds of " +
		"items the verifier lists as missing in brackets (unresolved, freshness, issuer_only, other).\n\n")
	b.WriteString("| fault point | retry | restart | effect | first answer | retry answer | effects | REJECTED with effect | state after retry -> after Reconcile | evidence of the effect | folders |\n|---|---|---|---|---|---|---|---|---|---|---|\n")
	for _, schedule := range result.Schedules {
		if schedule.Error != "" {
			fmt.Fprintf(&b, "| %s | %s | %s | - | error: %s | | | | | | |\n", schedule.Point, schedule.Retry, schedule.Restart, schedule.Error)
			continue
		}
		folders := []string{}
		for _, segment := range schedule.Segments {
			text := segment.Assurance
			if len(segment.Failing) > 0 {
				text += " (" + strings.Join(segment.Failing, ", ") + ")"
			}
			if kinds := missingKindsText(segment.MissingByKind); kinds != "" {
				text += " [missing: " + kinds + "]"
			} else if len(segment.Missing) > 0 {
				text += fmt.Sprintf(" [%d missing]", len(segment.Missing))
			}
			folders = append(folders, text)
		}
		for _, cell := range schedule.Cells {
			evidence := strings.Join(cell.EvidencedIn, ", ")
			if cell.EffectsContent == 0 {
				evidence = "no effect"
			} else if cell.EvidenceGap {
				evidence = "GAP " + evidence
			}
			fmt.Fprintf(&b, "| %s | %s | %s | %s | %s | %s | %d / %d | %s | %s -> %s | %s | %s |\n",
				cell.Point, cell.Retry, cell.Restart, cell.Effect, cell.First.statusKey(), cell.RetryCall.statusKey(),
				cell.EffectsOriginal, cell.EffectsFresh, boolText(cell.RejectedEffect), cell.StateAfterRetry, cell.StateAfterReconcile,
				evidence, strings.Join(folders, "; "))
		}
	}
	failing := map[string]int{}
	for _, schedule := range result.Schedules {
		for _, segment := range schedule.Segments {
			for _, id := range segment.Failing {
				failing[id]++
			}
		}
	}
	if len(failing) > 0 {
		keys := make([]string, 0, len(failing))
		for id := range failing {
			keys = append(keys, id)
		}
		sort.Strings(keys)
		b.WriteString("\n## Failing verifier checks over all folders\n\n| check | folders |\n|---|---|\n")
		for _, id := range keys {
			fmt.Fprintf(&b, "| %s | %d |\n", id, failing[id])
		}
	}
	return b.String()
}
