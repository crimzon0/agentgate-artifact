package main

import (
	"bytes"
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"

	"agentgate/internal/audit"
	"agentgate/internal/auditverify"
	"agentgate/internal/demo"
	"agentgate/internal/devcomposition"
	"agentgate/internal/headwitness"
)

// The custody experiment (REVISION_CONTRACT R6.6) runs the demo with the
// provider and the head witness as separate processes (cmd/agentgate-provider,
// cmd/agentgate-witness), each with its own key and its own directory:
//
//  1. a complete demo self-test with the operation journal, the provider
//     process and the witness (demo.RunSelfTest). The self-test itself kills
//     the witness during one action (outage: the gateway keeps running and
//     records WITNESS_UNAVAILABLE), restarts it on its own directory and
//     checks that it catches up; it also restarts the gateway on its journal
//     with a restarted provider process. Its revision checks are recorded.
//  2. after the run, the provider process and the witness are restarted on
//     their own directories (keys and stores must survive) and queried: the
//     provider's journal of commits and key, the witness's latest cosigned
//     head and its history. The witness is restarted with the gateway's
//     enrollment public key (the demo's custody folder) and queried through
//     a client pinned to the witness key saved with the run. Then the
//     registrations of a party without the enrollment private key are sent
//     to it (enrollment probes: a new run ID unsigned and with a forged
//     signature, the run's own ID with other keys, and a false continuation
//     of the newest segment unsigned and forged); each must be refused with
//     the witness's "enrollment" error and leave no trace. The probes sign
//     nothing: a forged signature is random bytes.
//  3. evidence variants are verified under every anchor condition, while the
//     restarted witness keeps running:
//     variants: the continuation segment the gateway restarted into (the
//     newest folder; the verifier follows it to the first one: the whole
//     run); the first run folder presented alone (the segment withheld, an
//     omission; without a restart segment it is the whole run, "closed run
//     folder", and clean); a coherent rollback copy of the first folder (log
//     cut to an earlier checkpoint with the head.json and provider journal
//     genuinely on disk then; auditverify.TamperRollback); and each of these
//     with provider-journal.json replaced by the journal the restarted
//     provider process serves (what a verifier sees when it takes the
//     provider's record from the provider's custody instead of from the
//     folder).
//     anchors: none; keys pinned; head pinned; both pinned (the first run's
//     values the demo process held; the segment's taken from its genuine
//     folder after the run); the saved latest cosigned head (a file: no run
//     status); the witness's latest cosigned head and run status fetched
//     live from the running witness when the cell is verified (what
//     agentgate-verify --witness-url does; it fails head.anchor when the
//     witness records that a later segment continued the presented run); an
//     earlier cosigned head from the witness history (a stale anchor); for
//     the withheld segment also the run's real final head (the segment's).

type custodyOptions struct {
	outDir, workDir         string
	providerExe, witnessExe string
	escalation              devcomposition.Escalation
}

func parseCustodyFlags(args []string, stderr io.Writer) (custodyOptions, error) {
	set := flag.NewFlagSet("custody", flag.ContinueOnError)
	set.SetOutput(stderr)
	out := set.String("out", "", "directory for custody.json, custody.csv and custody.md (required)")
	work := set.String("work", "", "directory for the run, the custody processes' state and copies (default: a temporary directory)")
	provider := set.String("provider-exe", "", "built cmd/agentgate-provider (default: the one next to this program, else built into the work directory with the Go toolchain)")
	witness := set.String("witness-exe", "", "built cmd/agentgate-witness (default: the one next to this program, else built into the work directory with the Go toolchain)")
	escalation := set.String("escalation", "flag", "escalation mode of the demo run: flag or deny")
	if err := set.Parse(args); err != nil {
		return custodyOptions{}, err
	}
	if set.NArg() != 0 {
		return custodyOptions{}, fmt.Errorf("unexpected arguments: %v", set.Args())
	}
	options := custodyOptions{outDir: *out, workDir: *work, providerExe: *provider, witnessExe: *witness}
	if options.outDir == "" {
		return custodyOptions{}, errors.New("-out is required")
	}
	mode, err := parseAutonomousEscalation(*escalation)
	if err != nil {
		return custodyOptions{}, err
	}
	options.escalation = mode
	return options, nil
}

// besideSelf returns the named command's executable next to this program
// (scripts/demo.ps1 and a plain "go build -o DIR ./cmd/..." put them in one
// folder), or "" when it is not there.
func besideSelf(name string) string {
	self, err := os.Executable()
	if err != nil {
		return ""
	}
	if runtime.GOOS == "windows" {
		name += ".exe"
	}
	candidate := filepath.Join(filepath.Dir(self), name)
	if info, err := os.Stat(candidate); err == nil && !info.IsDir() {
		return candidate
	}
	return ""
}

// buildCommand compiles one of this module's commands with the Go toolchain
// that built this program (it needs the AgentGate source in or above the
// working directory).
func buildCommand(dir, name string) (string, error) {
	executable := filepath.Join(dir, name)
	if runtime.GOOS == "windows" {
		executable += ".exe"
	}
	goTool, err := goToolFrom(runtime.GOROOT(), exec.LookPath)
	if err != nil {
		return "", fmt.Errorf("build %s (pass -%s-exe to use a built binary): %v", name, strings.TrimPrefix(name, "agentgate-"), err)
	}
	command := exec.Command(goTool, "build", "-o", executable, "agentgate/cmd/"+name)
	if output, err := command.CombinedOutput(); err != nil {
		return "", fmt.Errorf("build %s (pass -%s-exe to use a built binary): %v\n%s", name, strings.TrimPrefix(name, "agentgate-"), err, output)
	}
	return executable, nil
}

// goToolFrom returns the go command under goroot (runtime.GOROOT(): the
// GOROOT environment variable, else the Go installation that built this
// program). A program built with -trimpath (the frozen reproducible build)
// records no installation, so goroot is empty; then the go command on PATH
// is used, and without one there is no toolchain to build with.
func goToolFrom(goroot string, lookPath func(string) (string, error)) (string, error) {
	if goroot != "" {
		tool := filepath.Join(goroot, "bin", "go")
		if runtime.GOOS == "windows" {
			tool += ".exe"
		}
		return tool, nil
	}
	tool, err := lookPath("go")
	if err != nil {
		return "", fmt.Errorf("this program records no Go installation (built with -trimpath), GOROOT is not set and no go command is on PATH (%v)", err)
	}
	return tool, nil
}

type custodyCheck struct {
	ID     string   `json:"id"`
	Title  string   `json:"title"`
	Passed bool     `json:"passed"`
	Detail string   `json:"detail"`
	Issues []string `json:"problems,omitempty"`
}

type custodyCell struct {
	Variant   string        `json:"variant"`
	Anchors   string        `json:"anchors"`
	Tampered  bool          `json:"tampered"`
	Outcome   verifyOutcome `json:"verification"`
	Detected  bool          `json:"detected"`    // tampered variant FAILED
	Accepted  bool          `json:"accepted"`    // VERIFIED
	Anchored  bool          `json:"anchored"`    // ANCHORED
	FalseFail bool          `json:"false_alarm"` // untampered variant FAILED
}

type custodyFacts struct {
	RunID                string `json:"run_id"`
	RunDir               string `json:"run_dir"`
	KeysSHA256           string `json:"keys_sha256_pinned"`
	FinalHeadSeq         uint64 `json:"final_head_seq"`
	FinalHeadHash        string `json:"final_head_hash_pinned"`
	WitnessUnavailable   int    `json:"witness_unavailable_entries"`
	WitnessLatestSeq     uint64 `json:"witness_latest_cosigned_seq"`
	WitnessHistory       int    `json:"witness_cosigned_heads"`
	WitnessKeyStable     bool   `json:"witness_key_same_after_restart"`
	WitnessLatestMatches bool   `json:"witness_latest_after_restart_equals_saved_anchor"`
	WitnessPID           int    `json:"witness_pid_after_restart,omitempty"`
	// WitnessContinuedBy is continued_by in the witness's run status of the
	// first run (GET /runs/{id}); ContinuedBySegment: it names the restart
	// segment.
	WitnessContinuedBy string `json:"witness_run_continued_by,omitempty"`
	ContinuedBySegment bool   `json:"witness_run_continued_by_segment"`
	// Enrollment: the gateway enrollment key of the custody folder, whether
	// the restarted witness's key equals the key the demo pinned for the
	// folder, the enrollment key ID in the witness's signed run status of the
	// first run, the probes of a party without the enrollment key and
	// whether they left the witness's state unchanged.
	EnrollmentKID       string            `json:"enrollment_kid,omitempty"`
	WitnessPinMatches   bool              `json:"witness_key_equals_pin"`
	StatusEnrollmentKID string            `json:"witness_run_status_enrollment_kid,omitempty"`
	EnrollmentProbes    []enrollmentProbe `json:"enrollment_probes"`
	ProbesLeftNoTrace   bool              `json:"enrollment_probes_left_no_trace"`
	// The continuation segment of the self-test's gateway restart, its pins
	// (taken from the genuine folder after the run) and the witness's
	// latest cosigned seq of it.
	SegmentRunID            string   `json:"segment_run_id,omitempty"`
	SegmentDir              string   `json:"segment_dir,omitempty"`
	SegmentKeysSHA256       string   `json:"segment_keys_sha256,omitempty"`
	SegmentHeadSeq          uint64   `json:"segment_head_seq,omitempty"`
	SegmentHeadHash         string   `json:"segment_head_hash,omitempty"`
	SegmentWitnessLatestSeq uint64   `json:"segment_witness_latest_seq,omitempty"`
	StaleWitnessSeq         uint64   `json:"stale_witness_seq,omitempty"`
	RollbackSeq             uint64   `json:"rollback_seq,omitempty"`
	ProviderKIDMatches      bool     `json:"provider_key_after_restart_equals_keys_json"`
	ProviderCommits         uint64   `json:"provider_commits_after_restart"`
	FolderCommits           uint64   `json:"run_folder_provider_journal_commits"`
	RollbackFolderCommits   uint64   `json:"rollback_folder_provider_journal_commits,omitempty"`
	Notes                   []string `json:"notes"`
}

type custodyResult struct {
	Note        string           `json:"note"`
	Method      []string         `json:"method"`
	Environment environment      `json:"environment"`
	SelfTest    string           `json:"selftest_summary"`
	Passed      bool             `json:"selftest_passed"`
	Checks      []custodyCheck   `json:"selftest_revision_checks"`
	Custody     demo.CustodyView `json:"custody_view"`
	Facts       custodyFacts     `json:"facts"`
	Cells       []custodyCell    `json:"verification_matrix"`
	Console     string           `json:"selftest_console"`
	ElapsedSecs float64          `json:"elapsed_s"`
}

func runCustody(args []string, stdout io.Writer) error {
	options, err := parseCustodyFlags(args, stdout)
	if err != nil {
		return err
	}
	outDir, workDir, err := prepareDirs(options.outDir, options.workDir, "custody")
	if err != nil {
		return err
	}
	ctx, stop := interruptible()
	defer stop()
	began := hrTicks()
	binDir := filepath.Join(workDir, "bin")
	if err := os.MkdirAll(binDir, 0o755); err != nil {
		return err
	}
	if options.providerExe == "" {
		options.providerExe = besideSelf("agentgate-provider")
	}
	if options.providerExe == "" {
		fmt.Fprintln(stdout, "custody: building cmd/agentgate-provider")
		if options.providerExe, err = buildCommand(binDir, "agentgate-provider"); err != nil {
			return err
		}
	}
	if options.witnessExe == "" {
		options.witnessExe = besideSelf("agentgate-witness")
	}
	if options.witnessExe == "" {
		fmt.Fprintln(stdout, "custody: building cmd/agentgate-witness")
		if options.witnessExe, err = buildCommand(binDir, "agentgate-witness"); err != nil {
			return err
		}
	}
	runsDir, custodyDir := filepath.Join(workDir, "runs"), filepath.Join(workDir, "custody")
	console := filepath.Join(workDir, "selftest-console.txt")
	logFile, err := os.Create(console)
	if err != nil {
		return err
	}
	fmt.Fprintln(stdout, "custody: running the demo self-test with the provider process, the witness and the operation journal")
	report, runErr := demo.RunSelfTest(ctx, demo.SelfTestOptions{
		RunsDir: runsDir, Repeat: 1, Out: logFile, Escalation: options.escalation, Durable: true,
		ProviderExecutable: options.providerExe, WitnessExecutable: options.witnessExe, CustodyDir: custodyDir, HostLabel: hostLabelOption,
		Logf: func(format string, args ...any) { fmt.Fprintf(logFile, "agentgate-demo: "+format+"\n", args...) },
	})
	logFile.Close()
	if runErr != nil {
		return fmt.Errorf("self-test: %w (console: %s)", runErr, displayPath(console))
	}
	result := custodyResult{
		Note: "One demo run on one machine with the provider and the witness as separate local processes (separate keys and directories, " +
			"same user account and disk). The witness registers only runs signed with the gateway's enrollment key, and the gateway pins the witness key; " +
			"both keys are files any process of the same user can read. It demonstrates the custody boundary of this prototype; it is not independent organisational custody.",
		Method: []string{
			"demo.RunSelfTest with Durable, ProviderExecutable, WitnessExecutable: every scenario, the witness outage (the self-test kills the witness, runs one action, restarts it), a gateway restart on the operation journal with a restarted provider process, and the tamper lab.",
			"After the run: the provider process and the witness are restarted on their own directories and queried over loopback HTTP (GET /key, GET /journal; GET /runs/{id}/latest, /heads and GET /runs/{id}, the run status with continued_by and enrollment_kid). The witness keeps running through the verification matrix.",
			"Witness enrollment: the witness is restarted with the gateway's enrollment public key from the demo's custody folder and read through a client pinned to the witness key saved with the run. Enrollment probes (a party without the enrollment private key; nothing is signed, a forged signature is random bytes): a new run ID unsigned and with a forged signature, the run's own ID with other keys, a false continuation of the newest segment unsigned and with a forged signature. Each must be refused with the witness's enrollment error and leave the witness's state unchanged; they run before the matrix.",
			"Variants: the restart segment (newest folder, verified with the first folder it continues: the whole run); the first folder presented alone (the restart segment withheld, counted as tampered); a coherent rollback of the first folder; each with the live provider journal.",
			"Rollback: auditverify.TamperRollback applied to a copy, restoring the earlier head.json and provider journal the tamper lab saved for this run.",
			"Live provider journal: the copy's provider-journal.json is replaced by the restarted provider process's GET /journal.",
			"Pinned values: the first run's are the ones the demo process held (keys fingerprint at startup, head after shutdown); the segment's are SHA-256 of its keys.json and its last entry hash, taken from the genuine folder after the run. Witness anchors: the saved latest cosigned head (a file, without the run status), and 'witness latest via --witness-url': the latest cosigned head and run status fetched from the running witness when the cell is verified, as agentgate-verify --witness-url does, verified in process. The witness key is the one saved outside the run folder.",
		},
		Environment: currentEnvironment(append([]string{"custody"}, args...)), SelfTest: report.Summary, Passed: report.Passed,
		Custody: report.Custody, Console: displayPath(console),
	}
	result.Custody.AnchorsDir = hideWorkDir(result.Custody.AnchorsDir)
	for _, check := range report.Revision {
		issues := make([]string, len(check.Problems))
		for index, problem := range check.Problems {
			issues[index] = hideWorkDir(problem)
		}
		result.Checks = append(result.Checks, custodyCheck{ID: check.ID, Title: check.Title, Passed: check.Passed, Detail: hideWorkDir(check.Detail), Issues: issues})
	}
	facts, cells, err := custodyVerifications(ctx, report, options, workDir, custodyDir)
	if err != nil {
		facts.Notes = append(facts.Notes, "error: "+hideWorkDir(err.Error()))
	}
	result.Facts, result.Cells = facts, cells
	result.ElapsedSecs = round(hrElapsed(began, hrTicks()).Seconds(), 1)
	if err := writeJSON(filepath.Join(outDir, "custody.json"), result); err != nil {
		return err
	}
	if err := writeText(filepath.Join(outDir, "custody.csv"), custodyCSV(cells)); err != nil {
		return err
	}
	if err := writeText(filepath.Join(outDir, "custody.md"), custodyMarkdown(result)); err != nil {
		return err
	}
	fmt.Fprintf(stdout, "custody: self-test %s; %d verifications; results in %s\n", map[bool]string{true: "passed", false: "FAILED"}[report.Passed], len(cells), displayPath(outDir))
	return nil
}

// custodyAnchor is one anchor condition of the verification matrix. live,
// when set, builds the options at verification time (the witness's latest
// head and run status fetched from the running witness process, as
// agentgate-verify --witness-url does).
type custodyAnchor struct {
	name    string
	options auditverify.Options
	live    func() (auditverify.Options, error)
}

// custodyVariant is one evidence variant: the folder presented to the
// verifier (the newest segment of what is shown) and its anchor conditions.
type custodyVariant struct {
	name     string
	dir      string
	tampered bool
	anchors  []custodyAnchor
}

// Variant names (shared with docs/paper/data/revision/custody/scripts/probe.py,
// which cross-checks the CLI against these cells by name).
const (
	variantClosedRun = "closed run folder"
	variantWithheld  = "continuation segment withheld (earlier folder presented as the whole run)"
	variantRollback  = "coherent rollback"
	variantSegment   = "continuation segment (newest folder; earlier folder followed)"
	liveJournalTag   = " + provider journal from the provider process"
	anchorLive       = "witness latest via --witness-url"
)

func custodyVerifications(ctx context.Context, report demo.SelfTestReport, options custodyOptions, workDir, custodyDir string) (custodyFacts, []custodyCell, error) {
	facts := custodyFacts{RunID: report.RunID, RunDir: displayPath(report.RunDir), KeysSHA256: report.KeysSHA256,
		FinalHeadHash: report.Verifier.AfterShutdownHeadHash, Notes: []string{}, EnrollmentProbes: []enrollmentProbe{}}
	entries, err := audit.ReadLog(report.RunDir)
	if err != nil {
		return facts, nil, err
	}
	if len(entries) > 0 {
		facts.FinalHeadSeq = entries[len(entries)-1].Entry.Seq
	}
	for _, entry := range entries {
		if entry.Entry.Stage == "WITNESS_UNAVAILABLE" {
			facts.WitnessUnavailable++
		}
	}
	facts.FolderCommits = journalCommitSeq(filepath.Join(report.RunDir, audit.ProviderJournalFile))

	// The continuation segment the gateway restarted into (the self-test's
	// restart check). Its pins are taken from the genuine folder now, before
	// any variant is made: the self-test report does not carry the values
	// the demo held for it.
	segmentDir := report.RestartSegmentDir
	if segmentDir != "" {
		facts.SegmentDir = displayPath(segmentDir)
		facts.SegmentRunID = filepath.Base(segmentDir)
		segmentEntries, err := audit.ReadLog(segmentDir)
		keys, keysErr := os.ReadFile(filepath.Join(segmentDir, audit.KeysFile))
		if err != nil || keysErr != nil || len(segmentEntries) == 0 {
			facts.Notes = append(facts.Notes, fmt.Sprintf("restart segment unreadable (%v %v); its variants are left out", err, keysErr))
			segmentDir = ""
		} else {
			last := segmentEntries[len(segmentEntries)-1]
			facts.SegmentRunID, facts.SegmentHeadSeq, facts.SegmentHeadHash = last.Entry.RunID, last.Entry.Seq, last.EntryHash
			facts.SegmentKeysSHA256 = sha256Hex(keys)
		}
	} else {
		facts.Notes = append(facts.Notes, "the self-test made no restart segment, so the closed run folder is the whole run and there is no withheld-segment case")
	}

	anchorsDir := filepath.Join(custodyDir, "anchors", report.RunID)
	witnessHead, headErr := os.ReadFile(filepath.Join(anchorsDir, demo.WitnessHeadFile))
	witnessKeyText, keyErr := os.ReadFile(filepath.Join(anchorsDir, demo.WitnessKeyFile))
	witnessKey, decodeErr := hex.DecodeString(strings.TrimSpace(string(witnessKeyText)))
	haveWitness := headErr == nil && keyErr == nil && decodeErr == nil && len(witnessKey) == 32
	if !haveWitness {
		facts.Notes = append(facts.Notes, fmt.Sprintf("saved witness anchors unavailable: %v %v %v", headErr, keyErr, decodeErr))
	}
	// The witness is restarted with the gateway's enrollment public key, as
	// the demo started it, and must still hold the key pinned for the
	// custody folder.
	enrollPublic, enrollErr := headwitness.EnrollmentPublicKey(demo.EnrollmentKeyPath(custodyDir))
	if enrollErr == nil {
		facts.EnrollmentKID = sha256Hex(enrollPublic)
	} else if haveWitness {
		facts.Notes = append(facts.Notes, "the gateway's enrollment key: "+hideWorkDir(enrollErr.Error()))
		haveWitness = false
	}
	if pinned, err := demo.PinnedWitnessKey(custodyDir); err == nil {
		facts.WitnessPinMatches = haveWitness && bytes.Equal(pinned, witnessKey)
	} else if haveWitness {
		facts.Notes = append(facts.Notes, "the pinned witness key: "+hideWorkDir(err.Error()))
	}
	var segmentSaved []byte
	if segmentDir != "" && report.RestartSegmentWitnessHead != "" {
		if segmentSaved, err = os.ReadFile(report.RestartSegmentWitnessHead); err != nil {
			facts.Notes = append(facts.Notes, "saved witness head of the segment: "+err.Error())
			segmentSaved = nil
		}
	}

	// Restart the witness on its own directory: key, latest head, history
	// and run status. It keeps running through the verification matrix, so
	// the live anchor is fetched when each cell is verified.
	var stale []byte
	var liveOrigin string
	earlier, rollbackSeq, haveRollback := earlierCheckpoint(report)
	if haveWitness {
		witness, err := headwitness.StartProcess(ctx, headwitness.LaunchConfig{Executable: options.witnessExe,
			Args: []string{"-dir", filepath.Join(custodyDir, "witness"), "-enroll-key", base64Std(enrollPublic)}, Stderr: io.Discard})
		if err != nil {
			facts.Notes = append(facts.Notes, "restart the witness: "+err.Error())
		} else {
			defer func() { _ = witness.Stop(5 * time.Second) }()
			facts.WitnessPID = witness.Ready.PID
			// Pinned to the witness key saved with the run: every head and
			// status read below must verify under it.
			client, err := headwitness.NewClient(witness.Origin(), headwitness.WithPinnedWitness(witnessKey))
			key, keyErr := headwitness.KeyInfo{}, err
			if err == nil {
				key, keyErr = client.Key(ctx)
			}
			facts.WitnessKeyStable = keyErr == nil && strings.EqualFold(key.PublicKey, base64Std(witnessKey))
			if keyErr != nil {
				facts.Notes = append(facts.Notes, "the restarted witness: "+keyErr.Error())
			}
			if keyErr == nil {
				liveOrigin = witness.Origin()
				latest, _, latestErr := client.Latest(ctx, report.RunID)
				if latestErr == nil {
					facts.WitnessLatestSeq = latest.Head.Seq
					var saved headwitness.CosignedHead
					facts.WitnessLatestMatches = json.Unmarshal(witnessHead, &saved) == nil && saved.Head.EntryHash == latest.Head.EntryHash && saved.Head.Seq == latest.Head.Seq
				} else {
					facts.Notes = append(facts.Notes, "witness latest: "+latestErr.Error())
				}
				if status, _, err := client.RunStatus(ctx, report.RunID); err == nil {
					facts.WitnessContinuedBy, facts.StatusEnrollmentKID = status.ContinuedBy, status.EnrollmentKID
					facts.ContinuedBySegment = status.ContinuedBy != "" && status.ContinuedBy == facts.SegmentRunID
				} else {
					facts.Notes = append(facts.Notes, "witness run status: "+err.Error())
				}
				if facts.SegmentRunID != "" {
					if segmentLatest, _, err := client.Latest(ctx, facts.SegmentRunID); err == nil {
						facts.SegmentWitnessLatestSeq = segmentLatest.Head.Seq
					} else {
						facts.Notes = append(facts.Notes, "witness latest of the segment: "+err.Error())
					}
				}
				history, historyErr := client.History(ctx, report.RunID)
				if historyErr == nil {
					facts.WitnessHistory = len(history)
					// The stale anchor: the latest cosigned head at or before
					// the rollback point (or the first one).
					target := uint64(0)
					if haveRollback {
						target = rollbackSeq
					}
					for _, cosigned := range history {
						if target == 0 || cosigned.Head.Seq <= target {
							if raw, err := json.Marshal(cosigned); err == nil {
								stale, facts.StaleWitnessSeq = raw, cosigned.Head.Seq
							}
							if target == 0 {
								break
							}
						}
					}
				} else {
					facts.Notes = append(facts.Notes, "witness history: "+historyErr.Error())
				}
				// Enrollment probes, before the matrix: a refused probe
				// changes nothing the live anchors read.
				target := headwitness.Continuation{RunID: report.RunID, FinalHead: facts.FinalHeadHash, KeysSHA256: report.KeysSHA256}
				if segmentDir != "" {
					target = headwitness.Continuation{RunID: facts.SegmentRunID, FinalHead: facts.SegmentHeadHash, KeysSHA256: facts.SegmentKeysSHA256}
				}
				facts.EnrollmentProbes, facts.ProbesLeftNoTrace = runEnrollmentProbes(ctx, client, report.RunID, target, facts.EnrollmentKID)
			}
		}
	}

	// Restart the provider process on its own directory: key and journal.
	var liveJournal []byte
	providerDir := filepath.Join(custodyDir, "provider")
	runIDHex := ""
	if runs, err := os.ReadDir(filepath.Join(providerDir, "runs")); err == nil && len(runs) == 1 {
		runIDHex = runs[0].Name()
	}
	if runIDHex == "" {
		facts.Notes = append(facts.Notes, "provider run directory not found under "+displayPath(providerDir))
	} else {
		provider, err := headwitness.StartProcess(ctx, headwitness.LaunchConfig{Executable: options.providerExe,
			Args: []string{"-dir", providerDir, "-run-id", runIDHex}, Stderr: io.Discard})
		if err != nil {
			facts.Notes = append(facts.Notes, "restart the provider: "+err.Error())
		} else {
			external, _, err := devcomposition.FetchExternalProvider(ctx, provider.Origin())
			if err == nil {
				facts.ProviderKIDMatches = keysJSONHasKID(filepath.Join(report.RunDir, audit.KeysFile), "SIMULATOR_PROVIDER", hex.EncodeToString(external.KID[:]))
				liveJournal, err = httpGet(ctx, provider.Origin()+"/journal")
				if err == nil {
					facts.ProviderCommits = journalCommitSeqBytes(liveJournal)
				}
			}
			if err != nil {
				facts.Notes = append(facts.Notes, "provider after restart: "+err.Error())
			}
			_ = provider.Stop(5 * time.Second)
		}
	}

	// Anchor conditions. The first run's pins are the values the demo
	// process held; the segment's were taken from its genuine folder above.
	pinned := func(keys, head, suffix string) []custodyAnchor {
		return []custodyAnchor{
			{name: "none"},
			{name: "keys pinned" + suffix, options: auditverify.Options{ExpectKeysSHA256: keys}},
			{name: "head pinned" + suffix, options: auditverify.Options{ExpectHead: head}},
			{name: "keys+head pinned" + suffix, options: auditverify.Options{ExpectKeysSHA256: keys, ExpectHead: head}},
		}
	}
	live := func(runID string) custodyAnchor {
		return custodyAnchor{name: anchorLive, live: func() (auditverify.Options, error) {
			return liveWitnessOptions(ctx, liveOrigin, runID, witnessKey)
		}}
	}
	firstAnchors := pinned(report.KeysSHA256, report.Verifier.AfterShutdownHeadHash, "")
	if haveWitness {
		firstAnchors = append(firstAnchors, custodyAnchor{name: "witness latest cosigned head", options: auditverify.Options{WitnessHead: witnessHead, WitnessPublicKey: witnessKey}})
		if liveOrigin != "" {
			firstAnchors = append(firstAnchors, live(report.RunID))
		}
		if stale != nil {
			firstAnchors = append(firstAnchors, custodyAnchor{name: fmt.Sprintf("stale witness head (#%d)", facts.StaleWitnessSeq), options: auditverify.Options{WitnessHead: stale, WitnessPublicKey: witnessKey}})
		}
	}

	// Evidence variants.
	variantsDir := filepath.Join(workDir, "variants")
	_ = os.RemoveAll(variantsDir)
	if err := os.MkdirAll(variantsDir, 0o755); err != nil {
		return facts, nil, err
	}
	// Without a restart segment the closed run folder is the whole run.
	// With one, the same folder presented alone withholds the segment that
	// continued the run: an omission, so it counts as tampered evidence.
	first := custodyVariant{name: variantClosedRun, dir: report.RunDir, anchors: firstAnchors}
	if segmentDir != "" {
		withheld := append([]custodyAnchor(nil), firstAnchors...)
		withheld = append(withheld, custodyAnchor{name: "head pinned = run's final head (segment)", options: auditverify.Options{ExpectHead: facts.SegmentHeadHash}})
		first = custodyVariant{name: variantWithheld, dir: report.RunDir, tampered: true, anchors: withheld}
	}
	variants := []custodyVariant{first}
	if haveRollback {
		facts.RollbackSeq = rollbackSeq
		dir := filepath.Join(variantsDir, "rollback")
		if _, err := auditverify.ApplyTamperWith(report.RunDir, dir, auditverify.TamperRollback, earlier); err != nil {
			facts.Notes = append(facts.Notes, "rollback copy: "+err.Error())
		} else {
			variants = append(variants, custodyVariant{name: variantRollback, dir: dir, tampered: true, anchors: firstAnchors})
			facts.RollbackFolderCommits = journalCommitSeq(filepath.Join(dir, audit.ProviderJournalFile))
		}
	} else {
		facts.Notes = append(facts.Notes, "no earlier checkpoint of this run was saved by the tamper lab, so no rollback copy")
	}
	if liveJournal != nil {
		for _, base := range append([]custodyVariant(nil), variants...) {
			dir := filepath.Join(variantsDir, safeName(strings.ReplaceAll(base.name, " ", "-"))+"-live-provider-journal")
			if base.name == variantWithheld {
				dir = filepath.Join(variantsDir, "withheld-segment-live-provider-journal")
			}
			if err := copyEvidence(base.dir, dir); err != nil {
				facts.Notes = append(facts.Notes, "copy for the live provider journal: "+err.Error())
				continue
			}
			if err := os.WriteFile(filepath.Join(dir, audit.ProviderJournalFile), liveJournal, 0o600); err != nil {
				facts.Notes = append(facts.Notes, err.Error())
				continue
			}
			variants = append(variants, custodyVariant{name: base.name + liveJournalTag, dir: dir, tampered: base.tampered, anchors: base.anchors})
		}
	}
	if segmentDir != "" {
		segmentAnchors := pinned(facts.SegmentKeysSHA256, facts.SegmentHeadHash, " (segment)")
		if haveWitness && segmentSaved != nil {
			segmentAnchors = append(segmentAnchors, custodyAnchor{name: "segment's witness latest cosigned head (saved)", options: auditverify.Options{WitnessHead: segmentSaved, WitnessPublicKey: witnessKey}})
		}
		if haveWitness && liveOrigin != "" {
			segmentAnchors = append(segmentAnchors, live(facts.SegmentRunID))
		}
		// No live-journal copy of the segment: the provider process's journal
		// names the run it was started for (the first run), while the
		// segment's provider-journal.json is labelled with the segment's run
		// ID, so the swap fails files.run_id without saying anything about
		// the commits.
		variants = append(variants, custodyVariant{name: variantSegment, dir: segmentDir, anchors: segmentAnchors})
	}

	var cells []custodyCell
	for _, v := range variants {
		for _, a := range v.anchors {
			var outcome verifyOutcome
			options, err := a.options, error(nil)
			if a.live != nil {
				options, err = a.live()
			}
			if err != nil {
				// Like agentgate-verify exit 2: no verdict without the anchor.
				outcome = verifyOutcome{Folder: displayPath(v.dir), Anchors: a.name, Error: "witness: " + hideWorkDir(err.Error())}
			} else {
				outcome = verifyWith(v.dir, a.name, options)
			}
			cell := custodyCell{Variant: v.name, Anchors: a.name, Tampered: v.tampered, Outcome: outcome}
			cell.Accepted = outcome.Verdict == auditverify.VerdictVerified
			cell.Anchored = outcome.Assurance == auditverify.AssuranceAnchored
			cell.Detected = v.tampered && outcome.Verdict == auditverify.VerdictFailed
			cell.FalseFail = !v.tampered && outcome.Verdict == auditverify.VerdictFailed
			cells = append(cells, cell)
		}
	}
	return facts, cells, nil
}

// enrollmentProbe is one registration sent to the witness by a party that
// does not hold the gateway's enrollment private key.
type enrollmentProbe struct {
	Name string `json:"name"`
	// Refused: the witness refused it with its enrollment error (HTTP 403,
	// code "enrollment"); Answer is what it said.
	Refused bool   `json:"refused"`
	Answer  string `json:"witness_answer"`
}

// runEnrollmentProbes sends the witness (through client, which holds no
// enrollment key) the registrations a party without the gateway's enrollment
// private key can build from public facts: a new run ID unsigned, the same
// claiming the gateway's enrollment key ID with a forged signature (random
// bytes: nothing is signed), the genuine run's ID with other keys, and a
// false continuation of target (the newest segment) unsigned and forged.
// noTrace reports that afterwards no probed run ID is known to the witness,
// target is not continued and the genuine run still has its registered keys
// fingerprint and enrollment key.
func runEnrollmentProbes(ctx context.Context, client *headwitness.Client, genuineRunID string, target headwitness.Continuation, enrollmentKID string) (probes []enrollmentProbe, noTrace bool) {
	before, _, beforeErr := client.RunStatus(ctx, genuineRunID)
	tag := randomHexString(4)
	fresh := func(runID string) headwitness.RegisterRequest {
		return headwitness.RegisterRequest{RunID: runID, KeysSHA256: sha256Hex([]byte("probe keys " + runID)), AuditPublicKey: base64Std(randomBytes(32))}
	}
	forged := func(request headwitness.RegisterRequest) headwitness.RegisterRequest {
		request.EnrollmentKID, request.EnrollmentSignature = enrollmentKID, base64Std(randomBytes(64))
		return request
	}
	newRun, falseContinuation := "run-probe-"+tag+"-new", "run-probe-"+tag+"-continuation"
	continuation := fresh(falseContinuation)
	continuation.Continues = &target
	// Stable names (no run IDs), so repeated runs compare probe by probe.
	targetLabel := "the newest segment"
	if target.RunID == genuineRunID {
		targetLabel = "the run"
	}
	cases := []struct {
		name    string
		request headwitness.RegisterRequest
	}{
		{"new run ID, unsigned", fresh(newRun)},
		{"new run ID, gateway's enrollment key ID with a forged signature", forged(fresh(newRun))},
		{"the run's own ID with other keys, unsigned", fresh(genuineRunID)},
		{"false continuation of " + targetLabel + ", unsigned", continuation},
		{"false continuation of " + targetLabel + ", gateway's enrollment key ID with a forged signature", forged(continuation)},
	}
	for _, c := range cases {
		probe := enrollmentProbe{Name: c.name, Answer: "accepted"}
		if _, err := client.Register(ctx, c.request); err != nil {
			probe.Refused, probe.Answer = errors.Is(err, headwitness.ErrEnrollment), err.Error()
		}
		probes = append(probes, probe)
	}
	noTrace = beforeErr == nil
	for _, runID := range []string{newRun, falseContinuation} {
		if _, _, err := client.RunStatus(ctx, runID); !errors.Is(err, headwitness.ErrUnknownRun) {
			noTrace = false
		}
	}
	if status, _, err := client.RunStatus(ctx, target.RunID); err != nil || status.ContinuedBy != "" && target.RunID != genuineRunID {
		noTrace = false
	}
	if after, _, err := client.RunStatus(ctx, genuineRunID); err != nil || after.KeysSHA256 != before.KeysSHA256 || after.EnrollmentKID != before.EnrollmentKID ||
		after.ContinuedBy != before.ContinuedBy || after.LatestEntryHash != before.LatestEntryHash {
		noTrace = false
	}
	return probes, noTrace
}

func refusedProbes(probes []enrollmentProbe) int {
	refused := 0
	for _, probe := range probes {
		if probe.Refused {
			refused++
		}
	}
	return refused
}

func randomBytes(n int) []byte {
	out := make([]byte, n)
	if _, err := rand.Read(out); err != nil {
		panic(err)
	}
	return out
}

func randomHexString(n int) string { return hex.EncodeToString(randomBytes(n)) }

// liveWitnessOptions is the live witness anchor: the verifier options for the
// witness's current head and run status of runID, dated by when they were
// fetched (Options.WitnessRunFetchedAt), so the verifier holds the status to
// the same freshness bound (auditverify.MaxWitnessStatusSkew) as for
// agentgate-verify --witness-url.
func liveWitnessOptions(ctx context.Context, origin, runID string, witnessKey []byte) (auditverify.Options, error) {
	head, status, fetchedAt, err := fetchLiveWitness(ctx, origin, runID)
	return auditverify.Options{WitnessHead: head, WitnessRun: status, WitnessRunFetchedAt: fetchedAt, WitnessPublicKey: witnessKey}, err
}

// fetchLiveWitness reads the witness's latest cosigned head of runID and its
// run status (GET /runs/{id}/latest and GET /runs/{id}) from the running
// witness at origin, as agentgate-verify --witness-url does, and returns when
// the status was fetched.
func fetchLiveWitness(ctx context.Context, origin, runID string) (head, status []byte, fetchedAt time.Time, err error) {
	base := origin + "/runs/" + url.PathEscape(runID)
	if head, err = httpGet(ctx, base+"/latest"); err != nil {
		return nil, nil, time.Time{}, err
	}
	if status, err = httpGet(ctx, base); err != nil {
		return nil, nil, time.Time{}, fmt.Errorf("run status: %w", err)
	}
	return head, status, time.Now(), nil
}

func sha256Hex(data []byte) string {
	sum := sha256.Sum256(data)
	return hex.EncodeToString(sum[:])
}

func orDash(value string) string {
	if value == "" {
		return "-"
	}
	return value
}

// hideWorkDir replaces the absolute work directory in texts written by the
// demo (which names its own paths) with "<work>", as displayPath does.
func hideWorkDir(text string) string {
	if workRoot == "" {
		return text
	}
	for _, form := range []string{workRoot, filepath.ToSlash(workRoot)} {
		text = strings.ReplaceAll(text, form, "<work>")
	}
	return text
}

func base64Std(raw []byte) string { return base64.StdEncoding.EncodeToString(raw) }

// httpGet reads one loopback URL (the custody processes' GET endpoints).
func httpGet(ctx context.Context, url string) ([]byte, error) {
	request, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return nil, err
	}
	client := &http.Client{Timeout: 10 * time.Second}
	response, err := client.Do(request)
	if err != nil {
		return nil, err
	}
	defer response.Body.Close()
	data, err := io.ReadAll(io.LimitReader(response.Body, 64<<20))
	if err != nil {
		return nil, err
	}
	if response.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("GET %s: HTTP %d", url, response.StatusCode)
	}
	return data, nil
}

func journalCommitSeq(path string) uint64 {
	data, err := os.ReadFile(path)
	if err != nil {
		return 0
	}
	return journalCommitSeqBytes(data)
}

func journalCommitSeqBytes(data []byte) uint64 {
	var journal struct {
		CommitSeq uint64 `json:"commit_seq"`
	}
	if json.Unmarshal(data, &journal) != nil {
		return 0
	}
	return journal.CommitSeq
}

func keysJSONHasKID(path, role, kid string) bool {
	data, err := os.ReadFile(path)
	if err != nil {
		return false
	}
	var keys audit.KeysDocument
	if json.Unmarshal(data, &keys) != nil {
		return false
	}
	for _, key := range keys.Keys {
		if key.Role == role && strings.EqualFold(key.KIDHex, kid) {
			return true
		}
	}
	return false
}

// copyEvidence copies the five evidence files of a run folder.
func copyEvidence(src, dst string) error {
	if err := os.MkdirAll(dst, 0o755); err != nil {
		return err
	}
	for _, name := range []string{audit.LogFile, audit.HeadFile, audit.KeysFile, audit.RunFile, audit.ProviderJournalFile} {
		data, err := os.ReadFile(filepath.Join(src, name))
		if err != nil {
			return err
		}
		if err := os.WriteFile(filepath.Join(dst, name), data, 0o600); err != nil {
			return err
		}
	}
	return nil
}

func custodyCSV(cells []custodyCell) string {
	var b strings.Builder
	// missing_kinds names the kinds of the Missing entries (unresolved,
	// freshness, issuer_only, other): every cell anchored by a pin or a saved
	// head lists the freshness gap, so a non-empty missing column alone says
	// little. head_fresh and run_complete are the derived dimensions.
	b.WriteString(csvLine("variant", "anchors", "tampered", "verdict", "assurance", "detected", "false_alarm", "failing_checks", "missing", "error",
		"missing_kinds", "head_fresh", "run_complete"))
	for _, cell := range cells {
		b.WriteString(csvLine(cell.Variant, cell.Anchors, boolText(cell.Tampered), cell.Outcome.Verdict, cell.Outcome.Assurance, boolText(cell.Detected),
			boolText(cell.FalseFail), strings.Join(cell.Outcome.Failing, " "), strings.Join(cell.Outcome.Missing, " | "), cell.Outcome.Error,
			missingKindsText(cell.Outcome.MissingByKind), cell.Outcome.Dimensions[auditverify.DimHeadFresh], cell.Outcome.Dimensions[auditverify.DimRunComplete]))
	}
	return b.String()
}

func custodyMarkdown(result custodyResult) string {
	var b strings.Builder
	f := result.Facts
	fmt.Fprintf(&b, "# Custody: provider and witness processes\n\n%s\n\nCommand: `%s`. Elapsed %.1f s.\n\n## Method\n\n", result.Note, result.Environment.Command, result.ElapsedSecs)
	for _, line := range result.Method {
		fmt.Fprintf(&b, "- %s\n", line)
	}
	fmt.Fprintf(&b, "\n## The run\n\nSelf-test: %s (%s). Console: `%s`.\n\n| self-test custody check | result | detail |\n|---|---|---|\n",
		map[bool]string{true: "passed", false: "FAILED"}[result.Passed], result.SelfTest, result.Console)
	for _, check := range result.Checks {
		detail := check.Detail
		if len(check.Issues) > 0 {
			detail += " Problems: " + strings.Join(check.Issues, "; ")
		}
		fmt.Fprintf(&b, "| %s | %s | %s |\n", check.Title, map[bool]string{true: "pass", false: "FAIL"}[check.Passed], strings.ReplaceAll(detail, "|", "/"))
	}
	b.WriteString("\n## After the run\n\n| fact | value |\n|---|---|\n")
	rows := [][2]string{
		{"final audit head (seq)", fmt.Sprint(f.FinalHeadSeq)},
		{"WITNESS_UNAVAILABLE entries in the log", fmt.Sprint(f.WitnessUnavailable)},
		{"witness: latest cosigned seq after its restart", fmt.Sprint(f.WitnessLatestSeq)},
		{"witness: latest after restart equals the saved anchor", boolText(f.WitnessLatestMatches)},
		{"witness: same key after restart", boolText(f.WitnessKeyStable)},
		{"witness: cosigned heads in its history", fmt.Sprint(f.WitnessHistory)},
		{"witness: run status of the first run, continued_by", orDash(f.WitnessContinuedBy)},
		{"witness: continued_by names the restart segment", boolText(f.ContinuedBySegment)},
		{"gateway enrollment key (kid)", orDash(f.EnrollmentKID)},
		{"witness: run status enrollment_kid equals the gateway's", boolText(f.EnrollmentKID != "" && f.StatusEnrollmentKID == f.EnrollmentKID)},
		{"witness: key after restart equals the key pinned for the custody folder", boolText(f.WitnessPinMatches)},
		{"enrollment probes refused with the enrollment error", fmt.Sprintf("%d of %d", refusedProbes(f.EnrollmentProbes), len(f.EnrollmentProbes))},
		{"enrollment probes left the witness's state unchanged", boolText(f.ProbesLeftNoTrace)},
		{"restart segment: run / entries / witness latest cosigned seq", fmt.Sprintf("%s / %d / %d", orDash(f.SegmentRunID), f.SegmentHeadSeq, f.SegmentWitnessLatestSeq)},
		{"provider: key after restart equals keys.json SIMULATOR_PROVIDER", boolText(f.ProviderKIDMatches)},
		{"provider: commits in its own journal after restart", fmt.Sprint(f.ProviderCommits)},
		{"run folder provider-journal.json commits", fmt.Sprint(f.FolderCommits)},
		{"rollback copy: cut to seq / provider commits", fmt.Sprintf("%d / %d", f.RollbackSeq, f.RollbackFolderCommits)},
		{"stale witness anchor seq", fmt.Sprint(f.StaleWitnessSeq)},
	}
	for _, row := range rows {
		fmt.Fprintf(&b, "| %s | %s |\n", row[0], row[1])
	}
	for _, note := range f.Notes {
		fmt.Fprintf(&b, "\nNote: %s\n", note)
	}
	if len(f.EnrollmentProbes) > 0 {
		b.WriteString("\n## Enrollment probes (no enrollment private key)\n\n| registration | refused (enrollment) | witness answer |\n|---|---|---|\n")
		for _, probe := range f.EnrollmentProbes {
			fmt.Fprintf(&b, "| %s | %s | %s |\n", probe.Name, boolText(probe.Refused), strings.ReplaceAll(probe.Answer, "|", "/"))
		}
	}
	b.WriteString("\n## Verification matrix\n\nhead fresh / run complete: the verifier's derived dimensions; missing: the kinds of the gaps it lists " +
		"(every cell anchored by a pin or a saved head lists the freshness gap).\n\n" +
		"| evidence | anchors | verdict | assurance | outcome | failing checks | head fresh / run complete | missing |\n|---|---|---|---|---|---|---|---|\n")
	for _, cell := range result.Cells {
		outcome := "accepted"
		switch {
		case cell.Detected:
			outcome = "detected"
		case cell.FalseFail:
			outcome = "FALSE ALARM"
		case cell.Tampered && cell.Accepted:
			outcome = "NOT detected"
		}
		failing := strings.Join(cell.Outcome.Failing, ", ")
		if cell.Outcome.Error != "" {
			failing = "error: " + cell.Outcome.Error
		}
		derived := orDash(cell.Outcome.Dimensions[auditverify.DimHeadFresh]) + " / " + orDash(cell.Outcome.Dimensions[auditverify.DimRunComplete])
		fmt.Fprintf(&b, "| %s | %s | %s | %s | %s | %s | %s | %s |\n", cell.Variant, cell.Anchors, cell.Outcome.Verdict, cell.Outcome.Assurance, outcome, failing,
			derived, orDash(missingKindsText(cell.Outcome.MissingByKind)))
	}
	return b.String()
}
