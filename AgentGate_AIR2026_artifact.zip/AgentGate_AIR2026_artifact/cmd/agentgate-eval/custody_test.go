package main

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"agentgate/internal/audit"
	"agentgate/internal/auditverify"
	"agentgate/internal/auditverify/fixture"
	"agentgate/internal/headwitness"
)

// The custody runner's enrollment probes against a real witness (in process,
// started with a test enrollment key): a genuine run and its continuation
// segment are registered with that key and pushed; every probe (no
// enrollment private key) is refused with the enrollment error and leaves
// the witness's state unchanged. Against a stub that accepts every
// registration, the same probes are reported as not refused, so the counts
// in custody.json come from the witness's answers.
func TestEnrollmentProbesAreRefusedAndLeaveNoTrace(t *testing.T) {
	seed := make([]byte, ed25519.SeedSize)
	copy(seed, "agentgate eval test enrollment key")
	enroller, err := headwitness.NewEnrollmentKey(ed25519.NewKeyFromSeed(seed))
	if err != nil {
		t.Fatal(err)
	}
	service, err := headwitness.Open(headwitness.Options{Dir: t.TempDir(), EnrollmentKeys: []ed25519.PublicKey{enroller.PublicKey()}})
	if err != nil {
		t.Fatal(err)
	}
	defer service.Close()
	restart, err := fixture.WriteRestartWith(filepath.Join(t.TempDir(), "restart"), fixture.RestartOptions{})
	if err != nil {
		t.Fatal(err)
	}
	first, segment := restart.Segments[0].Dir, restart.Segments[1].Dir
	firstRun := registerAndPush(t, service, enroller, first, nil)
	target := registerAndPush(t, service, enroller, segment, &firstRun)
	server := httptest.NewServer(service.Handler())
	defer server.Close()
	client, err := headwitness.NewClient(server.URL, headwitness.WithPinnedWitness(service.PublicKey()))
	if err != nil {
		t.Fatal(err)
	}

	probes, noTrace := runEnrollmentProbes(context.Background(), client, firstRun.RunID, target, enroller.KID())
	if len(probes) != 5 || refusedProbes(probes) != len(probes) || !noTrace {
		t.Fatalf("probes against the witness: %d of %d refused, no trace %t: %+v", refusedProbes(probes), len(probes), noTrace, probes)
	}
	for _, probe := range probes {
		if !strings.Contains(probe.Answer, "enrolled gateway key") && !strings.Contains(probe.Answer, "enrollment") {
			t.Errorf("probe %q answered %q", probe.Name, probe.Answer)
		}
	}
	if status, err := service.RunStatus(target.RunID); err != nil || status.ContinuedBy != "" || status.EnrollmentKID != enroller.KID() {
		t.Fatalf("the segment after the probes: %+v, %v", status, err)
	}

	// A stub that accepts every registration: nothing is refused.
	accepting := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var request headwitness.RegisterRequest
		body, _ := io.ReadAll(r.Body)
		_ = json.Unmarshal(body, &request)
		w.WriteHeader(http.StatusCreated)
		_ = json.NewEncoder(w).Encode(headwitness.Registration{Format: headwitness.RegistrationFormat, RunID: request.RunID, KeysSHA256: request.KeysSHA256})
	}))
	defer accepting.Close()
	open, err := headwitness.NewClient(accepting.URL)
	if err != nil {
		t.Fatal(err)
	}
	if probes, noTrace := runEnrollmentProbes(context.Background(), open, firstRun.RunID, target, enroller.KID()); refusedProbes(probes) != 0 || noTrace {
		t.Fatalf("probes against an accepting stub: %d refused, no trace %t", refusedProbes(probes), noTrace)
	}
}

// The go command the custody runner builds missing binaries with: under the
// recorded Go installation, else (a -trimpath build records none) the go on
// PATH, else a clear error instead of a relative "bin/go".
func TestGoToolFrom(t *testing.T) {
	root := filepath.Join(t.TempDir(), "go")
	tool, err := goToolFrom(root, func(string) (string, error) { t.Fatal("PATH searched although GOROOT is known"); return "", nil })
	if err != nil || filepath.Dir(filepath.Dir(tool)) != root || !strings.HasPrefix(filepath.Base(tool), "go") {
		t.Fatalf("with GOROOT: %q, %v", tool, err)
	}
	onPath := filepath.Join(t.TempDir(), "go.exe")
	if tool, err := goToolFrom("", func(name string) (string, error) { return onPath, nil }); err != nil || tool != onPath {
		t.Fatalf("without GOROOT, go on PATH: %q, %v", tool, err)
	}
	if tool, err := goToolFrom("", func(string) (string, error) { return "", errors.New("not found") }); err == nil || !strings.Contains(err.Error(), "-trimpath") {
		t.Fatalf("without GOROOT and PATH: %q, %v", tool, err)
	}
}

// registerAndPush registers a fixture evidence folder with the witness
// (signed with enroller; a continuation when continues is set), pushes its
// whole log and returns it as the run a later segment continues.
func registerAndPush(t *testing.T, service *headwitness.Service, enroller *headwitness.EnrollmentKey, dir string, continues *headwitness.Continuation) headwitness.Continuation {
	t.Helper()
	keys, err := os.ReadFile(filepath.Join(dir, audit.KeysFile))
	if err != nil {
		t.Fatal(err)
	}
	headJSON, err := os.ReadFile(filepath.Join(dir, audit.HeadFile))
	if err != nil {
		t.Fatal(err)
	}
	var head audit.Head
	if err := json.Unmarshal(headJSON, &head); err != nil {
		t.Fatal(err)
	}
	log, err := os.ReadFile(filepath.Join(dir, audit.LogFile))
	if err != nil {
		t.Fatal(err)
	}
	request, err := enroller.Sign(headwitness.RegisterRequest{RunID: head.RunID, KeysSHA256: sha256Hex(keys),
		KeysFile: base64.StdEncoding.EncodeToString(keys), Continues: continues})
	if err != nil {
		t.Fatal(err)
	}
	if _, _, err := service.Register(request); err != nil {
		t.Fatal(err)
	}
	if _, _, err := service.PushHead(headwitness.HeadPush{Head: head, Entries: strings.Split(strings.TrimSuffix(string(log), "\n"), "\n")}); err != nil {
		t.Fatal(err)
	}
	return headwitness.Continuation{RunID: head.RunID, FinalHead: head.EntryHash, KeysSHA256: sha256Hex(keys)}
}

// The custody runner's live witness anchor dates its fetch
// (Options.WitnessRunFetchedAt), as agentgate-verify --witness-url does, so
// the verifier holds the run status to the same freshness bound: a genuine
// status signed long before the fetch (a replayed older status could hide a
// later segment) is refused, one signed at the fetch is accepted. The witness
// is served from the fixture's synthetic run, signed with the fixture's
// in-memory witness key.
func TestLiveWitnessOptionsApplyTheStatusFreshnessBound(t *testing.T) {
	if time.Now().Before(time.Date(2026, 10, 1, 12, 34, 0, 0, time.UTC)) {
		t.Skip("the system clock is before the fixture's witnessing time")
	}
	run, err := fixture.Write(filepath.Join(t.TempDir(), "run"))
	if err != nil {
		t.Fatal(err)
	}
	head, witnessKey, err := fixture.CosignHead(run.Dir, run.HeadSeq)
	if err != nil {
		t.Fatal(err)
	}
	stale, err := fixture.WitnessRunStatus(run.Dir, "") // signed at fixture.WitnessStatusTime
	if err != nil {
		t.Fatal(err)
	}
	var status []byte
	mux := http.NewServeMux()
	mux.HandleFunc("GET /runs/{id}/latest", func(w http.ResponseWriter, r *http.Request) {
		if r.PathValue("id") != run.RunID {
			http.NotFound(w, r)
			return
		}
		_, _ = w.Write(head)
	})
	mux.HandleFunc("GET /runs/{id}", func(w http.ResponseWriter, r *http.Request) {
		if r.PathValue("id") != run.RunID {
			http.NotFound(w, r)
			return
		}
		_, _ = w.Write(status)
	})
	server := httptest.NewServer(mux)
	defer server.Close()

	for _, tc := range []struct {
		name     string
		status   func() []byte
		accepted bool
	}{
		{"status signed long before the fetch", func() []byte { return stale }, false},
		{"status signed at the fetch", func() []byte {
			fresh, err := fixture.SignWitnessRunStatus(run.Dir, 0, "", time.Now())
			if err != nil {
				t.Fatal(err)
			}
			return fresh
		}, true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			status = tc.status()
			before := time.Now()
			options, err := liveWitnessOptions(context.Background(), server.URL, run.RunID, witnessKey)
			if err != nil {
				t.Fatal(err)
			}
			if fetchedAt := options.WitnessRunFetchedAt; fetchedAt.Before(before) || fetchedAt.After(time.Now()) {
				t.Fatalf("WitnessRunFetchedAt = %v, want the moment of the fetch (after %v)", fetchedAt, before)
			}
			if !bytes.Equal(options.WitnessHead, head) || !bytes.Equal(options.WitnessRun, status) || !bytes.Equal(options.WitnessPublicKey, witnessKey) {
				t.Fatal("the live anchor does not carry the witness's head, status and key")
			}
			report, err := auditverify.VerifyRun(run.Dir, options)
			if err != nil {
				t.Fatal(err)
			}
			witness := report.Anchors.Witness
			if tc.accepted {
				if report.Verdict != auditverify.VerdictVerified || report.Assurance != auditverify.AssuranceAnchored || witness == nil || !witness.StatusChecked {
					t.Fatalf("fresh status: %s/%s witness %+v failures %+v", report.Verdict, report.Assurance, witness, report.Failures)
				}
				return
			}
			refused := false
			for _, check := range report.Failures {
				refused = refused || check.ID == auditverify.CheckHeadWitness && strings.Contains(check.Detail, "is not the witness's current status")
			}
			if !refused || report.Assurance == auditverify.AssuranceAnchored || witness == nil || witness.StatusChecked {
				t.Fatalf("stale status was not refused: %s/%s witness %+v failures %+v", report.Verdict, report.Assurance, witness, report.Failures)
			}
		})
	}

	// Without an answer from the witness there is no anchor (like
	// agentgate-verify exit 2).
	if _, err := liveWitnessOptions(context.Background(), server.URL, "run-20261001-000000-000000", witnessKey); err == nil {
		t.Fatal("an unknown run gave a live anchor")
	}
}
