package main

import (
	"math"
	"strings"
	"testing"

	"agentgate/internal/audit"
	"agentgate/internal/auditverify"
)

func TestAblationConfigs(t *testing.T) {
	configs := ablationConfigs()
	all := auditverify.Mechanisms()
	byID := map[string]ablationConfig{}
	for _, config := range configs {
		if _, dup := byID[config.ID]; dup {
			t.Fatalf("duplicate config %s", config.ID)
		}
		byID[config.ID] = config
		if len(config.Enabled)+len(config.Disabled) != len(all) {
			t.Errorf("%s: %d enabled + %d disabled != %d mechanisms", config.ID, len(config.Enabled), len(config.Disabled), len(all))
		}
		anchorsOn := false
		for _, name := range config.Enabled {
			anchorsOn = anchorsOn || name == string(auditverify.MechanismAnchors)
		}
		if config.Pinned != anchorsOn && config.Family != familyReference {
			t.Errorf("%s: pinned %v but anchors enabled %v", config.ID, config.Pinned, anchorsOn)
		}
	}
	// 8 cumulative + 8 leave-one-out + 7 single + 1 reference.
	if len(configs) != 24 {
		t.Fatalf("%d configs, want 24", len(configs))
	}
	if c0 := byID["C0"]; len(c0.Enabled) != 1 || c0.Enabled[0] != string(auditverify.MechanismFiles) || c0.Pinned {
		t.Errorf("C0 = %+v, want files only, unpinned", c0)
	}
	// C7 and R-unpinned disable nothing: they are the default verifier
	// (with and without pins), not a modified one.
	for _, id := range []string{"C7", "R-unpinned"} {
		if config := byID[id]; len(config.disabled) != 0 {
			t.Errorf("%s disables %v", id, config.disabled)
		}
	}
	if !byID["C7"].Pinned || byID["R-unpinned"].Pinned || byID["L-anchors"].Pinned || !byID["L-files"].Pinned {
		t.Errorf("pins wrong: C7 %v R %v L-anchors %v L-files %v", byID["C7"].Pinned, byID["R-unpinned"].Pinned, byID["L-anchors"].Pinned, byID["L-files"].Pinned)
	}
	for k := 1; k < len(all); k++ {
		previous, current := byID["C"+string(rune('0'+k-1))], byID["C"+string(rune('0'+k))]
		if len(current.Enabled) != len(previous.Enabled)+1 || current.Enabled[k] != string(all[k]) {
			t.Errorf("C%d does not add %s to C%d: %v", k, all[k], k-1, current.Enabled)
		}
	}
	options := byID["L-bindings"].options(baseRun{KeysSHA256: "k", HeadHash: "h"})
	if options.ExpectKeysSHA256 != "k" || options.ExpectHead != "h" || len(options.DisableMechanisms) != 1 ||
		options.DisableMechanisms[0] != auditverify.MechanismBindings {
		t.Errorf("L-bindings options = %+v", options)
	}
}

func TestSummarize(t *testing.T) {
	stats := summarize("ms", []float64{4, 1, 3, 2})
	if stats.N != 4 || stats.Min != 1 || stats.Max != 4 || stats.Median != 2.5 || stats.Mean != 2.5 || stats.P95 != nil {
		t.Fatalf("summary = %+v", stats)
	}
	if math.Abs(stats.StdDev-1.291) > 0.001 {
		t.Errorf("stddev = %v", stats.StdDev)
	}
	values := make([]float64, 20)
	for i := range values {
		values[i] = float64(i + 1)
	}
	if stats := summarize("ms", values); stats.P95 == nil || math.Abs(*stats.P95-19.05) > 1e-9 {
		t.Errorf("p95 of 1..20 = %v", stats.P95)
	}
	if empty := summarize("ms", nil); empty.N != 0 {
		t.Errorf("empty summary = %+v", empty)
	}
}

func TestFitLine(t *testing.T) {
	points := []scalePoint{{Entries: 100}, {Entries: 200}, {Entries: 400}}
	for i := range points {
		points[i].Pinned.Median = 2 + 0.05*float64(points[i].Entries)
	}
	fit := fitLine(points)
	if fit.SlopeMSPer1000 != 50 || fit.InterceptMS != 2 || fit.R2 != 1 {
		t.Fatalf("fit = %+v", fit)
	}
}

func TestGatewaySegments(t *testing.T) {
	entry := func(stage, component, op string) audit.StoredEntry {
		return audit.StoredEntry{Entry: audit.Entry{Stage: stage, Component: component, OperationID: op}}
	}
	entries := []audit.StoredEntry{
		entry("RUN_STARTED", "demo/run", ""),
		entry("AGENT_PROPOSED", "agent", "a"),
		entry("REQUEST_VALIDATED", "gateway/normalizer", "a"),
		entry("CALL_RESULT", "gateway/control-point", "a"),
		entry("AGENT_RECEIVED", "agent", "a"),
		entry("HUMAN_DECISION", "approval-ui", "a"),
		entry("AGENT_PROPOSED", "agent", "b"),
		entry("MCP_REJECTED", "gateway/mcp-boundary", "b"),
		entry("AGENT_RECEIVED", "agent", "b"),
	}
	got := gatewaySegments(entries)
	if len(got) != 2 || got[0].gatewayEntries != 2 || got[1].gatewayEntries != 0 || got[0].executed || got[1].executed {
		t.Fatalf("segments = %+v, want 2 and 0 gateway entries, nothing executed", got)
	}
}

func TestParseWorkerCounts(t *testing.T) {
	got, err := parseWorkerCounts("12, 1,4,2")
	if err != nil || len(got) != 4 || got[0] != 1 || got[3] != 12 {
		t.Fatalf("parseWorkerCounts = %v, %v", got, err)
	}
	for _, bad := range []string{"2,4", "1,1,2", "1,0", "1,x", ""} {
		if _, err := parseWorkerCounts(bad); err == nil {
			t.Errorf("parseWorkerCounts(%q) accepted", bad)
		}
	}
}

func TestParallelMarkdown(t *testing.T) {
	result := parallelResult{Note: "note", Machine: "test CPU", Reps: 3, Workers: []int{1, 4}, Points: []parallelPoint{{
		Repeat: 1, Entries: 100, ReportsIdentical: true, Timings: []parallelTiming{
			{Workers: 1, MS: summary{Median: 40}, SpeedupVs1: 1, Efficiency: 1},
			{Workers: 4, MS: summary{Median: 12.5}, SpeedupVs1: 3.2, Efficiency: 0.8},
		},
	}}}
	text := parallelMarkdown(result)
	for _, want := range []string{"test CPU", "| 1 | 100 | 1.00x | 3.20x |", "| 1 | 100 | 0 | 4 | 12.50", "80%", "byte-identical", ": yes."} {
		if !strings.Contains(text, want) {
			t.Errorf("markdown lacks %q:\n%s", want, text)
		}
	}
}

func TestRunRejectsUnknownSubcommand(t *testing.T) {
	var out, errs strings.Builder
	if code := run([]string{"nope"}, &out, &errs); code != 2 || !strings.Contains(errs.String(), "unknown subcommand") {
		t.Fatalf("code %d, stderr %q", code, errs.String())
	}
	if code := run(nil, &out, &errs); code != 2 {
		t.Fatalf("no arguments: code %d", code)
	}
}
