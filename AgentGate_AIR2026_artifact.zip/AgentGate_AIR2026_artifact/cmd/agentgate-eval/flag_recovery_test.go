package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"agentgate/internal/auditverify"
	"agentgate/internal/devcomposition"
	"agentgate/internal/opjournal"
)

// A FLAGGED operation through the real gateway's recovery paths, end to end:
// the harness gateway in flag mode, a payment above the automatic limit
// (allowed and flagged for audit, rule FIN-APPROVAL-LIMIT), a fault armed for
// it, and the exact retry that reconciles it. Three ways between the first
// call and the retry: none (the same gateway), a restart on the operation
// journal, and a restart on a journal that ends right after the operation's
// dispatch intent (the "recorded" write lost, as after a crash between the
// two). Every evidence folder is verified with auditverify and its pinned
// keys and head.
//
// The verifier requires the recovery records (RECONCILED-committed and the
// reconciling call's CALL_RESULT) to state the flag of the decision the
// consumed capability binds (op.requires_policy). Before the gateway kept the
// flag in its dispatch-intent journal record, the intent-only restart
// produced RECONCILED entries without the flag, which that rule fails; this
// test is the check against the real gateway, not the fixture's model of it.
func TestFlaggedOperationRecoveryVerifies(t *testing.T) {
	cases := []struct {
		point devcomposition.FaultPoint
		first string // the first call's status
		// class and restartClass are the operation's classification
		// evidence without and with a restart. An adapter receipt binds the
		// decision when the log has EFFECT_EXECUTED (head_replace) or when
		// RECONCILED carries the adapter's genuine receipt: the adapter
		// signed before the failure, and the gateway still holds the receipt
		// (in memory only: a restarted gateway reconciles without it).
		class, restartClass string
	}{
		{devcomposition.FaultProviderResponseLost, "UNCERTAIN", auditverify.ClassIssuerReconciled, auditverify.ClassIssuerReconciled},
		{devcomposition.FaultHeadReplace, "RECONCILIATION_REQUIRED", auditverify.ClassIssuerAdapter, auditverify.ClassIssuerAdapter},
		{devcomposition.FaultAfterReceiptBeforeAudit, "RECONCILIATION_REQUIRED", auditverify.ClassIssuerAdapter, auditverify.ClassIssuerReconciled},
		{devcomposition.FaultAuditAppend, "RECONCILIATION_REQUIRED", auditverify.ClassIssuerAdapter, auditverify.ClassIssuerReconciled},
	}
	for _, c := range cases {
		for _, restart := range []string{restartNone, restartJournal, restartIntentOnly} {
			class := c.class
			if restart != restartNone {
				class = c.restartClass
			}
			t.Run(fmt.Sprintf("%s/restart=%s", c.point, restart), func(t *testing.T) {
				runFlaggedRecovery(t, c.point, restart, c.first, class)
			})
		}
	}
}

// How the flagged recovery test gets from the first call to the retry.
const (
	restartNone       = "none"
	restartJournal    = "journal"
	restartIntentOnly = "journal-cut-after-dispatch-intent"
)

func runFlaggedRecovery(t *testing.T, point devcomposition.FaultPoint, restart, firstStatus, class string) {
	t.Helper()
	ctx := context.Background()
	w, err := newWorld()
	if err != nil {
		t.Fatal(err)
	}
	label := "eval-flag-recovery"
	run, err := newRunIdentity(label)
	if err != nil {
		t.Fatal(err)
	}
	provider, err := startProviderHost(w, run, nil)
	if err != nil {
		t.Fatal(err)
	}
	defer provider.close()
	grant, err := signGrant(label, w.openGrant(time.Now()))
	if err != nil {
		t.Fatal(err)
	}
	dir, journal := t.TempDir(), filepath.Join(t.TempDir(), "operations.jsonl")
	operation := newOperationID()
	plan := devcomposition.NewFaultPlan().Arm(point, operation)
	var segments []*evidenceRun
	open := func(faults devcomposition.FaultInjector) *gateway {
		t.Helper()
		name := fmt.Sprintf("segment-%d", len(segments)+1)
		evidence, err := newEvidenceRun(filepath.Join(dir, name), label+"-"+name)
		if err != nil {
			t.Fatal(err)
		}
		if len(segments) > 0 {
			if err := evidence.continueFrom(segments[len(segments)-1]); err != nil {
				t.Fatal(err)
			}
		}
		g, err := buildGateway(ctx, w, run, provider, gatewaySpec{Escalation: devcomposition.EscalationFlag, Faults: faults, Journal: journal, Sink: evidence, Grant: grant})
		if err != nil {
			t.Fatal(err)
		}
		if err := evidence.begin(w, g, grant, "flagged recovery "+string(point)); err != nil {
			t.Fatal(err)
		}
		segments = append(segments, evidence)
		return g
	}
	args := paymentArgs(operation, "payee.carrier", 1_240_000, "AED", "Shipping invoice (flagged recovery)")
	g := open(plan)
	first := g.caller().call(ctx, toolPayment, args)
	if first.Status != firstStatus || len(plan.Fired()) != 1 {
		t.Fatalf("first call: %s (fired %v), want %s", first.statusKey(), plan.Fired(), firstStatus)
	}
	if _, outcome, flagged := segments[0].policyRules(opText(operation)); !flagged || outcome != "allow_flagged" {
		t.Fatalf("the payment is not flagged: outcome %q, flagged %t", outcome, flagged)
	}
	if restart != restartNone {
		// The first gateway "dies"; a new one is built on the same journal and
		// provider and opens a continuation segment.
		if err := segments[0].finish(provider); err != nil {
			t.Fatal(err)
		}
		if restart == restartIntentOnly {
			cutJournalAfterIntent(t, journal, operation)
		}
		g = open(nil)
	}
	retry := g.caller().call(ctx, toolPayment, args)
	if retry.statusKey() != "COMMITTED/reconciled" {
		t.Fatalf("exact retry: %s", retry.statusKey())
	}
	for _, segment := range segments {
		if err := segment.finish(provider); err != nil {
			t.Fatal(err)
		}
	}
	if commits, err := provider.commits(); err != nil || commitsByOperation(commits)[opText(operation)] != 1 {
		t.Fatalf("provider commits = %v, %v", commits, err)
	}

	// Every folder verifies; the newest one (following the chain back to the
	// first after a restart) reports the operation executed, reconciled and
	// flagged, bound as expected.
	newest := segments[len(segments)-1]
	for index, segment := range segments {
		report, err := auditverify.VerifyRun(segment.dir, auditverify.Options{ExpectKeysSHA256: segment.keysSHA256, ExpectHead: segment.headHash, Workers: 1})
		if err != nil {
			t.Fatal(err)
		}
		if report.Verdict != auditverify.VerdictVerified || report.Assurance != auditverify.AssuranceAnchored {
			t.Fatalf("segment %d: %s/%s%s", index+1, report.Verdict, report.Assurance, failureLines(report))
		}
		if segment != newest {
			continue
		}
		var op *auditverify.OperationReport
		for i := range report.Operations {
			if report.Operations[i].OperationID == opText(operation) {
				op = &report.Operations[i]
			}
		}
		if op == nil || op.Status != auditverify.OpExecuted || !op.Flagged || !op.Reconciled || op.ClassificationEvidence != class {
			t.Fatalf("operation report = %+v, want executed, flagged, reconciled, %s", op, class)
		}
	}

	// The recovery record and the reconciling call state the flag.
	reconciled, reconcilingCall := false, false
	for _, event := range newest.eventsFor(opText(operation)) {
		flagged, _ := event.Details["flagged"].(bool)
		switch {
		case event.Stage == "RECONCILED":
			reconciled = true
			if event.Outcome != "committed" || !flagged {
				t.Fatalf("RECONCILED = %s %v, want committed and flagged", event.Outcome, event.Details)
			}
			// The adapter signed an APPLIED receipt before every fault but the
			// lost response; only the gateway that holds it attaches it.
			_, hasReceipt := event.Artifacts["effect_receipt"]
			if want := point != devcomposition.FaultProviderResponseLost && restart == restartNone; hasReceipt != want {
				t.Fatalf("RECONCILED carries an adapter receipt: %t, want %t", hasReceipt, want)
			}
		case event.Stage == "CALL_RESULT" && fmt.Sprint(event.Details["status"]) == "COMMITTED":
			reconcilingCall = true
			if !flagged {
				t.Fatalf("reconciling CALL_RESULT = %v, want flagged", event.Details)
			}
		}
	}
	if !reconciled || !reconcilingCall {
		t.Fatalf("newest segment: RECONCILED %t, reconciling CALL_RESULT %t; stages %v", reconciled, reconcilingCall, newest.stagesFor(opText(operation)))
	}
}

// cutJournalAfterIntent keeps the operation journal up to and including the
// operation's dispatch intent record, as if the gateway died before its
// "recorded" write.
func cutJournalAfterIntent(t *testing.T, path string, operation [16]byte) {
	t.Helper()
	records, err := opjournal.Read(path)
	if err != nil {
		t.Fatal(err)
	}
	var kept bytes.Buffer
	for _, record := range records {
		line, err := json.Marshal(record)
		if err != nil {
			t.Fatal(err)
		}
		kept.Write(append(line, '\n'))
		if record.Kind == "dispatch_intent" && strings.HasSuffix(record.Operation, "/"+opText(operation)) {
			if err := os.WriteFile(path, kept.Bytes(), 0o600); err != nil {
				t.Fatal(err)
			}
			return
		}
	}
	t.Fatal("the journal has no dispatch intent for the operation")
}

// failureLines lists a report's failing items for a test message.
func failureLines(report auditverify.Report) string {
	text := ""
	for _, check := range report.Failures {
		text += fmt.Sprintf("\n  %s #%d: %s", check.ID, check.Seq, check.Detail)
	}
	return text
}
