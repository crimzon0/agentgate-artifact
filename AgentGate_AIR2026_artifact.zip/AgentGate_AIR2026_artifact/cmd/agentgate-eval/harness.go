package main

// Shared harness of the revision experiments (crash, concurrency, misuse,
// baseline; docs/demo/REVISION_CONTRACT.md R6.3-R6.5 and R6.8). Each of them
// builds the real gateway (internal/devcomposition) directly instead of going
// through the demo, because it needs things the demo does not expose: fault
// injection, a gateway restart on the same operation journal while the
// provider keeps its state, several gateways sharing one provider, and the
// gateway with its audit sink switched off.
//
// What the harness provides:
//
//   - a synthetic world (an organisation, recipients, payees, documents) that
//     plays the role of the demo catalog; nothing in it is real;
//   - a provider host: the simulated provider (internal/simulator) with its
//     own key and state behind its own loopback HTTP listener, speaking the
//     provider-process protocol of cmd/agentgate-provider (GET /key,
//     GET /journal, the simulator endpoints), so it outlives gateway restarts
//     and every gateway reaches it through Config.ExternalProvider over the
//     same adapter HTTP transport;
//   - gateway construction with the revision's policy (per-currency limits,
//     FIN-ZERO, MSG-CONFIDENTIAL-TEXT), an organisation-signed delegation
//     grant and the optional fault plan / operation journal;
//   - an MCP client that sends real JSON-RPC tools/call requests either in
//     process (http.Handler) or over loopback HTTP;
//   - an evidence folder in the demo's run format (keys.json, run.json,
//     audit.jsonl, head.json, provider-journal.json) written by the signed
//     audit log, so the independent verifier (internal/auditverify) can be run
//     on what each experiment produced.

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"agentgate/internal/audit"
	"agentgate/internal/auditverify"
	"agentgate/internal/canon"
	"agentgate/internal/devcomposition"
	"agentgate/internal/effects"
	"agentgate/internal/mcp"
	"agentgate/internal/signed"
	"agentgate/internal/simulator"
)

// --- the synthetic world -----------------------------------------------------

const (
	worldOrganization = "Example Logistics"
	worldTenant       = "example-logistics"
	worldPrincipal    = "agent.eval-assistant"
	worldIssuer       = "https://idp.example-logistics.example"
	worldTask         = "task.eval-revision"
	worldMediaType    = "text/plain"

	// outOfScopePayee is in the catalog but never in the default grant.
	outOfScopePayee = "payee.travel-agency"

	providerKeyFormat     = "agentgate-provider-key/v1"
	providerJournalFormat = "agentgate-provider-journal/v1"
	runFormat             = "agentgate-demo-run/v1"
)

// worldRecipient, worldPayee and worldDocument use the JSON shape of the demo
// catalog (run.json "catalog"), which the verifier's policy replay reads.
type worldRecipient struct {
	ID       string `json:"id"`
	Address  string `json:"address"`
	External bool   `json:"external"`
	Display  string `json:"display"`
}

type worldPayee struct {
	ID      string `json:"id"`
	Display string `json:"display"`
}

type worldDocument struct {
	Name           string `json:"-"`
	Filename       string `json:"filename"`
	Classification string `json:"classification"`
	SHA256         string `json:"sha256"`
	Text           string `json:"-"`
	digest         [32]byte
}

// The confidential contract is long enough for several 12-word shingles; the
// misuse experiment copies parts of it into messages.
const (
	brochureText = "Example Logistics moves freight between the port, the free zone and inland warehouses. " +
		"We offer next day delivery, cold storage and customs brokerage for small and medium businesses."
	summaryText = "Third quarter operations summary for internal use. On time delivery reached ninety four percent. " +
		"Warehouse two will close for maintenance during the second week of November."
	contractText = "Confidential supply agreement between Example Logistics and Harbor Retail Group. " +
		"Harbor Retail Group commits to a minimum annual volume of four thousand two hundred pallets at a " +
		"negotiated rate of eleven dirhams per pallet per day for cold storage. Either party may terminate the " +
		"agreement with ninety days written notice. The negotiated rate and the volume commitment must not be " +
		"disclosed to any other customer or carrier under any circumstances."
	payrollText = "Restricted payroll register for October. Basic salaries, housing allowances and bonus amounts " +
		"for all forty seven employees of the operations department are listed below and must stay within " +
		"the finance team."
)

type world struct {
	Recipients []worldRecipient `json:"recipients"`
	Payees     []worldPayee     `json:"payees"`
	Documents  []worldDocument  `json:"documents"`
	registry   [32]byte
}

func newWorld() (*world, error) {
	w := &world{
		Recipients: []worldRecipient{
			{ID: "ops.lead", Address: "ops.lead@example-logistics.example", Display: "Operations lead"},
			{ID: "finance.manager", Address: "finance.manager@example-logistics.example", Display: "Finance manager"},
			{ID: "legal.counsel", Address: "legal.counsel@example-logistics.example", Display: "Legal counsel"},
			{ID: "partner.carrier", Address: "dispatch@carrier-partner.example", External: true, Display: "Carrier partner"},
			{ID: "auditor.external", Address: "audit@external-auditor.example", External: true, Display: "External auditor"},
			{ID: "customer.retail", Address: "orders@harbor-retail.example", External: true, Display: "Retail customer"},
		},
		Payees: []worldPayee{
			{ID: "payee.office-supplies", Display: "Office Supplies Trading LLC"},
			{ID: "payee.carrier", Display: "Carrier Partner Shipping"},
			{ID: "payee.it-services", Display: "IT Services FZE"},
			{ID: outOfScopePayee, Display: "Travel Agency LLC"},
		},
		Documents: []worldDocument{
			{Name: "brochure", Filename: "example-brochure.txt", Classification: "public", Text: brochureText},
			{Name: "summary", Filename: "q3-operations-summary.txt", Classification: "internal", Text: summaryText},
			{Name: "contract", Filename: "harbor-retail-contract.txt", Classification: "confidential", Text: contractText},
			{Name: "payroll", Filename: "payroll-october.txt", Classification: "restricted", Text: payrollText},
		},
	}
	rows := make([]any, 0, len(w.Recipients)+len(w.Payees)+len(w.Documents))
	for _, recipient := range w.Recipients {
		rows = append(rows, []any{"recipient", recipient.ID, recipient.Address, recipient.External})
	}
	for _, payee := range w.Payees {
		rows = append(rows, []any{"payee", payee.ID, payee.Display})
	}
	for index := range w.Documents {
		document := &w.Documents[index]
		document.digest = effects.BlobDigest([]byte(document.Text))
		document.SHA256 = hex.EncodeToString(document.digest[:])
		rows = append(rows, []any{"document", document.Filename, document.Classification, document.SHA256})
	}
	// The catalog commitment uses the demo run format's recipe and label
	// (internal/demo catalog.registryHash), which the verifier recomputes
	// from run.json (check policy.snapshot_bound).
	registry, err := canon.HashObject("AgentGate/DemoRegistrySnapshot/v1", rows)
	if err != nil {
		return nil, err
	}
	w.registry = registry
	return w, nil
}

func (w *world) identity() mcp.Identity {
	return mcp.Identity{
		TenantID: worldTenant, PrincipalID: worldPrincipal, Issuer: worldIssuer,
		Roles: []string{"MEMBER"}, AuthEpoch: 1,
		TokenHash: sha256.Sum256([]byte("AgentGate/Eval/AgentToken/v1")),
	}
}

func (w *world) gatewayInputs() (map[string]effects.Recipient, map[[32]byte]devcomposition.Blob, map[string]string) {
	recipients := make(map[string]effects.Recipient, len(w.Recipients))
	for _, recipient := range w.Recipients {
		recipients[recipient.ID] = effects.Recipient{PrincipalID: recipient.ID, DeliveryAddress: recipient.Address, External: recipient.External}
	}
	blobs := make(map[[32]byte]devcomposition.Blob, len(w.Documents))
	for _, document := range w.Documents {
		blobs[document.digest] = devcomposition.Blob{
			Data: []byte(document.Text), MediaType: worldMediaType, Filename: document.Filename, Classification: document.Classification,
		}
	}
	payees := make(map[string]string, len(w.Payees))
	for _, payee := range w.Payees {
		payees[payee.ID] = payee.Display
	}
	return recipients, blobs, payees
}

func (w *world) document(name string) worldDocument {
	for _, document := range w.Documents {
		if document.Name == name {
			return document
		}
	}
	panic("eval world has no document " + name)
}

func (w *world) recipientIDs() []string {
	ids := make([]string, len(w.Recipients))
	for index, recipient := range w.Recipients {
		ids[index] = recipient.ID
	}
	return ids
}

// revisionPolicy is the demo's revision policy for this world.
func revisionPolicy(escalation devcomposition.Escalation) devcomposition.ContentPolicy {
	policy := devcomposition.RevisionContentPolicy()
	policy.OrganizationName = worldOrganization
	policy.Escalation = escalation
	return policy
}

// --- the delegation grant ------------------------------------------------------

// grantSpec is what the organisation delegates. Budgets are cumulative minor
// units per currency; MaxCounts are executed operations per effect type.
type grantSpec struct {
	EffectTypes []string          `json:"effect_types"`
	Recipients  []string          `json:"recipients"`
	Payees      []string          `json:"payees"`
	Budgets     map[string]uint64 `json:"budgets"`
	MaxCounts   map[string]uint64 `json:"max_counts"`
	NotBefore   time.Time         `json:"not_before"`
	ExpiresAt   time.Time         `json:"expires_at"`
}

var allEffectTypes = []string{string(effects.DocumentRelease), string(effects.ExternalMessageSend), string(effects.FinancialRequestCreate)}

// openGrant delegates everything in the world except outOfScopePayee, with
// budgets and counts large enough never to bind (crash, concurrency, load).
func (w *world) openGrant(now time.Time) grantSpec {
	payees := []string{}
	for _, payee := range w.Payees {
		if payee.ID != outOfScopePayee {
			payees = append(payees, payee.ID)
		}
	}
	return grantSpec{
		EffectTypes: append([]string(nil), allEffectTypes...), Recipients: w.recipientIDs(), Payees: payees,
		Budgets:   map[string]uint64{"AED": 1_000_000_000_000, "USD": 1_000_000_000_000},
		MaxCounts: map[string]uint64{string(effects.DocumentRelease): 1_000_000_000, string(effects.ExternalMessageSend): 1_000_000_000, string(effects.FinancialRequestCreate): 1_000_000_000},
		NotBefore: now.Add(-time.Minute), ExpiresAt: now.Add(24 * time.Hour),
	}
}

type signedGrant struct {
	grant  devcomposition.DelegationGrant
	signed []byte
	hash   [32]byte
	signer signed.Signer
	config devcomposition.DelegationConfig
}

func signGrant(label string, spec grantSpec) (*signedGrant, error) {
	signer, public, err := devcomposition.NewDelegationAuthorityKey()
	if err != nil {
		return nil, err
	}
	grant := devcomposition.DelegationGrant{
		Version: 1, GrantID: "grant-" + label, Issuer: worldOrganization + " operations management (organisation key)",
		TenantID: worldTenant, Delegate: worldPrincipal, Purpose: "Evaluation workload of the AgentGate revision experiments.",
		EffectTypes: append([]string(nil), spec.EffectTypes...), Recipients: append([]string(nil), spec.Recipients...),
		Payees: append([]string(nil), spec.Payees...), Budgets: spec.Budgets, MaxCounts: spec.MaxCounts,
		NotBefore: uint64(spec.NotBefore.Unix()), ExpiresAt: uint64(spec.ExpiresAt.Unix()),
	}
	raw, err := devcomposition.SignDelegationGrant(grant, signer)
	if err != nil {
		return nil, err
	}
	hash, err := devcomposition.DelegationGrantHash(grant)
	if err != nil {
		return nil, err
	}
	return &signedGrant{grant: grant, signed: raw, hash: hash, signer: signer,
		config: devcomposition.DelegationConfig{SignedGrant: raw, AuthorityKID: signer.KID, AuthorityPublic: public}}, nil
}

// --- run identity --------------------------------------------------------------

type runIdentity struct {
	Label        string
	ID           [16]byte
	InitialState [32]byte
}

func newRunIdentity(label string) (runIdentity, error) {
	run := runIdentity{Label: label}
	if _, err := rand.Read(run.ID[:]); err != nil {
		return runIdentity{}, err
	}
	raw, err := canon.Encode(map[int64]any{0: uint64(1), 1: run.ID, 2: simulator.SimulatorID, 3: []any{}})
	if err != nil {
		return runIdentity{}, err
	}
	if run.InitialState, err = canon.Hash("AgentGate/SimulatorState/v1", raw); err != nil {
		return runIdentity{}, err
	}
	return run, nil
}

// --- the provider host ----------------------------------------------------------

// simClock is the simulator's trusted clock (wall seconds, strictly advancing
// generation), like the gateway's in-process one.
type simClock struct{ generation atomic.Uint64 }

func (clock *simClock) ReadClock() (simulator.ClockReading, error) {
	return simulator.ClockReading{UnixSeconds: uint64(time.Now().Unix()), Generation: clock.generation.Add(1)}, nil
}

// providerHost is a provider "process" hosted by the harness: its own key and
// simulator state behind its own loopback listener. It is not the gateway's
// and survives any number of gateway restarts. Its state is in memory: it is
// a provider that does not crash in these experiments.
type providerHost struct {
	run      runIdentity
	origin   string
	kid      [32]byte
	public   ed25519.PublicKey
	runtime  *simulator.Runtime
	server   *http.Server
	done     chan error
	requests atomic.Int64 // dispatch and status requests served
}

var providerReceiptProfile = signed.Profile{
	ContentType: "application/agentgate-provider-receipt+cbor", Token: "SimulatorReceipt", Role: "SIMULATOR_PROVIDER",
}

func startProviderHost(w *world, run runIdentity, faults map[[32]byte][]simulator.Fault) (*providerHost, error) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return nil, err
	}
	public, private, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		listener.Close()
		return nil, err
	}
	kid, err := simulator.ProviderKID(public)
	if err != nil {
		listener.Close()
		return nil, err
	}
	runtime, err := simulator.New(simulator.Config{
		Environment: simulator.EnvironmentDEV, RunID: run.ID, TaskID: worldTask,
		TenantID: worldTenant, PrincipalID: worldPrincipal,
		RegistrySnapshotObjectHash: w.registry, InitialStateObjectHash: run.InitialState,
		Signer: signed.Signer{KID: kid, Role: "SIMULATOR_PROVIDER", Private: private}, Clock: &simClock{},
		Faults: faults,
	})
	if err != nil {
		listener.Close()
		return nil, err
	}
	handler, err := simulator.NewHandler(runtime, simulator.HandlerConfig{AllowedHost: listener.Addr().String()})
	if err != nil {
		listener.Close()
		return nil, err
	}
	host := &providerHost{run: run, origin: "http://" + listener.Addr().String(), kid: kid, public: public, runtime: runtime, done: make(chan error, 1)}
	keyDocument := devcomposition.ProviderKeyDocument{
		Format: providerKeyFormat, Role: "SIMULATOR_PROVIDER", Alg: "Ed25519",
		KID: hex.EncodeToString(kid[:]), PublicKey: base64.StdEncoding.EncodeToString(public),
		Run: devcomposition.ProviderRunSummary{
			RunID: hex.EncodeToString(run.ID[:]), RunLabel: run.Label, SimulatorID: simulator.SimulatorID,
			TaskID: worldTask, TenantID: worldTenant, PrincipalID: worldPrincipal,
			RegistrySnapshotObjectHash: hex.EncodeToString(w.registry[:]),
			InitialStateObjectHash:     hex.EncodeToString(run.InitialState[:]),
		},
	}
	mux := http.NewServeMux()
	mux.HandleFunc("GET /key", func(writer http.ResponseWriter, _ *http.Request) {
		writer.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(writer).Encode(keyDocument)
	})
	mux.HandleFunc("GET /journal", func(writer http.ResponseWriter, _ *http.Request) {
		document, err := host.journalDocument(run.Label)
		if err != nil {
			http.Error(writer, err.Error(), http.StatusInternalServerError)
			return
		}
		writer.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(writer).Encode(document)
	})
	mux.Handle("POST /", http.HandlerFunc(func(writer http.ResponseWriter, request *http.Request) {
		host.requests.Add(1)
		handler.ServeHTTP(writer, request)
	}))
	host.server = &http.Server{Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	go func() { host.done <- host.server.Serve(listener) }()
	return host, nil
}

func (p *providerHost) external() *devcomposition.ExternalProviderConfig {
	return &devcomposition.ExternalProviderConfig{Origin: p.origin, KID: p.kid, PublicKey: append(ed25519.PublicKey(nil), p.public...)}
}

func (p *providerHost) close() {
	if p == nil || p.server == nil {
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	_ = p.server.Shutdown(ctx)
	<-p.done
	p.server = nil
}

// providerJournalDocument is provider-journal.json (CONTRACTS section 5.5).
type providerJournalDocument struct {
	Format      string                 `json:"format"`
	RunID       string                 `json:"run_id"`
	SimulatorID string                 `json:"simulator_id"`
	CommitSeq   uint64                 `json:"commit_seq"`
	StateHash   string                 `json:"state_hash"`
	Entries     []providerJournalEntry `json:"entries"`
}

type providerJournalEntry struct {
	CommitSeq     uint64 `json:"commit_seq"`
	SignedReceipt string `json:"signed_receipt"`
}

func (p *providerHost) journalDocument(runLabel string) (providerJournalDocument, error) {
	snapshot, err := p.runtime.Snapshot()
	if err != nil {
		return providerJournalDocument{}, err
	}
	document := providerJournalDocument{
		Format: providerJournalFormat, RunID: runLabel, SimulatorID: snapshot.SimulatorID,
		CommitSeq: snapshot.CurrentCommitSeq, StateHash: hex.EncodeToString(snapshot.CanonicalStateHash[:]),
		Entries: []providerJournalEntry{},
	}
	sequences := make([]uint64, 0, len(snapshot.Journal))
	for sequence := range snapshot.Journal {
		sequences = append(sequences, sequence)
	}
	sort.Slice(sequences, func(left, right int) bool { return sequences[left] < sequences[right] })
	for _, sequence := range sequences {
		document.Entries = append(document.Entries, providerJournalEntry{CommitSeq: sequence, SignedReceipt: base64.StdEncoding.EncodeToString(snapshot.Journal[sequence])})
	}
	return document, nil
}

// providerCommit is one effect the provider committed, from its own signed
// journal (every receipt is verified under the provider key).
type providerCommit struct {
	Seq          uint64 `json:"commit_seq"`
	OperationID  string `json:"operation_id"`
	EffectType   string `json:"effect_type"`
	EffectDigest string `json:"effect_digest"`
	Reference    string `json:"provider_reference"`
}

type singleKey struct {
	kid    [32]byte
	public ed25519.PublicKey
	role   string
}

func (key singleKey) Resolve(kid [32]byte, role string, _ uint64) (ed25519.PublicKey, bool) {
	if kid != key.kid || role != key.role {
		return nil, false
	}
	return key.public, true
}

func (p *providerHost) commits() ([]providerCommit, error) {
	snapshot, err := p.runtime.Snapshot()
	if err != nil {
		return nil, err
	}
	resolver := singleKey{kid: p.kid, public: p.public, role: providerReceiptProfile.Role}
	out := make([]providerCommit, 0, len(snapshot.Journal))
	for sequence, envelope := range snapshot.Journal {
		var receipt simulator.SimulatorReceipt
		if _, err := signed.Verify(envelope, providerReceiptProfile, resolver, 0, &receipt); err != nil {
			return nil, fmt.Errorf("provider journal entry %d: %w", sequence, err)
		}
		out = append(out, providerCommit{
			Seq: sequence, OperationID: opText(receipt.OperationID), EffectType: string(receipt.EffectType),
			EffectDigest: hex.EncodeToString(receipt.EffectDigest[:]), Reference: receipt.ProviderReference,
		})
	}
	sort.Slice(out, func(left, right int) bool { return out[left].Seq < out[right].Seq })
	return out, nil
}

// commitsByOperation counts provider commits per operation ID.
func commitsByOperation(commits []providerCommit) map[string]int {
	out := map[string]int{}
	for _, commit := range commits {
		out[commit.OperationID]++
	}
	return out
}

// --- operation IDs and tool arguments ---------------------------------------------

func newOperationID() [16]byte {
	var id [16]byte
	for id == [16]byte{} {
		if _, err := rand.Read(id[:]); err != nil {
			panic("crypto/rand failed: " + err.Error())
		}
	}
	return id
}

func opText(id [16]byte) string {
	if id == [16]byte{} {
		return ""
	}
	return base64.RawURLEncoding.EncodeToString(id[:])
}

func paymentArgs(operation [16]byte, payee string, amount any, currency, purpose string) map[string]any {
	return map[string]any{"operation_id": opText(operation), "payee_id": payee, "amount_minor": amount, "currency": currency, "purpose": purpose}
}

func messageArgs(operation [16]byte, to []string, subject, body string) map[string]any {
	return map[string]any{"operation_id": opText(operation), "to": append([]string(nil), to...), "subject": subject, "body": body}
}

func documentArgs(operation [16]byte, sha string, recipients []string, permission string) map[string]any {
	return map[string]any{"operation_id": opText(operation), "document_blob_sha256": sha, "recipients": append([]string(nil), recipients...), "permission": permission}
}

const (
	toolPayment  = string(effects.FinancialRequestCreate)
	toolMessage  = string(effects.ExternalMessageSend)
	toolDocument = string(effects.DocumentRelease)
)

// --- the gateway ------------------------------------------------------------------

type gatewaySpec struct {
	Escalation devcomposition.Escalation // empty: flag (autonomous)
	Faults     devcomposition.FaultInjector
	Journal    string
	Sink       *evidenceRun // nil: audit disabled (Config.Audit nil)
	Grant      *signedGrant // nil: no delegation grant
	Unbound    bool
}

type gateway struct {
	comp   *devcomposition.Composition
	bearer string
	config devcomposition.Config
}

func randomToken() string {
	var raw [32]byte
	if _, err := rand.Read(raw[:]); err != nil {
		panic("crypto/rand failed: " + err.Error())
	}
	return base64.RawURLEncoding.EncodeToString(raw[:])
}

func buildGateway(ctx context.Context, w *world, run runIdentity, provider *providerHost, spec gatewaySpec) (*gateway, error) {
	bearer := randomToken()
	secret, err := devcomposition.NewGatewayBearerSecret(bearer)
	if err != nil {
		return nil, err
	}
	escalation := spec.Escalation
	if escalation == "" {
		escalation = devcomposition.EscalationFlag
	}
	if escalation == devcomposition.EscalationHuman {
		return nil, errors.New("the harness runs the autonomous modes only (flag or deny)")
	}
	policy := revisionPolicy(escalation)
	recipients, blobs, payees := w.gatewayInputs()
	config := devcomposition.Config{
		Identity: w.identity(), GatewayBearer: secret, SimulatorOrigin: provider.origin,
		RunID: run.ID, TaskID: worldTask,
		RegistrySnapshotObjectHash: w.registry, InitialStateObjectHash: run.InitialState,
		Recipients: recipients, Blobs: blobs, PayeeDisplayNames: payees,
		ContentPolicy: &policy, OperationJournal: spec.Journal, Faults: spec.Faults,
		ExternalProvider: provider.external(),
		Experiment:       devcomposition.ExperimentConfig{UnboundFlags: spec.Unbound},
		HostLabel:        hostLabelOption,
	}
	if spec.Sink != nil {
		config.Audit = spec.Sink // never a typed nil in the interface
	}
	if spec.Grant != nil {
		delegation := spec.Grant.config
		config.Delegation = &delegation
	}
	comp, err := devcomposition.New(ctx, config)
	if err != nil {
		return nil, err
	}
	return &gateway{comp: comp, bearer: bearer, config: config}, nil
}

func (g *gateway) caller() *mcpCaller { return &mcpCaller{handler: g.comp.MCP, bearer: g.bearer} }

// operationStates indexes Composition.Operations by operation ID text.
func (g *gateway) operationStates() map[string]devcomposition.OperationState {
	out := map[string]devcomposition.OperationState{}
	for _, state := range g.comp.Operations() {
		out[opText(state.OperationID)] = state
	}
	return out
}

// --- the MCP client ----------------------------------------------------------------

// mcpCaller sends JSON-RPC tools/call requests to a gateway: in process
// through handler, or over HTTP to url.
type mcpCaller struct {
	handler http.Handler
	url     string
	client  *http.Client
	bearer  string
}

// callResult is what the agent saw.
type callResult struct {
	HTTPStatus        int    `json:"http_status"`
	Error             string `json:"error,omitempty"`
	IsError           bool   `json:"is_error"`
	Status            string `json:"status"`
	Reason            string `json:"reason,omitempty"`
	Dispatched        bool   `json:"dispatched"`
	Outcome           string `json:"outcome,omitempty"`
	ProviderReference string `json:"provider_reference,omitempty"`
	// NoStatus marks an HTTP 200 tool result without structuredContent.status
	// (for example the MCP layer's generic "call denied").
	NoStatus   bool           `json:"no_status,omitempty"`
	Structured map[string]any `json:"-"`
}

func toolCallBody(tool string, arguments map[string]any) ([]byte, error) {
	return json.Marshal(map[string]any{
		"jsonrpc": "2.0", "id": 1, "method": "tools/call",
		"params": map[string]any{
			"name": tool, "arguments": arguments,
			"_meta": map[string]any{
				"io.modelcontextprotocol/protocolVersion":    mcp.ProtocolVersion,
				"io.modelcontextprotocol/clientCapabilities": map[string]any{},
				"io.modelcontextprotocol/clientInfo":         map[string]any{"name": "agentgate-eval", "version": "1"},
			},
		},
	})
}

func setToolHeaders(header http.Header, tool, bearer string) {
	header.Set("Content-Type", "application/json")
	header.Set("Accept", "application/json, text/event-stream")
	header.Set("MCP-Protocol-Version", mcp.ProtocolVersion)
	header.Set("Mcp-Method", "tools/call")
	header.Set("Mcp-Name", tool)
	if bearer != "" {
		header.Set("Authorization", "Bearer "+bearer)
	}
}

func (c *mcpCaller) call(ctx context.Context, tool string, arguments map[string]any) callResult {
	body, err := toolCallBody(tool, arguments)
	if err != nil {
		return callResult{Error: "encode: " + err.Error()}
	}
	if c.handler != nil {
		request := httptest.NewRequestWithContext(ctx, http.MethodPost, "http://gateway.eval/mcp", bytes.NewReader(body))
		setToolHeaders(request.Header, tool, c.bearer)
		response := httptest.NewRecorder()
		c.handler.ServeHTTP(response, request)
		return parseCallResponse(response.Code, response.Body.Bytes())
	}
	request, err := http.NewRequestWithContext(ctx, http.MethodPost, c.url, bytes.NewReader(body))
	if err != nil {
		return callResult{Error: err.Error()}
	}
	setToolHeaders(request.Header, tool, c.bearer)
	response, err := c.client.Do(request)
	if err != nil {
		return callResult{Error: "transport: " + err.Error()}
	}
	defer response.Body.Close()
	raw, err := io.ReadAll(io.LimitReader(response.Body, 8<<20))
	if err != nil {
		return callResult{HTTPStatus: response.StatusCode, Error: "read: " + err.Error()}
	}
	return parseCallResponse(response.StatusCode, raw)
}

func parseCallResponse(status int, body []byte) callResult {
	result := callResult{HTTPStatus: status}
	if status != http.StatusOK {
		result.Error = fmt.Sprintf("HTTP %d: %s", status, strings.TrimSpace(string(body)))
		return result
	}
	var rpc struct {
		Error *struct {
			Code    int64  `json:"code"`
			Message string `json:"message"`
		} `json:"error"`
		Result struct {
			IsError           bool           `json:"isError"`
			StructuredContent map[string]any `json:"structuredContent"`
			Content           []struct {
				Type string `json:"type"`
				Text string `json:"text"`
			} `json:"content"`
		} `json:"result"`
	}
	if err := json.Unmarshal(body, &rpc); err != nil {
		result.Error = "decode: " + err.Error()
		return result
	}
	if rpc.Error != nil {
		result.Error = fmt.Sprintf("JSON-RPC %d: %s", rpc.Error.Code, rpc.Error.Message)
		return result
	}
	result.IsError = rpc.Result.IsError
	structured := rpc.Result.StructuredContent
	result.Structured = structured
	result.Status, _ = structured["status"].(string)
	result.Reason, _ = structured["reason"].(string)
	result.Dispatched, _ = structured["dispatched"].(bool)
	result.Outcome, _ = structured["outcome"].(string)
	result.ProviderReference, _ = structured["provider_reference"].(string)
	if result.Status == "" && result.Error == "" {
		// A tool error without structuredContent.status: AgentGate's MCP layer
		// (internal/mcp/official.go, e.g. the generic "call denied") refused
		// the call outside the operation lifecycle. The agent gets only the
		// text. (Invalid arguments are answered REJECTED / invalid_request.)
		text := ""
		for _, content := range rpc.Result.Content {
			text += content.Text
		}
		result.NoStatus = true
		result.Error = "no structuredContent.status (isError=" + fmt.Sprint(rpc.Result.IsError) + "): " + text
	}
	return result
}

// statusKey is "STATUS/reason" (or "ERROR: ..." when no status came back).
func (r callResult) statusKey() string {
	if r.Status == "" {
		return "ERROR"
	}
	return r.Status + "/" + r.Reason
}

// --- the evidence folder ------------------------------------------------------------

// evidenceRun is the gateway's audit sink. With a directory it writes a run
// folder in the demo's format through the signed, hash-chained audit log
// (durable writes, fsync); without one it only keeps the events in memory.
// Either way every event is also kept in memory for the experiment.
type evidenceRun struct {
	dir   string
	label string
	log   *audit.Log

	mu      sync.Mutex
	begun   bool
	pending []audit.Event
	events  []devcomposition.AuditEvent

	keysSHA256 string
	headSeq    uint64
	headHash   string
	closed     bool

	// continues names the evidence segment this one continues after a
	// gateway restart on the operation journal (nil for a first segment);
	// see continueFrom and internal/audit continuation.go.
	continues *audit.Continuation
}

// continueFrom marks r as the continuation of the closed segment previous:
// run.json and RUN_STARTED will carry "continues" with previous's run ID,
// its folder relative to r's, and the final head and keys fingerprint the
// harness pinned for it (held in memory, never re-read from the folder). It
// must be called before begin.
func (r *evidenceRun) continueFrom(previous *evidenceRun) error {
	if previous == nil || previous.log == nil || r.log == nil {
		return nil
	}
	previous.mu.Lock()
	closed, head, keys := previous.closed, previous.headHash, previous.keysSHA256
	previous.mu.Unlock()
	if !closed {
		return errors.New("the previous evidence segment must be closed before its continuation begins")
	}
	continuation, err := audit.NewContinuation(previous.label, previous.dir, r.dir, head, keys)
	if err != nil {
		return err
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	r.continues = &continuation
	return nil
}

// hostLabelOption replaces the machine name wherever the harness's evidence
// records where it ran (run.json "host", the RUN_STARTED location and the
// gateway's audit locations through devcomposition.Config.HostLabel, and the
// demo runs through HostLabel). Empty means the real host name. It is set by
// the global -host-label option (main.go).
var hostLabelOption string

// evidenceHost is the host name the evidence records.
func evidenceHost() string {
	if hostLabelOption != "" {
		return hostLabelOption
	}
	host, _ := os.Hostname()
	return host
}

func newEvidenceRun(dir, label string) (*evidenceRun, error) {
	run := &evidenceRun{dir: dir, label: label}
	if dir == "" {
		return run, nil
	}
	log, err := audit.Create(audit.Options{Dir: dir, RunID: label})
	if err != nil {
		return nil, err
	}
	run.log = log
	return run, nil
}

func auditEventFor(event devcomposition.AuditEvent) audit.Event {
	digest := ""
	if event.EffectDigest != [32]byte{} {
		digest = hex.EncodeToString(event.EffectDigest[:])
	}
	return audit.Event{
		Stage: event.Stage, Actor: event.Actor, Component: event.Component, Location: event.Location,
		Outcome: event.Outcome, Summary: event.Summary, OperationID: opText(event.OperationID),
		EffectType: event.EffectType, EffectDigest: digest, Details: event.Details, Artifacts: event.Artifacts,
	}
}

// Record implements devcomposition.AuditSink.
func (r *evidenceRun) Record(event devcomposition.AuditEvent) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.closed {
		return errors.New("evidence run is closed")
	}
	r.events = append(r.events, event)
	if r.log == nil {
		return nil
	}
	converted := auditEventFor(event)
	if converted.Location == "" {
		converted.Location = "agentgate-eval harness"
	}
	if !r.begun {
		r.pending = append(r.pending, converted)
		return nil
	}
	_, err := r.log.Append(converted)
	return err
}

// evalRunDocument is run.json in the demo's format (CONTRACTS section 5.4).
type evalRunDocument struct {
	Format          string                        `json:"format"`
	Producer        string                        `json:"producer"`
	RunID           string                        `json:"run_id"`
	StartedAt       string                        `json:"started_at"`
	Host            string                        `json:"host"`
	PID             int                           `json:"pid"`
	Identity        map[string]string             `json:"identity"`
	Policy          devcomposition.PolicyInfo     `json:"policy"`
	PolicySnapshot  devcomposition.PolicySnapshot `json:"policy_snapshot"`
	Delegation      map[string]any                `json:"delegation,omitempty"`
	Catalog         *world                        `json:"catalog"`
	KeysSHA256      string                        `json:"keys_sha256"`
	SimulatorOrigin string                        `json:"simulator_origin"`
	Custody         map[string]any                `json:"custody"`
	Continues       *audit.Continuation           `json:"continues,omitempty"`
}

// begin writes keys.json and run.json, records RUN_STARTED and
// DELEGATION_GRANTED, then the events the gateway recorded before (none in
// practice). It must run after the gateway is built and before any call.
func (r *evidenceRun) begin(w *world, g *gateway, grant *signedGrant, note string) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.log == nil {
		r.begun = true
		return nil
	}
	auditKID, auditPublic := r.log.PublicKey()
	keys := []audit.Key{audit.NewKey(auditKID, audit.RoleAuditLog, audit.AuditKeyPurpose, auditPublic)}
	for _, key := range g.comp.PublicKeys() {
		keys = append(keys, audit.NewKey(key.KID, key.Role, key.Purpose, key.Public))
	}
	keysSHA, err := audit.WriteKeys(r.dir, audit.KeysDocument{Format: audit.KeysFormat, RunID: r.label, Keys: keys})
	if err != nil {
		return err
	}
	r.keysSHA256 = keysSHA
	policy := g.comp.Policy()
	host := evidenceHost()
	document := evalRunDocument{
		Format: runFormat, Producer: "cmd/agentgate-eval harness (" + note + ")",
		RunID: r.label, StartedAt: time.Now().UTC().Format(time.RFC3339Nano), Host: host, PID: os.Getpid(),
		Identity: map[string]string{"tenant_id": worldTenant, "principal_id": worldPrincipal, "task_id": worldTask},
		Policy:   policy, PolicySnapshot: g.comp.PolicySnapshot(), Catalog: w, KeysSHA256: keysSHA,
		SimulatorOrigin: g.config.SimulatorOrigin, Custody: map[string]any{"provider_process": true, "witness": false},
		Continues: r.continues,
	}
	if grant != nil {
		document.Delegation = map[string]any{
			"grant_id": grant.grant.GrantID, "grant_hash": hex.EncodeToString(grant.hash[:]),
			"authority_kid": hex.EncodeToString(grant.signer.KID[:]), "signed_grant": base64.StdEncoding.EncodeToString(grant.signed),
		}
	}
	runSHA, err := audit.WriteJSONAtomicSHA256(filepath.Join(r.dir, audit.RunFile), document)
	if err != nil {
		return err
	}
	location := fmt.Sprintf("agentgate-eval (pid %d) @ %s", os.Getpid(), host)
	summary := "Evaluation run started (" + note + ")."
	details := map[string]any{
		"keys_sha256": keysSHA, "run_sha256": runSHA, "policy_hash": policy.HashHex, "policy_name": policy.Name,
		"catalog":          map[string]int{"recipients": len(w.Recipients), "payees": len(w.Payees), "documents": len(w.Documents)},
		"simulator_origin": g.config.SimulatorOrigin, "escalation": policy.Escalation,
		"operation_journal": g.config.OperationJournal != "",
	}
	if r.continues != nil {
		// A continuation segment (gateway restarted on the operation
		// journal): the same record as run.json, signed by this segment's
		// audit key, as the demo records it (internal/demo/server.go).
		restored := len(g.comp.Operations())
		summary = fmt.Sprintf("Gateway restarted on the operation journal (%s): this evidence segment continues run %s (%d operation(s) restored from the journal), with new per-run keys.",
			note, r.continues.RunID, restored)
		details[audit.ContinuesField] = r.continues.Map()
		details["restored_operations"] = restored
	}
	if _, err := r.log.Append(audit.Event{
		Stage: "RUN_STARTED", Actor: "system", Component: "eval/run", Location: location, Outcome: "info",
		Summary: summary, Details: details,
	}); err != nil {
		return err
	}
	if grant != nil {
		if _, err := r.log.Append(audit.Event{
			Stage: "DELEGATION_GRANTED", Actor: "organisation:" + worldTenant, Component: "eval/delegation", Location: location, Outcome: "info",
			Summary: "Bounded autonomy delegated for the evaluation run.",
			Details: map[string]any{
				"grant_id": grant.grant.GrantID, "grant_hash": hex.EncodeToString(grant.hash[:]), "authority_kid": hex.EncodeToString(grant.signer.KID[:]),
				"purpose": grant.grant.Purpose, "effect_types": grant.grant.EffectTypes, "recipients": grant.grant.Recipients, "payees": grant.grant.Payees,
				"budgets": grant.grant.Budgets, "max_counts": grant.grant.MaxCounts, "nbf": grant.grant.NotBefore, "exp": grant.grant.ExpiresAt,
			},
			Artifacts: map[string][]byte{"delegation_grant": grant.signed},
		}); err != nil {
			return err
		}
		if status, ok := g.comp.DelegationStatus(); ok && status.Revoked && r.continues != nil {
			// The grant was revoked in an earlier segment and the restarted
			// gateway restored the revocation from its journal: record it
			// before any decision of this segment (as the demo does).
			if _, err := r.log.Append(audit.Event{
				Stage: "DELEGATION_REVOKED", Actor: "organisation:" + worldTenant, Component: "eval/delegation", Outcome: "info",
				Location: location,
				Summary:  "Grant " + grant.grant.GrantID + " stays revoked: it was revoked in an earlier segment and the restarted gateway restored the revocation from its operation journal.",
				Details:  map[string]any{"grant_id": grant.grant.GrantID, "grant_hash": hex.EncodeToString(grant.hash[:]), "restored": true},
			}); err != nil {
				return err
			}
		}
	}
	r.begun = true
	for _, event := range r.pending {
		if _, err := r.log.Append(event); err != nil {
			return err
		}
	}
	r.pending = nil
	return nil
}

// finish writes provider-journal.json (the provider's own record, read from
// the provider host) and closes the log. The keys fingerprint and the final
// head are the trust anchors the harness holds outside the folder.
func (r *evidenceRun) finish(provider *providerHost) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.closed {
		return nil
	}
	r.closed = true
	if r.log == nil {
		return nil
	}
	var errs []error
	if provider != nil {
		document, err := provider.journalDocument(r.label)
		if err == nil {
			err = audit.WriteJSONAtomic(filepath.Join(r.dir, audit.ProviderJournalFile), document)
		}
		errs = append(errs, err)
	}
	r.headSeq, r.headHash = r.log.Head()
	errs = append(errs, r.log.Close())
	return errors.Join(errs...)
}

// recordRevocation writes DELEGATION_REVOKED exactly as the demo does before
// it revokes the grant in the gateway (internal/demo/delegation.go), so the
// verifier's policy replay knows from when on DEL-REVOKED applies.
func (r *evidenceRun) recordRevocation(grant *signedGrant) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.log == nil || grant == nil {
		return nil
	}
	_, err := r.log.Append(audit.Event{
		Stage: "DELEGATION_REVOKED", Actor: "organisation:" + worldTenant, Component: "eval/delegation", Outcome: "info",
		Location: "agentgate-eval harness",
		Summary:  "The organisation revoked grant " + grant.grant.GrantID + ": from now on nothing more may run under it.",
		Details:  map[string]any{"grant_id": grant.grant.GrantID, "grant_hash": hex.EncodeToString(grant.hash[:])},
	})
	return err
}

// stagesFor returns the stages recorded for one operation, in order.
func (r *evidenceRun) stagesFor(operation string) []string {
	r.mu.Lock()
	defer r.mu.Unlock()
	var out []string
	for _, event := range r.events {
		if opText(event.OperationID) == operation {
			out = append(out, event.Stage)
		}
	}
	return out
}

func (r *evidenceRun) eventsFor(operation string) []devcomposition.AuditEvent {
	r.mu.Lock()
	defer r.mu.Unlock()
	var out []devcomposition.AuditEvent
	for _, event := range r.events {
		if opText(event.OperationID) == operation {
			out = append(out, event)
		}
	}
	return out
}

// evidencesEffect reports whether the operation's audit trail in this run
// accounts for a provider effect: EFFECT_EXECUTED, or RECONCILED with outcome
// committed.
func (r *evidenceRun) evidencesEffect(operation string) bool {
	for _, event := range r.eventsFor(operation) {
		if event.Stage == "EFFECT_EXECUTED" || event.Stage == "RECONCILED" && event.Outcome == "committed" {
			return true
		}
	}
	return false
}

// policyRules returns the rule IDs of the last POLICY_DECISION of the
// operation, its audit outcome (allow, allow_flagged, deny, ...) and whether
// it was flagged.
func (r *evidenceRun) policyRules(operation string) (rules []string, outcome string, flagged bool) {
	events := r.eventsFor(operation)
	for index := len(events) - 1; index >= 0; index-- {
		event := events[index]
		if event.Stage != "POLICY_DECISION" {
			continue
		}
		outcome = event.Outcome
		flagged, _ = event.Details["flagged"].(bool)
		reasons, _ := event.Details["reasons"].([]any)
		for _, reason := range reasons {
			if object, ok := reason.(map[string]any); ok {
				if id, ok := object["rule_id"].(string); ok {
					rules = append(rules, id)
				}
			}
		}
		return rules, outcome, flagged
	}
	return nil, "", false
}

// --- verification ---------------------------------------------------------------------

// verifyOutcome is the verifier's answer on one evidence folder.
type verifyOutcome struct {
	Folder     string            `json:"folder"`
	Anchors    string            `json:"anchors"`
	Verdict    string            `json:"verdict"`
	Assurance  string            `json:"assurance"`
	Failing    []string          `json:"failing_checks"`
	Findings   []string          `json:"findings"`   // "check #seq: detail" of the first failures
	Dimensions map[string]string `json:"dimensions"` // assurance dimension (check-based and derived) -> pass | fail | not_checked
	Missing    []string          `json:"missing"`
	// MissingByKind counts the Missing entries per kind
	// (auditverify.MissingKinds: unresolved, freshness, issuer_only, other).
	// Since the verifier reports head freshness, every folder verified with a
	// pinned or saved head lists the freshness gap, so a non-empty Missing
	// alone no longer singles anything out.
	MissingByKind map[string]int `json:"missing_by_kind,omitempty"`
	Entries       int            `json:"entries"`
	Operations    int            `json:"operations"`
	Error         string         `json:"error,omitempty"`
}

// maxFindings bounds the failure details kept per verification.
const maxFindings = 10

// verifyPinned verifies dir with the keys fingerprint and final head the
// harness held outside the folder.
func verifyPinned(r *evidenceRun) verifyOutcome {
	if r == nil || r.log == nil {
		return verifyOutcome{Error: "no evidence folder"}
	}
	return verifyWith(r.dir, "keys+head pinned", auditverify.Options{ExpectKeysSHA256: r.keysSHA256, ExpectHead: r.headHash, Workers: 1})
}

func verifyWith(dir, anchors string, options auditverify.Options) verifyOutcome {
	out := verifyOutcome{Folder: displayPath(dir), Anchors: anchors}
	report, err := auditverify.VerifyRun(dir, options)
	if err != nil {
		out.Error = err.Error()
		return out
	}
	out.Verdict, out.Assurance = report.Verdict, report.Assurance
	out.Failing = failingCheckIDs(report)
	if out.Failing == nil {
		out.Failing = []string{}
	}
	out.Findings = []string{}
	for index, check := range report.Failures {
		if index == maxFindings {
			out.Findings = append(out.Findings, fmt.Sprintf("... %d more", len(report.Failures)-maxFindings))
			break
		}
		out.Findings = append(out.Findings, fmt.Sprintf("%s #%d: %s", check.ID, check.Seq, check.Detail))
	}
	out.Dimensions = map[string]string{}
	for _, name := range append(auditverify.DimensionNames(), auditverify.DerivedDimensionNames()...) {
		if dimension, ok := report.Dimensions.ByName(name); ok {
			out.Dimensions[name] = dimension.Status
		}
	}
	out.Missing = append([]string{}, report.Missing...)
	out.MissingByKind = missingByKind(report.MissingKinds)
	out.Entries, out.Operations = report.Counts.Entries, report.Counts.Operations
	return out
}

// missingByKind counts Missing entries per kind, every kind present (zero
// included) so the results read the same for every folder.
func missingByKind(kinds []string) map[string]int {
	out := map[string]int{}
	for _, kind := range auditverify.MissingKinds() {
		out[kind] = 0
	}
	for _, kind := range kinds {
		out[kind]++
	}
	return out
}

// missingKindsText names the kinds of Missing entries a folder lists, in
// auditverify.MissingKinds order ("" when none).
func missingKindsText(counts map[string]int) string {
	var kinds []string
	for _, kind := range auditverify.MissingKinds() {
		if counts[kind] > 0 {
			kinds = append(kinds, kind)
		}
	}
	return strings.Join(kinds, " ")
}

// --- small helpers ---------------------------------------------------------------------

func boolText(value bool) string {
	if value {
		return "yes"
	}
	return "no"
}

func countKeys(counts map[string]int) string {
	keys := make([]string, 0, len(counts))
	for key := range counts {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	parts := make([]string, len(keys))
	for index, key := range keys {
		parts[index] = fmt.Sprintf("%s x%d", key, counts[key])
	}
	return strings.Join(parts, ", ")
}

func csvEscape(value string) string {
	if strings.ContainsAny(value, ",\"\n\r") {
		return `"` + strings.ReplaceAll(value, `"`, `""`) + `"`
	}
	return value
}

func csvLine(fields ...string) string {
	escaped := make([]string, len(fields))
	for index, field := range fields {
		escaped[index] = csvEscape(field)
	}
	return strings.Join(escaped, ",") + "\n"
}
