// Command agentgate-eval runs AgentGate's local evaluation experiments.
//
// The original experiments work on evidence produced by the offline demo
// (internal/demo) through the demo self-test:
//
//	agentgate-eval ablation -runs N -out DIR   which protection mechanism detects which attack
//	agentgate-eval cost -n N -out DIR          what the evidence costs per entry and per gateway call
//	agentgate-eval scale -out DIR              verifier runtime against log size
//	agentgate-eval scale -workers 1,2,4 -out DIR   parallel verifier speedup
//
// The 2026-10-07 revision (docs/demo/REVISION_CONTRACT.md R6) adds:
//
//	agentgate-eval compromise -out DIR  R6.1 flag-binding ablation + key-compromise simulation (operator x key set x snapshot variant x anchors x verifier config), joined with the oracle
//	agentgate-eval crash -out DIR   fault points x retry (same/fresh ID) x restart (none/journal)
//	agentgate-eval concurrency -out DIR   simultaneous retries, conflicting reuse, racing reservations
//	agentgate-eval misuse -out DIR  policy boundaries and misuse sequences, blocked/flagged/permitted
//	agentgate-eval custody -out DIR provider and witness processes, outage, rollback detection
//	agentgate-eval baseline -out DIR direct vs policy-only vs full, sequential paired and concurrent load
//
// crash, concurrency, misuse and baseline build the real gateway
// (internal/devcomposition) directly through the harness in harness.go,
// because they need fault injection, restarts on one journal and the gateway
// without its audit sink; custody drives the demo self-test with the custody
// processes. Results are written as JSON (complete, machine-readable), CSV
// and a short Markdown summary.
//
// All numbers are local measurements on the computer that runs the command,
// with simulated providers; detection and outcome counts describe the fixed
// case and attack sets of each experiment, not attacks or workloads in
// general.
package main

import (
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"strings"
)

const usage = `agentgate-eval runs AgentGate's local evaluation experiments.

Usage:
  agentgate-eval ablation -runs N -out DIR [-work DIR]
      Create N fresh demo runs, attack copies of each with every tamper-lab
      attack, and verify the clean run and every copy under cumulative and
      leave-one-out verifier configurations.
  agentgate-eval cost -n N -out DIR [-batches B] [-repeat R] [-work DIR]
      Measure audit append cost per entry (fsync, no fsync, hash+sign only;
      batches of N appends) and gateway call latency by outcome from a
      self-test with R scenario suites.
  agentgate-eval scale -out DIR [-sizes 1,2,5,10,20] [-reps K] [-work DIR]
                       [-workers 1,2,4,6,12 [-machine TEXT]]
      Measure verifier runtime on runs of increasing size (self-test repeat
      counts given by -sizes), K timed verifications each, with the
      sequential verifier. With -workers, measure the parallel verifier's
      speedup over one worker instead (parallel.json/md).

Revision experiments (docs/demo/REVISION_CONTRACT.md R6):
  agentgate-eval compromise -out DIR [-work DIR] [-runs N] [-oracle FILE]
                            [-operators LIST] [-keysets LIST] [-variants LIST]
      The R6.1 flag-binding ablation and key-compromise study: for design
      bound and unbound, every mutation operator x attacker key set x
      snapshot variant (plain, forge-snapshot, forge-restate) is written with
      the content-mutation engine (internal/evalattack; content edits and
      hash recomputation only, nothing signed) and verified under a
      key-compromise SIMULATION (auditverify AssumeCompromised) across anchor
      conditions none/keys/head/both and verifier configurations
      full/no-replay/no-replay-no-snapshot/no-snapshot-bound-only; the
      unmutated base runs are verified as clean controls. Results
      (results.csv/json, strongest.csv, controls.csv, compromise.md) are
      joined, without tuning, against the independent oracle
      (docs/paper/oracle/expected.json) under every reading, for every
      configuration. The results are a simulation, never a real verification
      of signed evidence.
  agentgate-eval crash -out DIR [-work DIR] [-points all|p1,p2] [-repeat R]
                       [-escalation flag|deny]
      Every fault point (and a fault-free control) x retry with the same or a
      fresh operation ID x no restart or a restart on the operation journal,
      for one payment and one message: statuses, provider effects,
      REJECTED-while-committed, unresolved operations, evidence gaps and the
      verifier's verdict on every evidence folder.
  agentgate-eval concurrency -out DIR [-work DIR] [-repeat 20] [-n 8]
      Simultaneous exact retries, conflicting operation-ID reuse (same tool
      and across tools), a lost response raced by retries, and budget and
      release-count races: committed effects, answer patterns, invariants.
  agentgate-eval misuse -out DIR [-work DIR] [-groups all|g1,g2]
                        [-escalation flag|deny]
      Limit boundaries per currency (zero, malformed, overflow), split
      payments against the grant budget, repeated releases against MaxCounts,
      confidential text copied or paraphrased into messages, out-of-scope
      payees and recipients, revocation and the validity window: outcome,
      fired rules, and whether harm was blocked, flagged or permitted.
  agentgate-eval custody -out DIR [-work DIR] [-provider-exe P] [-witness-exe W]
      The demo with the provider and the head witness as separate processes:
      witness outage and catch-up, restarts, and a coherent rollback verified
      with no anchors, pinned values, the witness head and the provider's own
      journal.
  agentgate-eval baseline -out DIR [-work DIR] [-trials 500] [-block 50]
                          [-clients 1,2,4,8,16] [-load-calls 400]
                          [-workload financial|message]
      Direct execution vs policy-only gateway vs full gateway (signed
      recording, fsync) vs full + operation journal, identical transport and
      provider: paired interleaved sequential trials and concurrent load;
      throughput, p50/p95/p99/max, CPU time and memory; every observation kept.

Run any subcommand with -h for its flags. Evidence folders go to -work
(default: a folder in the system temporary directory); results go to -out.

Global option (before the subcommand):
  -host-label NAME   record NAME instead of this computer's name wherever the
                     evidence says where it ran (run.json "host", audit entry
                     locations), e.g. agentgate-eval -host-label lab-1 crash ...
`

func main() {
	os.Exit(run(os.Args[1:], os.Stdout, os.Stderr))
}

func run(args []string, stdout, stderr io.Writer) int {
	// Global option before the subcommand: -host-label NAME (or
	// -host-label=NAME) replaces the machine name in every evidence folder
	// the experiments write (harness.go hostLabelOption).
	hostLabelOption = ""
	for len(args) > 0 {
		name, value, hasValue := strings.Cut(strings.TrimPrefix(args[0], "-"), "=")
		if name != "host-label" && name != "-host-label" {
			break
		}
		if !hasValue {
			if len(args) < 2 {
				fmt.Fprintf(stderr, "agentgate-eval: %s needs a value\n\n%s", args[0], usage)
				return 2
			}
			value, args = args[1], args[1:]
		}
		if strings.TrimSpace(value) == "" || strings.ContainsAny(value, "\t\r\n") {
			fmt.Fprintf(stderr, "agentgate-eval: -host-label must be a non-empty single-line name\n")
			return 2
		}
		hostLabelOption, args = value, args[1:]
	}
	if len(args) == 0 {
		fmt.Fprint(stderr, usage)
		return 2
	}
	var err error
	switch args[0] {
	case "ablation":
		err = runAblation(args[1:], stdout)
	case "cost":
		err = runCost(args[1:], stdout)
	case "scale":
		err = runScale(args[1:], stdout)
	case "compromise":
		err = runCompromise(args[1:], stdout)
	case "crash":
		err = runCrash(args[1:], stdout)
	case "concurrency":
		err = runConcurrency(args[1:], stdout)
	case "misuse":
		err = runMisuse(args[1:], stdout)
	case "custody":
		err = runCustody(args[1:], stdout)
	case "baseline":
		err = runBaseline(args[1:], stdout)
	case "-h", "--help", "help":
		fmt.Fprint(stdout, usage)
		return 0
	default:
		fmt.Fprintf(stderr, "agentgate-eval: unknown subcommand %q\n\n%s", args[0], usage)
		return 2
	}
	if errors.Is(err, flag.ErrHelp) {
		return 0
	}
	if err != nil {
		fmt.Fprintf(stderr, "agentgate-eval %s: %v\n", args[0], err)
		return 1
	}
	return 0
}
