package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"path/filepath"
	"runtime"
	"strings"
	"time"

	"agentgate/internal/auditverify"
)

// The parallel sweep (agentgate-eval scale -workers 1,2,4,...) measures how
// much faster the verifier gets when it spreads its independent work (log
// lines, entry signatures, embedded artifacts, operations, provider receipts)
// over several goroutines. Each size is one fresh demo run, verified pinned
// (as agentgate-verify --expect-keys --expect-head --workers N) with every
// listed worker count. Before timing, one verification per worker count is
// discarded as warm-up and its report is compared with the sequential one:
// apart from checked_at they must be byte-identical. The timed verifications
// are interleaved (one per worker count per round, the starting count rotating
// each round) and each starts after a forced garbage collection, so slow drift
// of the machine and garbage left by the previous verification affect every
// worker count alike.

// minSampleTime is the shortest a timed batch takes with one worker.
const minSampleTime = 250 * time.Millisecond

type parallelSetup struct {
	repeats    []int
	reps       int
	workers    []int
	machine    string
	conditions string
	outDir     string
	workDir    string
	args       []string
}

// parallelTiming is one worker count on one run.
type parallelTiming struct {
	Workers int     `json:"workers"`
	MS      summary `json:"ms"`
	// SpeedupVs1 is the median with one worker divided by this median.
	SpeedupVs1 float64 `json:"speedup_vs_1"`
	// Efficiency is SpeedupVs1 divided by Workers.
	Efficiency float64 `json:"efficiency"`
}

type parallelPoint struct {
	Repeat     int    `json:"repeat"`
	RunID      string `json:"run_id"`
	Entries    int    `json:"entries"`
	LogBytes   int64  `json:"log_bytes"`
	Operations int    `json:"operations"`
	Effects    int    `json:"effects"`
	Artifacts  int    `json:"artifacts"`
	Verdict    string `json:"verdict"`
	// BatchSize is how many back-to-back verifications one sample times
	// (the sample is the batch time divided by BatchSize).
	BatchSize int `json:"batch_size"`
	// ReportsIdentical is true when every worker count produced the same
	// report as one worker (checked_at aside).
	ReportsIdentical bool             `json:"reports_identical"`
	Timings          []parallelTiming `json:"timings"`
}

type parallelResult struct {
	Format      string          `json:"format"`
	Note        string          `json:"note"`
	Machine     string          `json:"machine,omitempty"`
	Conditions  string          `json:"conditions,omitempty"`
	Environment environment     `json:"environment"`
	Reps        int             `json:"reps"`
	Workers     []int           `json:"workers"`
	Points      []parallelPoint `json:"points"`
	Runs        []baseRun       `json:"runs"`
	DurationS   float64         `json:"duration_s"`
}

func runParallelSweep(ctx context.Context, setup parallelSetup, stdout io.Writer) error {
	began := time.Now()
	result := parallelResult{
		Format: "agentgate-eval-parallel/v1",
		Note: "Local measurements on one computer: each point is one fresh demo run, verified repeatedly in one process with a warm file cache. " +
			"Runtime includes reading and parsing the files and every check (pinned verification). Speedups are ratios of medians.",
		Machine:     setup.machine,
		Conditions:  setup.conditions,
		Environment: currentEnvironment(append([]string{"scale"}, setup.args...)),
		Reps:        setup.reps,
		Workers:     setup.workers,
	}
	for index, repeat := range setup.repeats {
		fmt.Fprintf(stdout, "repeat %d: self-test ... ", repeat)
		run, err := createBaseRun(ctx, index+1, filepath.Join(setup.workDir, "runs"), repeat)
		if err != nil {
			return err
		}
		point, err := measureParallel(run, setup.workers, setup.reps)
		if err != nil {
			return err
		}
		result.Points = append(result.Points, point)
		result.Runs = append(result.Runs, run)
		last := point.Timings[len(point.Timings)-1]
		fmt.Fprintf(stdout, "%d entries: 1 worker %.1f ms, %d workers %.1f ms (%.2fx)\n",
			run.Entries, point.Timings[0].MS.Median, last.Workers, last.MS.Median, last.SpeedupVs1)
	}
	result.DurationS = round(time.Since(began).Seconds(), 1)
	if err := writeJSON(filepath.Join(setup.outDir, "parallel.json"), result); err != nil {
		return err
	}
	if err := writeText(filepath.Join(setup.outDir, "parallel.md"), parallelMarkdown(result)); err != nil {
		return err
	}
	fmt.Fprintf(stdout, "wrote %s (parallel.json, parallel.md)\n", setup.outDir)
	return nil
}

// measureParallel times the pinned verification of one run with every worker
// count (workers[0] must be 1).
func measureParallel(run baseRun, workers []int, reps int) (parallelPoint, error) {
	point := parallelPoint{Repeat: run.Repeat, RunID: run.RunID, Entries: run.Entries, LogBytes: run.LogBytes,
		Operations: run.Operations, Effects: run.Effects, ReportsIdentical: true}
	options := func(n int) auditverify.Options {
		return auditverify.Options{ExpectKeysSHA256: run.KeysSHA256, ExpectHead: run.HeadHash, Workers: n}
	}

	// Warm-up, and the identical-report check.
	var baseline string
	for _, n := range workers {
		report, err := auditverify.VerifyRun(run.dir, options(n))
		if err != nil {
			return point, err
		}
		if report.Verdict != auditverify.VerdictVerified {
			return point, fmt.Errorf("run %s did not verify with %d workers: %v", run.RunID, n, failingCheckIDs(report))
		}
		normalized, err := reportWithoutTime(report)
		if err != nil {
			return point, err
		}
		if n == workers[0] {
			baseline = normalized
			point.Verdict, point.Artifacts = report.Verdict, report.Counts.Artifacts
		} else if normalized != baseline {
			point.ReportsIdentical = false
			return point, fmt.Errorf("run %s: the report with %d workers differs from the report with 1 worker", run.RunID, n)
		}
	}

	// Small runs verify in a few milliseconds, close to the Windows clock
	// step, so each sample times a batch of verifications lasting at least
	// minSampleTime with one worker, and divides by the batch size.
	probeStart := time.Now()
	if _, err := auditverify.VerifyRun(run.dir, options(1)); err != nil {
		return point, err
	}
	probe := max(time.Since(probeStart), time.Microsecond)
	point.BatchSize = min(200, int(minSampleTime/probe)+1)

	samples := make([][]float64, len(workers))
	for rep := 0; rep < reps; rep++ {
		for k := range workers {
			slot := (k + rep) % len(workers) // rotate the starting worker count each round
			runtime.GC()
			start := time.Now()
			for i := 0; i < point.BatchSize; i++ {
				if _, err := auditverify.VerifyRun(run.dir, options(workers[slot])); err != nil {
					return point, err
				}
			}
			samples[slot] = append(samples[slot], round(ms(time.Since(start))/float64(point.BatchSize), 3))
		}
	}
	for k, n := range workers {
		point.Timings = append(point.Timings, parallelTiming{Workers: n, MS: summarize("ms", samples[k])})
	}
	sequential := point.Timings[0].MS.Median
	for k := range point.Timings {
		timing := &point.Timings[k]
		if timing.MS.Median > 0 {
			timing.SpeedupVs1 = round(sequential/timing.MS.Median, 2)
			timing.Efficiency = round(timing.SpeedupVs1/float64(timing.Workers), 2)
		}
	}
	return point, nil
}

// reportWithoutTime is the report JSON without checked_at.
func reportWithoutTime(report auditverify.Report) (string, error) {
	report.CheckedAt = ""
	data, err := json.Marshal(report)
	return string(data), err
}

func parallelMarkdown(result parallelResult) string {
	var b strings.Builder
	fmt.Fprintf(&b, "# Parallel verifier speedup\n\n%s\n\n", result.Note)
	machine := result.Machine
	if machine == "" {
		machine = "(not recorded)"
	}
	env := result.Environment
	fmt.Fprintf(&b, "- Machine: %s; Go %s on %s/%s, NumCPU %d, GOMAXPROCS %d.\n", machine, env.GoVersion, env.GOOS, env.GOARCH, env.NumCPU, env.GOMAXPROCS)
	if result.Conditions != "" {
		fmt.Fprintf(&b, "- Conditions: %s\n", result.Conditions)
	}
	fmt.Fprintf(&b, "- Command: `%s`; %d timed samples per worker count and run, interleaved across worker counts, each after a forced GC. "+
		"A sample times a batch of back-to-back verifications lasting at least %d ms with one worker (batch size per run below) and divides by the batch size; total %.0f s.\n",
		env.Command, result.Reps, minSampleTime.Milliseconds(), result.DurationS)
	fmt.Fprintf(&b, "- Every worker count produced a report byte-identical to the sequential one (checked_at aside) on every run: %s.\n\n", yesNo(allIdentical(result.Points)))

	fmt.Fprintf(&b, "## Speedup over one worker (median runtime ratio)\n\n| Suites | Entries |")
	for _, n := range result.Workers {
		fmt.Fprintf(&b, " %d |", n)
	}
	fmt.Fprintf(&b, "\n|---|---|")
	for range result.Workers {
		fmt.Fprintf(&b, "---|")
	}
	fmt.Fprintln(&b)
	for _, point := range result.Points {
		fmt.Fprintf(&b, "| %d | %d |", point.Repeat, point.Entries)
		for _, timing := range point.Timings {
			fmt.Fprintf(&b, " %.2fx |", timing.SpeedupVs1)
		}
		fmt.Fprintln(&b)
	}

	fmt.Fprintf(&b, "\n## Runtime per worker count\n\n| Suites | Entries | Batch | Workers | Median ms (min-max) | Speedup | Efficiency |\n|---|---|---|---|---|---|---|\n")
	for _, point := range result.Points {
		for _, timing := range point.Timings {
			fmt.Fprintf(&b, "| %d | %d | %d | %d | %.2f (%.2f-%.2f) | %.2fx | %.0f%% |\n", point.Repeat, point.Entries, point.BatchSize, timing.Workers,
				timing.MS.Median, timing.MS.Min, timing.MS.Max, timing.SpeedupVs1, timing.Efficiency*100)
		}
	}
	fmt.Fprintf(&b, "\nNotes: warm file cache (the files are read once before timing); a local measurement on one development PC, "+
		"not a benchmark of the method in general. Each suite is one self-test pass over the 14 demo scenarios plus 3 custom requests. "+
		"Worker counts above the number of physical cores share cores through simultaneous multithreading. "+
		"The remaining sequential work (reading the files, chain links, cross-operation and provider matching, assembling the report) bounds the speedup.\n")
	return b.String()
}

func allIdentical(points []parallelPoint) bool {
	for _, point := range points {
		if !point.ReportsIdentical {
			return false
		}
	}
	return len(points) > 0
}

func yesNo(value bool) string {
	if value {
		return "yes"
	}
	return "no"
}
