package main

import (
	"runtime/metrics"
	"sync"
	"time"
)

// Resource accounting for one measurement window (baseline experiment):
// process CPU time (clock_*.go), Go allocations and GC cycles
// (runtime/metrics, exact counters) and peak memory, sampled every few
// milliseconds while the window is open (Go heap objects, all Go-mapped
// memory, and the process working set). Peaks are sampled, so a spike
// shorter than the interval can be missed; the process-lifetime peak working
// set is reported as well.

var resourceMetricNames = []string{
	"/gc/heap/allocs:bytes",
	"/gc/heap/allocs:objects",
	"/gc/cycles/total:gc-cycles",
	"/memory/classes/heap/objects:bytes",
	"/memory/classes/total:bytes",
	"/cpu/classes/gc/total:cpu-seconds",
}

type metricReading struct {
	allocBytes, allocObjects, gcCycles uint64
	heapObjects, goTotal               uint64
	gcCPUSeconds                       float64
}

func readMetrics() metricReading {
	samples := make([]metrics.Sample, len(resourceMetricNames))
	for index, name := range resourceMetricNames {
		samples[index].Name = name
	}
	metrics.Read(samples)
	uintValue := func(index int) uint64 {
		if samples[index].Value.Kind() == metrics.KindUint64 {
			return samples[index].Value.Uint64()
		}
		return 0
	}
	reading := metricReading{
		allocBytes: uintValue(0), allocObjects: uintValue(1), gcCycles: uintValue(2),
		heapObjects: uintValue(3), goTotal: uintValue(4),
	}
	if samples[5].Value.Kind() == metrics.KindFloat64 {
		reading.gcCPUSeconds = samples[5].Value.Float64()
	}
	return reading
}

// resourceUsage is what one window consumed.
type resourceUsage struct {
	WallMS                float64 `json:"wall_ms"`
	CPUUserMS             float64 `json:"cpu_user_ms"`
	CPUKernelMS           float64 `json:"cpu_kernel_ms"`
	CPUTotalMS            float64 `json:"cpu_total_ms"`
	CPUUtilization        float64 `json:"cpu_utilization_cores"` // CPU time / wall time
	GCCPUMS               float64 `json:"gc_cpu_ms_estimate"`
	AllocBytes            uint64  `json:"alloc_bytes"`
	AllocObjects          uint64  `json:"alloc_objects"`
	GCCycles              uint64  `json:"gc_cycles"`
	PeakHeapObjectsBytes  uint64  `json:"peak_heap_objects_bytes"`
	PeakGoMemoryBytes     uint64  `json:"peak_go_memory_bytes"`
	PeakWorkingSetBytes   uint64  `json:"peak_working_set_bytes"`
	ProcessPeakWSBytes    uint64  `json:"process_lifetime_peak_working_set_bytes"`
	MemorySamples         int     `json:"memory_samples"`
	SampleIntervalMS      float64 `json:"memory_sample_interval_ms"`
	CPUSource             string  `json:"cpu_source"`
	MemorySource          string  `json:"memory_source"`
	CPUResolutionCaveat   string  `json:"cpu_resolution"`
	CPUIncludesComponents string  `json:"cpu_includes"`
}

type resourceWindow struct {
	startTicks  int64
	startProc   processSample
	startMetric metricReading
	interval    time.Duration

	mu      sync.Mutex
	peakHO  uint64
	peakGo  uint64
	peakWS  uint64
	samples int
	stop    chan struct{}
	done    chan struct{}
}

func beginResources(interval time.Duration) *resourceWindow {
	if interval <= 0 {
		interval = 5 * time.Millisecond
	}
	window := &resourceWindow{interval: interval, stop: make(chan struct{}), done: make(chan struct{})}
	window.sample()
	window.startProc = readProcessSample()
	window.startMetric = readMetrics()
	window.startTicks = hrTicks()
	go func() {
		defer close(window.done)
		ticker := time.NewTicker(interval)
		defer ticker.Stop()
		for {
			select {
			case <-window.stop:
				return
			case <-ticker.C:
				window.sample()
			}
		}
	}()
	return window
}

func (window *resourceWindow) sample() {
	reading := readMetrics()
	proc := readProcessSample()
	window.mu.Lock()
	defer window.mu.Unlock()
	window.samples++
	window.peakHO = max(window.peakHO, reading.heapObjects)
	window.peakGo = max(window.peakGo, reading.goTotal)
	window.peakWS = max(window.peakWS, proc.WorkingSet)
}

func (window *resourceWindow) end(includes string) resourceUsage {
	endTicks := hrTicks()
	endMetric := readMetrics()
	endProc := readProcessSample()
	close(window.stop)
	<-window.done
	window.sample()
	window.mu.Lock()
	defer window.mu.Unlock()
	wall := hrElapsed(window.startTicks, endTicks)
	usage := resourceUsage{
		WallMS:      round(ms(wall), 3),
		CPUUserMS:   round(ms(endProc.UserCPU-window.startProc.UserCPU), 3),
		CPUKernelMS: round(ms(endProc.KernelCPU-window.startProc.KernelCPU), 3),
		GCCPUMS:     round((endMetric.gcCPUSeconds-window.startMetric.gcCPUSeconds)*1000, 3),
		AllocBytes:  endMetric.allocBytes - window.startMetric.allocBytes, AllocObjects: endMetric.allocObjects - window.startMetric.allocObjects,
		GCCycles: endMetric.gcCycles - window.startMetric.gcCycles, PeakHeapObjectsBytes: window.peakHO, PeakGoMemoryBytes: window.peakGo,
		PeakWorkingSetBytes: window.peakWS, ProcessPeakWSBytes: endProc.PeakWorkingSet, MemorySamples: window.samples,
		SampleIntervalMS: ms(window.interval), CPUSource: endProc.CPUSource, MemorySource: endProc.MemorySource,
		CPUResolutionCaveat: endProc.CPUResolutionMax, CPUIncludesComponents: includes,
	}
	usage.CPUTotalMS = round(usage.CPUUserMS+usage.CPUKernelMS, 3)
	if wall > 0 {
		usage.CPUUtilization = round(usage.CPUTotalMS/ms(wall), 3)
	}
	return usage
}
