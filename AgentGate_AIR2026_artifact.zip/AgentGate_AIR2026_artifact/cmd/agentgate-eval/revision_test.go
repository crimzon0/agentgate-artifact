package main

import (
	"context"
	"encoding/json"
	"io"
	"math"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"agentgate/internal/auditverify"
	"agentgate/internal/devcomposition"
)

// --- the harness --------------------------------------------------------------

// TestHarnessProducesVerifiableEvidence: one allowed payment and one flagged
// external message through a harness gateway; the evidence folder must verify
// ANCHORED with the pinned keys and head, and the provider must hold exactly
// the two effects.
func TestHarnessProducesVerifiableEvidence(t *testing.T) {
	ctx := context.Background()
	w, err := newWorld()
	if err != nil {
		t.Fatal(err)
	}
	run, err := newRunIdentity("eval-harness-test")
	if err != nil {
		t.Fatal(err)
	}
	provider, err := startProviderHost(w, run, nil)
	if err != nil {
		t.Fatal(err)
	}
	defer provider.close()
	grant, err := signGrant("harness-test", w.openGrant(time.Now()))
	if err != nil {
		t.Fatal(err)
	}
	evidence, err := newEvidenceRun(filepath.Join(t.TempDir(), "run"), run.Label)
	if err != nil {
		t.Fatal(err)
	}
	g, err := buildGateway(ctx, w, run, provider, gatewaySpec{Sink: evidence, Grant: grant, Journal: filepath.Join(t.TempDir(), "operations.jsonl")})
	if err != nil {
		t.Fatal(err)
	}
	if err := evidence.begin(w, g, grant, "harness test"); err != nil {
		t.Fatal(err)
	}
	caller := g.caller()
	payment := caller.call(ctx, toolPayment, paymentArgs(newOperationID(), "payee.office-supplies", 12_500, "AED", "Printer paper"))
	if payment.Status != "COMMITTED" {
		t.Fatalf("payment = %+v", payment)
	}
	messageID := newOperationID()
	message := caller.call(ctx, toolMessage, messageArgs(messageID, []string{"partner.carrier"}, "Pickup", "Pickup is confirmed for Thursday."))
	if message.Status != "COMMITTED" {
		t.Fatalf("message = %+v", message)
	}
	if _, outcome, flagged := evidence.policyRules(opText(messageID)); !flagged || outcome != "allow_flagged" {
		t.Errorf("external message: outcome %q flagged %v", outcome, flagged)
	}
	if err := evidence.finish(provider); err != nil {
		t.Fatal(err)
	}
	commits, err := provider.commits()
	if err != nil || len(commits) != 2 {
		t.Fatalf("commits = %v, %v", commits, err)
	}
	outcome := verifyPinned(evidence)
	if outcome.Verdict != auditverify.VerdictVerified || outcome.Assurance != auditverify.AssuranceAnchored {
		t.Fatalf("verification = %+v", outcome)
	}
}

// --- argument parsing --------------------------------------------------------------

func TestParseCrashFlags(t *testing.T) {
	options, err := parseCrashFlags([]string{"-out", "x"}, io.Discard)
	if err != nil || len(options.points) != 1+len(devcomposition.AllFaultPoints()) || options.points[0] != crashNone ||
		options.repeat != 1 || options.escalation != devcomposition.EscalationFlag {
		t.Fatalf("defaults = %+v, %v", options, err)
	}
	options, err = parseCrashFlags([]string{"-out", "x", "-points", "head_replace, none", "-escalation", "deny", "-repeat", "3"}, io.Discard)
	if err != nil || strings.Join(options.points, ",") != "none,head_replace" || options.escalation != devcomposition.EscalationDeny || options.repeat != 3 {
		t.Fatalf("subset = %+v, %v", options, err)
	}
	for _, bad := range [][]string{
		{}, {"-out", "x", "-points", "nope"}, {"-out", "x", "-points", "none,none"}, {"-out", "x", "-points", ","},
		{"-out", "x", "-escalation", "human"}, {"-out", "x", "-repeat", "0"}, {"-out", "x", "extra"},
	} {
		if _, err := parseCrashFlags(bad, io.Discard); err == nil {
			t.Errorf("parseCrashFlags(%q) accepted", bad)
		}
	}
}

func TestParseConcurrencyFlags(t *testing.T) {
	options, err := parseConcurrencyFlags([]string{"-out", "x"}, io.Discard)
	if err != nil || options.repeat != 20 || options.calls != 8 {
		t.Fatalf("defaults = %+v, %v", options, err)
	}
	for _, bad := range [][]string{{}, {"-out", "x", "-n", "1"}, {"-out", "x", "-repeat", "0"}, {"-out", "x", "-escalation", "x"}} {
		if _, err := parseConcurrencyFlags(bad, io.Discard); err == nil {
			t.Errorf("parseConcurrencyFlags(%q) accepted", bad)
		}
	}
}

func TestParseMisuseFlags(t *testing.T) {
	options, err := parseMisuseFlags([]string{"-out", "x"}, io.Discard)
	if err != nil || len(options.groups) != len(misuseGroups) {
		t.Fatalf("defaults = %+v, %v", options, err)
	}
	options, err = parseMisuseFlags([]string{"-out", "x", "-groups", "split,boundary,split"}, io.Discard)
	if err != nil || strings.Join(options.groups, ",") != "split,boundary" {
		t.Fatalf("groups = %+v, %v", options, err)
	}
	for _, bad := range [][]string{{}, {"-out", "x", "-groups", "nope"}, {"-out", "x", "-groups", ""}, {"-out", "x", "-escalation", "human"}} {
		if _, err := parseMisuseFlags(bad, io.Discard); err == nil {
			t.Errorf("parseMisuseFlags(%q) accepted", bad)
		}
	}
}

func TestParseBaselineFlags(t *testing.T) {
	options, err := parseBaselineFlags([]string{"-out", "x"}, io.Discard)
	if err != nil || options.trials != 500 || options.block != 50 || len(options.clients) != 5 || options.clients[4] != 16 ||
		len(options.sequential) != 5 || len(options.concurrent) != 4 || options.workload != "financial" {
		t.Fatalf("defaults = %+v, %v", options, err)
	}
	options, err = parseBaselineFlags([]string{"-out", "x", "-clients", "8, 1", "-configs", "full,direct", "-workload", "message", "-load-configs", "direct"}, io.Discard)
	if err != nil || len(options.clients) != 2 || options.clients[0] != 1 || options.sequential[0].Name != "full" {
		t.Fatalf("custom = %+v, %v", options, err)
	}
	for _, bad := range [][]string{
		{}, {"-out", "x", "-clients", "0"}, {"-out", "x", "-clients", "2,2"}, {"-out", "x", "-clients", "a"},
		{"-out", "x", "-configs", "nope"}, {"-out", "x", "-configs", "full,full"}, {"-out", "x", "-workload", "x"},
		{"-out", "x", "-workload", "message"}, // full-flagged is in the default sequential configs
		{"-out", "x", "-trials", "0"}, {"-out", "x", "-sample", "0s"},
	} {
		if _, err := parseBaselineFlags(bad, io.Discard); err == nil {
			t.Errorf("parseBaselineFlags(%q) accepted", bad)
		}
	}
}

func TestParseCustodyFlags(t *testing.T) {
	options, err := parseCustodyFlags([]string{"-out", "x", "-provider-exe", "p", "-witness-exe", "w"}, io.Discard)
	if err != nil || options.providerExe != "p" || options.witnessExe != "w" || options.escalation != devcomposition.EscalationFlag {
		t.Fatalf("options = %+v, %v", options, err)
	}
	for _, bad := range [][]string{{}, {"-out", "x", "-escalation", "human"}, {"-out", "x", "extra"}} {
		if _, err := parseCustodyFlags(bad, io.Discard); err == nil {
			t.Errorf("parseCustodyFlags(%q) accepted", bad)
		}
	}
}

func TestRunKnowsTheRevisionSubcommands(t *testing.T) {
	for _, name := range []string{"compromise", "crash", "concurrency", "misuse", "custody", "baseline"} {
		var out, errs strings.Builder
		run([]string{name, "-definitely-not-a-flag"}, &out, &errs)
		if strings.Contains(errs.String(), "unknown subcommand") {
			t.Errorf("%s is not registered", name)
		}
	}
	var out, errs strings.Builder
	if code := run([]string{"crash", "-h"}, &out, &errs); code != 0 {
		t.Errorf("crash -h: code %d", code)
	}
}

// --- statistics ----------------------------------------------------------------------

func TestPairedDiffAndLatencySummary(t *testing.T) {
	a := make([]float64, 100)
	b := make([]float64, 100)
	for index := range a {
		a[index] = 1000
		b[index] = 1000 + float64(index) // differences 0..99
	}
	pair := pairedDiff("b - a", a, b)
	if pair.N != 100 || pair.MedianUS != 49.5 || pair.MeanUS != 49.5 || math.Abs(pair.ShareSlower-0.99) > 1e-9 {
		t.Fatalf("pair = %+v", pair)
	}
	// k = floor((100 - 19.6) / 2) = 40: the interval is [d(40), d(59)].
	if pair.CI95LowUS == nil || *pair.CI95LowUS != 40 || *pair.CI95HighUS != 59 {
		t.Fatalf("interval = %v %v", pair.CI95LowUS, pair.CI95HighUS)
	}
	if small := pairedDiff("x", []float64{1}, []float64{2}); small.CI95LowUS != nil {
		t.Errorf("an interval for n=1: %+v", small)
	}
	stats := latencySummary(b)
	if stats.N != 100 || stats.Min != 1000 || stats.Max != 1099 || stats.P50 != 1049.5 || stats.P99 != 1098 {
		t.Fatalf("summary = %+v", stats)
	}
	if formatMinor(123_456_789, "AED") != "AED 1,234,567.89" || formatMinor(5, "USD") != "USD 0.05" {
		t.Errorf("formatMinor = %q %q", formatMinor(123_456_789, "AED"), formatMinor(5, "USD"))
	}
}

func TestHighResolutionTimer(t *testing.T) {
	start := hrTicks()
	time.Sleep(2 * time.Millisecond)
	elapsed := hrElapsed(start, hrTicks())
	if elapsed < time.Millisecond || elapsed > time.Second {
		t.Fatalf("2 ms sleep measured as %s (%s)", elapsed, hrMethod())
	}
	window := beginResources(time.Millisecond)
	buffer := make([]byte, 1<<20)
	_ = buffer
	usage := window.end("test")
	if usage.WallMS <= 0 || usage.MemorySamples < 1 {
		t.Fatalf("usage = %+v", usage)
	}
}

// --- smoke runs of every subcommand ----------------------------------------------------

func readJSONFile(t *testing.T, path string, out any) {
	t.Helper()
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if err := json.Unmarshal(data, out); err != nil {
		t.Fatalf("%s: %v", path, err)
	}
}

func runSmoke(t *testing.T, args ...string) string {
	t.Helper()
	out := t.TempDir()
	var stdout, stderr strings.Builder
	full := append(append([]string{}, args...), "-out", out, "-work", t.TempDir())
	if code := run(full, &stdout, &stderr); code != 0 {
		t.Fatalf("%v: exit %d\n%s\n%s", full, code, stdout.String(), stderr.String())
	}
	return out
}

func TestCrashSmoke(t *testing.T) {
	const label = "eval-smoke-host"
	out, work := t.TempDir(), t.TempDir()
	args := []string{"-host-label", label, "crash", "-points", "provider_response_lost", "-out", out, "-work", work}
	defer func() { hostLabelOption = "" }()
	var stdout, stderr strings.Builder
	if code := run(args, &stdout, &stderr); code != 0 {
		t.Fatalf("%v: exit %d\n%s\n%s", args, code, stdout.String(), stderr.String())
	}
	var result crashResult
	readJSONFile(t, filepath.Join(out, "crash.json"), &result)
	if len(result.Schedules) != 4 || result.Totals.Operations != 8 || result.Totals.ScheduleErrors != 0 {
		t.Fatalf("schedules %d, totals %+v", len(result.Schedules), result.Totals)
	}
	if result.Totals.DuplicatePerID != 0 || result.Totals.RejectedWithEffect != 0 || result.Totals.CommittedWithoutEffect != 0 || result.Totals.EvidenceGaps != 0 {
		t.Fatalf("totals = %+v", result.Totals)
	}
	for _, schedule := range result.Schedules {
		for _, cell := range schedule.Cells {
			if cell.First.Status != "UNCERTAIN" || !cell.FaultFired {
				t.Errorf("%s %s %s: first answer %s, fired %v", cell.Retry, cell.Restart, cell.Effect, cell.First.statusKey(), cell.FaultFired)
			}
			if cell.Retry == "same-id" && (cell.RetryCall.statusKey() != "COMMITTED/reconciled" || cell.EffectsContent != 1) {
				t.Errorf("same-id retry: %s, effects %d", cell.RetryCall.statusKey(), cell.EffectsContent)
			}
			if cell.Retry == "fresh-id" && (!cell.BusinessDup || cell.EffectsContent != 2) {
				t.Errorf("fresh-id retry: effects %d, business duplicate %v", cell.EffectsContent, cell.BusinessDup)
			}
		}
		if want := map[string]int{"none": 1, "journal": 2}[schedule.Restart]; len(schedule.Segments) != want {
			t.Errorf("%s: %d evidence folders, want %d", schedule.Label, len(schedule.Segments), want)
		}
		// Evidence continuity: the segment opened after the restart names
		// the first one, so the verifier checks both together and the
		// restored operations are no false alarm.
		for index, segment := range schedule.Segments {
			if segment.Verdict != "VERIFIED" || segment.Assurance != "ANCHORED" {
				t.Errorf("%s segment %d: %s/%s, failing %v: %v", schedule.Label, index+1, segment.Verdict, segment.Assurance, segment.Failing, segment.Findings)
			}
		}
	}
	// -host-label: the label, never the machine name, is what the evidence
	// records as where it ran.
	if result.Totals.SegmentsVerified != 6 {
		t.Errorf("segments verified %d, want 6", result.Totals.SegmentsVerified)
	}
	// Missing by kind: every pinned folder lists the head-freshness gap (so
	// the any-kind count is saturated); the reconciled payment and message
	// (a lost response leaves no adapter receipt) rest on the issuer key.
	byKind := result.Totals.SegmentsMissingByKind
	if result.Totals.SegmentsWithMissing != 6 || byKind[auditverify.MissingKindFreshness] != 6 || byKind[auditverify.MissingKindIssuerOnly] == 0 || len(byKind) != len(auditverify.MissingKinds()) {
		t.Errorf("segments with missing items %d, by kind %v", result.Totals.SegmentsWithMissing, byKind)
	}
	for _, schedule := range result.Schedules {
		for index, segment := range schedule.Segments {
			total := 0
			for _, count := range segment.MissingByKind {
				total += count
			}
			if total != len(segment.Missing) || segment.Dimensions[auditverify.DimHeadFresh] != auditverify.DimensionNotChecked {
				t.Errorf("%s segment %d: missing by kind %v for %d entries, head_fresh %q", schedule.Label, index+1, segment.MissingByKind, len(segment.Missing), segment.Dimensions[auditverify.DimHeadFresh])
			}
		}
	}
	host, _ := os.Hostname()
	checked := 0
	err := filepath.WalkDir(work, func(path string, entry os.DirEntry, err error) error {
		if err != nil || entry.IsDir() || (entry.Name() != "run.json" && entry.Name() != "audit.jsonl") {
			return err
		}
		data, err := os.ReadFile(path)
		if err != nil {
			return err
		}
		if host != "" && strings.Contains(strings.ToLower(string(data)), strings.ToLower(host)) {
			t.Errorf("%s mentions the machine name %q", path, host)
		}
		if !strings.Contains(string(data), label) {
			t.Errorf("%s does not record the host label", path)
		}
		checked++
		return nil
	})
	if err != nil || checked != 12 {
		t.Fatalf("checked %d run.json/audit.jsonl files, want 12 (6 segments): %v", checked, err)
	}
	for _, name := range []string{"crash.csv", "crash.md"} {
		if _, err := os.Stat(filepath.Join(out, name)); err != nil {
			t.Error(err)
		}
	}
}

func TestConcurrencySmoke(t *testing.T) {
	out := runSmoke(t, "concurrency", "-repeat", "2", "-n", "4")
	var result concurrencyResult
	readJSONFile(t, filepath.Join(out, "concurrency.json"), &result)
	if len(result.Repetitions) != 2 || len(result.Repetitions[0].Scenarios) != len(concurrencyScenarios) || result.Repetitions[0].Error != "" {
		t.Fatalf("repetitions = %+v", result.Repetitions)
	}
	// Genuine concurrent evidence must verify: decisions are logged in the
	// order the delegation ledger reserved (delegation.accounting), and a
	// conflicting caller's call-scope refusal is not a REJECTED answer for
	// the executed call (op.outcome_resolved).
	for _, repetition := range result.Repetitions {
		if repetition.Evidence.Verdict != "VERIFIED" {
			t.Errorf("repetition %d: evidence %s %v %v", repetition.Repeat, repetition.Evidence.Verdict, repetition.Evidence.Failing, repetition.Evidence.Findings)
		}
	}
	for _, scenario := range result.Repetitions[0].Scenarios {
		if scenario.MaxPerID > 1 || len(scenario.Calls) != 4 {
			t.Errorf("%s: max effects per ID %d, calls %d", scenario.Scenario, scenario.MaxPerID, len(scenario.Calls))
		}
		if strings.HasPrefix(scenario.Scenario, "exact-") && scenario.Effects != 1 {
			t.Errorf("%s: %d effects", scenario.Scenario, scenario.Effects)
		}
	}
}

func TestMisuseSmoke(t *testing.T) {
	out := runSmoke(t, "misuse", "-groups", "boundary,revocation,confidential-text")
	var result misuseResult
	readJSONFile(t, filepath.Join(out, "misuse.json"), &result)
	classes := map[string]string{}
	for _, testCase := range result.Cases {
		if testCase.Error != "" {
			t.Errorf("%s: %s", testCase.Case, testCase.Error)
		}
		for _, step := range testCase.Steps {
			classes[testCase.Case+"/"+step.Label] = step.Class
			if step.Class == "error" {
				t.Errorf("%s / %s: %+v", testCase.Case, step.Label, step.Result)
			}
			if !step.Matches {
				t.Errorf("%s / %s: expected %s, got %s (rules %v)", testCase.Case, step.Label, step.Expected, step.Class, step.Deciding)
			}
		}
	}
	for key, want := range map[string]string{
		"AED auto limit/auto limit": "permitted", "AED auto limit + 1/auto limit + 1": "flagged", "AED hard limit + 1/hard limit + 1": "blocked",
		"AED zero/zero": "blocked", "revoked grant/payment after revocation": "blocked",
		// Punctuation is stripped before shingling: inserted commas do not
		// hide a verbatim copy; a paraphrase still does (documented limit).
		"comma after every fifth word, external/comma after every fifth word, external": "blocked",
		"paraphrase, external/paraphrase, external":                                     "flagged",
	} {
		if classes[key] != want {
			t.Errorf("%s: %q, want %q", key, classes[key], want)
		}
	}
}

func TestBaselineSmoke(t *testing.T) {
	out := runSmoke(t, "baseline", "-trials", "6", "-block", "3", "-warmup", "1", "-clients", "1,2", "-load-calls", "4",
		"-configs", "direct,policy-only,full,full-flagged", "-load-configs", "direct,full")
	var result baselineResult
	readJSONFile(t, filepath.Join(out, "baseline.json"), &result)
	if result.Sequential == nil || result.Sequential.Trials != 6 || result.Sequential.Blocks != 2 || len(result.Sequential.Configs) != 4 {
		t.Fatalf("sequential = %+v", result.Sequential)
	}
	for _, row := range result.Sequential.Configs {
		if row.Latency.N != 6 || row.Failed != 0 {
			t.Errorf("%s: n %d failed %d", row.Config, row.Latency.N, row.Failed)
		}
		if strings.HasPrefix(row.Config, "full") && (len(row.Evidence) != 2 || row.Evidence[0] != auditverify.AssuranceAnchored) {
			t.Errorf("%s evidence %v %v", row.Config, row.Evidence, row.EvidenceFails)
		}
	}
	if len(result.Sequential.Paired) == 0 {
		t.Error("no paired differences")
	}
	if len(result.Concurrent) != 4 || len(result.Errors) != 0 {
		t.Fatalf("concurrent = %+v, errors %v", result.Concurrent, result.Errors)
	}
	for _, cell := range result.Concurrent {
		if cell.Calls != 4 || cell.Failed != 0 || cell.Throughput <= 0 {
			t.Errorf("cell %+v", cell)
		}
	}
	for _, name := range []string{"baseline-sequential.csv", "baseline-concurrent.csv", "baseline-concurrent-summary.csv", "baseline.md"} {
		data, err := os.ReadFile(filepath.Join(out, name))
		if err != nil || len(data) == 0 {
			t.Errorf("%s: %v", name, err)
		}
	}
}

func TestCustodySmoke(t *testing.T) {
	if testing.Short() {
		t.Skip("builds the custody binaries and runs a complete demo self-test")
	}
	out := runSmoke(t, "custody")
	var result custodyResult
	readJSONFile(t, filepath.Join(out, "custody.json"), &result)
	if !result.Passed || len(result.Cells) == 0 {
		t.Fatalf("self-test passed %v (%s), cells %d, notes %v", result.Passed, result.SelfTest, len(result.Cells), result.Facts.Notes)
	}
	detected, withheld := map[string]bool{}, map[string]bool{}
	segmentAnchored := map[string]bool{}
	for _, cell := range result.Cells {
		if cell.FalseFail || cell.Outcome.Error != "" {
			t.Errorf("false alarm or error: %s / %s: %v %s", cell.Variant, cell.Anchors, cell.Outcome.Failing, cell.Outcome.Error)
		}
		switch cell.Variant {
		case variantRollback:
			detected[cell.Anchors] = cell.Detected
		case variantWithheld:
			withheld[cell.Anchors] = cell.Detected
		case variantSegment:
			segmentAnchored[cell.Anchors] = cell.Anchored
		}
	}
	if detected["none"] || !detected["witness latest cosigned head"] || !detected[anchorLive] || !detected["keys+head pinned"] {
		t.Errorf("rollback detection by anchors = %v", detected)
	}
	// The self-test restarts the gateway into a continuation segment: the
	// first folder alone withholds it. The live witness (head and run
	// status) detects that; a saved head cannot (the documented limit).
	if result.Facts.SegmentRunID == "" || !result.Facts.ContinuedBySegment {
		t.Fatalf("restart segment facts = %+v", result.Facts)
	}
	if !withheld[anchorLive] || withheld["witness latest cosigned head"] || !withheld["head pinned = run's final head (segment)"] {
		t.Errorf("withheld-segment detection by anchors = %v", withheld)
	}
	if !segmentAnchored[anchorLive] || !segmentAnchored["keys+head pinned (segment)"] || segmentAnchored["none"] {
		t.Errorf("the whole run (newest segment) ANCHORED by anchors = %v", segmentAnchored)
	}
	// Witness enrollment: the restarted witness holds the pinned key, its
	// signed status names the gateway's enrollment key, and every probe of a
	// party without that key was refused and left no trace.
	f := result.Facts
	if f.EnrollmentKID == "" || f.StatusEnrollmentKID != f.EnrollmentKID || !f.WitnessPinMatches || !f.WitnessKeyStable {
		t.Errorf("enrollment facts: kid %q, status kid %q, pin matches %t, key stable %t", f.EnrollmentKID, f.StatusEnrollmentKID, f.WitnessPinMatches, f.WitnessKeyStable)
	}
	if len(f.EnrollmentProbes) != 5 || refusedProbes(f.EnrollmentProbes) != 5 || !f.ProbesLeftNoTrace {
		t.Errorf("enrollment probes: %d of %d refused, no trace %t: %+v", refusedProbes(f.EnrollmentProbes), len(f.EnrollmentProbes), f.ProbesLeftNoTrace, f.EnrollmentProbes)
	}
}
