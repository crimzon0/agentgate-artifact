package main

import (
	"flag"
	"fmt"
	"io"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"

	"agentgate/internal/auditverify"
)

// The scale experiment measures how verifier runtime grows with the log.
// Each size is one fresh demo run made by the self-test with that many
// scenario suites (each suite = 14 scenarios + 3 custom requests); after one
// discarded warm-up, the closed run is verified -reps times without pins
// (agentgate-verify --workers 1 DIR) and -reps times pinned to the keys
// fingerprint and the final head (agentgate-verify --workers 1 --expect-keys
// --expect-head). These timings use the sequential verifier (one worker), so
// they stay comparable across machines and with earlier results.
//
// With -workers, the same runs are instead verified (pinned) with each listed
// worker count, and the parallel speedup over one worker is reported in
// parallel.json/md (see parallel.go).

type scalePoint struct {
	Repeat     int     `json:"repeat"`
	RunID      string  `json:"run_id"`
	Entries    int     `json:"entries"`
	LogBytes   int64   `json:"log_bytes"`
	EvidenceKB float64 `json:"evidence_kb"`
	Operations int     `json:"operations"`
	Effects    int     `json:"effects"`
	Unpinned   summary `json:"unpinned_ms"`
	Pinned     summary `json:"pinned_ms"`
	// PerEntryUS is the pinned median divided by the number of entries.
	PerEntryUS float64 `json:"pinned_per_entry_us"`
	Verdict    string  `json:"pinned_verdict"`
	Checks     int     `json:"pinned_checks_passed"`
}

type linearFit struct {
	SlopeMSPer1000 float64 `json:"slope_ms_per_1000_entries"`
	InterceptMS    float64 `json:"intercept_ms"`
	R2             float64 `json:"r2"`
}

type scaleResult struct {
	Format      string       `json:"format"`
	Note        string       `json:"note"`
	Environment environment  `json:"environment"`
	Reps        int          `json:"reps"`
	Points      []scalePoint `json:"points"`
	FitPinned   linearFit    `json:"fit_pinned_median"`
	Runs        []baseRun    `json:"runs"`
	DurationS   float64      `json:"duration_s"`
}

func runScale(args []string, stdout io.Writer) error {
	flags := flag.NewFlagSet("scale", flag.ContinueOnError)
	sizes := flags.String("sizes", "1,2,5,10,20", "comma-separated self-test repeat counts (one run per value)")
	reps := flags.Int("reps", 7, "timed verifications per configuration and run")
	out := flags.String("out", "", "output directory for scale.json/md (parallel.json/md with -workers)")
	work := flags.String("work", "", "directory for the runs (default: temp)")
	workers := flags.String("workers", "", "comma-separated verifier worker counts including 1 (e.g. 1,2,4,6,12): measure the parallel speedup and write parallel.json/md instead of scale.json/md")
	machine := flags.String("machine", "", "processor description recorded with -workers results (e.g. \"AMD Ryzen 5 7600X, 6 cores / 12 threads\")")
	conditions := flags.String("conditions", "", "free-text measurement conditions recorded with -workers results (e.g. background load)")
	if err := flags.Parse(args); err != nil {
		return err
	}
	repeats, err := parsePositiveList(*sizes, "-sizes")
	if err != nil {
		return err
	}
	if *reps < 1 {
		return fmt.Errorf("-reps must be at least 1")
	}
	var workerCounts []int
	if *workers != "" {
		if workerCounts, err = parseWorkerCounts(*workers); err != nil {
			return err
		}
	}
	outDir, workDir, err := prepareDirs(*out, *work, "scale")
	if err != nil {
		return err
	}
	ctx, cancel := interruptible()
	defer cancel()
	if workerCounts != nil {
		return runParallelSweep(ctx, parallelSetup{repeats: repeats, reps: *reps, workers: workerCounts, machine: *machine, conditions: *conditions,
			outDir: outDir, workDir: workDir, args: args}, stdout)
	}
	began := time.Now()
	result := scaleResult{
		Format: "agentgate-eval-scale/v1",
		Note: "Local measurements on one computer; each point is one run, timed several times in one process (warm file cache). " +
			"Runtime includes reading and parsing the files and every check. The verifier runs sequentially (Workers = 1).",
		Environment: currentEnvironment(append([]string{"scale"}, args...)),
		Reps:        *reps,
	}
	for index, repeat := range repeats {
		fmt.Fprintf(stdout, "repeat %d: self-test ... ", repeat)
		run, err := createBaseRun(ctx, index+1, filepath.Join(workDir, "runs"), repeat)
		if err != nil {
			return err
		}
		point := scalePoint{Repeat: repeat, RunID: run.RunID, Entries: run.Entries, LogBytes: run.LogBytes,
			EvidenceKB: run.EvidenceKB, Operations: run.Operations, Effects: run.Effects}
		pinned := auditverify.Options{ExpectKeysSHA256: run.KeysSHA256, ExpectHead: run.HeadHash, Workers: 1}
		if _, err := auditverify.VerifyRun(run.dir, pinned); err != nil { // warm-up
			return err
		}
		time1 := func(options auditverify.Options) (summary, auditverify.Report, error) {
			var values []float64
			var last auditverify.Report
			for rep := 0; rep < *reps; rep++ {
				start := time.Now()
				report, err := auditverify.VerifyRun(run.dir, options)
				if err != nil {
					return summary{}, report, err
				}
				values = append(values, round(ms(time.Since(start)), 3))
				last = report
			}
			return summarize("ms", values), last, nil
		}
		if point.Unpinned, _, err = time1(auditverify.Options{Workers: 1}); err != nil {
			return err
		}
		var report auditverify.Report
		if point.Pinned, report, err = time1(pinned); err != nil {
			return err
		}
		point.Verdict, point.Checks = report.Verdict, report.Counts.ChecksPassed
		if report.Verdict != auditverify.VerdictVerified {
			return fmt.Errorf("run %s did not verify: %v", run.RunID, failingCheckIDs(report))
		}
		point.PerEntryUS = round(point.Pinned.Median*1000/float64(max(1, run.Entries)), 2)
		result.Points = append(result.Points, point)
		result.Runs = append(result.Runs, run)
		fmt.Fprintf(stdout, "%d entries, pinned median %.1f ms\n", run.Entries, point.Pinned.Median)
	}
	result.FitPinned = fitLine(result.Points)
	result.DurationS = round(time.Since(began).Seconds(), 1)
	if err := writeJSON(filepath.Join(outDir, "scale.json"), result); err != nil {
		return err
	}
	if err := writeText(filepath.Join(outDir, "scale.md"), scaleMarkdown(result)); err != nil {
		return err
	}
	fmt.Fprintf(stdout, "wrote %s (scale.json, scale.md)\n", outDir)
	return nil
}

// parsePositiveList parses a comma-separated list of positive integers.
func parsePositiveList(text, flagName string) ([]int, error) {
	var values []int
	for _, field := range strings.Split(text, ",") {
		value, err := strconv.Atoi(strings.TrimSpace(field))
		if err != nil || value < 1 {
			return nil, fmt.Errorf("%s: %q is not a positive integer", flagName, field)
		}
		values = append(values, value)
	}
	return values, nil
}

// parseWorkerCounts parses -workers: distinct positive counts, including 1
// (the sequential baseline every speedup is relative to), in ascending order.
func parseWorkerCounts(text string) ([]int, error) {
	values, err := parsePositiveList(text, "-workers")
	if err != nil {
		return nil, err
	}
	sort.Ints(values)
	for i := 1; i < len(values); i++ {
		if values[i] == values[i-1] {
			return nil, fmt.Errorf("-workers: %d is listed twice", values[i])
		}
	}
	if values[0] != 1 {
		return nil, fmt.Errorf("-workers must include 1, the sequential baseline")
	}
	return values, nil
}

// fitLine is an ordinary least-squares fit of pinned median runtime (ms)
// against entries.
func fitLine(points []scalePoint) linearFit {
	n := float64(len(points))
	if n < 2 {
		return linearFit{}
	}
	var sx, sy, sxx, sxy float64
	for _, point := range points {
		x, y := float64(point.Entries), point.Pinned.Median
		sx, sy, sxx, sxy = sx+x, sy+y, sxx+x*x, sxy+x*y
	}
	denominator := n*sxx - sx*sx
	if denominator == 0 {
		return linearFit{}
	}
	slope := (n*sxy - sx*sy) / denominator
	intercept := (sy - slope*sx) / n
	mean := sy / n
	var residual, total float64
	for _, point := range points {
		predicted := intercept + slope*float64(point.Entries)
		residual += (point.Pinned.Median - predicted) * (point.Pinned.Median - predicted)
		total += (point.Pinned.Median - mean) * (point.Pinned.Median - mean)
	}
	r2 := 1.0
	if total > 0 {
		r2 = 1 - residual/total
	}
	return linearFit{SlopeMSPer1000: round(slope*1000, 3), InterceptMS: round(intercept, 3), R2: round(r2, 4)}
}

func scaleMarkdown(result scaleResult) string {
	var b strings.Builder
	fmt.Fprintf(&b, "# Verifier runtime against log size\n\n%s\n\n", result.Note)
	fmt.Fprintf(&b, "- Command: `%s`; Go %s on %s/%s, %d CPUs; %d timed verifications per configuration and point; total %.0f s.\n\n",
		result.Environment.Command, result.Environment.GoVersion, result.Environment.GOOS, result.Environment.GOARCH,
		result.Environment.NumCPU, result.Reps, result.DurationS)
	fmt.Fprintf(&b, "| Suites | Entries | audit.jsonl KB | Operations | Effects | Unpinned median ms | Pinned median ms (min-max) | Pinned us/entry |\n|---|---|---|---|---|---|---|---|\n")
	for _, point := range result.Points {
		fmt.Fprintf(&b, "| %d | %d | %.0f | %d | %d | %.1f | %.1f (%.1f-%.1f) | %.1f |\n", point.Repeat, point.Entries,
			float64(point.LogBytes)/1024, point.Operations, point.Effects, point.Unpinned.Median, point.Pinned.Median,
			point.Pinned.Min, point.Pinned.Max, point.PerEntryUS)
	}
	fit := result.FitPinned
	fmt.Fprintf(&b, "\nLeast-squares fit of the pinned median: slope %.2f ms per 1,000 entries, intercept %.2f ms (R^2 = %.4f).\n", fit.SlopeMSPer1000, fit.InterceptMS, fit.R2)
	return b.String()
}
