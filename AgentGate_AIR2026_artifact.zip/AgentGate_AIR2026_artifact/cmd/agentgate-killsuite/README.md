# agentgate-killsuite: the OS-level crash suite

This program kills and restarts real gateway processes and checks what
survives. It answers the reviewer's request for a focused crash suite: kill the
gateway at its durable transitions, let the provider misbehave, cross the
faults with the flagged and human-approval paths, and show that

- no operation ID ever gets a second provider effect, and
- no operation is reported as having no effect (`REJECTED`, in particular
  `provider_not_committed`) while the provider holds one.

It does not change the gateway or the verifier. Every evidence folder is
checked with the `agentgate-verify` program you pass with `-verify`.

Everything is simulated and local: a loopback provider with in-memory state,
synthetic payees and recipients, per-run keys generated in memory. No private
key is ever written to disk or read from one, nothing is re-signed, and the
test secrets (MCP bearer, admin token, approver credential) are passed to each
child through its environment only.

## How it works

The binary has two modes.

- **`run` (the parent).** For every cell it starts a fresh provider inside its
  own (the parent's) process, not `agentgate-provider` (so the provider
  survives every kill; wording clarified 2026-10-10), signs a delegation grant,
  starts a gateway child, drives MCP `tools/call` over loopback HTTP, and
  records each answer. A reset connection counts as *no answer*. After a kill
  it writes the dead segment's `provider-journal.json` from the provider,
  restarts a new child on the same operation journal, retries, asks the child
  for `Composition.Reconcile`, closes it gracefully and runs `agentgate-verify
  --json` on every segment.
- **`gateway` (the child, started by `run`).** One real gateway
  (`devcomposition.New`) with its MCP endpoint on loopback, its operation
  journal and one evidence segment written by the signed audit log. It prints
  a ready line with the `keys.json` fingerprint and streams its head after
  every audit append, so the parent holds real external pins for a process it
  then kills. A restart reads the continuation (run ID, final head, keys
  fingerprint) from the dead segment's own files (`audit.ReadContinuation`).

A kill is `os.Exit(86)` at the kill point (no deferred code, no flush, no log
close), or `TerminateProcess` from the parent for the two human points that
have no gateway hook. **On Windows both model a crash of the gateway process,
not a power loss:** the kernel's file cache survives, so a killed process
never loses a write it already made. Power loss is approximated by the
surrogate cells below.

## Build and run (offline toolchain)

```bash
export GOMODCACHE="$PWD/.tools/go-host-cache-20260916/mod" GOPROXY=off GOFLAGS=-mod=readonly GOTOOLCHAIN=local
GO=./.tools/go-1.26.6/bin/go.exe
$GO build -trimpath -buildvcs=false -o agentgate-killsuite.exe ./cmd/agentgate-killsuite
$GO build -trimpath -buildvcs=false -o agentgate-verify.exe ./cmd/agentgate-verify
./agentgate-killsuite.exe run -verify ./agentgate-verify.exe -out results -reps 5 -commit <commit or archive digest>
```

Build the verifier from the same commit as the suite: the suite reads the
verifier's `classification_evidence` and relies on its recovery- and
replay-flag rules, which older (frozen) verifier builds do not have.
`-trimpath -buildvcs=false` keeps the checkout path and the VCS stamp out of
the binaries, so a rebuild of the commit recorded with `-commit` with the
same Go toolchain, from any checkout path, should give the same SHA-256
values.

| flag | default | meaning |
|---|---|---|
| `-verify PATH` | required | the `agentgate-verify` program used on every folder |
| `-out DIR` | required | where `results.json`, `results.csv` and `summary.md` go |
| `-work DIR` | temp folder | where the cell folders go (kept after the run) |
| `-reps N` | 5 | repetitions of every cell (stability, not samples) |
| `-groups LIST` | all | `kill`, `human`, `provider`, `surrogate`, `journal`, `replay` |
| `-only LIST` | | run only cells whose name contains one of these substrings |
| `-host-label TEXT` | `review-host` | host name recorded in the evidence instead of the machine name |
| `-call-timeout D` | 60s | timeout of one call to a child (at least 15 s: the delay cells wait out the adapter's 10 s timeout) |
| `-commit TEXT` | | the source commit the binaries were built from, recorded in the build manifest as given |
| `-list` | | print the selected cells and exit |

The two delayed-delivery cells each wait out the adapter's 10 s response
timeout; every other cell is much shorter. `results.json` records the elapsed
time of every cell and of the run.

Ctrl-C stops the run after the current cell. A call cancelled by Ctrl-C is
not recorded as a kill: the cell is marked `interrupted`, counts as a cell
error, and the results cover the cells that ran. A Ctrl-C during a cell's
close-and-verify step marks that cell `interrupted` too (the children and
the verifier share the console), and an interrupted run never passes the
acceptance, even when the interrupt fell between two cells.

## The cells

**Kill points** (`kill/<point>/<path>/<retry>`). Each is crossed with the
ALLOW payment (400.00 AED to an in-grant payee, allowed, not flagged) and the
FLAG message (to an external partner, allowed and flagged), both with an exact
(same-ID) retry after the restart, plus a fresh-ID control for the payment.

| kill point | where the child dies | on disk at that moment |
|---|---|---|
| `before_consume` | fault hook `before_capability_consume` | capability issued and journaled, not consumed; nothing sent |
| `after_consume` | fault hook `after_capability_consume` | capability consumed, dispatch intent not yet journaled; no request byte sent |
| `after_provider_response` | fault hook `provider_response_lost` | intent journaled, provider committed and answered; the gateway dies before reading the answer |
| `after_receipt` | fault hook `after_receipt_before_audit` | receipts verified and signed, `EFFECT_EXECUTED` not appended |
| `before_effect_executed` | fault hook `audit_append` | as above, at the `EFFECT_EXECUTED` append itself |
| `after_effect_executed` | audit sink, right after the append | `EFFECT_EXECUTED` and head written; the journal's `recorded` record not |
| `before_call_result` | audit sink, right before the append | `recorded` journaled (stored answer); `CALL_RESULT` not appended |

The `head_replace` hook fires at the same moment as `audit_append`, so it is
not a separate point. A kill *inside* `audit.Append` (between the line fsync
and the head rename) has no hook; the `head_reverted` surrogate covers the
state it would leave.

**Human path** (`human/<point>`, human mode, 12,400.00 AED needs an approval):
`pending` (terminated after the challenge, before any decision), `approved`
(terminated after the approver approved, before the agent resumed),
`after_consume` and `after_receipt` (gateway kill points of the approved
call). The approver's click is driven through the approval relay's real
handlers inside the child (page, CSRF token, decision POST); a local click is
not authenticated consent.

**Provider faults, no kill** (`provider/<fault>/<path>`):

| fault | what the provider does | expected |
|---|---|---|
| `lost_response` | commits, withholds the answer (`DROP_AFTER_COMMIT`) | `UNCERTAIN`, the retry reconciles: `COMMITTED` |
| `certified_no_effect` | drops before committing (`DROP_BEFORE_COMMIT`) | the retry's lookup draws a signed `ABSENT`: `REJECTED/provider_not_committed`, 0 effects |
| `unknown_then_applied` | lost answer, then a signed `UNKNOWN` status | `UNCERTAIN/provider_status_unknown`, then `COMMITTED` |
| `delayed_release_before_lookup` | holds the dispatch past the gateway's 10 s timeout, delivers it before the retry | `COMMITTED` (reconciled), 1 effect |
| `delayed_release_after_absent` | holds the dispatch; the retry draws `ABSENT` first; then the late delivery arrives | the tombstone refuses it: 0 effects, no false no-effect |
| `lookup_failure_3` | lost answer, then 3 status lookups answered HTTP 503 | `UNCERTAIN/reconciliation_unavailable` three times, never re-dispatched, then resolved by Reconcile |
| `lookup_failure_persistent` | every lookup answered 503 | still `UNCERTAIN` after Reconcile (deliberate), never re-dispatched |

`lost_response` also runs on the flagged message.

Every provider fault must leave the first answer `UNCERTAIN`; a different
first answer means the fault never fired, and the cell fails rather than
passing as a fault-free run. The lookup-failure cells also check that the
provider really answered the lookups with 503, `unknown_then_applied` that the
first retry drew the signed `UNKNOWN`, and the delayed cells that the dispatch
was really held and released.

**Power-loss surrogates** (`surrogate/<state>`), on the folder of a kill after
`EFFECT_EXECUTED`. An untouched copy is kept as `as-killed/` and verified
alone; the surrogate is applied to the working folder the restart uses, with
bytes the gateway itself wrote:

| state | how it is made | expected |
|---|---|---|
| `torn_journal_tail` | first half of the last `operations.jsonl` line appended, no newline | the journal discards it; the restart proceeds |
| `torn_audit_tail` | first half of the last `audit.jsonl` line appended, no newline | the continuation cannot be read: restart refused (fail closed); segment 1 `FAILED`; the effect the provider applied stays unaccounted for until the folder is repaired by hand |
| `head_reverted` | `head.json` replaced by the previous genuine head the child streamed | the restart proceeds (the continuation takes the head from the log's last line, not from `head.json`), but `head.matches` fails for segment 1 and the run walk: a permanent alarm on a crash state with nothing tampered (a power loss can leave this on Windows: no directory flush, `os.Rename` is not write-through) |
| `temp_head_left` | a `.head.json.tmp-*` file holding the current head, next to an intact head | shows whether the verifier minds a leftover temporary file |

**One journal write failure** (`journal/read_only_at_consume`): right after
the capability is consumed the child sets the journal file's read-only
attribute (a file attribute, not a system setting), so the dispatch-intent
write fails. A second operation and an exact retry follow in the same
process; then the child is closed, the attribute is cleared and the restarted
gateway gets the exact retry. If the attribute was not set, or the first
answer is not `REJECTED`, the cell fails.

**Replay of a committed flagged operation** (`replay/flag-message/same-process`,
no fault): the flagged message commits, two exact retries go to the same
gateway process (answered with the stored result from the coordinator's
store; no policy check runs again), then the gateway is closed and
restarted and one more exact retry is answered from the journal. Every
answer must be `COMMITTED`; the cell checks that every replayed
`CALL_RESULT` keeps the flag (`flag_in_replay_entries`, part of
`flag_preserved`), and the verifier fails `op.requires_policy` on a replay
that drops it. The kill cells cover only replays after a restart
(`before_call_result`), so this is the one cell for the same-process path.

## Acceptance measures

Per cell in `results.json` and `results.csv`, summed in `summary.md`:

| measure | required |
|---|---|
| cells that could not run, or did not test what they model (a kill point or fault that never fired, the journal attribute not set, an interrupted cell) | 0 |
| operation IDs with more than one provider effect (from the provider's own signed journal) | 0 |
| `REJECTED` answered while the provider held an effect for that operation ID | 0 |
| `REJECTED/provider_not_committed` while the provider holds an effect, checked at the end of the cell (catches a late delivery after `ABSENT`) | 0 |
| `COMMITTED` answered while the provider held no effect | 0 |
| operations still `UNCERTAIN`/`RECONCILIATION_REQUIRED` after Reconcile, over every operation the gateway lists (original, fresh-ID and probe), except deliberate cells | 0 |
| operations of the cell (listed by the gateway after Reconcile or not) that were dispatched (the gateway says so, or the provider received a request) or for which the provider holds an effect, and that are not `COMMITTED` or `REJECTED` after Reconcile, except deliberate cells | 0 |
| an operation ID dispatched to the provider more than once (counted by the provider per `X-Agentgate-Operation-Id`) | 0 |
| dispatch requests whose operation ID is missing or none of the cell's operations | 0 |
| kill points not reached, or a child that died at another point or for another operation than the cell's | 0 |
| an interrupted run (Ctrl-C) | none |

Reported, not required: deliberate unresolved operations; operations left
undecided after Reconcile (no final status at all, e.g. the original operation
of a fresh-ID control killed after its capability was consumed, and every
operation of the cell the gateway does not list, counted separately as
unlisted, e.g. the journal cell's probe, refused before it could be
journaled); `REJECTED` answers whose operation ID the restarted gateway later
committed; fresh-ID business duplicates; restarts refused; the second
approval a restarted human cell needed; flag preservation (`flag_preserved`:
every `RECONCILED(committed)` and `CALL_RESULT(COMMITTED)` entry of a flagged
operation says `flagged`; the agent's answer is judged only if it carries
`flagged`), with two subsets counted separately: the recovery entries
(`RECONCILED(committed)`, a reconciling `CALL_RESULT`, and in a restarted
segment a replay or an outcome entry of an operation that did not simply run
again from scratch there) and the replayed answers (`CALL_RESULT(COMMITTED)`
with `replayed`, split into those written by the process that recorded the
effect and those after a restart); the verifier's classification evidence
for the original operation, taken only from a folder that VERIFIED (a FAILED
newest folder is counted as "not reported (newest folder FAILED)"); its
warnings; its verdicts: segment 1 alone, the newest segment with the chain
followed (run walk), and single segments; and, apart from those, the
verdicts, failing checks and warnings of the surrogate cells' untouched
as-killed copies.

## Results

This README carries no results, because they depend on the build. Each run
writes them to `results.json`, `results.csv` and `summary.md`; the `build`
section of `results.json` (the results manifest, repeated at the top of
`summary.md`) names the builds they come from: the SHA-256 and the embedded
VCS revision of this program, which is also every gateway child, and of the
verifier given by `-verify`. Cite a result only together with the build named
in its results manifest. The SHA-256 is authoritative. The VCS stamp is
whatever the Go toolchain embedded: `vcs.modified` is true whenever the
checkout has untracked files, and a build inside a git worktree nested in
another checkout carries the outer checkout's revision. Build as shown above
(`-trimpath -buildvcs=false`) and record the commit with `-commit`; the
manifest's `commit` is the operator's statement, which a rebuild can check
against the SHA-256 values.

## Limits

One machine, one gateway build per run, a simulated provider that never
crashes, kills only at instrumented points (plus two external terminations),
process crashes rather than power cuts, and repetitions that show stability
rather than statistical samples. `before_effect_executed` leaves the same
journal and audit state on disk as `after_receipt`, so the seven kill points
are six distinct on-disk states. The human cells drive the approval relay's
real handlers in process with a synthetic TLS, loopback and browser-header
request; no browser or TLS connection is exercised. These are observations of
these schedules only.

## Files

`main.go` (modes, flags, the run loop), `child.go` (the gateway child),
`evidence.go` (its evidence folder, head streaming, sink kill points),
`provider.go` (the parent's provider with fault injection), `process.go`
(child process, MCP and admin clients), `cells.go` (the cell schedules),
`matrix.go` (kill points and cells), `surrogate.go` (power-loss surrogates),
`verify.go` (the `agentgate-verify` call), `results.go` (measures and result
files), `world.go` (the synthetic world, copied from `cmd/agentgate-eval`).
A cell folder holds `operations.jsonl`, `segment-N/` (the evidence),
`segment-N.child.json` (the child's configuration, no secrets) and
`segment-N.stderr.log`.
