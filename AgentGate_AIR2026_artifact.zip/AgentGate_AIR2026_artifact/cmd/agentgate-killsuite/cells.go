package main

// One cell: a fresh run identity, provider host, grant and journal; one or two
// gateway child processes (segments); the calls of the cell's schedule; the
// verifier on every segment; the acceptance measures.

import (
	"context"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"agentgate/internal/adapters"
	"agentgate/internal/audit"
	"agentgate/internal/devcomposition"
	"agentgate/internal/effects"
	"agentgate/internal/simulator"
)

// Operation roles inside a cell.
const (
	roleOriginal = "original"
	roleFresh    = "fresh"
	roleProbe    = "probe"
)

// Timeouts of the parent's side.
const (
	childReadyTimeout = 60 * time.Second
	childExitTimeout  = 30 * time.Second
	heldReleaseWait   = 30 * time.Second
)

// suite holds what every cell shares.
type suite struct {
	exe         string   // the gateway child executable (this program)
	childEnv    []string // extra environment for children (tests)
	verifier    verifierCommand
	workDir     string
	hostLabel   string
	callTimeout time.Duration
	w           *world
}

type segmentRun struct {
	index int
	dir   string
	label string
	child *childProc
	mcp   *mcpClient
	admin *adminClient
	keys  string
	out   *segmentOutcome
}

type cellRun struct {
	s           *suite
	spec        cellSpec
	res         *cellResult
	label       string
	dir         string
	run         runIdentity
	provider    *providerHost
	grant       *signedGrant
	journal     string
	bearer      string
	admin       string
	approver    string
	tool        string
	escalation  devcomposition.Escalation
	elicitation bool
	args        func(id [16]byte) map[string]any
	ids         map[string][16]byte
	segments    []*segmentRun
	// failures are the reasons the cell's schedule ran but did not test what
	// it models (a kill point or fault that never fired, an unexpected
	// dispatch); they become the cell's error.
	failures []string
}

// errInterrupted ends a cell whose call was cancelled by the operator
// (Ctrl-C): a cancelled call is no answer, but not a kill.
var errInterrupted = errors.New("interrupted by the operator (Ctrl-C); the cell did not finish")

// safeName turns a cell name into a folder and run-label component.
func safeName(name string) string {
	return strings.NewReplacer("/", "-", "\\", "-", " ", "-").Replace(name)
}

func (s *suite) display(path string) string {
	if rel, err := filepath.Rel(s.workDir, path); err == nil && !strings.HasPrefix(rel, "..") {
		return filepath.ToSlash(filepath.Join("<work>", rel))
	}
	return filepath.Base(path)
}

// runCell runs one cell and never panics on a cell failure: an error is
// recorded in the result and the measures cover what did run.
func (s *suite) runCell(ctx context.Context, spec cellSpec, rep int) cellResult {
	started := time.Now()
	res := cellResult{cellSpec: spec, Rep: rep, Effects: map[string]int{}, Dispatches: map[string]int{}, Answers: []answerRecord{}, Segments: []segmentOutcome{}, Notes: []string{}}
	c, err := s.newCellRun(spec, rep, &res)
	if err != nil {
		res.Error = err.Error()
		res.ElapsedMS = msSince(started)
		return res
	}
	defer c.cleanup()
	switch spec.Group {
	case groupKill, groupSurrogate:
		err = c.runKill(ctx)
	case groupHuman:
		err = c.runHuman(ctx)
	case groupProvider:
		err = c.runProvider(ctx)
	case groupJournal:
		err = c.runJournal(ctx)
	case groupReplay:
		err = c.runReplay(ctx)
	default:
		err = fmt.Errorf("unknown group %q", spec.Group)
	}
	if errors.Is(err, errInterrupted) {
		res.Interrupted = true
	}
	c.stopChildren()
	c.finish()
	// A schedule error and every failure the schedule or the measures found
	// make the cell an error (a cell error fails the acceptance).
	var problems []string
	if err != nil {
		problems = append(problems, err.Error())
	}
	problems = append(problems, c.failures...)
	res.Error = strings.Join(problems, "; ")
	res.ElapsedMS = msSince(started)
	return res
}

func msSince(started time.Time) float64 {
	return float64(time.Since(started).Microseconds()) / 1000
}

func (s *suite) newCellRun(spec cellSpec, rep int, res *cellResult) (*cellRun, error) {
	label := fmt.Sprintf("ks-%s-r%d", safeName(spec.Name), rep)
	dir := filepath.Join(s.workDir, label)
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return nil, err
	}
	run, err := newRunIdentity(label)
	if err != nil {
		return nil, err
	}
	c := &cellRun{
		s: s, spec: spec, res: res, label: label, dir: dir, run: run, journal: filepath.Join(dir, "operations.jsonl"),
		bearer: randomToken(), admin: randomToken(), approver: randomToken(), escalation: devcomposition.EscalationFlag,
		ids: map[string][16]byte{roleOriginal: newOperationID()},
	}
	res.Label, res.Dir = label, s.display(dir)
	switch spec.Path {
	case pathAllowPayment:
		c.tool = toolPayment
		c.args = func(id [16]byte) map[string]any {
			return paymentArgs(id, "payee.office-supplies", 40_000, "AED", "Courier charges (kill suite)")
		}
	case pathFlagMessage:
		c.tool = toolMessage
		c.args = func(id [16]byte) map[string]any {
			return messageArgs(id, []string{"partner.carrier"}, "Pickup", "Pickup is confirmed for Thursday.")
		}
	case pathHumanPayment:
		c.tool, c.escalation, c.elicitation = toolPayment, devcomposition.EscalationHuman, true
		c.args = func(id [16]byte) map[string]any {
			return paymentArgs(id, "payee.office-supplies", 1_240_000, "AED", "Shipping invoice (kill suite)")
		}
	default:
		return nil, fmt.Errorf("unknown path %q", spec.Path)
	}
	if spec.Retry == "fresh-id" {
		c.ids[roleFresh] = newOperationID()
	}
	if spec.Group == groupJournal {
		c.ids[roleProbe] = newOperationID()
	}
	res.OperationID = opText(c.ids[roleOriginal])
	res.FreshOperationID = opText(c.ids[roleFresh])
	res.ProbeOperationID = opText(c.ids[roleProbe])
	behavior, err := c.providerBehavior()
	if err != nil {
		return nil, err
	}
	if c.provider, err = startProviderHost(s.w, run, behavior); err != nil {
		return nil, err
	}
	if c.grant, err = signGrant(label, s.w.openGrant(time.Now())); err != nil {
		c.provider.close()
		return nil, err
	}
	return c, nil
}

// providerBehavior maps the cell's provider fault to simulator faults (keyed
// by the original operation's idempotency key) and handler behavior.
func (c *cellRun) providerBehavior() (providerBehavior, error) {
	var faults []simulator.Fault
	behavior := providerBehavior{}
	switch c.spec.Fault {
	case "":
		return behavior, nil
	case faultLostResponse:
		faults = []simulator.Fault{simulator.FaultDropAfterCommit}
	case faultCertifiedNoEffect:
		faults = []simulator.Fault{simulator.FaultDropBeforeCommit}
	case faultUnknownThenApplied:
		faults = []simulator.Fault{simulator.FaultDropAfterCommit, simulator.FaultStatusUnknown}
	case faultLookupFailure:
		faults, behavior.FailStatus = []simulator.Fault{simulator.FaultDropAfterCommit}, lookupFailures
	case faultLookupFailurePersist:
		faults, behavior.FailStatus = []simulator.Fault{simulator.FaultDropAfterCommit}, -1
	case faultDelayedBeforeLookup, faultDelayedAfterAbsent:
		behavior.HoldFirstDispatch = true
		return behavior, nil
	default:
		return behavior, fmt.Errorf("unknown provider fault %q", c.spec.Fault)
	}
	key, err := idempotencyKey(c.s.w, c.run, c.tool, c.args(c.ids[roleOriginal]))
	if err != nil {
		return behavior, err
	}
	behavior.Faults = map[[32]byte][]simulator.Fault{key: faults}
	return behavior, nil
}

// capabilityAudiences are the adapter audiences per tool (the provider's
// idempotency key depends on them).
var capabilityAudiences = map[string]string{
	toolPayment: "urn:agentgate:adapter:financial-request:v1",
	toolMessage: "urn:agentgate:adapter:external-message:v1",
}

// idempotencyKey computes the provider idempotency key the gateway will use
// for one call: the normalizer's exact effect (InspectNormalizedEffect, a
// read-only development oracle) prepared by the adapter for this run.
func idempotencyKey(w *world, run runIdentity, tool string, args map[string]any) ([32]byte, error) {
	recipients, blobs, payees := w.gatewayInputs()
	policy := revisionPolicy(devcomposition.EscalationFlag)
	secret, err := devcomposition.NewGatewayBearerSecret(randomToken())
	if err != nil {
		return [32]byte{}, err
	}
	config := devcomposition.Config{
		Identity: w.identity(), GatewayBearer: secret, SimulatorOrigin: "http://127.0.0.1:1", RunID: run.ID, TaskID: worldTask,
		RegistrySnapshotObjectHash: w.registry, InitialStateObjectHash: run.InitialState,
		Recipients: recipients, Blobs: blobs, PayeeDisplayNames: payees, ContentPolicy: &policy,
	}
	effect, err := devcomposition.InspectNormalizedEffect(context.Background(), config, effects.EffectType(tool), args)
	if err != nil {
		return [32]byte{}, err
	}
	prepared, err := adapters.Prepare(effect, run.ID, adapters.AuthorityContext{CapabilityAudience: capabilityAudiences[tool], RegistrySnapshotObjectHash: w.registry, RegistryEpoch: 1})
	if err != nil {
		return [32]byte{}, err
	}
	return prepared.IdempotencyKeyHash(), nil
}

func (c *cellRun) note(format string, args ...any) {
	c.res.Notes = append(c.res.Notes, fmt.Sprintf(format, args...))
}

// fail records that the cell did not test what it models; the cell then
// counts as an error.
func (c *cellRun) fail(format string, args ...any) {
	c.failures = append(c.failures, fmt.Sprintf(format, args...))
}

// stopped reports an operator interrupt: once the run's context is
// cancelled, the last call's missing answer says nothing about the gateway.
func (c *cellRun) stopped(ctx context.Context) error {
	if ctx.Err() != nil {
		return errInterrupted
	}
	return nil
}

// expectFirst fails the cell when its first answer does not have the status
// its fault or failure produces (cellSpec.ExpectFirst).
func (c *cellRun) expectFirst(first callResult) {
	if c.spec.ExpectFirst != "" && first.Status != c.spec.ExpectFirst {
		c.fail("first answer %s, want %s: the cell's %s did not take effect", first.key(), c.spec.ExpectFirst, c.faultName())
	}
}

func (c *cellRun) faultName() string {
	if c.spec.Fault != "" {
		return "provider fault " + c.spec.Fault
	}
	return "journal write failure"
}

// stopChildren terminates any child a failed schedule left running.
func (c *cellRun) stopChildren() {
	for _, seg := range c.segments {
		if seg.child == nil {
			continue
		}
		select {
		case <-seg.child.exited:
		default:
			seg.child.terminate(5 * time.Second)
			seg.out.ExitCode = seg.child.code()
			c.note("segment %d was still running at the end of the cell and was terminated", seg.index)
		}
	}
}

// cleanup stops the provider (its state stays readable) and never leaves a
// read-only journal behind.
func (c *cellRun) cleanup() {
	c.stopChildren()
	c.provider.close()
	_ = os.Chmod(c.journal, 0o600)
}

// startSegment starts gateway child number len(segments)+1. A continuation
// segment continues the previous one (read from disk by the child).
func (c *cellRun) startSegment(kill string, readOnlyJournal bool) (*segmentRun, error) {
	index := len(c.segments) + 1
	seg := &segmentRun{index: index, dir: filepath.Join(c.dir, fmt.Sprintf("segment-%d", index)), label: fmt.Sprintf("%s-segment-%d", c.label, index)}
	seg.out = &segmentOutcome{Index: index, Folder: c.s.display(seg.dir), ExitCode: -1}
	c.segments = append(c.segments, seg)
	config := childConfig{
		RunLabel: c.run.Label, RunID: hex.EncodeToString(c.run.ID[:]), SegmentDir: seg.dir, SegmentLabel: seg.label,
		Journal: c.journal, Escalation: string(c.escalation), ProviderOrigin: c.provider.origin,
		ProviderKID: hex.EncodeToString(c.provider.kid[:]), ProviderPublic: base64.StdEncoding.EncodeToString(c.provider.public),
		Grant: c.grant.wire(), HostLabel: c.s.hostLabel, Note: fmt.Sprintf("%s r%d, segment %d", c.spec.Name, c.res.Rep, index),
	}
	if index > 1 {
		config.ContinueFrom = c.segments[index-2].dir
	}
	if kill != "" {
		config.Kill, config.KillOperation = kill, opText(c.ids[roleOriginal])
	}
	if readOnlyJournal {
		config.ReadOnlyJournalOperation = opText(c.ids[roleOriginal])
	}
	raw, err := json.MarshalIndent(config, "", "  ")
	if err != nil {
		return seg, err
	}
	configPath := filepath.Join(c.dir, fmt.Sprintf("segment-%d.child.json", index))
	if err := os.WriteFile(configPath, raw, 0o600); err != nil {
		return seg, err
	}
	env := append(os.Environ(), envBearer+"="+c.bearer, envAdmin+"="+c.admin)
	if c.escalation == devcomposition.EscalationHuman {
		env = append(env, envApprover+"="+c.approver)
	}
	env = append(env, c.s.childEnv...)
	child, err := startChild(c.s.exe, []string{"gateway", "-config", configPath}, env, filepath.Join(c.dir, fmt.Sprintf("segment-%d.stderr.log", index)))
	if err != nil {
		seg.out.StartError = err.Error()
		return seg, err
	}
	seg.child = child
	ready, err := child.waitReady(childReadyTimeout)
	if err != nil {
		seg.out.StartError, seg.out.Ended = err.Error(), "start refused"
		seg.out.ExitCode, _ = child.waitExit(childExitTimeout)
		return seg, err
	}
	seg.keys = ready.KeysSHA256
	seg.out.KeysSHA256, seg.out.Restored = ready.KeysSHA256, ready.Restored
	seg.mcp = newMCPClient(ready.MCP, c.bearer, c.s.callTimeout)
	seg.admin = newAdminClient(ready.Admin, c.admin, c.s.callTimeout)
	return seg, nil
}

// call sends one tools/call for the operation of role and records the answer
// with the provider's effects for that operation at the moment of the answer.
func (c *cellRun) call(ctx context.Context, seg *segmentRun, name, role, requestState string) callResult {
	id := c.ids[role]
	result := seg.mcp.call(ctx, c.tool, c.args(id), c.elicitation, requestState)
	effectsNow := 0
	if commits, err := c.provider.commitsByOperation(); err == nil {
		effectsNow = commits[opText(id)]
	} else {
		c.note("provider journal unreadable after %s: %v", name, err)
	}
	c.res.Answers = append(c.res.Answers, answerRecord{Segment: seg.index, Call: name, Operation: role, Result: result, EffectsAtAnswer: effectsNow})
	return result
}

// waitDead waits for a child that died at its kill point. A child that
// ended without reporting the kill point fails the cell, unless the operator
// interrupted the run (Ctrl-C reaches the children of the console too).
func (c *cellRun) waitDead(ctx context.Context, seg *segmentRun) error {
	code, err := seg.child.waitExit(childExitTimeout)
	seg.out.ExitCode = code
	if err != nil {
		c.note("segment %d: %v", seg.index, err)
	}
	if killed := seg.child.killMessage(); killed != nil {
		c.res.KillReached = true
		seg.out.Ended, seg.out.KillPoint = "killed at "+killed.Point, killed.Point
		// The child is built to die only at its configured point and
		// operation; a mismatch means the cell did not test what it models.
		if killed.Point != c.spec.Kill || killed.Operation != opText(c.ids[roleOriginal]) {
			c.fail("segment %d died at %s for operation %q, want %s for the original operation", seg.index, killed.Point, killed.Operation, c.spec.Kill)
		}
		return nil
	}
	seg.out.Ended = fmt.Sprintf("exited with code %d without reaching its kill point", code)
	if err := c.stopped(ctx); err != nil {
		return err
	}
	c.fail("segment %d gave no answer and exited with code %d without reaching the kill point %s", seg.index, code, c.spec.Kill)
	return nil
}

// killNotReached fails the cell whose call was answered although the child
// should have died during it, and closes the child gracefully.
func (c *cellRun) killNotReached(ctx context.Context, seg *segmentRun, answer callResult) {
	c.fail("the kill point %s was not reached (answer %s); segment %d was closed gracefully", c.spec.Kill, answer.key(), seg.index)
	c.closeSegment(ctx, seg)
}

// terminate ends a child from outside (TerminateProcess on Windows).
func (c *cellRun) terminate(seg *segmentRun) {
	seg.child.terminate(childExitTimeout)
	seg.out.ExitCode = seg.child.code()
	seg.out.Ended, seg.out.KillPoint = "terminated by the parent", c.spec.Kill
	c.res.KillReached = true
}

// closeSegment closes a live child gracefully (provider journal written by the
// child, log closed) and waits for it to exit.
func (c *cellRun) closeSegment(ctx context.Context, seg *segmentRun) {
	if _, err := seg.admin.close(ctx); err != nil {
		c.note("segment %d close: %v", seg.index, err)
	}
	code, err := seg.child.waitExit(childExitTimeout)
	seg.out.ExitCode = code
	if err != nil {
		c.note("segment %d: %v", seg.index, err)
	}
	seg.out.Ended = "closed"
	c.pin(seg)
}

// postMortem writes the dead segment's provider-journal.json from the
// provider (which outlived the gateway) and records the pins the parent
// holds for it. The dead process never wrote that file.
func (c *cellRun) postMortem(seg *segmentRun) {
	c.pin(seg)
	if seg.out.Ended == "closed" {
		return
	}
	document, err := c.provider.journalDocument(seg.label)
	if err == nil {
		err = audit.WriteJSONAtomic(filepath.Join(seg.dir, audit.ProviderJournalFile), document)
	}
	if err != nil {
		c.note("segment %d provider journal: %v", seg.index, err)
	}
}

func (c *cellRun) pin(seg *segmentRun) {
	head, _ := seg.child.pins()
	seg.out.PinSeq, seg.out.PinHead = head.Seq, head.Hash
}

// verifySegment runs the CLI on the segment with the keys fingerprint and the
// last head the parent received. For segment 1 that is "segment 1 alone"; for
// a continuation the verifier follows "continues" and checks the whole run.
func (c *cellRun) verifySegment(seg *segmentRun) {
	outcome := c.s.verifier.verify(seg.dir, c.s.display(seg.dir), seg.keys, seg.out.PinHead)
	seg.out.Verify = &outcome
}

// afterCalls records the states, asks for Reconcile, closes and verifies the
// last segment.
func (c *cellRun) afterCalls(ctx context.Context, seg *segmentRun) error {
	if err := c.stopped(ctx); err != nil {
		return err
	}
	if states, err := seg.admin.operations(ctx); err == nil {
		c.res.StatesAfterRetry = states.Operations
	} else {
		c.note("operations: %v", err)
	}
	if states, err := seg.admin.reconcile(ctx); err == nil {
		c.res.StatesAfterReconcile = states.Operations
	} else {
		c.note("reconcile: %v", err)
		if again, err := seg.admin.operations(ctx); err == nil {
			c.res.StatesAfterReconcile = again.Operations
		}
	}
	if err := c.stopped(ctx); err != nil {
		return err
	}
	if c.res.StatesAfterReconcile == nil {
		// Without the states, no operation can be shown resolved.
		c.fail("segment %d gave no operation states after Reconcile", seg.index)
	}
	c.closeSegment(ctx, seg)
	c.verifySegment(seg)
	return nil
}

// runKill: kill segment 1 at the kill point during the first call, restart
// from disk, retry (same or fresh operation ID), Reconcile, close, verify.
// Surrogate cells mutate the killed folder before the restart.
func (c *cellRun) runKill(ctx context.Context) error {
	seg1, err := c.startSegment(c.spec.Kill, false)
	if err != nil {
		return fmt.Errorf("segment 1: %w", err)
	}
	first := c.call(ctx, seg1, "first", roleOriginal, "")
	if err := c.stopped(ctx); err != nil {
		return err
	}
	if first.NoAnswer {
		if err := c.waitDead(ctx, seg1); err != nil {
			return err
		}
	} else {
		c.killNotReached(ctx, seg1, first)
	}
	c.postMortem(seg1)
	if c.spec.Surrogate != "" {
		if err := c.applySurrogate(seg1); err != nil {
			c.verifySegment(seg1)
			return fmt.Errorf("surrogate: %w", err)
		}
	}
	c.verifySegment(seg1)
	seg2, err := c.startSegment("", false)
	if err != nil {
		// The child's start error crossed a process boundary as text.
		if strings.Contains(err.Error(), errRestartBlocked.Error()) {
			c.res.RestartBlocked, c.res.RestartError = true, err.Error()
			return nil
		}
		return fmt.Errorf("segment 2: %w", err)
	}
	role := roleOriginal
	if c.spec.Retry == "fresh-id" {
		role = roleFresh
	}
	c.call(ctx, seg2, "retry", role, "")
	return c.afterCalls(ctx, seg2)
}

// applySurrogate keeps an untouched copy of the killed state (as-killed/,
// verified alone for comparison) and applies the power-loss surrogate to the
// working folder the restart uses.
func (c *cellRun) applySurrogate(seg *segmentRun) error {
	pristine := filepath.Join(c.dir, "as-killed")
	if err := os.MkdirAll(pristine, 0o755); err != nil {
		return err
	}
	if err := copyFile(c.journal, filepath.Join(pristine, "operations.jsonl")); err != nil {
		return err
	}
	pristineSegment := filepath.Join(pristine, filepath.Base(seg.dir))
	if err := copyTree(seg.dir, pristineSegment); err != nil {
		return err
	}
	_, previous := seg.child.pins()
	description, err := applySurrogate(c.spec.Surrogate, c.journal, seg.dir, previous.File)
	if err != nil {
		return err
	}
	c.res.SurrogateApplied = description
	asKilled := c.s.verifier.verify(pristineSegment, c.s.display(pristineSegment), seg.keys, seg.out.PinHead)
	c.res.AsKilled = &asKilled
	return nil
}

// runHuman: the human path. The child dies (or is terminated) while the
// approval is pending, after the approval, or at a gateway kill point of the
// approved call; the restart's exact retry is approved again if challenged.
func (c *cellRun) runHuman(ctx context.Context) error {
	point, ok := lookupKillPoint(c.spec.Kill)
	if !ok {
		return fmt.Errorf("unknown kill point %q", c.spec.Kill)
	}
	gatewayKill := ""
	if !point.External {
		gatewayKill = point.Name
	}
	seg1, err := c.startSegment(gatewayKill, false)
	if err != nil {
		return fmt.Errorf("segment 1: %w", err)
	}
	first := c.call(ctx, seg1, "first", roleOriginal, "")
	if err := c.stopped(ctx); err != nil {
		return err
	}
	if !first.Challenge {
		return fmt.Errorf("expected an approval challenge, got %s %s", first.key(), first.Error)
	}
	switch point.Name {
	case "pending":
		c.terminate(seg1)
	case "approved":
		if err := seg1.admin.approve(ctx, first.ApprovalURL); err != nil {
			return fmt.Errorf("approve: %w", err)
		}
		c.terminate(seg1)
	default:
		if err := seg1.admin.approve(ctx, first.ApprovalURL); err != nil {
			return fmt.Errorf("approve: %w", err)
		}
		resumed := c.call(ctx, seg1, "resume", roleOriginal, first.RequestState)
		if err := c.stopped(ctx); err != nil {
			return err
		}
		if resumed.NoAnswer {
			if err := c.waitDead(ctx, seg1); err != nil {
				return err
			}
		} else {
			c.killNotReached(ctx, seg1, resumed)
		}
	}
	c.postMortem(seg1)
	c.verifySegment(seg1)
	seg2, err := c.startSegment("", false)
	if err != nil {
		return fmt.Errorf("segment 2: %w", err)
	}
	retry := c.call(ctx, seg2, "retry", roleOriginal, "")
	if err := c.stopped(ctx); err != nil {
		return err
	}
	if retry.Challenge {
		c.res.SecondApprovalRequired = true
		if err := seg2.admin.approve(ctx, retry.ApprovalURL); err != nil {
			return fmt.Errorf("second approval: %w", err)
		}
		c.call(ctx, seg2, "resume", roleOriginal, retry.RequestState)
	}
	return c.afterCalls(ctx, seg2)
}

// runProvider: one gateway, no kill; the provider misbehaves.
func (c *cellRun) runProvider(ctx context.Context) error {
	seg1, err := c.startSegment("", false)
	if err != nil {
		return fmt.Errorf("segment 1: %w", err)
	}
	first := c.call(ctx, seg1, "first", roleOriginal, "")
	if err := c.stopped(ctx); err != nil {
		return err
	}
	c.expectFirst(first)
	answers := []callResult{first}
	switch c.spec.Fault {
	case faultDelayedBeforeLookup:
		c.releaseHeld()
		answers = append(answers, c.call(ctx, seg1, "retry-1", roleOriginal, ""))
	case faultDelayedAfterAbsent:
		answers = append(answers, c.call(ctx, seg1, "retry-1", roleOriginal, ""))
		c.releaseHeld()
		answers = append(answers, c.call(ctx, seg1, "retry-2", roleOriginal, ""))
	default:
		for retry := 1; retry <= c.spec.Retries; retry++ {
			answers = append(answers, c.call(ctx, seg1, fmt.Sprintf("retry-%d", retry), roleOriginal, ""))
		}
	}
	if err := c.stopped(ctx); err != nil {
		return err
	}
	c.expectFaultFired(answers)
	return c.afterCalls(ctx, seg1)
}

// expectFaultFired fails a provider cell whose fault left no trace beyond
// the first answer: the lookups answered 503, the signed UNKNOWN status.
func (c *cellRun) expectFaultFired(answers []callResult) {
	lookups, failed := c.provider.statusCounts()
	switch c.spec.Fault {
	case faultLookupFailure:
		if failed != lookupFailures {
			c.fail("the provider answered %d status lookups with HTTP 503, want %d", failed, lookupFailures)
		}
	case faultLookupFailurePersist:
		if failed == 0 || failed != lookups {
			c.fail("the provider answered %d of %d status lookups with HTTP 503, want every lookup (at least one)", failed, lookups)
		}
	case faultUnknownThenApplied:
		// The first retry draws the signed UNKNOWN status.
		if len(answers) < 2 || answers[1].Status != string(devcomposition.StatusUncertain) {
			got := "none"
			if len(answers) >= 2 {
				got = answers[1].key()
			}
			c.fail("the first retry answered %s, want UNCERTAIN from the signed UNKNOWN status", got)
		}
	}
}

// releaseHeld releases the held dispatch of a delayed-delivery cell; a
// dispatch that was never held, or never answered, fails the cell.
func (c *cellRun) releaseHeld() {
	if err := c.provider.waitHeld(time.Second); err != nil {
		c.fail("held dispatch: %v", err)
		return
	}
	status, err := c.provider.releaseHeld(heldReleaseWait)
	c.res.HeldDispatchStatus = status
	if err != nil {
		c.fail("held dispatch: %v", err)
	}
}

// runJournal: one journal write failure. The journal becomes read-only right
// after the capability is consumed, so the dispatch-intent write fails; a
// second operation and an exact retry follow in the same process; then a
// graceful close, the attribute is cleared, and the restarted gateway gets
// the exact retry.
func (c *cellRun) runJournal(ctx context.Context) error {
	seg1, err := c.startSegment("", true)
	if err != nil {
		return fmt.Errorf("segment 1: %w", err)
	}
	first := c.call(ctx, seg1, "first", roleOriginal, "")
	if err := c.stopped(ctx); err != nil {
		return err
	}
	if !seg1.child.journalMadeReadOnly() {
		c.fail("the journal was not made read-only (the consume hook did not fire or the attribute could not be set)")
	}
	c.expectFirst(first)
	c.call(ctx, seg1, "probe", roleProbe, "")
	c.call(ctx, seg1, "retry-same-process", roleOriginal, "")
	if err := c.stopped(ctx); err != nil {
		return err
	}
	c.closeSegment(ctx, seg1)
	if err := os.Chmod(c.journal, 0o600); err != nil {
		return fmt.Errorf("clear the read-only attribute: %w", err)
	}
	c.verifySegment(seg1)
	seg2, err := c.startSegment("", false)
	if err != nil {
		return fmt.Errorf("segment 2: %w", err)
	}
	c.call(ctx, seg2, "retry", roleOriginal, "")
	return c.afterCalls(ctx, seg2)
}

// runReplay: no fault. The operation commits; exact retries in the same
// process are answered with the stored result (the coordinator's store, no
// FINAL runs); after a graceful close and restart one more exact retry is
// answered from the journal. Every answer must be COMMITTED, and the flag
// measures (flagMeasures) judge the replayed CALL_RESULT entries.
func (c *cellRun) runReplay(ctx context.Context) error {
	seg1, err := c.startSegment("", false)
	if err != nil {
		return fmt.Errorf("segment 1: %w", err)
	}
	call := func(seg *segmentRun, name string) {
		if answer := c.call(ctx, seg, name, roleOriginal, ""); answer.Status != string(devcomposition.StatusCommitted) {
			c.fail("%s answered %s, want COMMITTED (a stored result to replay)", name, answer.key())
		}
	}
	call(seg1, "first")
	if err := c.stopped(ctx); err != nil {
		return err
	}
	for retry := 1; retry <= sameProcessRetries; retry++ {
		call(seg1, fmt.Sprintf("retry-same-process-%d", retry))
	}
	if err := c.stopped(ctx); err != nil {
		return err
	}
	c.closeSegment(ctx, seg1)
	c.verifySegment(seg1)
	seg2, err := c.startSegment("", false)
	if err != nil {
		return fmt.Errorf("segment 2: %w", err)
	}
	call(seg2, "retry-after-restart")
	return c.afterCalls(ctx, seg2)
}
