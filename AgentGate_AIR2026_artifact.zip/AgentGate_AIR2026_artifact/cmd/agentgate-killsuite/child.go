package main

// The "gateway" child mode: one real gateway process (internal/devcomposition)
// with its MCP boundary on loopback HTTP, its operation journal and one
// evidence segment, reaching the parent's provider host over the adapter
// transport (Config.ExternalProvider). The parent kills it, restarts it from
// disk and talks to it over HTTP only.
//
// The child prints protocol lines on stdout ("KILLSUITE " + one JSON object):
//
//	ready   MCP and admin URLs, the keys.json fingerprint, restored operations
//	head    after every audit append: sequence, entry hash, head.json bytes
//	kill    right before the process exits at its kill point (exit code 86)
//	closed  after a graceful close (provider journal written, log closed)
//	error   a start-up failure (exit code 3), e.g. a refused continuation
//
// Admin calls (loopback, bearer token from the parent):
//
//	GET  /admin/operations  Composition.Operations
//	POST /admin/reconcile   Composition.Reconcile, then Operations
//	POST /admin/approve     {"url": ...} approve a pending challenge through
//	                        the approval relay, in process, with the CSRF flow
//	                        a browser would follow (human mode only)
//	POST /admin/close       write provider-journal.json, close the log, exit 0
//
// Secrets (the MCP bearer, the admin token, the test approver credential) come
// from environment variables the parent sets for this process only; nothing
// secret is written to disk, and no private key ever leaves the process.

import (
	"context"
	"crypto/subtle"
	"crypto/tls"
	"encoding/base64"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"regexp"
	"strings"
	"sync"
	"time"

	"agentgate/internal/audit"
	"agentgate/internal/devapproval"
	"agentgate/internal/devcomposition"
)

const (
	envBearer   = "AGENTGATE_KILLSUITE_BEARER"
	envAdmin    = "AGENTGATE_KILLSUITE_ADMIN"
	envApprover = "AGENTGATE_KILLSUITE_APPROVER"

	protocolPrefix = "KILLSUITE "

	// killExitCode is the exit code of a child that died at its kill point.
	killExitCode = 86
	// startFailureExitCode is the exit code of a child that could not start.
	startFailureExitCode = 3

	// The approval relay is never served on a socket: the admin call drives
	// it in process (approveInProcess), so its origin only names it.
	approvalOrigin = "https://127.0.0.1:19444"
	approverID     = "human.reviewer"
)

// exitProcess is os.Exit; tests may replace it.
var exitProcess = os.Exit

// childConfig is what the parent tells one gateway child (no secrets).
type childConfig struct {
	RunLabel       string    `json:"run_label"`
	RunID          string    `json:"run_id"` // hex of the 16-byte run ID
	SegmentDir     string    `json:"segment_dir"`
	SegmentLabel   string    `json:"segment_label"`
	ContinueFrom   string    `json:"continue_from,omitempty"` // previous segment folder (read from disk)
	Journal        string    `json:"journal"`
	Escalation     string    `json:"escalation"` // flag | human
	ProviderOrigin string    `json:"provider_origin"`
	ProviderKID    string    `json:"provider_kid"`    // hex
	ProviderPublic string    `json:"provider_public"` // std base64
	Grant          grantWire `json:"grant"`
	// Kill names a kill point (killPoints); KillOperation the operation it
	// applies to.
	Kill          string `json:"kill,omitempty"`
	KillOperation string `json:"kill_operation,omitempty"`
	// ReadOnlyJournalOperation: at after_capability_consume for this
	// operation the child sets the journal file's read-only attribute, so the
	// dispatch-intent write fails (one journal write failure).
	ReadOnlyJournalOperation string `json:"read_only_journal_operation,omitempty"`
	HostLabel                string `json:"host_label"`
	Note                     string `json:"note"`
}

// childMessage is one protocol line.
type childMessage struct {
	Event      string `json:"event"`
	PID        int    `json:"pid,omitempty"`
	MCP        string `json:"mcp,omitempty"`
	Admin      string `json:"admin,omitempty"`
	KeysSHA256 string `json:"keys_sha256,omitempty"`
	RunID      string `json:"run_id,omitempty"`
	Restored   int    `json:"restored,omitempty"`
	Seq        uint64 `json:"seq,omitempty"`
	Hash       string `json:"hash,omitempty"`
	HeadFile   []byte `json:"head_file,omitempty"`
	Point      string `json:"point,omitempty"`
	Operation  string `json:"operation_id,omitempty"`
	Error      string `json:"error,omitempty"`
}

type emitter struct {
	mu  sync.Mutex
	out io.Writer
}

// emit writes one protocol line in a single write (stdout is unbuffered, so
// the line reaches the parent before a following os.Exit).
func (e *emitter) emit(message childMessage) {
	raw, err := json.Marshal(message)
	if err != nil {
		return
	}
	line := append([]byte(protocolPrefix), raw...)
	line = append(line, '\n')
	e.mu.Lock()
	defer e.mu.Unlock()
	_, _ = e.out.Write(line)
}

// die reports the kill point and ends the process at once: no deferred
// function, no flush, no log close runs (on Windows os.Exit ends the process
// through ExitProcess, like a crash of this process; the kernel's file cache
// survives, so this models a process crash, not a power loss).
func (e *emitter) die(point string, operation [16]byte) {
	e.emit(childMessage{Event: "kill", Point: point, Operation: opText(operation)})
	exitProcess(killExitCode)
}

// childInjector is the gateway's FaultInjector in the child: it never makes a
// step fail; it ends the process at the configured kill point, or sets the
// journal read-only for the journal-write-failure cell.
type childInjector struct {
	emitter   *emitter
	kill      killPoint
	operation [16]byte

	readOnlyOperation [16]byte
	journal           string
	readOnlyOnce      sync.Once
}

func (injector *childInjector) Fail(point devcomposition.FaultPoint, operation [16]byte) error {
	if injector.readOnlyOperation != [16]byte{} && point == devcomposition.FaultAfterCapabilityConsume && operation == injector.readOnlyOperation {
		injector.readOnlyOnce.Do(func() {
			// A file attribute, not a system setting; the parent clears it
			// before the restart.
			err := os.Chmod(injector.journal, 0o444)
			message := childMessage{Event: "journal_read_only", Operation: opText(operation)}
			if err != nil {
				message.Error = err.Error()
			}
			injector.emitter.emit(message)
		})
	}
	if injector.kill.Fault != "" && point == injector.kill.Fault && operation == injector.operation {
		injector.emitter.die(injector.kill.Name, operation)
	}
	return nil
}

func runGatewayChild(args []string, stdout, stderr io.Writer) error {
	set := flag.NewFlagSet("gateway", flag.ContinueOnError)
	set.SetOutput(stderr)
	configPath := set.String("config", "", "child configuration written by the run mode (required)")
	if err := set.Parse(args); err != nil {
		return err
	}
	if *configPath == "" || set.NArg() != 0 {
		return errors.New("gateway mode needs -config and no other arguments; it is started by the run mode")
	}
	raw, err := os.ReadFile(*configPath)
	if err != nil {
		return err
	}
	var config childConfig
	decoder := json.NewDecoder(strings.NewReader(string(raw)))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&config); err != nil {
		return fmt.Errorf("child configuration: %w", err)
	}
	out := &emitter{out: stdout}
	if err := serveGateway(config, out); err != nil {
		out.emit(childMessage{Event: "error", Error: err.Error()})
		return err
	}
	return nil
}

// errRestartBlocked marks a refused continuation (the previous segment's
// files cannot be read back), which the parent reports as a blocked restart.
var errRestartBlocked = errors.New("restart blocked")

func serveGateway(config childConfig, out *emitter) error {
	ctx := context.Background()
	bearer, admin := os.Getenv(envBearer), os.Getenv(envAdmin)
	if bearer == "" || admin == "" {
		return errors.New("the MCP bearer and the admin token must be set in the environment")
	}
	w, err := newWorld()
	if err != nil {
		return err
	}
	runID, err := decodeHex16(config.RunID)
	if err != nil {
		return fmt.Errorf("run ID: %w", err)
	}
	run, err := runIdentityFor(config.RunLabel, runID)
	if err != nil {
		return err
	}
	grant, err := grantFromWire(config.Grant)
	if err != nil {
		return err
	}
	providerKID, err := decodeHex32(config.ProviderKID)
	if err != nil {
		return fmt.Errorf("provider kid: %w", err)
	}
	providerPublic, err := base64.StdEncoding.DecodeString(config.ProviderPublic)
	if err != nil {
		return fmt.Errorf("provider public key: %w", err)
	}
	injector := &childInjector{emitter: out, journal: config.Journal}
	if config.Kill != "" {
		point, ok := lookupKillPoint(config.Kill)
		if !ok || point.External {
			return fmt.Errorf("unknown or external kill point %q", config.Kill)
		}
		if injector.operation, err = parseOpText(config.KillOperation); err != nil {
			return err
		}
		injector.kill = point
	}
	if config.ReadOnlyJournalOperation != "" {
		if injector.readOnlyOperation, err = parseOpText(config.ReadOnlyJournalOperation); err != nil {
			return err
		}
	}

	// A restart reads the continuation from the previous segment's own files
	// (audit.ReadContinuation) before anything is created: a torn audit tail
	// refuses it and leaves no empty new segment behind.
	var continuation *audit.Continuation
	if config.ContinueFrom != "" {
		read, err := audit.ReadContinuation(config.ContinueFrom, config.SegmentDir)
		if err != nil {
			return fmt.Errorf("%w: %w", errRestartBlocked, err)
		}
		continuation = &read
	}
	evidence, err := newEvidenceRun(config.SegmentDir, config.SegmentLabel)
	if err != nil {
		return err
	}
	evidence.continues = continuation
	evidence.onHead = func(seq uint64, hash string, file []byte) {
		out.emit(childMessage{Event: "head", Seq: seq, Hash: hash, HeadFile: file})
	}
	switch injector.kill.Sink {
	case sinkAfterEffectExecuted:
		evidence.afterAppend = func(event devcomposition.AuditEvent) {
			if event.Stage == "EFFECT_EXECUTED" && event.OperationID == injector.operation {
				out.die(injector.kill.Name, event.OperationID)
			}
		}
	case sinkBeforeCallResult:
		evidence.beforeAppend = func(event devcomposition.AuditEvent) {
			if event.Stage == "CALL_RESULT" && event.OperationID == injector.operation {
				out.die(injector.kill.Name, event.OperationID)
			}
		}
	}

	escalation := devcomposition.EscalationFlag
	if config.Escalation == string(devcomposition.EscalationHuman) {
		escalation = devcomposition.EscalationHuman
	} else if config.Escalation != string(devcomposition.EscalationFlag) {
		return fmt.Errorf("escalation must be flag or human, not %q", config.Escalation)
	}
	secret, err := devcomposition.NewGatewayBearerSecret(bearer)
	if err != nil {
		return err
	}
	policy := revisionPolicy(escalation)
	recipients, blobs, payees := w.gatewayInputs()
	delegation := grant.config()
	gatewayConfig := devcomposition.Config{
		Identity: w.identity(), GatewayBearer: secret, SimulatorOrigin: config.ProviderOrigin,
		RunID: run.ID, TaskID: worldTask,
		RegistrySnapshotObjectHash: w.registry, InitialStateObjectHash: run.InitialState,
		Recipients: recipients, Blobs: blobs, PayeeDisplayNames: payees,
		ContentPolicy: &policy, OperationJournal: config.Journal, Faults: injector,
		ExternalProvider: &devcomposition.ExternalProviderConfig{Origin: config.ProviderOrigin, KID: providerKID, PublicKey: providerPublic},
		Audit:            evidence, Delegation: &delegation, HostLabel: config.HostLabel,
	}
	var approver string
	if escalation == devcomposition.EscalationHuman {
		approver = os.Getenv(envApprover)
		human, err := devapproval.NewHumanSecret(approver)
		if err != nil {
			return fmt.Errorf("approver credential: %w", err)
		}
		gatewayConfig.HumanApproval = &devcomposition.HumanApprovalConfig{Origin: approvalOrigin, ApproverID: approverID, HumanSecret: human, TTLSeconds: 120}
	}
	comp, err := devcomposition.New(ctx, gatewayConfig)
	if err != nil {
		return fmt.Errorf("gateway: %w", err)
	}
	host := config.HostLabel
	if host == "" {
		host, _ = os.Hostname()
	}
	if err := evidence.begin(w, comp, gatewayConfig, grant, host, config.Note); err != nil {
		return fmt.Errorf("evidence: %w", err)
	}

	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return err
	}
	closing := make(chan struct{})
	var closeOnce sync.Once
	mux := http.NewServeMux()
	mux.Handle("/mcp", comp.MCP)
	authorized := func(next http.HandlerFunc) http.HandlerFunc {
		want := "Bearer " + admin
		return func(writer http.ResponseWriter, request *http.Request) {
			if subtle.ConstantTimeCompare([]byte(request.Header.Get("Authorization")), []byte(want)) != 1 {
				http.Error(writer, "unauthorized", http.StatusUnauthorized)
				return
			}
			next(writer, request)
		}
	}
	mux.HandleFunc("GET /admin/operations", authorized(func(writer http.ResponseWriter, _ *http.Request) {
		writeJSONResponse(writer, http.StatusOK, adminStates{Operations: operationWires(comp.Operations())})
	}))
	mux.HandleFunc("POST /admin/reconcile", authorized(func(writer http.ResponseWriter, request *http.Request) {
		attempted, err := comp.Reconcile(request.Context())
		answer := adminStates{Attempted: operationWires(attempted), Operations: operationWires(comp.Operations())}
		if err != nil {
			answer.Error = err.Error()
		}
		writeJSONResponse(writer, http.StatusOK, answer)
	}))
	mux.HandleFunc("POST /admin/approve", authorized(func(writer http.ResponseWriter, request *http.Request) {
		var body struct {
			URL string `json:"url"`
		}
		if err := json.NewDecoder(io.LimitReader(request.Body, 1<<16)).Decode(&body); err != nil {
			http.Error(writer, err.Error(), http.StatusBadRequest)
			return
		}
		if comp.Approval == nil {
			http.Error(writer, "this gateway has no approval relay", http.StatusConflict)
			return
		}
		if err := approveInProcess(comp.Approval, body.URL, approver); err != nil {
			http.Error(writer, err.Error(), http.StatusBadGateway)
			return
		}
		writeJSONResponse(writer, http.StatusOK, map[string]any{"approved": true})
	}))
	mux.HandleFunc("POST /admin/close", authorized(func(writer http.ResponseWriter, request *http.Request) {
		seq, hash, err := evidence.finish(request.Context(), config.ProviderOrigin)
		answer := map[string]any{"seq": seq, "hash": hash}
		status, errText := http.StatusOK, ""
		if err != nil {
			errText, status = err.Error(), http.StatusInternalServerError
			answer["error"] = errText
		}
		writeJSONResponse(writer, status, answer)
		out.emit(childMessage{Event: "closed", Seq: seq, Hash: hash, Error: errText})
		closeOnce.Do(func() { close(closing) })
	}))
	server := &http.Server{Handler: mux, ReadHeaderTimeout: 10 * time.Second}
	served := make(chan error, 1)
	go func() { served <- server.Serve(listener) }()
	base := "http://" + listener.Addr().String()
	out.emit(childMessage{
		Event: "ready", PID: os.Getpid(), MCP: base + "/mcp", Admin: base + "/admin",
		KeysSHA256: evidence.keysSHA256, RunID: config.SegmentLabel, Restored: len(comp.Operations()),
	})
	select {
	case <-closing:
	case err := <-served:
		return fmt.Errorf("MCP server: %w", err)
	}
	shutdown, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	_ = server.Shutdown(shutdown)
	return nil
}

// adminStates is the answer of /admin/operations and /admin/reconcile.
type adminStates struct {
	Attempted  []operationWire `json:"attempted,omitempty"`
	Operations []operationWire `json:"operations"`
	Error      string          `json:"error,omitempty"`
}

type operationWire struct {
	OperationID string `json:"operation_id"`
	EffectType  string `json:"effect_type"`
	Status      string `json:"status"`
	Reason      string `json:"reason,omitempty"`
	Dispatched  bool   `json:"dispatched"`
}

func operationWires(states []devcomposition.OperationState) []operationWire {
	out := make([]operationWire, 0, len(states))
	for _, state := range states {
		out = append(out, operationWire{
			OperationID: opText(state.OperationID), EffectType: state.EffectType,
			Status: string(state.Status), Reason: state.Reason, Dispatched: state.Dispatched,
		})
	}
	return out
}

func writeJSONResponse(writer http.ResponseWriter, status int, value any) {
	writer.Header().Set("Content-Type", "application/json")
	writer.WriteHeader(status)
	_ = json.NewEncoder(writer).Encode(value)
}

// --- the approval flow, in process ----------------------------------------------

var csrfPattern = regexp.MustCompile(`(?s)action="[^"]+/approve"[^>]*>.*?name="csrf" value="([A-Za-z0-9_-]{43})"`)

// browserRequest builds the request a same-origin browser on the approval
// page would send (TLS, loopback peer, Fetch metadata on the decision POST).
func browserRequest(method, path, body string, mutation bool) *http.Request {
	request := httptest.NewRequest(method, approvalOrigin+path, strings.NewReader(body))
	request.RequestURI = path
	request.URL.Scheme, request.URL.Host = "", ""
	request.RemoteAddr = "127.0.0.1:43124"
	request.TLS = &tls.ConnectionState{HandshakeComplete: true, Version: tls.VersionTLS13}
	if body == "" {
		request.Body, request.ContentLength = http.NoBody, 0
	}
	if mutation {
		request.Header.Set("Origin", approvalOrigin)
		request.Header.Set("Sec-Fetch-Site", "same-origin")
		request.Header.Set("Sec-Fetch-Mode", "navigate")
		request.Header.Set("Sec-Fetch-Dest", "document")
		request.Header.Set("Sec-Fetch-User", "?1")
	}
	return request
}

// approveInProcess opens the approval page at url as the test approver,
// reads its CSRF token and posts the approval, as the reviewer's browser
// would. A local click is not authenticated consent; it only drives the
// relay through its real handlers.
func approveInProcess(handler http.Handler, url, approver string) error {
	if !strings.HasPrefix(url, approvalOrigin+"/") {
		return fmt.Errorf("approval URL %q is not on the approval origin", url)
	}
	path := strings.TrimPrefix(url, approvalOrigin)
	page := browserRequest(http.MethodGet, path, "", false)
	page.SetBasicAuth(approverID, approver)
	pageResponse := httptest.NewRecorder()
	handler.ServeHTTP(pageResponse, page)
	match := csrfPattern.FindStringSubmatch(pageResponse.Body.String())
	if len(match) != 2 {
		return fmt.Errorf("approval page answered HTTP %d without a decision form", pageResponse.Code)
	}
	post := browserRequest(http.MethodPost, path+"/approve", "csrf="+match[1], true)
	post.SetBasicAuth(approverID, approver)
	post.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	decision := httptest.NewRecorder()
	handler.ServeHTTP(decision, post)
	if decision.Code != http.StatusOK {
		return fmt.Errorf("approval decision answered HTTP %d", decision.Code)
	}
	return nil
}
