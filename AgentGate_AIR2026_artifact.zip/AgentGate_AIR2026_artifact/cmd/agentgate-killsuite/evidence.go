package main

// The gateway child's evidence folder: the minimal part of the evidence
// writer of cmd/agentgate-eval/harness.go (keys.json, run.json, audit.jsonl,
// head.json, provider-journal.json in the demo's run format, written by the
// signed, hash-chained audit log), plus what the kill suite needs:
//
//   - after every append the head (sequence, entry hash and the exact bytes
//     of head.json) is streamed to the parent, so the parent holds real
//     external pins for a segment whose process it then kills, and keeps the
//     previous genuine head.json for the "reverted head" power-loss surrogate;
//   - two sink-level kill points: right after EFFECT_EXECUTED was appended
//     (before the operation journal's "recorded" record) and right before
//     CALL_RESULT is appended (after "recorded").

import (
	"context"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"sync"
	"time"

	"agentgate/internal/audit"
	"agentgate/internal/devcomposition"
)

// evidenceRun is the gateway's audit sink (devcomposition.AuditSink).
type evidenceRun struct {
	dir   string
	label string
	log   *audit.Log

	mu      sync.Mutex
	begun   bool
	pending []audit.Event
	closed  bool

	keysSHA256 string
	continues  *audit.Continuation

	// beforeAppend and afterAppend run under mu around each gateway event's
	// append (the sink-level kill points); onHead receives every new head.
	beforeAppend func(devcomposition.AuditEvent)
	afterAppend  func(devcomposition.AuditEvent)
	onHead       func(seq uint64, hash string, file []byte)
}

func newEvidenceRun(dir, label string) (*evidenceRun, error) {
	log, err := audit.Create(audit.Options{Dir: dir, RunID: label})
	if err != nil {
		return nil, err
	}
	return &evidenceRun{dir: dir, label: label, log: log}, nil
}

func auditEventFor(event devcomposition.AuditEvent) audit.Event {
	digest := ""
	if event.EffectDigest != [32]byte{} {
		digest = hex.EncodeToString(event.EffectDigest[:])
	}
	return audit.Event{
		Stage: event.Stage, Actor: event.Actor, Component: event.Component, Location: event.Location,
		Outcome: event.Outcome, Summary: event.Summary, OperationID: opText(event.OperationID),
		EffectType: event.EffectType, EffectDigest: digest, Details: event.Details, Artifacts: event.Artifacts,
	}
}

// appendLocked appends one entry and streams the new head. The caller holds
// mu.
func (r *evidenceRun) appendLocked(event audit.Event) error {
	_, err := r.log.Append(event)
	if err != nil {
		return err
	}
	if r.onHead != nil {
		seq, file, readErr := r.log.HeadFileBytes()
		_, hash := r.log.Head()
		if readErr != nil {
			file = nil
		}
		r.onHead(seq, hash, file)
	}
	return nil
}

// Record implements devcomposition.AuditSink.
func (r *evidenceRun) Record(event devcomposition.AuditEvent) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.closed {
		return errors.New("evidence run is closed")
	}
	converted := auditEventFor(event)
	if converted.Location == "" {
		converted.Location = "agentgate-killsuite gateway"
	}
	if !r.begun {
		r.pending = append(r.pending, converted)
		return nil
	}
	if r.beforeAppend != nil {
		r.beforeAppend(event)
	}
	if err := r.appendLocked(converted); err != nil {
		return err
	}
	if r.afterAppend != nil {
		r.afterAppend(event)
	}
	return nil
}

// evalRunDocument is run.json in the demo's format (CONTRACTS section 5.4).
type evalRunDocument struct {
	Format          string                        `json:"format"`
	Producer        string                        `json:"producer"`
	RunID           string                        `json:"run_id"`
	StartedAt       string                        `json:"started_at"`
	Host            string                        `json:"host"`
	PID             int                           `json:"pid"`
	Identity        map[string]string             `json:"identity"`
	Policy          devcomposition.PolicyInfo     `json:"policy"`
	PolicySnapshot  devcomposition.PolicySnapshot `json:"policy_snapshot"`
	Delegation      map[string]any                `json:"delegation,omitempty"`
	Catalog         *world                        `json:"catalog"`
	KeysSHA256      string                        `json:"keys_sha256"`
	SimulatorOrigin string                        `json:"simulator_origin"`
	Custody         map[string]any                `json:"custody"`
	Continues       *audit.Continuation           `json:"continues,omitempty"`
}

// begin writes keys.json and run.json, records RUN_STARTED and
// DELEGATION_GRANTED (and a restored DELEGATION_REVOKED), then the events the
// gateway recorded before (none in practice). It runs after the gateway is
// built and before any call.
func (r *evidenceRun) begin(w *world, comp *devcomposition.Composition, config devcomposition.Config, grant *signedGrant, host, note string) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	auditKID, auditPublic := r.log.PublicKey()
	keys := []audit.Key{audit.NewKey(auditKID, audit.RoleAuditLog, audit.AuditKeyPurpose, auditPublic)}
	for _, key := range comp.PublicKeys() {
		keys = append(keys, audit.NewKey(key.KID, key.Role, key.Purpose, key.Public))
	}
	keysSHA, err := audit.WriteKeys(r.dir, audit.KeysDocument{Format: audit.KeysFormat, RunID: r.label, Keys: keys})
	if err != nil {
		return err
	}
	r.keysSHA256 = keysSHA
	policy := comp.Policy()
	document := evalRunDocument{
		Format: runFormat, Producer: "cmd/agentgate-killsuite gateway child (" + note + ")",
		RunID: r.label, StartedAt: time.Now().UTC().Format(time.RFC3339Nano), Host: host, PID: os.Getpid(),
		Identity: map[string]string{"tenant_id": worldTenant, "principal_id": worldPrincipal, "task_id": worldTask},
		Policy:   policy, PolicySnapshot: comp.PolicySnapshot(), Catalog: w, KeysSHA256: keysSHA,
		SimulatorOrigin: config.SimulatorOrigin, Custody: map[string]any{"provider_process": true, "witness": false},
		Continues: r.continues,
	}
	if grant != nil {
		document.Delegation = map[string]any{
			"grant_id": grant.grant.GrantID, "grant_hash": hex.EncodeToString(grant.hash[:]),
			"authority_kid": hex.EncodeToString(grant.authorityKID[:]), "signed_grant": base64.StdEncoding.EncodeToString(grant.signed),
		}
	}
	runSHA, err := audit.WriteJSONAtomicSHA256(filepath.Join(r.dir, audit.RunFile), document)
	if err != nil {
		return err
	}
	location := fmt.Sprintf("agentgate-killsuite (pid %d) @ %s", os.Getpid(), host)
	summary := "Kill-suite run started (" + note + ")."
	details := map[string]any{
		"keys_sha256": keysSHA, "run_sha256": runSHA, "policy_hash": policy.HashHex, "policy_name": policy.Name,
		"catalog":          map[string]int{"recipients": len(w.Recipients), "payees": len(w.Payees), "documents": len(w.Documents)},
		"simulator_origin": config.SimulatorOrigin, "escalation": policy.Escalation,
		"operation_journal": config.OperationJournal != "",
	}
	if r.continues != nil {
		// A continuation segment (gateway restarted on the operation journal),
		// recorded as the demo and the evaluation harness record it.
		restored := len(comp.Operations())
		summary = fmt.Sprintf("Gateway restarted on the operation journal (%s): this evidence segment continues run %s (%d operation(s) restored from the journal), with new per-run keys.",
			note, r.continues.RunID, restored)
		details[audit.ContinuesField] = r.continues.Map()
		details["restored_operations"] = restored
	}
	if err := r.appendLocked(audit.Event{
		Stage: "RUN_STARTED", Actor: "system", Component: "eval/run", Location: location, Outcome: "info",
		Summary: summary, Details: details,
	}); err != nil {
		return err
	}
	if grant != nil {
		if err := r.appendLocked(audit.Event{
			Stage: "DELEGATION_GRANTED", Actor: "organisation:" + worldTenant, Component: "eval/delegation", Location: location, Outcome: "info",
			Summary: "Bounded autonomy delegated for the evaluation run.",
			Details: map[string]any{
				"grant_id": grant.grant.GrantID, "grant_hash": hex.EncodeToString(grant.hash[:]), "authority_kid": hex.EncodeToString(grant.authorityKID[:]),
				"purpose": grant.grant.Purpose, "effect_types": grant.grant.EffectTypes, "recipients": grant.grant.Recipients, "payees": grant.grant.Payees,
				"budgets": grant.grant.Budgets, "max_counts": grant.grant.MaxCounts, "nbf": grant.grant.NotBefore, "exp": grant.grant.ExpiresAt,
			},
			Artifacts: map[string][]byte{"delegation_grant": grant.signed},
		}); err != nil {
			return err
		}
		if status, ok := comp.DelegationStatus(); ok && status.Revoked && r.continues != nil {
			if err := r.appendLocked(audit.Event{
				Stage: "DELEGATION_REVOKED", Actor: "organisation:" + worldTenant, Component: "eval/delegation", Outcome: "info",
				Location: location,
				Summary:  "Grant " + grant.grant.GrantID + " stays revoked: it was revoked in an earlier segment and the restarted gateway restored the revocation from its operation journal.",
				Details:  map[string]any{"grant_id": grant.grant.GrantID, "grant_hash": hex.EncodeToString(grant.hash[:]), "restored": true},
			}); err != nil {
				return err
			}
		}
	}
	r.begun = true
	for _, event := range r.pending {
		if err := r.appendLocked(event); err != nil {
			return err
		}
	}
	r.pending = nil
	return nil
}

// finish writes provider-journal.json from the provider process's GET
// /journal (named after this segment) and closes the log. It returns the
// final head.
func (r *evidenceRun) finish(ctx context.Context, providerOrigin string) (uint64, string, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.closed {
		seq, hash := r.log.Head()
		return seq, hash, nil
	}
	r.closed = true
	var errs []error
	document, err := fetchProviderJournal(ctx, providerOrigin)
	if err == nil {
		document.RunID = r.label
		err = audit.WriteJSONAtomic(filepath.Join(r.dir, audit.ProviderJournalFile), document)
	}
	errs = append(errs, err)
	seq, hash := r.log.Head()
	errs = append(errs, r.log.Close())
	return seq, hash, errors.Join(errs...)
}

// fetchProviderJournal reads GET /journal from the provider process.
func fetchProviderJournal(ctx context.Context, origin string) (providerJournalDocument, error) {
	request, err := http.NewRequestWithContext(ctx, http.MethodGet, origin+"/journal", nil)
	if err != nil {
		return providerJournalDocument{}, err
	}
	response, err := (&http.Client{Timeout: 10 * time.Second}).Do(request)
	if err != nil {
		return providerJournalDocument{}, fmt.Errorf("provider journal: %w", err)
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK {
		return providerJournalDocument{}, fmt.Errorf("provider journal: HTTP %d", response.StatusCode)
	}
	var document providerJournalDocument
	if err := json.NewDecoder(io.LimitReader(response.Body, 64<<20)).Decode(&document); err != nil {
		return providerJournalDocument{}, fmt.Errorf("provider journal: %w", err)
	}
	return document, nil
}
