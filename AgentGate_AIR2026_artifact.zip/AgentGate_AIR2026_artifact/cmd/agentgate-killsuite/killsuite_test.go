package main

import (
	"bytes"
	"context"
	csvpkg "encoding/csv"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"agentgate/internal/audit"
	"agentgate/internal/auditverify"
	"agentgate/internal/devcomposition"
	"agentgate/internal/opjournal"
)

// The test binary doubles as the gateway child and as a stand-in for the
// agentgate-verify program (same flags subset, same --json report, same exit
// codes), so the end-to-end test needs no separately built executables.
const testRoleEnv = "KILLSUITE_TEST_ROLE"

func TestMain(m *testing.M) {
	switch os.Getenv(testRoleEnv) {
	case "gateway":
		os.Exit(run(os.Args[1:], os.Stdout, os.Stderr))
	case "verify":
		os.Exit(standInVerifier(os.Args[1:], os.Stdout, os.Stderr))
	}
	os.Exit(m.Run())
}

// standInVerifier mirrors agentgate-verify --json [--workers N]
// [--expect-keys HEX] [--expect-head HEX] DIR.
func standInVerifier(args []string, stdout, stderr io.Writer) int {
	var options auditverify.Options
	dir := ""
	for index := 0; index < len(args); index++ {
		switch args[index] {
		case "--json":
		case "--workers":
			index++
		case "--expect-keys":
			index++
			options.ExpectKeysSHA256 = args[index]
		case "--expect-head":
			index++
			options.ExpectHead = args[index]
		default:
			dir = args[index]
		}
	}
	options.Workers = 1
	report, err := auditverify.VerifyRun(dir, options)
	if err != nil {
		fmt.Fprintln(stderr, err)
		return 2
	}
	if err := json.NewEncoder(stdout).Encode(report); err != nil {
		return 2
	}
	if report.Verdict != auditverify.VerdictVerified {
		return 1
	}
	return 0
}

func TestMatrixShape(t *testing.T) {
	cells := matrix()
	names := map[string]bool{}
	groups := map[string]int{}
	for _, cell := range cells {
		if names[cell.Name] {
			t.Fatalf("duplicate cell name %s", cell.Name)
		}
		names[cell.Name] = true
		groups[cell.Group]++
		if cell.Kill != "" {
			if _, ok := lookupKillPoint(cell.Kill); !ok {
				t.Errorf("%s: unknown kill point %q", cell.Name, cell.Kill)
			}
		}
		if cell.Retry == "fresh-id" && cell.Path != pathAllowPayment {
			t.Errorf("%s: fresh-ID controls are for the ALLOW payment only", cell.Name)
		}
		if cell.Retry != "same-id" && cell.Retry != "fresh-id" {
			t.Errorf("%s: retry %q", cell.Name, cell.Retry)
		}
		if cell.Models == "" {
			t.Errorf("%s: no description", cell.Name)
		}
		if cell.Group == groupSurrogate && cell.Kill != sinkAfterEffectExecuted {
			t.Errorf("%s: surrogates start from a kill after EFFECT_EXECUTED", cell.Name)
		}
	}
	// 7 kill points x (ALLOW same-id, FLAG same-id, ALLOW fresh-id), 4 human,
	// 8 provider, 4 surrogates, 1 journal write failure, 1 same-process replay.
	want := map[string]int{groupKill: 21, groupHuman: 4, groupProvider: 8, groupSurrogate: 4, groupJournal: 1, groupReplay: 1}
	for group, count := range want {
		if groups[group] != count {
			t.Errorf("group %s has %d cells, want %d", group, groups[group], count)
		}
	}
	if len(cells) != 39 {
		t.Errorf("matrix has %d cells, want 39", len(cells))
	}
}

func TestKillPointsCoverTheFaultHooks(t *testing.T) {
	mapped := map[devcomposition.FaultPoint]bool{}
	for _, point := range killPoints {
		if point.Fault != "" {
			mapped[point.Fault] = true
		}
		hooks := 0
		for _, set := range []bool{point.Fault != "", point.Sink != "", point.External} {
			if set {
				hooks++
			}
		}
		if hooks != 1 {
			t.Errorf("kill point %s must have exactly one of a fault hook, a sink point or an external kill", point.Name)
		}
	}
	for _, point := range devcomposition.AllFaultPoints() {
		// head_replace fires at the same moment as audit_append (see
		// killPoints); every other hook is a kill point.
		if point != devcomposition.FaultHeadReplace && !mapped[point] {
			t.Errorf("fault hook %s has no kill point", point)
		}
	}
	if len(gatewayKillPoints()) != 7 {
		t.Errorf("%d gateway kill points, want 7", len(gatewayKillPoints()))
	}
}

func TestSelectCells(t *testing.T) {
	cells := matrix()
	human, err := selectCells(cells, "human", "")
	if err != nil || len(human) != 4 {
		t.Fatalf("human group: %d cells, %v", len(human), err)
	}
	some, err := selectCells(cells, "all", "kill/after_receipt/,journal/")
	if err != nil || len(some) != 4 {
		t.Fatalf("substring selection: %d cells, %v", len(some), err)
	}
	both, err := selectCells(cells, "kill,surrogate", "torn,after_effect_executed")
	if err != nil || len(both) != 5 {
		t.Fatalf("group and substring: %d cells, %v", len(both), err)
	}
	if _, err := selectCells(cells, "nonsense", ""); err == nil {
		t.Error("an unknown group was accepted")
	}
	if _, err := selectCells(cells, "", "no-such-cell"); err == nil {
		t.Error("an empty selection was accepted")
	}
}

func TestParseSuiteFlags(t *testing.T) {
	verifier := filepath.Join(t.TempDir(), "agentgate-verify.exe")
	if err := os.WriteFile(verifier, []byte("stand-in"), 0o600); err != nil {
		t.Fatal(err)
	}
	options, err := parseSuiteFlags([]string{"-verify", verifier, "-out", "out"}, io.Discard)
	if err != nil {
		t.Fatal(err)
	}
	if options.reps != 5 || options.hostLabel != "review-host" || options.callTimeout != time.Minute {
		t.Errorf("defaults: %+v", options)
	}
	for name, args := range map[string][]string{
		"no verify":      {"-out", "out"},
		"no out":         {"-verify", verifier},
		"zero reps":      {"-verify", verifier, "-out", "out", "-reps", "0"},
		"short timeout":  {"-verify", verifier, "-out", "out", "-call-timeout", "5s"},
		"missing binary": {"-verify", verifier + ".missing", "-out", "out"},
		"extra argument": {"-verify", verifier, "-out", "out", "extra"},
	} {
		if _, err := parseSuiteFlags(args, io.Discard); err == nil {
			t.Errorf("%s: accepted", name)
		}
	}
	if options, err := parseSuiteFlags([]string{"-list"}, io.Discard); err != nil || !options.list {
		t.Errorf("-list needs no other flag: %v", err)
	}
}

func TestParseCallResponse(t *testing.T) {
	answer := parseCallResponse(http.StatusOK, []byte(`{"jsonrpc":"2.0","id":1,"result":{"structuredContent":{"status":"COMMITTED","reason":"reconciled","dispatched":true,"flagged":true}}}`))
	if answer.Status != "COMMITTED" || answer.Reason != "reconciled" || !answer.Dispatched || !answer.Flagged || !answer.FlagReported || answer.key() != "COMMITTED/reconciled" {
		t.Errorf("committed answer: %+v", answer)
	}
	plain := parseCallResponse(http.StatusOK, []byte(`{"result":{"structuredContent":{"status":"REJECTED","reason":"provider_not_committed"}}}`))
	if plain.FlagReported || plain.Flagged {
		t.Errorf("an answer without the member must not count as reporting the flag: %+v", plain)
	}
	challenge := parseCallResponse(http.StatusOK, []byte(`{"result":{"requestState":"state-1","inputRequests":{"approval":{"params":{"url":"https://127.0.0.1:19444/approvals/abc"}}},"structuredContent":{"status":"PENDING","reason":"approval_required"}}}`))
	if !challenge.Challenge || challenge.RequestState != "state-1" || challenge.ApprovalURL != approvalOrigin+"/approvals/abc" {
		t.Errorf("challenge: %+v", challenge)
	}
	if rpc := parseCallResponse(http.StatusOK, []byte(`{"error":{"code":-32602,"message":"bad"}}`)); rpc.Error == "" || rpc.key() != "ERROR" {
		t.Errorf("JSON-RPC error: %+v", rpc)
	}
	if status := parseCallResponse(http.StatusUnauthorized, []byte("no")); status.Error == "" || status.HTTPStatus != http.StatusUnauthorized {
		t.Errorf("HTTP error: %+v", status)
	}
	if dead := (callResult{NoAnswer: true}); dead.key() != "NO_ANSWER" {
		t.Errorf("no answer key %q", dead.key())
	}
}

func TestChildProtocolLines(t *testing.T) {
	var out bytes.Buffer
	sink := &emitter{out: &out}
	sink.emit(childMessage{Event: "ready", PID: 7, MCP: "http://127.0.0.1:1/mcp", KeysSHA256: strings.Repeat("a", 64)})
	sink.emit(childMessage{Event: "head", Seq: 1, Hash: strings.Repeat("1", 64), HeadFile: []byte(`{"seq":1}`)})
	out.WriteString("noise from a library\n")
	sink.emit(childMessage{Event: "head", Seq: 2, Hash: strings.Repeat("2", 64), HeadFile: []byte(`{"seq":2}`)})
	sink.emit(childMessage{Event: "journal_read_only"})
	sink.emit(childMessage{Event: "kill", Point: "after_receipt", Operation: "op"})
	child := &childProc{readyCh: make(chan struct{}), exited: make(chan struct{})}
	child.readLines(&out)
	if child.ready == nil || child.ready.PID != 7 {
		t.Fatalf("ready line not read: %+v", child.ready)
	}
	head, previous := child.pins()
	if head.Seq != 2 || string(head.File) != `{"seq":2}` || previous.Seq != 1 || string(previous.File) != `{"seq":1}` {
		t.Errorf("pins: head %+v previous %+v", head, previous)
	}
	if killed := child.killMessage(); killed == nil || killed.Point != "after_receipt" {
		t.Errorf("kill line: %+v", killed)
	}
	if !child.journalMadeReadOnly() {
		t.Error("journal_read_only line not read")
	}
}

// writeKilledFolder makes a small genuine journal and evidence segment with
// the real writers and returns the head.json bytes before the last append.
func writeKilledFolder(t *testing.T) (journal, segment string, previousHead []byte) {
	t.Helper()
	dir := t.TempDir()
	journal = filepath.Join(dir, "operations.jsonl")
	handle, _, err := opjournal.Open(journal)
	if err != nil {
		t.Fatal(err)
	}
	for _, kind := range []string{"received", "capability_issued", "dispatch_intent"} {
		if _, err := handle.Append("tenant/principal/op", kind, map[string]string{"k": kind}); err != nil {
			t.Fatal(err)
		}
	}
	segment = filepath.Join(dir, "segment-1")
	log, err := audit.Create(audit.Options{Dir: segment, RunID: "ks-test-segment-1"})
	if err != nil {
		t.Fatal(err)
	}
	if _, err := audit.WriteJSONAtomicSHA256(filepath.Join(segment, audit.RunFile), map[string]string{"run_id": "ks-test-segment-1"}); err != nil {
		t.Fatal(err)
	}
	kid, public := log.PublicKey()
	if _, err := audit.WriteKeys(segment, audit.KeysDocument{RunID: "ks-test-segment-1", Keys: []audit.Key{audit.NewKey(kid, audit.RoleAuditLog, audit.AuditKeyPurpose, public)}}); err != nil {
		t.Fatal(err)
	}
	for index, stage := range []string{"RUN_STARTED", "CAPABILITY_ISSUED", "EFFECT_EXECUTED"} {
		if index == 2 {
			_, previousHead, err = log.HeadFileBytes()
			if err != nil {
				t.Fatal(err)
			}
		}
		if _, err := log.Append(audit.Event{Stage: stage, Actor: "test", Component: "test", Outcome: "info", Summary: stage}); err != nil {
			t.Fatal(err)
		}
	}
	if err := log.Close(); err != nil {
		t.Fatal(err)
	}
	return journal, segment, previousHead
}

func TestSurrogateTornJournalIsDiscarded(t *testing.T) {
	journal, segment, previous := writeKilledFolder(t)
	before, _ := os.ReadFile(journal)
	if _, err := applySurrogate(surrogateTornJournal, journal, segment, previous); err != nil {
		t.Fatal(err)
	}
	torn, _ := os.ReadFile(journal)
	if len(torn) <= len(before) || torn[len(torn)-1] == '\n' {
		t.Fatal("no torn tail was written")
	}
	_, records, err := opjournal.Open(journal)
	if err != nil {
		t.Fatalf("the journal must discard a torn final line: %v", err)
	}
	if len(records) != 3 {
		t.Errorf("%d records after discarding the torn line, want 3", len(records))
	}
	if after, _ := os.ReadFile(journal); !bytes.Equal(after, before) {
		t.Error("opjournal.Open did not truncate the torn line")
	}
}

func TestSurrogateTornAuditBlocksTheContinuation(t *testing.T) {
	journal, segment, previous := writeKilledFolder(t)
	if _, err := audit.ReadContinuation(segment, filepath.Join(filepath.Dir(segment), "segment-2")); err != nil {
		t.Fatalf("the intact segment must give a continuation: %v", err)
	}
	if _, err := applySurrogate(surrogateTornAudit, journal, segment, previous); err != nil {
		t.Fatal(err)
	}
	if _, err := audit.ReadContinuation(segment, filepath.Join(filepath.Dir(segment), "segment-2")); err == nil {
		t.Fatal("a torn audit tail must refuse the continuation")
	}
}

func TestSurrogateHeadRevertedAndTempHead(t *testing.T) {
	journal, segment, previous := writeKilledFolder(t)
	current, _ := os.ReadFile(filepath.Join(segment, audit.HeadFile))
	if _, err := applySurrogate(surrogateTempHead, journal, segment, previous); err != nil {
		t.Fatal(err)
	}
	temp, err := os.ReadFile(filepath.Join(segment, ".head.json.tmp-1234567890"))
	if err != nil || !bytes.Equal(temp, current) {
		t.Fatalf("leftover temp head: %v", err)
	}
	if _, err := applySurrogate(surrogateHeadReverted, journal, segment, previous); err != nil {
		t.Fatal(err)
	}
	reverted, _ := os.ReadFile(filepath.Join(segment, audit.HeadFile))
	if !bytes.Equal(reverted, previous) || bytes.Equal(reverted, current) {
		t.Fatal("head.json was not replaced by the previous genuine head")
	}
	if _, err := applySurrogate(surrogateHeadReverted, journal, segment, nil); err == nil {
		t.Error("a reverted head without a streamed previous head was accepted")
	}
	if _, err := applySurrogate("nonsense", journal, segment, previous); err == nil {
		t.Error("an unknown surrogate was accepted")
	}
	empty := filepath.Join(t.TempDir(), "empty")
	if err := os.WriteFile(empty, []byte("no newline"), 0o600); err != nil {
		t.Fatal(err)
	}
	if _, err := tearLastLine(empty); err == nil {
		t.Error("a file without a complete line was torn")
	}
}

func TestChildInjectorMakesTheJournalReadOnly(t *testing.T) {
	journal, _, _ := writeKilledFolder(t)
	var out bytes.Buffer
	operation := newOperationID()
	injector := &childInjector{emitter: &emitter{out: &out}, readOnlyOperation: operation, journal: journal}
	defer os.Chmod(journal, 0o600)
	if err := injector.Fail(devcomposition.FaultBeforeCapabilityConsume, operation); err != nil {
		t.Fatal(err)
	}
	writable, err := os.OpenFile(journal, os.O_WRONLY|os.O_APPEND, 0o600)
	if err != nil {
		t.Fatalf("the journal must stay writable before the consume hook: %v", err)
	}
	writable.Close()
	if err := injector.Fail(devcomposition.FaultAfterCapabilityConsume, operation); err != nil {
		t.Fatal(err)
	}
	if file, err := os.OpenFile(journal, os.O_WRONLY|os.O_APPEND, 0o600); err == nil {
		file.Close()
		t.Fatal("the journal is still writable after the consume hook")
	}
	if !strings.Contains(out.String(), `"journal_read_only"`) {
		t.Errorf("no journal_read_only line: %q", out.String())
	}
}

func TestChildInjectorDiesOnlyAtItsPoint(t *testing.T) {
	var out bytes.Buffer
	operation, other := newOperationID(), newOperationID()
	died := []int{}
	saved := exitProcess
	exitProcess = func(code int) { died = append(died, code) }
	defer func() { exitProcess = saved }()
	point, _ := lookupKillPoint("after_receipt")
	injector := &childInjector{emitter: &emitter{out: &out}, kill: point, operation: operation}
	_ = injector.Fail(devcomposition.FaultAfterReceiptBeforeAudit, other)
	_ = injector.Fail(devcomposition.FaultAuditAppend, operation)
	if len(died) != 0 {
		t.Fatalf("died at the wrong point or operation: %v", died)
	}
	_ = injector.Fail(devcomposition.FaultAfterReceiptBeforeAudit, operation)
	if len(died) != 1 || died[0] != killExitCode || !strings.Contains(out.String(), `"point":"after_receipt"`) {
		t.Fatalf("kill: exits %v, output %q", died, out.String())
	}
}

func TestTotalsAcceptance(t *testing.T) {
	verified := &verifyOutcome{Verdict: "VERIFIED", Assurance: "ANCHORED"}
	failed := &verifyOutcome{Verdict: "FAILED", Assurance: "FAILED", Failing: []string{"provider.matches_audit"}}
	clean := cellResult{cellSpec: cellSpec{Name: "a", Kill: "after_receipt"}, KillReached: true, Effects: map[string]int{roleOriginal: 1},
		Segments: []segmentOutcome{{Index: 1, Verify: failed}, {Index: 2, Verify: verified}}, FlagPreserved: boolPtr(false), FlagOutcomeEntries: boolPtr(false)}
	deliberate := cellResult{cellSpec: cellSpec{Name: "b", Deliberate: true}, UnresolvedAfterReconcile: true, UnresolvedOperations: 1, UndecidedOperations: 1,
		UnsettledWithEffect: 1, Effects: map[string]int{roleOriginal: 1}, ClassificationEvidence: "issuer_only_unresolved",
		Segments: []segmentOutcome{{Index: 1, Verify: &verifyOutcome{Verdict: "VERIFIED", Assurance: "ANCHORED", Warning: []string{"op.outcome_resolved"}}}}}
	surrogate := cellResult{cellSpec: cellSpec{Name: "c"}, Effects: map[string]int{roleOriginal: 1}, ClassificationFolder: "FAILED/FAILED",
		AsKilled: &verifyOutcome{Verdict: "VERIFIED", Assurance: "ANCHORED", Warning: []string{"op.outcome_resolved"}},
		Segments: []segmentOutcome{{Index: 1, Verify: failed}}}
	totals := totalsOf([]cellResult{clean, deliberate, surrogate})
	if !totals.AcceptancePassed || totals.UnresolvedDeliberate != 1 || totals.UnresolvedAfterReconcile != 0 || totals.UndecidedAfterReconcile != 1 || totals.UnsettledWithEffect != 0 {
		t.Fatalf("clean totals: %+v", totals)
	}
	if totals.WarningChecks["op.outcome_resolved"] != 1 || totals.ClassificationEvidence["issuer_only_unresolved"] != 1 || totals.ClassificationEvidence[classNotReported] != 1 ||
		totals.ClassificationEvidence[classFailedFolder] != 1 {
		t.Errorf("warning and classification counts: %+v %+v", totals.WarningChecks, totals.ClassificationEvidence)
	}
	// The as-killed copy is counted apart from the segment verdicts.
	if totals.AsKilled["VERIFIED/ANCHORED"] != 1 || totals.AsKilledWarningChecks["op.outcome_resolved"] != 1 || totals.SingleSegment["FAILED/FAILED"] != 1 {
		t.Errorf("as-killed counts: %+v %+v single %+v", totals.AsKilled, totals.AsKilledWarningChecks, totals.SingleSegment)
	}
	totals = totalsOf([]cellResult{clean, deliberate})
	if totals.Segment1Alone["FAILED/FAILED"] != 1 || totals.RunWalk["VERIFIED/ANCHORED"] != 1 || totals.SingleSegment["VERIFIED/ANCHORED"] != 1 {
		t.Errorf("verdict counts: %+v %+v %+v", totals.Segment1Alone, totals.RunWalk, totals.SingleSegment)
	}
	if totals.FlagCells != 1 || totals.FlagLost != 1 || totals.FlagLostInEntries != 1 || totals.FailingChecks["provider.matches_audit"] != 1 {
		t.Errorf("flag and check counts: %+v", totals)
	}
	for name, broken := range map[string]cellResult{
		"duplicate":        {DuplicateOperations: 1},
		"false no":         {NotCommittedWithEffect: 1},
		"rejected":         {RejectedWithEffectAtAnswer: 1},
		"committed":        {CommittedWithoutEffect: 1},
		"unresolved":       {UnresolvedAfterReconcile: true, UnresolvedOperations: 1},
		"unsettled effect": {UnsettledWithEffect: 1},
		"redispatch":       {Redispatch: true},
		"unknown dispatch": {UnknownDispatches: 1},
		"kill not reached": {cellSpec: cellSpec{Kill: "after_receipt"}},
		"interrupted":      {Interrupted: true},
		"cell failed":      {Error: "boom"},
	} {
		if totalsOf([]cellResult{clean, broken}).AcceptancePassed {
			t.Errorf("%s: acceptance passed", name)
		}
	}
	csv := resultsCSV([]cellResult{clean, deliberate, surrogate})
	if lines := strings.Count(csv, "\n"); lines != 4 {
		t.Errorf("CSV has %d lines, want a header and 3 rows", lines)
	}
	header := strings.SplitN(csv, "\n", 2)[0]
	for _, column := range []string{"as_killed_warnings", "unsettled_with_dispatch_or_effect", "unlisted_operations", "flag_in_replay_entries", "classification_folder_verdict"} {
		if !strings.Contains(header, column) {
			t.Errorf("CSV header has no %s column", column)
		}
	}
	// encoding/csv refuses rows whose field count differs from the header's.
	if rows, err := csvpkg.NewReader(strings.NewReader(csv)).ReadAll(); err != nil || len(rows) != 4 {
		t.Errorf("CSV rows %d: %v", len(rows), err)
	}
}

// Every operation of the cell is judged after Reconcile, listed or not: one
// that was dispatched or holds a provider effect must be COMMITTED or
// REJECTED, and one the gateway does not list counts as undecided.
func TestSettledMeasuresCountUnlistedAndUndecidedOperations(t *testing.T) {
	original, fresh, probe := newOperationID(), newOperationID(), newOperationID()
	c := &cellRun{ids: map[string][16]byte{roleOriginal: original, roleFresh: fresh, roleProbe: probe}, res: &cellResult{}}
	c.res.StatesAfterReconcile = []operationWire{
		{OperationID: opText(original), Status: ""}, // undecided, but the provider received a request
		{OperationID: opText(fresh), Status: "COMMITTED", Dispatched: true},
	}
	c.res.UnresolvedOperations, c.res.UndecidedOperations = afterReconcileCounts(c.res.StatesAfterReconcile)
	c.settledMeasures(map[string]int{opText(fresh): 1}, map[string]int{opText(original): 1, opText(fresh): 1})
	if c.res.UnlistedOperations != 1 || c.res.UndecidedOperations != 2 || c.res.UnsettledWithEffect != 1 {
		t.Fatalf("unlisted %d undecided %d unsettled %d, want 1, 2 and 1", c.res.UnlistedOperations, c.res.UndecidedOperations, c.res.UnsettledWithEffect)
	}
	// An unlisted operation that holds a provider effect is unsettled too.
	c = &cellRun{ids: map[string][16]byte{roleOriginal: original, roleProbe: probe}, res: &cellResult{StatesAfterReconcile: []operationWire{}}}
	c.settledMeasures(map[string]int{opText(probe): 1}, map[string]int{})
	if c.res.UnlistedOperations != 2 || c.res.UnsettledWithEffect != 1 || len(c.res.Notes) != 1 || !strings.Contains(c.res.Notes[0], "not listed") {
		t.Fatalf("unlisted %d unsettled %d notes %v", c.res.UnlistedOperations, c.res.UnsettledWithEffect, c.res.Notes)
	}
	if totalsOf([]cellResult{*c.res}).AcceptancePassed {
		t.Error("an unlisted operation with a provider effect passed the acceptance")
	}
}

func TestAfterReconcileCountsEveryOperation(t *testing.T) {
	unresolved, undecided := afterReconcileCounts([]operationWire{
		{OperationID: "original", Status: "COMMITTED"},
		{OperationID: "fresh", Status: "UNCERTAIN", Reason: "provider_outcome_unknown"},
		{OperationID: "probe", Status: "RECONCILIATION_REQUIRED"},
		{OperationID: "consumed", Status: ""},
		{OperationID: "waiting", Status: "PENDING"},
		{OperationID: "absent", Status: "REJECTED", Reason: "provider_not_committed"},
	})
	if unresolved != 2 || undecided != 2 {
		t.Errorf("unresolved %d undecided %d, want 2 and 2", unresolved, undecided)
	}
}

func TestVerifierWarningsAndClassificationAreRead(t *testing.T) {
	raw := []byte(`{"verdict":"VERIFIED","assurance":"ANCHORED","missing":["m"],
		"failures":[],
		"warnings":[{"id":"op.outcome_resolved","seq":7,"detail":"left uncertain"},{"id":"head.fresh","seq":0,"detail":"stale"},{"id":"op.outcome_resolved","seq":9,"detail":"again"}],
		"operations":[{"operation_id":"op-1","status":"executed","flagged":true,"reconciled":true,"classification_evidence":"issuer_only_reconciled"}]}`)
	var report verifierReport
	if err := json.Unmarshal(raw, &report); err != nil {
		t.Fatal(err)
	}
	out := verifyOutcome{Failing: []string{}, Findings: []string{}, Warning: []string{}, WarningFindings: []string{}, Missing: []string{}}
	out.fromReport(report)
	if strings.Join(out.Warning, " ") != "head.fresh op.outcome_resolved" || len(out.WarningFindings) != 3 || len(out.Failing) != 0 {
		t.Errorf("warnings: %v %v", out.Warning, out.WarningFindings)
	}
	if op, ok := out.operation("op-1"); !ok || op.ClassificationEvidence != "issuer_only_reconciled" || !op.Flagged {
		t.Errorf("operation: %+v", op)
	}
	if out.verdictKey() != "VERIFIED/ANCHORED" || len(out.Missing) != 1 {
		t.Errorf("verdict %s missing %v", out.verdictKey(), out.Missing)
	}
}

func TestExpectFirstFailsACellWhoseFaultDidNotFire(t *testing.T) {
	c := &cellRun{spec: cellSpec{Fault: faultLostResponse, ExpectFirst: "UNCERTAIN"}, res: &cellResult{}}
	c.expectFirst(callResult{Status: "UNCERTAIN", Reason: "provider_outcome_unknown"})
	if len(c.failures) != 0 {
		t.Fatalf("an UNCERTAIN first answer failed the cell: %v", c.failures)
	}
	c.expectFirst(callResult{Status: "COMMITTED"})
	if len(c.failures) != 1 || !strings.Contains(c.failures[0], faultLostResponse) {
		t.Errorf("a COMMITTED first answer did not fail the cell: %v", c.failures)
	}
	for _, cell := range matrix() {
		if (cell.Group == groupProvider || cell.Group == groupJournal) && cell.ExpectFirst == "" {
			t.Errorf("%s has no expected first answer", cell.Name)
		}
	}
}

func TestDescribeBinary(t *testing.T) {
	exe, err := os.Executable()
	if err != nil {
		t.Fatal(err)
	}
	info := describeBinary(exe)
	if len(info.SHA256) != 64 || info.GoVersion == "" || info.Error != "" {
		t.Errorf("test binary: %+v", info)
	}
	if missing := describeBinary(filepath.Join(t.TempDir(), "none.exe")); missing.Error == "" || missing.SHA256 != "" {
		t.Errorf("missing binary: %+v", missing)
	}
}

// useTestBinaryAsChild points the suite at the test binary as the gateway
// child and as the verifier stand-in.
func useTestBinaryAsChild(t *testing.T) string {
	t.Helper()
	exe, err := os.Executable()
	if err != nil {
		t.Fatal(err)
	}
	testHooks.childExe = exe
	testHooks.childEnv = []string{testRoleEnv + "=gateway"}
	testHooks.verifierEnv = []string{testRoleEnv + "=verify"}
	t.Cleanup(func() { testHooks.childExe, testHooks.childEnv, testHooks.verifierEnv = "", nil, nil })
	return exe
}

// TestInterruptedCellIsNotAKill: a call cancelled by the operator is no
// answer, but the cell must be marked interrupted, not recorded as a kill.
func TestInterruptedCellIsNotAKill(t *testing.T) {
	if testing.Short() {
		t.Skip("starts a gateway process")
	}
	exe := useTestBinaryAsChild(t)
	w, err := newWorld()
	if err != nil {
		t.Fatal(err)
	}
	s := &suite{exe: exe, childEnv: testHooks.childEnv, workDir: t.TempDir(), hostLabel: "review-host", callTimeout: 30 * time.Second, w: w,
		verifier: verifierCommand{path: exe, extraEnv: testHooks.verifierEnv, timeout: time.Minute}}
	cells, err := selectCells(matrix(), "kill", "kill/after_receipt/allow-payment/same-id")
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	started := time.Now()
	res := s.runCell(ctx, cells[0], 1)
	if !res.Interrupted || res.KillReached || !strings.Contains(res.Error, "interrupted") {
		t.Errorf("interrupted %t kill reached %t error %q", res.Interrupted, res.KillReached, res.Error)
	}
	if len(res.Answers) != 1 || !res.Answers[0].Result.NoAnswer || len(res.Segments) != 1 || res.Segments[0].KillPoint != "" {
		t.Errorf("answers %+v segments %+v", res.Answers, res.Segments)
	}
	if elapsed := time.Since(started); elapsed > childExitTimeout {
		t.Errorf("the interrupted cell waited %s for a kill", elapsed)
	}
	if totals := totalsOf([]cellResult{res}); totals.AcceptancePassed || totals.InterruptedCells != 1 {
		t.Errorf("totals of an interrupted cell: %+v", totals)
	}
}

// TestEndToEnd runs a reduced matrix with real gateway child processes (the
// test binary in gateway mode), a real provider host and the verifier
// stand-in (the verifier package of this tree), and checks the measures and
// verdicts, including that every kill really happened and that the flag
// survives the recovery entries of a restarted gateway.
func TestEndToEnd(t *testing.T) {
	if testing.Short() {
		t.Skip("starts gateway processes")
	}
	exe := useTestBinaryAsChild(t)
	out, work := t.TempDir(), t.TempDir()
	only := strings.Join([]string{
		"kill/after_receipt/flag-message/same-id", "kill/before_call_result/allow-payment/same-id",
		"kill/after_consume/allow-payment/fresh-id", "human/after_receipt", "human/pending",
		"provider/certified_no_effect/", "provider/lookup_failure_persistent/",
		"surrogate/torn_audit_tail", "surrogate/head_reverted", "journal/", "replay/",
	}, ",")
	var console bytes.Buffer
	if err := runSuite([]string{"-verify", exe, "-out", out, "-work", work, "-reps", "1", "-only", only}, &console, io.Discard); err != nil {
		t.Fatalf("%v\n%s", err, console.String())
	}
	jsonPath, csvPath, mdPath := resultFiles(out)
	for _, path := range []string{csvPath, mdPath} {
		if _, err := os.Stat(path); err != nil {
			t.Fatal(err)
		}
	}
	raw, err := os.ReadFile(jsonPath)
	if err != nil {
		t.Fatal(err)
	}
	var result suiteResult
	if err := json.Unmarshal(raw, &result); err != nil {
		t.Fatal(err)
	}
	if len(result.Cells) != 11 {
		t.Fatalf("%d cells ran, want 11\n%s", len(result.Cells), console.String())
	}
	if !result.Totals.AcceptancePassed {
		t.Fatalf("acceptance failed: %+v\n%s", result.Totals, console.String())
	}
	if result.Totals.KillNotReached != 0 || result.Totals.UnknownDispatches != 0 {
		t.Errorf("kill points not reached %d, unknown dispatches %d", result.Totals.KillNotReached, result.Totals.UnknownDispatches)
	}
	if result.Build.SuiteAndGateway.SHA256 == "" || result.Build.Verifier.SHA256 == "" {
		t.Errorf("the results name no build: %+v", result.Build)
	}
	cells := map[string]cellResult{}
	for _, cell := range result.Cells {
		cells[cell.Name] = cell
		if cell.Error != "" {
			t.Errorf("%s: %s", cell.Name, cell.Error)
		}
		if cell.Kill != "" && !cell.KillReached {
			t.Errorf("%s: the kill point was not reached", cell.Name)
		}
	}
	check := func(name string, condition bool, format string, args ...any) {
		t.Helper()
		if !condition {
			t.Errorf("%s: "+format, append([]any{name}, args...)...)
		}
	}
	walk := func(cell cellResult) string {
		_, failing := segmentVerdict(cell, len(cell.Segments))
		verdict, _ := segmentVerdict(cell, len(cell.Segments))
		return verdict + " " + failing
	}
	// answer is the key of the answer to call in segment 1.
	answer := func(cell cellResult, call string) string {
		for _, record := range cell.Answers {
			if record.Segment == 1 && record.Call == call {
				return record.Result.key()
			}
		}
		return "none"
	}
	// killedAt says segment 1 died at point during call (no answer).
	killedAt := func(name, call, point string) {
		t.Helper()
		cell := cells[name]
		check(name, cell.KillReached && answer(cell, call) == "NO_ANSWER" && len(cell.Segments) == 2 && cell.Segments[0].KillPoint == point && cell.Segments[0].ExitCode == killExitCode,
			"kill reached %t, %s answer %s, segments %+v", cell.KillReached, call, answer(cell, call), cell.Segments)
	}

	name := "kill/after_receipt/flag-message/same-id"
	cell := cells[name]
	killedAt(name, "first", "after_receipt")
	check(name, cell.Effects[roleOriginal] == 1 && cell.StateAfterReconcile == "COMMITTED/reconciled", "effects %d state %s", cell.Effects[roleOriginal], cell.StateAfterReconcile)
	alone, failing := segmentVerdict(cell, 1)
	check(name, alone == "FAILED/FAILED" && strings.Contains(failing, "provider.matches_audit"), "segment 1 alone %s %s", alone, failing)
	// The verifier fails op.requires_policy when a recovery entry loses the
	// bound flag, so the run walk also guards the gateway's flag fix.
	check(name, strings.HasPrefix(walk(cell), "VERIFIED/ANCHORED"), "run walk %s", walk(cell))
	check(name, cell.FlagExpected && cell.FlagVerifier != nil && *cell.FlagVerifier, "flag in the verifier report %v", cell.FlagVerifier)
	check(name, cell.FlagPreserved != nil && *cell.FlagPreserved && cell.RecoveryEntries > 0 && cell.FlagRecoveryEntries != nil && *cell.FlagRecoveryEntries,
		"flag preserved %v, recovery entries %d flagged %v", cell.FlagPreserved, cell.RecoveryEntries, cell.FlagRecoveryEntries)
	check(name, cell.ClassificationEvidence == auditverify.ClassIssuerReconciled, "classification evidence %q", cell.ClassificationEvidence)

	name = "kill/before_call_result/allow-payment/same-id"
	cell = cells[name]
	killedAt(name, "first", sinkBeforeCallResult)
	alone, _ = segmentVerdict(cell, 1)
	check(name, alone == "VERIFIED/ANCHORED" && cell.StateAfterReconcile == "COMMITTED" && cell.Effects[roleOriginal] == 1, "segment 1 %s state %s", alone, cell.StateAfterReconcile)

	name = "kill/after_consume/allow-payment/fresh-id"
	cell = cells[name]
	killedAt(name, "first", "after_consume")
	check(name, cell.Effects[roleOriginal] == 0 && cell.Effects[roleFresh] == 1 && cell.Dispatches[roleOriginal] == 0, "effects %v dispatches %v", cell.Effects, cell.Dispatches)
	// The original operation keeps a consumed capability and no final status.
	check(name, cell.UndecidedOperations == 1 && cell.UnresolvedOperations == 0, "undecided %d unresolved %d", cell.UndecidedOperations, cell.UnresolvedOperations)

	name = "human/after_receipt"
	cell = cells[name]
	killedAt(name, "resume", "after_receipt")
	check(name, !cell.SecondApprovalRequired && cell.Effects[roleOriginal] == 1, "second approval %t effects %d", cell.SecondApprovalRequired, cell.Effects[roleOriginal])
	name = "human/pending"
	cell = cells[name]
	check(name, cell.SecondApprovalRequired && cell.Effects[roleOriginal] == 1 && cell.Segments[0].Ended == "terminated by the parent", "second approval %t effects %d ended %q", cell.SecondApprovalRequired, cell.Effects[roleOriginal], cell.Segments[0].Ended)

	name = "provider/certified_no_effect/allow-payment"
	cell = cells[name]
	check(name, cell.Effects[roleOriginal] == 0 && cell.StateAfterReconcile == "REJECTED/provider_not_committed", "effects %d state %s", cell.Effects[roleOriginal], cell.StateAfterReconcile)

	name = "provider/lookup_failure_persistent/allow-payment"
	cell = cells[name]
	check(name, cell.UnresolvedAfterReconcile && cell.Deliberate && cell.Dispatches[roleOriginal] == 1 && cell.StatusFailures == cell.StatusLookups && cell.StatusLookups >= 3,
		"unresolved %t dispatches %d lookups %d/%d", cell.UnresolvedAfterReconcile, cell.Dispatches[roleOriginal], cell.StatusFailures, cell.StatusLookups)

	name = "surrogate/torn_audit_tail"
	cell = cells[name]
	alone, _ = segmentVerdict(cell, 1)
	check(name, cell.RestartBlocked && strings.Contains(cell.RestartError, "restart blocked") && alone == "FAILED/FAILED", "blocked %t (%s) segment 1 %s", cell.RestartBlocked, cell.RestartError, alone)
	check(name, cell.AsKilled != nil && cell.AsKilled.verdictKey() == "VERIFIED/ANCHORED", "untouched copy %+v", cell.AsKilled)

	name = "surrogate/head_reverted"
	cell = cells[name]
	_, failing = segmentVerdict(cell, 1)
	check(name, strings.Contains(failing, "head.matches") && cell.StateAfterReconcile == "COMMITTED/reconciled", "segment 1 failing %q state %s", failing, cell.StateAfterReconcile)

	// The flagged message commits and is replayed in the same process and
	// after a restart: every replayed CALL_RESULT keeps the flag (the verifier
	// fails op.requires_policy on a replay that drops it, so both walks also
	// guard the gateway's fix).
	name = "replay/flag-message/same-process"
	cell = cells[name]
	alone, _ = segmentVerdict(cell, 1)
	check(name, cell.Effects[roleOriginal] == 1 && cell.Dispatches[roleOriginal] == 1 && cell.StateAfterReconcile == "COMMITTED" && len(cell.Answers) == sameProcessRetries+2,
		"effects %d dispatches %d state %s answers %d", cell.Effects[roleOriginal], cell.Dispatches[roleOriginal], cell.StateAfterReconcile, len(cell.Answers))
	check(name, cell.ReplayEntries == sameProcessRetries+1 && cell.SameProcessReplayEntries == sameProcessRetries && cell.RecoveryEntries == 1,
		"replays %d (same process %d), recovery entries %d", cell.ReplayEntries, cell.SameProcessReplayEntries, cell.RecoveryEntries)
	check(name, cell.FlagReplayEntries != nil && *cell.FlagReplayEntries && cell.FlagPreserved != nil && *cell.FlagPreserved && cell.FlagVerifier != nil && *cell.FlagVerifier,
		"flag in replays %v, preserved %v, verifier %v", cell.FlagReplayEntries, cell.FlagPreserved, cell.FlagVerifier)
	check(name, alone == "VERIFIED/ANCHORED" && strings.HasPrefix(walk(cell), "VERIFIED/ANCHORED"), "segment 1 %s, run walk %s", alone, walk(cell))
	check(name, result.Totals.FlagCellsWithSameProcessReplay == 1 && result.Totals.FlagLostInReplay == 0, "totals %+v", result.Totals)

	name = "journal/read_only_at_consume"
	cell = cells[name]
	keys := []string{}
	for _, answer := range cell.Answers {
		keys = append(keys, answer.Call+"="+answer.Result.key())
	}
	chain := strings.Join(keys, " ")
	check(name, strings.Contains(chain, "first=REJECTED/aborted_before_send") && strings.Contains(chain, "probe=REJECTED/journal_unavailable") &&
		strings.Contains(chain, "retry=COMMITTED") && cell.Effects[roleOriginal] == 1 && cell.Effects[roleProbe] == 0, "answers %s effects %v", chain, cell.Effects)
	info, err := os.Stat(filepath.Join(work, cell.Label, "operations.jsonl"))
	if err != nil {
		t.Fatal(err)
	}
	if info.Mode().Perm()&0o200 == 0 {
		t.Errorf("the journal must be writable again after the cell (mode %v)", info.Mode())
	}
}
