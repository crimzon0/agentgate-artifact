// Command agentgate-killsuite is the OS-level crash suite of the AgentGate
// revision: it kills and restarts real gateway processes at durable
// transitions, lets the provider misbehave, produces power-loss surrogate
// states on disk, and checks that no operation ID ever gets a second effect
// and that no operation is reported as having no effect while the provider
// holds one. Every evidence folder is verified with the agentgate-verify
// program given by -verify.
//
// Usage:
//
//	agentgate-killsuite run -verify PATH -out DIR [-work DIR] [-reps N]
//	                        [-groups LIST] [-only LIST] [-host-label TEXT]
//	                        [-call-timeout DURATION] [-commit TEXT] [-list]
//	agentgate-killsuite gateway -config FILE   (started by run; not for direct use)
//
// See README.md next to this file for the cells and what each one models.
// Everything is simulated and local: a loopback provider, synthetic payees
// and recipients, per-run keys generated in memory. A process kill on
// Windows (os.Exit, TerminateProcess) models a crash of the gateway process,
// not a power loss: the kernel's file cache survives it.
package main

import (
	"context"
	"crypto/sha256"
	"debug/buildinfo"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"os/signal"
	"path/filepath"
	"runtime"
	"strings"
	"time"
)

const usage = `usage:
  agentgate-killsuite run -verify PATH -out DIR [-work DIR] [-reps N]
                          [-groups LIST] [-only LIST] [-host-label TEXT]
                          [-call-timeout DURATION] [-commit TEXT] [-list]
  agentgate-killsuite gateway -config FILE   (started by run)

run       kills and restarts gateway child processes over the cell matrix and
          writes results.json, results.csv and summary.md into -out
gateway   one gateway child process (the run mode starts it)
`

func main() {
	os.Exit(run(os.Args[1:], os.Stdout, os.Stderr))
}

func run(args []string, stdout, stderr io.Writer) int {
	if len(args) == 0 {
		fmt.Fprint(stderr, usage)
		return 2
	}
	var err error
	switch args[0] {
	case "run":
		err = runSuite(args[1:], stdout, stderr)
	case "gateway":
		if err = runGatewayChild(args[1:], stdout, stderr); err != nil {
			fmt.Fprintf(stderr, "agentgate-killsuite gateway: %v\n", err)
			return startFailureExitCode
		}
		return 0
	case "-h", "-help", "--help", "help":
		fmt.Fprint(stdout, usage)
		return 0
	default:
		err = fmt.Errorf("unknown mode %q", args[0])
	}
	if err != nil {
		if !errors.Is(err, flag.ErrHelp) {
			fmt.Fprintf(stderr, "agentgate-killsuite: %v\n", err)
		}
		return 1
	}
	return 0
}

// suiteOptions are the run mode's flags.
type suiteOptions struct {
	verifyPath  string
	outDir      string
	workDir     string
	reps        int
	groups      string
	only        string
	hostLabel   string
	callTimeout time.Duration
	list        bool
	commit      string
}

func parseSuiteFlags(args []string, stderr io.Writer) (suiteOptions, error) {
	set := flag.NewFlagSet("run", flag.ContinueOnError)
	set.SetOutput(stderr)
	options := suiteOptions{}
	set.StringVar(&options.verifyPath, "verify", "", "path of the agentgate-verify program used on every evidence folder (required)")
	set.StringVar(&options.outDir, "out", "", "directory for results.json, results.csv and summary.md (required)")
	set.StringVar(&options.workDir, "work", "", "directory for the cell folders (default: a new folder under the system temp directory)")
	set.IntVar(&options.reps, "reps", 5, "repetitions of every cell")
	set.StringVar(&options.groups, "groups", "all", "comma-separated cell groups: "+strings.Join(allGroups, ", "))
	set.StringVar(&options.only, "only", "", "comma-separated substrings; run only cells whose name contains one of them")
	set.StringVar(&options.hostLabel, "host-label", "review-host", "host name recorded in the evidence instead of the machine name (empty: the real name)")
	set.DurationVar(&options.callTimeout, "call-timeout", 60*time.Second, "timeout of one MCP or admin call to a gateway child")
	set.BoolVar(&options.list, "list", false, "list the selected cells and exit")
	set.StringVar(&options.commit, "commit", "", "the source commit both binaries were built from, recorded in the build manifest as given (the SHA-256 values stay authoritative)")
	if err := set.Parse(args); err != nil {
		return options, err
	}
	if set.NArg() != 0 {
		return options, fmt.Errorf("unexpected arguments: %v", set.Args())
	}
	if options.list {
		return options, nil
	}
	switch {
	case options.verifyPath == "":
		return options, errors.New("-verify is required (the agentgate-verify program)")
	case options.outDir == "":
		return options, errors.New("-out is required")
	case options.reps < 1:
		return options, errors.New("-reps must be at least 1")
	case options.callTimeout < 15*time.Second:
		// The delayed-delivery cells wait out the adapter's 10 s timeout.
		return options, errors.New("-call-timeout must be at least 15s")
	}
	if _, err := os.Stat(options.verifyPath); err != nil {
		return options, fmt.Errorf("-verify: %w", err)
	}
	return options, nil
}

// environment describes the machine and the command.
type environment struct {
	GoVersion string `json:"go_version"`
	GOOS      string `json:"goos"`
	GOARCH    string `json:"goarch"`
	NumCPU    int    `json:"num_cpu"`
	StartedAt string `json:"started_at"`
	Command   string `json:"command"`
}

// buildManifest names the builds a results.json comes from: this program
// (every gateway child is this same executable, so it carries the gateway
// code) and the verifier given by -verify. Commit is the source commit the
// operator gave with -commit (not checked against the binaries; build with
// -trimpath -buildvcs=false so that anyone can rebuild the same SHA-256 from
// it).
type buildManifest struct {
	Commit          string     `json:"commit,omitempty"`
	SuiteAndGateway binaryInfo `json:"suite_and_gateway"`
	Verifier        binaryInfo `json:"verifier"`
}

// binaryInfo identifies one executable: its SHA-256 and the module and VCS
// stamp the Go toolchain embedded in it (absent when built outside a
// repository or without VCS stamping).
type binaryInfo struct {
	File        string `json:"file"`
	SHA256      string `json:"sha256,omitempty"`
	GoVersion   string `json:"go_version,omitempty"`
	Module      string `json:"module,omitempty"`
	VCSRevision string `json:"vcs_revision,omitempty"`
	VCSTime     string `json:"vcs_time,omitempty"`
	VCSModified string `json:"vcs_modified,omitempty"`
	Error       string `json:"error,omitempty"`
}

func describeBinary(path string) binaryInfo {
	info := binaryInfo{File: filepath.Base(path)}
	file, err := os.Open(path)
	if err != nil {
		info.Error = err.Error()
		return info
	}
	defer file.Close()
	digest := sha256.New()
	if _, err := io.Copy(digest, file); err != nil {
		info.Error = err.Error()
		return info
	}
	info.SHA256 = hex.EncodeToString(digest.Sum(nil))
	build, err := buildinfo.ReadFile(path)
	if err != nil {
		info.Error = "build info: " + err.Error()
		return info
	}
	info.GoVersion, info.Module = build.GoVersion, build.Main.Path
	for _, setting := range build.Settings {
		switch setting.Key {
		case "vcs.revision":
			info.VCSRevision = setting.Value
		case "vcs.time":
			info.VCSTime = setting.Value
		case "vcs.modified":
			info.VCSModified = setting.Value
		}
	}
	return info
}

// line is the one-line description of a binary in summary.md.
func (info binaryInfo) line() string {
	text := "`" + info.File + "`"
	if info.VCSRevision != "" {
		text += " revision " + info.VCSRevision
		if info.VCSModified == "true" {
			text += " (with uncommitted changes)"
		}
	} else {
		text += " (no VCS stamp)"
	}
	if info.SHA256 != "" {
		text += ", SHA-256 " + info.SHA256
	}
	if info.Error != "" {
		text += ", " + info.Error
	}
	return text
}

// suiteResult is results.json.
type suiteResult struct {
	Note        string        `json:"note"`
	Method      []string      `json:"method"`
	Environment environment   `json:"environment"`
	Build       buildManifest `json:"build"`
	Reps        int           `json:"reps"`
	Interrupted bool          `json:"interrupted,omitempty"`
	ElapsedS    float64       `json:"elapsed_s"`
	KillPoints  []killPoint   `json:"kill_points"`
	Totals      totals        `json:"totals"`
	Cells       []cellResult  `json:"cells"`
}

// testHooks lets the package tests run the suite with the test binary as the
// gateway child and as the verifier stand-in.
var testHooks struct {
	childExe    string
	childEnv    []string
	verifierEnv []string
}

func runSuite(args []string, stdout, stderr io.Writer) error {
	options, err := parseSuiteFlags(args, stderr)
	if err != nil {
		return err
	}
	cells, err := selectCells(matrix(), options.groups, options.only)
	if err != nil {
		return err
	}
	if options.list {
		for _, cell := range cells {
			fmt.Fprintf(stdout, "%-58s %s\n", cell.Name, cell.Models)
		}
		return nil
	}
	if err := os.MkdirAll(options.outDir, 0o755); err != nil {
		return err
	}
	workDir := options.workDir
	if workDir == "" {
		workDir = filepath.Join(os.TempDir(), "agentgate-killsuite", time.Now().Format("20060102-150405"))
	}
	if err := os.MkdirAll(workDir, 0o755); err != nil {
		return err
	}
	if absolute, err := filepath.Abs(workDir); err == nil {
		workDir = absolute
	}
	exe := testHooks.childExe
	if exe == "" {
		if exe, err = os.Executable(); err != nil {
			return err
		}
	}
	verifyPath, err := filepath.Abs(options.verifyPath)
	if err != nil {
		return err
	}
	w, err := newWorld()
	if err != nil {
		return err
	}
	s := &suite{
		exe: exe, childEnv: testHooks.childEnv, workDir: workDir, hostLabel: options.hostLabel, callTimeout: options.callTimeout, w: w,
		verifier: verifierCommand{path: verifyPath, extraEnv: testHooks.verifierEnv, timeout: 2 * time.Minute},
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()
	started := time.Now()
	result := suiteResult{
		Note: "OS-level crash runs of the gateway and verifier builds named under build, on one machine, with a simulated provider in the parent process. " +
			"Statuses, provider effects and verifier verdicts are observations of these schedules only, not a proof of crash safety for other schedules; " +
			"a process kill models a gateway crash, not a power loss.",
		Method: []string{
			"Gateway: a separate child process of this program (devcomposition.New, MCP on loopback HTTP, operation journal, one evidence segment written by the signed audit log); the parent talks to it over HTTP only.",
			"Kill: at a devcomposition fault hook or at one of two audit-sink points the child prints its kill point and calls os.Exit(86) (no deferred code, no flush, no close); human pending/approved cells are terminated from outside (TerminateProcess). A reset connection is recorded as no answer.",
			"Pins: the child streams its head after every audit append and its keys.json fingerprint when ready; the parent verifies every folder with these values pinned outside the folder.",
			"Provider: in the parent, with its own key and in-memory state, so it survives every kill; simulator faults keyed by idempotency key, a held dispatch for delayed delivery, HTTP 503 for lookup failures; dispatch requests are counted per operation ID.",
			"Restart: a new child on the same journal; it reads the continuation (run ID, final head, keys fingerprint) from the dead segment's own files (audit.ReadContinuation); the parent first writes the dead segment's provider-journal.json from the provider.",
			"After the retry: the parent asks the child for Composition.Reconcile, closes it gracefully and verifies the newest segment (the verifier follows the chain) and segment 1 alone, with agentgate-verify --json.",
			"Power-loss surrogates: on the folder of a kill after EFFECT_EXECUTED (an untouched copy is kept as as-killed/), using only bytes the gateway wrote; nothing is re-signed.",
		},
		Environment: environment{
			GoVersion: runtime.Version(), GOOS: runtime.GOOS, GOARCH: runtime.GOARCH, NumCPU: runtime.NumCPU(),
			StartedAt: time.Now().UTC().Format(time.RFC3339), Command: "agentgate-killsuite run " + strings.Join(displayArgs(args), " "),
		},
		Build: buildManifest{Commit: options.commit, SuiteAndGateway: describeBinary(exe), Verifier: describeBinary(verifyPath)},
		Reps:  options.reps, KillPoints: killPoints,
	}
	fmt.Fprintf(stdout, "killsuite: %d cells x %d repetitions, work folder %s\n", len(cells), options.reps, workDir)
schedule:
	for rep := 1; rep <= options.reps; rep++ {
		for _, cell := range cells {
			if ctx.Err() != nil {
				// Interrupted: the cells that ran are still written.
				result.Interrupted = true
				break schedule
			}
			res := s.runCell(ctx, cell, rep)
			if ctx.Err() != nil && !res.Interrupted {
				// Ctrl-C arrived after the cell's last interrupt check (during
				// the close and verify step): the children and the verifier
				// share the console and may have died with it, so the cell's
				// last results say nothing about the gateway.
				res.Interrupted = true
				res.Error = strings.TrimPrefix(res.Error+"; "+errInterrupted.Error(), "; ")
			}
			fmt.Fprintf(stdout, "%-56s r%d %6.1fs %s\n", cell.Name, rep, res.ElapsedMS/1000, cellLine(res))
			result.Cells = append(result.Cells, res)
			if res.Interrupted {
				// Kept and marked; its answers say nothing about the gateway.
				result.Interrupted = true
				break schedule
			}
		}
	}
	result.ElapsedS = time.Since(started).Seconds()
	result.Totals = totalsOf(result.Cells)
	// An interrupted run never passes, even when the interrupt fell between
	// two cells and marked none of them.
	result.Totals.AcceptancePassed = result.Totals.AcceptancePassed && !result.Interrupted
	jsonPath, csvPath, mdPath := resultFiles(options.outDir)
	raw, err := json.MarshalIndent(result, "", "  ")
	if err != nil {
		return err
	}
	if err := os.WriteFile(jsonPath, append(raw, '\n'), 0o644); err != nil {
		return err
	}
	if err := os.WriteFile(csvPath, []byte(resultsCSV(result.Cells)), 0o644); err != nil {
		return err
	}
	if err := os.WriteFile(mdPath, []byte(summaryMarkdown(result)), 0o644); err != nil {
		return err
	}
	t := result.Totals
	fmt.Fprintf(stdout, "killsuite: %d cells in %.1f s; duplicates %d, REJECTED with effect %d, not-committed with effect %d, COMMITTED without effect %d, unresolved %d (+%d deliberate, %d undecided), unsettled with a dispatch or effect %d, re-dispatch %d, unknown dispatches %d, kill not reached %d, errors %d; acceptance %s\n",
		t.Cells, result.ElapsedS, t.DuplicateEffects, t.RejectedWithEffectAtAnswer, t.NotCommittedWithEffect, t.CommittedWithoutEffect,
		t.UnresolvedAfterReconcile, t.UnresolvedDeliberate, t.UndecidedAfterReconcile, t.UnsettledWithEffect, t.Redispatches, t.UnknownDispatches, t.KillNotReached, t.CellErrors, yesNo(t.AcceptancePassed))
	fmt.Fprintf(stdout, "killsuite: results in %s\n", options.outDir)
	if result.Interrupted {
		return errors.New("interrupted; the results cover the cells that ran")
	}
	return nil
}

// cellLine is the one-line console summary of a cell.
func cellLine(res cellResult) string {
	s1, _ := segmentVerdict(res, 1)
	s2, _ := segmentVerdict(res, 2)
	line := fmt.Sprintf("%s | effects %d", answerChain(res.Answers), res.Effects[roleOriginal])
	if value, ok := res.Effects[roleFresh]; ok {
		line += fmt.Sprintf("+%d", value)
	}
	line += " | after Reconcile " + res.StateAfterReconcile + " | seg1 " + s1
	if s2 != "" {
		line += " | seg2 " + s2
	}
	if res.FlagPreserved != nil {
		line += " | flag preserved " + yesNo(*res.FlagPreserved)
	}
	if res.RestartBlocked {
		line += " | restart blocked"
	}
	if res.Error != "" {
		line += " | ERROR " + res.Error
	}
	return line
}

// displayArgs replaces absolute paths in the recorded command by their base
// names, so results do not name the machine's folders.
func displayArgs(args []string) []string {
	out := make([]string, len(args))
	for index, arg := range args {
		if filepath.IsAbs(arg) {
			arg = "<path>/" + filepath.Base(arg)
		}
		out[index] = arg
	}
	return out
}
