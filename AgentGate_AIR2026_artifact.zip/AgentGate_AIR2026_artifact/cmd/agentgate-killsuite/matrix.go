package main

// The kill points and the cell matrix.

import (
	"fmt"
	"strings"

	"agentgate/internal/devcomposition"
)

// Sink-level kill points (evidence.go): they fire in the child's audit sink.
const (
	sinkAfterEffectExecuted = "after_effect_executed"
	sinkBeforeCallResult    = "before_call_result"
)

// killPoint is one place where a gateway child dies.
type killPoint struct {
	Name string `json:"name"`
	// Fault is the devcomposition fault hook the child exits at (empty for
	// sink-level and external kills).
	Fault devcomposition.FaultPoint `json:"fault_hook,omitempty"`
	// Sink names a sink-level kill point.
	Sink string `json:"sink_point,omitempty"`
	// External: the parent terminates the child itself (TerminateProcess on
	// Windows) at a moment the gateway has no hook for.
	External bool `json:"external,omitempty"`
	// Models says what is on disk when the process dies.
	Models string `json:"models"`
}

// killPoints in lifecycle order. The head_replace hook fires at the same
// moment as audit_append (before EFFECT_EXECUTED is appended), so killing
// there leaves the same state and is not a separate point; a kill inside
// audit.Append (between the line fsync and the head rename) has no hook and is
// covered by the head_reverted power-loss surrogate.
var killPoints = []killPoint{
	{Name: "before_consume", Fault: devcomposition.FaultBeforeCapabilityConsume,
		Models: "capability issued and journaled, not consumed; no dispatch intent; nothing sent"},
	{Name: "after_consume", Fault: devcomposition.FaultAfterCapabilityConsume,
		Models: "capability consumed (journaled), dispatch intent not yet journaled; no request byte sent"},
	{Name: "after_provider_response", Fault: devcomposition.FaultProviderResponseLost,
		Models: "dispatch intent journaled, provider committed and answered; the gateway dies before it reads the answer"},
	{Name: "after_receipt", Fault: devcomposition.FaultAfterReceiptBeforeAudit,
		Models: "provider and effect receipts verified and signed (provider_outcome journaled), EFFECT_EXECUTED not appended"},
	{Name: "before_effect_executed", Fault: devcomposition.FaultAuditAppend,
		Models: "as after_receipt, at the EFFECT_EXECUTED append itself (the audit_append hook)"},
	{Name: sinkAfterEffectExecuted, Sink: sinkAfterEffectExecuted,
		Models: "EFFECT_EXECUTED appended and the head replaced; the journal's 'recorded' record not written"},
	{Name: sinkBeforeCallResult, Sink: sinkBeforeCallResult,
		Models: "'recorded' journaled (stored answer); CALL_RESULT not appended; the agent gets no answer"},
	{Name: "pending", External: true,
		Models: "human path: approval challenge answered PENDING, no decision yet; the parent terminates the process"},
	{Name: "approved", External: true,
		Models: "human path: the approver approved, the agent has not resumed yet; the parent terminates the process"},
}

func lookupKillPoint(name string) (killPoint, bool) {
	for _, point := range killPoints {
		if point.Name == name {
			return point, true
		}
	}
	return killPoint{}, false
}

// gatewayKillPoints are the seven points crossed with the ALLOW payment and
// the FLAG message.
func gatewayKillPoints() []killPoint {
	var out []killPoint
	for _, point := range killPoints {
		if !point.External {
			out = append(out, point)
		}
	}
	return out
}

// Cell groups.
const (
	groupKill      = "kill"
	groupHuman     = "human"
	groupProvider  = "provider"
	groupSurrogate = "surrogate"
	groupJournal   = "journal"
	groupReplay    = "replay"
)

var allGroups = []string{groupKill, groupHuman, groupProvider, groupSurrogate, groupJournal, groupReplay}

// sameProcessRetries is the number of exact retries the replay cell sends to
// the gateway that committed the operation, before its restart.
const sameProcessRetries = 2

// Paths (the operation a cell drives).
const (
	pathAllowPayment = "allow-payment" // flag mode, 400.00 AED to an in-grant payee: allowed, not flagged
	pathFlagMessage  = "flag-message"  // flag mode, message to an external partner: allowed and flagged
	pathHumanPayment = "human-payment" // human mode, 12,400.00 AED: needs an approval
)

// Provider faults (group provider).
const (
	faultLostResponse         = "lost_response"        // DROP_AFTER_COMMIT
	faultCertifiedNoEffect    = "certified_no_effect"  // DROP_BEFORE_COMMIT, then a signed ABSENT
	faultUnknownThenApplied   = "unknown_then_applied" // DROP_AFTER_COMMIT, a signed UNKNOWN, then APPLIED
	faultDelayedBeforeLookup  = "delayed_release_before_lookup"
	faultDelayedAfterAbsent   = "delayed_release_after_absent"
	faultLookupFailure        = "lookup_failure_3" // DROP_AFTER_COMMIT, 3 lookups answered 503, then resolved
	faultLookupFailurePersist = "lookup_failure_persistent"
)

// lookupFailures is k of the lookup-failure cell.
const lookupFailures = 3

// Power-loss surrogates (group surrogate), applied to a copy of a folder
// killed after EFFECT_EXECUTED.
const (
	surrogateTornJournal  = "torn_journal_tail"
	surrogateTornAudit    = "torn_audit_tail"
	surrogateHeadReverted = "head_reverted"
	surrogateTempHead     = "temp_head_left"
)

// cellSpec is one cell of the matrix.
type cellSpec struct {
	Name      string `json:"name"`
	Group     string `json:"group"`
	Path      string `json:"path"`
	Kill      string `json:"kill_point,omitempty"`
	Retry     string `json:"retry"` // same-id | fresh-id
	Fault     string `json:"provider_fault,omitempty"`
	Surrogate string `json:"surrogate,omitempty"`
	// Retries is the number of exact retries after the first call (provider
	// cells; kill cells retry once after the restart).
	Retries int `json:"retries,omitempty"`
	// Deliberate: an operation left unresolved after Reconcile is the point
	// of the cell (lookup failure that never ends, a refused restart).
	Deliberate bool `json:"deliberate_unresolved,omitempty"`
	// ExpectFirst is the status the first answer must have when the cell's
	// provider fault or journal failure fired (provider and journal cells).
	// A different first answer means the fault never happened, and the cell
	// fails instead of passing as a fault-free run.
	ExpectFirst string `json:"expect_first_status,omitempty"`
	Models      string `json:"models"`
}

// matrix returns the full cell list of one repetition.
func matrix() []cellSpec {
	var cells []cellSpec
	for _, point := range gatewayKillPoints() {
		for _, path := range []string{pathAllowPayment, pathFlagMessage} {
			cells = append(cells, cellSpec{
				Name: fmt.Sprintf("kill/%s/%s/same-id", point.Name, path), Group: groupKill, Path: path, Kill: point.Name, Retry: "same-id",
				Retries: 1, Models: "process crash: " + point.Models + "; restart from disk, exact retry",
			})
		}
		cells = append(cells, cellSpec{
			Name: fmt.Sprintf("kill/%s/%s/fresh-id", point.Name, pathAllowPayment), Group: groupKill, Path: pathAllowPayment, Kill: point.Name, Retry: "fresh-id",
			Retries: 1, Models: "control: as the same-id cell, but the agent retries with a fresh operation ID for identical content (one effect per operation ID, not per intent)",
		})
	}
	for _, name := range []string{"pending", "approved", "after_consume", "after_receipt"} {
		point, _ := lookupKillPoint(name)
		cells = append(cells, cellSpec{
			Name: "human/" + name, Group: groupHuman, Path: pathHumanPayment, Kill: name, Retry: "same-id", Retries: 1,
			Models: "process crash on the human path: " + point.Models + "; restart from disk, exact retry (approved again if challenged)",
		})
	}
	provider := []cellSpec{
		{Fault: faultLostResponse, Retries: 1, Models: "provider committed, its response was lost (DROP_AFTER_COMMIT); the exact retry reconciles"},
		{Fault: faultCertifiedNoEffect, Retries: 1, Models: "provider dropped the request before committing (DROP_BEFORE_COMMIT); the retry's lookup draws a signed ABSENT (tombstone): certified no-effect"},
		{Fault: faultUnknownThenApplied, Retries: 2, Models: "lost response, then a signed UNKNOWN status (STATUS_UNKNOWN), then APPLIED on the next lookup"},
		{Fault: faultDelayedBeforeLookup, Retries: 1, Models: "the dispatch is held past the gateway's 10 s response timeout and delivered (commits) before the retry's lookup: APPLIED"},
		{Fault: faultDelayedAfterAbsent, Retries: 2, Models: "the dispatch is held past the timeout; the retry draws a signed ABSENT first; the late delivery must then be refused by the tombstone"},
		{Fault: faultLookupFailure, Retries: lookupFailures, Models: fmt.Sprintf("lost response, then %d status lookups answered HTTP 503: UNCERTAIN, never re-dispatched; Reconcile resolves it", lookupFailures)},
		{Fault: faultLookupFailurePersist, Retries: 2, Deliberate: true, Models: "lost response and every status lookup answered HTTP 503: stays UNCERTAIN after Reconcile, never re-dispatched"},
	}
	// Every provider fault leaves the first call without a known outcome: a
	// first answer other than UNCERTAIN means the fault did not fire.
	uncertain := string(devcomposition.StatusUncertain)
	for _, cell := range provider {
		cell.Name, cell.Group, cell.Path, cell.Retry = "provider/"+cell.Fault+"/"+pathAllowPayment, groupProvider, pathAllowPayment, "same-id"
		cell.ExpectFirst = uncertain
		cells = append(cells, cell)
	}
	cells = append(cells, cellSpec{
		Name: "provider/" + faultLostResponse + "/" + pathFlagMessage, Group: groupProvider, Path: pathFlagMessage, Retry: "same-id",
		Fault: faultLostResponse, Retries: 1, ExpectFirst: uncertain, Models: "lost response on the flagged path; the reconciled answer must stay flagged",
	})
	surrogates := []cellSpec{
		{Surrogate: surrogateTornJournal, Models: "power-loss surrogate: a torn final line in operations.jsonl (a record that was being written); the journal discards it and the restart proceeds"},
		{Surrogate: surrogateTornAudit, Deliberate: true, Models: "power-loss surrogate: a torn final line in audit.jsonl (an entry that was being written); the continuation cannot be read, so the restart is refused (fail closed)"},
		{Surrogate: surrogateHeadReverted, Models: "power-loss surrogate: head.json replaced by the previous genuine head (the line was synced, the head rename did not reach the disk)"},
		{Surrogate: surrogateTempHead, Models: "power-loss surrogate: a leftover .head.json.tmp-* file next to an intact head (a crash inside the atomic head replacement)"},
	}
	for _, cell := range surrogates {
		cell.Name, cell.Group, cell.Path, cell.Kill, cell.Retry, cell.Retries = "surrogate/"+cell.Surrogate, groupSurrogate, pathAllowPayment, sinkAfterEffectExecuted, "same-id", 1
		cells = append(cells, cell)
	}
	cells = append(cells, cellSpec{
		Name: "journal/read_only_at_consume", Group: groupJournal, Path: pathAllowPayment, Retry: "same-id", Retries: 1,
		ExpectFirst: string(devcomposition.StatusRejected),
		Models:      "one journal write failure: the journal file is made read-only right after the capability was consumed, so the dispatch-intent write fails; after a graceful close the attribute is cleared and the gateway restarted",
	})
	cells = append(cells, cellSpec{
		Name: "replay/" + pathFlagMessage + "/same-process", Group: groupReplay, Path: pathFlagMessage, Retry: "same-id", Retries: sameProcessRetries + 1,
		Models: fmt.Sprintf("no fault: the flagged message commits, then %d exact retries in the same process are answered with the stored result, and after a graceful restart one more from the journal; every replayed answer must keep the flag", sameProcessRetries),
	})
	return cells
}

// selectCells filters the matrix by group and by name substrings (both
// optional; an empty selection is an error).
func selectCells(cells []cellSpec, groups, only string) ([]cellSpec, error) {
	wantGroups := map[string]bool{}
	if strings.TrimSpace(groups) != "" && strings.TrimSpace(groups) != "all" {
		for _, part := range strings.Split(groups, ",") {
			name := strings.TrimSpace(part)
			if name == "" {
				continue
			}
			known := false
			for _, group := range allGroups {
				known = known || group == name
			}
			if !known {
				return nil, fmt.Errorf("unknown group %q (known: %s)", name, strings.Join(allGroups, ", "))
			}
			wantGroups[name] = true
		}
	}
	var substrings []string
	for _, part := range strings.Split(only, ",") {
		if part = strings.TrimSpace(part); part != "" {
			substrings = append(substrings, part)
		}
	}
	var out []cellSpec
	for _, cell := range cells {
		if len(wantGroups) > 0 && !wantGroups[cell.Group] {
			continue
		}
		if len(substrings) > 0 {
			matched := false
			for _, part := range substrings {
				matched = matched || strings.Contains(cell.Name, part)
			}
			if !matched {
				continue
			}
		}
		out = append(out, cell)
	}
	if len(out) == 0 {
		return nil, fmt.Errorf("no cell matches -groups %q -only %q", groups, only)
	}
	return out, nil
}
