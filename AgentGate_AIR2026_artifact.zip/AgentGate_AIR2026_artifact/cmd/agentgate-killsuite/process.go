package main

// The parent's side of a gateway child: the process, its protocol lines, its
// MCP endpoint and its admin calls.

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"strings"
	"sync"
	"time"

	"agentgate/internal/mcp"
)

// headPin is a head the parent holds outside the folder.
type headPin struct {
	Seq  uint64 `json:"seq"`
	Hash string `json:"hash"`
	File []byte `json:"-"` // head.json bytes as the child wrote them
}

type childProc struct {
	cmd    *exec.Cmd
	stderr *os.File

	readyCh chan struct{}
	exited  chan struct{}

	mu        sync.Mutex
	ready     *childMessage
	head      headPin
	prevHead  headPin // the genuine head before head
	killed    *childMessage
	closed    *childMessage
	startErr  string
	readOnly  bool
	exitCode  int
	waitError error
}

// startChild starts exe with args and env. stderr goes to stderrPath.
func startChild(exe string, args, env []string, stderrPath string) (*childProc, error) {
	stderr, err := os.Create(stderrPath)
	if err != nil {
		return nil, err
	}
	cmd := exec.Command(exe, args...)
	cmd.Env = env
	cmd.Stderr = stderr
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		stderr.Close()
		return nil, err
	}
	if err := cmd.Start(); err != nil {
		stderr.Close()
		return nil, err
	}
	child := &childProc{cmd: cmd, stderr: stderr, readyCh: make(chan struct{}), exited: make(chan struct{}), exitCode: -1}
	go func() {
		// All reads from the pipe must finish before Wait (os/exec).
		child.readLines(stdout)
		err := cmd.Wait()
		child.mu.Lock()
		child.waitError = err
		if cmd.ProcessState != nil {
			child.exitCode = cmd.ProcessState.ExitCode()
		}
		child.mu.Unlock()
		stderr.Close()
		close(child.exited)
	}()
	return child, nil
}

func (c *childProc) readLines(stdout io.Reader) {
	scanner := bufio.NewScanner(stdout)
	scanner.Buffer(make([]byte, 64<<10), 4<<20)
	readyClosed := false
	for scanner.Scan() {
		line := scanner.Text()
		if !strings.HasPrefix(line, protocolPrefix) {
			continue
		}
		var message childMessage
		if err := json.Unmarshal([]byte(strings.TrimPrefix(line, protocolPrefix)), &message); err != nil {
			continue
		}
		c.mu.Lock()
		switch message.Event {
		case "ready":
			copied := message
			c.ready = &copied
			if !readyClosed {
				close(c.readyCh)
				readyClosed = true
			}
		case "head":
			c.prevHead, c.head = c.head, headPin{Seq: message.Seq, Hash: message.Hash, File: message.HeadFile}
		case "kill":
			copied := message
			c.killed = &copied
		case "closed":
			copied := message
			c.closed = &copied
		case "journal_read_only":
			c.readOnly = message.Error == ""
		case "error":
			c.startErr = message.Error
		}
		c.mu.Unlock()
	}
	_, _ = io.Copy(io.Discard, stdout)
}

// waitReady waits for the ready line; a child that exits first failed to
// start and its error line is returned.
func (c *childProc) waitReady(timeout time.Duration) (childMessage, error) {
	select {
	case <-c.readyCh:
		c.mu.Lock()
		defer c.mu.Unlock()
		return *c.ready, nil
	case <-c.exited:
		c.mu.Lock()
		defer c.mu.Unlock()
		if c.ready != nil {
			return *c.ready, nil
		}
		if c.startErr != "" {
			return childMessage{}, fmt.Errorf("gateway child exited with code %d: %s", c.exitCode, c.startErr)
		}
		return childMessage{}, fmt.Errorf("gateway child exited with code %d before it was ready", c.exitCode)
	case <-time.After(timeout):
		c.terminate(5 * time.Second)
		return childMessage{}, fmt.Errorf("gateway child not ready within %s", timeout)
	}
}

// waitExit waits for the process to end and returns its exit code; after the
// timeout it terminates the process.
func (c *childProc) waitExit(timeout time.Duration) (int, error) {
	select {
	case <-c.exited:
	case <-time.After(timeout):
		c.terminate(5 * time.Second)
		return c.code(), fmt.Errorf("gateway child did not exit within %s and was terminated", timeout)
	}
	return c.code(), nil
}

// terminate ends the process at once (TerminateProcess on Windows) and waits
// for it.
func (c *childProc) terminate(timeout time.Duration) {
	if c.cmd.Process != nil {
		_ = c.cmd.Process.Kill()
	}
	select {
	case <-c.exited:
	case <-time.After(timeout):
	}
}

func (c *childProc) code() int {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.exitCode
}

// pins returns the latest streamed head and the one before it.
func (c *childProc) pins() (headPin, headPin) {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.head, c.prevHead
}

func (c *childProc) killMessage() *childMessage {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.killed
}

func (c *childProc) journalMadeReadOnly() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.readOnly
}

// --- the MCP client ---------------------------------------------------------------

type mcpClient struct {
	url    string
	bearer string
	client *http.Client
}

func newMCPClient(url, bearer string, timeout time.Duration) *mcpClient {
	// No keep-alive: a dead child must not leave a reusable connection.
	return &mcpClient{url: url, bearer: bearer, client: &http.Client{Timeout: timeout, Transport: &http.Transport{DisableKeepAlives: true}}}
}

// callResult is what the agent saw for one tools/call.
type callResult struct {
	HTTPStatus int    `json:"http_status,omitempty"`
	NoAnswer   bool   `json:"no_answer,omitempty"` // the connection ended without a response (the gateway died)
	Error      string `json:"error,omitempty"`
	Status     string `json:"status,omitempty"`
	Reason     string `json:"reason,omitempty"`
	Dispatched bool   `json:"dispatched,omitempty"`
	// Flagged is structuredContent.flagged; FlagReported says whether the
	// answer carries that member at all (the gateway may not report the flag
	// to the agent).
	Flagged      bool `json:"flagged,omitempty"`
	FlagReported bool `json:"flag_reported,omitempty"`
	// RequestState and ApprovalURL are set for an approval challenge.
	RequestState string `json:"-"`
	ApprovalURL  string `json:"-"`
	Challenge    bool   `json:"challenge,omitempty"`
}

func (r callResult) key() string {
	switch {
	case r.NoAnswer:
		return "NO_ANSWER"
	case r.Status == "":
		return "ERROR"
	}
	return r.Status + "/" + r.Reason
}

func toolCallBody(tool string, arguments map[string]any, elicitation bool, requestState string) ([]byte, error) {
	capabilities := map[string]any{}
	if elicitation {
		capabilities["elicitation"] = map[string]any{}
	}
	params := map[string]any{
		"name": tool, "arguments": arguments,
		"_meta": map[string]any{
			"io.modelcontextprotocol/protocolVersion":    mcp.ProtocolVersion,
			"io.modelcontextprotocol/clientCapabilities": capabilities,
			"io.modelcontextprotocol/clientInfo":         map[string]any{"name": "agentgate-killsuite", "version": "1"},
		},
	}
	if requestState != "" {
		params["requestState"] = requestState
		params["inputResponses"] = map[string]any{"approval": map[string]any{"action": "accept"}}
	}
	return json.Marshal(map[string]any{"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": params})
}

func setToolHeaders(header http.Header, tool, bearer string) {
	header.Set("Content-Type", "application/json")
	header.Set("Accept", "application/json, text/event-stream")
	header.Set("MCP-Protocol-Version", mcp.ProtocolVersion)
	header.Set("Mcp-Method", "tools/call")
	header.Set("Mcp-Name", tool)
	header.Set("Authorization", "Bearer "+bearer)
}

func (c *mcpClient) call(ctx context.Context, tool string, arguments map[string]any, elicitation bool, requestState string) callResult {
	body, err := toolCallBody(tool, arguments, elicitation, requestState)
	if err != nil {
		return callResult{Error: "encode: " + err.Error()}
	}
	request, err := http.NewRequestWithContext(ctx, http.MethodPost, c.url, bytes.NewReader(body))
	if err != nil {
		return callResult{Error: err.Error()}
	}
	setToolHeaders(request.Header, tool, c.bearer)
	response, err := c.client.Do(request)
	if err != nil {
		// A reset or closed connection: the gateway gave no answer.
		return callResult{NoAnswer: true, Error: "transport: " + err.Error()}
	}
	defer response.Body.Close()
	raw, err := io.ReadAll(io.LimitReader(response.Body, 8<<20))
	if err != nil {
		return callResult{NoAnswer: true, HTTPStatus: response.StatusCode, Error: "read: " + err.Error()}
	}
	return parseCallResponse(response.StatusCode, raw)
}

func parseCallResponse(status int, body []byte) callResult {
	result := callResult{HTTPStatus: status}
	if status != http.StatusOK {
		result.Error = fmt.Sprintf("HTTP %d: %s", status, strings.TrimSpace(string(body)))
		return result
	}
	var rpc struct {
		Error *struct {
			Code    int64  `json:"code"`
			Message string `json:"message"`
		} `json:"error"`
		Result map[string]any `json:"result"`
	}
	if err := json.Unmarshal(body, &rpc); err != nil {
		result.Error = "decode: " + err.Error()
		return result
	}
	if rpc.Error != nil {
		result.Error = fmt.Sprintf("JSON-RPC %d: %s", rpc.Error.Code, rpc.Error.Message)
		return result
	}
	structured, _ := rpc.Result["structuredContent"].(map[string]any)
	result.Status, _ = structured["status"].(string)
	result.Reason, _ = structured["reason"].(string)
	result.Dispatched, _ = structured["dispatched"].(bool)
	_, result.FlagReported = structured["flagged"]
	result.Flagged, _ = structured["flagged"].(bool)
	if state, _ := rpc.Result["requestState"].(string); state != "" {
		result.RequestState, result.Challenge = state, true
		requests, _ := rpc.Result["inputRequests"].(map[string]any)
		approval, _ := requests["approval"].(map[string]any)
		params, _ := approval["params"].(map[string]any)
		result.ApprovalURL, _ = params["url"].(string)
	}
	if result.Status == "" && !result.Challenge {
		result.Error = "no structuredContent.status"
	}
	return result
}

// --- the admin client ---------------------------------------------------------------

type adminClient struct {
	base   string
	token  string
	client *http.Client
}

func newAdminClient(base, token string, timeout time.Duration) *adminClient {
	return &adminClient{base: base, token: token, client: &http.Client{Timeout: timeout, Transport: &http.Transport{DisableKeepAlives: true}}}
}

func (a *adminClient) do(ctx context.Context, method, path string, body any, out any) error {
	var reader io.Reader
	if body != nil {
		raw, err := json.Marshal(body)
		if err != nil {
			return err
		}
		reader = bytes.NewReader(raw)
	}
	request, err := http.NewRequestWithContext(ctx, method, a.base+path, reader)
	if err != nil {
		return err
	}
	request.Header.Set("Authorization", "Bearer "+a.token)
	if body != nil {
		request.Header.Set("Content-Type", "application/json")
	}
	response, err := a.client.Do(request)
	if err != nil {
		return err
	}
	defer response.Body.Close()
	raw, err := io.ReadAll(io.LimitReader(response.Body, 8<<20))
	if err != nil {
		return err
	}
	if response.StatusCode != http.StatusOK {
		return fmt.Errorf("admin %s: HTTP %d: %s", path, response.StatusCode, strings.TrimSpace(string(raw)))
	}
	if out == nil {
		return nil
	}
	return json.Unmarshal(raw, out)
}

func (a *adminClient) operations(ctx context.Context) (adminStates, error) {
	var states adminStates
	err := a.do(ctx, http.MethodGet, "/operations", nil, &states)
	return states, err
}

func (a *adminClient) reconcile(ctx context.Context) (adminStates, error) {
	var states adminStates
	err := a.do(ctx, http.MethodPost, "/reconcile", map[string]any{}, &states)
	if err == nil && states.Error != "" {
		err = errors.New(states.Error)
	}
	return states, err
}

func (a *adminClient) approve(ctx context.Context, url string) error {
	return a.do(ctx, http.MethodPost, "/approve", map[string]string{"url": url}, nil)
}

func (a *adminClient) close(ctx context.Context) (headPin, error) {
	var answer struct {
		Seq   uint64 `json:"seq"`
		Hash  string `json:"hash"`
		Error string `json:"error"`
	}
	err := a.do(ctx, http.MethodPost, "/close", map[string]any{}, &answer)
	if err == nil && answer.Error != "" {
		err = errors.New(answer.Error)
	}
	return headPin{Seq: answer.Seq, Hash: answer.Hash}, err
}
