package main

// The provider host runs in the parent ("run" mode), so it outlives every
// gateway child the suite kills. It is the simulated provider
// (internal/simulator) with its own key and in-memory state behind its own
// loopback listener, speaking the provider-process protocol of
// cmd/agentgate-provider (GET /key, GET /journal, the simulator endpoints),
// as in cmd/agentgate-eval/harness.go. On top of that it can
//
//   - inject the simulator's own faults, keyed by idempotency key
//     (DROP_BEFORE_COMMIT, DROP_AFTER_COMMIT, STATUS_UNKNOWN);
//   - hold the first dispatch request until the cell releases it (delayed
//     delivery: the gateway's adapter gives up after its 10 s response
//     header timeout, internal/adapters/http_transport.go);
//   - answer the first k status lookups with HTTP 503 (lookup failure); and
//   - count the dispatch requests it received per operation ID, so a cell can
//     assert that nothing was dispatched twice (a request without the header,
//     or with an ID that is none of the cell's operations, is counted under
//     its header value and fails the cell).
//
// The provider itself never crashes in this suite: its state is in memory.

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"agentgate/internal/devcomposition"
	"agentgate/internal/signed"
	"agentgate/internal/simulator"
)

// simClock is the simulator's trusted clock (wall seconds, strictly advancing
// generation).
type simClock struct{ generation atomic.Uint64 }

func (clock *simClock) ReadClock() (simulator.ClockReading, error) {
	return simulator.ClockReading{UnixSeconds: uint64(time.Now().Unix()), Generation: clock.generation.Add(1)}, nil
}

var providerReceiptProfile = signed.Profile{
	ContentType: "application/agentgate-provider-receipt+cbor", Token: "SimulatorReceipt", Role: "SIMULATOR_PROVIDER",
}

// providerBehavior configures one cell's provider.
type providerBehavior struct {
	// Faults are the simulator's fault queues, keyed by idempotency key hash.
	Faults map[[32]byte][]simulator.Fault
	// HoldFirstDispatch holds the first dispatch request until Release.
	HoldFirstDispatch bool
	// FailStatus answers the first FailStatus status lookups with HTTP 503;
	// a negative value fails every lookup.
	FailStatus int
}

type providerHost struct {
	run     runIdentity
	origin  string
	kid     [32]byte
	public  ed25519.PublicKey
	runtime *simulator.Runtime
	server  *http.Server
	done    chan error

	mu             sync.Mutex
	dispatches     map[string]int // dispatch requests per operation ID (X-Agentgate-Operation-Id)
	statusRequests int
	statusFailed   int
	failStatus     int
	hold           *heldDispatch
}

// heldDispatch is the one dispatch request a delayed-delivery cell holds.
type heldDispatch struct {
	held     chan struct{} // closed when the request arrived and is being held
	release  chan struct{} // closed by Release
	served   chan struct{} // closed when the simulator has answered it
	once     sync.Once
	released sync.Once
	status   int // the simulator's HTTP status for the released request
}

func startProviderHost(w *world, run runIdentity, behavior providerBehavior) (*providerHost, error) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return nil, err
	}
	public, private, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		listener.Close()
		return nil, err
	}
	kid, err := simulator.ProviderKID(public)
	if err != nil {
		listener.Close()
		return nil, err
	}
	runtime, err := simulator.New(simulator.Config{
		Environment: simulator.EnvironmentDEV, RunID: run.ID, TaskID: worldTask,
		TenantID: worldTenant, PrincipalID: worldPrincipal,
		RegistrySnapshotObjectHash: w.registry, InitialStateObjectHash: run.InitialState,
		Signer: signed.Signer{KID: kid, Role: "SIMULATOR_PROVIDER", Private: private}, Clock: &simClock{},
		Faults: behavior.Faults,
	})
	if err != nil {
		listener.Close()
		return nil, err
	}
	handler, err := simulator.NewHandler(runtime, simulator.HandlerConfig{AllowedHost: listener.Addr().String()})
	if err != nil {
		listener.Close()
		return nil, err
	}
	host := &providerHost{
		run: run, origin: "http://" + listener.Addr().String(), kid: kid, public: public, runtime: runtime,
		done: make(chan error, 1), dispatches: map[string]int{}, failStatus: behavior.FailStatus,
	}
	if behavior.HoldFirstDispatch {
		host.hold = &heldDispatch{held: make(chan struct{}), release: make(chan struct{}), served: make(chan struct{})}
	}
	keyDocument := devcomposition.ProviderKeyDocument{
		Format: providerKeyFormat, Role: "SIMULATOR_PROVIDER", Alg: "Ed25519",
		KID: hex.EncodeToString(kid[:]), PublicKey: base64.StdEncoding.EncodeToString(public),
		Run: devcomposition.ProviderRunSummary{
			RunID: hex.EncodeToString(run.ID[:]), RunLabel: run.Label, SimulatorID: simulator.SimulatorID,
			TaskID: worldTask, TenantID: worldTenant, PrincipalID: worldPrincipal,
			RegistrySnapshotObjectHash: hex.EncodeToString(w.registry[:]),
			InitialStateObjectHash:     hex.EncodeToString(run.InitialState[:]),
		},
	}
	mux := http.NewServeMux()
	mux.HandleFunc("GET /key", func(writer http.ResponseWriter, _ *http.Request) {
		writer.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(writer).Encode(keyDocument)
	})
	mux.HandleFunc("GET /journal", func(writer http.ResponseWriter, _ *http.Request) {
		document, err := host.journalDocument(run.Label)
		if err != nil {
			http.Error(writer, err.Error(), http.StatusInternalServerError)
			return
		}
		writer.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(writer).Encode(document)
	})
	mux.Handle("POST /", http.HandlerFunc(func(writer http.ResponseWriter, request *http.Request) {
		host.serveProvider(handler, writer, request)
	}))
	host.server = &http.Server{Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	go func() { host.done <- host.server.Serve(listener) }()
	return host, nil
}

// isStatusPath reports a status lookup (".../status"); its receipt query
// (".../status/receipt") is not counted as a lookup.
func isStatusPath(path string) bool { return strings.HasSuffix(path, "/status") }

func isReceiptPath(path string) bool { return strings.HasSuffix(path, "/status/receipt") }

func (p *providerHost) serveProvider(handler http.Handler, writer http.ResponseWriter, request *http.Request) {
	path := request.URL.Path
	switch {
	case isStatusPath(path):
		p.mu.Lock()
		p.statusRequests++
		fail := p.failStatus < 0 || p.statusFailed < p.failStatus
		if fail {
			p.statusFailed++
		}
		p.mu.Unlock()
		if fail {
			http.Error(writer, "status lookup unavailable (injected by the kill suite)", http.StatusServiceUnavailable)
			return
		}
	case isReceiptPath(path):
	default:
		p.mu.Lock()
		p.dispatches[request.Header.Get("X-Agentgate-Operation-Id")]++
		hold := p.hold
		p.mu.Unlock()
		if hold != nil {
			first := false
			hold.once.Do(func() { first = true })
			if first {
				p.serveHeld(handler, hold, writer, request)
				return
			}
		}
	}
	handler.ServeHTTP(writer, request)
}

// serveHeld reads the request, signals that it is held, waits for Release
// and then hands an identical request to the simulator. The gateway has given
// up on the connection by then, so the simulator's answer goes to a recorder
// and is copied to the (probably closed) connection afterwards. The released
// request runs under a fresh context: the original one ended with the
// gateway's connection.
func (p *providerHost) serveHeld(handler http.Handler, hold *heldDispatch, writer http.ResponseWriter, request *http.Request) {
	body, err := io.ReadAll(io.LimitReader(request.Body, 64<<20))
	close(hold.held)
	<-hold.release
	defer close(hold.served)
	if err != nil {
		hold.status = http.StatusBadRequest
		return
	}
	replay := request.Clone(context.Background())
	replay.Body = io.NopCloser(bytes.NewReader(body))
	replay.ContentLength = int64(len(body))
	recorder := httptest.NewRecorder()
	handler.ServeHTTP(recorder, replay)
	hold.status = recorder.Code
	for name, values := range recorder.Header() {
		writer.Header()[name] = values
	}
	writer.WriteHeader(recorder.Code)
	_, _ = writer.Write(recorder.Body.Bytes())
}

// waitHeld waits until the held dispatch arrived.
func (p *providerHost) waitHeld(timeout time.Duration) error {
	if p.hold == nil {
		return fmt.Errorf("this provider holds no dispatch")
	}
	select {
	case <-p.hold.held:
		return nil
	case <-time.After(timeout):
		return fmt.Errorf("no dispatch arrived within %s", timeout)
	}
}

// releaseHeld releases the held dispatch and waits until the simulator has
// answered it; it returns the simulator's HTTP status.
func (p *providerHost) releaseHeld(timeout time.Duration) (int, error) {
	if p.hold == nil {
		return 0, fmt.Errorf("this provider holds no dispatch")
	}
	p.hold.released.Do(func() { close(p.hold.release) })
	select {
	case <-p.hold.served:
		return p.hold.status, nil
	case <-time.After(timeout):
		return 0, fmt.Errorf("the released dispatch was not answered within %s", timeout)
	}
}

func (p *providerHost) close() {
	if p == nil || p.server == nil {
		return
	}
	if p.hold != nil {
		// Never leave a held handler blocked behind a shutdown.
		p.hold.released.Do(func() { close(p.hold.release) })
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	_ = p.server.Shutdown(ctx)
	<-p.done
	p.server = nil
}

// dispatchCounts returns the dispatch requests per operation ID so far.
func (p *providerHost) dispatchCounts() map[string]int {
	p.mu.Lock()
	defer p.mu.Unlock()
	out := make(map[string]int, len(p.dispatches))
	for id, count := range p.dispatches {
		out[id] = count
	}
	return out
}

func (p *providerHost) statusCounts() (requests, failed int) {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.statusRequests, p.statusFailed
}

// providerJournalDocument is provider-journal.json (CONTRACTS section 5.5).
type providerJournalDocument struct {
	Format      string                 `json:"format"`
	RunID       string                 `json:"run_id"`
	SimulatorID string                 `json:"simulator_id"`
	CommitSeq   uint64                 `json:"commit_seq"`
	StateHash   string                 `json:"state_hash"`
	Entries     []providerJournalEntry `json:"entries"`
}

type providerJournalEntry struct {
	CommitSeq     uint64 `json:"commit_seq"`
	SignedReceipt string `json:"signed_receipt"`
}

func (p *providerHost) journalDocument(runLabel string) (providerJournalDocument, error) {
	snapshot, err := p.runtime.Snapshot()
	if err != nil {
		return providerJournalDocument{}, err
	}
	document := providerJournalDocument{
		Format: providerJournalFormat, RunID: runLabel, SimulatorID: snapshot.SimulatorID,
		CommitSeq: snapshot.CurrentCommitSeq, StateHash: hex.EncodeToString(snapshot.CanonicalStateHash[:]),
		Entries: []providerJournalEntry{},
	}
	sequences := make([]uint64, 0, len(snapshot.Journal))
	for sequence := range snapshot.Journal {
		sequences = append(sequences, sequence)
	}
	sort.Slice(sequences, func(left, right int) bool { return sequences[left] < sequences[right] })
	for _, sequence := range sequences {
		document.Entries = append(document.Entries, providerJournalEntry{CommitSeq: sequence, SignedReceipt: base64.StdEncoding.EncodeToString(snapshot.Journal[sequence])})
	}
	return document, nil
}

type singleKey struct {
	kid    [32]byte
	public ed25519.PublicKey
	role   string
}

func (key singleKey) Resolve(kid [32]byte, role string, _ uint64) (ed25519.PublicKey, bool) {
	if kid != key.kid || role != key.role {
		return nil, false
	}
	return key.public, true
}

// commitsByOperation counts the effects the provider committed per operation
// ID, from its own signed journal (every receipt verified under the provider
// key).
func (p *providerHost) commitsByOperation() (map[string]int, error) {
	snapshot, err := p.runtime.Snapshot()
	if err != nil {
		return nil, err
	}
	resolver := singleKey{kid: p.kid, public: p.public, role: providerReceiptProfile.Role}
	out := map[string]int{}
	for sequence, envelope := range snapshot.Journal {
		var receipt simulator.SimulatorReceipt
		if _, err := signed.Verify(envelope, providerReceiptProfile, resolver, 0, &receipt); err != nil {
			return nil, fmt.Errorf("provider journal entry %d: %w", sequence, err)
		}
		if receipt.Outcome == "APPLIED" {
			out[opText(receipt.OperationID)]++
		}
	}
	return out, nil
}
