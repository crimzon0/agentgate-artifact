package main

// Acceptance measures, totals and the result files (results.json,
// results.csv, summary.md).

import (
	"fmt"
	"path/filepath"
	"sort"
	"strings"

	"agentgate/internal/audit"
	"agentgate/internal/devcomposition"
)

// answerRecord is one answer the agent received.
type answerRecord struct {
	Segment   int        `json:"segment"`
	Call      string     `json:"call"`
	Operation string     `json:"operation"` // original | fresh | probe
	Result    callResult `json:"result"`
	// EffectsAtAnswer is the provider's committed effects for that operation
	// ID right after the answer arrived.
	EffectsAtAnswer int `json:"effects_at_answer"`
}

// segmentOutcome is one gateway process and its evidence folder.
type segmentOutcome struct {
	Index      int            `json:"index"`
	Folder     string         `json:"folder"`
	Ended      string         `json:"ended"`
	KillPoint  string         `json:"kill_point,omitempty"`
	ExitCode   int            `json:"exit_code"`
	KeysSHA256 string         `json:"keys_sha256,omitempty"`
	PinSeq     uint64         `json:"pinned_head_seq,omitempty"`
	PinHead    string         `json:"pinned_head,omitempty"`
	Restored   int            `json:"restored_operations,omitempty"`
	StartError string         `json:"start_error,omitempty"`
	Verify     *verifyOutcome `json:"verify,omitempty"`
}

// cellResult is one cell run with its measures.
type cellResult struct {
	cellSpec
	Rep              int    `json:"rep"`
	Label            string `json:"label"`
	Dir              string `json:"dir"`
	OperationID      string `json:"operation_id"`
	FreshOperationID string `json:"fresh_operation_id,omitempty"`
	ProbeOperationID string `json:"probe_operation_id,omitempty"`

	KillReached          bool             `json:"kill_reached"`
	Answers              []answerRecord   `json:"answers"`
	StatesAfterRetry     []operationWire  `json:"states_after_retry,omitempty"`
	StatesAfterReconcile []operationWire  `json:"states_after_reconcile,omitempty"`
	StateAfterRetry      string           `json:"original_state_after_retry"`
	StateAfterReconcile  string           `json:"original_state_after_reconcile"`
	Effects              map[string]int   `json:"provider_effects"`   // by role
	Dispatches           map[string]int   `json:"dispatch_requests"`  // by role, as the provider received them
	StatusLookups        int              `json:"status_lookups"`     // as the provider received them
	StatusFailures       int              `json:"status_lookups_503"` // answered 503 by the suite
	HeldDispatchStatus   int              `json:"held_dispatch_http_status,omitempty"`
	Segments             []segmentOutcome `json:"segments"`
	AsKilled             *verifyOutcome   `json:"as_killed_copy_verify,omitempty"`
	SurrogateApplied     string           `json:"surrogate_applied,omitempty"`
	RestartBlocked       bool             `json:"restart_blocked,omitempty"`
	RestartError         string           `json:"restart_error,omitempty"`

	// Acceptance measures (the "must be 0 / false" ones are summed in totals).
	DuplicateEffect     bool `json:"duplicate_effect"` // some operation ID has more than one effect
	DuplicateOperations int  `json:"operations_with_duplicate_effect"`
	// BusinessDuplicate: the fresh-ID control committed identical content a
	// second time (one effect per operation ID, not per business intent).
	BusinessDuplicate          bool `json:"business_duplicate,omitempty"`
	RejectedWithEffectAtAnswer int  `json:"rejected_with_effect_at_answer"` // REJECTED while the provider held an effect for it
	NotCommittedWithEffect     int  `json:"not_committed_with_effect"`      // provider_not_committed although the provider holds an effect (at the end)
	RejectedThenEffect         int  `json:"rejected_then_effect"`           // REJECTED, and an effect exists for that ID by the end (a later re-run)
	CommittedWithoutEffect     int  `json:"committed_without_effect"`       // COMMITTED while the provider held no effect for it
	// UnresolvedAfterReconcile: some operation of the cell is still UNCERTAIN
	// or RECONCILIATION_REQUIRED after Reconcile, or the restart was refused.
	// UnresolvedOperations counts those operations (every operation the
	// gateway lists, not only the original one); UndecidedOperations counts
	// the cell's operations with no final status at all: listed with none or
	// PENDING (e.g. a capability consumed and never dispatched), or not listed
	// by the gateway after Reconcile (UnlistedOperations, e.g. a call refused
	// before the operation could be journaled).
	UnresolvedAfterReconcile bool `json:"unresolved_after_reconcile"`
	UnresolvedOperations     int  `json:"unresolved_operations"`
	UndecidedOperations      int  `json:"undecided_operations"`
	UnlistedOperations       int  `json:"unlisted_operations"`
	// UnsettledWithEffect counts the cell's operations that were dispatched
	// (the gateway says so, or the provider received a request for them) or
	// for which the provider holds an effect, and that are not COMMITTED or
	// REJECTED after Reconcile: listed with another status, or not listed.
	UnsettledWithEffect int  `json:"unsettled_with_dispatch_or_effect"`
	Redispatch          bool `json:"redispatch"` // some operation ID was dispatched to the provider more than once
	// UnknownDispatches counts dispatch requests whose operation-ID header is
	// missing or names none of the cell's operations (a cell error).
	UnknownDispatches int `json:"unknown_dispatches"`

	FlagExpected       bool  `json:"flag_expected"`
	FlagAnswer         *bool `json:"flag_in_committed_answers,omitempty"`
	FlagOutcomeEntries *bool `json:"flag_in_outcome_entries,omitempty"` // RECONCILED(committed) and CALL_RESULT(COMMITTED) entries
	// FlagRecoveryEntries is FlagOutcomeEntries for the recovery entries
	// alone: RECONCILED(committed), a reconciling CALL_RESULT, and an outcome
	// entry of a restarted segment that is a replay or belongs to an
	// operation that did not simply run again from scratch there (no
	// POLICY_DECISION or EFFECT_EXECUTED of it in that segment).
	FlagRecoveryEntries *bool `json:"flag_in_recovery_entries,omitempty"`
	// FlagReplayEntries is FlagOutcomeEntries for the replayed answers alone
	// (CALL_RESULT COMMITTED with replayed=true); SameProcessReplayEntries
	// counts those written by the process that recorded the effect (answered
	// from its own store), the rest came after a restart (from the journal).
	FlagReplayEntries        *bool `json:"flag_in_replay_entries,omitempty"`
	FlagVerifier             *bool `json:"flag_in_verifier_report,omitempty"`
	FlagPreserved            *bool `json:"flag_preserved,omitempty"`
	OutcomeEntries           int   `json:"outcome_entries"`
	RecoveryEntries          int   `json:"recovery_entries"`
	ReplayEntries            int   `json:"replay_entries"`
	SameProcessReplayEntries int   `json:"same_process_replay_entries"`
	// ClassificationEvidence is the verifier's classification evidence for
	// the original operation, from the newest verified segment, and only when
	// that folder verified (VERIFIED); ClassificationFolder is that folder's
	// verdict (a FAILED folder supplies no classification).
	ClassificationEvidence string `json:"classification_evidence,omitempty"`
	ClassificationFolder   string `json:"classification_folder_verdict,omitempty"`
	// SecondApprovalRequired: the restarted gateway challenged the exact
	// retry again (human cells).
	SecondApprovalRequired bool `json:"second_approval_required"`

	// Interrupted: the operator stopped the run (Ctrl-C) during this cell.
	Interrupted bool     `json:"interrupted,omitempty"`
	Error       string   `json:"error,omitempty"`
	Notes       []string `json:"notes"`
	ElapsedMS   float64  `json:"elapsed_ms"`
}

func boolPtr(value bool) *bool { return &value }

func stateOf(states []operationWire, id string) string {
	for _, state := range states {
		if state.OperationID == id {
			status := state.Status
			if status == "" {
				status = "UNDECIDED"
			}
			if state.Reason != "" {
				status += "/" + state.Reason
			}
			return status
		}
	}
	return "unknown"
}

// afterReconcileCounts counts, over every operation the gateway lists, the
// unresolved ones (UNCERTAIN, RECONCILIATION_REQUIRED) and the undecided ones
// (no final status: none, or PENDING).
func afterReconcileCounts(states []operationWire) (unresolved, undecided int) {
	for _, state := range states {
		switch devcomposition.OperationStatus(state.Status) {
		case devcomposition.StatusUncertain, devcomposition.StatusReconciliationRequired:
			unresolved++
		case devcomposition.StatusCommitted, devcomposition.StatusRejected:
		default:
			undecided++
		}
	}
	return unresolved, undecided
}

// finish computes the cell's measures from the provider's own journal and
// request counts, the answers, the states and the evidence folders.
func (c *cellRun) finish() {
	res := c.res
	for _, seg := range c.segments {
		res.Segments = append(res.Segments, *seg.out)
	}
	commits, err := c.provider.commitsByOperation()
	if err != nil {
		c.note("provider journal: %v", err)
		commits = map[string]int{}
	}
	dispatches := c.provider.dispatchCounts()
	res.StatusLookups, res.StatusFailures = c.provider.statusCounts()
	known := map[string]bool{}
	for role, id := range c.ids {
		known[opText(id)] = true
		res.Effects[role] = commits[opText(id)]
		res.Dispatches[role] = dispatches[opText(id)]
		if res.Effects[role] > 1 {
			res.DuplicateOperations++
		}
		res.Redispatch = res.Redispatch || res.Dispatches[role] > 1
	}
	// A dispatch the per-operation counts above cannot see (no header, or an
	// ID that is none of the cell's operations) fails the cell.
	var unknown []string
	for id, count := range dispatches {
		if !known[id] {
			res.UnknownDispatches += count
			unknown = append(unknown, fmt.Sprintf("%q x%d", id, count))
		}
	}
	if res.UnknownDispatches > 0 {
		sort.Strings(unknown)
		c.fail("the provider received %d dispatch request(s) whose operation ID is none of the cell's operations: %s", res.UnknownDispatches, strings.Join(unknown, ", "))
	}
	res.DuplicateEffect = res.DuplicateOperations > 0
	if fresh, ok := c.ids[roleFresh]; ok {
		res.BusinessDuplicate = commits[opText(c.ids[roleOriginal])]+commits[opText(fresh)] > 1
	}
	for _, answer := range res.Answers {
		end := commits[opText(c.ids[answer.Operation])]
		switch answer.Result.Status {
		case string(devcomposition.StatusRejected):
			if answer.EffectsAtAnswer > 0 {
				res.RejectedWithEffectAtAnswer++
			} else if end > 0 {
				res.RejectedThenEffect++
			}
			if answer.Result.Reason == "provider_not_committed" && end > 0 {
				res.NotCommittedWithEffect++
			}
		case string(devcomposition.StatusCommitted):
			if answer.EffectsAtAnswer == 0 {
				res.CommittedWithoutEffect++
			}
		}
	}
	original := opText(c.ids[roleOriginal])
	res.StateAfterRetry = stateOf(res.StatesAfterRetry, original)
	res.StateAfterReconcile = stateOf(res.StatesAfterReconcile, original)
	// Reconcile can also settle an operation as not committed without any
	// answer (an operation the fresh-ID control left behind).
	for _, state := range res.StatesAfterReconcile {
		if state.Status == string(devcomposition.StatusRejected) && state.Reason == "provider_not_committed" && commits[state.OperationID] > 0 {
			already := false
			for _, answer := range res.Answers {
				already = already || opText(c.ids[answer.Operation]) == state.OperationID && answer.Result.Reason == "provider_not_committed"
			}
			if !already {
				res.NotCommittedWithEffect++
			}
		}
	}
	res.UnresolvedOperations, res.UndecidedOperations = afterReconcileCounts(res.StatesAfterReconcile)
	if res.RestartBlocked {
		// The refused restart leaves the original operation unaccounted for.
		res.UnresolvedOperations++
	}
	res.UnresolvedAfterReconcile = res.UnresolvedOperations > 0
	c.settledMeasures(commits, dispatches)
	for index := len(c.segments) - 1; index >= 0; index-- {
		if verified := c.segments[index].out.Verify; verified != nil {
			res.ClassificationFolder = verified.verdictKey()
			if op, ok := verified.operation(original); ok && verified.Verdict == "VERIFIED" {
				res.ClassificationEvidence = op.ClassificationEvidence
			}
			break
		}
	}
	c.flagMeasures(commits[original] > 0)
}

// settledMeasures checks every operation of the cell (original, fresh-ID
// and probe), not only those the gateway lists after Reconcile: one it does
// not list is undecided (and unlisted), and one that was dispatched or holds
// a provider effect must end COMMITTED or REJECTED.
func (c *cellRun) settledMeasures(commits, dispatches map[string]int) {
	res := c.res
	listed := map[string]operationWire{}
	for _, state := range res.StatesAfterReconcile {
		listed[state.OperationID] = state
	}
	roles := make([]string, 0, len(c.ids))
	for role := range c.ids {
		roles = append(roles, role)
	}
	sort.Strings(roles)
	for _, role := range roles {
		id := opText(c.ids[role])
		state, ok := listed[id]
		if !ok && res.StatesAfterReconcile != nil {
			res.UnlistedOperations++
			res.UndecidedOperations++
		}
		final := ok && (state.Status == string(devcomposition.StatusCommitted) || state.Status == string(devcomposition.StatusRejected))
		if final || !(ok && state.Dispatched || dispatches[id] > 0 || commits[id] > 0) {
			continue
		}
		res.UnsettledWithEffect++
		status := "not listed"
		if ok {
			status = stateOf(res.StatesAfterReconcile, id)
		}
		c.note("the %s operation was dispatched or holds a provider effect (%d) but is %s after Reconcile", role, commits[id], status)
	}
}

// flagMeasures checks, for the flagged path, that every answer and every
// audit entry stating the committed outcome still says "flagged".
func (c *cellRun) flagMeasures(committed bool) {
	res := c.res
	res.FlagExpected = c.spec.Path == pathFlagMessage
	if !res.FlagExpected || !committed {
		return
	}
	original := opText(c.ids[roleOriginal])
	// The agent's answers are judged only if they report the flag at all.
	answers, answerFlags := 0, true
	for _, answer := range res.Answers {
		if answer.Operation == roleOriginal && answer.Result.Status == string(devcomposition.StatusCommitted) && answer.Result.FlagReported {
			answers++
			answerFlags = answerFlags && answer.Result.Flagged
		}
	}
	if answers > 0 {
		res.FlagAnswer = boolPtr(answerFlags)
	}
	entries, entryFlags := 0, true
	recovery, recoveryFlags := 0, true
	replays, sameProcess, replayFlags := 0, 0, true
	for _, seg := range c.segments {
		stored, err := audit.ReadLog(seg.dir)
		if err != nil {
			c.note("segment %d log unreadable for the flag check: %v", seg.index, err)
			continue
		}
		// ranAgain: the operation simply ran again from scratch in this
		// segment (a kill before the dispatch intent), so its outcome entries
		// here are not recoveries.
		ranAgain := false
		for _, line := range stored {
			ranAgain = ranAgain || line.Entry.OperationID == original && (line.Entry.Stage == "POLICY_DECISION" || line.Entry.Stage == "EFFECT_EXECUTED")
		}
		// effectHere: this process recorded the effect (EFFECT_EXECUTED or
		// RECONCILED committed) before the entry, so a replay it wrote came
		// from its own store, not from the journal after a restart.
		effectHere := false
		for _, line := range stored {
			entry := line.Entry
			if entry.OperationID != original {
				continue
			}
			status, _ := entry.Details["status"].(string)
			committedRecord := entry.Stage == "RECONCILED" && entry.Outcome == "committed"
			if committedRecord || entry.Stage == "CALL_RESULT" && status == string(devcomposition.StatusCommitted) {
				entries++
				flagged, _ := entry.Details["flagged"].(bool)
				entryFlags = entryFlags && flagged
				reconciled, _ := entry.Details["reconciled"].(bool)
				replayed, _ := entry.Details["replayed"].(bool)
				replayed = replayed && entry.Stage == "CALL_RESULT"
				if replayed {
					replays++
					replayFlags = replayFlags && flagged
					if effectHere {
						sameProcess++
					}
				}
				if entry.Stage == "RECONCILED" || reconciled || seg.index > 1 && (replayed || !ranAgain) {
					recovery++
					recoveryFlags = recoveryFlags && flagged
				}
			}
			effectHere = effectHere || entry.Stage == "EFFECT_EXECUTED" || committedRecord
		}
	}
	res.OutcomeEntries, res.RecoveryEntries = entries, recovery
	res.ReplayEntries, res.SameProcessReplayEntries = replays, sameProcess
	if entries > 0 {
		res.FlagOutcomeEntries = boolPtr(entryFlags)
	}
	if recovery > 0 {
		res.FlagRecoveryEntries = boolPtr(recoveryFlags)
	}
	if replays > 0 {
		res.FlagReplayEntries = boolPtr(replayFlags)
	}
	if last := c.segments; len(last) > 0 && last[len(last)-1].out.Verify != nil {
		if op, ok := last[len(last)-1].out.Verify.operation(original); ok {
			res.FlagVerifier = boolPtr(op.Flagged)
		}
	}
	if res.FlagAnswer != nil || res.FlagOutcomeEntries != nil {
		preserved := (res.FlagAnswer == nil || *res.FlagAnswer) && (res.FlagOutcomeEntries == nil || *res.FlagOutcomeEntries)
		res.FlagPreserved = boolPtr(preserved)
	}
}

// --- totals ---------------------------------------------------------------------------

// classNotReported is the classification-evidence key of a cell whose
// original operation has none in the verifier's report.
const classNotReported = "not reported"

type totals struct {
	Cells      int `json:"cells"`
	CellErrors int `json:"cell_errors"`
	Operations int `json:"operations"`

	DuplicateEffects           int `json:"operations_with_more_than_one_effect"`
	RejectedWithEffectAtAnswer int `json:"rejected_while_provider_holds_effect"`
	NotCommittedWithEffect     int `json:"provider_not_committed_while_provider_holds_effect"`
	CommittedWithoutEffect     int `json:"committed_without_effect"`
	// UnresolvedAfterReconcile and UnresolvedDeliberate count operations
	// (every operation of a cell, not only the original one).
	UnresolvedAfterReconcile int `json:"unresolved_after_reconcile_not_deliberate"`
	UnresolvedDeliberate     int `json:"unresolved_after_reconcile_deliberate"`
	UndecidedAfterReconcile  int `json:"undecided_after_reconcile"`
	UnlistedAfterReconcile   int `json:"unlisted_after_reconcile"`
	// UnsettledWithEffect counts operations (not in deliberate cells) that
	// were dispatched or hold a provider effect and are not COMMITTED or
	// REJECTED after Reconcile.
	UnsettledWithEffect int `json:"unsettled_with_dispatch_or_effect_not_deliberate"`
	Redispatches        int `json:"cells_with_redispatch"`
	UnknownDispatches   int `json:"dispatches_for_unknown_operation_ids"`
	RejectedThenEffect  int `json:"rejected_answers_then_effect_after_restart"`
	BusinessDuplicates  int `json:"fresh_id_business_duplicates"`

	KillNotReached         int `json:"kill_point_not_reached"`
	InterruptedCells       int `json:"interrupted_cells"`
	RestartBlocked         int `json:"restart_blocked"`
	SecondApprovalRequired int `json:"second_approval_required"`
	FlagCells              int `json:"flag_cells_committed"`
	FlagPreserved          int `json:"flag_preserved"`
	FlagLost               int `json:"flag_lost"`
	FlagLostInEntries      int `json:"flag_lost_in_outcome_entries"`
	FlagLostInAnswers      int `json:"flag_lost_in_answers"`
	FlagCellsWithRecovery  int `json:"flag_cells_with_recovery_entries"`
	FlagLostInRecovery     int `json:"flag_lost_in_recovery_entries"`
	// FlagCellsWithReplay: flagged cells that committed and have replayed
	// answers (CALL_RESULT COMMITTED, replayed); ...SameProcessReplay: among
	// them, those with a replay written by the process that recorded the
	// effect.
	FlagCellsWithReplay            int `json:"flag_cells_with_replay_entries"`
	FlagCellsWithSameProcessReplay int `json:"flag_cells_with_same_process_replay_entries"`
	FlagLostInReplay               int `json:"flag_lost_in_replay_entries"`

	Segment1Alone map[string]int `json:"segment1_alone_verdicts"`
	RunWalk       map[string]int `json:"run_walk_verdicts"` // newest segment of a restarted cell, chain followed
	SingleSegment map[string]int `json:"single_segment_verdicts"`
	FailingChecks map[string]int `json:"failing_checks"`
	WarningChecks map[string]int `json:"warning_checks"` // folders per warning check ID
	// AsKilled* count the untouched as-killed copies of the surrogate cells
	// (verified alone, never part of the verdicts above): verdicts, failing
	// and warning check IDs per copy.
	AsKilled              map[string]int `json:"as_killed_verdicts"`
	AsKilledFailingChecks map[string]int `json:"as_killed_failing_checks"`
	AsKilledWarningChecks map[string]int `json:"as_killed_warning_checks"`
	// ClassificationEvidence counts the cells per classification evidence of
	// the original operation (newest verified segment when it VERIFIED;
	// classFailedFolder when that folder FAILED; classNotReported when the
	// verifier gives none or did not run).
	ClassificationEvidence map[string]int `json:"classification_evidence"`

	// AcceptancePassed: every "must be 0" measure is 0, every kill point was
	// reached, no cell failed to run or to test what it models, and the run
	// was not interrupted (runSuite applies the last condition).
	AcceptancePassed bool `json:"acceptance_passed"`
}

// classFailedFolder is the classification-evidence key of a cell whose
// newest verified folder did not verify: a FAILED folder supplies none.
const classFailedFolder = "not reported (newest folder FAILED)"

func totalsOf(results []cellResult) totals {
	t := totals{Segment1Alone: map[string]int{}, RunWalk: map[string]int{}, SingleSegment: map[string]int{}, FailingChecks: map[string]int{},
		WarningChecks: map[string]int{}, AsKilled: map[string]int{}, AsKilledFailingChecks: map[string]int{}, AsKilledWarningChecks: map[string]int{},
		ClassificationEvidence: map[string]int{}}
	for _, res := range results {
		t.Cells++
		if res.Error != "" {
			t.CellErrors++
		}
		if res.Interrupted {
			t.InterruptedCells++
		}
		t.UndecidedAfterReconcile += res.UndecidedOperations
		t.UnlistedAfterReconcile += res.UnlistedOperations
		if !res.Deliberate {
			t.UnsettledWithEffect += res.UnsettledWithEffect
		}
		t.UnknownDispatches += res.UnknownDispatches
		class := res.ClassificationEvidence
		switch {
		case class != "":
		case res.ClassificationFolder != "" && !strings.HasPrefix(res.ClassificationFolder, "VERIFIED"):
			class = classFailedFolder
		default:
			class = classNotReported
		}
		t.ClassificationEvidence[class]++
		t.Operations += len(res.Effects)
		t.DuplicateEffects += res.DuplicateOperations
		if res.BusinessDuplicate {
			t.BusinessDuplicates++
		}
		t.RejectedWithEffectAtAnswer += res.RejectedWithEffectAtAnswer
		t.NotCommittedWithEffect += res.NotCommittedWithEffect
		t.CommittedWithoutEffect += res.CommittedWithoutEffect
		t.RejectedThenEffect += res.RejectedThenEffect
		if res.Deliberate {
			t.UnresolvedDeliberate += res.UnresolvedOperations
		} else {
			t.UnresolvedAfterReconcile += res.UnresolvedOperations
		}
		if res.Redispatch {
			t.Redispatches++
		}
		if res.Kill != "" && !res.KillReached {
			t.KillNotReached++
		}
		if res.RestartBlocked {
			t.RestartBlocked++
		}
		if res.SecondApprovalRequired {
			t.SecondApprovalRequired++
		}
		if res.FlagPreserved != nil {
			t.FlagCells++
			if *res.FlagPreserved {
				t.FlagPreserved++
			} else {
				t.FlagLost++
			}
			if res.FlagOutcomeEntries != nil && !*res.FlagOutcomeEntries {
				t.FlagLostInEntries++
			}
			if res.FlagAnswer != nil && !*res.FlagAnswer {
				t.FlagLostInAnswers++
			}
			if res.FlagRecoveryEntries != nil {
				t.FlagCellsWithRecovery++
				if !*res.FlagRecoveryEntries {
					t.FlagLostInRecovery++
				}
			}
			if res.FlagReplayEntries != nil {
				t.FlagCellsWithReplay++
				if res.SameProcessReplayEntries > 0 {
					t.FlagCellsWithSameProcessReplay++
				}
				if !*res.FlagReplayEntries {
					t.FlagLostInReplay++
				}
			}
		}
		if res.AsKilled != nil {
			t.AsKilled[res.AsKilled.verdictKey()]++
			for _, id := range res.AsKilled.Failing {
				t.AsKilledFailingChecks[id]++
			}
			for _, id := range res.AsKilled.Warning {
				t.AsKilledWarningChecks[id]++
			}
		}
		for _, seg := range res.Segments {
			if seg.Verify == nil {
				continue
			}
			key := seg.Verify.verdictKey()
			switch {
			case len(res.Segments) == 1:
				t.SingleSegment[key]++
			case seg.Index == 1:
				t.Segment1Alone[key]++
			case seg.Index == len(res.Segments):
				t.RunWalk[key]++
			}
			for _, id := range seg.Verify.Failing {
				t.FailingChecks[id]++
			}
			for _, id := range seg.Verify.Warning {
				t.WarningChecks[id]++
			}
		}
	}
	t.AcceptancePassed = t.CellErrors == 0 && t.DuplicateEffects == 0 && t.RejectedWithEffectAtAnswer == 0 && t.NotCommittedWithEffect == 0 &&
		t.CommittedWithoutEffect == 0 && t.UnresolvedAfterReconcile == 0 && t.UnsettledWithEffect == 0 && t.Redispatches == 0 && t.UnknownDispatches == 0 &&
		t.KillNotReached == 0 && t.InterruptedCells == 0
	return t
}

// --- CSV -----------------------------------------------------------------------------

func csvEscape(value string) string {
	if strings.ContainsAny(value, ",\"\n\r") {
		return `"` + strings.ReplaceAll(value, `"`, `""`) + `"`
	}
	return value
}

func csvLine(fields ...string) string {
	escaped := make([]string, len(fields))
	for index, field := range fields {
		escaped[index] = csvEscape(field)
	}
	return strings.Join(escaped, ",") + "\n"
}

func yesNo(value bool) string {
	if value {
		return "yes"
	}
	return "no"
}

func optional(value *bool) string {
	if value == nil {
		return ""
	}
	return yesNo(*value)
}

// answerChain is the answers in order, "call=STATUS/reason".
func answerChain(answers []answerRecord) string {
	parts := make([]string, len(answers))
	for index, answer := range answers {
		text := fmt.Sprintf("s%d:%s=%s", answer.Segment, answer.Call, answer.Result.key())
		if answer.Result.Challenge {
			text = fmt.Sprintf("s%d:%s=CHALLENGE", answer.Segment, answer.Call)
		}
		if answer.Operation != roleOriginal {
			text += "(" + answer.Operation + ")"
		}
		parts[index] = text
	}
	return strings.Join(parts, " ")
}

func segmentVerdict(res cellResult, index int) (string, string) {
	for _, seg := range res.Segments {
		if seg.Index == index && seg.Verify != nil {
			return seg.Verify.verdictKey(), strings.Join(seg.Verify.Failing, " ")
		}
	}
	return "", ""
}

// segmentWarnings is the warning check IDs of segment index.
func segmentWarnings(res cellResult, index int) string {
	for _, seg := range res.Segments {
		if seg.Index == index && seg.Verify != nil {
			return strings.Join(seg.Verify.Warning, " ")
		}
	}
	return ""
}

func resultsCSV(results []cellResult) string {
	var b strings.Builder
	b.WriteString(csvLine("cell", "group", "path", "kill_point", "retry", "provider_fault", "surrogate", "rep", "kill_reached",
		"answers", "state_after_retry", "state_after_reconcile",
		"effects_original", "effects_fresh", "effects_probe", "dispatches_original", "dispatches_fresh", "unknown_dispatches", "status_lookups", "status_lookups_503",
		"duplicate_effect", "rejected_with_effect_at_answer", "not_committed_with_effect", "rejected_then_effect", "committed_without_effect",
		"unresolved_after_reconcile", "unresolved_operations", "undecided_operations", "unlisted_operations", "unsettled_with_dispatch_or_effect",
		"deliberate_unresolved", "redispatch", "restart_blocked",
		"flag_expected", "flag_in_answers", "flag_in_outcome_entries", "recovery_entries", "flag_in_recovery_entries",
		"replay_entries", "same_process_replay_entries", "flag_in_replay_entries", "flag_in_verifier_report", "flag_preserved",
		"classification_evidence", "classification_folder_verdict", "second_approval_required",
		"segment1_verdict", "segment1_failing", "segment1_warnings", "segment2_verdict", "segment2_failing", "segment2_warnings",
		"as_killed_verdict", "as_killed_failing", "as_killed_warnings",
		"interrupted", "error", "notes", "elapsed_ms"))
	for _, res := range results {
		s1, f1 := segmentVerdict(res, 1)
		s2, f2 := segmentVerdict(res, 2)
		asKilled, asKilledFailing, asKilledWarnings := "", "", ""
		if res.AsKilled != nil {
			asKilled, asKilledFailing, asKilledWarnings = res.AsKilled.verdictKey(), strings.Join(res.AsKilled.Failing, " "), strings.Join(res.AsKilled.Warning, " ")
		}
		b.WriteString(csvLine(res.Name, res.Group, res.Path, res.Kill, res.Retry, res.Fault, res.Surrogate, fmt.Sprint(res.Rep), yesNo(res.KillReached),
			answerChain(res.Answers), res.StateAfterRetry, res.StateAfterReconcile,
			fmt.Sprint(res.Effects[roleOriginal]), countIf(res.Effects, roleFresh), countIf(res.Effects, roleProbe),
			fmt.Sprint(res.Dispatches[roleOriginal]), countIf(res.Dispatches, roleFresh), fmt.Sprint(res.UnknownDispatches), fmt.Sprint(res.StatusLookups), fmt.Sprint(res.StatusFailures),
			yesNo(res.DuplicateEffect), fmt.Sprint(res.RejectedWithEffectAtAnswer), fmt.Sprint(res.NotCommittedWithEffect), fmt.Sprint(res.RejectedThenEffect), fmt.Sprint(res.CommittedWithoutEffect),
			yesNo(res.UnresolvedAfterReconcile), fmt.Sprint(res.UnresolvedOperations), fmt.Sprint(res.UndecidedOperations), fmt.Sprint(res.UnlistedOperations), fmt.Sprint(res.UnsettledWithEffect),
			yesNo(res.Deliberate), yesNo(res.Redispatch), yesNo(res.RestartBlocked),
			yesNo(res.FlagExpected), optional(res.FlagAnswer), optional(res.FlagOutcomeEntries), fmt.Sprint(res.RecoveryEntries), optional(res.FlagRecoveryEntries),
			fmt.Sprint(res.ReplayEntries), fmt.Sprint(res.SameProcessReplayEntries), optional(res.FlagReplayEntries), optional(res.FlagVerifier), optional(res.FlagPreserved),
			res.ClassificationEvidence, res.ClassificationFolder, yesNo(res.SecondApprovalRequired),
			s1, f1, segmentWarnings(res, 1), s2, f2, segmentWarnings(res, 2),
			asKilled, asKilledFailing, asKilledWarnings,
			yesNo(res.Interrupted), res.Error, strings.Join(res.Notes, "; "), fmt.Sprintf("%.0f", res.ElapsedMS)))
	}
	return b.String()
}

func countIf(counts map[string]int, role string) string {
	if value, ok := counts[role]; ok {
		return fmt.Sprint(value)
	}
	return ""
}

// --- summary.md ------------------------------------------------------------------------

// signature is what must be identical across the repetitions of one cell.
func signature(res cellResult) string {
	s1, _ := segmentVerdict(res, 1)
	s2, _ := segmentVerdict(res, 2)
	parts := []string{
		answerChain(res.Answers), "after Reconcile " + res.StateAfterReconcile,
		fmt.Sprintf("effects %d", res.Effects[roleOriginal]),
	}
	if value, ok := res.Effects[roleFresh]; ok {
		parts = append(parts, fmt.Sprintf("fresh effects %d", value))
	}
	parts = append(parts, "seg1 "+s1)
	if s2 != "" {
		parts = append(parts, "seg2 "+s2)
	}
	if res.FlagPreserved != nil {
		parts = append(parts, "flag preserved "+yesNo(*res.FlagPreserved))
	}
	if res.ClassificationEvidence != "" {
		parts = append(parts, "class "+res.ClassificationEvidence)
	}
	if res.UndecidedOperations > 0 {
		parts = append(parts, fmt.Sprintf("%d undecided", res.UndecidedOperations))
	}
	if res.UnsettledWithEffect > 0 {
		parts = append(parts, fmt.Sprintf("%d unsettled with a dispatch or effect", res.UnsettledWithEffect))
	}
	if res.RestartBlocked {
		parts = append(parts, "restart blocked")
	}
	if res.Error != "" {
		parts = append(parts, "ERROR "+res.Error)
	}
	return strings.Join(parts, "; ")
}

func summaryMarkdown(result suiteResult) string {
	var b strings.Builder
	t := result.Totals
	fmt.Fprintf(&b, "# OS-level crash suite (agentgate-killsuite)\n\n%s\n\n", result.Note)
	fmt.Fprintf(&b, "Command: `%s`  \nGo %s on %s/%s, %d CPUs. Repetitions: %d. Cells: %d. Elapsed: %.1f s.\n\n",
		result.Environment.Command, result.Environment.GoVersion, result.Environment.GOOS, result.Environment.GOARCH, result.Environment.NumCPU,
		result.Reps, t.Cells, result.ElapsedS)
	fmt.Fprintf(&b, "Builds: suite and gateway %s; verifier %s.\n\n", result.Build.SuiteAndGateway.line(), result.Build.Verifier.line())
	if result.Build.Commit != "" {
		fmt.Fprintf(&b, "Source commit (as given with -commit): %s.\n\n", result.Build.Commit)
	}
	if result.Interrupted {
		b.WriteString("**The run was interrupted (Ctrl-C); these results cover the cells that ran.**\n\n")
	}
	b.WriteString("## Acceptance\n\n| measure | count | required |\n|---|---|---|\n")
	type row struct {
		name  string
		value int
		want  string
	}
	rows := []row{
		{"cells that could not run or did not test what they model (kill point or fault not fired, unexpected dispatch, interrupted)", t.CellErrors, "0"},
		{"operation IDs with more than one provider effect", t.DuplicateEffects, "0"},
		{"REJECTED answered while the provider held an effect for that operation ID", t.RejectedWithEffectAtAnswer, "0"},
		{"REJECTED/provider_not_committed while the provider holds an effect (checked at the end of the cell)", t.NotCommittedWithEffect, "0"},
		{"COMMITTED answered while the provider held no effect", t.CommittedWithoutEffect, "0"},
		{"operations unresolved after Reconcile, every operation of a cell (not deliberate)", t.UnresolvedAfterReconcile, "0"},
		{"operations dispatched or holding a provider effect that are not COMMITTED or REJECTED after Reconcile, listed or not (not deliberate)", t.UnsettledWithEffect, "0"},
		{"cells where an operation ID was dispatched more than once", t.Redispatches, "0"},
		{"dispatch requests for no operation of the cell (missing or unknown operation ID)", t.UnknownDispatches, "0"},
		{"kill point not reached", t.KillNotReached, "0"},
		{"operations unresolved after Reconcile (deliberate: endless lookup failure, refused restart)", t.UnresolvedDeliberate, "reported"},
		{"operations left undecided after Reconcile (no final status, e.g. a capability consumed and never dispatched; unlisted ones included)", t.UndecidedAfterReconcile, "reported"},
		{"... of them not listed by the gateway after Reconcile (e.g. refused before the operation was journaled)", t.UnlistedAfterReconcile, "reported"},
		{"REJECTED answers whose operation ID was committed later by the restarted gateway (journal write failure)", t.RejectedThenEffect, "reported"},
		{"fresh-ID controls that committed identical content twice (one effect per operation ID, not per intent)", t.BusinessDuplicates, "reported"},
		{"restarts refused (fail closed)", t.RestartBlocked, "reported"},
		{"human cells whose restart required a second approval", t.SecondApprovalRequired, "reported"},
		{"flagged operations that committed", t.FlagCells, "reported"},
		{"... flag preserved in every answer and outcome entry", t.FlagPreserved, "reported"},
		{"... flag lost in an outcome entry (RECONCILED / CALL_RESULT)", t.FlagLostInEntries, "reported"},
		{"... with recovery entries (RECONCILED, reconciling CALL_RESULT, a replay or recovery in a restarted segment; not a plain re-run)", t.FlagCellsWithRecovery, "reported"},
		{"... flag lost in a recovery entry", t.FlagLostInRecovery, "reported"},
		{"... with replayed answers (CALL_RESULT COMMITTED, replayed)", t.FlagCellsWithReplay, "reported"},
		{"... with a replay in the same process that recorded the effect", t.FlagCellsWithSameProcessReplay, "reported"},
		{"... flag lost in a replayed answer", t.FlagLostInReplay, "reported"},
		{"... flag lost in an answer", t.FlagLostInAnswers, "reported"},
	}
	if t.InterruptedCells > 0 || result.Interrupted {
		rows = append(rows, row{"cells interrupted by the operator (Ctrl-C)", t.InterruptedCells, "0"})
	}
	for _, row := range rows {
		fmt.Fprintf(&b, "| %s | %d | %s |\n", row.name, row.value, row.want)
	}
	fmt.Fprintf(&b, "\nAll required measures met: **%s**.\n", yesNo(t.AcceptancePassed))
	b.WriteString("\n## Verifier verdicts (agentgate-verify, keys and head pinned by the parent)\n\n| folder | verdict | count |\n|---|---|---|\n")
	for _, group := range []struct {
		name   string
		counts map[string]int
	}{{"segment 1 alone (restarted cells)", t.Segment1Alone}, {"newest segment, chain followed (run walk)", t.RunWalk}, {"single segment (no restart)", t.SingleSegment}} {
		for _, key := range sortedKeys(group.counts) {
			fmt.Fprintf(&b, "| %s | %s | %d |\n", group.name, key, group.counts[key])
		}
	}
	if len(t.FailingChecks) > 0 {
		b.WriteString("\n| failing check | folders |\n|---|---|\n")
		for _, key := range sortedKeys(t.FailingChecks) {
			fmt.Fprintf(&b, "| %s | %d |\n", key, t.FailingChecks[key])
		}
	}
	if len(t.WarningChecks) > 0 {
		b.WriteString("\n| warning (never changes the verdict) | folders |\n|---|---|\n")
		for _, key := range sortedKeys(t.WarningChecks) {
			fmt.Fprintf(&b, "| %s | %d |\n", key, t.WarningChecks[key])
		}
	}
	if len(t.AsKilled) > 0 {
		b.WriteString("\n| untouched as-killed copy of a surrogate cell (verified alone) | copies |\n|---|---|\n")
		for _, key := range sortedKeys(t.AsKilled) {
			fmt.Fprintf(&b, "| verdict %s | %d |\n", key, t.AsKilled[key])
		}
		for _, key := range sortedKeys(t.AsKilledFailingChecks) {
			fmt.Fprintf(&b, "| failing check %s | %d |\n", key, t.AsKilledFailingChecks[key])
		}
		for _, key := range sortedKeys(t.AsKilledWarningChecks) {
			fmt.Fprintf(&b, "| warning %s | %d |\n", key, t.AsKilledWarningChecks[key])
		}
	}
	if len(t.ClassificationEvidence) > 0 {
		b.WriteString("\n| classification evidence of the original operation (newest segment) | cells |\n|---|---|\n")
		for _, key := range sortedKeys(t.ClassificationEvidence) {
			fmt.Fprintf(&b, "| %s | %d |\n", key, t.ClassificationEvidence[key])
		}
	}
	b.WriteString("\n## Per cell (outcome signature over the repetitions)\n\n" +
		"Answers are `segment:call=STATUS/reason`; NO_ANSWER means the connection ended because the gateway process died. " +
		"Verdicts are VERDICT/ASSURANCE from agentgate-verify.\n\n| cell | reps | stable | outcome (most frequent) | models |\n|---|---|---|---|---|\n")
	byName := map[string][]cellResult{}
	var names []string
	for _, res := range result.Cells {
		if _, ok := byName[res.Name]; !ok {
			names = append(names, res.Name)
		}
		byName[res.Name] = append(byName[res.Name], res)
	}
	for _, name := range names {
		group := byName[name]
		counts := map[string]int{}
		best, bestCount := "", 0
		for _, res := range group {
			key := signature(res)
			counts[key]++
			if counts[key] > bestCount {
				best, bestCount = key, counts[key]
			}
		}
		stable := "yes"
		if len(counts) > 1 {
			stable = fmt.Sprintf("no (%d variants)", len(counts))
		}
		fmt.Fprintf(&b, "| %s | %d | %s | %s | %s |\n", name, len(group), stable, mdEscape(best), mdEscape(group[0].Models))
	}
	return b.String()
}

func mdEscape(text string) string { return strings.ReplaceAll(text, "|", "\\|") }

func sortedKeys(counts map[string]int) []string {
	keys := make([]string, 0, len(counts))
	for key := range counts {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	return keys
}

// resultFiles are the files run mode writes into -out.
func resultFiles(outDir string) (string, string, string) {
	return filepath.Join(outDir, "results.json"), filepath.Join(outDir, "results.csv"), filepath.Join(outDir, "summary.md")
}
