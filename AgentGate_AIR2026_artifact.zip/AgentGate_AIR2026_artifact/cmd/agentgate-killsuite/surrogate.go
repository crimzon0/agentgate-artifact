package main

// Power-loss surrogates. A real power cut cannot be produced on this machine
// without system changes (os.Exit and TerminateProcess leave the kernel's file
// cache intact, so a killed process never loses a write it already made). The
// suite therefore produces, on a copy of a folder killed after
// EFFECT_EXECUTED, the on-disk states a power loss could leave, using only
// bytes the gateway itself wrote. Nothing is re-signed and no key is touched:
//
//	torn_journal_tail  operations.jsonl ends in the first half of a line (a
//	                   record that was being written; opjournal promises to
//	                   discard it)
//	torn_audit_tail    audit.jsonl ends in the first half of a line (an entry
//	                   that was being written; head.json still vouches for
//	                   the last complete line, as it would)
//	head_reverted      head.json is the previous genuine head the child
//	                   streamed (the line was synced, the rename of the new
//	                   head did not reach the disk: Windows has no directory
//	                   flush and os.Rename is not write-through)
//	temp_head_left     a .head.json.tmp-* file holding the current genuine
//	                   head, next to an intact head.json (a crash inside the
//	                   atomic head replacement)

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"

	"agentgate/internal/audit"
)

// applySurrogate mutates the journal and segment folder in place (the caller
// works on a copy) and describes what it did.
func applySurrogate(kind, journal, segmentDir string, previousHead []byte) (string, error) {
	switch kind {
	case surrogateTornJournal:
		return tearLastLine(journal)
	case surrogateTornAudit:
		return tearLastLine(filepath.Join(segmentDir, audit.LogFile))
	case surrogateHeadReverted:
		if len(previousHead) == 0 {
			return "", errors.New("no previous genuine head was streamed")
		}
		if err := os.WriteFile(filepath.Join(segmentDir, audit.HeadFile), previousHead, 0o600); err != nil {
			return "", err
		}
		return fmt.Sprintf("head.json replaced by the previous genuine head (%d bytes)", len(previousHead)), nil
	case surrogateTempHead:
		current, err := os.ReadFile(filepath.Join(segmentDir, audit.HeadFile))
		if err != nil {
			return "", err
		}
		name := "." + audit.HeadFile + ".tmp-1234567890"
		if err := os.WriteFile(filepath.Join(segmentDir, name), current, 0o600); err != nil {
			return "", err
		}
		return fmt.Sprintf("left %s holding the current head (%d bytes)", name, len(current)), nil
	}
	return "", fmt.Errorf("unknown surrogate %q", kind)
}

// tearLastLine appends the first half of the file's last complete line,
// without its newline.
func tearLastLine(path string) (string, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return "", err
	}
	trimmed := bytes.TrimSuffix(data, []byte("\n"))
	if len(trimmed) == 0 || len(trimmed) == len(data) {
		return "", fmt.Errorf("%s has no complete line to tear", filepath.Base(path))
	}
	last := trimmed[bytes.LastIndexByte(trimmed, '\n')+1:]
	torn := last[:len(last)/2]
	file, err := os.OpenFile(path, os.O_WRONLY|os.O_APPEND, 0o600)
	if err != nil {
		return "", err
	}
	_, writeErr := file.Write(torn)
	closeErr := file.Close()
	if err := errors.Join(writeErr, closeErr); err != nil {
		return "", err
	}
	return fmt.Sprintf("appended a torn line to %s (%d of %d bytes, no newline)", filepath.Base(path), len(torn), len(last)+1), nil
}

// copyTree copies the regular files under src to dst.
func copyTree(src, dst string) error {
	return filepath.WalkDir(src, func(path string, entry os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		rel, err := filepath.Rel(src, path)
		if err != nil {
			return err
		}
		target := filepath.Join(dst, rel)
		if entry.IsDir() {
			return os.MkdirAll(target, 0o755)
		}
		if !entry.Type().IsRegular() {
			return nil
		}
		return copyFile(path, target)
	})
}

func copyFile(src, dst string) error {
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	out, err := os.OpenFile(dst, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0o600)
	if err != nil {
		return err
	}
	_, copyErr := io.Copy(out, in)
	return errors.Join(copyErr, out.Close())
}
