package main

// Verification goes through the agentgate-verify command-line program given
// by -verify (the frozen build or one built from the same sources), never
// through the verifier package: the suite judges evidence exactly as an
// outside auditor would. The report is read from its --json output.

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os/exec"
	"sort"
	"strings"
	"time"
)

// verifierReport is the part of the CLI's JSON report the suite reads.
type verifierReport struct {
	Verdict   string   `json:"verdict"`
	Assurance string   `json:"assurance"`
	Missing   []string `json:"missing"`
	Segments  []struct {
		Index   int    `json:"index"`
		RunID   string `json:"run_id"`
		Entries int    `json:"entries"`
	} `json:"segments"`
	Counts struct {
		Entries         int `json:"entries"`
		Operations      int `json:"operations"`
		Effects         int `json:"effects"`
		ProviderEffects int `json:"provider_effects"`
		Flagged         int `json:"flagged"`
		Reconciled      int `json:"reconciled"`
		Unresolved      int `json:"unresolved"`
	} `json:"counts"`
	Failures   []reportedCheck     `json:"failures"`
	Warnings   []reportedCheck     `json:"warnings"`
	Operations []verifiedOperation `json:"operations"`
}

// reportedCheck is one failing or warning item of the report.
type reportedCheck struct {
	ID     string `json:"id"`
	Seq    uint64 `json:"seq"`
	Detail string `json:"detail"`
}

type verifiedOperation struct {
	OperationID    string `json:"operation_id"`
	EffectType     string `json:"effect_type"`
	Status         string `json:"status"`
	Flagged        bool   `json:"flagged"`
	Reconciled     bool   `json:"reconciled,omitempty"`
	ReportedStatus string `json:"reported_status,omitempty"`
	// ClassificationEvidence is what the operation's classification (its
	// flag) rests on, as the verifier reports it (auditverify
	// OperationReport.ClassificationEvidence: issuer_adapter,
	// issuer_only_reconciled, ...); empty from a verifier build without it.
	ClassificationEvidence string `json:"classification_evidence,omitempty"`
}

// verifyOutcome is the verifier's answer on one evidence folder.
type verifyOutcome struct {
	Folder    string   `json:"folder"`
	Anchors   string   `json:"anchors"`
	ExitCode  int      `json:"exit_code"`
	Verdict   string   `json:"verdict,omitempty"`
	Assurance string   `json:"assurance,omitempty"`
	Failing   []string `json:"failing_checks"`
	Findings  []string `json:"findings"`
	// Warning lists the check IDs the verifier warned about (warnings never
	// change the verdict); WarningFindings their details.
	Warning         []string            `json:"warning_checks"`
	WarningFindings []string            `json:"warning_findings"`
	Missing         []string            `json:"missing"`
	Segments        int                 `json:"segments_walked"`
	Entries         int                 `json:"entries"`
	Operations      []verifiedOperation `json:"operations,omitempty"`
	Error           string              `json:"error,omitempty"`
}

// verdictKey is "VERDICT/ASSURANCE" (or "ERROR").
func (v verifyOutcome) verdictKey() string {
	if v.Error != "" || v.Verdict == "" {
		return "ERROR"
	}
	return v.Verdict + "/" + v.Assurance
}

func (v verifyOutcome) operation(id string) (verifiedOperation, bool) {
	for _, op := range v.Operations {
		if op.OperationID == id {
			return op, true
		}
	}
	return verifiedOperation{}, false
}

// maxFindings bounds the failure details kept per verification.
const maxFindings = 10

// verifierCommand runs the CLI; tests replace extraEnv to point it at a
// stand-in.
type verifierCommand struct {
	path     string
	extraEnv []string
	timeout  time.Duration
}

// verify runs the CLI on dir with the given pins (empty pins are omitted).
func (v verifierCommand) verify(dir, display, keysSHA256, head string) verifyOutcome {
	anchors := []string{}
	args := []string{"--json", "--workers", "1"}
	if keysSHA256 != "" {
		args = append(args, "--expect-keys", keysSHA256)
		anchors = append(anchors, "keys")
	}
	if head != "" {
		args = append(args, "--expect-head", head)
		anchors = append(anchors, "head")
	}
	args = append(args, dir)
	out := verifyOutcome{Folder: display, Anchors: strings.Join(anchors, "+") + " pinned by the parent", Failing: []string{}, Findings: []string{},
		Warning: []string{}, WarningFindings: []string{}, Missing: []string{}}
	if len(anchors) == 0 {
		out.Anchors = "none"
	}
	ctx, cancel := context.WithTimeout(context.Background(), v.timeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, v.path, args...)
	if len(v.extraEnv) > 0 {
		cmd.Env = append(cmd.Environ(), v.extraEnv...)
	}
	var stdout, stderr bytes.Buffer
	cmd.Stdout, cmd.Stderr = &stdout, &stderr
	err := cmd.Run()
	out.ExitCode = 0
	var exit *exec.ExitError
	if errors.As(err, &exit) {
		out.ExitCode = exit.ExitCode()
	} else if err != nil {
		out.ExitCode, out.Error = -1, err.Error()
		return out
	}
	// Exit 0 is VERIFIED and 1 is FAILED, both with a report; 2 is a usage
	// or read error without one.
	if out.ExitCode != 0 && out.ExitCode != 1 {
		out.Error = fmt.Sprintf("agentgate-verify exit %d: %s", out.ExitCode, strings.TrimSpace(stderr.String()))
		return out
	}
	var report verifierReport
	if err := json.Unmarshal(stdout.Bytes(), &report); err != nil {
		out.Error = "agentgate-verify --json output: " + err.Error()
		return out
	}
	out.fromReport(report)
	return out
}

// fromReport copies what the suite keeps from one --json report.
func (out *verifyOutcome) fromReport(report verifierReport) {
	out.Verdict, out.Assurance = report.Verdict, report.Assurance
	out.Failing, out.Findings = checkIDs(report.Failures, out.Failing, out.Findings)
	out.Warning, out.WarningFindings = checkIDs(report.Warnings, out.Warning, out.WarningFindings)
	out.Missing = append(out.Missing, report.Missing...)
	out.Segments = len(report.Segments)
	if out.Segments == 0 {
		out.Segments = 1
	}
	out.Entries = report.Counts.Entries
	out.Operations = report.Operations
}

// checkIDs appends the distinct check IDs (sorted) and at most maxFindings
// details of checks.
func checkIDs(checks []reportedCheck, ids, findings []string) ([]string, []string) {
	seen := map[string]bool{}
	for index, check := range checks {
		if !seen[check.ID] {
			seen[check.ID] = true
			ids = append(ids, check.ID)
		}
		if index < maxFindings {
			findings = append(findings, fmt.Sprintf("%s #%d: %s", check.ID, check.Seq, check.Detail))
		} else if index == maxFindings {
			findings = append(findings, fmt.Sprintf("... %d more", len(checks)-maxFindings))
		}
	}
	sort.Strings(ids)
	return ids, findings
}
