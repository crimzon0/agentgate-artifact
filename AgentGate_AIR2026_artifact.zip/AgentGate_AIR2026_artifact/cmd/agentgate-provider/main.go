// Command agentgate-provider runs the simulated provider of one run in its own
// process, with its own Ed25519 key and its own durable state, outside the
// gateway (docs/demo/REVISION_CONTRACT.md R5). The gateway uses it through
// devcomposition.Config.ExternalProvider.
//
//	agentgate-provider -dir DIR -run-id HEX32 [-run-label RUN] \
//	    -tenant-id T -principal-id P -task-id K -registry-hash HEX64 \
//	    [-initial-state-hash HEX64] [-addr 127.0.0.1:0] [-stdin-shutdown]
//
// The run flags must equal the gateway's devcomposition.Config (RunID,
// TenantID, PrincipalID, TaskID, RegistrySnapshotObjectHash,
// InitialStateObjectHash); -initial-state-hash defaults to the empty
// provider state of the run. -run-label is the run_id string written into
// GET /journal (the demo's run-YYYYMMDD-… ID); it defaults to the hex run ID.
// On a restart with the same -dir and -run-id the other run flags may be
// omitted; given ones must match what is stored.
//
// Run at most one provider process per run directory at a time. Directory
// layout (keep it outside the gateway's run folders):
//
//	DIR/provider-key.json                  provider key, generated on first start (private)
//	DIR/runs/<run-id hex>/run.json         the run identity
//	DIR/runs/<run-id hex>/requests.jsonl   every state-changing request, synced before its answer
//
// HTTP (loopback clients only): the simulator endpoints of
// internal/simulator/http.go (POST /v1/messages, /v1/document-releases,
// /v1/financial-requests, their /status and /status/receipt), plus
//
//	GET /key      {"format":"agentgate-provider-key/v1","role":"SIMULATOR_PROVIDER","alg":"Ed25519",
//	               "kid":"<hex COSE kid>","public_key":"<std base64>","run":{…run identity…}}
//	GET /journal  provider-journal.json (CONTRACTS section 5.5)
//
// Once listening it prints one JSON ready line on stdout
// (headwitness.ReadyLine) and logs to stderr. -stdin-shutdown makes it exit
// cleanly when stdin closes (used by headwitness.StartProcess).
package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"time"

	"agentgate/internal/headwitness"
)

func main() { os.Exit(run()) }

func run() int {
	addr := flag.String("addr", "127.0.0.1:0", "loopback address to listen on (port 0 picks a free port)")
	dir := flag.String("dir", "", "provider directory (key and per-run state); created if missing")
	runIDHex := flag.String("run-id", "", "the run's 16-byte simulator run ID as 32 hex characters (devcomposition.Config.RunID)")
	runLabel := flag.String("run-label", "", "run_id string written into GET /journal (default: the hex run ID)")
	tenantID := flag.String("tenant-id", "", "tenant ID of the gateway identity")
	principalID := flag.String("principal-id", "", "principal ID of the agent")
	taskID := flag.String("task-id", "", "task ID of the run")
	registryHex := flag.String("registry-hash", "", "registry snapshot object hash, 64 hex characters")
	initialHex := flag.String("initial-state-hash", "", "initial state object hash, 64 hex characters (default: empty provider state)")
	stdinShutdown := flag.Bool("stdin-shutdown", false, "exit cleanly when stdin closes")
	flag.Parse()
	log.SetFlags(log.Ltime)
	log.SetPrefix("agentgate-provider: ")
	if *dir == "" || *runIDHex == "" || flag.NArg() != 0 {
		fmt.Fprintln(os.Stderr, "usage: agentgate-provider -dir DIR -run-id HEX32 [-run-label RUN] -tenant-id T -principal-id P -task-id K -registry-hash HEX64 [-initial-state-hash HEX64] [-addr 127.0.0.1:0] [-stdin-shutdown]")
		return 2
	}
	identity := RunIdentity{RunLabel: *runLabel, TaskID: *taskID, TenantID: *tenantID, PrincipalID: *principalID}
	if err := decodeHex(*runIDHex, identity.RunID[:]); err != nil {
		log.Printf("-run-id: %v", err)
		return 2
	}
	if *registryHex != "" {
		if err := decodeHex(*registryHex, identity.RegistrySnapshotObjectHash[:]); err != nil {
			log.Printf("-registry-hash: %v", err)
			return 2
		}
	}
	if *initialHex != "" {
		if err := decodeHex(*initialHex, identity.InitialStateObjectHash[:]); err != nil {
			log.Printf("-initial-state-hash: %v", err)
			return 2
		}
	}
	if err := requireLoopback(*addr); err != nil {
		log.Print(err)
		return 2
	}

	listener, err := net.Listen("tcp", *addr)
	if err != nil {
		log.Print(err)
		return 1
	}
	host := listener.Addr().String()
	service, err := Open(context.Background(), Options{Dir: *dir, AllowedHost: host, Identity: identity, Logf: log.Printf})
	if err != nil {
		_ = listener.Close()
		log.Print(err)
		return 1
	}
	defer service.Close()
	server := &http.Server{Handler: service, ReadHeaderTimeout: 5 * time.Second}
	served := make(chan error, 1)
	go func() { served <- server.Serve(listener) }()

	key := service.KeyDocument()
	ready, _ := json.Marshal(headwitness.ReadyLine{
		Ready: "agentgate-provider", Origin: "http://" + host, Role: key.Role,
		KID: key.KID, PublicKey: key.PublicKey, PID: os.Getpid(),
	})
	fmt.Println(string(ready))
	log.Printf("listening on %s for run %s (%s), provider kid %s", host, key.Run.RunID, key.Run.RunLabel, key.KID)

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt)
	stdinClosed := make(chan struct{})
	if *stdinShutdown {
		go func() {
			_, _ = io.Copy(io.Discard, os.Stdin)
			close(stdinClosed)
		}()
	}
	status := 0
	select {
	case err := <-served:
		if !errors.Is(err, http.ErrServerClosed) {
			log.Print(err)
			status = 1
		}
	case err := <-service.Fatal():
		log.Printf("%v; stopping so a restart resumes from the stored state", err)
		status = 1
	case <-stop:
	case <-stdinClosed:
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	_ = server.Shutdown(ctx)
	log.Print("stopped")
	return status
}

// requireLoopback refuses a listen address whose host is not a loopback IP.
func requireLoopback(addr string) error {
	host, _, err := net.SplitHostPort(addr)
	if err != nil {
		return fmt.Errorf("invalid -addr %q: %w", addr, err)
	}
	if ip := net.ParseIP(host); ip == nil || !ip.IsLoopback() {
		return fmt.Errorf("-addr %q must be a numeric loopback address such as 127.0.0.1:0", addr)
	}
	return nil
}
