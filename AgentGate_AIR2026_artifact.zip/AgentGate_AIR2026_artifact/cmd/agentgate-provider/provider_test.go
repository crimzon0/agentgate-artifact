package main

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"agentgate/internal/devcomposition"
	"agentgate/internal/effects"
	"agentgate/internal/mcp"
	"agentgate/internal/signed"
	"agentgate/internal/simulator"
)

const testBearer = "dev.gateway.bearer.0123456789abcdef"

func testIdentity() RunIdentity {
	identity := RunIdentity{
		RunLabel: "run-20261007-120000-abcdef", TaskID: "graduation-demo",
		TenantID: "tenant-dev", PrincipalID: "student",
		RegistrySnapshotObjectHash: sha256.Sum256([]byte("DEV registry snapshot")),
	}
	for index := range identity.RunID {
		identity.RunID[index] = 0x70
	}
	return identity
}

// capturedRequest is one simulator request as it reached the provider.
type capturedRequest struct {
	path   string
	header http.Header
	body   []byte
}

// runningProvider is a provider Service behind a real loopback listener.
type runningProvider struct {
	service  *Service
	origin   string
	mu       sync.Mutex
	captured []capturedRequest
	stop     func()
}

func startProvider(t *testing.T, dir string, identity RunIdentity) *runningProvider {
	t.Helper()
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	service, err := Open(context.Background(), Options{Dir: dir, AllowedHost: listener.Addr().String(), Identity: identity})
	if err != nil {
		_ = listener.Close()
		t.Fatal(err)
	}
	provider := &runningProvider{service: service, origin: "http://" + listener.Addr().String()}
	server := &http.Server{ReadHeaderTimeout: 2 * time.Second, Handler: http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodPost {
			body, _ := io.ReadAll(r.Body)
			r.Body = io.NopCloser(bytes.NewReader(body))
			provider.mu.Lock()
			provider.captured = append(provider.captured, capturedRequest{r.URL.Path, r.Header.Clone(), body})
			provider.mu.Unlock()
		}
		service.ServeHTTP(w, r)
	})}
	done := make(chan error, 1)
	go func() { done <- server.Serve(listener) }()
	var once sync.Once
	provider.stop = func() {
		once.Do(func() {
			ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
			defer cancel()
			_ = server.Shutdown(ctx)
			<-done
			_ = service.Close()
		})
	}
	t.Cleanup(provider.stop)
	return provider
}

func (p *runningProvider) get(t *testing.T, path string) []byte {
	t.Helper()
	response, err := http.Get(p.origin + path)
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	body, err := io.ReadAll(response.Body)
	if err != nil || response.StatusCode != http.StatusOK {
		t.Fatalf("GET %s: HTTP %d %v", path, response.StatusCode, err)
	}
	return body
}

func (p *runningProvider) journal(t *testing.T) journalDocument {
	t.Helper()
	var journal journalDocument
	if err := json.Unmarshal(p.get(t, "/journal"), &journal); err != nil {
		t.Fatal(err)
	}
	return journal
}

// newGateway composes a real gateway that uses the provider process.
func newGateway(t *testing.T, provider *runningProvider) *devcomposition.Composition {
	t.Helper()
	identity := provider.service.identity
	bearer, err := devcomposition.NewGatewayBearerSecret(testBearer)
	if err != nil {
		t.Fatal(err)
	}
	external, _, err := devcomposition.FetchExternalProvider(context.Background(), provider.origin)
	if err != nil {
		t.Fatal(err)
	}
	if external.KID != provider.service.KID() {
		t.Fatal("GET /key does not report the provider's own key")
	}
	operations := map[[16]byte]devcomposition.OperationRule{}
	for fill := byte(1); fill <= 4; fill++ {
		effectType := effects.ExternalMessageSend
		if fill == 2 {
			effectType = effects.FinancialRequestCreate
		}
		operations[operation(fill)] = devcomposition.OperationRule{EffectType: effectType, Outcome: devcomposition.OutcomeAllow}
	}
	composition, err := devcomposition.New(context.Background(), devcomposition.Config{
		Identity: mcp.Identity{
			TenantID: identity.TenantID, PrincipalID: identity.PrincipalID, Issuer: "https://identity.dev.example",
			Roles: []string{"MEMBER"}, AuthEpoch: 1, TokenHash: sha256.Sum256([]byte("DEV OAuth token")),
		},
		GatewayBearer: bearer, RunID: identity.RunID, TaskID: identity.TaskID,
		RegistrySnapshotObjectHash: identity.RegistrySnapshotObjectHash, InitialStateObjectHash: identity.InitialStateObjectHash,
		Recipients: map[string]effects.Recipient{
			"reviewer": {PrincipalID: "reviewer", DeliveryAddress: "reviewer@example.test", External: true},
		},
		PayeeDisplayNames: map[string]string{"supplier": "Synthetic Supplier"},
		Operations:        operations,
		ExternalProvider:  &external,
	})
	if err != nil {
		t.Fatal(err)
	}
	return composition
}

func operation(fill byte) [16]byte {
	var id [16]byte
	for index := range id {
		id[index] = fill
	}
	return id
}

func operationText(fill byte) string {
	id := operation(fill)
	return base64.RawURLEncoding.EncodeToString(id[:])
}

func sendMessage(t *testing.T, gateway *devcomposition.Composition, fill byte, subject string) {
	t.Helper()
	callTool(t, gateway.MCP, "external_message.send", map[string]any{
		"operation_id": operationText(fill),
		"to":           []string{"reviewer"}, "subject": subject, "body": "Synthetic message through the provider process.",
	})
}

func callTool(t *testing.T, handler http.Handler, tool string, arguments map[string]any) map[string]any {
	t.Helper()
	body, err := json.Marshal(map[string]any{
		"jsonrpc": "2.0", "id": 1, "method": "tools/call",
		"params": map[string]any{
			"name": tool, "arguments": arguments,
			"_meta": map[string]any{
				"io.modelcontextprotocol/protocolVersion":    mcp.ProtocolVersion,
				"io.modelcontextprotocol/clientCapabilities": map[string]any{},
				"io.modelcontextprotocol/clientInfo":         map[string]any{"name": "provider-test", "version": "1"},
			},
		},
	})
	if err != nil {
		t.Fatal(err)
	}
	request := httptest.NewRequest(http.MethodPost, "http://gateway.dev/mcp", bytes.NewReader(body))
	request.Header.Set("Content-Type", "application/json")
	request.Header.Set("Accept", "application/json, text/event-stream")
	request.Header.Set("MCP-Protocol-Version", mcp.ProtocolVersion)
	request.Header.Set("Mcp-Method", "tools/call")
	request.Header.Set("Mcp-Name", tool)
	request.Header.Set("Authorization", "Bearer "+testBearer)
	response := httptest.NewRecorder()
	handler.ServeHTTP(response, request)
	var rpc struct {
		Error  any `json:"error"`
		Result struct {
			IsError           bool           `json:"isError"`
			StructuredContent map[string]any `json:"structuredContent"`
		} `json:"result"`
	}
	if response.Code != http.StatusOK || json.Unmarshal(response.Body.Bytes(), &rpc) != nil || rpc.Error != nil || rpc.Result.IsError {
		t.Fatalf("%s failed: HTTP %d %s", tool, response.Code, response.Body.String())
	}
	return rpc.Result.StructuredContent
}

type receiptResolver struct {
	kid    [32]byte
	public ed25519.PublicKey
}

func (r receiptResolver) Resolve(kid [32]byte, role string, _ uint64) (ed25519.PublicKey, bool) {
	return r.public, kid == r.kid && role == providerRole
}

func decodeReceipt(t *testing.T, provider *runningProvider, encoded string) simulator.SimulatorReceipt {
	t.Helper()
	raw, err := base64.StdEncoding.DecodeString(encoded)
	if err != nil {
		t.Fatal(err)
	}
	var receipt simulator.SimulatorReceipt
	profile := signed.Profile{ContentType: "application/agentgate-provider-receipt+cbor", Token: "SimulatorReceipt", Role: providerRole}
	if _, err := signed.Verify(raw, profile, receiptResolver{provider.service.KID(), provider.service.PublicKey()}, 0, &receipt); err != nil {
		t.Fatal(err)
	}
	return receipt
}

func TestProviderRestartKeepsStateKeyAndIdempotency(t *testing.T) {
	dir := t.TempDir()
	first := startProvider(t, dir, testIdentity())
	gateway := newGateway(t, first)
	sendMessage(t, gateway, 1, "Before the restart")
	callTool(t, gateway.MCP, "financial_request.create", map[string]any{
		"operation_id": operationText(2),
		"payee_id":     "supplier", "amount_minor": uint64(12500), "currency": "AED", "purpose": "Synthetic equipment request",
	})
	snapshot, err := gateway.Snapshot()
	if err != nil || snapshot.CurrentCommitSeq != 2 {
		t.Fatalf("gateway snapshot over GET /journal: seq=%d err=%v", snapshot.CurrentCommitSeq, err)
	}
	journalBefore := first.get(t, "/journal")
	keyBefore := first.get(t, "/key")
	var dispatch *capturedRequest
	for index := range first.captured {
		if first.captured[index].path == "/v1/messages" {
			dispatch = &first.captured[index]
		}
	}
	if dispatch == nil {
		t.Fatal("the gateway never dispatched the message to the provider process")
	}
	first.stop()

	// Restart with only the run ID: the identity comes from run.json and the
	// state from replaying requests.jsonl, on a different port.
	second := startProvider(t, dir, RunIdentity{RunID: testIdentity().RunID})
	if got := second.get(t, "/key"); !bytes.Equal(got, keyBefore) {
		t.Fatalf("restart changed the provider key or run:\n%s\n%s", keyBefore, got)
	}
	if got := second.get(t, "/journal"); !bytes.Equal(got, journalBefore) {
		t.Fatalf("restart changed the provider journal:\n%s\n%s", journalBefore, got)
	}

	// An exact retry of the first dispatch after the restart returns the
	// stored receipt and commits nothing new.
	retry, err := http.NewRequest(http.MethodPost, second.origin+dispatch.path, bytes.NewReader(dispatch.body))
	if err != nil {
		t.Fatal(err)
	}
	retry.Header = dispatch.header.Clone()
	// The simulator refuses unknown headers, so do not let the client add
	// Accept-Encoding (the gateway's adapter transport does the same).
	client := &http.Client{Transport: &http.Transport{DisableCompression: true}}
	response, err := client.Do(retry)
	if err != nil {
		t.Fatal(err)
	}
	retryBody, _ := io.ReadAll(response.Body)
	response.Body.Close()
	journal := second.journal(t)
	if response.StatusCode != http.StatusOK || base64.StdEncoding.EncodeToString(retryBody) != journal.Entries[0].SignedReceipt || journal.CommitSeq != 2 {
		t.Fatalf("retry after restart: HTTP %d, commit_seq %d", response.StatusCode, journal.CommitSeq)
	}

	// A new gateway instance continues the same provider state chain.
	gateway2 := newGateway(t, second)
	sendMessage(t, gateway2, 3, "After the restart")
	journal = second.journal(t)
	if journal.CommitSeq != 3 || len(journal.Entries) != 3 {
		t.Fatalf("after restart: commit_seq %d, %d entries", journal.CommitSeq, len(journal.Entries))
	}
	previous := decodeReceipt(t, second, journal.Entries[1].SignedReceipt)
	next := decodeReceipt(t, second, journal.Entries[2].SignedReceipt)
	if next.StateBeforeHash != previous.StateAfterHash || next.CommittedAt < previous.CommittedAt || next.CommitSeq != 3 {
		t.Fatal("the provider state chain does not continue across the restart")
	}

	// And it survives a second restart too.
	second.stop()
	third := startProvider(t, dir, RunIdentity{RunID: testIdentity().RunID})
	if got := third.journal(t); got.CommitSeq != 3 || got.Entries[2].SignedReceipt != journal.Entries[2].SignedReceipt {
		t.Fatal("second restart lost provider state")
	}
}

func TestProviderStoredStateIsCheckedOnStart(t *testing.T) {
	dir := t.TempDir()
	identity := testIdentity()
	provider := startProvider(t, dir, identity)
	sendMessage(t, newGateway(t, provider), 1, "One effect")
	journalBefore := provider.get(t, "/journal")
	provider.stop()
	logPath := filepath.Join(dir, "runs", strings.Repeat("70", 16), requestFileName)

	// A torn last line (crash during an append, never acknowledged) is cut.
	appendFile(t, logPath, []byte(`{"seq":2,"path":"/v1/mess`))
	restarted := startProvider(t, dir, RunIdentity{RunID: identity.RunID})
	if got := restarted.get(t, "/journal"); !bytes.Equal(got, journalBefore) {
		t.Fatal("torn tail changed the provider state")
	}
	restarted.stop()

	// An edited record no longer replays to the same answer: refuse to start.
	original, err := os.ReadFile(logPath)
	if err != nil {
		t.Fatal(err)
	}
	var record requestRecord
	if err := json.Unmarshal(bytes.TrimSpace(original), &record); err != nil {
		t.Fatal(err)
	}
	record.Body[len(record.Body)-1] ^= 0x01
	edited, _ := json.Marshal(record)
	if err := os.WriteFile(logPath, append(edited, '\n'), 0o600); err != nil {
		t.Fatal(err)
	}
	listener, _ := net.Listen("tcp", "127.0.0.1:0")
	defer listener.Close()
	if _, err := Open(context.Background(), Options{Dir: dir, AllowedHost: listener.Addr().String(), Identity: RunIdentity{RunID: identity.RunID}}); err == nil || !strings.Contains(err.Error(), "does not replay") {
		t.Fatalf("an edited request log was accepted: %v", err)
	}
	if err := os.WriteFile(logPath, original, 0o600); err != nil {
		t.Fatal(err)
	}

	// A restart that names a different run identity is refused.
	other := identity
	other.TenantID = "another-tenant"
	if _, err := Open(context.Background(), Options{Dir: dir, AllowedHost: listener.Addr().String(), Identity: other}); err == nil || !strings.Contains(err.Error(), "tenant-id") {
		t.Fatalf("a different tenant was accepted for a stored run: %v", err)
	}
	// A first start needs the full identity.
	fresh := RunIdentity{RunID: operation(0x55)}
	if _, err := Open(context.Background(), Options{Dir: dir, AllowedHost: listener.Addr().String(), Identity: fresh}); err == nil || !strings.Contains(err.Error(), "first start") {
		t.Fatalf("a first start without the run identity was accepted: %v", err)
	}
}

func TestProviderServesLoopbackOnlyAndNoPrivateKey(t *testing.T) {
	provider := startProvider(t, t.TempDir(), testIdentity())
	request := httptest.NewRequest(http.MethodGet, "http://provider/key", nil)
	request.RemoteAddr = "192.0.2.1:4000"
	response := httptest.NewRecorder()
	provider.service.ServeHTTP(response, request)
	if response.Code != http.StatusNotFound {
		t.Fatalf("non-loopback client got HTTP %d", response.Code)
	}
	key := provider.get(t, "/key")
	if bytes.Contains(key, []byte("seed")) || bytes.Contains(key, []byte("private")) {
		t.Fatalf("GET /key exposes private material: %s", key)
	}
	journal := provider.journal(t)
	if journal.Format != journalFormat || journal.RunID != testIdentity().RunLabel || journal.CommitSeq != 0 || journal.Entries == nil {
		t.Fatalf("empty journal is wrong: %+v", journal)
	}
	empty, err := EmptyStateHash(testIdentity().RunID)
	if err != nil {
		t.Fatal(err)
	}
	if journal.StateHash != hex.EncodeToString(empty[:]) {
		t.Fatal("the provider did not start from the empty state of its run")
	}
}

func appendFile(t *testing.T, path string, data []byte) {
	t.Helper()
	file, err := os.OpenFile(path, os.O_APPEND|os.O_WRONLY, 0o600)
	if err != nil {
		t.Fatal(err)
	}
	defer file.Close()
	if _, err := file.Write(data); err != nil {
		t.Fatal(err)
	}
}
