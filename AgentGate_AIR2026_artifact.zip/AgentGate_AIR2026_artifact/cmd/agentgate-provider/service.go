package main

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"path/filepath"
	"sort"
	"sync"
	"time"

	"agentgate/internal/signed"
	"agentgate/internal/simulator"
)

const (
	// maxRequestBytes mirrors the simulator's own request limit.
	maxRequestBytes = 128 << 10

	// keyDocumentFormat and journalFormat are the GET /key and GET /journal
	// formats (the journal is CONTRACTS section 5.5).
	keyDocumentFormat = "agentgate-provider-key/v1"
	journalFormat     = "agentgate-provider-journal/v1"
)

// Options configures Open.
type Options struct {
	// Dir is the provider directory (key + per-run state). Created if missing.
	Dir string
	// AllowedHost is the exact host:port of the listener; the simulator
	// accepts only requests whose Host header equals it.
	AllowedHost string
	// Identity selects the run. RunID is required; on first start the other
	// fields are required too (InitialStateObjectHash defaults to the empty
	// state, RunLabel to the run ID in hex); later starts may leave them zero.
	Identity RunIdentity
	// Now is the wall clock; nil means time.Now.
	Now func() time.Time
	// Logf receives progress messages; nil discards them.
	Logf func(format string, args ...any)
}

// Service is the simulated provider of one run in its own process: the
// simulator runtime with the provider's own key, made durable by replaying
// requests.jsonl on start.
//
// Every request is handled under one mutex: the simulator runs, the request
// is appended to requests.jsonl and synced if it read the clock (that is, if
// it may have changed provider state), and only then is the answer sent. A
// crash therefore never loses a receipt a client has seen; if the append
// itself fails the service stops answering (503) and Fatal reports it, so the
// process restarts from what is on disk.
type Service struct {
	mu        sync.Mutex
	identity  RunIdentity
	kid       [32]byte
	public    ed25519.PublicKey
	runtime   *simulator.Runtime
	simulator http.Handler
	clock     *persistentClock
	log       *requestLog
	host      string
	failure   error
	fatal     chan error
}

// Open loads (or creates) the provider key and the run's state and replays
// every stored request. It refuses to open if a stored request no longer
// produces the same answer (damaged or edited state).
func Open(ctx context.Context, options Options) (*Service, error) {
	if options.Dir == "" || options.AllowedHost == "" {
		return nil, errors.New("provider: a directory and the listener host are required")
	}
	if options.Identity.RunID == ([16]byte{}) {
		return nil, errors.New("provider: -run-id is required")
	}
	now := options.Now
	if now == nil {
		now = time.Now
	}
	logf := options.Logf
	if logf == nil {
		logf = func(string, ...any) {}
	}
	private, kid, err := loadOrCreateKey(filepath.Join(options.Dir, keyFileName))
	if err != nil {
		return nil, fmt.Errorf("provider: %w", err)
	}
	runDir := filepath.Join(options.Dir, "runs", hex.EncodeToString(options.Identity.RunID[:]))
	identity, err := resolveRun(runDir, options.Identity, now())
	if err != nil {
		return nil, fmt.Errorf("provider: %w", err)
	}
	clock := &persistentClock{now: now}
	runtime, err := simulator.NewContext(ctx, simulator.Config{
		Environment:                simulator.EnvironmentDEV,
		RunID:                      identity.RunID,
		TaskID:                     identity.TaskID,
		TenantID:                   identity.TenantID,
		PrincipalID:                identity.PrincipalID,
		RegistrySnapshotObjectHash: identity.RegistrySnapshotObjectHash,
		InitialStateObjectHash:     identity.InitialStateObjectHash,
		Signer:                     signed.Signer{KID: kid, Role: providerRole, Private: private},
		Clock:                      clock,
	})
	if err != nil {
		return nil, fmt.Errorf("provider: simulator: %w", err)
	}
	handler, err := simulator.NewHandler(runtime, simulator.HandlerConfig{AllowedHost: options.AllowedHost})
	if err != nil {
		return nil, fmt.Errorf("provider: simulator handler: %w", err)
	}
	log, records, err := openRequestLog(filepath.Join(runDir, requestFileName))
	if err != nil {
		return nil, fmt.Errorf("provider: %w", err)
	}
	service := &Service{
		identity: identity, kid: kid, public: private.Public().(ed25519.PublicKey),
		runtime: runtime, simulator: handler, clock: clock, log: log,
		host: options.AllowedHost, fatal: make(chan error, 1),
	}
	replayContext := context.WithoutCancel(ctx)
	for _, record := range records {
		answer, _, err := service.handleLocked(replayRequest(replayContext, record, options.AllowedHost), record.Clock)
		if err != nil || answer.status != record.Status || answer.digest() != record.ResponseSHA256 {
			_ = log.close()
			return nil, fmt.Errorf("provider: %s record %d does not replay to the same answer; the stored provider state is damaged", requestFileName, record.Seq)
		}
	}
	if len(records) > 0 {
		logf("replayed %d stored requests for run %x", len(records), identity.RunID)
	}
	return service, nil
}

// Close closes the request log; later requests get 503.
func (s *Service) Close() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.failure == nil {
		s.failure = errors.New("provider closed")
	}
	return s.log.close()
}

// Fatal delivers the storage error after which the service stopped answering.
func (s *Service) Fatal() <-chan error { return s.fatal }

// KID is the COSE kid of the provider signing key.
func (s *Service) KID() [32]byte { return s.kid }

// PublicKey returns a copy of the provider verification key.
func (s *Service) PublicKey() ed25519.PublicKey { return append(ed25519.PublicKey(nil), s.public...) }

// ServeHTTP serves the simulator endpoints (POST, internal/simulator/http.go)
// plus GET /key and GET /journal, to loopback clients only.
func (s *Service) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if ip := net.ParseIP(host); err != nil || ip == nil || !ip.IsLoopback() {
		http.NotFound(w, r)
		return
	}
	switch {
	case r.Method == http.MethodGet && r.URL.Path == "/key" && r.URL.RawQuery == "":
		writeJSON(w, s.KeyDocument())
	case r.Method == http.MethodGet && r.URL.Path == "/journal" && r.URL.RawQuery == "":
		journal, err := s.Journal()
		if err != nil {
			http.Error(w, "provider journal unavailable", http.StatusServiceUnavailable)
			return
		}
		writeJSON(w, journal)
	case r.Method == http.MethodPost:
		s.serveSimulator(w, r)
	default:
		http.NotFound(w, r)
	}
}

func (s *Service) serveSimulator(w http.ResponseWriter, r *http.Request) {
	body, err := io.ReadAll(io.LimitReader(r.Body, maxRequestBytes+1))
	if err != nil {
		writeEmpty(w, http.StatusBadRequest)
		return
	}
	r.Body = io.NopCloser(bytes.NewReader(body))
	// A client that hangs up must not abort the simulator half-way: the
	// stored request has to replay to the same answer later.
	r = r.WithContext(context.WithoutCancel(r.Context()))

	s.mu.Lock()
	defer s.mu.Unlock()
	if s.failure != nil {
		writeEmpty(w, http.StatusServiceUnavailable)
		return
	}
	answer, used, err := s.handleLocked(r, nil)
	if err == nil && len(used) > 0 {
		err = s.log.append(requestRecord{
			Path: r.URL.Path, Header: r.Header.Clone(), Body: body, Clock: used,
			Status: answer.status, ResponseSHA256: answer.digest(),
		})
	}
	if err != nil {
		// The runtime may have committed something that is not on disk.
		// Answer non-authoritatively (the gateway treats 503 as an unknown
		// outcome and reconciles) and stop until restarted from disk.
		s.failure = err
		select {
		case s.fatal <- fmt.Errorf("provider: cannot persist request: %w", err):
		default:
		}
		writeEmpty(w, http.StatusServiceUnavailable)
		return
	}
	answer.writeTo(w)
}

// handleLocked runs one request through the simulator with the clock live
// (replay nil) or replaying the given readings. The caller holds s.mu (or is
// Open, before the service is shared).
func (s *Service) handleLocked(request *http.Request, replay []clockReading) (*bufferedAnswer, []clockReading, error) {
	s.clock.begin(replay)
	answer := &bufferedAnswer{header: http.Header{}, status: http.StatusOK}
	s.simulator.ServeHTTP(answer, request)
	used, err := s.clock.end()
	return answer, used, err
}

// replayRequest rebuilds a stored request as the simulator handler sees it.
func replayRequest(ctx context.Context, record requestRecord, host string) *http.Request {
	request := &http.Request{
		Method: http.MethodPost, URL: &url.URL{Path: record.Path}, RequestURI: record.Path,
		Proto: "HTTP/1.1", ProtoMajor: 1, ProtoMinor: 1,
		Header: http.Header(record.Header).Clone(), Host: host, RemoteAddr: "127.0.0.1:0",
		Body: io.NopCloser(bytes.NewReader(record.Body)), ContentLength: int64(len(record.Body)),
	}
	if request.Header == nil {
		request.Header = http.Header{}
	}
	return request.WithContext(ctx)
}

// --- GET /key and GET /journal ----------------------------------------------

// keyDocument is the GET /key answer. devcomposition.ProviderKeyDocument
// reads the same JSON.
type keyDocument struct {
	Format    string      `json:"format"`
	Role      string      `json:"role"`
	Alg       string      `json:"alg"`
	KID       string      `json:"kid"` // hex COSE kid of the provider receipts
	PublicKey string      `json:"public_key"`
	Run       runDocument `json:"run"`
}

type runDocument struct {
	RunID                      string `json:"run_id"` // hex of the 16-byte simulator run ID
	RunLabel                   string `json:"run_label"`
	SimulatorID                string `json:"simulator_id"`
	TaskID                     string `json:"task_id"`
	TenantID                   string `json:"tenant_id"`
	PrincipalID                string `json:"principal_id"`
	RegistrySnapshotObjectHash string `json:"registry_snapshot_object_hash"`
	InitialStateObjectHash     string `json:"initial_state_object_hash"`
}

// KeyDocument returns the GET /key answer.
func (s *Service) KeyDocument() keyDocument {
	identity := s.identity
	return keyDocument{
		Format: keyDocumentFormat, Role: providerRole, Alg: "Ed25519",
		KID: hex.EncodeToString(s.kid[:]), PublicKey: base64.StdEncoding.EncodeToString(s.public),
		Run: runDocument{
			RunID: hex.EncodeToString(identity.RunID[:]), RunLabel: identity.RunLabel, SimulatorID: simulator.SimulatorID,
			TaskID: identity.TaskID, TenantID: identity.TenantID, PrincipalID: identity.PrincipalID,
			RegistrySnapshotObjectHash: hex.EncodeToString(identity.RegistrySnapshotObjectHash[:]),
			InitialStateObjectHash:     hex.EncodeToString(identity.InitialStateObjectHash[:]),
		},
	}
}

// journalDocument is provider-journal.json (CONTRACTS section 5.5).
type journalDocument struct {
	Format      string         `json:"format"`
	RunID       string         `json:"run_id"`
	SimulatorID string         `json:"simulator_id"`
	CommitSeq   uint64         `json:"commit_seq"`
	StateHash   string         `json:"state_hash"`
	Entries     []journalEntry `json:"entries"`
}

type journalEntry struct {
	CommitSeq     uint64 `json:"commit_seq"`
	SignedReceipt string `json:"signed_receipt"`
}

// Journal returns the provider's own record of every committed effect.
func (s *Service) Journal() (journalDocument, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.failure != nil {
		// After a storage failure the runtime may hold a commit that is not
		// on disk; never show it.
		return journalDocument{}, s.failure
	}
	snapshot, err := s.runtime.Snapshot()
	if err != nil {
		return journalDocument{}, err
	}
	journal := journalDocument{
		Format: journalFormat, RunID: s.identity.RunLabel, SimulatorID: snapshot.SimulatorID,
		CommitSeq: snapshot.CurrentCommitSeq, StateHash: hex.EncodeToString(snapshot.CanonicalStateHash[:]),
		Entries: []journalEntry{},
	}
	sequences := make([]uint64, 0, len(snapshot.Journal))
	for sequence := range snapshot.Journal {
		sequences = append(sequences, sequence)
	}
	sort.Slice(sequences, func(i, j int) bool { return sequences[i] < sequences[j] })
	for _, sequence := range sequences {
		journal.Entries = append(journal.Entries, journalEntry{
			CommitSeq: sequence, SignedReceipt: base64.StdEncoding.EncodeToString(snapshot.Journal[sequence]),
		})
	}
	return journal, nil
}

// --- buffered answers -----------------------------------------------------------

// bufferedAnswer holds the simulator's answer until the request is on disk.
type bufferedAnswer struct {
	header      http.Header
	status      int
	wroteHeader bool
	body        bytes.Buffer
}

func (a *bufferedAnswer) Header() http.Header { return a.header }

func (a *bufferedAnswer) WriteHeader(status int) {
	if !a.wroteHeader {
		a.status, a.wroteHeader = status, true
	}
}

func (a *bufferedAnswer) Write(data []byte) (int, error) {
	a.WriteHeader(http.StatusOK)
	return a.body.Write(data)
}

// digest is what requests.jsonl stores: SHA-256 over the content type, the
// provider reference and the body, so replay must reproduce the exact
// signed receipt.
func (a *bufferedAnswer) digest() string {
	hash := sha256.New()
	hash.Write([]byte(a.header.Get("Content-Type")))
	hash.Write([]byte{0})
	hash.Write([]byte(a.header.Get("X-Agentgate-Provider-Reference")))
	hash.Write([]byte{0})
	hash.Write(a.body.Bytes())
	return hex.EncodeToString(hash.Sum(nil))
}

func (a *bufferedAnswer) writeTo(w http.ResponseWriter) {
	for name, values := range a.header {
		w.Header()[name] = append([]string(nil), values...)
	}
	w.WriteHeader(a.status)
	_, _ = w.Write(a.body.Bytes())
}

func writeEmpty(w http.ResponseWriter, status int) {
	w.Header()["Content-Length"] = []string{"0"}
	w.WriteHeader(status)
}

func writeJSON(w http.ResponseWriter, value any) {
	data, err := json.Marshal(value)
	if err != nil {
		http.Error(w, "encode answer", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(append(data, '\n'))
}
