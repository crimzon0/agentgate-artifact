package main

import (
	"bufio"
	"bytes"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sync"
	"time"

	"agentgate/internal/canon"
	"agentgate/internal/simulator"
)

// Files inside the provider directory:
//
//	provider-key.json            the provider's Ed25519 key (generated on first start; private)
//	runs/<run-id hex>/run.json   the run identity this provider serves
//	runs/<run-id hex>/requests.jsonl
//	                             every state-changing request, synced before its answer
const (
	keyFileName     = "provider-key.json"
	runFileName     = "run.json"
	requestFileName = "requests.jsonl"

	keyFileFormat = "agentgate-provider-key-file/v1"
	runFileFormat = "agentgate-provider-run/v1"
	providerRole  = "SIMULATOR_PROVIDER"
)

// --- provider key -----------------------------------------------------------

type keyFile struct {
	Format    string `json:"format"`
	Role      string `json:"role"`
	Alg       string `json:"alg"`
	KID       string `json:"kid"` // COSE kid: simulator.ProviderKID(public)
	PublicKey string `json:"public_key"`
	Seed      string `json:"private_key_seed"`
}

// loadOrCreateKey returns the provider key stored at path, generating and
// storing a fresh one on first start.
func loadOrCreateKey(path string) (ed25519.PrivateKey, [32]byte, error) {
	data, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		public, private, err := ed25519.GenerateKey(rand.Reader)
		if err != nil {
			return nil, [32]byte{}, err
		}
		kid, err := simulator.ProviderKID(public)
		if err != nil {
			return nil, [32]byte{}, err
		}
		encoded, err := json.MarshalIndent(keyFile{
			Format: keyFileFormat, Role: providerRole, Alg: "Ed25519", KID: hex.EncodeToString(kid[:]),
			PublicKey: base64.StdEncoding.EncodeToString(public),
			Seed:      base64.StdEncoding.EncodeToString(private.Seed()),
		}, "", "  ")
		if err != nil {
			return nil, [32]byte{}, err
		}
		// The provider directory is created on first start.
		if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
			return nil, [32]byte{}, err
		}
		if err := writeFileAtomic(path, append(encoded, '\n')); err != nil {
			return nil, [32]byte{}, fmt.Errorf("write %s: %w", keyFileName, err)
		}
		return private, kid, nil
	}
	if err != nil {
		return nil, [32]byte{}, fmt.Errorf("read %s: %w", keyFileName, err)
	}
	var document keyFile
	if err := decodeStrict(data, &document); err != nil {
		return nil, [32]byte{}, fmt.Errorf("%s: %w", keyFileName, err)
	}
	seed, err := base64.StdEncoding.DecodeString(document.Seed)
	if document.Format != keyFileFormat || document.Role != providerRole || err != nil || len(seed) != ed25519.SeedSize {
		return nil, [32]byte{}, fmt.Errorf("%s is malformed", keyFileName)
	}
	private := ed25519.NewKeyFromSeed(seed)
	public := private.Public().(ed25519.PublicKey)
	kid, err := simulator.ProviderKID(public)
	if err != nil || document.KID != hex.EncodeToString(kid[:]) || document.PublicKey != base64.StdEncoding.EncodeToString(public) {
		return nil, [32]byte{}, fmt.Errorf("%s public key or kid does not match its seed", keyFileName)
	}
	return private, kid, nil
}

// --- run identity -------------------------------------------------------------

// RunIdentity is everything the simulator runtime needs to serve one run. It
// must equal the gateway's devcomposition.Config values, otherwise the
// simulator rejects the gateway's requests.
type RunIdentity struct {
	RunID                      [16]byte
	RunLabel                   string // the run_id string written into GET /journal (e.g. the demo's run-… ID)
	TaskID                     string
	TenantID                   string
	PrincipalID                string
	RegistrySnapshotObjectHash [32]byte
	InitialStateObjectHash     [32]byte
}

// runFile is runs/<hex>/run.json.
type runFile struct {
	Format                     string `json:"format"`
	RunID                      string `json:"run_id"`
	RunLabel                   string `json:"run_label"`
	TaskID                     string `json:"task_id"`
	TenantID                   string `json:"tenant_id"`
	PrincipalID                string `json:"principal_id"`
	RegistrySnapshotObjectHash string `json:"registry_snapshot_object_hash"`
	InitialStateObjectHash     string `json:"initial_state_object_hash"`
	CreatedAt                  string `json:"created_at"`
}

func (identity RunIdentity) file(now time.Time) runFile {
	return runFile{
		Format: runFileFormat, RunID: hex.EncodeToString(identity.RunID[:]), RunLabel: identity.RunLabel,
		TaskID: identity.TaskID, TenantID: identity.TenantID, PrincipalID: identity.PrincipalID,
		RegistrySnapshotObjectHash: hex.EncodeToString(identity.RegistrySnapshotObjectHash[:]),
		InitialStateObjectHash:     hex.EncodeToString(identity.InitialStateObjectHash[:]),
		CreatedAt:                  now.UTC().Format(time.RFC3339Nano),
	}
}

func (document runFile) identity() (RunIdentity, error) {
	var identity RunIdentity
	if document.Format != runFileFormat {
		return identity, fmt.Errorf("%s has format %q", runFileName, document.Format)
	}
	if err := decodeHex(document.RunID, identity.RunID[:]); err != nil {
		return identity, fmt.Errorf("%s run_id: %w", runFileName, err)
	}
	if err := decodeHex(document.RegistrySnapshotObjectHash, identity.RegistrySnapshotObjectHash[:]); err != nil {
		return identity, fmt.Errorf("%s registry hash: %w", runFileName, err)
	}
	if err := decodeHex(document.InitialStateObjectHash, identity.InitialStateObjectHash[:]); err != nil {
		return identity, fmt.Errorf("%s initial state hash: %w", runFileName, err)
	}
	identity.RunLabel, identity.TaskID = document.RunLabel, document.TaskID
	identity.TenantID, identity.PrincipalID = document.TenantID, document.PrincipalID
	return identity, nil
}

// resolveRun loads the stored identity of requested.RunID from runDir, or
// stores requested on first start. Fields left zero in requested are taken
// from the stored file; non-zero fields must match it.
func resolveRun(runDir string, requested RunIdentity, now time.Time) (RunIdentity, error) {
	path := filepath.Join(runDir, runFileName)
	data, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		if requested.InitialStateObjectHash == ([32]byte{}) {
			if requested.InitialStateObjectHash, err = EmptyStateHash(requested.RunID); err != nil {
				return RunIdentity{}, err
			}
		}
		if requested.RunLabel == "" {
			requested.RunLabel = hex.EncodeToString(requested.RunID[:])
		}
		if requested.TaskID == "" || requested.TenantID == "" || requested.PrincipalID == "" || requested.RegistrySnapshotObjectHash == ([32]byte{}) {
			return RunIdentity{}, errors.New("first start of a run needs -task-id, -tenant-id, -principal-id and -registry-hash")
		}
		if err := os.MkdirAll(runDir, 0o700); err != nil {
			return RunIdentity{}, err
		}
		encoded, err := json.MarshalIndent(requested.file(now), "", "  ")
		if err != nil {
			return RunIdentity{}, err
		}
		if err := writeFileAtomic(path, append(encoded, '\n')); err != nil {
			return RunIdentity{}, fmt.Errorf("write %s: %w", runFileName, err)
		}
		return requested, nil
	}
	if err != nil {
		return RunIdentity{}, fmt.Errorf("read %s: %w", runFileName, err)
	}
	var document runFile
	if err := decodeStrict(data, &document); err != nil {
		return RunIdentity{}, fmt.Errorf("%s: %w", runFileName, err)
	}
	stored, err := document.identity()
	if err != nil {
		return RunIdentity{}, err
	}
	mismatch := func(name string) error {
		return fmt.Errorf("-%s differs from the stored run %x (%s)", name, stored.RunID, path)
	}
	switch {
	case stored.RunID != requested.RunID:
		return RunIdentity{}, mismatch("run-id")
	case requested.RunLabel != "" && requested.RunLabel != stored.RunLabel:
		return RunIdentity{}, mismatch("run-label")
	case requested.TaskID != "" && requested.TaskID != stored.TaskID:
		return RunIdentity{}, mismatch("task-id")
	case requested.TenantID != "" && requested.TenantID != stored.TenantID:
		return RunIdentity{}, mismatch("tenant-id")
	case requested.PrincipalID != "" && requested.PrincipalID != stored.PrincipalID:
		return RunIdentity{}, mismatch("principal-id")
	case requested.RegistrySnapshotObjectHash != ([32]byte{}) && requested.RegistrySnapshotObjectHash != stored.RegistrySnapshotObjectHash:
		return RunIdentity{}, mismatch("registry-hash")
	case requested.InitialStateObjectHash != ([32]byte{}) && requested.InitialStateObjectHash != stored.InitialStateObjectHash:
		return RunIdentity{}, mismatch("initial-state-hash")
	}
	return stored, nil
}

// EmptyStateHash is the simulator's canonical hash of an empty provider state
// for runID (the demo commits to it as the run's initial state).
func EmptyStateHash(runID [16]byte) ([32]byte, error) {
	raw, err := canon.Encode(map[int64]any{0: uint64(1), 1: runID, 2: simulator.SimulatorID, 3: []any{}})
	if err != nil {
		return [32]byte{}, err
	}
	return canon.Hash("AgentGate/SimulatorState/v1", raw)
}

// --- request log --------------------------------------------------------------

// clockReading is one simulator.ClockReading as stored in the request log.
type clockReading struct {
	UnixSeconds       uint64 `json:"unix"`
	UncertaintyMillis uint64 `json:"uncertainty_ms"`
	Generation        uint64 `json:"generation"`
}

// requestRecord is one line of requests.jsonl: a request that read the
// provider clock (and so may have changed provider state), the clock readings
// it was given, and a hash of the answer it produced. Replaying the records in
// order through a fresh runtime with the same key reproduces the state and,
// because Ed25519 signatures are deterministic, byte-identical receipts.
type requestRecord struct {
	Seq            uint64              `json:"seq"`
	Path           string              `json:"path"`
	Header         map[string][]string `json:"header"`
	Body           []byte              `json:"body"` // standard base64 in JSON
	Clock          []clockReading      `json:"clock"`
	Status         int                 `json:"status"`
	ResponseSHA256 string              `json:"response_sha256"`
}

// requestLog is the append-only, synced requests.jsonl.
type requestLog struct {
	mu   sync.Mutex
	file *os.File
	next uint64
}

// openRequestLog opens the log and returns its records. A torn last line (the
// trace of a crash during an append, whose answer was therefore never sent)
// is cut off; any other damage refuses to open.
func openRequestLog(path string) (*requestLog, []requestRecord, error) {
	file, err := os.OpenFile(path, os.O_RDWR|os.O_CREATE, 0o600)
	if err != nil {
		return nil, nil, err
	}
	data, err := io.ReadAll(file)
	if err != nil {
		_ = file.Close()
		return nil, nil, err
	}
	complete := bytes.LastIndexByte(data, '\n') + 1
	if complete != len(data) {
		if err := file.Truncate(int64(complete)); err != nil {
			_ = file.Close()
			return nil, nil, fmt.Errorf("cut torn tail of %s: %w", requestFileName, err)
		}
	}
	if _, err := file.Seek(int64(complete), io.SeekStart); err != nil {
		_ = file.Close()
		return nil, nil, err
	}
	var records []requestRecord
	scanner := bufio.NewScanner(bytes.NewReader(data[:complete]))
	scanner.Buffer(make([]byte, 0, 64<<10), 4<<20)
	for scanner.Scan() {
		var record requestRecord
		if err := decodeStrict(scanner.Bytes(), &record); err != nil || record.Seq != uint64(len(records))+1 || len(record.Clock) == 0 {
			_ = file.Close()
			return nil, nil, fmt.Errorf("%s line %d is damaged", requestFileName, len(records)+1)
		}
		records = append(records, record)
	}
	if err := scanner.Err(); err != nil {
		_ = file.Close()
		return nil, nil, err
	}
	return &requestLog{file: file, next: uint64(len(records)) + 1}, records, nil
}

// append writes one record and syncs it to stable storage.
func (l *requestLog) append(record requestRecord) error {
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.file == nil {
		return errors.New("request log is closed")
	}
	record.Seq = l.next
	data, err := json.Marshal(record)
	if err != nil {
		return err
	}
	if _, err := l.file.Write(append(data, '\n')); err != nil {
		return err
	}
	if err := l.file.Sync(); err != nil {
		return err
	}
	l.next++
	return nil
}

func (l *requestLog) close() error {
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.file == nil {
		return nil
	}
	err := l.file.Close()
	l.file = nil
	return err
}

// --- provider clock -----------------------------------------------------------

// persistentClock is the simulator's trusted clock in the provider process.
// Live, it returns the wall clock (never earlier than the last reading) with
// a strictly increasing generation. While a stored request is replayed it
// returns exactly the readings that request was given. It also remembers
// the readings handed out during the current request so they can be stored.
type persistentClock struct {
	mu        sync.Mutex
	now       func() time.Time
	last      simulator.ClockReading
	replaying bool
	queue     []simulator.ClockReading
	issued    []simulator.ClockReading
}

func (c *persistentClock) ReadClock() (simulator.ClockReading, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	var reading simulator.ClockReading
	if c.replaying {
		if len(c.queue) == 0 {
			return simulator.ClockReading{}, errors.New("replay diverged: the request read the clock more often than when it was recorded")
		}
		reading, c.queue = c.queue[0], c.queue[1:]
	} else {
		unix := c.now().Unix()
		if unix < 1 {
			unix = 1
		}
		reading = simulator.ClockReading{UnixSeconds: uint64(unix), Generation: c.last.Generation + 1}
		if reading.UnixSeconds < c.last.UnixSeconds {
			reading.UnixSeconds = c.last.UnixSeconds
		}
	}
	c.last = reading
	c.issued = append(c.issued, reading)
	return reading, nil
}

// begin starts one request: live when replay is nil, else replaying exactly
// those readings.
func (c *persistentClock) begin(replay []clockReading) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.issued = nil
	c.replaying = replay != nil
	c.queue = c.queue[:0]
	for _, reading := range replay {
		c.queue = append(c.queue, simulator.ClockReading{UnixSeconds: reading.UnixSeconds, UncertaintyMillis: reading.UncertaintyMillis, Generation: reading.Generation})
	}
}

// end finishes the request and returns the readings it used. During replay
// it fails if the request used fewer readings than recorded.
func (c *persistentClock) end() ([]clockReading, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	var err error
	if c.replaying && len(c.queue) != 0 {
		err = errors.New("replay diverged: the request read the clock less often than when it was recorded")
	}
	used := make([]clockReading, 0, len(c.issued))
	for _, reading := range c.issued {
		used = append(used, clockReading{UnixSeconds: reading.UnixSeconds, UncertaintyMillis: reading.UncertaintyMillis, Generation: reading.Generation})
	}
	c.replaying, c.queue, c.issued = false, nil, nil
	return used, err
}

// --- small helpers ------------------------------------------------------------

func decodeHex(value string, out []byte) error {
	raw, err := hex.DecodeString(value)
	if err != nil || len(raw) != len(out) || hex.EncodeToString(raw) != value {
		return fmt.Errorf("want %d lowercase hex characters", 2*len(out))
	}
	copy(out, raw)
	return nil
}

// decodeStrict decodes exactly one JSON value, rejecting unknown members and
// trailing data.
func decodeStrict(data []byte, out any) error {
	decoder := json.NewDecoder(bytes.NewReader(data))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(out); err != nil {
		return err
	}
	if err := decoder.Decode(&struct{}{}); err != io.EOF {
		return errors.New("trailing data after the JSON value")
	}
	return nil
}

// writeFileAtomic writes data to a synced temporary file and renames it over
// path, so a crash leaves either the old or the new file.
func writeFileAtomic(path string, data []byte) error {
	temporary, err := os.CreateTemp(filepath.Dir(path), "."+filepath.Base(path)+".*.tmp")
	if err != nil {
		return err
	}
	name := temporary.Name()
	defer os.Remove(name)
	if _, err := temporary.Write(data); err != nil {
		_ = temporary.Close()
		return err
	}
	if err := temporary.Sync(); err != nil {
		_ = temporary.Close()
		return err
	}
	if err := temporary.Close(); err != nil {
		return err
	}
	return os.Rename(name, path)
}
