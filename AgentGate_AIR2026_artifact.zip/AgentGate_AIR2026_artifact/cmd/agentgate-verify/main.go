// Command agentgate-verify re-checks an AgentGate demo run directory from its
// files alone and prints a grouped pass/fail report.
//
//	agentgate-verify [--json] [--expect-keys HEX] [--expect-head HEX]
//	                 [--expect-earlier-keys HEX[,HEX...]]
//	                 [--witness FILE | --witness-url URL] [--witness-key KEY]
//	                 [--assume-compromised ROLE[,ROLE...]] [--workers N] [--unicode] <run-dir>
//
// Exit status: 0 verified, 1 evidence failed verification, 2 usage or I/O
// error.
package main

import (
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"agentgate/internal/auditverify"
)

const usage = `usage: agentgate-verify [--json] [--expect-keys HEX] [--expect-head HEX]
                        [--expect-earlier-keys HEX[,HEX...]]
                        [--witness FILE | --witness-url URL] [--witness-key KEY]
                        [--assume-compromised ROLE[,ROLE...]] [--workers N] [--unicode] <run-dir>

Re-checks an AgentGate run directory (audit.jsonl, head.json, keys.json,
run.json, provider-journal.json) from the files alone.

  --json             print the full report as JSON
  --expect-keys HEX  require SHA-256 of keys.json to equal this fingerprint,
                     pinned outside the run folder (the demo prints it at
                     startup as "Trust anchor (keys fingerprint)")
  --expect-head HEX  require the log to end at this entry hash, pinned outside
                     the run folder (the demo prints it when it stops)
  --expect-earlier-keys HEX[,HEX...]
                     for a run that continued across gateway restarts: the
                     keys fingerprints of its earlier segments, each pinned
                     when that segment started (repeatable, any order).
                     --expect-keys anchors only the newest segment's keys;
                     the earlier segments' keys are named by its
                     continuation record, which its audit key alone signs.
                     Every earlier segment must match one of these and each
                     of these a segment, else keys.anchor fails. Without
                     them (and without --expect-head or a witness), the
                     keys anchor of such a run covers the newest segment only
  --witness FILE     a cosigned head from the head witness (the body of
                     GET /runs/<run id>/latest); it anchors the keys (the
                     fingerprint the witness registered at run start) and
                     the log head (the entry it cosigned). It must be the
                     witness's LATEST cosigned head, fetched when you verify:
                     an older one anchors only the log up to that entry. A
                     saved head cannot show that the run went on in a later
                     restart segment; prefer --witness-url
  --witness-url URL  fetch that latest cosigned head now from the witness at
                     URL (GET URL/runs/<run id>/latest; loopback addresses
                     only), instead of --witness FILE, together with the
                     witness's signed run status (GET URL/runs/<run id>). The
                     status must be signed by the witness key, name the same
                     latest head and be signed within 2 minutes of the fetch;
                     otherwise head.witness fails. If the witness records that
                     a later segment continued the run (continued_by),
                     head.anchor fails, because that segment was not
                     presented (verify the newest segment). Only this fresh
                     status makes the head_fresh dimension pass (and lets
                     run_complete pass); a pinned or saved head is anchored
                     but not shown to be fresh
  --witness-key KEY  the witness's Ed25519 public key, obtained outside the
                     run folder (64 hex characters or standard base64);
                     required with --witness or --witness-url
  --assume-compromised ROLE[,ROLE...]
                     SIMULATION, NOT A VERIFICATION: accept every signature
                     of these roles without verifying it, as if the attacker
                     held their keys (AUDIT_LOG, CAPABILITY_ISSUER, ADAPTER,
                     SIMULATOR_PROVIDER, DELEGATION_AUTHORITY,
                     APPROVAL_AUTHORITY, WITNESS); everything else is checked
                     as usual. For evaluating mutants that edit content and
                     recompute hashes; the output is labelled SIMULATED
  --workers N        verify independent items on N goroutines (default 0 =
                     one per CPU; 1 = sequential); the report is the same
  --unicode          use check marks instead of [PASS]/[FAIL]

Signatures are checked against keys.json from the run folder itself, and the
end of the log against head.json from the same folder. A run folder that
continues an earlier one after a gateway restart ("continues" in run.json)
is verified together with every earlier segment it names; give the newest. Without a keys anchor
(--expect-keys or --witness), someone able to rewrite the whole folder with
substitute keys cannot be ruled out; without a head anchor (--expect-head or
--witness), a rollback to an earlier, genuinely signed checkpoint cannot be
ruled out. For a run of several segments, the keys anchor covers the earlier
segments only with --expect-earlier-keys or a head anchor (or the witness's
run status). Each missing anchor is a [WARN], never a failure, and the
assurance line says CONSISTENT instead of ANCHORED.

The verdict VERIFIED (kept for compatibility) means only that no check
failed. What the evidence supports is the ASSURANCE line, the nine
dimensions (including head_fresh and run_complete) and the Missing list;
each operation also states what its classification rests on.

Exit status: 0 verified (warnings allowed), 1 failed verification,
2 usage or I/O error.
`

func main() {
	os.Exit(run(os.Args[1:], os.Stdout, os.Stderr))
}

type options struct {
	json        bool
	unicode     bool
	expectHead  string
	expectKeys  string
	earlierKeys []string
	witnessFile string
	witnessURL  string
	witnessKey  ed25519.PublicKey
	assumed     []string
	workers     int
	dir         string
}

func parseArgs(args []string) (options, error) {
	var opts options
	for i := 0; i < len(args); i++ {
		arg := args[i]
		switch {
		case arg == "--json" || arg == "-json":
			opts.json = true
		case arg == "--unicode" || arg == "-unicode":
			opts.unicode = true
		case arg == "--expect-head" || arg == "-expect-head":
			if i+1 >= len(args) {
				return opts, fmt.Errorf("%s needs a hex entry hash", arg)
			}
			i++
			opts.expectHead = args[i]
		case strings.HasPrefix(arg, "--expect-head="):
			opts.expectHead = strings.TrimPrefix(arg, "--expect-head=")
		case arg == "--expect-keys" || arg == "-expect-keys":
			if i+1 >= len(args) {
				return opts, fmt.Errorf("%s needs the hex SHA-256 of keys.json", arg)
			}
			i++
			opts.expectKeys = args[i]
		case strings.HasPrefix(arg, "--expect-keys="):
			opts.expectKeys = strings.TrimPrefix(arg, "--expect-keys=")
		case arg == "--expect-earlier-keys" || arg == "-expect-earlier-keys":
			if i+1 >= len(args) {
				return opts, fmt.Errorf("%s needs a comma-separated list of hex keys fingerprints", arg)
			}
			i++
			opts.earlierKeys = append(opts.earlierKeys, splitList(args[i])...)
		case strings.HasPrefix(arg, "--expect-earlier-keys="):
			opts.earlierKeys = append(opts.earlierKeys, splitList(strings.TrimPrefix(arg, "--expect-earlier-keys="))...)
		case arg == "--workers" || arg == "-workers":
			if i+1 >= len(args) {
				return opts, fmt.Errorf("%s needs a number of workers", arg)
			}
			i++
			if err := parseWorkers(args[i], &opts); err != nil {
				return opts, err
			}
		case strings.HasPrefix(arg, "--workers="):
			if err := parseWorkers(strings.TrimPrefix(arg, "--workers="), &opts); err != nil {
				return opts, err
			}
		case arg == "--witness" || arg == "-witness":
			if i+1 >= len(args) {
				return opts, fmt.Errorf("%s needs the path of a cosigned head file", arg)
			}
			i++
			opts.witnessFile = args[i]
		case strings.HasPrefix(arg, "--witness="):
			opts.witnessFile = strings.TrimPrefix(arg, "--witness=")
		case arg == "--witness-url" || arg == "-witness-url":
			if i+1 >= len(args) {
				return opts, fmt.Errorf("%s needs the witness's base URL", arg)
			}
			i++
			opts.witnessURL = args[i]
		case strings.HasPrefix(arg, "--witness-url="):
			opts.witnessURL = strings.TrimPrefix(arg, "--witness-url=")
		case arg == "--witness-key" || arg == "-witness-key":
			if i+1 >= len(args) {
				return opts, fmt.Errorf("%s needs the witness public key", arg)
			}
			i++
			if err := parseWitnessKey(args[i], &opts); err != nil {
				return opts, err
			}
		case strings.HasPrefix(arg, "--witness-key="):
			if err := parseWitnessKey(strings.TrimPrefix(arg, "--witness-key="), &opts); err != nil {
				return opts, err
			}
		case arg == "--assume-compromised" || arg == "-assume-compromised":
			if i+1 >= len(args) {
				return opts, fmt.Errorf("%s needs a comma-separated list of roles", arg)
			}
			i++
			opts.assumed = append(opts.assumed, splitList(args[i])...)
		case strings.HasPrefix(arg, "--assume-compromised="):
			opts.assumed = append(opts.assumed, splitList(strings.TrimPrefix(arg, "--assume-compromised="))...)
		case arg == "-h" || arg == "--help" || arg == "-help":
			return opts, errHelp
		case strings.HasPrefix(arg, "-"):
			return opts, fmt.Errorf("unknown flag %s", arg)
		case opts.dir != "":
			return opts, fmt.Errorf("only one run directory may be given")
		default:
			opts.dir = arg
		}
	}
	if opts.dir == "" {
		return opts, fmt.Errorf("missing run directory")
	}
	if opts.expectKeys != "" && !isHex64(strings.TrimSpace(opts.expectKeys)) {
		return opts, fmt.Errorf("--expect-keys must be the 64-character hex SHA-256 of keys.json")
	}
	if opts.expectHead != "" && !isHex64(strings.TrimSpace(opts.expectHead)) {
		return opts, fmt.Errorf("--expect-head must be a 64-character hex entry hash")
	}
	for _, pin := range opts.earlierKeys {
		if !isHex64(pin) {
			return opts, fmt.Errorf("--expect-earlier-keys must list 64-character hex SHA-256 fingerprints of keys.json, not %q", pin)
		}
	}
	if opts.witnessFile != "" && opts.witnessURL != "" {
		return opts, fmt.Errorf("give either --witness FILE or --witness-url URL, not both")
	}
	if (opts.witnessFile == "" && opts.witnessURL == "") != (opts.witnessKey == nil) {
		return opts, fmt.Errorf("--witness (or --witness-url) and --witness-key must be given together")
	}
	if opts.witnessURL != "" {
		if _, err := witnessURL(opts.witnessURL, "run", "/latest"); err != nil {
			return opts, err
		}
	}
	return opts, nil
}

// witnessURL builds <base>/runs/<run id><suffix>: suffix "/latest" for the
// latest cosigned head, "" for the run status. The witness must be on a
// loopback address: the verifier never fetches anything from the network
// beyond this machine.
func witnessURL(base, runID, suffix string) (string, error) {
	parsed, err := url.Parse(strings.TrimSpace(base))
	if err != nil || (parsed.Scheme != "http" && parsed.Scheme != "https") || parsed.Host == "" {
		return "", fmt.Errorf("--witness-url must be an http(s) URL such as http://127.0.0.1:8090, not %q", base)
	}
	if parsed.User != nil || parsed.RawQuery != "" || parsed.Fragment != "" {
		return "", fmt.Errorf("--witness-url must be a plain base URL without user, query or fragment")
	}
	if !loopbackHost(parsed.Hostname()) {
		return "", fmt.Errorf("--witness-url must name a loopback address (127.0.0.1, ::1 or localhost), not %q", parsed.Hostname())
	}
	parsed.Path = strings.TrimSuffix(parsed.Path, "/") + "/runs/" + url.PathEscape(runID) + suffix
	parsed.RawPath = ""
	return parsed.String(), nil
}

func loopbackHost(host string) bool {
	if strings.EqualFold(host, "localhost") {
		return true
	}
	ip := net.ParseIP(host)
	return ip != nil && ip.IsLoopback()
}

// fetchAttempts is how often fetchWitness reads the head and the status
// when a push between the two reads makes them disagree.
const fetchAttempts = 3

// fetchWitness fetches the witness's latest cosigned head for runID and
// its signed run status (which names the same latest head and a later
// segment that continued the run). Both are read now, from the same witness,
// so the status describes the run as the witness sees it at verification
// time; fetchedAt is when the status was received (the verifier refuses a
// status signed far from it). A head pushed between the two reads makes the
// status name a newer head than the one fetched: both are read again, up to
// fetchAttempts times; the last pair is returned either way and the verifier
// judges it.
func fetchWitness(base, runID string) (head, status []byte, fetchedAt time.Time, err error) {
	client := loopbackClient()
	for attempt := 0; attempt < fetchAttempts; attempt++ {
		if head, err = fetchLoopback(client, base, runID, "/latest"); err != nil {
			return nil, nil, time.Time{}, err
		}
		if status, err = fetchLoopback(client, base, runID, ""); err != nil {
			return nil, nil, time.Time{}, fmt.Errorf("run status: %w", err)
		}
		fetchedAt = time.Now()
		if !statusIsNewer(head, status) {
			break
		}
	}
	return head, status, fetchedAt, nil
}

// statusIsNewer reports whether the run status names a later cosigned head
// than the head fetched before it (a push in between). It is a quick read to
// decide whether to fetch again; the verifier checks both documents itself.
func statusIsNewer(head, status []byte) bool {
	var cosigned struct {
		Index uint64 `json:"index"`
	}
	var run struct {
		LatestIndex uint64 `json:"latest_index"`
	}
	if json.Unmarshal(head, &cosigned) != nil || json.Unmarshal(status, &run) != nil {
		return false // nothing to gain from fetching again
	}
	return run.LatestIndex > cosigned.Index
}

// loopbackClient is an HTTP client whose connections may only reach a
// loopback address (also after name resolution) and which refuses
// redirects.
func loopbackClient() *http.Client {
	dialer := &net.Dialer{Timeout: 5 * time.Second}
	transport := &http.Transport{
		Proxy: nil,
		DialContext: func(ctx context.Context, network, address string) (net.Conn, error) {
			host, _, err := net.SplitHostPort(address)
			if err != nil {
				return nil, err
			}
			addresses, err := net.DefaultResolver.LookupIPAddr(ctx, host)
			if err != nil {
				return nil, err
			}
			for _, candidate := range addresses {
				if !candidate.IP.IsLoopback() {
					return nil, fmt.Errorf("the witness address %s resolves to %s, which is not a loopback address", host, candidate.IP)
				}
			}
			return dialer.DialContext(ctx, network, address)
		},
	}
	return &http.Client{Timeout: 10 * time.Second, Transport: transport,
		CheckRedirect: func(*http.Request, []*http.Request) error {
			return errors.New("the witness answered with a redirect, which is not followed")
		}}
}

// fetchLoopback reads GET <base>/runs/<run id><suffix> from the witness.
func fetchLoopback(client *http.Client, base, runID, suffix string) ([]byte, error) {
	target, err := witnessURL(base, runID, suffix)
	if err != nil {
		return nil, err
	}
	response, err := client.Get(target)
	if err != nil {
		return nil, err
	}
	defer response.Body.Close()
	data, err := io.ReadAll(io.LimitReader(response.Body, auditverify.MaxWitnessHeadBytes+1))
	if err != nil {
		return nil, err
	}
	if response.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("GET %s answered %s: %s", target, response.Status, strings.TrimSpace(string(data[:min(len(data), 200)])))
	}
	if int64(len(data)) > auditverify.MaxWitnessHeadBytes {
		return nil, fmt.Errorf("the witness's answer to %s is larger than %d bytes", target, auditverify.MaxWitnessHeadBytes)
	}
	return data, nil
}

// folderRunID reads the run ID of a run folder (run.json, else head.json),
// to ask the witness for that run's latest head.
func folderRunID(dir string) (string, error) {
	for _, name := range []string{"run.json", "head.json"} {
		file, err := os.Open(filepath.Join(dir, name))
		if err != nil {
			continue
		}
		var document struct {
			RunID string `json:"run_id"`
		}
		err = json.NewDecoder(io.LimitReader(file, 32<<20)).Decode(&document)
		file.Close()
		if err == nil && document.RunID != "" {
			return document.RunID, nil
		}
	}
	return "", fmt.Errorf("neither run.json nor head.json in %s names the run, so the witness cannot be asked for its head", dir)
}

// splitList splits a comma-separated list of roles or fingerprints (items
// are trimmed and empty items dropped; VerifyRun rejects unknown roles, and
// parseArgs malformed fingerprints).
func splitList(value string) []string {
	var items []string
	for _, item := range strings.Split(value, ",") {
		if item = strings.TrimSpace(item); item != "" {
			items = append(items, item)
		}
	}
	return items
}

// parseWitnessKey accepts the 32-byte witness public key as 64 hex
// characters or standard base64 (as GET /key prints it).
func parseWitnessKey(value string, opts *options) error {
	value = strings.TrimSpace(value)
	key, err := hex.DecodeString(value)
	if err != nil || len(key) != ed25519.PublicKeySize {
		key, err = base64.StdEncoding.DecodeString(value)
	}
	if err != nil || len(key) != ed25519.PublicKeySize {
		return fmt.Errorf("--witness-key must be a 32-byte Ed25519 public key (64 hex characters or standard base64)")
	}
	opts.witnessKey = ed25519.PublicKey(key)
	return nil
}

// readWitness reads the cosigned head file, refusing an oversized one.
func readWitness(path string) ([]byte, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()
	data, err := io.ReadAll(io.LimitReader(file, auditverify.MaxWitnessHeadBytes+1))
	if err != nil {
		return nil, err
	}
	if int64(len(data)) > auditverify.MaxWitnessHeadBytes {
		return nil, fmt.Errorf("%s is larger than %d bytes", path, auditverify.MaxWitnessHeadBytes)
	}
	return data, nil
}

func parseWorkers(value string, opts *options) error {
	n, err := strconv.Atoi(strings.TrimSpace(value))
	if err != nil || n < 0 {
		return fmt.Errorf("--workers must be 0 (one per CPU) or a positive number, not %q", value)
	}
	opts.workers = n
	return nil
}

func isHex64(value string) bool {
	if len(value) != 64 {
		return false
	}
	_, err := hex.DecodeString(value)
	return err == nil
}

var errHelp = fmt.Errorf("help requested")

func run(args []string, stdout, stderr io.Writer) int {
	opts, err := parseArgs(args)
	if err == errHelp {
		fmt.Fprint(stdout, usage)
		return 0
	}
	if err != nil {
		fmt.Fprintf(stderr, "agentgate-verify: %v\n\n%s", err, usage)
		return 2
	}
	verifyOptions := auditverify.Options{ExpectHead: opts.expectHead, ExpectKeysSHA256: opts.expectKeys, ExpectEarlierKeysSHA256: opts.earlierKeys,
		Workers: opts.workers, WitnessPublicKey: opts.witnessKey, AssumeCompromised: opts.assumed}
	if opts.witnessFile != "" {
		witness, err := readWitness(opts.witnessFile)
		if err != nil {
			fmt.Fprintf(stderr, "agentgate-verify: witness head: %v\n", err)
			return 2
		}
		verifyOptions.WitnessHead = witness
	}
	if opts.witnessURL != "" {
		runID, err := folderRunID(opts.dir)
		if err == nil {
			verifyOptions.WitnessHead, verifyOptions.WitnessRun, verifyOptions.WitnessRunFetchedAt, err = fetchWitness(opts.witnessURL, runID)
		}
		if err != nil {
			fmt.Fprintf(stderr, "agentgate-verify: witness head: %v\n", err)
			return 2
		}
	}
	report, err := auditverify.VerifyRun(opts.dir, verifyOptions)
	if err != nil {
		fmt.Fprintf(stderr, "agentgate-verify: %v\n", err)
		return 2
	}
	if opts.json {
		encoder := json.NewEncoder(stdout)
		encoder.SetIndent("", "  ")
		encoder.SetEscapeHTML(false)
		if err := encoder.Encode(report); err != nil {
			fmt.Fprintf(stderr, "agentgate-verify: %v\n", err)
			return 2
		}
	} else {
		printHuman(stdout, report, opts.unicode)
	}
	if report.Verdict != auditverify.VerdictVerified {
		return 1
	}
	return 0
}

func printHuman(w io.Writer, report auditverify.Report, unicode bool) {
	text := func(s string) string {
		if unicode {
			return s
		}
		return asciiSafe(s)
	}
	mark := map[string]string{auditverify.StatusPass: "[PASS]", auditverify.StatusFail: "[FAIL]", auditverify.StatusWarn: "[WARN]"}
	if unicode {
		mark = map[string]string{auditverify.StatusPass: "✓", auditverify.StatusFail: "✗", auditverify.StatusWarn: "!"}
	}

	fmt.Fprintln(w, "AgentGate offline verifier")
	fmt.Fprintf(w, "  Run:     %s\n", text(report.RunID))
	fmt.Fprintf(w, "  Folder:  %s\n", text(report.Dir))
	flagged := ""
	if n := report.Counts.Flagged; n > 0 {
		flagged = fmt.Sprintf(" (%d flagged for audit)", n)
		if unconfirmed := report.Counts.FlaggedUnconfirmed; unconfirmed > 0 {
			flagged = fmt.Sprintf(" (%d flagged for audit, %d of them with the outcome unconfirmed)", n, unconfirmed)
		}
	}
	fmt.Fprintf(w, "  Log:     %d entries, %d operations, %d executed effects%s, %d at the provider\n",
		report.Counts.Entries, report.Counts.Operations, report.Counts.Effects, flagged, report.Counts.ProviderEffects)
	if report.HeadHash != "" {
		fmt.Fprintf(w, "  Head:    entry #%d  %s\n", report.HeadSeq, report.HeadHash)
	}
	if report.Simulation != nil {
		fmt.Fprintf(w, "  %s\n", text(report.Simulation.Note))
	}
	if len(report.Segments) > 1 {
		fmt.Fprintf(w, "  Segments: the run continued across %d gateway restart(s) and was verified as one run:\n", len(report.Segments)-1)
		for _, segment := range report.Segments {
			fmt.Fprintf(w, "    %d. %s  %d entries, ends at #%d %s  (%s)\n", segment.Index, text(segment.RunID), segment.Entries, segment.HeadSeq, shortOp(segment.HeadHash), text(filepath.Clean(segment.Dir)))
		}
	}

	for _, group := range auditverify.Groups {
		fmt.Fprintf(w, "\n%s\n", group)
		var inGroup []auditverify.Check
		for _, check := range report.Checks {
			if check.Group == group {
				inGroup = append(inGroup, check)
			}
		}
		for i := 0; i < len(inGroup); i++ {
			check := inGroup[i]
			fmt.Fprintf(w, "  %s %-26s %s\n", mark[check.Status], check.ID, text(check.Title))
			fmt.Fprintf(w, "         %s\n", text(check.Detail))
			// A tampered log can fail one check on dozens of entries; show
			// the first few and summarize the rest.
			run := i
			for run+1 < len(inGroup) && inGroup[run+1].ID == check.ID && inGroup[run+1].Status == check.Status {
				run++
			}
			if extra := run - i; extra > maxRepeats {
				for _, next := range inGroup[i+1 : i+maxRepeats] {
					fmt.Fprintf(w, "  %s %-26s %s\n", mark[next.Status], next.ID, text(next.Detail))
				}
				last := inGroup[run]
				fmt.Fprintf(w, "  %s %-26s ... and %d more like this, up to entry #%d\n", mark[check.Status], check.ID, run-i-maxRepeats+1, last.Seq)
				i = run
			}
		}
	}
	// Anything outside the known groups (for example verifier.error).
	for _, check := range report.Checks {
		if !contains(auditverify.Groups, check.Group) {
			fmt.Fprintf(w, "  %s %-26s %s\n         %s\n", mark[check.Status], check.ID, text(check.Title), text(check.Detail))
		}
	}

	printAnchors(w, report.Anchors)

	if len(report.Operations) > 0 {
		fmt.Fprintf(w, "\nOperations\n")
		for _, op := range report.Operations {
			flag := ""
			unresolved := op.Status == auditverify.OpUncertain || op.Status == auditverify.OpReconciliationRequired
			switch {
			case op.Flagged && unresolved:
				flag = "  [flagged for audit, outcome unconfirmed]"
			case op.Flagged:
				flag = "  [flagged for audit]"
			}
			if op.ClassificationEvidence == auditverify.ClassIssuerReconciled || op.ClassificationEvidence == auditverify.ClassIssuerUnresolved {
				flag += "  [classification: issuer key only]"
			}
			if op.Reconciled {
				// Settled by the provider's signed status; an adapter receipt the
				// RECONCILED entry carried makes it issuer_adapter.
				flag += "  [reconciled]"
			}
			if op.Failures > 0 {
				flag += fmt.Sprintf("  <- %d failing check(s)", op.Failures)
			}
			fmt.Fprintf(w, "  %-9s %-25s %s  %s%s\n", op.Status, op.EffectType, shortOp(op.OperationID), text(op.Summary), flag)
		}
		var classes []string
		for _, class := range auditverify.ClassificationClasses() {
			if n := report.Counts.ClassificationEvidence[class]; n > 0 {
				classes = append(classes, fmt.Sprintf("%d %s", n, class))
			}
		}
		if len(classes) > 0 {
			fmt.Fprintf(w, "  Classification evidence (what binds each operation's flag, mode and rules): %s\n", strings.Join(classes, ", "))
		}
	}

	total := report.Counts.ChecksPassed + report.Counts.ChecksFailed
	warnings := ""
	if n := report.Counts.Warnings; n > 0 {
		warnings = fmt.Sprintf("; %s (see [WARN] lines)", count(n, "warning", "warnings"))
	}
	fmt.Fprintln(w)
	if report.Simulation != nil {
		fmt.Fprintf(w, "SIMULATION (signatures of %s not verified): the verdict below is what an attacker holding these keys could achieve, not a verdict on genuine evidence.\n", strings.Join(report.Simulation.AssumeCompromised, ", "))
	}
	if report.Verdict == auditverify.VerdictVerified {
		fmt.Fprintf(w, "VERDICT: VERIFIED - all %d checks passed%s\n", total, warnings)
		fmt.Fprintln(w, "         VERIFIED means only that no check failed; what the evidence supports is the ASSURANCE line, the dimensions and Missing below.")
		keysAnchored := report.Dimensions.AnchoredKeys.Status == auditverify.DimensionPass
		headAnchored := report.Dimensions.AnchoredHead.Status == auditverify.DimensionPass
		newestOnly := !keysAnchored && report.Anchors.EarlierSegments > 0 && !report.Anchors.EarlierKeysAnchored &&
			(report.Anchors.KeysMatch || report.Anchors.Witness != nil && report.Anchors.Witness.Valid && report.Anchors.Witness.KeysMatch)
		switch {
		case newestOnly:
			fmt.Fprintln(w, "         Keys anchored for the newest segment only: the earlier segments' keys rest on the newest segment's audit key")
			fmt.Fprintln(w, "         alone, and the end of the log is not anchored. Re-run with --expect-earlier-keys (each earlier segment's")
			fmt.Fprintln(w, "         fingerprint) or --expect-head.")
		case !keysAnchored && !headAnchored:
			fmt.Fprintln(w, "         Not anchored: the keys and the end of the log were taken from the run folder itself. Re-run with")
			fmt.Fprintln(w, "         --expect-keys and --expect-head to rule out re-signing with substitute keys or a rollback to an earlier checkpoint.")
		case !keysAnchored:
			fmt.Fprintln(w, "         Not anchored to the keys: they were taken from the run folder itself. Re-run with --expect-keys to rule out re-signing with substitute keys.")
		case !headAnchored:
			fmt.Fprintln(w, "         End of log not anchored: it was checked only against head.json in the folder. Re-run with --expect-head to rule out a rollback to an earlier checkpoint.")
		}
	} else {
		fmt.Fprintf(w, "VERDICT: FAILED - %d of %d checks failed (%s)%s\n", report.Counts.ChecksFailed, total, count(report.Counts.Findings, "finding", "findings"), warnings)
	}
	printAssurance(w, report, text)
}

// printAssurance shows what the evidence supports: the assurance level, each
// dimension and what is missing.
func printAssurance(w io.Writer, report auditverify.Report, text func(string) string) {
	meaning := map[string]string{
		auditverify.AssuranceAnchored:   "every check passed and both the keys and the log end match values held outside the folder (head_fresh says whether that head is the run's current one)",
		auditverify.AssuranceConsistent: "every check passed, but the evidence is only internally consistent (see Missing)",
		auditverify.AssuranceFailed:     "at least one check failed",
	}[auditverify.AssuranceLevel(report.Assurance)]
	if report.Simulation != nil {
		meaning = "SIMULATION, not a verification: " + meaning
	}
	fmt.Fprintf(w, "ASSURANCE: %s - %s\n", report.Assurance, meaning)
	for _, name := range append(auditverify.DimensionNames(), auditverify.DerivedDimensionNames()...) {
		dimension, _ := report.Dimensions.ByName(name)
		fmt.Fprintf(w, "  %-24s %-11s %s\n", name, dimension.Status, text(dimension.Reason))
	}
	if len(report.Missing) > 0 {
		fmt.Fprintln(w, "Missing:")
		for index, item := range report.Missing {
			// The kind (Report.MissingKinds) is shown for the gaps a reader
			// counts: an unresolved operation, a head not shown to be fresh,
			// a classification on the issuer key alone.
			kind := ""
			if index < len(report.MissingKinds) && report.MissingKinds[index] != auditverify.MissingKindOther {
				kind = "[" + report.MissingKinds[index] + "] "
			}
			fmt.Fprintf(w, "  - %s%s\n", kind, text(item))
		}
	}
}

// printAnchors shows what the verdict is anchored to: values obtained outside
// the run folder, or nothing.
func printAnchors(w io.Writer, anchors auditverify.Anchors) {
	fmt.Fprintf(w, "\nTrust anchors\n")
	witness := anchors.Witness
	keys := "NOT PINNED (pass --expect-keys)"
	switch {
	case anchors.KeysPinned && anchors.KeysMatch:
		keys = "pinned, matches"
	case anchors.KeysPinned:
		keys = "pinned " + anchors.ExpectedKeysSHA256 + ", DOES NOT MATCH"
	case witness != nil && witness.Valid && witness.KeysMatch:
		keys = "not pinned; matches the fingerprint the witness registered"
	case witness != nil && witness.Valid:
		keys = "not pinned; the witness registered " + witness.KeysSHA256 + ", DOES NOT MATCH"
	}
	fmt.Fprintf(w, "  keys.json SHA-256  %s\n                     %s\n", orNone(anchors.KeysSHA256), keys)
	head := "NOT PINNED (pass --expect-head)"
	switch {
	case anchors.HeadPinned && anchors.HeadMatch:
		head = "pinned, matches"
	case anchors.HeadPinned:
		head = "pinned " + anchors.ExpectedHeadHash + ", DOES NOT MATCH"
	case witness != nil && witness.Valid && witness.ContinuedBy != "":
		head = "not pinned; the witness says the run went on in run " + witness.ContinuedBy + ", DOES NOT END HERE"
	case witness != nil && witness.Valid && witness.CoversEnd:
		head = "not pinned; the witness cosigned this entry"
	case witness != nil && witness.Valid:
		head = "not pinned; see the witness head below"
	}
	fmt.Fprintf(w, "  log head hash      %s\n                     %s\n", orNone(anchors.HeadHash), head)
	if witness != nil {
		state := "INVALID (see head.witness)"
		switch {
		case witness.Valid && witness.CoversEnd:
			state = "valid, cosigned the last entry"
		case witness.Valid && witness.InLog:
			state = fmt.Sprintf("valid, cosigned entry #%d only (later entries not anchored)", witness.Seq)
		case witness.Valid:
			state = fmt.Sprintf("valid, but its entry #%d is NOT in this log", witness.Seq)
		}
		fmt.Fprintf(w, "  witness head       entry #%d %s (witness key %s)\n                     %s\n", witness.Seq, orNone(witness.EntryHash), shortOp(witness.WitnessKID), state)
		status := "not consulted (a saved head does not carry it; --witness-url reads it):\n                     a withheld later restart segment is not ruled out"
		switch {
		case witness.StatusChecked && witness.ContinuedBy != "":
			status = "the run was CONTINUED by run " + witness.ContinuedBy + ",\n                     which is not part of this chain (withheld segment)"
		case witness.StatusChecked:
			status = "signed " + witness.StatusAt + ": no later segment continues this run"
		case witness.StatusGiven:
			status = "INVALID (see head.witness): not the witness's current signed status of\n                     this run, so a withheld later restart segment is not ruled out"
		}
		fmt.Fprintf(w, "  witness run status %s\n", status)
	}
}

func orNone(value string) string {
	if value == "" {
		return "(unavailable)"
	}
	return value
}

func count(n int, one, many string) string {
	if n == 1 {
		return "1 " + one
	}
	return fmt.Sprintf("%d %s", n, many)
}

// maxRepeats is how many failures of one check are printed before the rest
// are summarized (--json always lists every failure).
const maxRepeats = 3

func shortOp(op string) string {
	if len(op) > 10 {
		return op[:10]
	}
	return fmt.Sprintf("%-10s", op)
}

func contains(values []string, want string) bool {
	for _, value := range values {
		if value == want {
			return true
		}
	}
	return false
}

// asciiSafe keeps output readable on legacy Windows consoles.
func asciiSafe(s string) string {
	replacer := strings.NewReplacer("—", "-", "–", "-", "…", "...", "“", `"`, "”", `"`, "‘", "'", "’", "'", "→", "->", "✓", "[PASS]", "✗", "[FAIL]")
	s = replacer.Replace(s)
	var b strings.Builder
	for _, r := range s {
		if r < 0x80 {
			b.WriteRune(r)
		} else {
			b.WriteByte('?')
		}
	}
	return b.String()
}
