package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"agentgate/internal/auditverify"
	"agentgate/internal/auditverify/fixture"
)

func TestExitCodesAndOutput(t *testing.T) {
	run, err := fixture.Write(filepath.Join(t.TempDir(), "run"))
	if err != nil {
		t.Fatal(err)
	}

	var out, errOut bytes.Buffer
	if code := run_(t, []string{run.Dir}, &out, &errOut); code != 0 {
		t.Fatalf("clean run exit %d\n%s%s", code, out.String(), errOut.String())
	}
	if !strings.Contains(out.String(), "VERDICT: VERIFIED") || !strings.Contains(out.String(), "[PASS] chain.signature") {
		t.Fatalf("unexpected human output:\n%s", out.String())
	}

	out.Reset()
	if code := run_(t, []string{"--json", "--expect-head", run.HeadHash, run.Dir}, &out, &errOut); code != 0 {
		t.Fatalf("json run exit %d", code)
	}
	var report auditverify.Report
	if err := json.Unmarshal(out.Bytes(), &report); err != nil || report.Verdict != auditverify.VerdictVerified {
		t.Fatalf("json output: %v %+v", err, report.Verdict)
	}

	tampered := filepath.Join(run.Dir, "tamper", "edit-value-1")
	if _, err := auditverify.ApplyTamper(run.Dir, tampered, auditverify.TamperEditValue); err != nil {
		t.Fatal(err)
	}
	out.Reset()
	if code := run_(t, []string{tampered}, &out, &errOut); code != 1 {
		t.Fatalf("tampered run exit %d, want 1", code)
	}
	if !strings.Contains(out.String(), "[FAIL] chain.entry_hash") || !strings.Contains(out.String(), "VERDICT: FAILED") {
		t.Fatalf("tampered output lacks the failure:\n%s", out.String())
	}

	for _, args := range [][]string{{}, {"--bogus", run.Dir}, {"--expect-head"}, {"--expect-keys"}, {"--expect-keys", "abc", run.Dir}, {run.Dir, run.Dir}, {filepath.Join(run.Dir, "missing")}} {
		if code := run_(t, args, &out, &errOut); code != 2 {
			t.Errorf("args %q: exit %d, want 2", args, code)
		}
	}
}

func TestTrustAnchors(t *testing.T) {
	run, err := fixture.Write(filepath.Join(t.TempDir(), "run"))
	if err != nil {
		t.Fatal(err)
	}
	data, err := os.ReadFile(filepath.Join(run.Dir, "keys.json"))
	if err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256(data)
	fingerprint := hex.EncodeToString(sum[:])

	// Unpinned: verified, but the warning and the missing anchor are plain.
	var out, errOut bytes.Buffer
	if code := run_(t, []string{run.Dir}, &out, &errOut); code != 0 {
		t.Fatalf("unpinned exit %d\n%s", code, out.String())
	}
	for _, want := range []string{"[WARN] keys.anchor", "[WARN] head.anchor", "Trust anchors", fingerprint, "NOT PINNED", "2 warnings", "Not anchored", "--expect-head"} {
		if !strings.Contains(out.String(), want) {
			t.Errorf("unpinned output lacks %q:\n%s", want, out.String())
		}
	}

	// Pinned keys and head: verified and anchored.
	out.Reset()
	if code := run_(t, []string{"--expect-keys", fingerprint, "--expect-head=" + run.HeadHash, run.Dir}, &out, &errOut); code != 0 {
		t.Fatalf("pinned exit %d\n%s", code, out.String())
	}
	if !strings.Contains(out.String(), "[PASS] keys.anchor") || strings.Contains(out.String(), "NOT PINNED") || strings.Contains(out.String(), "Not anchored") {
		t.Fatalf("pinned output:\n%s", out.String())
	}

	// Keys pinned but not the head: still a warning, and the note says so.
	out.Reset()
	if code := run_(t, []string{"--expect-keys", fingerprint, run.Dir}, &out, &errOut); code != 0 {
		t.Fatalf("keys-only exit %d\n%s", code, out.String())
	}
	if !strings.Contains(out.String(), "[WARN] head.anchor") || !strings.Contains(out.String(), "End of log not anchored") {
		t.Fatalf("keys-only output:\n%s", out.String())
	}

	// A different pin fails the run.
	out.Reset()
	if code := run_(t, []string{"--json", "--expect-keys=" + strings.Repeat("0", 64), run.Dir}, &out, &errOut); code != 1 {
		t.Fatalf("wrong pin exit %d, want 1", code)
	}
	var report auditverify.Report
	if err := json.Unmarshal(out.Bytes(), &report); err != nil || !report.Anchors.KeysPinned || report.Anchors.KeysMatch || report.Anchors.KeysSHA256 != fingerprint {
		t.Fatalf("wrong pin report: %v %+v", err, report.Anchors)
	}
}

func TestWorkersAndFlaggedOutput(t *testing.T) {
	run, err := fixture.WriteEscalation(filepath.Join(t.TempDir(), "run"), fixture.EscalationFlag)
	if err != nil {
		t.Fatal(err)
	}
	reports := map[string]string{}
	for _, workers := range []string{"1", "4", "0"} {
		var out, errOut bytes.Buffer
		if code := run_(t, []string{"--json", "--workers", workers, run.Dir}, &out, &errOut); code != 0 {
			t.Fatalf("--workers %s: exit %d\n%s", workers, code, errOut.String())
		}
		var report map[string]any
		if err := json.Unmarshal(out.Bytes(), &report); err != nil {
			t.Fatal(err)
		}
		delete(report, "checked_at")
		normalized, _ := json.Marshal(report)
		reports[workers] = string(normalized)
	}
	if reports["1"] != reports["4"] || reports["1"] != reports["0"] {
		t.Fatalf("reports differ between worker counts")
	}

	var out, errOut bytes.Buffer
	if code := run_(t, []string{"--workers=2", run.Dir}, &out, &errOut); code != 0 {
		t.Fatalf("human output exit %d", code)
	}
	for _, want := range []string{"4 executed effects (2 flagged for audit)", "[flagged for audit]", "VERDICT: VERIFIED"} {
		if !strings.Contains(out.String(), want) {
			t.Errorf("output lacks %q:\n%s", want, out.String())
		}
	}
	for _, args := range [][]string{{"--workers", run.Dir}, {"--workers", "-1", run.Dir}, {"--workers=many", run.Dir}} {
		if code := run_(t, args, &out, &errOut); code != 2 {
			t.Errorf("args %q: exit %d, want 2", args, code)
		}
	}
}

func run_(t *testing.T, args []string, stdout, stderr *bytes.Buffer) int {
	t.Helper()
	return run(args, stdout, stderr)
}

// The human output names what each operation's classification rests on: an
// operation settled only by reconciliation, and a flagged operation left
// unresolved (here restated so by an audit-key holder, which only a head
// anchor would detect), rest on the issuer key alone.
func TestClassificationEvidenceOutput(t *testing.T) {
	run, err := fixture.WriteWith(filepath.Join(t.TempDir(), "run"), fixture.Options{Revision: true})
	if err != nil {
		t.Fatal(err)
	}
	flagged := run.Operations["flagged"]
	if err := fixture.RewriteLogWithAuditKey(run.Dir, func(entries []fixture.Entry) []fixture.Entry {
		var out []fixture.Entry
		for _, entry := range entries {
			if entry.OperationID == flagged && entry.Stage == "EFFECT_EXECUTED" {
				continue
			}
			if entry.OperationID == flagged && entry.Stage == "CALL_RESULT" {
				entry.Details["status"] = "RECONCILIATION_REQUIRED"
			}
			out = append(out, entry)
		}
		return out
	}); err != nil {
		t.Fatal(err)
	}
	var out, errOut bytes.Buffer
	if code := run_(t, []string{run.Dir}, &out, &errOut); code != 0 {
		t.Fatalf("exit %d\n%s%s", code, out.String(), errOut.String())
	}
	for _, want := range []string{"5 executed effects (3 flagged for audit, 1 of them with the outcome unconfirmed)",
		"[flagged for audit, outcome unconfirmed]  [classification: issuer key only]",
		"Classification evidence (what binds each operation's flag, mode and rules): 4 issuer_adapter, 1 issuer_only_reconciled, 1 issuer_only_unresolved, 6 audit_only",
		fmt.Sprintf("%-24s %s", "run_complete", "fail"), "reported flagged with the outcome unconfirmed",
		// Missing entries show their kind; the fixture's reconciled payment
		// is marked as such.
		"- [unresolved] Operation ", "- [issuer_only] 1 operation was executed only according to a RECONCILED entry", "  [reconciled]"} {
		if !strings.Contains(out.String(), want) {
			t.Errorf("output lacks %q:\n%s", want, out.String())
		}
	}
}

func TestWitnessFlagsAndAssurance(t *testing.T) {
	run, err := fixture.WriteWith(filepath.Join(t.TempDir(), "run"), fixture.Options{Revision: true})
	if err != nil {
		t.Fatal(err)
	}
	document, public, err := fixture.CosignHead(run.Dir, run.HeadSeq)
	if err != nil {
		t.Fatal(err)
	}
	witnessFile := filepath.Join(t.TempDir(), "witness.json")
	if err := os.WriteFile(witnessFile, document, 0o600); err != nil {
		t.Fatal(err)
	}
	key := hex.EncodeToString(public)

	// Unanchored: consistent only, and the output says what is missing.
	var out, errOut bytes.Buffer
	if code := run_(t, []string{run.Dir}, &out, &errOut); code != 0 {
		t.Fatalf("unanchored exit %d\n%s", code, out.String())
	}
	for _, want := range []string{"ASSURANCE: CONSISTENT", "policy_replayed          pass", "anchored_head            not_checked", "Missing:", "No head anchor", "Policy and delegation", "[PASS] policy.replay"} {
		if !strings.Contains(out.String(), want) {
			t.Errorf("unanchored output lacks %q:\n%s", want, out.String())
		}
	}

	// The witness head anchors both keys and head.
	out.Reset()
	if code := run_(t, []string{"--witness", witnessFile, "--witness-key", key, run.Dir}, &out, &errOut); code != 0 {
		t.Fatalf("witness exit %d\n%s%s", code, out.String(), errOut.String())
	}
	for _, want := range []string{"ASSURANCE: ANCHORED", "[PASS] head.witness", "valid, cosigned the last entry", "matches the fingerprint the witness registered",
		// A saved head anchors the log but is not shown to be fresh.
		fmt.Sprintf("%-24s %s", "head_fresh", "not_checked"), fmt.Sprintf("%-24s %s", "run_complete", "not_checked"), "- [freshness] Head not shown to be fresh",
		"VERIFIED means only that no check failed"} {
		if !strings.Contains(out.String(), want) {
			t.Errorf("witness output lacks %q:\n%s", want, out.String())
		}
	}
	if strings.Contains(out.String(), "Not anchored") {
		t.Errorf("an anchored run must not say it is not anchored:\n%s", out.String())
	}

	// The base64 spelling of the key works too, and --json carries the assurance.
	out.Reset()
	if code := run_(t, []string{"--json", "--witness=" + witnessFile, "--witness-key=" + base64.StdEncoding.EncodeToString(public), run.Dir}, &out, &errOut); code != 0 {
		t.Fatalf("json witness exit %d", code)
	}
	var report auditverify.Report
	if err := json.Unmarshal(out.Bytes(), &report); err != nil || report.Assurance != auditverify.AssuranceAnchored || report.Anchors.Witness == nil {
		t.Fatalf("json report: %v %s %+v", err, report.Assurance, report.Anchors.Witness)
	}

	// A wrong witness key fails the run.
	out.Reset()
	if code := run_(t, []string{"--witness", witnessFile, "--witness-key", strings.Repeat("ab", 32), run.Dir}, &out, &errOut); code != 1 {
		t.Fatalf("wrong witness key exit %d, want 1", code)
	}
	if !strings.Contains(out.String(), "[FAIL] head.witness") || !strings.Contains(out.String(), "ASSURANCE: FAILED") {
		t.Fatalf("wrong witness key output:\n%s", out.String())
	}

	for _, args := range [][]string{
		{"--witness", witnessFile, run.Dir},                                              // key missing
		{"--witness-key", key, run.Dir},                                                  // file missing
		{"--witness", witnessFile, "--witness-key", "abc", run.Dir},                      // malformed key
		{"--witness", filepath.Join(t.TempDir(), "none"), "--witness-key", key, run.Dir}, // unreadable file
		{"--witness"},
	} {
		if code := run_(t, args, &out, &errOut); code != 2 {
			t.Errorf("args %q: exit %d, want 2", args, code)
		}
	}
}

// --witness-url fetches the witness's latest cosigned head for the run at
// verification time (loopback only).
func TestWitnessURL(t *testing.T) {
	run, err := fixture.WriteWith(filepath.Join(t.TempDir(), "run"), fixture.Options{Revision: true})
	if err != nil {
		t.Fatal(err)
	}
	document, public, err := fixture.CosignHead(run.Dir, run.HeadSeq)
	if err != nil {
		t.Fatal(err)
	}
	status, err := fixture.SignWitnessRunStatus(run.Dir, 0, "", time.Now())
	if err != nil {
		t.Fatal(err)
	}
	var requested []string
	server := witnessServer(t, map[string][]byte{"/runs/" + run.RunID + "/latest": document, "/runs/" + run.RunID: status}, &requested)
	key := hex.EncodeToString(public)

	var out, errOut bytes.Buffer
	if code := run_(t, []string{"--witness-url", server.URL, "--witness-key", key, run.Dir}, &out, &errOut); code != 0 {
		t.Fatalf("witness URL exit %d\n%s%s", code, out.String(), errOut.String())
	}
	if strings.Join(requested, " ") != "/runs/"+run.RunID+"/latest /runs/"+run.RunID || !strings.Contains(out.String(), "ASSURANCE: ANCHORED") ||
		!strings.Contains(out.String(), "[PASS] head.witness") || !strings.Contains(out.String(), "witness run status signed ") ||
		!strings.Contains(out.String(), ": no later segment continues this run") {
		t.Fatalf("requested %q, output:\n%s", requested, out.String())
	}
	// The fetched status is fresh: the head is the witness's current one and
	// the run is complete.
	for _, want := range []string{fmt.Sprintf("%-24s %s", "head_fresh", "pass"), fmt.Sprintf("%-24s %s", "run_complete", "pass")} {
		if !strings.Contains(out.String(), want) || strings.Contains(out.String(), "Head not shown to be fresh") {
			t.Fatalf("witness URL output lacks %q (or claims a stale head):\n%s", want, out.String())
		}
	}

	// A witness that does not know the run is an I/O error, not a verdict.
	out.Reset()
	errOut.Reset()
	if code := run_(t, []string{"--witness-url=" + server.URL + "/other/", "--witness-key", key, run.Dir}, &out, &errOut); code != 2 || !strings.Contains(errOut.String(), "404") {
		t.Fatalf("unknown run exit %d: %s", code, errOut.String())
	}

	for _, args := range [][]string{
		{"--witness-url", "http://192.0.2.10:8090", "--witness-key", key, run.Dir},             // not loopback
		{"--witness-url", "ftp://127.0.0.1/", "--witness-key", key, run.Dir},                   // not http
		{"--witness-url", server.URL, run.Dir},                                                 // key missing
		{"--witness-url", server.URL, "--witness", "file.json", "--witness-key", key, run.Dir}, // both sources
		{"--witness-url"},
	} {
		errOut.Reset()
		if code := run_(t, args, &out, &errOut); code != 2 {
			t.Errorf("args %q: exit %d, want 2", args, code)
		}
	}
	if !loopbackHost("127.0.0.1") || !loopbackHost("::1") || !loopbackHost("localhost") || loopbackHost("example.com") || loopbackHost("10.0.0.1") {
		t.Fatal("loopbackHost")
	}
}

// witnessServer serves fixed witness answers by path (404 unknown_run
// otherwise) and records the paths requested.
func witnessServer(t *testing.T, answers map[string][]byte, requested *[]string) *httptest.Server {
	t.Helper()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		*requested = append(*requested, r.URL.Path)
		w.Header().Set("Content-Type", "application/json")
		answer, ok := answers[r.URL.Path]
		if !ok {
			w.WriteHeader(http.StatusNotFound)
			_, _ = w.Write([]byte(`{"error":"headwitness: run is not registered","code":"unknown_run"}`))
			return
		}
		_, _ = w.Write(answer)
	}))
	t.Cleanup(server.Close)
	return server
}

// A restart segment withheld: the earlier folder is presented as the whole
// run. Its latest cosigned head is its genuine last entry, but the witness's
// run status says a later segment continued it, so --witness-url fails
// head.anchor (exit 1). The newest segment verifies ANCHORED; a saved head
// (--witness FILE) of the earlier folder cannot show the continuation.
func TestWitnessURLDetectsWithheldSegment(t *testing.T) {
	restart, err := fixture.WriteRestart(filepath.Join(t.TempDir(), "restart"))
	if err != nil {
		t.Fatal(err)
	}
	first, newest := restart.Segments[0], restart.Segments[1]
	answers := map[string][]byte{}
	var key string
	for _, segment := range []struct {
		run         fixture.Run
		continuedBy string
	}{{first, newest.RunID}, {newest, ""}} {
		document, public, err := fixture.CosignHead(segment.run.Dir, segment.run.HeadSeq)
		if err != nil {
			t.Fatal(err)
		}
		status, err := fixture.SignWitnessRunStatus(segment.run.Dir, 0, segment.continuedBy, time.Now())
		if err != nil {
			t.Fatal(err)
		}
		answers["/runs/"+segment.run.RunID+"/latest"], answers["/runs/"+segment.run.RunID] = document, status
		key = hex.EncodeToString(public)
	}
	var requested []string
	server := witnessServer(t, answers, &requested)

	var out, errOut bytes.Buffer
	if code := run_(t, []string{"--witness-url", server.URL, "--witness-key", key, first.Dir}, &out, &errOut); code != 1 {
		t.Fatalf("withheld segment exit %d\n%s%s", code, out.String(), errOut.String())
	}
	for _, want := range []string{"[FAIL] head.anchor", "was continued by run " + newest.RunID, "ASSURANCE: FAILED", "Head anchor MISMATCH", "the run was CONTINUED by run " + newest.RunID} {
		if !strings.Contains(out.String(), want) {
			t.Fatalf("withheld segment output lacks %q:\n%s", want, out.String())
		}
	}

	out.Reset()
	if code := run_(t, []string{"--witness-url", server.URL, "--witness-key", key, newest.Dir}, &out, &errOut); code != 0 ||
		!strings.Contains(out.String(), "ASSURANCE: ANCHORED") || !strings.Contains(out.String(), "Segments: the run continued across 1 gateway restart") {
		t.Fatalf("newest segment exit %d\n%s%s", code, out.String(), errOut.String())
	}

	// The documented limit of a saved head: ANCHORED, with the status
	// reported as not consulted.
	file := filepath.Join(t.TempDir(), "witness-head.json")
	if err := os.WriteFile(file, answers["/runs/"+first.RunID+"/latest"], 0o600); err != nil {
		t.Fatal(err)
	}
	out.Reset()
	if code := run_(t, []string{"--witness", file, "--witness-key", key, first.Dir}, &out, &errOut); code != 0 ||
		!strings.Contains(out.String(), "ASSURANCE: ANCHORED") || !strings.Contains(out.String(), "witness run status not consulted") {
		t.Fatalf("saved head exit %d\n%s%s", code, out.String(), errOut.String())
	}

	// A witness that answers the head but not the status: an I/O error,
	// never a silent fallback to the head alone.
	delete(answers, "/runs/"+first.RunID)
	errOut.Reset()
	if code := run_(t, []string{"--witness-url", server.URL, "--witness-key", key, first.Dir}, &out, &errOut); code != 2 || !strings.Contains(errOut.String(), "run status") {
		t.Fatalf("missing run status exit %d: %s", code, errOut.String())
	}
}

// The run status read by --witness-url must be the witness's current signed
// status naming the cosigned head fetched with it: an unsigned, tampered or
// stale status fails head.witness (exit 1), never anchors. A status that
// names a newer head than the head fetched before it (a push between the two
// reads) makes the CLI fetch both again.
func TestWitnessURLRunStatusMustBeSigned(t *testing.T) {
	restart, err := fixture.WriteRestart(filepath.Join(t.TempDir(), "restart"))
	if err != nil {
		t.Fatal(err)
	}
	first := restart.Segments[0]
	document, public, err := fixture.CosignHead(first.Dir, first.HeadSeq)
	if err != nil {
		t.Fatal(err)
	}
	previous, _, err := fixture.CosignHead(first.Dir, first.HeadSeq-1)
	if err != nil {
		t.Fatal(err)
	}
	key := hex.EncodeToString(public)
	fresh, err := fixture.SignWitnessRunStatus(first.Dir, 0, restart.Segments[1].RunID, time.Now())
	if err != nil {
		t.Fatal(err)
	}
	stale, err := fixture.WitnessRunStatus(first.Dir, restart.Segments[1].RunID)
	if err != nil {
		t.Fatal(err)
	}
	earlier, err := fixture.SignWitnessRunStatus(first.Dir, first.HeadSeq-1, restart.Segments[1].RunID, time.Now())
	if err != nil {
		t.Fatal(err)
	}
	stripped := strings.Replace(string(fresh), `"continued_by":"`+restart.Segments[1].RunID+`",`, "", 1)
	if stripped == string(fresh) {
		t.Fatal("the status names no continued_by")
	}
	headPath, statusPath := "/runs/"+first.RunID+"/latest", "/runs/"+first.RunID
	current := [][]byte{document}
	for _, tc := range []struct {
		name     string
		heads    [][]byte // answered in turn; the last one again after that
		statuses [][]byte
		code     int
		want     []string
		requests int
	}{
		{"unsigned registration", current, [][]byte{[]byte(`{"format":"agentgate-witness-run/v1","run_id":"` + first.RunID + `"}`)}, 1,
			[]string{"[FAIL] head.witness", "is not signed (format agentgate-witness-run/v1", "witness run status INVALID"}, 2},
		{"continued_by stripped", current, [][]byte{[]byte(stripped)}, 1, []string{"[FAIL] head.witness", "is not signed by the given witness key"}, 2},
		{"stale status", current, [][]byte{stale}, 1, []string{"[FAIL] head.witness", "is not the witness's current status"}, 2},
		{"status of an older head", current, [][]byte{earlier}, 1, []string{"[FAIL] head.witness", "describe different moments"}, 2},
		{"status always newer than the head", [][]byte{previous}, [][]byte{fresh}, 1, []string{"[FAIL] head.witness", "describe different moments"}, 6},
		{"push between the reads", [][]byte{previous, document}, [][]byte{fresh}, 1,
			[]string{"[PASS] head.witness", "[FAIL] head.anchor", "the run was CONTINUED by run " + restart.Segments[1].RunID}, 4},
		{"current signed status", current, [][]byte{fresh}, 1, []string{"[PASS] head.witness", "[FAIL] head.anchor", "was continued by run"}, 2},
	} {
		t.Run(tc.name, func(t *testing.T) {
			var mu sync.Mutex
			var requested []string
			heads, statuses := 0, 0
			server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				mu.Lock()
				defer mu.Unlock()
				requested = append(requested, r.URL.Path)
				w.Header().Set("Content-Type", "application/json")
				switch r.URL.Path {
				case headPath:
					_, _ = w.Write(tc.heads[min(heads, len(tc.heads)-1)])
					heads++
				case statusPath:
					_, _ = w.Write(tc.statuses[min(statuses, len(tc.statuses)-1)])
					statuses++
				default:
					w.WriteHeader(http.StatusNotFound)
				}
			}))
			defer server.Close()
			var out, errOut bytes.Buffer
			code := run_(t, []string{"--witness-url", server.URL, "--witness-key", key, first.Dir}, &out, &errOut)
			if code != tc.code || len(requested) != tc.requests {
				t.Fatalf("exit %d (want %d), %d requests (want %d)\n%s%s", code, tc.code, len(requested), tc.requests, out.String(), errOut.String())
			}
			for _, want := range tc.want {
				if !strings.Contains(out.String(), want) {
					t.Fatalf("output lacks %q:\n%s", want, out.String())
				}
			}
		})
	}
}

// A run that continued across a restart is verified from its newest folder,
// and the output lists the segments.
func TestRestartSegmentsOutput(t *testing.T) {
	restart, err := fixture.WriteRestart(filepath.Join(t.TempDir(), "restart"))
	if err != nil {
		t.Fatal(err)
	}
	var out, errOut bytes.Buffer
	if code := run_(t, []string{restart.Segments[1].Dir}, &out, &errOut); code != 0 {
		t.Fatalf("restart exit %d\n%s", code, out.String())
	}
	for _, want := range []string{"Segments: the run continued across 1 gateway restart(s)", "1. " + restart.Segments[0].RunID, "2. " + fixture.RestartRunID, "[PASS] files.continuity"} {
		if !strings.Contains(out.String(), want) {
			t.Errorf("output lacks %q:\n%s", want, out.String())
		}
	}
}

// --expect-earlier-keys pins the keys of a restarted run's earlier segments:
// with only --expect-keys the output says the keys anchor covers the newest
// segment only; with the earlier fingerprint (comma list, repeated flag or
// --flag=value) the keys are anchored; a fingerprint that matches no earlier
// segment fails keys.anchor; a malformed one is a usage error.
func TestExpectEarlierKeysFlag(t *testing.T) {
	restart, err := fixture.WriteRestart(filepath.Join(t.TempDir(), "restart"))
	if err != nil {
		t.Fatal(err)
	}
	fingerprint := func(dir string) string {
		data, err := os.ReadFile(filepath.Join(dir, "keys.json"))
		if err != nil {
			t.Fatal(err)
		}
		sum := sha256.Sum256(data)
		return hex.EncodeToString(sum[:])
	}
	newest, first := restart.Segments[1], restart.Segments[0]
	newestKeys, firstKeys := fingerprint(newest.Dir), fingerprint(first.Dir)

	var out, errOut bytes.Buffer
	if code := run_(t, []string{"--expect-keys", newestKeys, newest.Dir}, &out, &errOut); code != 0 {
		t.Fatalf("keys pin only: exit %d\n%s", code, out.String())
	}
	for _, want := range []string{"Keys anchored for the newest segment only", "--expect-earlier-keys", "[WARN] keys.anchor", "anchored_keys            not_checked"} {
		if !strings.Contains(out.String(), want) {
			t.Errorf("keys pin only: output lacks %q:\n%s", want, out.String())
		}
	}

	for _, args := range [][]string{
		{"--expect-keys", newestKeys, "--expect-earlier-keys", firstKeys, newest.Dir},
		{"--expect-keys", newestKeys, "--expect-earlier-keys=" + firstKeys + "," + newestKeys, newest.Dir},
		{"--expect-keys", newestKeys, "--expect-earlier-keys", firstKeys, "--expect-earlier-keys", " " + newestKeys + " ", newest.Dir},
	} {
		out.Reset()
		if code := run_(t, append([]string{"--json"}, args...), &out, &errOut); code != 0 {
			t.Fatalf("%q: exit %d\n%s", args, code, out.String())
		}
		var report auditverify.Report
		if err := json.Unmarshal(out.Bytes(), &report); err != nil {
			t.Fatal(err)
		}
		if report.Dimensions.AnchoredKeys.Status != auditverify.DimensionPass || !report.Anchors.EarlierKeysAnchored ||
			report.Anchors.EarlierKeysAnchoredBy != "pins" || report.Anchors.EarlierSegments != 1 || report.Anchors.ExpectedEarlierKeysSHA256[0] != firstKeys {
			t.Fatalf("%q: anchored_keys %+v, anchors %+v", args, report.Dimensions.AnchoredKeys, report.Anchors)
		}
	}

	out.Reset()
	if code := run_(t, []string{"--expect-keys", newestKeys, "--expect-earlier-keys", strings.Repeat("ab", 32), newest.Dir}, &out, &errOut); code != 1 {
		t.Fatalf("wrong earlier fingerprint: exit %d, want 1\n%s", code, out.String())
	}
	if !strings.Contains(out.String(), "[FAIL] keys.anchor") || !strings.Contains(out.String(), "none of the fingerprints pinned for the earlier segments") {
		t.Fatalf("wrong earlier fingerprint: output lacks the failure:\n%s", out.String())
	}

	for _, args := range [][]string{{"--expect-earlier-keys"}, {"--expect-earlier-keys", "abc", newest.Dir}, {"--expect-earlier-keys=" + firstKeys + ",zz", newest.Dir}} {
		if code := run_(t, args, &out, &errOut); code != 2 {
			t.Errorf("args %q: exit %d, want 2", args, code)
		}
	}
}

// --assume-compromised runs the key-compromise simulation and says so.
func TestAssumeCompromisedFlag(t *testing.T) {
	run, err := fixture.WriteWith(filepath.Join(t.TempDir(), "run"), fixture.Options{Revision: true})
	if err != nil {
		t.Fatal(err)
	}
	var out, errOut bytes.Buffer
	if code := run_(t, []string{"--assume-compromised", "AUDIT_LOG,adapter", run.Dir}, &out, &errOut); code != 0 {
		t.Fatalf("simulation exit %d\n%s%s", code, out.String(), errOut.String())
	}
	for _, want := range []string{"SIMULATION, NOT A VERIFICATION", "SIMULATION (signatures of AUDIT_LOG, ADAPTER not verified)", "ASSURANCE: SIMULATED_CONSISTENT", "SIMULATED: signatures of"} {
		if !strings.Contains(out.String(), want) {
			t.Errorf("simulation output lacks %q:\n%s", want, out.String())
		}
	}
	out.Reset()
	if code := run_(t, []string{"--json", "--assume-compromised=WITNESS", run.Dir}, &out, &errOut); code != 0 {
		t.Fatalf("json simulation exit %d", code)
	}
	var report auditverify.Report
	if err := json.Unmarshal(out.Bytes(), &report); err != nil || report.Simulation == nil || report.Simulation.AssumeCompromised[0] != "WITNESS" {
		t.Fatalf("json simulation: %v %+v", err, report.Simulation)
	}
	errOut.Reset()
	if code := run_(t, []string{"--assume-compromised", "ROOT", run.Dir}, &out, &errOut); code != 2 || !strings.Contains(errOut.String(), "unknown role") {
		t.Fatalf("unknown role exit %d: %s", code, errOut.String())
	}
	if code := run_(t, []string{"--assume-compromised"}, &out, &errOut); code != 2 {
		t.Fatalf("missing roles exit %d", code)
	}
}
