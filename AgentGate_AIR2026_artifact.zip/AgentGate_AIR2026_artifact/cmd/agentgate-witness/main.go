// Command agentgate-witness runs the audit-head witness in its own process,
// with its own Ed25519 key and its own append-only store
// (docs/demo/REVISION_CONTRACT.md R5, package internal/headwitness).
//
//	agentgate-witness -dir DIR -enroll-key KEY [-enroll-key KEY ...] [-addr 127.0.0.1:0] [-stdin-shutdown]
//
// -dir holds witness-key.json (generated on first start; it contains the
// private key, keep it out of the gateway's run folders) and
// witness-store.jsonl (every registration and cosigned head, synced before
// each answer). Restarting with the same -dir keeps the key and the history.
// Run at most one witness process per -dir.
// -enroll-key names a gateway enrollment public key: the standard base64 of
// the 32-byte Ed25519 key, or the path of a file holding that text. It is
// required and repeatable; the witness registers a run or a continuation
// only when the request is signed by one of these keys (and a continuation
// only by the key that registered the run it continues), so a process that
// does not hold a gateway's enrollment private key cannot register, preempt
// or continue a run (internal/headwitness/enrollment.go). There is no open
// mode.
// -addr must be a loopback address; port 0 picks a free port.
// -stdin-shutdown makes the process exit cleanly when its stdin closes (used
// by headwitness.StartProcess).
//
// Once listening it prints one JSON ready line on stdout (headwitness.ReadyLine)
// and logs to stderr. API: see internal/headwitness/http.go. A run continued
// after a gateway restart registers its new evidence segment with
// "continues"; the witness accepts it only on top of the earlier run's final
// cosigned head and closes the earlier run (internal/headwitness/witness.go).
// GET /runs/{id} answers the run status (registration with its enrollment
// key ID, continued_by, latest cosigned head, signing time) signed with the
// witness key, so a verifier can tell the witness's current status from a
// forged or replayed one.
package main

import (
	"context"
	"crypto/ed25519"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"time"

	"agentgate/internal/headwitness"
)

func main() { os.Exit(run()) }

// enrollKeys collects the repeatable -enroll-key flag.
type enrollKeys []ed25519.PublicKey

func (k *enrollKeys) String() string { return fmt.Sprintf("%d key(s)", len(*k)) }

func (k *enrollKeys) Set(value string) error {
	public, err := readEnrollKey(value)
	if err != nil {
		return err
	}
	*k = append(*k, public)
	return nil
}

// readEnrollKey reads one -enroll-key value: base64 of the key, or a file
// holding it.
func readEnrollKey(value string) (ed25519.PublicKey, error) {
	if public, err := headwitness.ParseEnrollmentPublicKey(value); err == nil {
		return public, nil
	}
	data, err := os.ReadFile(value)
	if err != nil {
		return nil, fmt.Errorf("-enroll-key %q is neither the standard base64 of a 32-byte Ed25519 key nor a readable file: %v", value, err)
	}
	public, err := headwitness.ParseEnrollmentPublicKey(strings.TrimSpace(string(data)))
	if err != nil {
		return nil, fmt.Errorf("-enroll-key file %s: %v", value, err)
	}
	return public, nil
}

func run() int {
	var enroll enrollKeys
	addr := flag.String("addr", "127.0.0.1:0", "loopback address to listen on (port 0 picks a free port)")
	dir := flag.String("dir", "", "witness directory (key and store); created if missing")
	flag.Var(&enroll, "enroll-key", "gateway enrollment public key (standard base64, or a file holding it); required, repeatable")
	stdinShutdown := flag.Bool("stdin-shutdown", false, "exit cleanly when stdin closes")
	flag.Parse()
	log.SetFlags(log.Ltime)
	log.SetPrefix("agentgate-witness: ")
	if *dir == "" || len(enroll) == 0 || flag.NArg() != 0 {
		fmt.Fprintln(os.Stderr, "usage: agentgate-witness -dir DIR -enroll-key KEY [-enroll-key KEY ...] [-addr 127.0.0.1:0] [-stdin-shutdown]")
		if *dir != "" && len(enroll) == 0 {
			fmt.Fprintln(os.Stderr, "agentgate-witness: at least one -enroll-key is required; the witness registers only runs signed by an enrolled gateway")
		}
		return 2
	}
	if err := requireLoopback(*addr); err != nil {
		log.Print(err)
		return 2
	}

	service, err := headwitness.Open(headwitness.Options{Dir: *dir, EnrollmentKeys: enroll})
	if err != nil {
		log.Print(err)
		return 1
	}
	defer service.Close()

	listener, err := net.Listen("tcp", *addr)
	if err != nil {
		log.Print(err)
		return 1
	}
	server := &http.Server{Handler: service.Handler(), ReadHeaderTimeout: 5 * time.Second}
	served := make(chan error, 1)
	go func() { served <- server.Serve(listener) }()

	key := service.Key()
	ready, _ := json.Marshal(headwitness.ReadyLine{
		Ready: "agentgate-witness", Origin: "http://" + listener.Addr().String(),
		Role: key.Role, KID: key.KID, PublicKey: key.PublicKey, PID: os.Getpid(),
	})
	fmt.Println(string(ready))
	log.Printf("listening on %s, witness kid %s, store %s, enrollment keys %s", listener.Addr(), key.KID, *dir, strings.Join(service.EnrollmentKIDs(), ", "))

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt)
	stdinClosed := make(chan struct{})
	if *stdinShutdown {
		go func() {
			_, _ = io.Copy(io.Discard, os.Stdin)
			close(stdinClosed)
		}()
	}
	select {
	case err := <-served:
		if !errors.Is(err, http.ErrServerClosed) {
			log.Print(err)
			return 1
		}
	case <-stop:
	case <-stdinClosed:
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	_ = server.Shutdown(ctx)
	log.Print("stopped")
	return 0
}

// requireLoopback refuses a listen address whose host is not a loopback IP.
func requireLoopback(addr string) error {
	host, _, err := net.SplitHostPort(addr)
	if err != nil {
		return fmt.Errorf("invalid -addr %q: %w", addr, err)
	}
	if ip := net.ParseIP(host); ip == nil || !ip.IsLoopback() {
		return fmt.Errorf("-addr %q must be a numeric loopback address such as 127.0.0.1:0", addr)
	}
	return nil
}
