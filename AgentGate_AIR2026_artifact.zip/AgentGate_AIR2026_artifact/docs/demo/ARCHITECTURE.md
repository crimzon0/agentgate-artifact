# AgentGate supervisor demo: architecture

This page explains how the demo works, where each part lives in the code, and
what is cryptographically bound to what. The build contract (formats, audit
vocabulary, API) is [CONTRACTS.md](CONTRACTS.md). The talk track is
[PRESENTER_GUIDE.md](PRESENTER_GUIDE.md).

## In one paragraph

An AI agent can be manipulated, so AgentGate treats it as **untrusted**. The
agent can only ask for one of three effects (`external_message.send`,
`document.release`, `financial_request.create`) through an MCP tool call.
AgentGate then works like a **reference monitor**: it validates the request
against a fixed catalog, evaluates a readable content policy, issues a
short-lived single-use **capability** for that exact action, and lets an
adapter execute it against a (simulated) provider that returns signed
receipts. Every step is written to a **flight recorder**: a hash-chained,
signed log. A separate **verifier** re-checks the whole run from the files
alone, spread over all CPU cores, and reconciles it with the provider's own
journal.

Companies already run agents autonomously, so by default **no human approves
individual actions**. The policy decides **ALLOW / ALLOW-AND-FLAG / DENY**:
an action that a rule would once have sent to a person runs, but it is
**flagged for audit**. The flag is part of the policy decision whose hash
the signed capability carries, and the action is listed in an **audit
queue**. Nothing reviews that queue yet (an automatic audit is future work);
for now flagged actions are recorded and listed. **Human approval is still fully available as an
option** (`-HumanApproval`): those actions then pause until a reviewer
approves or rejects the exact action. A strict third mode denies them.

| Escalation mode | Rules that would ask a human... | Start with |
|---|---|---|
| `flag` (default) | let the action run, flagged for audit (audit queue) | `scripts\demo.ps1` |
| `human` (optional) | pause it for the reviewer's signed decision | `scripts\demo.ps1 -HumanApproval` |
| `deny` | deny it | `scripts\demo.ps1 -Escalation deny` |

Hard DENY rules (hard limit, restricted documents, confidential data leaving
the company, hidden external BCC, disallowed currency), the catalog check and
every later gateway check are the same in all three modes.

## Revision 2026-10-07: delegation, explicit outcomes, custody

The supervisor's review asked for five changes; each is in the demo:

- **Bounded autonomous delegation.** Autonomous mode now runs under an
  explicit consent artefact: the organisation's signed delegation grant
  (purpose, effect types, recipients, payees, cumulative budget per currency,
  counts per type, validity window, revocation). The organisation key
  (`DELEGATION_AUTHORITY`) is held by the demo, never by the gateway, which
  receives only the signed grant (`internal/demo/delegation.go`,
  `internal/devcomposition/delegation.go`). Anything outside the grant is
  denied (DEL-* rules); split payments that each pass the per-payment rule
  are stopped by the cumulative budget. The dashboard shows the grant, the
  budget used and left, and a revoke button.
- **Explicit operation outcomes.** Every call ends REJECTED, PENDING,
  COMMITTED, UNCERTAIN or RECONCILIATION_REQUIRED (`internal/devcomposition/
  auditing.go`, `durable.go`). REJECTED means no provider effect exists; a
  lost provider answer is UNCERTAIN and an exact retry reconciles it with the
  provider's signed status (`RECONCILED`) instead of dispatching again.
- **Operation journal.** With `-durable` (default) the gateway persists
  operation transitions in `operations.jsonl` and replays it on a restart:
  completed operations return their stored result, consumed capabilities stay
  consumed, dispatched-but-unanswered operations are reconciled first, and the
  delegation ledger is restored.
- **Assurance, not just a verdict.** The verifier re-runs the policy from the
  snapshot in run.json (`policy.replay`), checks the delegation, and reports
  FAILED / CONSISTENT / ANCHORED with seven dimensions plus two derived ones
  (freshness, `head_fresh`, and run completeness, `run_complete`; they own no
  check and change no verdict) and a list of what the evidence cannot show
  (Verify tab). The legacy verdict VERIFIED means only that no check failed.
- **Separate custody (optional).** `-external-provider` runs the simulated
  provider as its own process with its own key and journal;
  `-witness` runs a head witness that countersigns the audit head after every
  operation and refuses rollbacks and forks. Its cosigned head, saved outside
  the run folder, anchors the verifier on its own.

```mermaid
flowchart LR
  subgraph DEMO["agentgate-demo process"]
    ORG["Organisation key<br/>signs the grant"]
    GW["Gateway (internal/devcomposition)<br/>policy + DEL-* rules, lifecycle, journal"]
    LOG["Audit log (AUDIT_LOG key)"]
  end
  subgraph PROV["agentgate-provider process (-external-provider)"]
    SIM["Simulator, own key,<br/>synced request log"]
  end
  subgraph WIT["agentgate-witness process (-witness)"]
    W["Countersigns heads,<br/>refuses rollback / fork"]
  end
  ORG -- "signed grant + public key" --> GW
  GW -- "HTTP, capability-bound requests" --> SIM
  LOG -- "head + new lines after every operation" --> W
  W -. "cosigned head (saved outside the run folder)" .-> V["agentgate-verify --witness"]
```

Without the two options everything still runs in one process, as before.

## Components

```mermaid
flowchart LR
  subgraph U["Untrusted"]
    AG["AI agent<br/>scripted scenarios or live LLM<br/>internal/demo"]
  end

  subgraph G["AgentGate gateway (trusted), inside agentgate-demo"]
    MCP["MCP boundary<br/>internal/mcp/official.go"]
    CP["Control point<br/>internal/controlpoint"]
    NORM["Normalizer<br/>internal/devcomposition"]
    POL["Content policy PRE / FINAL<br/>internal/devcomposition"]
    APR["Approval authority (human mode only)<br/>internal/devapproval"]
    ISS["Capability issuer + registry<br/>internal/capability"]
    ADP["Adapters<br/>internal/adapters"]
    WRAP["Audit wrappers<br/>internal/devcomposition"]
  end

  subgraph H["Human (optional)"]
    UI["Reviewer in the dashboard<br/>internal/demo/assets"]
  end

  Q["Audit queue: flagged actions<br/>GET /api/flagged, from the log"]

  subgraph P["Simulated provider: same process, loopback HTTP"]
    SIM["Simulator<br/>internal/simulator"]
  end

  subgraph E["Evidence: demo-runs/RUN_ID/"]
    LOG["audit.jsonl + head.json<br/>internal/audit"]
    JRN["provider-journal.json"]
    META["keys.json + run.json"]
  end

  VER["Independent verifier<br/>internal/auditverify<br/>cmd/agentgate-verify"]

  AG -- "MCP tools/call" --> MCP --> CP
  CP --> NORM
  CP --> POL
  CP --> APR
  UI -. "approve / reject (human mode, relayed by internal/demo)" .-> APR
  LOG -. "allow_flagged entries" .-> Q
  CP --> ISS
  CP --> ADP
  ADP -- "HTTP + single-use capability" --> SIM
  SIM -- "signed provider receipt" --> ADP
  WRAP -- "AuditEvent -> AuditSink" --> LOG
  SIM -. "Snapshot after every call" .-> JRN
  LOG --> VER
  JRN --> VER
  META --> VER
```

| Component | What it does | Code |
|---|---|---|
| Launcher | Builds offline and starts one process; picks the escalation mode (`-HumanApproval`, `-Escalation flag\|human\|deny`); optional hidden OpenRouter key prompt. | `scripts/demo.ps1`, `scripts/demo.sh` |
| Demo server | Creates the run directory and keys, wires the gateway in the chosen escalation mode (`-escalation`, default `flag`), runs the scripted agent and scenarios, serves the dashboard API and the audit queue, relays human decisions (human mode only), implements the `AuditSink`, rewrites the provider journal after every call. | `internal/demo` (`*.go`; modes and audit queue in `escalation.go`), `cmd/agentgate-demo` |
| Dashboard | Mode chip, scenario cards, 7-step pipeline (step 4 "Escalation", or "Human approval" in human mode), Flagged badges, Audit queue, approval card (human mode), Outside world (provider), Audit trail, Verify, Tamper lab. | `internal/demo/assets` |
| Agent | Proposes tool calls through a real MCP client. Scripted by default; optionally a live LLM via OpenRouter. Untrusted either way. | `internal/demo` |
| MCP boundary | Official MCP Go SDK (stateless). Three tools with strict JSON Schemas (published to the agent; the SDK does not enforce them, so extra fields are rejected by the normalizer); strict JSON parsing (no duplicate keys, no unsafe numbers or fractions); bearer authentication; errors reach the agent only as "call denied". | `internal/mcp/official.go`; authenticator in `internal/devcomposition/composition.go` |
| Control point | Per-operation state machine: normalize, PRE policy, approval begin/resume (human mode), FINAL policy, issue capability, dispatch, verify the result. Keyed by operation ID, so an exact retry returns the stored result instead of acting again. Unchanged by the escalation modes: a flagged action reaches it as `ALLOW_BASE`. | `internal/controlpoint` (`controlpoint.go`, `store.go`) |
| Normalizer | Turns untrusted arguments into one canonical `EffectObject`, using only the frozen catalog (recipient IDs, payee IDs, document SHA-256 digests). Unknown names cannot be expressed. | `internal/devcomposition` (`components.go`, `devNormalizer`); effect type and digest in `internal/effects` |
| Content policy | The `falcon-demo-policy` rules (CONTRACTS §3). Every firing rule becomes a reason `{rule_id, outcome, message}`. The escalation mode decides what the escalating rules produce: FLAG (DENY > FLAG > ALLOW), REQUIRE_APPROVAL (DENY > REQUIRE_APPROVAL > ALLOW) or DENY. The mode and the flag are part of the policy hash and of the PRE and FINAL decision values. FINAL re-evaluates and refuses if the decision changed. | `internal/devcomposition/policy.go` (rules, reasons, policy hash); parameters `ContentPolicy` and `Escalation` in `audit.go`; PRE/FINAL entry points on `devPolicy` in `components.go` |
| Audit wrappers | Wrap normalizer, policy, approval, issuer, dispatcher and coordinator; emit one `AuditEvent` per step. If recording fails the step fails closed: no authority is created past an unrecorded step. | `internal/devcomposition/auditing.go` (wrappers); `AuditEvent`, `AuditSink` in `audit.go`; adapter to the audit log in `internal/demo/auditsink.go` |
| Approval authority (human mode only) | On `Begin`, signs a request state bound to the exact effect. On the human's click, signs a decision. On `Resume`, re-verifies both and checks they match the resumed effect. Approvals expire after at most 120 s. In the autonomous modes it is not created at all, so nothing can wait for, or forge, a human decision. | `internal/devapproval` (`authority.go`, `handler.go`) |
| Capability issuer and registry | Issues a COSE-signed CWT capability: 60 s lifetime, one adapter audience, bound to the effect digest and the FINAL decision hash. The registry lets it be consumed exactly once. | `internal/capability/capability.go`; glue in `internal/devcomposition/components.go` (`devIssuer`) |
| Adapters | Consume the capability once with an adapter proof of possession, send the canonical request to the provider, verify the provider receipt, sign an effect receipt. | `internal/adapters` (`adapters.go`, `capability_fence.go`, `http_transport.go`, `effect_receipt.go`); glue in `internal/devcomposition/dispatch.go` |
| Simulator | Stands in for the email, document and finance providers. Runs inside the demo process (its own loopback HTTP listener and its own key). Idempotent per request key; every commit gets a sequence number, a state-before/after hash and a receipt signed with the provider's key. | `internal/simulator` (`runtime.go`, `http.go`, `model.go`, `types.go`) |
| Audit log | Append-only JSON Lines; each entry hash-chained to the previous one and Ed25519-signed; signed head checkpoint replaced after every append. | `internal/audit/audit.go` |
| Verifier and tamper lab | Re-checks a run directory from files alone (CONTRACTS §6). Imports no gateway package, so a writer bug is not silently mirrored. Runs its independent checks (parsing, entry hashes and signatures, artifacts, the per-operation walk, provider receipts) on a bounded worker pool, one worker per CPU by default, and replays the results in sequential order, so the report is byte-identical to a one-worker run. Opens the logged PRE and FINAL decision values and reports an execution as flagged from the decision its capability commits to (`decisions.go`). The dashboard's button runs it inside the demo process on a consistent copy of the files; `agentgate-verify [--workers N]` runs the same code as its own program. The tamper lab mutates a copy of a run. | `internal/auditverify` (`verify.go`, `operations.go`, `decisions.go`, `parallel.go`, `tamper.go`), CLI `cmd/agentgate-verify` |
| Shared primitives | Deterministic CBOR and domain-separated hashing; COSE_Sign1 profiles. | `internal/canon`, `internal/signed` |

## One flagged action, end to end (default, autonomous)

Scenario `shipping-invoice` in flag mode: the agent asks for AED 12,400.00 to
BlueWave Shipping Co., above the AED 5,000.00 automatic limit. Each note names
the audit stage that is written at that point.

```mermaid
sequenceDiagram
  autonumber
  participant Agent as Agent (untrusted)
  participant MCP as MCP boundary
  participant CP as Control point
  participant Pol as Policy
  participant Iss as Capability issuer
  participant Ad as Adapter
  participant Sim as Simulator (provider)

  Agent->>MCP: tools/call financial_request.create (payee.bluewave, 1240000, AED)
  Note right of Agent: AGENT_PROPOSED
  MCP->>CP: schema-checked arguments + authenticated identity
  CP->>CP: normalize against catalog -> EffectObject + effect digest
  Note right of CP: REQUEST_VALIDATED (effect_cbor)
  CP->>Pol: PRE(effect)
  Pol-->>CP: ALLOW_BASE, PRE value with mode "flag", flagged=true, [FIN-APPROVAL-LIMIT]
  Note right of CP: POLICY_DECISION allow_flagged
  CP->>Pol: FINAL(effect, PRE)
  Pol-->>CP: re-evaluated, same PRE hash -> DEV_FINAL_FLAGGED (flag, true, rule IDs)
  Note right of CP: POLICY_FINAL flagged=true
  CP->>Iss: Issue(effect, FINAL)
  Iss-->>CP: capability (60 s, single use, digest + hash of the flagged FINAL)
  Note right of CP: CAPABILITY_ISSUED
  CP->>Ad: Dispatch(effect, capability)
  Ad->>Sim: commit request (idempotency key)
  Sim-->>Ad: signed provider receipt
  Ad-->>CP: signed effect receipt (carries the same policy decision hash)
  Note right of CP: EFFECT_EXECUTED
  CP-->>Agent: completed + provider reference
  Note right of Agent: CALL_RESULT completed flagged=true, AGENT_RECEIVED
```

No one waits, but the flag is bound to the authorization. It is in the PRE
value, and the FINAL value (`DEV_FINAL_FLAGGED`) commits to the PRE hash; the
FINAL hash is the capability's `policy_decision_hash`, signed by the
capability issuer and repeated in the adapter's effect receipt. The gateway
logs both values (`details.decision_value`), and the verifier recomputes both
hashes, so it reads the flag from the values the capability commits to, not
from details that only the audit key protects. Removing or inventing the
flag of an operation executed with an adapter receipt was therefore accepted,
among the key sets we tested, only with the capability issuer's and the
adapter's keys as well as the audit key; with the audit key alone it fails
`op.capability_bound` or `op.requires_policy`. For an operation recorded as
committed through reconciliation (a provider-signed status, no adapter
receipt) the audit and issuer keys sufficed (corrected 2026-10-10;
`docs/paper/data/build2/fixture-studies/RESULTS.md`). (All keys live in the one gateway process here, so this
protects the files after the fact, not against a compromised gateway.) The
dashboard lists the action in the **Audit queue** (`GET /api/flagged`), built
from the signed log. In deny mode the same request stops at POLICY_DECISION
`deny`, like a hard limit.

## With human approval (optional), end to end

The same scenario started with `-HumanApproval`: the rule now asks a person.

```mermaid
sequenceDiagram
  autonumber
  participant Agent as Agent (untrusted)
  participant MCP as MCP boundary
  participant CP as Control point
  participant Pol as Policy
  participant Appr as Approval authority
  participant Human as Reviewer (dashboard)
  participant Iss as Capability issuer
  participant Ad as Adapter
  participant Sim as Simulator (provider)

  Agent->>MCP: tools/call financial_request.create (payee.bluewave, 1240000, AED)
  Note right of Agent: AGENT_PROPOSED
  MCP->>CP: schema-checked arguments + authenticated identity
  CP->>CP: normalize against catalog -> EffectObject + effect digest
  Note right of CP: REQUEST_VALIDATED (effect_cbor)
  CP->>Pol: PRE(effect)
  Pol-->>CP: REQUIRE_APPROVAL [FIN-APPROVAL-LIMIT], PRE hash
  Note right of CP: POLICY_DECISION
  CP->>Appr: Begin(effect, PRE)
  Appr-->>CP: signed request state (digest, operation, PRE hash, expiry)
  Note right of CP: APPROVAL_REQUESTED
  CP-->>Agent: inputRequired + requestState
  Note right of CP: CALL_RESULT approval_required
  Human->>Appr: Approve (sees exact fields, reasons, fingerprint)
  Note right of Human: HUMAN_DECISION (signed decision)
  Agent->>MCP: same tools/call + requestState
  MCP->>CP: resume
  CP->>Appr: Resume(effect, PRE, requestState)
  Appr-->>CP: signed state + signed APPROVED decision
  Note right of CP: APPROVAL_VERIFIED
  CP->>Pol: FINAL(effect, PRE, approval)
  Pol-->>CP: ALLOW, FINAL hash
  Note right of CP: POLICY_FINAL
  CP->>Iss: Issue(effect, FINAL)
  Iss-->>CP: capability (60 s, single use, digest + FINAL hash)
  Note right of CP: CAPABILITY_ISSUED
  CP->>Ad: Dispatch(effect, capability)
  Ad->>Ad: consume capability once + proof of possession
  Ad->>Sim: commit request (idempotency key)
  Sim-->>Ad: signed provider receipt (commit_seq, state before/after)
  Ad-->>CP: signed effect receipt (cti, digest, provider receipt hash)
  Note right of CP: EFFECT_EXECUTED
  CP-->>Agent: completed + provider reference
  Note right of Agent: CALL_RESULT completed, AGENT_RECEIVED
```

If the agent resumes with a different action under the same operation ID
(scenario `approval-swap`, human mode only), the control point refuses it at the operation
check: that operation ID is already bound to the approved request's digest.
The signed request state would not fit a fresh operation ID either: it names
the original operation and effect digest. No capability is issued. If the human rejects (scenario
`suspicious-invoice`), `Resume` returns a rejection and the chain stops before
FINAL.

## What is bound to what

Each link names the value it commits to, so changing anything earlier breaks
every later link. The right column is the verifier check that re-tests it.

| # | Evidence | Signed by (key role) | Commits to | Verifier check |
|---|---|---|---|---|
| 1 | **Effect digest** (the "fingerprint") | hash: SHA-256 over `"AgentGate/EffectObject/v1"` + canonical CBOR | the exact effect: type, tenant, principal, operation ID, task, catalog snapshot, recipients / document digest / payee, amount, currency, text | `artifact.effect_digest` |
| 2 | **PRE decision hash** | hash (value logged in POLICY_DECISION `decision_value`) | policy hash (which includes the escalation mode), outcome, effect digest, sorted fired rule IDs; in flag and deny mode also the mode and flagged true/false | `op.requires_policy` (recomputes the hash from the logged value and compares outcome, flag, mode and reasons with the entry) |
| 3 | **Approval request state** (human mode) | `APPROVAL_AUTHORITY` | tenant, principal, operation ID, effect digest, PRE hash, approval ID, issued/expires, nonce | `op.approval_bound` |
| 4 | **Human decision** (human mode) | `APPROVAL_AUTHORITY` | APPROVED/REJECTED, approver, operation ID, effect digest, PRE hash, approval ID, hash of the request state, decided-at | `op.approval_bound` |
| 5 | **FINAL decision hash** | hash (value logged in POLICY_FINAL `decision_value`) | PRE hash, operation, effect type, policy hash and, when approved, the approval artifacts' overlay root; when flagged (`DEV_FINAL_FLAGGED`), the mode "flag", flagged=true and the flagging rule IDs | `op.requires_policy` (recomputes the hash, checks that field 3 is a logged PRE hash and that PRE and FINAL agree on the flag), `op.capability_bound` (FINAL hash = capability's hash) |
| 6 | **Capability token** (CWT) | `CAPABILITY_ISSUER` | `cti`, 60 s validity, one adapter audience, the adapter's key (proof of possession), operation ID, effect type, effect digest, policy decision hash = FINAL hash, policy hash | `op.capability_bound`, `op.single_use` |
| 7 | **Provider receipt** | `SIMULATOR_PROVIDER` | operation ID, effect digest, idempotency key, provider reference, `commit_seq`, state hash before and after | `op.receipts_bound`, `provider.*` |
| 8 | **Effect receipt** | `ADAPTER_MESSAGE` / `ADAPTER_DOCUMENT` / `ADAPTER_FINANCIAL` | capability `cti` and hash, effect digest, policy decision hash, hash of the provider receipt, provider reference, outcome | `op.receipts_bound` |
| 9 | **Audit entry** | `AUDIT_LOG` | who / what / when / which component / where, the artifacts above, and the previous entry's hash | `chain.*` |
| 10 | **Head checkpoint** | `AUDIT_LOG` | run ID, last sequence number, last entry hash (detects truncation) | `head.signature`, `head.matches` |
| 11 | **Provider journal** | provider receipts (`SIMULATOR_PROVIDER`) | the provider's own ordered list of committed effects and its state hash | `provider.signature`, `provider.state_chain`, `provider.matches_audit` |
| 12 | **Policy snapshot** (run.json `policy_snapshot`) | not signed; its recomputed policy hash must equal the policy hash in every capability (`CAPABILITY_ISSUER`) and decision value | every rule parameter the replay uses: per-currency limits, `max_recipients`, escalation mode, FIN-ZERO, confidential-text shingle hashes | `policy.snapshot_bound`, then `policy.replay` |
| 13 | **Catalog** (run.json `catalog`) | not signed; its recomputed commitment must equal the catalog snapshot hash in every effect (row 1) | recipients (external flags), payees, documents (classification, SHA-256) | `policy.snapshot_bound` |

The chain in short: **effect digest -> policy decision (with the flag) ->
approval (human mode) -> capability -> receipts -> audit chain -> provider
journal.**

## Evidence on disk

Every launch creates `demo-runs/run-YYYYMMDD-HHMMSS-<6 hex>/` (ignored by Git).

| File | Written by | Contents |
|---|---|---|
| `audit.jsonl` | `internal/audit` | One line per step: `{"entry_hash","signature","entry"}`; entries carry the signed artifacts as base64 |
| `head.json` | `internal/audit` | Signed checkpoint of the latest entry, replaced atomically after every append |
| `keys.json` | `internal/demo` via `internal/audit` | Public keys only, one per role, with KIDs |
| `run.json` | `internal/demo` | Run ID, host, PID, identity, policy rules and hash, catalog with document SHA-256s, `keys_sha256`, simulator origin. Written once, before RUN_STARTED, which records its SHA-256 |
| `provider-journal.json` | `internal/demo` from the simulator snapshot | The simulated provider's signed receipts, `commit_seq`, state hash (the demo process writes the file) |

Tamper-lab copies go to `demo-runs/tamper-lab/<run id>/<kind>-<n>/`, next to
the evidence folder and never inside it; the live run is never changed.

Keys (all Ed25519, generated fresh per run, private halves never leave the
process): `AUDIT_LOG`, `CAPABILITY_ISSUER`, `SIMULATOR_PROVIDER`,
`ADAPTER_MESSAGE`, `ADAPTER_DOCUMENT`, `ADAPTER_FINANCIAL`, and in human mode
also `APPROVAL_AUTHORITY` (six keys in the autonomous modes, seven in human
mode).

## Trust boundaries

1. **Agent -> gateway.** Everything the agent sends is untrusted. It reaches
   the gateway only through the MCP boundary (authenticated, strict schema,
   strict JSON). The agent has no reference to the simulator, the approval
   authority or any key.
2. **Human -> approval authority** (human mode only). Only the dashboard's
   approval relay can produce a decision. The agent can carry the signed
   request state back, but cannot forge or alter it: the signature and the
   effect digest are re-checked on resume. In the autonomous modes there is no
   approval authority and no relay; if the gateway ever asked for a human,
   the agent side stops instead of waiting (fail closed).
3. **Adapter -> provider.** The adapter needs a valid, unused capability for
   the exact effect. The provider signs its own receipts with its own key and
   keeps its own journal, which the verifier compares with the audit log.
4. **Writer -> verifier.** The verifier shares no code with the writer and
   reads only files, so anyone with the run folder can re-check it.

In this demo all gateway roles **and the simulated provider** run in **one
OS process on one machine**. The boundaries are code and interface boundaries
(plus loopback HTTP to the provider), not separate processes, machines or key
custodians. The provider journal is a second record, signed with the
provider's own key, by design; here its key and the file it is written to are
in the same process.

## Trust anchors

Every signature is checked against `keys.json` from the run folder, and the
end of the log against `head.json` from the same folder. The files alone
therefore prove only that they are consistent with each other. Two values held
outside the folder close the remaining gaps:

| Anchor | Where it comes from | What it catches |
|---|---|---|
| Keys fingerprint (SHA-256 of `keys.json`) | pinned in memory at startup, printed in the terminal banner | someone who rewrites the folder and re-signs everything with substitute keys (`keys.anchor`) |
| Head hash (last entry) | the live log when the dashboard verifies; printed in the terminal when the demo stops | a rollback to an earlier, genuinely signed checkpoint (`head.anchor`; tamper `rollback`) |

Without a pin each check is a warning, never a failure. The dashboard pins
both; `agentgate-verify --expect-keys <fp> --expect-head <hash> <dir>` does the
same from a terminal. Both values live in the process that writes the log, so
they protect against later edits of the files, not against a compromised
gateway.

## What this prototype does not claim

- It does **not** detect or prevent prompt injection. It assumes the agent can
  be manipulated and limits, authorizes, records and verifies the effects a
  manipulated agent can cause.
- All providers are **simulated**. No real email, document or money leaves the
  computer.
- **Keys are generated per run on this machine, in one process.** Signatures
  show which role produced an artifact and that it was not changed afterwards.
  They do not show independent custody: a fully compromised gateway process
  could write a self-consistent false log, and in this demo it also holds the
  simulated provider's key unless `-external-provider` is used. The pinned
  keys fingerprint and head hash (or the witness's cosigned head) catch later
  edits of the files; keys held by different organisations are future work.
- **A flag is evidence, not prevention.** In the default autonomous mode a
  flagged action has already run when it appears in the audit queue. Nobody
  and nothing reviews the queue yet: the automatic audit is future work, so a
  flagged action can go unexamined for as long as nobody looks. What the
  prototype guarantees is that the flag is recorded, bound into the decision
  whose hash the capability carries, and checked by the verifier. Hard DENY
  rules still stop the worst actions without a human.
- In human mode the approval is a **click in a local dashboard** (a DEV
  approval authority). There is no passkey/WebAuthn, approver identity
  proofing or trusted preview in this demo.
- Clocks are local and unauthenticated; timestamps are evidence of order, not
  of true time.
- The operation journal survives a gateway restart (the self-test rebuilds
  the gateway on it and checks stored outcomes, no new provider effect and the
  restored budget), but a demo launch is still a new run: the dashboard does
  not reopen an earlier run folder. Pending approvals do not survive a
  restart, and a revocation is not journaled (after a restart the demo must
  revoke again). An approval that is never resumed keeps its delegation
  reservation until the grant ends.
- The delegation grant bounds what the agent may do; it does not show that an
  allowed action serves the user's task. MSG-CONFIDENTIAL-TEXT catches
  verbatim copies of 12 or more words, not paraphrases: it is copy
  detection, not information-flow control.
- With `-external-provider` and `-witness` the provider and witness keys live
  in other processes on the same machine and under the same OS user. That
  separates the evidence from the gateway process, not from a compromised
  machine. The witness registers only runs signed with the gateway's
  enrollment key, but every process of the same OS user can read that key.
- Performance numbers are local measurements on one development PC, not
  benchmarks. `-SelfTest` prints informal timings (1 ms clock resolution).
  The GP1 report's experiments (`cmd/agentgate-eval`, `docs/report/data/`)
  include the parallel verifier: on a 6-core / 12-thread desktop the full
  pinned verification of a 5,901-entry log ran 4.2x faster on 6 workers and
  5.2x on 12 than on one (`docs/report/data/parallel.md`), with identical
  reports. Usability and effectiveness have not been measured.
- This is a research prototype, not a production system.

## Suggested reading order for the code

1. `internal/effects/effects.go`: the three effect types and the digest.
2. `internal/mcp/official.go`: the tool schemas the agent sees.
3. `internal/devcomposition/composition.go`: how the gateway is wired.
4. `internal/devcomposition/components.go` and `dispatch.go`: normalizer,
   policy, issuer, dispatcher.
5. `internal/devcomposition/policy.go`: the rules and the escalation modes.
6. `internal/devapproval/authority.go`: signed approval state and decision
   (human mode).
7. `internal/audit/audit.go` then `internal/auditverify/verify.go` and
   `parallel.go`: how the log is written and how it is checked independently.
8. `internal/demo`: scenarios, the audit queue (`escalation.go`) and the
   dashboard API.
