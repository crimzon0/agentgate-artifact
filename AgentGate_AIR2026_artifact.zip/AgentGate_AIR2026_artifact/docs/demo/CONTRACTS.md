# AgentGate supervisor demo — engineering contracts

Status: authoritative build contract for the 2026-10-01 supervisor demo,
updated 2026-10-06 for the autonomous escalation modes (allow / flag / deny,
with human approval as an option) and the parallel verifier, and on
2026-10-07 for the supervisor's review (delegation grant, explicit operation
outcomes, operation journal, separate provider and witness processes,
assurance levels; on 2026-10-08 call IDs on effect entries, call scope
(every replayed answer of a completed operation is scope `call`),
continuation registration with the witness, the witness's signed run status
and the 30 s development dispatch lease; summary in section 10, decisions in
[REVISION_CONTRACT.md](REVISION_CONTRACT.md), every verifier check in
[VERIFIER_CHECKS.md](VERIFIER_CHECKS.md)). On 2026-10-10 the flag for audit
on answers changed: every CALL_RESULT with status COMMITTED states
`flagged=true` exactly when the decision the operation's effect rests on
flagged it, including a replay of the stored result (scope `call`, in the
same process or after a restart), and a stored refusal (replayed REJECTED,
e.g. after `provider_not_committed`) states no flag; this supersedes the
parenthesis on repeats in the CALL_RESULT row of section 4, and the
verifier checks it (`op.requires_policy`). Every implementer works against
this document. If code and this document disagree, fix the code or update
this document in the same change.

## 0. Goal and story

One command (`scripts\demo.ps1`) builds and starts **one offline process**
(`cmd/agentgate-demo`) and opens a local dashboard at `http://127.0.0.1:8470/`.
No API key, certificate import, passkey or Postgres is required.

The dashboard shows three things a supervisor must be able to see and trust:

1. **Request validation**: an AI agent (scripted by default; optional live
   OpenRouter LLM) proposes a tool call. The gateway checks the MCP schema,
   normalizes the call against the immutable catalog (known recipients,
   payees, documents) and evaluates a content-aware policy with readable
   reasons.
2. **Action validation**: companies run agents autonomously, so by default
   no human approves individual actions. A sensitive action (one a policy
   rule escalates) runs but is **flagged for audit**: the flag is part of the
   policy decision whose hash the signed capability carries (the verifier
   checks this), and the action is listed in an audit queue (nothing reviews
   that queue yet; an automatic audit is future work). Hard rules still deny. A short-lived, single-use capability is
   issued for the exact action, the adapter executes against the simulated
   provider, and signed provider + adapter receipts come back. **Human
   approval stays available as an option** (`-escalation human`, launcher
   `-HumanApproval`): sensitive actions then pause for a reviewer who sees
   the exact action and its fingerprint (effect digest), and the approval is
   signed and bound to that action. A third mode, `deny`, denies escalated
   actions. Attacks (unknown recipient, schema smuggling, replay; in human
   mode also post-approval swap and forged approval state) are refused, and
   the dashboard shows where and why.
3. **Auditing**: every step is written to a signed, hash-chained flight
   recorder (who, what, when, which component, where). A separate verifier
   re-checks the run from files alone: chain, signatures, every embedded
   signed artifact, the per-operation authorization chain, and reconciliation
   with the provider's own journal. It spreads its checks over all CPU cores
   and produces exactly the report a sequential run would. A tamper lab
   mutates a copy of the evidence and shows the verifier pinpointing the
   change.

Honest scope line, shown once in the UI footer: *Local research prototype.
All providers are simulated; no real email, document or money leaves this
computer. All keys are generated per run on this machine.*

## 1. Build environment (all agents)

```
GO=./.tools/go-1.26.6/bin/go.exe
export GOMODCACHE="$PWD/.tools/go-host-cache-20260916/mod" GOPROXY=off GOFLAGS=-mod=readonly GOTOOLCHAIN=local
```

* Never run `go mod tidy`, never add a dependency, never use the network.
  Available third-party modules: stdlib, `github.com/fxamacker/cbor/v2`,
  `github.com/modelcontextprotocol/go-sdk` (already used by internal/mcp).
* Build/test only the packages you touch, e.g.
  `$GO test ./internal/audit/ ./internal/auditverify/`.
* `research/` is a separate module (research/go.mod) and must never be edited.
* Do not touch files outside your ownership list. Do not create review,
  checkpoint, custody or receipt documents. Write tests only where they
  protect demo-critical behavior.

## 2. Synthetic catalog (owned by internal/demo, used by everyone)

Organization: **Falcon Freight** (fictional), internal domain
`falcon-freight.example`.

Identity: tenant `falcon-freight`, principal `agent.ops-assistant`, roles
`["MEMBER"]`, issuer `https://idp.falcon-freight.example`, auth epoch 1,
task `task.demo-operations`. Approver `human.reviewer` (display: "Reviewer").

Recipients (principal id → address, external?, display name, role):

| id | address | external | display |
|---|---|---|---|
| `sara.ahmed` | sara.ahmed@falcon-freight.example | no | Sara Ahmed — Finance Manager |
| `omar.khalid` | omar.khalid@falcon-freight.example | no | Omar Khalid — Operations Lead |
| `lina.haddad` | lina.haddad@falcon-freight.example | no | Lina Haddad — Legal Counsel |
| `partner.bluewave` | dispatch@bluewave-shipping.example | yes | BlueWave Shipping (partner) |
| `auditor.northstar` | audit@northstar-audit.example | yes | Northstar Audit (external auditor) |
| `customer.desertbloom` | orders@desertbloom-retail.example | yes | Desert Bloom Retail (customer) |

Payees: `payee.gulf-office` "Gulf Office Supplies LLC", `payee.bluewave`
"BlueWave Shipping Co.", `payee.sandstone-it` "Sandstone IT Services",
`payee.quickcash` "QuickCash Trading FZE".

Documents (immutable blobs, text/plain, synthetic text):

| filename | classification |
|---|---|
| `falcon-brochure-2026.txt` | public |
| `q3-operations-summary.txt` | internal |
| `desertbloom-contract.txt` | confidential |
| `payroll-october-2026.txt` | restricted |

## 3. Content policy `falcon-demo-policy` v1 (internal/devcomposition)

All firing rules are reported as reasons `{rule_id, outcome, message}`; the
most restrictive outcome wins. When no restricting rule fires, one ALLOW
reason explains why it is allowed.

Rules marked ESCALATE are the ones that used to ask a human. What they
produce is set by `ContentPolicy.Escalation` (type `Escalation`, constants
`EscalationFlag = "flag"`, `EscalationHuman = "human"`, `EscalationDeny =
"deny"`):

| mode | ESCALATE rules produce | precedence | who sets it |
|---|---|---|---|
| `flag` (demo default, autonomous) | FLAG: the action runs and is flagged for audit | DENY > FLAG > ALLOW | `-escalation flag` |
| `human` (optional) | REQUIRE_APPROVAL: the action waits for the reviewer | DENY > REQUIRE_APPROVAL > ALLOW | `-escalation human`, launcher `-HumanApproval`; also the meaning of an empty value |
| `deny` (autonomous, strict) | DENY | DENY > ALLOW | `-escalation deny` |

An empty `Escalation` means `human`, so `DefaultContentPolicy()` and the older
tests keep their REQUIRE_APPROVAL behavior; the demo always sets the mode
explicitly. Any other value makes `devcomposition.New` fail. `HumanApproval`
configuration is required only in human mode; in flag and deny mode it may be
nil, and then no approval authority (and no `APPROVAL_AUTHORITY` key) exists.
Hard DENY rules are identical in every mode.

| rule | effect | outcome | condition (message shown to humans) |
|---|---|---|---|
| MSG-INTERNAL | message | ALLOW | all recipients are internal and no restricted attachment |
| MSG-EXTERNAL | message | ESCALATE | any to/cc recipient is external ("Message leaves Falcon Freight: <address>") |
| MSG-HIDDEN-EXTERNAL | message | DENY | any BCC recipient is external |
| MSG-CONFIDENTIAL-OUT | message | DENY | an attachment classified confidential/restricted goes to an external recipient |
| MSG-RESTRICTED-ATTACH | message | ESCALATE | a restricted attachment to internal recipients |
| MSG-BULK | message | ESCALATE | more than MaxRecipients total recipients |
| DOC-PUBLIC | document | ALLOW | public document (any recipients, view or download) |
| DOC-INTERNAL | document | ALLOW | internal document to internal recipients |
| DOC-INTERNAL-OUT | document | ESCALATE | internal document to an external recipient |
| DOC-CONFIDENTIAL | document | ESCALATE | confidential document to internal recipients only |
| DOC-CONFIDENTIAL-OUT | document | DENY | confidential document to any external recipient |
| DOC-RESTRICTED | document | DENY | restricted document, any recipient |
| DOC-DOWNLOAD-OUT | document | ESCALATE | permission `download` to an external recipient (non-public) |
| FIN-CURRENCY | financial | DENY | currency not in AllowedCurrencies (AED, USD) |
| FIN-HARD-LIMIT | financial | DENY | amount > HardLimitMinor (50,000.00 in the request's currency) |
| FIN-APPROVAL-LIMIT | financial | ESCALATE | amount > AutoApproveLimitMinor (5,000.00 in the request's currency) |
| FIN-AUTO | financial | ALLOW | amount ≤ 5,000.00 in an allowed currency |

`PolicyInfo.Rules[].outcome` (in run.json and `/api/state`) shows the
effective outcome, so ESCALATE rules read FLAG, REQUIRE_APPROVAL or DENY.
In flag and deny mode, DOC-CONFIDENTIAL and MSG-RESTRICTED-ATTACH do not
promise a human: their messages say the item "is sensitive, even for internal
recipients".

Limits are minor units compared without any exchange rate: USD 40,000.00 is
judged against 50,000.00 exactly like AED 40,000.00. With more than one
allowed currency the rule descriptions say "in the request's currency" rather
than naming one (with a single allowed currency they name it).

PRE returns `ALLOW_BASE` / `REQUIRE_APPROVAL` / `DENY` to the control point.
A flagged action returns `ALLOW_BASE`, so the control point needs no change;
the flag travels in the decision values:

* **PRE value** (its hash is the PRE decision hash): the policy hash, the
  outcome, the effect digest and the sorted fired rule IDs (fields 0-7).
  Flag and deny mode add `8: <mode>` and `9: flagged (bool)`; human mode
  keeps exactly the original eight fields (and hashes).
* **FINAL value** (its hash is the capability's `policy_decision_hash`): a
  plain allow is the 7-field `DEV_FINAL` (version, tag, ALLOW, PRE hash,
  operation, effect type, policy hash); an approved action adds the approval
  overlay as before. A flagged action is the 10-field `DEV_FINAL_FLAGGED`:
  the same seven fields plus `7: "flag"`, `8: true`, `9: [flagging rule
  IDs]`. So the flag is bound into the capability: its
  `policy_decision_hash` is the hash of this value, and the capability issuer
  accepts the flagged shape only with all three fields.
* Both values are logged as `details.decision_value` (std base64 of the exact
  canonical CBOR the hash is computed over) on POLICY_DECISION and
  POLICY_FINAL, so the offline verifier can recompute both hashes and read
  the flag from them (§6). Without that, the flag would be protected only by
  the audit key.
* FINAL re-evaluates the same rules on the same effect and refuses if the
  recomputed PRE hash differs, so a PRE that hides the flag, or one made in
  another mode, is refused.
* The policy hash is `closedHash("AgentGate/DEVContentPolicy/v1", <rules +
  parameters>)`. The rule rows carry the effective outcomes, and flag and
  deny mode add field 9 (the mode); the human-mode hash is unchanged.

The existing per-operation table mode stays unchanged for the existing tests
(it has no escalation modes and rejects FLAG).

## 4. Audit vocabulary (closed)

Actors: `agent:ops-assistant` (the AI), `agentgate` (gateway components),
`human:human.reviewer` (human mode only), `adapter:email-v1` |
`adapter:document-release-v1` | `adapter:financial-request-v1`,
`provider:simulator`, `system` (run-level).

The approval stages (APPROVAL_*, HUMAN_DECISION) occur only in human mode. The
flag adds no stage; it is carried by the outcome `allow_flagged` and by
`details.flagged` / `details.escalation` on existing stages.

Components: `agent`, `gateway/mcp-boundary`, `gateway/normalizer`,
`gateway/policy`, `gateway/approval`, `approval-ui`,
`gateway/capability-issuer`, `gateway/adapter`, `gateway/control-point`,
`demo/run`.

Location: a short "where" string, e.g. `agentgate-demo (pid 1234) @ HOSTNAME`
for in-process components and `simulator @ http://127.0.0.1:PORT` for the
provider.

| stage | recorded by | outcome values | details (keys) | artifacts |
|---|---|---|---|---|
| RUN_STARTED | demo | info | keys_sha256, run_sha256 (SHA-256 of the exact run.json bytes, written before this entry), policy_hash, policy_name, catalog counts, simulator_origin, version, escalation (flag\|human\|deny); in a continuation segment (gateway restarted on its operation journal) also continues {run_id, dir (previous folder relative to this one), final_head, keys_sha256}, identical to run.json "continues" (`internal/audit/continuation.go`), and restored_operations | — |
| AGENT_PROPOSED | demo (agent side) | info | tool, arguments (object), mode (scripted\|llm), scenario_id, step, justification | — |
| MCP_REJECTED | gateway MCP boundary (`mcp.RejectionRecorder`, component gateway/mcp-boundary) for arguments it refuses itself (negative, fractional or > 2^53-1 numbers, non-strict JSON, malformed resume); the demo records it only for transport errors it observed | rejected | error (the agent's text), reason (invalid_request), detail, status (REJECTED), dispatched (false), scope (call), resumed, call_id | — |
| REQUEST_VALIDATED | devcomposition normalizer wrapper | ok | effect (readable object, see §4.1), request_digest | effect_cbor |
| REQUEST_REJECTED | normalizer wrapper | rejected | reason | — |
| POLICY_DECISION | policy wrapper (PRE) | allow \| allow_flagged \| approval_required \| deny | decision (ALLOW_BASE…), reasons [{rule_id,outcome,message}] (outcome FLAG for the flagging rules), decision_hash, decision_value (base64 canonical CBOR of the PRE value, §3), policy_hash; in flag and deny mode also escalation; when flagged also flagged=true | — |
| APPROVAL_REQUESTED | approval wrapper (Begin) | pending | approval_id, expires_at (unix), pre_decision_hash | signed_request_state |
| HUMAN_DECISION | demo approval relay | approved \| rejected | decision, approval_id, approver | — |
| APPROVAL_VERIFIED | approval wrapper (Resume ok) | approved | approval_id, approver, decided_at | signed_request_state, signed_decision |
| APPROVAL_REJECTED / APPROVAL_PENDING / APPROVAL_EXPIRED / APPROVAL_CONFLICT | approval wrapper (Resume error; APPROVAL_CONFLICT also Begin error) | rejected \| pending \| expired \| refused | reason, approval_id when known, scope: `operation` for a rejection or expiry (the operation ends REJECTED and its delegation reservation is released with the entry) and for a Begin error (no approval request exists); `call` for APPROVAL_PENDING and for an APPROVAL_CONFLICT of a resume whose approval does not match the pending action (only that call is refused; the operation stays PENDING with its reservation, and a matching resume may still complete it) | signed_request_state, signed_decision when available |
| POLICY_FINAL | policy wrapper (FINAL ok) | allow | decision_hash, decision_value (base64 canonical CBOR of the FINAL value, §3), pre_decision_hash, human_approved (bool), overlay_root; flagged=true for a flagged action | — |
| POLICY_FINAL_REFUSED | policy wrapper (FINAL error) | refused | reason | — |
| CAPABILITY_ISSUED | issuer wrapper | ok | cti (hex), audience, issued_at, not_before, expires_at, single_use=true, confirmation_kid | capability_token |
| EFFECT_EXECUTED | dispatcher wrapper | ok | outcome, status, provider_reference, provider_request_digest, adapter_id, provider_location, call_id (the call that executed the action: its CALL_RESULT carries the same value, so the verifier matches them even when other calls of the operation are logged in between) | provider_receipt, effect_receipt |
| EFFECT_FAILED | dispatcher wrapper | error \| uncertain | reason; with outcome uncertain also status UNCERTAIN (a request may have left, or lease_expired=true: the dispatch lease ran out after the capability was consumed) | — |
| CALL_RESULT | coordinator wrapper (every call) | completed \| denied \| approval_required \| refused \| pending_evidence | status, reason, dispatched, scope (call\|operation; `call` for every replayed=true answer with status COMMITTED or REJECTED), call_id (16 random bytes in hex, the same value the agent receives as structuredContent.call_id), refused_reason (raw internal error text), resumed (bool); flagged=true when the effect this answer reports rests on a flagged decision: the call that executed it, the call that reconciled it, and every replayed COMMITTED answer (in the same process or after a restart); a refusal never says flagged | — |
| AGENT_RECEIVED | demo (agent side) | info | what the agent saw: status / error text / provider_reference | — |

Every gateway event carries OperationID, EffectType and (when known)
EffectDigest. Summaries are one plain-English sentence, e.g. *"Allowed and
flagged for audit: amount AED 12,400.00 exceeds the AED 5,000.00 automatic
limit (rule FIN-APPROVAL-LIMIT)."* (flag mode) or *"Policy requires human
approval: amount AED 12,400.00 exceeds the AED 5,000.00 automatic limit."*
(human mode).

### 4.1 Readable effect object (`details.effect`)

```json
{"type":"financial_request.create","summary":"Request AED 12,400.00 to BlueWave Shipping Co.",
 "fields":[{"label":"Payee","value":"BlueWave Shipping Co. (payee.bluewave)"},
           {"label":"Amount","value":"AED 12,400.00"}, ...],
 "raw":{ ...the effect branch as JSON (effects.*Effect with hex digests)... }}
```

## 5. Audit run directory format v1 (internal/audit writes, internal/auditverify reads)

Run directory: `demo-runs/<run_id>/` where `run_id` = `run-YYYYMMDD-HHMMSS-<6 hex>`.

### 5.1 `audit.jsonl`

One line per entry, UTF-8, `\n` terminated, exactly:

```
{"entry_hash":"<64 hex>","signature":"<std base64>","entry":<ENTRY_JSON>}
```

* `ENTRY_JSON` is the compact `encoding/json` serialization of `audit.Entry`
  (fields in struct order; map keys sorted by encoding/json; HTML escaping
  disabled via `SetEscapeHTML(false)`; no trailing newline inside).
* `entry_hash = hex(SHA-256("AgentGate/AuditEntry/v1" || 0x00 || ENTRY_JSON_bytes))`,
  computed over the exact bytes that appear in the file.
* `signature = base64std(Ed25519.Sign(auditKey, "AgentGate/AuditEntrySig/v1" || 0x00 || raw32(entry_hash)))`.
* `seq` starts at 1 and increases by exactly 1. `prev_hash` of seq 1 is 64
  zeros; otherwise it equals the previous line's `entry_hash`.
* `time` is RFC 3339 with nanoseconds, UTC (`2026-10-01T12:00:00.123456789Z`),
  non-decreasing.
* `artifacts` values are standard padded base64; `details`/`artifacts` are
  `{}` when empty (never null).
* The verifier rebuilds each line from its parsed members and refuses any line
  that is not byte-for-byte in this form (a repeated member, a member spelled
  `"ENTRY"`, extra spaces): Go's decoder would quietly pick one value while
  another JSON reader could see a different entry. The same applies to
  `head.json`, `keys.json`, `run.json` and `provider-journal.json`: member
  names are lowercase and appear once per object, else `files.present` fails.

### 5.2 `head.json` (atomically replaced after every append)

```json
{"format":"agentgate-audit-head/v1","run_id":"…","seq":42,"entry_hash":"…","time":"…","kid":"<hex>","signature":"<std base64>"}
```

`signature = Ed25519.Sign(auditKey, "AgentGate/AuditHead/v1" || 0x00 || run_id || 0x00 || decimal(seq) || 0x00 || entry_hash_hex)`.

### 5.3 `keys.json`

```json
{"format":"agentgate-keys/v1","run_id":"…","keys":[{"kid":"<64 hex>","role":"AUDIT_LOG","purpose":"Signs every audit entry and the head checkpoint","alg":"Ed25519","public_key":"<std base64 of 32 bytes>"}, …]}
```

Roles: `AUDIT_LOG` (kid = hex SHA-256 of the raw 32-byte public key),
`CAPABILITY_ISSUER`, `SIMULATOR_PROVIDER`, `ADAPTER_MESSAGE`,
`ADAPTER_DOCUMENT`, `ADAPTER_FINANCIAL`, `APPROVAL_AUTHORITY` (kids = the COSE
`kid` header values that appear in the corresponding artifacts, i.e.
`capability.DeriveKID`). `APPROVAL_AUTHORITY` exists only in human mode; the
autonomous modes have six keys.

### 5.4 `run.json`

```json
{"format":"agentgate-demo-run/v1","run_id":"…","started_at":"…","host":"…","pid":1234,
 "identity":{"tenant_id":"falcon-freight","principal_id":"agent.ops-assistant","task_id":"task.demo-operations"},
 "policy":{"name":"falcon-demo-policy","version":"1","hash":"…","escalation":"flag|human|deny","rules":[…]},
 "policy_snapshot":{…devcomposition.PolicySnapshot, see VERIFIER_CHECKS.md §3…},
 "delegation":{"grant_id":"grant-…","grant_hash":"<hex>","authority_kid":"<hex>","signed_grant":"<std base64 COSE>"},
 "catalog":{"recipients":[…],"payees":[…],"documents":[{"filename":"…","classification":"…","sha256":"…"}]},
 "keys_sha256":"<hex of exact keys.json bytes>","simulator_origin":"http://127.0.0.1:PORT",
 "custody":{"provider_process":false,"witness":false}}
```

`custody` is present only when a provider process or a witness runs.

### 5.5 `provider-journal.json` (the provider's own record)

Rewritten (atomically) by the demo after every gateway call from
`Composition.Snapshot()`:

```json
{"format":"agentgate-provider-journal/v1","run_id":"…","simulator_id":"…","commit_seq":3,
 "state_hash":"<hex CanonicalStateHash>","entries":[{"commit_seq":1,"signed_receipt":"<std base64 COSE bytes>"}, …]}
```

### 5.6 Signed artifacts (COSE_Sign1, Ed25519)

All embedded artifacts are COSE_Sign1 `Tag(18)[protected bstr, {}, payload bstr, signature bstr]`.
`protected` decodes to a map `{1:-8, 2:[-65537], 3:<content type>, 4:<kid 32 bytes>, -65537:1}`.
Signature input = deterministic CBOR of `["Signature1", protected, h'', payload]`.

| artifact name | content type (protected 3) | key role | payload |
|---|---|---|---|
| `capability_token` | application/agentgate-cap+cwt | CAPABILITY_ISSUER | int-keyed CWT: 4 exp, 5 nbf, 6 iat, 7 cti, -70002 operation_id, -70003 effect_type, -70004 effect_digest, -70007 policy_decision_hash (= hash of the FINAL value, which for a flagged action is `DEV_FINAL_FLAGGED`, §3), -70009 policy_hash (see internal/capability/capability.go `Claims.wire`) |
| `provider_receipt` | application/agentgate-provider-receipt+cbor | SIMULATOR_PROVIDER | text-keyed `simulator.SimulatorReceipt` (operation_id, effect_digest, commit_seq, state_before_hash, state_after_hash, …) |
| `effect_receipt` | application/agentgate-effect-receipt+cbor | ADAPTER_* by effect type | text-keyed `adapters.EffectReceipt` (cti, effect_digest, operation_id, policy_decision_hash, provider_receipt_hash, …) |
| `signed_request_state`, `signed_decision` (human mode only) | see internal/devapproval/authority.go stateProfile/decisionProfile | APPROVAL_AUTHORITY | int-keyed `stateWire` / `decisionWire` |
| `effect_cbor` | (not signed) | — | canonical effect bytes; `effect_digest = hex(SHA-256("AgentGate/EffectObject/v1" || 0x00 || bytes))` |

## 6. Verifier checks (internal/auditverify, cmd/agentgate-verify)

Groups and minimum checks (IDs are stable strings used by the UI):

* **Run files**: `files.present` (also fails a file with ambiguous JSON, see
  §5.1), `files.run_record` "Run record matches the signed log"
  (sha256(run.json) == RUN_STARTED details.run_sha256; for older runs without
  it, run.json policy hash/name, simulator_origin and catalog counts == the
  values RUN_STARTED recorded; and every POLICY_DECISION policy_hash == run.json
  policy.hash), `keys.hash` (sha256(keys.json) == run.json
  keys_sha256 == RUN_STARTED details.keys_sha256), `keys.anchor` "Keys match
  the pinned fingerprint" (with `--expect-keys` / `Options.ExpectKeysSHA256`:
  sha256(keys.json) must equal the pinned hex value, else FAIL; without a pin
  it is a WARN explaining that a complete re-signing by someone holding
  substitute keys cannot be ruled out — warnings never fail the verdict).
* **Log integrity**: `chain.entry_hash` (every line), `chain.signature`
  (every line, AUDIT_LOG key), `chain.links` (seq +1, prev_hash), `chain.time`
  (non-decreasing), `head.signature`, `head.matches` (head seq/hash == last
  line; detects truncation), `head.anchor` "Log end matches the pinned head"
  (with `--expect-head` / `Options.ExpectHead`: the last entry's hash must
  equal the pin, else FAIL; without a pin it is a WARN explaining that a
  rollback to an earlier, genuinely signed checkpoint cannot be ruled out).
* **Signed artifacts**: `artifact.signature` (each COSE artifact verifies with
  the key whose kid is in its protected header AND whose role matches the
  artifact name), `artifact.effect_digest` (effect_cbor recomputes to the
  entry's effect_digest).
* **Authorization chain** (per operation): `op.requires_validation`,
  `op.requires_policy` (a non-denying PRE decision, where `allow_flagged`
  counts as allowing, and an allowing FINAL; and the decision values: the
  POLICY_FINAL `decision_value` must hash to its `decision_hash` under
  `AgentGate/DEVFinalDecision/v1`, its field 3 must be the hash of a logged
  PRE value for this operation that hashes correctly under
  `AgentGate/DEVPreDecision/v1`, and both must name this operation, effect
  and policy. The flag, outcome, mode and fired rules are then read from the
  values: POLICY_DECISION outcome / `decision` / `flagged` / `escalation` /
  reason rule IDs and FLAG outcomes, POLICY_FINAL `flagged` /
  `human_approved` / `overlay_root` and the executing call's CALL_RESULT
  `flagged` must all match them, PRE and FINAL must agree on the flag, and a
  flagged decision needs run.json `policy.escalation = "flag"`. A missing or
  unopenable value fails; there is no fallback to the details),
  `op.approval_bound` (only for
  `approval_required` decisions: approval state + decision bind
  the same effect digest, operation and pre-decision hash; decision is
  APPROVED; decided before capability issue; a flagged action expects no
  approval), `op.capability_bound`
  (capability effect digest / operation / policy decision hash ==
  POLICY_FINAL decision_hash; capability policy hash == the POLICY_DECISION
  policy_hash), `op.receipts_bound` (provider + effect receipt
  effect digests/operation match; effect receipt cti == capability cti),
  `op.single_use` (≤1 EFFECT_EXECUTED per operation and per cti),
  `op.no_effect_when_refused` (no EFFECT_EXECUTED after DENY / rejection /
  refusal without a later valid chain).
* **Provider reconciliation**: `provider.signature` (every journal receipt
  verifies with SIMULATOR_PROVIDER), `provider.state_chain` (commit_seq
  1..n contiguous; state_before_hash == previous state_after_hash),
  `provider.matches_audit` (every journal receipt is byte-identical to exactly
  one EFFECT_EXECUTED provider_receipt and vice versa; an effect at the
  provider with no authorization trail is a FAIL that names it).

**Trust anchors.** Every signature is checked against `keys.json` from the
same folder, so the files alone only prove *internal* consistency: whoever
can rewrite the whole folder can also replace `keys.json` (and the
fingerprint in run.json and RUN_STARTED) with keys of their own. Only values
held outside the folder close that gap: the keys fingerprint (sha256 of
keys.json, pinned at run start) and optionally the head hash. The Report
states them:

```json
"anchors":{"keys_sha256":"<sha256 of keys.json as found>","head_hash":"<last entry hash as found>",
           "keys_pinned":true,"head_pinned":true,
           "expected_keys_sha256":"<pin, omitted when not pinned>","expected_head_hash":"<pin, omitted>",
           "keys_match":true,"head_match":true}
```

The Report also carries `"warnings":[Check…]` (every `warn` item) and
`counts.warnings`.

**Flagged actions.** `OperationReport` has `"flagged": true` for an
operation with status `executed` whose execution rests on a flagged decision,
read from the opened decision values (when they cannot be opened,
`op.requires_policy` fails and the report falls back to the log's
`allow_flagged` / `details.flagged`, so a flag is never hidden);
`counts.flagged` counts them. A denied or blocked operation is never reported
as flagged.

**What the flag binding covers.** An insider who holds only the audit key can
rewrite and re-sign every entry, but cannot change the capability (issuer
key) or the adapter's effect receipt (adapter key), which both carry the
FINAL hash. Dropping or inventing a flag in the details then fails
`op.requires_policy`; re-making the decision values fails
`op.capability_bound`. Tests: `internal/auditverify/insider_test.go`. On this
single machine all keys are in one process, so this protects the files after
the run, not against a compromised gateway.

**Parallel checks.** `Options.Workers` sets how many goroutines verify
independent items: line parsing, entry hash and signature checks, artifact
verification, the per-operation authorization walk and the provider-journal
receipts. 0 means `runtime.NumCPU()`, 1 is fully sequential. Each item's
check results are buffered and replayed in sequential order (if several items
crash, the lowest index is reported), so the report (checks, order, details,
counts) is byte-identical for every worker count apart from `checked_at`.
The demo's `/api/verify` and tamper lab use all cores.

Verdict VERIFIED only when no check fails (warnings allowed). CLI:
`agentgate-verify [--json] [--expect-keys HEX] [--expect-head HEX] [--workers N] [--unicode] <run-dir>`
(both pins must be 64 hex characters, else usage error; `--workers` default 0
= one per CPU); the human output
adds a "Trust anchors" section and, under a VERIFIED verdict, a note naming
any missing pin ("Not anchored" when neither is given); exit 0 verified,
1 failed, 2 usage/IO error. Human output: grouped ✓/✗ lines, an operations
list (flagged ones tagged "[flagged for audit]", the log line adds "(N
flagged for audit)"), then a one-line
verdict with counts. On Windows the verifier retries a read that fails with
a sharing violation (a writer replacing head.json at that moment).

**Tamper lab** (`auditverify.Tampers`, `ApplyTamper`, `ApplyTamperWith`):
`edit-value`, `delete-entry`, `rehash-chain`, `truncate`, `swap-receipt`,
`hide-operation`, `forge-approval` (each by an attacker without the signing
keys) and `rollback`: the log is cut back to an earlier checkpoint and the
head.json and provider journal genuinely on disk at that moment are put back
(`TamperOptions.EarlierHead` / `EarlierJournal`). Nothing is forged, so every
check that looks only at the folder passes; only `head.anchor` with the pinned
head fails. A re-signing attack with substitute keys is deliberately not part
of the lab.

Targets adapt to runs without a human: `edit-value` changes the latest
payment over the automatic limit that was human-approved or flagged for
audit; `delete-entry` removes a HUMAN_DECISION if there is one, else the
POLICY_DECISION that flagged an action, else any policy decision;
`forge-approval` turns a rejected action, or else a denied one, into an
approved, executed one.

## 7. Demo server HTTP API (internal/demo; consumed by internal/demo/assets)

Bind `127.0.0.1:8470` (flag `-addr`; if busy, fall back to `127.0.0.1:0`).
The escalation mode is fixed per run by `-escalation flag|human|deny`
(default `flag`; `scripts\demo.ps1 -HumanApproval` or `-Escalation <mode>`,
`scripts/demo.sh --escalation <mode>` or `--human-approval`). Only human mode
creates the approval authority and the approval relay.
Reject requests whose Host is not the bound address. Every POST requires
`Content-Type: application/json` and header `X-AgentGate-Demo: 1` (CSRF
guard). All responses JSON, `Cache-Control: no-store`. Static assets:
`/`, `/app.js`, `/app.css`, `/favicon.svg`.

* `GET /api/state` →
```json
{"run":{"id":"…","dir":"demo-runs/…","started_at":"…","host":"…","policy":{PolicyInfo},"keys_sha256":"…","simulator_origin":"…"},
 "escalation":"flag|human|deny",
 "audit":{"count":17,"head_seq":17,"head_hash":"…"},
 "runs":[RunView… newest first],
 "pending_approvals":[ApprovalView…],
 "provider":{"commit_seq":3,"state_hash":"…","count":3},
 "last_verification":{"verdict":"VERIFIED","checked_at":"…","checks_passed":40,"checks_failed":0,"head_seq":17} | null,
 "llm":{"enabled":false,"model":""}}
```
  `pending_approvals` is always empty outside human mode.
* `GET /api/scenarios` → `{"groups":[{"id":"everyday","title":"Everyday work","subtitle":"Allowed automatically","scenarios":[ScenarioView…]}, …]}`
  ScenarioView: `{"id","title","story","agent_says","expected":"ALLOW|APPROVAL|FLAG|DENY|BLOCKED","watch":"what the presenter should point at","effect_type","kind":"normal|attack","available":true,"unavailable_reason":"…"}`.
  Group `approval` reads "Flagged for audit / Allowed, recorded and listed
  in the audit queue" in flag mode, "Needs a human / Paused until the reviewer
  decides" in human mode and "Would need a human / Denied: in strict mode
  nothing is escalated" in deny mode; `expected`, `story` and `watch` of its
  scenarios follow the mode (§8). `available` is false (with
  `unavailable_reason`) for the two approval attacks outside human mode.
* `POST /api/scenarios/{id}/run` `{}` → `RunView` (202). Only one run may be
  active at a time → 409 `{"error":"A scenario is already running"}`. An
  unavailable scenario → 409 with its `unavailable_reason`.
* `POST /api/custom` `{"tool":"financial_request.create","arguments":{…}}` →
  RunView. `operation_id` is generated when absent.
* `POST /api/approvals/{id}` `{"decision":"approve"|"reject"}` → ApprovalView
  (human mode; elsewhere no approval exists, so 404).
* `GET /api/flagged` → the audit queue, newest first, built from the signed
  log alone (every executed operation whose policy decision was
  `allow_flagged`):
  `{"items":[{"operation_id","run_id","title","effect_type","summary","reasons":[{rule_id,outcome:"FLAG",message}],"executed_at","provider_reference"}]}`.
  `run_id` is the dashboard run that proposed it (omitted for a call the
  dashboard did not start) and drives the "Show the run" link. Empty outside
  flag mode.
* `GET /api/runs/{id}` → RunView.
* `GET /api/audit?operation=<op>&run=<runViewId>` →
  `{"entries":[audit.Entry + {"entry_hash","signature_ok":true}]}` (read from the
  log; artifacts included as base64 plus `artifacts_decoded` name → decoded
  JSON for COSE payloads where possible).
* `GET /api/audit/download` → raw `audit.jsonl` (`text/plain`).
* Trust anchor: at startup the server pins sha256(keys.json) — the exact bytes
  it wrote — in memory (`Server.KeysSHA256()`, also `GET /api/state`
  `run.keys_sha256`); the launcher prints it as "Trust anchor (keys
  fingerprint)". It never re-reads the value from disk.
* `POST /api/verify` `{}` → `auditverify.Report` of the live run, verified
  with `ExpectKeysSHA256` = the pinned fingerprint and `ExpectHead` = the head
  of the copy. The server never verifies files that are being appended to: it
  copies the five evidence files into a temporary folder while no gateway call
  is in flight (every MCP tools/call holds `Server.callGate` shared; the copy
  holds it exclusively, so a provider commit and its EFFECT_EXECUTED entry are
  always copied together), with audit.jsonl and head.json copied under the
  audit log's append lock (`audit.Log.Snapshot`). The copy is byte-identical
  to the run folder at that moment; `report.dir` names the run folder. The
  result is stored as `last_verification` (with `head_seq`, the entry the
  copy ended at).
* `GET /api/tampers` → `[auditverify.TamperInfo]`.
* `POST /api/tamper` `{"kind":"edit-value"}` →
  `{"tamper":TamperResult,"report":Report,"naive_report":Report,"anchors":{"keys_sha256","head_seq","head_hash","source"}}`.
  The attack is applied to a consistent copy (taken as for `/api/verify`) and
  written to `demo-runs/tamper-lab/<run id>/<kind>-<n>/`, next to the evidence
  folder and never inside it (so no earlier genuine head.json ever sits among
  the evidence); the live run is untouched. The copy is verified twice by the
  same verifier: `naive_report` with no anchors (trusts the copy's own
  keys.json/head.json), `report` anchored with the pinned keys fingerprint and
  the head at copy time (`anchors`). For `rollback` the server supplies the
  newest checkpoint it saved (head.json and provider-journal.json as on disk
  at the end of an earlier run, with no gateway call in flight) that precedes
  the latest executed effect; with no such checkpoint it answers 409.
* `GET /api/provider` → `{"simulator_id","commit_seq","state_hash","items":[{"commit_seq","effect_type","operation_id","provider_reference","committed_at","summary","fields":[{label,value}]}]}`
* `POST /api/llm` `{"prompt":"…"}` → RunView (only when LLM enabled; else 404).

RunView:
```json
{"id":"r3","scenario_id":"shipping-invoice","title":"…","kind":"normal|attack|custom|llm",
 "status":"running|awaiting_approval|completed|denied|rejected|blocked|failed",
 "headline":"Executed and flagged for audit","message":"plain-language result paragraph",
 "started_at":"…","finished_at":"…","operation_ids":["…"],
 "pipeline":[PipelineStep×7],"approval":ApprovalView|null,"audit_seqs":[12,13,…],
 "flagged":true}
```
A flagged execution has status `completed`, `flagged: true` and headline
"Executed and flagged for audit" (human mode: "Executed after human
approval"; plain allow: "Allowed and executed automatically").

PipelineStep (always these 7, in order, ids fixed):
`propose` "Agent proposes", `validate` "Request check", `policy` "Policy
decision", `approval` "Human approval" in human mode and "Escalation" in flag
and deny mode, `capability` "Capability",
`execute` "Execution", `record` "Receipts & audit". Each:
`{"id","title","state":"waiting|active|pass|fail|skip|warn","text":"one plain sentence","detail":{…small JSON…},"seqs":[audit seq numbers]}`.
For a flagged action, `policy` and `approval` are `warn` with
`detail.flagged = true` (e.g. "No human in the loop: allowed and flagged for
audit (rule FIN-APPROVAL-LIMIT).") and `capability` says the final re-check
confirmed the flag.

ApprovalView (human mode only): `{"id","run_id","operation_id","effect_type","title","summary","fields":[{label,value,emphasis:bool}],"effect_digest","reasons":[…],"requested_at","expires_at","status":"pending|approved|rejected|expired"}`.
If the gateway ever asked for a human outside human mode, the agent stops
(fail closed) instead of waiting.

## 8. Scenarios (scripted agent, internal/demo)

Each scenario's agent uses a fresh operation ID per call. Expected outcome
per escalation mode (the self-test checks exactly these):

| id | group | flag (default) | human | deny | what happens |
|---|---|---|---|---|---|
| `internal-update` | everyday | ALLOW | ALLOW | ALLOW | email Omar (internal) a shipment ETA update |
| `office-supplies` | everyday | ALLOW | ALLOW | ALLOW | AED 1,250.00 to Gulf Office Supplies |
| `share-brochure` | everyday | ALLOW | ALLOW | ALLOW | release the public brochure to Desert Bloom (view) |
| `partner-email` | approval | FLAG | APPROVAL (approve) | DENY | email BlueWave dispatch about the pickup schedule |
| `shipping-invoice` | approval | FLAG | APPROVAL (approve) | DENY | AED 12,400.00 to BlueWave Shipping |
| `suspicious-invoice` | approval | FLAG | APPROVAL (reject) | DENY | AED 18,500.00 to QuickCash Trading, "urgent consulting" |
| `over-limit` | blocked | DENY | DENY | DENY | AED 75,000.00 to Sandstone IT |
| `payroll-leak` | blocked | DENY | DENY | DENY | release the restricted payroll file to Northstar Audit |
| `contract-leak` | blocked | DENY | DENY | DENY | email the confidential contract to BlueWave |
| `prompt-injection` | attack | BLOCKED | BLOCKED | BLOCKED | injected text makes the agent email `exfil.collector` (not in catalog) |
| `schema-smuggling` | attack | BLOCKED | BLOCKED | BLOCKED | adds `"skip_approval": true` and a fractional amount |
| `approval-swap` | attack | n/a (409) | BLOCKED | n/a (409) | gets AED 12,400.00 approved, then resumes with payee QuickCash / AED 49,900.00 |
| `forged-approval` | attack | n/a (409) | BLOCKED | n/a (409) | ignores the human and resumes with a self-made/modified requestState |
| `replay` | attack | BLOCKED | BLOCKED | BLOCKED | repeats a completed AED 900.00 request (same operation ID) 3 times → exactly one provider effect |

FLAG: status `completed`, `flagged: true`, one provider effect, listed in
`GET /api/flagged`. In flag mode `suspicious-invoice` deliberately shows the
cost of autonomy: the fooled agent's payment runs; it is not hidden (it is
flagged and listed in the audit queue), but nothing reviews that queue yet.

Self-test summary line (`-selftest`, `scripts\demo.ps1 -SelfTest`):
`SELF-TEST PASSED in autonomous flag mode (16/16 scenarios, 2 skipped as
human-approval only, 3/3 custom requests, verifier VERIFIED / ANCHORED, 8/8
tamper attacks detected, 5/5 revision checks)`; with `-HumanApproval`:
`SELF-TEST PASSED in human-approval mode (18/18 scenarios, …)`; with
`-ExternalProvider -Witness`: `… in autonomous flag mode with provider
process + witness (…, 8/8 revision checks)`. The skipped scenarios are still
checked: they must be marked unavailable and the server must refuse them with
409. The flag-mode self-test also compares the audit queue with the runs that
executed flagged.

## 10. Revision 2026-10-07 (supervisor's review): what changed

Decisions and file ownership: [REVISION_CONTRACT.md](REVISION_CONTRACT.md).

**Delegation grant.** At startup the demo generates an organisation key
(role `DELEGATION_AUTHORITY`, listed in keys.json) and signs one
`devcomposition.DelegationGrant`: purpose, the three effect types, every
catalog recipient, the payees `payee.bluewave`, `payee.gulf-office`,
`payee.quickcash`, `payee.sandstone-it` (not `payee.horizon-travel`), budgets
AED 100,000.00 and USD 3,000.00 over the whole run, per-type counts (10
document releases, 20 messages, 20 financial requests), valid 24 hours. The
gateway receives only the signed grant and the public key; the grant applies
in every escalation mode. New DENY rules, evaluated together with the content
rules: DEL-SCOPE, DEL-EXPIRED, DEL-REVOKED, DEL-BUDGET, DEL-COUNT. PRE
reserves, a COMMITTED outcome commits and an operation-scope REJECTED outcome
releases the reservation (a call-scope REJECTED, such as
`operation_id_conflict` or a refused conflicting resume, answers that call
only and releases nothing); UNCERTAIN keeps it. (The self-test multiplies the
AED budget and the counts by `-repeat`; the USD budget is never scaled.)

**Policy.** `devcomposition.RevisionContentPolicy()`: separate inclusive
limits AED 5,000.00 / 50,000.00 and USD 1,500.00 / 15,000.00, FIN-ZERO (amount
0 is denied), MSG-CONFIDENTIAL-TEXT (a message repeating 12 consecutive words
of a confidential or restricted document: DENY with an external recipient,
escalated otherwise; verbatim copies only). FINAL refuses unless its policy
hash equals the PRE decision's.

**New audit stages.** `DELEGATION_GRANTED` (artifact `delegation_grant`),
`DELEGATION_REVOKED` (`details.grant_id`, recorded before the gateway
revokes), `RECONCILED` (component `gateway/reconciler`, outcome `committed` /
`not_committed`, artifact `provider_status`, plus `provider_receipt` when
committed; `details.call_id` of the call that reconciled, absent when
`Composition.Reconcile` resolved the operation outside any MCP call),
`WITNESS_UNAVAILABLE` (once per witness outage). `EFFECT_FAILED`
with outcome `uncertain` and `details.status` `UNCERTAIN` records a dispatch
whose provider answer is unknown (no receipt, so no EFFECT_EXECUTED).
`CALL_RESULT` details now carry `status` (REJECTED, PENDING, COMMITTED,
UNCERTAIN, RECONCILIATION_REQUIRED), `reason`, `dispatched` and `scope`
(`call`: refusal of that call only, or the stored result of a completed
operation replayed to a retry; `operation`: the operation now has this
status). A replay (`replayed` true) with status COMMITTED or REJECTED is
always scope `call`, whether the coordinator's store answers it in the same
process or the operation ledger answers it (a refusal stored as the
outcome, a reconciled commit, any outcome after a restart); the call that
settled the operation keeps scope `operation`
(`internal/devcomposition/auditing.go`, `CallWithMetadata`).

**Calls and scope.** Every MCP call gets a `call_id` (16 random bytes, hex;
also `structuredContent.call_id` for the agent). The gateway writes it on
CALL_RESULT and MCP_REJECTED, and on the EFFECT_EXECUTED and RECONCILED
entries a call records, so an execution is tied to its own answer even when
concurrent calls of the same operation are logged in between. `details.scope`
says whether an entry concerns that call only (`call`: MCP_REJECTED, a
call-scope CALL_RESULT, APPROVAL_PENDING, an APPROVAL_CONFLICT of a
mismatching resume) or the operation (`operation`). A call-scope refusal
never ends the operation and never releases its delegation reservation; the
verifier treats it that way (VERIFIER_CHECKS.md, `op.no_effect_when_refused`,
§4).

**Dispatch lease (development).** The demo's capability registry
(`capability.NewDevelopmentRegistryWithClock`) grants a 30-second dispatch
lease (`capability.DevelopmentDispatchLeaseSeconds`) and accepts adapter
possession proofs that live as long (the stock registries keep their 2 s
lease and 10 s PoP). Only durations change: the lease still ends at the
earliest of lower+30 s, the capability's expiry, the PoP's expiry and every
quota window, is single-use and non-renewable, and the first write after it
expired is refused; such a dispatch ends `EFFECT_FAILED` with
`lease_expired=true` and status UNCERTAIN, and is reconciled, never
dispatched again.

**Agent results and operation status.** Every MCP call returns
`structuredContent.status` / `reason` / `message` / `dispatched` / `call_id`
(see `internal/devcomposition/auditing.go`), and its CALL_RESULT records the
same values plus `scope`. A status describes **this call**; `scope` says
whether it is also the operation's status (`operation`) or concerns this call
only (`call`). The operation key is (tenant, principal, operation ID).

| status | what it says about this call | scope `call` cases (operation unchanged) |
|---|---|---|
| REJECTED | this call caused no provider effect (definition below) | `operation_id_conflict`, `operation_state_conflict` (except a resume the coordinator never challenged, which is scope `operation`), `approval_invalid`, `invalid_request`, `journal_unavailable`, `gateway_error`, and a stored REJECTED replayed to a retry (`replayed` true) |
| PENDING | waiting for the reviewer (human mode only) | `approval_pending`: a resume before the reviewer decided |
| COMMITTED | the operation's effect is committed and its evidence is complete | every replayed answer (`replayed` true): this call caused no new effect, it reports the earlier commit |
| UNCERTAIN | a request for the operation may have left; the outcome is unknown; the delegation reservation is kept | a reconciliation attempt that could not settle it (`reconciliation_unavailable`, `provider_status_unknown`, `provider_changed`) |
| RECONCILIATION_REQUIRED | the provider committed; the evidence is incomplete (for example a failed audit append) | as for UNCERTAIN |

**REJECTED, defined per call.** A REJECTED answer means that *this call
caused no provider effect*. With `dispatched` false nothing was sent for it.
With `dispatched` true (reasons `provider_rejected`, `provider_not_committed`)
a request was sent and the provider signed that it committed nothing: a
signed REJECTED receipt, or an ABSENT status observation, which also
tombstones the idempotency key. What the answer says about the operation
depends on `scope`:

* scope `operation`: the refusal is the operation's outcome. No provider
  effect exists for the operation key, and the operation's delegation
  reservation is released (only an operation-scope REJECTED releases it).
* scope `call` (an operation-ID conflict, a conflicting resume, a replayed
  refusal and the other `call` cases above): only this call was refused or
  answered. An earlier or concurrent call of the same operation may have
  committed, may be pending or may be uncertain, so a call-scope REJECTED is
  never evidence that the operation key has no effect. It never ends the
  operation and never releases its reservation (the verifier treats it the
  same way: VERIFIER_CHECKS.md `op.no_effect_when_refused`,
  `op.outcome_resolved`, §4).

So R4 ("a possibly committed effect is never reported as REJECTED") holds
per call: no call whose own provider request may have left is answered
REJECTED unless the provider's signed answer proves that nothing was
committed, and only an operation-scope REJECTED speaks for the operation key.
The verifier checks the call side (`op.outcome_resolved`: REJECTED is never
reported for a call that recorded an execution, and a call-scope REJECTED
with `dispatched` true is never given for an operation that was executed).

Examples:

* *Same operation ID, different content.* Operation `o`, AED 400.00 to a
  catalog payee, commits. A later call reuses `o` for AED 900.00 and is
  answered REJECTED, reason `operation_id_conflict`, `dispatched` false,
  scope `call`, while the provider holds the AED 400.00 effect. An exact
  retry of the AED 400.00 call is answered with the stored COMMITTED (scope
  `call`, `replayed` true). Measured in the concurrency experiment's
  conflicting-reuse scenario: 260 COMMITTED and 4,460
  REJECTED/`operation_id_conflict` answers, exactly one effect in each of the
  260 repetitions (`docs/paper/data/revision/concurrency/RESULTS.md`).
* *Fresh operation ID, same business intent.* The same AED 400.00 request
  sent under a new operation ID `o2` is a new operation and commits a second
  payment. Uniqueness is per operation key, not per business intent; this is
  by design (crash experiment: 400 of 1,120 operations committed the same
  content again after a fresh-ID retry,
  `docs/paper/data/revision/crash/RESULTS.md`).

A REJECTED answer describes the moment it was given. One consequence: when
the operation journal cannot record a refusal's outcome, a gateway restarted
on that journal does not know the refusal, and an exact retry of an
operation with no recorded outcome and no dispatch intent runs again and may
commit once. Nothing was sent the first time, so this is still at most one
effect (`internal/devcomposition/durable.go`, `settle`).

**Finality of an operation-scope REJECTED** (added 2026-10-10). An
operation-scope REJECTED says that no effect exists for the operation key at
the time of the answer. If the consumption or the dispatch intent cannot be
journaled, the call is refused with reason `aborted_before_send`, scope
`operation`, `dispatched` false: nothing is sent, the capability stays spent
and the journal fails closed (`internal/devcomposition/replay_scope_test.go`,
"aborted before send"). Such a REJECTED is final only once its outcome
record is journaled (`internal/devcomposition/auditing.go`, the comment on
the agent result). After a lost journal write, a restarted gateway may
commit the same key once, and the verifier accepts that history without a
warning. Measured in the OS-level kill suite's journal-write-failure cell
(`journal/read_only_at_consume`, 5 repetitions): 10 REJECTED answers were
followed by a commit of the same operation ID, each operation with exactly
one effect (`docs/paper/data/build2/killsuite/RESULTS.md`).

An exact retry of an UNCERTAIN or
RECONCILIATION_REQUIRED operation reconciles with the provider's signed
status; it never dispatches again. Reconciliation asks only the provider the
request may have been sent to: the journaled dispatch intent records its key
ID (`provider_kid`), and when the gateway now trusts a different provider
(for example an in-process simulator recreated by a restart) the operation
stays UNCERTAIN with reason `provider_changed` (manual handling) and keeps
its delegation reservation.

**Run folder.** `operations.jsonl` (with `-durable`, default on in the
command): the gateway's operation journal, local state, not evidence.

**Custody (optional).** `-external-provider`: `cmd/agentgate-provider` runs
the simulator in its own process with its own key and synced request log
under `<runs-dir>/custody/provider/`; endpoints: the simulator API plus
`GET /key` (KID, public key, run identity) and `GET /journal` (§5.5).
`-witness`: `cmd/agentgate-witness` under `<runs-dir>/custody/witness/`,
started with `-enroll-key` (see **Witness enrollment** below);
`POST /runs` (run_id + exact keys.json bytes, signed with the gateway's
enrollment key; with `continues` `{run_id, final_head, keys_sha256}` it
registers a continuation segment),
`POST /heads` (head.json with the audit lines since the last cosigned head,
from entry 1 on the first push; rollback, forks and a new head without those
lines are refused, code `extension_required`), `GET /runs/{id}/latest`,
`GET /runs/{id}/heads`, `GET /runs/{id}` (the run status: the
registration, with `continues` for a segment and `continued_by` once a
later segment continues the run, plus the latest cosigned head as
`latest_index` / `latest_seq` / `latest_entry_hash` and the signing time
`status_at`, signed by the witness key like a cosigned head:
`witness_kid`, `witness_public_key`, `witness_signature` over a label and
every other member, NUL-separated. A run registered with an enrollment key
gets format `agentgate-witness-run-status/v2`: label
`"AgentGate/WitnessRunStatus/v2"`, 16 fields, the last one `enrollment_kid`
(the enrollment key that signed the registration). A run registered before
enrollment was required gets the earlier format
`agentgate-witness-run-status/v1`: label `"AgentGate/WitnessRunStatus/v1"`,
15 fields, no `enrollment_kid`. A verifier built before v2 reports a v2
status as an unknown format (`head.witness` fails with "has format"), not
as a forged signature; `internal/headwitness` `RunStatus`,
`RunStatusMessage`), `GET /key`. The
demo pushes the head after every agent call, after a revocation and when it
stops, and saves the latest cosigned head and the witness key to
`<runs-dir>/custody/anchors/<run id>/witness-head.json` and
`witness-key.txt` (`agentgate-verify --witness FILE --witness-key HEX`).

**Witness enrollment (build 3).** The witness registers a run or a
continuation only when the request is signed by a gateway enrollment key it
was started with (`agentgate-witness -dir DIR -enroll-key KEY`, required and
repeatable; KEY is the standard base64 of the 32-byte Ed25519 public key or
a file holding it). There is no open mode: without `-enroll-key` the witness
does not start. The request adds `enrollment_kid` (hex SHA-256 of the
enrollment public key) and `enrollment_signature` = Ed25519 over
`"AgentGate/WitnessEnrollment/v1"` 0x00 run_id 0x00 keys_sha256 0x00
audit_public_key (std base64 of the AUDIT_LOG key the witness registers)
0x00 keys_file_verified (`1` when the request carries keys.json, else `0`)
0x00 continues.run_id 0x00 continues.final_head 0x00 continues.keys_sha256
(empty continues fields for a first registration;
`internal/headwitness/enrollment.go`). An unsigned request, an unknown
enrollment key or a signature that does not verify is refused with 403
`enrollment`. This check runs before the run ID is looked up, so the
refusal does not depend on whether the run ID is registered; it does not
hide which runs exist, since `GET /runs/{id}`, `/latest` and `/heads` need
no authentication. A continuation must be signed
by the enrollment key that registered the run it continues (403
`enrollment`); registering a run again is idempotent only with the same
keys, continuation and enrollment key (409 `run_conflict`). The store keeps
each registration's enrollment signature and the witness checks it again
when it reopens the store. The demo generates one enrollment key per
custody folder in `<runs-dir>/custody/gateway/enrollment-key.json` (owner-only
mode; it holds the private seed, unlike the per-run evidence keys, which are
never written), starts the witness with its public half and signs every
registration with it. It pins the key of the first witness started for the
custody folder in `<runs-dir>/custody/gateway/witness-pin.txt` (hex),
refuses a witness that announces another key, and accepts only cosigned
heads and run statuses that verify under the pinned key. Both files are
created atomically and exclusively (a crash leaves no file or the whole
file; of two processes creating one at once, the first wins;
`internal/headwitness/pin.go`). To trust a new witness (or start over with
a new enrollment key), remove the custody folder. Limits: any
enrolled key may register a new run ID; on one OS user account every
process of that user can read the enrollment key file (on Windows the mode
bits are not enforced; the profile's access rules apply), so enrollment
keeps out a registrant that cannot read the gateway's files, not one that
can. `agentgate-eval custody` restarts the witness with the same enrollment
key, reads it through a client pinned to the saved witness key and records
five enrollment probes of a party without the enrollment private key (all
must be refused with `enrollment` and leave no trace).

**Continuation registration.** When the gateway is restarted on the
operation journal of a closed run, the demo opens a new evidence segment
(`internal/demo/segment.go`) and, with a witness, registers it as the run's
continuation: it starts the witness again if needed, brings it up to the
run's final head, then sends `POST /runs` with the segment's exact keys.json
and `continues` naming the run, its final head and its keys fingerprint,
signed with the same enrollment key as the run's registration. The
witness accepts it only on top of the run's latest cosigned head and only
once per run (409 `continuity` otherwise), closes the earlier run (no later
head of it is cosigned; `continued_by` names the segment), and requires the
segment's first push to start with a RUN_STARTED entry carrying the same
`continues`. The segment's heads are pushed like the run's and its anchor is
saved under `<runs-dir>/custody/anchors/<segment run id>/`. Verify the newest
segment: `agentgate-verify --witness-url URL --witness-key HEX` fetches its
latest cosigned head and its signed run status, and fails `head.anchor` when
the status says a later segment continued the folder given (a withheld
segment); a saved head file cannot show that. A status that is unsigned,
does not verify with the witness key, names another latest head or was
signed more than 2 minutes from the fetch fails `head.witness` (a mismatch;
VERIFIER_CHECKS.md, signed-status rule).

**Verifier.** `Report.Assurance` = FAILED, CONSISTENT (every check passed but
an anchor is missing) or ANCHORED (keys and head pinned or witnessed);
`Report.Dimensions` (seven, pass / fail / not_checked), `Report.Missing`,
`Report.Assumptions`. New checks: `policy.replay`, `delegation.*`,
`op.outcome_resolved`, `head.witness` (36 in all; VERIFIER_CHECKS.md).

**Dashboard API.** `GET /api/delegation` (grant, budgets used / reserved /
left, counts, revoked), `POST /api/delegation/revoke` (409 when already
revoked); `/api/state` adds `delegation`, `custody` and `durable`; `RunView`
adds `gateway_status` and `gateway_reason`; run status `uncertain`.

**Scenarios.** Added `confidential-text` (DENY, MSG-CONFIDENTIAL-TEXT),
`zero-amount` (DENY, FIN-ZERO), and a new group "Outside the delegation":
`split-payments` (three USD 1,400.00 payments under the USD 3,000.00 budget:
two run, the third is denied by DEL-BUDGET; status denied, 2 effects) and
`out-of-scope-payee` (AED 2,300.00 to Horizon Travel: DEL-SCOPE). The
self-test adds revision checks (grant recorded, fault injection with exact
retry, revocation, assurance, and with the options: provider process, witness
outage, witness-only anchor, restart on the journal). Summary lines:
`SELF-TEST PASSED in autonomous flag mode (16/16 scenarios, 2 skipped as
human-approval only, 3/3 custom requests, verifier VERIFIED / ANCHORED, 8/8
tamper attacks detected, N/N revision checks)`; human mode `18/18 scenarios`.

**Evaluation hook.** `demo.HeadlessRun` makes one closed run without a
dashboard and returns the run folder and its pins (keys fingerprint, final
head, the witness's cosigned head). No private signing key is ever written
or exported. `-host-label NAME` (`Options.HostLabel`, `SelfTestOptions.HostLabel`,
`HeadlessOptions.HostLabel`, `devcomposition.Config.HostLabel`) replaces the
machine name in run.json `host` and in every audit entry's location.

## 9. File ownership

Historical: the parallel build of 2026-10-01. Escalation modes live in
`internal/devcomposition` (`audit.go`, `policy.go`, `components.go`,
`auditing.go`) and `internal/demo/escalation.go`; the parallel verifier in
`internal/auditverify/parallel.go`; its measurement in
`cmd/agentgate-eval/parallel.go`; opening the logged decision values in
`internal/auditverify/decisions.go` (insider tests: `insider_test.go`, with
`fixture.RewriteWithAuditKey`).

| owner | files |
|---|---|
| gateway-hooks | internal/devcomposition/** (except audit.go type names are fixed), internal/devapproval/** |
| audit-log | internal/audit/** |
| verifier | internal/auditverify/**, cmd/agentgate-verify/** |
| demo-server | internal/demo/*.go, cmd/agentgate-demo/** |
| ui | internal/demo/assets/** |
| launch-docs | scripts/demo.ps1, scripts/demo.sh, docs/demo/PRESENTER_GUIDE.md, docs/demo/ARCHITECTURE.md, README.md (demo section only), .gitignore (add demo-runs/) |
