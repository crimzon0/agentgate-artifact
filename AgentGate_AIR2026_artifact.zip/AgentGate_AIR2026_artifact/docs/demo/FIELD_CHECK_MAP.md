# AgentGate verifier: field-to-check map

Status: written 2026-10-10 against the verifier sources at commit `f01d1c9`
(the frozen build of 2026-10-08); updated the same day for build 2 (commit
`86643d7`): the flag rule of `op.requires_policy` now also covers replayed
COMMITTED answers, RECONCILED entries and the call that writes a confirming
RECONCILED (`checkReconciledFlag`, `checkReplayedFlag`); an adapter receipt
attached to a RECONCILED entry is checked under `op.receipts_bound`
(`checkReconciledReceipt`); the report adds the derived dimensions
`head_fresh` and `run_complete` and per-operation classification evidence,
which own no check. The reason "redundant (honest provider)" was renamed
"provider accounting" on 2026-10-10: the provider is a role an
attacker may hold (paper, Section II), so no field is redundant because the
provider is assumed honest. Updated 2026-10-20 for build 3 (round 5 of the
supervisor's review): the capability's `cnf`, the status observation's
`observed_at` (and a reason to reconcile before a RECONCILED entry that
records an effect), CAPABILITY_ISSUED `confirmation_kid` and the witness
run status's `continues` are now checked; an operation that holds a
verified capability and no outcome is reported as not settled; and
[Unchecked fields at a glance](#unchecked-fields-at-a-glance) gives, for
every field still unchecked, why changing it cannot change P1-P7 or which
property it weakens. Later the same day (round-5 review fixes): the earlier
segments' keys.json fingerprints can be pinned (`--expect-earlier-keys`) and
are otherwise anchored only through the newest segment's log; the
`observed_at` lower bound applies to `committed` only; the run status's
`enrollment_kid` and format v2 are read.
For every security-relevant field of every signed artifact, decision value,
audit entry and anchor document, this file names the verifier check that
reads it, or says that no check reads it and why, and which paper property
(P1-P7, `docs/paper/latex/sections/04_properties.tex`) depends on it. The
check IDs and their full predicates are in
[VERIFIER_CHECKS.md](VERIFIER_CHECKS.md); the formats are in
[CONTRACTS.md](CONTRACTS.md) §5. If this file and the code disagree, the
code is right and this file must be fixed.

## How to read it

**Properties.** P1 log integrity; P2 classification (flag, mode, fired
rules) of an executed operation; P3 effect binding (e.g. the amount); P4
hidden effects (provider journal); P5 coherent rollback and withheld
segment; P6 key authenticity; P7 honest status and one effect per operation
key. "—" means no property depends on the field.

**Why a field is not checked.** Every unchecked field has one of these
reasons:

* **provider accounting**: the provider's own accounting of the
  request (row bytes, state delta, request digest, idempotency key). No
  check compares these fields with the effect digest, so a holder of the
  provider key can make them disagree with the effect undetected. P3 rests
  on the effect digest, which the issuer, the adapter and the provider all
  sign and the verifier compares; the paper's provider-key results rest only
  on the receipt signature, the effect digest and journal matching. The
  paper claims nothing about the provider having applied the row it reports
  (Lim4).
* **redundant (bound elsewhere)**: another field that is checked, or a hash
  that is checked, already commits to the same value (for example the
  tenant, which is a field of the canonical effect and so is covered by the
  effect digest).
* **not needed**: no claim rests on it (descriptive text, a constant, a
  timestamp whose order the log already gives).
* **deferred**: a check that would add assurance but is not built; it is
  listed in [Unchecked fields at a glance](#unchecked-fields-at-a-glance).

**Decoded is not checked.** `internal/auditverify/cose.go` decodes a few
fields that no check compares: the capability's tenant, the provider
receipt's `adapter_id` and `committed_at`, the adapter receipt's `outcome`
(compared only on a RECONCILED entry), the status observation's
`provider_reference`, and the human decision's approver. They are marked
"decoded, not checked" below. (The status observation's `observed_at` was in
this list until build 3; it is now checked.)

**Signatures.** Every COSE artifact's envelope (content type, a kid listed in
keys.json with the role the artifact requires, Ed25519 over the
`Signature1` structure, closed protected header) is checked by
`artifact.signature`; on a refusal stage a bad artifact is only a warning.
That is not repeated in each table.

## 1. Capability token (`capability_token`, CAPABILITY_ISSUER)

Checked in `operations.go` `checkCapability` (op.capability_bound),
`decisionsFor` / `requirePolicy` (op.requires_policy), `checkReceipts`
(op.receipts_bound, op.single_use) and `binding.go` `checkSnapshotBinding`
(policy.snapshot_bound). CWT keys as in `internal/capability` `Claims.wire`.

| claim | checked by | requirement | property |
|---|---|---|---|
| 3 `aud` | op.capability_bound | the adapter audience of the claimed effect type | P3 |
| 4 `exp`, 5 `nbf`, 6 `iat` | op.capability_bound | nbf ≤ iat ≤ exp and exp − iat ≤ 60 s | — (design rule) |
| 6 `iat` (human mode) | op.approval_bound | the human decision's `decided_at` ≤ iat + 5 s, and iat ≤ the decision's `expires_at` + 5 s | — (human mode, Lim8) |
| `exp` against the time of use | not checked: not needed | the online registry refuses an expired token; offline the log gives order, not true time (Lim6) | — |
| 7 `cti` | op.capability_bound; op.receipts_bound; op.single_use | = CAPABILITY_ISSUED `details.cti`; = the adapter receipt's `cti`; at most one effect per cti, across operations | P7 |
| -70002 operation ID | op.capability_bound | = the entry's operation | P3, P7 |
| -70003 effect type | op.capability_bound | = the entry's effect type | P3 |
| -70004 effect digest | op.capability_bound | = the entry's digest and = the validated request's digest | P3 |
| -70007 policy decision hash | op.capability_bound; op.requires_policy; op.receipts_bound | = the latest POLICY_FINAL `decision_hash` when issued; an execution rests on the FINAL whose hash this is (never simply the latest FINAL); = the adapter receipt's `policy_decision_hash` | P2 |
| -70009 policy hash | op.capability_bound; policy.snapshot_bound | = the PRE entry's `policy_hash` (when the claim is present); = the hash recomputed from the run's policy snapshot (a missing claim fails) | P2 |
| 1 `iss`, 2 `sub` | not checked: redundant (bound elsewhere) | the issuer is identified by the CAPABILITY_ISSUER key role; the subject (principal) is a field of the canonical effect | — |
| 8 `cnf` (confirmation kid) | op.capability_bound (build 3) | a map with exactly one member, 3, a 32-byte key ID; listed in keys.json with the ADAPTER_* role of the effect type; = CAPABILITY_ISSUED `details.confirmation_kid` when logged; = the COSE kid of the adapter receipt of the effect (EFFECT_EXECUTED, or attached to RECONCILED). The gateway puts the adapter signer's KID here: the key whose proof of possession the registry demands at consume and the key that signs the effect receipt (`internal/devcomposition` issuance and dispatch) | P3 |
| -70001 tenant | decoded, not checked: redundant (bound elsewhere) | the tenant is inside the effect digest | — |
| -70005 base root | not checked: redundant (bound elsewhere) | a copy of the effect's `base_provenance_root`, inside the effect digest | — |
| -70006 overlay root | not checked: redundant (bound elsewhere) | the human-approved FINAL value commits to it (field 7) and -70007 commits to that value; for an action without a human approval it is the constant empty-overlay root | — |
| -70008 policy decision object hash | not checked: redundant (bound elsewhere) | a second hash of the same FINAL value (`AgentGate/DEVFinalDecisionObject/v1`) | — |
| -70010 policy epoch, -70011 auth epoch, -70012 adapter epoch | not checked: not needed | constants in the demo (1, the identity's auth epoch, 1) | — |
| -70013 artifact hashes, -70014 covered paths | not checked: **deferred** | the approval lineage list of a human-approved action (see §7 and the glance list) | — |
| -70015 profile version | not checked: not needed | the COSE protected header's profile version (-65537) is checked by `artifact.signature` | — |
| -70016 task grant hash, -70017 selected constraint digest, -70018 requirements hash | not checked: redundant (bound elsewhere) | derived by the issuer from (task, operation), (operation, effect type) and (effect digest, catalog hash) | — |
| whole token bytes | op.receipts_bound | the adapter receipt's `capability_hash` = H("AgentGate/Capability/v1/cose", token) | P2 |

## 2. Adapter receipt (`effect_receipt`, ADAPTER_* of the effect type)

Checked in `operations.go` `checkReceipts` (op.receipts_bound) on
EFFECT_EXECUTED and, since build 2, by `checkReconciledReceipt` (also
op.receipts_bound) when a RECONCILED entry carries one. A RECONCILED commit
need not carry an adapter receipt, and after a gateway restart it never does
(the gateway keeps the receipt in memory only). Such an operation's
classification rests on the issuer's signature alone
(`issuer_only_reconciled`), and an editor with the audit and issuer keys and
access to the provider's status interface can convert an execution into
that form and change its classification, in both designs and every verifier
setting (fixture studies L3 and L4, real signatures; VERIFIER_CHECKS.md §1
"Lifecycle states"). Fields as in
`internal/adapters` `EffectReceipt`.

| field | checked by | requirement | property |
|---|---|---|---|
| `operation_id` | op.receipts_bound | = the entry's operation | P3, P7 |
| `cti` | op.receipts_bound; op.single_use | = the capability's cti; this cti is the one counted for single use | P7 |
| `capability_hash` | op.receipts_bound | = H("AgentGate/Capability/v1/cose", the issued token) | P2 |
| `effect_digest` | op.receipts_bound | = the entry's digest | P3 |
| `policy_decision_hash` | op.receipts_bound | = the capability's -70007 | P2 |
| `effect_type` | op.receipts_bound | = the entry's effect type (when present); the entry's type also selects the required ADAPTER_* role | P3 |
| `provider_receipt_hash` | op.receipts_bound | = H("AgentGate/SimulatorReceipt/v1/cose", the provider receipt on the same entry) | P3, P4 |
| `provider_reference` | op.receipts_bound | = the provider receipt's (when present) | P3 |
| `v`, `receipt_id`, `attempt`, `started_at`, `completed_at`, `attestation_level`, `reason_code` | not checked: not needed | descriptive or timing | — |
| `tenant_id`, `base_provenance_root` | not checked: redundant (bound elsewhere) | inside the effect digest | — |
| `authorization_overlay_root` | not checked: redundant (bound elsewhere) | the FINAL value that `policy_decision_hash` commits to carries it | — |
| `authorization_artifact_hashes` | not checked: **deferred** | approval lineage list (§7) | — |
| `provider_request_digest`, `idempotency_key_hash`, `provider_response_digest` | not checked: provider accounting | cross-role equality with the provider receipt is deferred; P3 already rests on the adapter-signed `effect_digest` | — |
| COSE kid (the signing key) | artifact.signature; op.capability_bound (build 3) | a key of keys.json with the ADAPTER_* role of the effect type; = the consumed capability's `cnf` | P3 |
| `adapter_id` | not checked: redundant (bound elsewhere) | the signing key's role is the ADAPTER_* of the effect type, the signing key is the one the capability's `cnf` names, and the capability's audience names the adapter | — |
| `outcome` | decoded; checked on RECONCILED only (op.receipts_bound: APPLIED); on EFFECT_EXECUTED not checked: redundant (bound elsewhere) | the provider receipt's own `outcome` is what the provider checks read | — |

## 3. Provider receipt (`provider_receipt`, SIMULATOR_PROVIDER)

Appears on EFFECT_EXECUTED, optionally on RECONCILED, and as every entry of
`provider-journal.json`. Checked in `operations.go` `checkReceipts`,
`provider.go` (`readJournalEntry`, `checkProviderStateChain`,
`checkProviderMatchesAudit`) and `reconcile.go` `checkReconciled`. Fields as
in `internal/simulator` `SimulatorReceipt`.

| field | checked by | requirement | property |
|---|---|---|---|
| `effect_digest` | op.receipts_bound; op.outcome_resolved | = the entry's digest (an attached RECONCILED receipt too) | P3 |
| `operation_id` | op.receipts_bound; op.outcome_resolved; provider.matches_audit | = the entry's operation; the journal receipt of a RECONCILED-not_committed operation fails; an unresolved operation's journal receipt is reported | P3, P4 |
| `effect_type` | op.receipts_bound | = the entry's effect type | P3 |
| `provider_reference` | op.receipts_bound | = EFFECT_EXECUTED `details.provider_reference` (when logged) and = the adapter receipt's | P3 |
| `commit_seq` | provider.signature; provider.state_chain | = the journal entry's listed `commit_seq`; commits run 1..n without gaps; the journal header's `commit_seq` = n | P4 |
| `outcome` | provider.state_chain; provider.matches_audit | the journal holds only APPLIED; an EFFECT_EXECUTED receipt with another outcome need not be in the journal | P4 |
| `state_before_hash`, `state_after_hash` | provider.state_chain | before = the previous commit's after; the last after = the header's `state_hash`. Commit 1 is not covered: no initial state is in the evidence, so the first commit's `state_before_hash` is never compared (validly re-signed with an edited value, it was accepted: `TestRound4ValidlySignedInconsistentFields`). Not recomputed from the rows (state replay is deferred) | P4 |
| whole receipt bytes | provider.matches_audit; op.receipts_bound; op.outcome_resolved | each journal receipt is byte-identical to exactly one EFFECT_EXECUTED receipt (or named by one RECONCILED-committed entry), and vice versa; cited by hash in the adapter receipt; an attached RECONCILED receipt hashes to the observation's stored receipt hash | P3, P4 |
| `effect_row_bytes`, `effect_row_hash` | not checked: provider accounting | Lim4; the row hash is not recomputed and the row is not compared with the canonical effect | — |
| `canonical_state_delta_hash` | not checked: provider accounting | Lim4 | — |
| `provider_request_digest`, `idempotency_key_hash` | not checked: provider accounting | the provider contract (one commit per idempotency key) is an assumption of P7, not something the evidence shows | — |
| `run_id` | not checked: redundant (bound elsewhere) | the receipt must be in this run's journal byte for byte and is cited by hash in a receipt signed with this run's adapter key | — |
| `simulator_id`, `endpoint_profile`, `v`, `reason_code` | not checked: not needed | the journal header's `simulator_id` is used only to decide whether a later segment's journal must extend an earlier one | — |
| `tenant_id` | not checked: redundant (bound elsewhere) | inside the effect digest | — |
| `adapter_id` | decoded, not checked: redundant (bound elsewhere) | effect type and digest | — |
| `committed_at` | decoded, not checked: not needed | the log orders the commit | — |

## 4. Provider status observation (`provider_status`, SIMULATOR_PROVIDER)

Carried by RECONCILED entries. Checked in `reconcile.go` `checkReconciled`
(op.outcome_resolved) and `provider.go` (provider.matches_audit). Fields as
in `internal/simulator` `SimulatorStatusObservation`.

| field | checked by | requirement | property |
|---|---|---|---|
| `operation_id` | op.outcome_resolved | = the entry's operation | P7 |
| `effect_digest` | op.outcome_resolved | = the entry's digest and = the validated request's | P7 |
| `effect_type` | op.outcome_resolved | = the entry's effect type (when the entry names one) | P7 |
| `status` | op.outcome_resolved | APPLIED for outcome `committed`, ABSENT for `not_committed` (an UNKNOWN answer resolves nothing and the gateway logs no RECONCILED for it) | P7 |
| `stored_simulator_receipt_object_hash` | op.outcome_resolved; provider.matches_audit | 32 bytes for `committed`; = the hash of an attached receipt; must be the hash of a journal receipt, which it then claims | P4, P7 |
| (entry context) | op.outcome_resolved; provider.matches_audit | a verified capability precedes it; `not_committed` only when the log recorded no execution, and the journal holds no receipt for that operation; (build 3) a RECONCILED `committed` entry that records the effect follows a reason to reconcile after the capability: an UNCERTAIN / RECONCILIATION_REQUIRED CALL_RESULT of scope operation or an EFFECT_FAILED reporting UNCERTAIN before it, another call's such CALL_RESULT after it, or a restart (later segment) between the capability and it; an unresolved CALL_RESULT of the reconciling call itself (same `call_id`) does not count | P4, P7 |
| `run_id`, `simulator_id`, `tenant_id`, `adapter_id` | not checked: redundant (bound elsewhere) | operation and effect digest identify the request | — |
| `idempotency_key_hash`, `status_request_digest` | not checked: provider accounting | | — |
| `query_id`, `reconciliation_seq`, `v` | not checked: not needed | | — |
| `provider_reference` | decoded, not checked: redundant (bound elsewhere) | the stored receipt hash names the receipt, which carries the reference | — |
| `canonical_state_hash`, `current_commit_seq` | not checked: **deferred** | would tie the observation to the journal's state chain | — |
| `observed_at` | op.outcome_resolved (build 3) | set (non-zero), at most the RECONCILED entry time + 5 s, and for `committed` at least the capability's `iat` - 5 s (a `not_committed` observation gets the upper bound only: no provider reading orders an ABSENT answer after the capability, so an OS clock stepped back by more than 5 s would date a genuine one before it). Assumes the provider, issuer and recorder read one machine's clock (the report's "One clock" assumption). Until build 2 it was not checked (an observation dated 2027-06-01 was accepted, fixture study L2; one dated 2030, SF). The date and order rules add no key to the conversion of an execution into a reconciled commit (the status endpoint answers any local caller; the unresolved status is audit-signed), so the reconciliation path stays issuer-only, but they add a timing requirement: the converting editor needs a provider-signed status fetched while the run went on (dated at or before the RECONCILED entry), or must append the RECONCILED entry after a late observation (an in-place conversion would then require re-dating every later entry) | P7; P2 (limit, reconciliation path) |

## 5. Provider journal file (`provider-journal.json`)

Checked in `provider.go`. P4 holds only when this file comes from the
provider and was not rolled back with the folder; the verifier cannot tell
where it came from (an assumption of P4, Section IV).

| field | checked by | requirement | property |
|---|---|---|---|
| `run_id` | files.run_id | names this run | P4 |
| `commit_seq` | provider.state_chain | = the number of receipts | P4 |
| `state_hash` | provider.state_chain | = the last receipt's `state_after_hash` | P4 |
| `entries[].commit_seq` | provider.signature | = the signed receipt's `commit_seq` | P4 |
| `entries[].signed_receipt` | provider.signature; provider.state_chain; provider.matches_audit | §3 | P4 |
| `simulator_id` | provider.state_chain (restart only) | with the same provider key and simulator in two segments, the later journal starts with every receipt of the earlier one | P4 |
| `format` | not checked: not needed | `files.present` only requires unambiguous JSON | — |

## 6. Policy decision values (`details.decision_value` on POLICY_DECISION and POLICY_FINAL)

Opened in `decisions.go` (`openDecision`, `parsePre`, `parseFinal`,
`preValueProblems`, `finalDetailProblems`), `replay.go` `replayDecision`,
`binding.go` `checkSnapshotBinding` and `delegation.go`. Which decisions are
opened: op.requires_policy opens the FINAL a capability or execution rests on
and the PRE that FINAL confirms; policy.replay opens every POLICY_DECISION
value; policy.snapshot_bound opens every PRE and FINAL value for its policy
hash. Decisions of operations that never executed are covered by the replay
and the audit key only (Lim5).

### PRE value (`DEV_CONTENT_PRE`; `DEV_PRE` for the operation table)

| field | checked by | requirement | property |
|---|---|---|---|
| the hash (`details.decision_hash`) | op.requires_policy; policy.replay | H("AgentGate/DEVPreDecision/v1", value) = `decision_hash`; FINAL field 3 must name it | P2 |
| 0 version | op.requires_policy; policy.replay | 1 | P2 |
| 1 tag and shape | op.requires_policy; policy.replay | closed shapes: DEV_CONTENT_PRE with 8 closed fields (human mode) or 10 (flag, deny); 7 fields is the unbound-flags ablation, which fails outside `Options.UnboundFlags`; DEV_PRE (6 fields) only in a run that records no escalation mode and no content snapshot | P2 |
| 2 outcome | op.requires_policy; policy.replay | = the entry's outcome and `details.decision`; the FINAL tag must fit (ALLOW_BASE: DEV_FINAL or DEV_FINAL_FLAGGED; REQUIRE_APPROVAL: DEV_FINAL_HUMAN_APPROVED); = the replayed outcome | P2 |
| 3 operation ID, 4 effect type | op.requires_policy | = the entry's | P2 |
| 5 policy hash | op.requires_policy; policy.snapshot_bound | = `details.policy_hash` and = FINAL field 6; = the hash recomputed from the snapshot | P2 |
| 6 effect digest | op.requires_policy | = the entry's effect digest | P2, P3 |
| 7 fired rule IDs | op.requires_policy; policy.replay | = the rule IDs of `details.reasons`; = FINAL field 9 when flagged; = the replayed set | P2 |
| 8 escalation mode (absent = human) | op.requires_policy; policy.replay | = `details.escalation` (absent in human mode); = run.json `policy.escalation`; = the snapshot's mode | P2 |
| 9 flagged | op.requires_policy; policy.replay | = outcome `allow_flagged`, `details.flagged`, the number of FLAG reasons, the FINAL flag, the executing CALL_RESULT's `flagged`, every replayed COMMITTED answer's `flagged` and the `flagged` of a RECONCILED committed entry and of the call that wrote it (including a confirming RECONCILED); a flag needs run mode `flag`; = the replayed flag | P2 |
| 20.0 grant ID, 20.1 grant hash | delegation.grant | = the run's grant ID and grant hash; in a run that records no grant, a block naming one fails | — (delegation) |
| 20.2 evaluated at | not checked: not needed | delegation.window and DEL-EXPIRED use the entry's time | — |
| 20.3 cumulative before, 20.4 cumulative after | delegation.accounting | before lies in the decision's [lower, upper] interval; after = before + this action for an allow; = `details.delegation` when both are logged | — (delegation) |
| other keys from 10 up | not read | covered by the hash; never read for the flag | — |

### FINAL value (`DEV_FINAL`, `DEV_FINAL_FLAGGED`, `DEV_FINAL_HUMAN_APPROVED`)

| field | checked by | requirement | property |
|---|---|---|---|
| the hash (`details.decision_hash`) | op.requires_policy; op.capability_bound; op.receipts_bound | H("AgentGate/DEVFinalDecision/v1", value) = `decision_hash`; = the capability's -70007, which the adapter receipt repeats | P2 |
| 0 version, 1 tag and shape | op.requires_policy | 1; DEV_FINAL with 7 closed fields, DEV_FINAL_FLAGGED 10, DEV_FINAL_HUMAN_APPROVED 11; keys from the extension base up are extension fields | P2 |
| 2 outcome | op.requires_policy | ALLOW | P2 |
| 3 PRE hash | op.requires_policy | = `details.pre_decision_hash`; names a PRE recorded for this operation whose value hashes to it | P2 |
| 4 operation ID, 5 effect type | op.requires_policy | = the operation and type of the step that rests on it | P2 |
| 6 policy hash | op.requires_policy; policy.snapshot_bound | = PRE field 5; = the recomputed snapshot hash | P2 |
| flagged: 7 mode, 8 flag, 9 flagging rules | op.requires_policy | mode `flag`, flag true, rules non-empty and exactly PRE field 7; = POLICY_FINAL `details.flagged`; the PRE flag agrees; run mode `flag` | P2 |
| approved: 7 overlay root | op.requires_policy | = `details.overlay_root`. Not recomputed from the approval artifacts (deferred with the hash list) | — (human mode) |
| approved: 8 approval artifact hashes | not checked: **deferred** | the FINAL hash covers it, but the verifier links the approval by operation, effect digest, PRE hash and request (op.approval_bound), not by this list | — |
| approved: 9 covered paths, 10 profile | not checked: not needed | only the field count is checked | — |
| 20 delegation block | delegation.grant (only in a run that records no grant) | totals not compared: redundant (bound elsewhere), field 3 commits to the PRE value, whose block delegation.accounting checks | — |
| tag against `details.human_approved` | op.requires_policy | `human_approved` is true exactly for DEV_FINAL_HUMAN_APPROVED | P2 (relabel-approved control) |

### Entry details next to the values

| entry and field | checked by | property |
|---|---|---|
| POLICY_DECISION `decision`, outcome, `reasons[].rule_id`, `reasons[].outcome` (FLAG), `flagged`, `escalation` | op.requires_policy (against the value, for decisions an execution rests on); policy.replay (against the replay, every decision) | P2 |
| POLICY_DECISION `policy_hash` | op.capability_bound; op.requires_policy; files.run_record (= run.json `policy.hash`) | P2 |
| POLICY_DECISION `reasons[].message` | not checked: not needed (text for humans) | — |
| POLICY_FINAL `pre_decision_hash`, `flagged`, `human_approved`, `overlay_root` | op.requires_policy | P2 |

## 7. Approval artifacts (human mode only, APPROVAL_AUTHORITY)

Checked in `operations.go` (`stateProblems`, `decisionProblems`,
`checkApprovalRequest`, `checkApprovalVerified`, `checkApprovalForCapability`;
op.approval_bound). No paper property depends on them (Lim8: human mode
demonstrates approval binding only); the key-compromise simulation's
relabel-approved operator uses them as a control.

| artifact and field | checked by | requirement |
|---|---|---|
| state 4 operation, 5 effect digest, 6 PRE hash | op.approval_bound | this operation, this effect, a PRE recorded for it; = APPROVAL_REQUESTED `details.pre_decision_hash` |
| state 7 approval ID | op.approval_bound | = the decision's |
| state 8 issued at, 9 expires at | op.approval_bound | the decision's `decided_at` lies in [issued at, expires at) |
| state 0 version, 1 profile, 2 tenant, 3 principal, 10 nonce | not checked | redundant (bound elsewhere: content type and role; tenant and principal inside the effect digest) or not needed (nonce) |
| decision 2 decision | op.approval_bound | APPROVED for the approval a capability rests on, and not followed by an operation-scope refusal |
| decision 6 operation, 7 effect digest, 8 PRE hash, 9 approval ID | op.approval_bound | = this operation and effect, a recorded PRE, the state's PRE hash and approval ID |
| decision 10 state object hash | op.approval_bound | = H("AgentGate/DEVApprovalState/v1/cose", the signed state bytes) |
| decision 11 decided at | op.approval_bound | inside the state's window; ≤ the capability's iat + 5 s |
| decision 12 expires at | op.approval_bound | the capability's iat ≤ expires at + 5 s |
| decision 5 approver | decoded, not checked: not needed | the reviewer is an unauthenticated local click (Lim8); entry `details.approver` is not compared either |
| decision 0 version, 1 profile, 3 tenant, 4 principal | not checked: redundant (bound elsewhere) | |
| APPROVAL_* `approval_id`, `decided_at`, `expires_at` details | not compared: redundant (bound elsewhere) | the signed artifacts are what is checked |
| the lineage lists (FINAL field 8, capability -70013 / -70014, adapter receipt `authorization_artifact_hashes`) | not checked: **deferred** | residual: an audit-key holder could put a second, genuinely signed APPROVED decision for the same operation, effect and PRE in place of the one used, if such a second decision exists |

## 8. Delegation grant (`delegation_grant`, DELEGATION_AUTHORITY)

Checked in `delegation.go` (`readGrant`, `checkDecisionUnderGrant`,
`checkRevocationEntry`, scope and budget walks) and the DEL-* rules of
`policy.replay`. No P1-P7 property depends on the grant; the replay of the
DEL-* rules is part of P2's replay (an executed operation must have fired
none), and the grant feeds the `delegation_respected` dimension and the
misuse results (Section V-E). Fields as in `devcomposition.DelegationGrant`.

| field | checked by | requirement |
|---|---|---|
| `v` | delegation.grant | 1 |
| `grant_id` | delegation.grant; delegation.revocation | non-empty; = DELEGATION_GRANTED `details.grant_id` and every decision's block; DELEGATION_REVOKED must name it |
| grant hash (body hash) | delegation.grant | H("AgentGate/DelegationGrant/v1/body", payload) = the entry's `grant_hash` and every decision's |
| `tenant_id` | delegation.grant | = run.json `identity.tenant_id` |
| `delegate` | delegation.grant; delegation.scope | = run.json `identity.principal_id`; = the principal of every executed effect |
| `effect_types`, `recipients`, `payees` | delegation.scope; policy.replay (DEL-SCOPE) | every executed effect lies inside them |
| `budgets` | delegation.budget; policy.replay (DEL-BUDGET) | committed totals per currency within the budget |
| `max_counts` | delegation.budget; policy.replay (DEL-COUNT) | committed counts per effect type within the limit |
| `nbf`, `exp` | delegation.grant; delegation.window; policy.replay (DEL-EXPIRED) | nbf ≤ exp; allowing decisions, FINAL allows and capabilities inside [nbf − 1 s, exp + 1 s] |
| signed grant bytes | delegation.grant | run.json's copy and every segment's DELEGATION_GRANTED carry the same bytes |
| `issuer` | not checked: redundant (bound elsewhere) | the DELEGATION_AUTHORITY key role is the issuer statement |
| `purpose` | not checked: not needed | free text, shown in the pass line; wrong-purpose payments pass (Lim8) |
| a policy hash | not present: **deferred** | the grant does not name the policy, so the snapshot is bound to the issuer-signed policy hash, not to the organisation's intent (Lim5) |

## 9. Canonical effect (`effect_cbor` on REQUEST_VALIDATED)

Not signed itself; its digest H("AgentGate/EffectObject/v1", bytes) is signed
by the issuer, the adapter and the provider. Checked in `verify.go`
`checkEffectBytes` (artifact.effect_digest, artifact.effect_readable),
`replay.go` and `delegation.go`.

| field | checked by | requirement | property |
|---|---|---|---|
| the bytes | artifact.effect_digest | hash to the entry's `effect_digest`; every REQUEST_VALIDATED carries them | P3 |
| `operation_id`, `effect_type` | artifact.effect_digest | = the entry's | P3 |
| recipients (to, cc, bcc, document recipients, `external`), attachments, document classification and permission, payee, amount, currency, subject, body | policy.replay; delegation.scope; delegation.budget | the rules are replayed on them; catalog facts agree with the snapshot | P2 |
| `principal_id` | delegation.scope | = the grant's delegate | — (delegation) |
| `registry_snapshot_object_hash` | policy.snapshot_bound | = the catalog commitment recomputed from run.json `catalog` | P2 |
| `details.effect` (readable view) | artifact.effect_readable | every leaf present on both sides agrees | — |
| `tenant_id` | not checked against run.json: not needed | one tenant per run; the digest binds it | — |
| `task_id`, `base_provenance_root`, `v` | not checked: not needed | | — |

## 10. Audit entries (`audit.jsonl`)

Checked in `verify.go`, `operations.go`, `reconcile.go`, `delegation.go`,
`segments.go`.

| field | checked by | requirement | property |
|---|---|---|---|
| `entry_hash` | chain.entry_hash | H("AgentGate/AuditEntry/v1", exact entry bytes); the line is in the recorder's exact form | P1 |
| `signature` | chain.signature | Ed25519 by the AUDIT_LOG key over the entry hash | P1 |
| `seq` | chain.links; head.matches; head.anchor | starts at 1, +1 per line; the head and the anchor name the last one | P1, P5 |
| `prev_hash` | chain.links | 64 zeros, then the previous line's hash | P1 |
| `time` | chain.time | RFC 3339, never earlier than the previous entry within a segment; also the decision time used by delegation.window and delegation.accounting | P1 (order only) |
| `run_id` | files.run_id | names this run | P1 |
| `operation_id` | op.requires_validation and every op.* check | gateway steps must name one; it must equal the operation in every artifact and decision value | P2, P3, P7 |
| `effect_type` | op.capability_bound; op.receipts_bound; op.requires_policy; op.outcome_resolved; artifact.signature | = the type in every artifact and value; selects the adapter role | P3 |
| `effect_digest` | artifact.effect_digest; op.requires_validation; op.capability_bound; op.receipts_bound; op.outcome_resolved; op.requires_policy | the validated request's digest is the one every later step names | P3 |
| `stage`, `outcome` | the op.* walk, delegation.*, policy.replay | the walk follows them; outcomes are compared with the decision values and the statuses | P2, P7 |
| `actor`, `component`, `location`, `summary` | not checked beyond the entry hash and signature: not needed | descriptive; authority comes from the signed artifacts | P1 only |

Security-relevant `details`, by stage:

| stage and field | checked by | property |
|---|---|---|
| RUN_STARTED `keys_sha256` | keys.hash (= SHA-256 of keys.json); with a head anchor this is how replacement keys are caught | P6 |
| RUN_STARTED `run_sha256` | files.run_record (= SHA-256 of run.json) | P2 (snapshot, mode) |
| RUN_STARTED `continues` | files.continuity (= run.json `continues`; the earlier folder ends with `final_head` and its keys hash to `keys_sha256`); keys.anchor (build 3): signed by the newest segment's audit key alone, so it anchors the earlier segments' keys only when the newest log is anchored (head pin, witness head checked as an extension, witness run status) or the earlier keys are pinned (`--expect-earlier-keys`); otherwise keys.anchor warns and `anchored_keys` is `not_checked` | P5, P6 (the earlier segments' keys) |
| RUN_STARTED `policy_hash`, `policy_name`, `simulator_origin`, catalog counts | files.run_record, only for older runs without `run_sha256` | P2 |
| RUN_STARTED `escalation`, `version`, `restored_operations` | not checked: redundant (run.json is bound by `run_sha256`) or not needed | — |
| REQUEST_VALIDATED `request_digest` | not checked: not needed (the verifier has no MCP request bytes; the effect digest is what is bound) | — |
| CAPABILITY_ISSUED `cti` | op.capability_bound | P7 |
| CAPABILITY_ISSUED `confirmation_kid` | op.capability_bound (build 3): = the token's `cnf` when logged | P3 |
| CAPABILITY_ISSUED `audience`, `issued_at`, `not_before`, `expires_at`, `single_use`, `policy_decision_hash` | not compared: redundant (the signed token's claims are checked) | — |
| EFFECT_EXECUTED `provider_reference` | op.receipts_bound | P3 |
| EFFECT_EXECUTED `call_id`; CALL_RESULT `call_id`; RECONCILED `call_id` | op.outcome_resolved; op.requires_policy (the executing call's CALL_RESULT is matched by call ID) | P2, P7 |
| EFFECT_EXECUTED `provider_request_digest` | not checked: provider accounting | — |
| EFFECT_EXECUTED `adapter_id`, `provider_location`, `status`, outcome | not checked: not needed | — |
| EFFECT_FAILED outcome `uncertain` / `status` UNCERTAIN | delegation walk (the reservation stays held) | — (delegation) |
| EFFECT_FAILED `lease_expired`, `reason` | not checked: not needed | — |
| CALL_RESULT `status` | op.outcome_resolved; op.no_effect_when_refused (denied or refused unless UNCERTAIN / RECONCILIATION_REQUIRED) | P7 |
| CALL_RESULT, MCP_REJECTED, REQUEST_REJECTED, APPROVAL_CONFLICT `scope` | op.no_effect_when_refused; op.approval_bound; op.outcome_resolved; the delegation walk (only scope `operation`, or no scope in older runs, releases a reservation) | P7 |
| CALL_RESULT `dispatched` | op.outcome_resolved (a call-scope REJECTED with `dispatched` true cannot be given for an executed operation) | P7 |
| CALL_RESULT `flagged` | op.requires_policy: the executing call's flag, every replayed COMMITTED answer's flag, and the flag of the call that reconciled or confirmed the effect (build 2) = the bound decision's; a refusal states no flag | P2 |
| CALL_RESULT `reason`, `refused_reason`, `resumed`, `replayed` | not checked: not needed (`scope` carries what the checks need) | — |
| RECONCILED outcome, `provider_status`, `provider_receipt` | op.outcome_resolved; provider.matches_audit; op.single_use; op.requires_validation and op.requires_policy when it records a new effect | P4, P7 |
| RECONCILED `flagged` | op.requires_policy (= the bound decision's flag, on a recording and on a confirming RECONCILED; build 2). Recovery records state the flag, not the mode or the fired rules | P2 |
| RECONCILED `effect_receipt` (optional) | op.receipts_bound (`checkReconciledReceipt`, build 2): bound to the consumed capability and its decision hash when present; not required | P2 |
| APPROVAL_REQUESTED `pre_decision_hash` | op.approval_bound | — (human mode) |
| HUMAN_DECISION outcome `rejected` | op.no_effect_when_refused | P7 |
| HUMAN_DECISION and APPROVAL_VERIFIED `approver` | not checked: not needed | — |
| DELEGATION_GRANTED `grant_id`, `grant_hash`, `delegation_grant` | delegation.grant | — (delegation) |
| DELEGATION_GRANTED grant parameters in details | not compared: redundant (the signed grant is read) | — |
| DELEGATION_REVOKED `grant_id` | delegation.revocation; policy.replay (DEL-REVOKED) | — (delegation) |
| WITNESS_UNAVAILABLE | no check; listed in `missing` | — |

## 11. Signed head (`head.json`)

Checked in `verify.go` (head.signature, head.matches). Note that the head
anchor compares the pin with the log's last entry hash, not with head.json.

| field | checked by | requirement | property |
|---|---|---|---|
| `run_id` | files.run_id; head.signature | names this run; signed | P1 |
| `seq`, `entry_hash` | head.signature; head.matches | signed; = the last line's seq and hash (truncation) | P1 |
| `kid` | head.signature | = the run's audit key kid | P1 |
| `signature` | head.signature | Ed25519 by the audit key over "AgentGate/AuditHead/v1", run, seq, entry hash | P1 |
| `time` | not checked and not signed: not needed | P1 and P5 rest on seq and hash | — |
| `format` | not checked: not needed | | — |

## 12. Keys and run record (`keys.json`, `run.json`)

| file and field | checked by | requirement | property |
|---|---|---|---|
| keys.json bytes | keys.hash; keys.anchor | SHA-256 = run.json and RUN_STARTED `keys_sha256`; = the pin or the witness's registered fingerprint | P6 |
| keys.json `keys[].kid`, `role`, `alg`, `public_key` | keys.valid (and every signature check looks keys up by kid and role) | 32-byte Ed25519 keys, known roles, unique 64-hex kids, exactly one AUDIT_LOG key whose kid is SHA-256 of its key | P1-P6 (all signatures rest on it) |
| keys.json `run_id` | files.run_id | | P6 |
| keys.json `purpose`, `format` | not checked: not needed | | — |
| run.json bytes | files.run_record | SHA-256 = RUN_STARTED `run_sha256` (audit key only) | P2 |
| run.json `policy.escalation` | op.requires_policy | every content decision's mode = this; a flag needs `flag` | P2 |
| run.json `policy.hash` | files.run_record; policy.snapshot_bound | = every POLICY_DECISION `policy_hash`; = the recomputed snapshot hash | P2 |
| run.json `policy_snapshot` | policy.snapshot_bound; policy.replay | recomputes to the issuer-signed policy hash; the replay's parameters | P2 |
| run.json `catalog` | policy.snapshot_bound | recomputes to every effect's catalog commitment | P2 |
| run.json `delegation.signed_grant` | delegation.grant | byte-identical to the logged grant | — (delegation) |
| run.json `identity` | delegation.grant | tenant and principal = the grant's | — (delegation) |
| run.json `keys_sha256` | keys.hash | | P6 |
| run.json `continues` | files.continuity | | P5 |
| an earlier segment's keys.json bytes | keys.hash (its own run.json and RUN_STARTED); files.continuity (= the next segment's `continues.keys_sha256`); keys.anchor (build 3) | SHA-256 among `Options.ExpectEarlierKeysSHA256` when pins are given (each pin must name a segment); without pins, anchored only through an anchor of the newest segment's log | P6 (the earlier segments' keys) |
| run.json `custody`, `host`, `pid`, `started_at`, `simulator_origin` | not checked: not needed (`simulator_origin` only in older runs, see RUN_STARTED) | | — |

## 13. Witness cosigned head (`--witness FILE` or `--witness-url`)

Checked in `witness.go` (`readWitness` for head.witness, `checkWitnessKeys`
for keys.anchor, `checkWitnessHead` for head.anchor).

| field | checked by | requirement | property |
|---|---|---|---|
| `format`, `head.format` | head.witness | `agentgate-witness-cosigned-head/v1` with an `agentgate-audit-head/v1` head | P5 |
| `run_id`, `head.run_id` | head.witness | this run | P5 |
| `witness_kid`, `witness_public_key`, `witness_signature` | head.witness | kid = SHA-256 of the witness key given from outside the folder; the embedded key (when present) is that key; the signature verifies over "AgentGate/WitnessCosign/v1" and the fields below | P5, P6 |
| `keys_sha256` | head.witness; keys.anchor | 64 hex; = SHA-256 of keys.json | P6 |
| `audit_kid`, `head.kid` | head.witness | equal; = keys.json's audit kid when the keys match | P5, P6 |
| `head.seq`, `head.entry_hash` | head.witness; head.anchor | signed; that entry is in the log with that hash and is the last entry (a proper prefix is a warning) | P5 |
| `head.signature` | head.witness | verifies with this run's audit key when keys.json is the registered one | P1, P5 |
| `extension_verified` | head.anchor | false: a warning, the head is not anchored (it could end a forked log) | P5 |
| `index` | head.witness | = the run status's `latest_index` when a status is given | P5 |
| `witnessed_at` | head.witness | the run status was not signed before it | P5 |
| `head.time` | covered by the witness signature only: not needed | the entry is identified by seq and hash | — |
| `witnessed_at` against the verification time | not checked | a saved head carries no freshness: a stale saved head is reported ANCHORED (measured: 20 of 20 custody runs, VERIFIER_CHECKS.md `head.anchor`). Build 2 reports this: the derived dimension `head_fresh` is `not_checked` for a saved or pinned head and `missing` lists a `freshness` entry; only a live witness run status (`--witness-url`) can make `head_fresh` pass. Freshness is reported, not enforced (Lim6) | P5 (limit) |

## 14. Witness run status (`--witness-url` only)

Checked in `witness.go` `readWitnessRun` (head.witness) and
`checkWitnessHead` (head.anchor).

| field | checked by | requirement | property |
|---|---|---|---|
| `format` | head.witness | `agentgate-witness-run-status/v2` (build 3, enrolled run; requires `enrollment_kid`) or `agentgate-witness-run-status/v1` (earlier witnesses, or a run registered before enrollment; carries no `enrollment_kid`); the unsigned registration format is a mismatch | P5 |
| `witness_kid`, `witness_public_key`, `witness_signature` | head.witness | the given witness key; the signature verifies over "AgentGate/WitnessRunStatus/v2" (v2, `enrollment_kid` last) or "AgentGate/WitnessRunStatus/v1" (v1, 15 fields) and every other member | P5 |
| `run_id` | head.witness | this run | P5 |
| `keys_sha256`, `audit_kid` | head.witness | = the cosigned head's | P5, P6 |
| `latest_index`, `latest_seq`, `latest_entry_hash` | head.witness | = the cosigned head given (else both are fetched again, up to 3 times) | P5 |
| `status_at` | head.witness; `head_fresh` | not before the head's `witnessed_at`; within 2 minutes (inclusive) of `WitnessRunFetchedAt` when that is set (the CLI sets it; since build 2 the custody runner's in-process live anchor sets it too) | P5 |
| `continued_by` | head.witness; head.anchor | not this run itself, and (build 3) not a run of the verified chain (an earlier segment); non-empty: head.anchor fails (a later segment was withheld) | P5 |
| `audit_public_key` | signed, not compared: redundant (bound elsewhere) | `audit_kid` is compared, and keys.valid requires the audit kid to be SHA-256 of the audit key | — |
| `continues.run_id`, `continues.final_head`, `continues.keys_sha256` | head.witness (build 3) | = the newest segment's continuation record (run.json `continues`, tied to RUN_STARTED by files.continuity; RUN_STARTED's when run.json has none), or both absent; the witness accepts a continuation's first push only with a RUN_STARTED carrying the same `continues` (CONTRACTS §10), so a mismatch means the chain is not the one the witness saw | P5, P6 (the earlier segments' keys) |
| `keys_file_verified`, `registered_at` | signed, not used: not needed | | — |
| `enrollment_kid` (build 3) | head.witness: shape only | v2: present, 64 hex, signed as the 16th field under the v2 label (removing or changing it breaks the signature; relabelling the status v1 changes the label); v1: absent (a v1 status carrying one is refused, even one signed as a 16th field, so it can be neither stripped nor added). Reported as `anchors.witness.enrollment_kid`, not compared with an enrollment key given out of band: it names which gateway key registered the run, it does not prove who held that key | — (registration authentication is the witness's check, not a verifier property) |

## Unchecked fields at a glance

Rewritten 2026-10-20 for build 3 (round 5). For every field that no check
reads, one line says why changing it cannot change a claimed property
(P1-P7, see [How to read it](#how-to-read-it)), or names the property it
weakens. "SF" marks a field that the validly signed single-field test
edits (`TestRound4ValidlySignedInconsistentFields`: one field edited, every
affected artifact re-signed with the fixture's keys, verified under the
full verifier with the keys anchor) and that the test confirms ACCEPTED.

**The validly signed single-field edits.** Round 4: 59 edits, 41 detected,
18 accepted. Build 3: 62 edits, 45 detected, 17 accepted (asserted per
claim: effect binding 15/5, classification binding 7/0, provider evidence
11/7, approval lineage 12/5). Of the 18 accepted in round 4, the status
observation's `observed_at` (dated 2030) is now detected
(`op.outcome_resolved`); three edits were added and are detected (the
capability's `cnf` naming an unlisted key, `cnf` naming the message adapter
key on a payment, `op.capability_bound`; `observed_at` before the
capability, `op.outcome_resolved`). The other 17 are in the tables below,
marked SF.

**Not fields, but gaps of the same kind (build 3).** A keys pin anchors the
newest segment's keys.json only: the earlier segments of a run, keys
included, hang on the continuation record in the newest segment's
RUN_STARTED, which its audit key alone signs. Without a head anchor, the
witness's run status (whose `continues` is now compared) or pins of the
earlier segments' keys (`--expect-earlier-keys`), an audit-key holder can
present a made-up earlier segment with issuer and adapter keys of its own
and move operations into it (tested with real fixture signatures,
`TestEarlierSegmentKeysAnchor`: still VERIFIED with the newest keys pin
alone). Since the round-5 fixes such a verification never reports the keys
as anchored: `keys.anchor` warns, `anchored_keys` is `not_checked` and
Missing says "Keys anchored for the newest segment only"; with the earlier
pins the made-up segment fails `keys.anchor`. So P2, P3 and P6 under a keys
anchor hold for a run of several segments only when `anchored_keys`
passes.

### Capability token (§1, signed by the issuer)

| field | why changing it cannot change P1-P7 | SF |
|---|---|---|
| 1 `iss` | the issuer is the CAPABILITY_ISSUER key that signs; the text names no key | |
| 2 `sub` | the principal is the canonical effect's `principal_id`, inside the effect digest the token signs (-70004, checked); `sub` is read only online | SF |
| -70001 tenant | the tenant is inside the effect digest (as `sub`) | SF |
| 4 `exp` against the time of use | no property claims when the token was used: the online registry refuses an expired token, and offline the log gives order, not time (Lim6) | |
| -70005 base root | a copy of the effect's `base_provenance_root`, inside the effect digest | |
| -70006 overlay root | the FINAL value commits to it and -70007 (checked) to that value; in flag mode it is the constant empty-overlay root | |
| -70008 decision object hash | a second hash of the FINAL value that -70007 (checked) already binds | |
| -70010, -70011, -70012 epochs | constants of the prototype, checked online; no claim reads them | |
| -70013 artifact hashes, -70014 covered paths | human mode only (approval lineage); no P1-P7 property rests on approvals (Lim8). Weakens approval lineage: an issuer- and adapter-key holder could cite another genuine approval of the same operation, effect, PRE and request (op.approval_bound links the approval by those); the flag, mode and rules (P2) are other FINAL fields, which are checked | SF (-70013) |
| -70015 profile version | the COSE header's profile version is checked by artifact.signature | |
| -70016, -70017, -70018 | derived by the issuer from (task, operation), (operation, effect type) and (effect digest, catalog hash), each bound elsewhere | |

### Adapter receipt (§2)

| field | why changing it cannot change P1-P7 | SF |
|---|---|---|
| `v`, `receipt_id`, `attempt`, `started_at`, `completed_at`, `attestation_level`, `reason_code` | descriptive or timing; P3 rests on the operation, effect digest and type and the cited hashes, which are checked | |
| `tenant_id`, `base_provenance_root` | inside the effect digest, which is checked | |
| `authorization_overlay_root` | the FINAL value that `policy_decision_hash` (checked) binds carries it | |
| `authorization_artifact_hashes` | approval lineage, human mode only (as -70013 above) | SF |
| `provider_request_digest`, `idempotency_key_hash`, `provider_response_digest` | provider accounting: they describe the provider request, not the effect, operation or capability the receipt binds (all checked); the provider's one-commit-per-key contract is an assumption of P7, not evidence | SF (first two) |
| `adapter_id` | the signing key has the ADAPTER_* role of the effect type and is the key the capability's `cnf` names (build 3) | SF |
| `outcome` (on EFFECT_EXECUTED) | the provider receipt's outcome and the journal decide P3 and P4; the adapter's own word is not an input of any check there (on RECONCILED it is checked: APPLIED) | SF |

### Provider receipt (§3) and journal (§5)

| field | why changing it cannot change P1-P7 | SF |
|---|---|---|
| `effect_row_bytes`, `effect_row_hash`, `canonical_state_delta_hash` | provider accounting. Weakens only "the provider applied exactly the canonical effect", which is not claimed (Lim4): P3 is stated on the effect digest that the issuer, the adapter and the provider all sign | SF (row hash) |
| `provider_request_digest`, `idempotency_key_hash` | provider accounting; P7's one effect per operation key rests on the provider's contract (assumed) and on the one-to-one journal matching (checked) | SF |
| `run_id` | the receipt is in this run's journal byte for byte and cited by hash in an adapter receipt signed with this run's key | |
| `simulator_id`, `endpoint_profile`, `v`, `reason_code` | descriptive; the journal header's `simulator_id` only decides whether a later journal must extend an earlier one | |
| `tenant_id` | inside the effect digest | |
| `adapter_id` | the effect type and digest (checked) identify the request | SF |
| `committed_at` | P4 orders commits by `commit_seq` and the state chain, not by time | SF |
| `state_before_hash` of the first commit | weakens P4 at the start of the journal only: nothing in the evidence states the provider's initial state, so the first commit's starting state is not anchored (state changes before the run's first commit could be hidden). P4 as claimed covers the commits in the journal, each matched one-to-one with the log; no journaled commit can be hidden by this field | SF |
| journal `format` | `files.present` only requires unambiguous JSON | |

### Provider status observation (§4)

| field | why changing it cannot change P1-P7 | SF |
|---|---|---|
| `run_id`, `simulator_id`, `tenant_id`, `adapter_id` | the operation, effect digest and type (checked) identify the request | |
| `idempotency_key_hash`, `status_request_digest` | provider accounting; P7's honest status rests on the operation, effect digest, type, status and stored receipt hash, all checked | SF |
| `query_id`, `reconciliation_seq`, `v` | request identifiers the verifier has no counterpart for; no claim reads them | |
| `provider_reference` | the stored receipt hash (checked) names the receipt, which carries the reference | SF |
| `canonical_state_hash`, `current_commit_seq` | P4 rests on the journal (state chain and one-to-one matching), not on the status's view of the state; a change cannot add or hide a journaled commit. Deferred: tying them to the journal would add assurance | SF |

### Decision values (§6), approval artifacts (§7), delegation grant (§8)

| field | why changing it cannot change P1-P7 | SF |
|---|---|---|
| PRE 20.2 `evaluated_at` | delegation uses the entry's time; no P1-P7 property rests on the grant | |
| PRE keys from 10 up | covered by the PRE hash (checked); never read for the flag | |
| FINAL (approved) 8 artifact hashes, 9 covered paths, 10 profile | approval lineage, human mode only (as -70013) | SF (field 8) |
| FINAL (approved) 7 overlay root, recomputed from the approvals | human mode only: compared with the entry's `overlay_root` but not recomputed; the flag-mode values (P2) carry no overlay | SF (with the details changed too) |
| FINAL 20 delegation totals | field 3 (checked) commits to the PRE value, whose block delegation.accounting checks | |
| POLICY_DECISION `reasons[].message` | text for humans | |
| approval state 0, 1, 2, 3, 10; decision 0, 1, 3, 4 | content type and key role, or inside the effect digest, or a nonce; human mode only (Lim8) | |
| decision 5 approver, entries' `details.approver` | an unauthenticated local click (Lim8); no property rests on who clicked | SF |
| grant `issuer` | the DELEGATION_AUTHORITY key role is the issuer statement | |
| grant `purpose` | free text; a wrong-purpose payment passes (Lim8); no P1-P7 property rests on the grant | |
| a policy hash in the grant (absent) | the grant names no policy, so the snapshot is bound to the issuer-signed policy hash, not to the organisation's intent (Lim5); P2 is stated against that snapshot | |

### Canonical effect (§9), audit entries (§10), head, keys and run record (§11, §12)

| field | why changing it cannot change P1-P7 | SF |
|---|---|---|
| effect `tenant_id` against run.json, `task_id`, `base_provenance_root`, `v` | inside the effect digest that every signer signs; no claim compares them with run.json | |
| entry `actor`, `component`, `location`, `summary` | covered by P1 (entry hash and signature) only; authority comes from the signed artifacts | |
| RUN_STARTED `escalation`, `version`, `restored_operations` | run.json (whose `policy.escalation` is checked) is bound by `run_sha256`; `version` is descriptive; delegation totals are checked from the decisions | |
| REQUEST_VALIDATED `request_digest` | the verifier has no MCP request bytes; P3 binds the effect digest | |
| CAPABILITY_ISSUED `audience`, `issued_at`, `not_before`, `expires_at`, `single_use`, `policy_decision_hash` details | the signed token's claims are what is checked | |
| EFFECT_EXECUTED `provider_request_digest`; `adapter_id`, `provider_location`, `status`, outcome | provider accounting, or descriptive: the receipts decide | |
| EFFECT_FAILED `lease_expired`, `reason` | descriptive; the status-order and pending rules read only its outcome / `status` UNCERTAIN | |
| CALL_RESULT `reason`, `refused_reason`, `resumed`, `replayed` | `status`, `scope`, `dispatched`, `flagged` and `call_id` carry what the checks need | |
| RECONCILED `previous_status`, `status_reference`, `reconciliation_seq`, `observed_at`, `idempotency_key_hash`, `provider_request_digest`, `adapter_id`, `provider_location` details | audit-key copies of what the signed status observation states (checked); the order rule reads the log's own unresolved entries, not `previous_status` (both audit-key only) | |
| DELEGATION_GRANTED parameters in details | the signed grant is read | |
| head.json `time`, `format` | P1 and P5 rest on `seq` and `entry_hash` | |
| keys.json `purpose`, `format` | descriptive | |
| run.json `custody`, `host`, `pid`, `started_at`, `simulator_origin` | descriptive (bound by `run_sha256` anyway) | |

### Witness documents (§13, §14)

| field | why changing it cannot change P1-P7 | SF |
|---|---|---|
| cosigned head `head.time` | covered by the witness signature; the entry is identified by seq and hash | |
| `witnessed_at` against the verification time | weakens P5 for a saved or pinned head: a stale anchor is still ANCHORED (measured: 20 of 20 custody runs). Reported, not enforced: `head_fresh` is `not_checked` and Missing lists `freshness` (Lim6); only a live run status makes `head_fresh` pass | |
| run status `audit_public_key` | `audit_kid` (checked) commits to it through keys.valid | |
| run status `keys_file_verified`, `registered_at` | signed, not used; who may register is the witness's business (since build 3 only a holder of an enrollment key the witness was started with; on one OS account any same-user process can read that key, VERIFIER_CHECKS.md §7) | |
| run status `enrollment_kid` against a key given out of band | signed and reported, not compared: the verifier takes no enrollment-key pin, so it shows which enrollment key registered the run without proving it is the gateway's (the witness enforced enrollment at registration) | |

### Deferred checks (would add assurance; not built)

* the approval lineage lists: FINAL field 8, the capability's -70013 /
  -70014 and the adapter receipt's `authorization_artifact_hashes`
  (expected check: all equal [H(decision label, the `signed_decision` the
  capability rests on)] for an approved action and empty otherwise), and
  recomputing the FINAL overlay root;
* cross-role equality of the request digest and idempotency key hash across
  the two receipts and the entry details; recomputing the row hash
  (H("AgentGate/EffectRow/v1", row)) and the delta hash; comparing the row
  with the projection of the canonical effect; replaying the provider state
  from its initial state; tying a status observation's
  `canonical_state_hash` / `current_commit_seq` to the journal;
* enforcing freshness (build 2 reports `head_fresh` and `run_complete`);
* an adapter-signed reconciliation receipt with an authenticated provider
  status endpoint (GP2): until then a reconciled commit is issuer-only (the
  build-3 status date and order rules add no key);
* a policy hash in the delegation grant;
* comparing the run status's `enrollment_kid` with an enrollment key given
  out of band.

(Built in the round-5 fixes, no longer deferred: one keys pin per earlier
segment, `--expect-earlier-keys`; without it, or an anchor of the newest
log, `anchored_keys` is `not_checked` for a run of several segments.)

The not-needed fields are listed in the tables above with their reason
(descriptive text, constants, timestamps whose order the log gives, request
identifiers the verifier has no counterpart for).
