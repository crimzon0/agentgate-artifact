# From demo to paper: candidate research angles

> **Superseded 2026-10-01:** the chosen research question, plan and timeline are in
> [docs/research/RESEARCH_DECISION.md](../research/RESEARCH_DECISION.md). This note is kept as background.

Written 2026-10-01 after the supervisor demo was finished. These are
*candidates* to discuss with the supervisor, not results. Every number the
demo prints today is a local development measurement on one laptop.

The demo already contains the parts of a measurement setup: a scripted attack
and benign workload (14 scenarios), an evidence writer (`internal/audit`), an
independent verifier with stable check IDs (`internal/auditverify`), a mutation
generator (the tamper lab), and a harness that writes machine-readable results
(`scripts\demo.ps1 -SelfTest -Repeat N` → `selftest-report.json`).

## Angle 1 — Which evidence layer catches which failure? (recommended)

Working claim to test (matches `research/14_paper_focus_2026-09-05.md`): *a
separate verifier can tell whether each recorded effect matches its
authorization, detects inconsistent histories, and reports when evidence is
insufficient, without falsely certifying success.*

- **Mutation corpus:** generalize the 8 tamper kinds into systematic operators
  (edit any field, delete, reorder, duplicate, splice between operations,
  roll back to an earlier checkpoint, swap artifacts) applied at every position
  of many runs, plus clean runs as controls.
- **Ablation:** run the verifier with layers switched off: hash chain only →
  + entry signatures → + artifact signatures → + cross-step bindings → +
  provider-journal reconciliation → + external anchors. Report the detection
  rate per operator per configuration, and false alarms on clean runs.
- **Expected story:** chains alone miss re-hashing; signatures miss rollback
  and receipt swaps; bindings and reconciliation catch the swaps and hidden
  operations; only anchors catch rollback. The rollback attack already shows
  "VERIFIED without anchor, FAILED with anchor".

## Angle 2 — What does verifiable evidence cost?

- Per-step gateway latency and evidence size per operation are already
  reported. The self-test suggests each signed, fsynced audit append costs
  about 2 ms, which is most of the gateway's per-call overhead.
- Experiment: durability policies (fsync each entry vs group commit vs
  per-operation checkpoint) against latency, and the crash window each leaves.
- Caveat: Go's clock on this Windows machine advances in 1 ms steps; use many
  repetitions (`-Repeat 50`) or a high-resolution timer before claiming
  sub-millisecond numbers.

## Angle 3 — Refusing post-approval and replay attacks against a fair baseline

- Attack families already implemented: post-approval swap, forged approval
  state, replay, prompt-injected unknown recipient, schema smuggling.
- A fair comparison needs a *competent* baseline (exact approved-action hash,
  execution-time check, durable idempotency), not a strawman. Measure refusal
  correctness and legitimate-completion rate for both.

## Before any claim-bearing measurement

- Freeze the corpus and verifier version first; keep ground truth outside the
  runtime; count variants of one case as one case.
- Honest limits to state up front: one machine, per-run keys, no independent
  key custody or witness; the approver is not authenticated; providers are
  simulated. Human-subject work needs ethics approval first.
