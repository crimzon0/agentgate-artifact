# Revision contract (2026-10-07): response to the supervisor's review

> **Correction note (2026-10-10, honesty sweep; the contract below is
> unchanged).** R6.1 says the attacker "re-signs exactly what its keys allow".
> As built, the key-compromise study is a structural simulation: the edit
> engine changes content and recomputes hashes, and the verifier skips the
> signature checks of the roles the attacker holds; nothing is re-signed
> (`docs/demo/VERIFIER_CHECKS.md` §9). Real re-signing was added only on test
> fixtures (audit key; audit and issuer keys). "An independently written
> oracle" means an oracle written by the same authors from the specification,
> without opening the verifier or the edit engine
> (`docs/paper/artifact/ORACLE_FREEZE.md`). Log:
> `docs/paper/artifact/HONESTY_SWEEP.md`.

Source: the supervisor's review "AgentGate review and proposed improvements" (major revision).
This document extends `docs/demo/CONTRACTS.md`; where they disagree, this one wins.
Go contract types: `internal/devcomposition/revision.go` (fixed names; implement behind them).
Zero values / absent flags must keep today's behaviour and keep every existing test passing.

Deadline for the paper: AIR'2026 full paper 2026-10-31. Build only what the experiments and the
revised paper need; prefer narrowing a claim over half-building a feature.

## R1. Central contribution (what everything serves)

AgentGate binds the audit classification (FLAG, escalation mode) and the fired policy rule IDs of
an autonomous action into its execution authorisation (PRE/FINAL decision hashes → capability →
adapter receipt), so an offline verifier can detect a classification change under explicitly
defined signing-key compromise assumptions. The evaluation must show which attacks change from
accepted to rejected *because of* this binding (ablation: `Experiment.UnboundFlags`), separately
from anchoring.

## R2. Explicit operation outcomes and failure boundary

- Statuses (`OperationStatus`): REJECTED, PENDING, COMMITTED, UNCERTAIN, RECONCILIATION_REQUIRED.
  The agent receives `structuredContent.status` (and a reason); CALL_RESULT records
  `details.status`. The MCP layer must no longer collapse every error to "call denied": a call
  whose provider request may have been sent must never be reported as REJECTED.
- Mapping: any refusal before capability consumption → REJECTED (keep `reason`, e.g. policy deny,
  catalog miss, schema). Capability consumed but provider not contacted (FaultAfterCapabilityConsume)
  → REJECTED only if the dispatcher can prove no request left (else UNCERTAIN). Provider response
  lost → UNCERTAIN, then resolved by reconciliation (provider status lookup by idempotency key; the
  simulator already supports idempotency + status observations). Provider committed but the
  EFFECT_EXECUTED append or head replacement fails → RECONCILIATION_REQUIRED.
- New audit stage `RECONCILED` (component `gateway/reconciler`): records the provider's signed
  status observation that resolves an UNCERTAIN or RECONCILIATION_REQUIRED operation (outcome
  `committed` or `not_committed`), with artifact `provider_status`. The verifier accepts a provider
  effect whose audit trail ends in RECONCILED-committed (instead of EFFECT_EXECUTED) and reports it.
- Retry rules: an exact retry of an UNCERTAIN/RECONCILIATION_REQUIRED operation ID first reconciles,
  never re-dispatches blindly; a fresh operation ID for identical content is a new operation
  (documented: one effect per operation ID, not per business intent — business-level uniqueness is
  the delegation budget's job, R4).
- Fault points (`FaultPoint`): before/after capability consumption, provider response lost, after
  receipt before audit, audit append, head replace. `Config.Faults` injects them (nil in production).
- Durable state (`Config.OperationJournal`): append-only, fsynced JSONL journal of operation
  transitions (received, decision, capability issued, capability consumed, dispatch intent written
  BEFORE the provider request, provider outcome, recorded, reconciled). On restart the composition
  replays it: completed operations return their stored result; consumed capabilities stay consumed;
  operations with a dispatch intent but no recorded outcome are reconciled with the provider before
  any retry. Claims in the paper are limited to what restart tests demonstrate.
- Concurrency: simultaneous exact retries of one operation ID and conflicting reuse (same ID,
  different content) must yield at most one provider effect and a deterministic status for each call.

## R3. Verification outcomes that express the actual assurance

- Verdict levels (Report.Assurance): `FAILED`; `CONSISTENT` (all checks pass but at least one
  anchor missing — the evidence is internally consistent only); `ANCHORED` (all pass with the keys
  fingerprint AND a trusted head — pinned value or witness cosigned head — matching). Keep
  Report.Verdict = VERIFIED|FAILED for compatibility, add Report.Assurance and
  Report.Dimensions: {structural, decisions_authenticated, policy_replayed, provider_reconciled,
  delegation_respected, anchored_keys, anchored_head} each pass|fail|not_checked with a reason, and
  Report.Missing []string (e.g. "no head anchor: a coherent rollback to an earlier signed prefix
  cannot be ruled out").
- Policy replay: run.json gains `policy_snapshot` (all rule parameters incl. per-currency limits,
  escalation mode, organisation name, the catalog facts the rules read: recipient external flags,
  document classifications, payee IDs, confidential-text shingle hashes) and the delegation grant.
  The verifier independently re-implements the rules (no gateway import) from this snapshot and the
  canonical effect (`effect_cbor`) and checks outcome + fired rule IDs against each logged decision
  value. Check ID `policy.replay`.
- Publish the full check specification (ID, group, inputs, predicate, failure semantics):
  `docs/demo/VERIFIER_CHECKS.md`, generated from or kept in sync with `internal/auditverify/checks.go`.
- Robustness: Go fuzz targets for log-line parsing, COSE/CBOR decoding and run-file parsing; tests
  for duplicate/case-variant fields, unknown key roles and algorithm IDs, malformed envelopes,
  oversized inputs. Refusal-site mutation testing tool (delete one `checks.fail` call at a time, run
  the verifier test suite, report the kill score).

## R4. Bounded autonomous delegation and policy hardening

- The demo generates a separate organisation key (role `DELEGATION_AUTHORITY`, listed in keys.json),
  signs one `DelegationGrant` at startup (COSE_Sign1, content type
  `application/agentgate-delegation+cbor`), records it in run.json and in a `DELEGATION_GRANTED`
  audit entry (artifact `delegation_grant`), and passes only the signed grant + public key to the
  composition. Revocation: `Composition.RevokeDelegation(grantID)` (and demo `POST /api/delegation/revoke`);
  afterwards every new or resumed operation under that grant is denied (`DEL-REVOKED`).
- New rules, evaluated before the content rules, all DENY: `DEL-SCOPE` (effect type, recipient or
  payee not in the grant), `DEL-EXPIRED` (outside nbf/exp), `DEL-REVOKED`, `DEL-BUDGET` (currency
  not in Budgets, or cumulative committed+reserved amount for that currency would exceed the
  budget), `DEL-COUNT` (executed+reserved count for the effect type would exceed MaxCounts).
  Reservation happens at PRE and is released on any non-commit outcome; FINAL re-checks.
  Decision values add: grant ID, grant hash, cumulative_before, cumulative_after (per currency /
  per effect type). The verifier recomputes the cumulative sums from executed operations and checks
  them against the grant (`delegation.*` checks).
- Per-currency limits: `ContentPolicy` gains per-currency (auto, hard) limits; demo values
  AED 5,000.00 / 50,000.00 and USD 1,500.00 / 15,000.00 (≈ same value). Committed into the policy hash.
- Amount edge cases: `FIN-ZERO` DENY for amount 0; negative, fractional, > 2^53−1 and malformed
  amounts are rejected at the schema/normalizer (REJECTED). Boundary semantics: auto limit is
  inclusive (≤ auto → ALLOW), hard limit inclusive (≤ hard → FLAG/approval), above hard → DENY.
- Content rule `MSG-CONFIDENTIAL-TEXT`: if a message subject/body contains a 12-word shingle of a
  confidential or restricted catalog document, DENY when any recipient is external, FLAG (or approval
  in human mode) when internal. Snapshot stores shingle hashes, not text. State clearly that this is
  verbatim-copy detection, not information-flow control (paraphrase evades it).
- Policy version pinning: FINAL refuses unless its policy hash equals the PRE decision's policy hash.

## R5. Separate custody

- `cmd/agentgate-provider`: runs the simulator runtime in its own process with its own Ed25519 key
  (generated on first start, private key stored in its own directory) and persisted state/journal
  under its own directory; serves the existing simulator HTTP endpoints plus `GET /journal` (the
  provider journal format of CONTRACTS §5.5) and `GET /key` (KID + public key). The gateway uses it via
  `Config.ExternalProvider`.
- `cmd/agentgate-witness`: accepts `POST /heads` with a signed audit head (head.json content); verifies
  the audit key from the run's keys.json fingerprint registered at run start (`POST /runs` with
  run_id + keys_sha256), rejects non-monotonic seq or forks for a run, countersigns with its own key
  and appends to its own store; `GET /runs/{id}/latest` returns the latest cosigned head. The demo
  pushes the head after every operation. The verifier option `WitnessHead` (CLI `--witness FILE`)
  uses a cosigned head as the head anchor (and the registered keys hash as the keys anchor).
- Witness unavailable: the gateway keeps running, records `WITNESS_UNAVAILABLE` and the verifier
  reports the gap (assurance cannot be ANCHORED beyond the last cosigned head).

## R6. Evaluation (cmd/agentgate-eval; results under docs/paper/data/revision/)

1. Flag-binding ablation + key compromise: mutation operators {strip flag, invent flag, change fired
   rules, change escalation mode, swap PRE/FINAL values between operations, change effect amount,
   relabel human-approved as automatic (human mode)} × attacker key sets {none, audit, issuer,
   adapter, provider, delegation-authority, audit+issuer, audit+issuer+adapter,
   audit+issuer+adapter+provider, all (replacement key set)} × anchor conditions {no anchors, keys
   only, head only, both (or witness)} × design {bound (default), unbound (ablation)}. Mutants are
   repair-closed: the attacker re-signs exactly what its keys allow and re-chains/re-signs the log
   when it holds the audit key. Expected outcomes come from an independently written oracle
   (`docs/paper/oracle/`), never from the verifier. Report acceptance matrices and the exact cells
   that flip because of the binding.
2. Anchor ablation incl. replacement keys and coherent rollback.
3. Crash/response-loss schedules at every fault point, with restart and retry (same and fresh IDs):
   duplicate provider effects, unresolved outcomes, incorrect statuses, evidence gaps.
4. Concurrency: simultaneous exact retries, conflicting ID reuse, racing capability consumption.
5. Policy misuse sequences: boundary values, split payments vs delegation budget, repeated external
   releases vs MaxCounts, confidential text copied into a message, out-of-scope payee.
6. Custody: provider + witness processes, witness outage, rollback detection via witness.
7. Verifier robustness: fuzzing summary + refusal-site mutation kill score.
8. Baselines and load: direct (adapter → provider, no gateway), policy-only (gateway, audit off), full
   (policy + signed recording), identical transport/provider; sequential and concurrent load;
   throughput, p50/p95/p99, CPU and memory; paired trials; full distributions kept.

## R7. File ownership (Phase 1)

| owner | files |
|---|---|
| gateway-policy | internal/devcomposition/policy.go, delegation.go (new), components.go (decision values), their tests |
| gateway-lifecycle | internal/devcomposition/auditing.go, dispatch.go, faults.go (new), durable.go (new), the Operations/registry construction lines in composition.go, internal/mcp/official.go (status mapping), internal/controlpoint (only if required), new internal/opjournal/**, their tests |
| custody | cmd/agentgate-provider/**, cmd/agentgate-witness/**, internal/headwitness/** (new), internal/devcomposition/external_provider.go (new) and the simulator-construction lines in composition.go |
| verifier | internal/auditverify/**, cmd/agentgate-verify/**, docs/demo/VERIFIER_CHECKS.md |
| eval-engine | cmd/agentgate-eval/** (new subcommands), internal/evalattack/** (new) |
| oracle | docs/paper/oracle/** only (must not read internal/auditverify) |
| demo (Phase 2) | internal/demo/**, cmd/agentgate-demo/**, scripts/demo.* |
