# AgentGate verifier: check specification

Status: authoritative specification of every check of the offline verifier
(`internal/auditverify`, CLI `cmd/agentgate-verify`) after the 2026-10-07
revision (`docs/demo/REVISION_CONTRACT.md` R2-R5), including evidence that
continues across a gateway restart (§8) and the key-compromise simulation
(§9); updated 2026-10-08 (the witness's run status and withheld restart
segments in `head.anchor`, call-scope approval conflicts, `call_id` on
effect entries; later the same day: the run status is signed by the witness
and checked in `head.witness`, and §6 lists the refusal conditions no test
or fuzz input executed); updated 2026-10-10 (the derived dimensions
`head_fresh` and `run_complete`, per-operation classification evidence,
the recovery-record flag rule in `op.requires_policy` and the lifecycle
states table in §1; no check ID was added; later the same day: an adapter
receipt carried by a RECONCILED entry is checked in `op.receipts_bound` and,
when bound, makes the operation `issuer_adapter`; `missing_kinds`; the
`head_fresh` cases of a refused witness; then: a replayed `COMMITTED`
answer and the call whose RECONCILED entry confirms an execution must state
the bound flag, in `op.requires_policy`; last: §6 shows the build-2 robustness numbers and the lifecycle notes state that an unjustified reconciliation is reported like a genuine one); updated 2026-10-20 for build 3 (round 5 of the supervisor's review; no check ID was added): `op.outcome_resolved` dates the provider's status observation and requires a reason to reconcile before a RECONCILED entry that records an effect, and reports an operation that holds a verified capability with no outcome like an unresolved one; `op.capability_bound` checks the capability's confirmation key (cnf); `head.witness` compares the witness's registered continuation with the verified chain; later the same day (round-5 review fixes, still no new check ID): `keys.anchor` covers the earlier segments of a restarted run only through pins of their own (`--expect-earlier-keys`) or an anchor of the newest segment's log, else `anchored_keys` is `not_checked` for such a run; the status date's lower bound applies to a `committed` RECONCILED only; the reconciling call's own unresolved answer is no reason to reconcile; the witness run status may be format `v2` and its `enrollment_kid` is reported; the report states the one-clock assumption. The test
`TestVerifierChecksDocument` keeps this file in sync with
`internal/auditverify/checks.go`: every check ID has exactly one section
below, and the group, dimension and mechanism stated in it are the ones the
code uses.

The verifier imports no gateway package. It re-implements the evidence format
(`docs/demo/CONTRACTS.md` §5) and the policy rules itself, so a bug in the
writer is not silently mirrored by the checker.

## 1. How results are reported

**Items and statuses.** A check is evaluated once per item it applies to (a
log line, an artifact, an operation, a journal receipt, a decision). Each
item is `pass`, `fail` or `warn`. In the report, passing items of one check
collapse into a single `pass` line with a count; every failing or warning item
is listed on its own, with the entry (`seq`) and operation it concerns. A
check switched off for an evaluation (`Options.DisableChecks` /
`DisableMechanisms`, ablation only) is reported once as `skipped`.

**Optional checks.** `verifier.error`, `files.continuity`, `head.witness`,
`policy.snapshot_bound`, `policy.replay` and the six `delegation.*` checks are
omitted from the report when nothing applied to them (no crash, a run that
does not continue an earlier segment, no witness head given, no policy
snapshot to bind or replay, no delegation grant). Their
absence is never shown as a pass: the matching assurance dimension says
`not_checked` and the report's `missing` list says why.

**Verdict.** `verdict` is `FAILED` when any item failed, else `VERIFIED`
(warnings allowed). It is a legacy value kept for compatibility, and
`VERIFIED` means only that **no check failed**: it does not say that the
evidence is anchored, that the anchor is fresh, that the run is complete, or
what each operation's classification rests on. Consumers read `assurance`,
the nine `dimensions` and `missing` (and, per operation,
`classification_evidence`) for what the evidence supports; the CLI prints
this under the verdict line.

**Assurance.**

| assurance | meaning |
|---|---|
| `FAILED` | at least one check failed |
| `CONSISTENT` | every check passed, but at least one anchor is missing (or a check was switched off): the evidence is internally consistent only |
| `ANCHORED` | every check passed, nothing was switched off, and both `anchored_keys` and `anchored_head` pass: the keys and the end of the log match values held outside the run folder |

**Dimensions.** Nine named properties, each `pass`, `fail` or
`not_checked`, with a reason and the check IDs it is computed from. Seven
are check-based (`DimensionNames()`): a dimension fails when one of its
checks has a failing item; it is `not_checked` when none of its checks
applied (or all were switched off); the two anchor dimensions pass only when
their anchor check has a passing item (a missing pin is a warning, which
means `not_checked`, never `pass`). Two are derived (`DerivedDimensionNames()`,
`freshness.go`): `head_fresh` and `run_complete` own no check, add no failing
item and never change `verdict` or `assurance`; they are computed from the
state the checks leave, and their `checks` member lists the checks whose
state they read. They are listed apart so that a consumer requiring every
check-based dimension to pass for a pinned run (the demo self-test) is not
changed by them.

| dimension | question it answers | checks |
|---|---|---|
| `structural` | Are the files complete, well-formed, chained, signed, and does every step follow a validated request? | `verifier.error`, `files.*` (incl. `files.continuity`), `keys.valid`, `keys.hash`, `chain.*`, `head.signature`, `head.matches`, `artifact.*`, `op.requires_validation`, `op.single_use`, `op.no_effect_when_refused` |
| `decisions_authenticated` | Is every execution bound to the decision values its capability and receipts sign? | `op.requires_policy`, `op.approval_bound`, `op.capability_bound`, `op.receipts_bound` |
| `policy_replayed` | Is the recorded policy the one the capabilities commit to, and does every logged decision follow from it and the canonical effect? | `policy.snapshot_bound`, `policy.replay` |
| `provider_reconciled` | Does the provider's own journal match the log, and is every reported outcome honest? | `provider.*`, `op.outcome_resolved` |
| `delegation_respected` | Did every autonomous action stay inside the organisation's signed grant? | `delegation.*` |
| `anchored_keys` | Are the keys the ones the run started with (pin or witness registration)? For a run of several segments, also the earlier segments' keys (their own pins, or an anchor of the newest segment's log; build 3) | `keys.anchor` |
| `anchored_head` | Does the log end where an outside party saw it end (pin or witness cosignature)? | `head.anchor`, `head.witness` |
| `head_fresh` (derived) | Is the witness's statement about the run *current* (its signed status fetched now), not a saved copy? | reads `head.witness`, `head.anchor` |
| `run_complete` (derived) | Is this evidence the complete latest run: a fresh signed run status, no later segment, end anchored, every outcome settled? | reads `head.witness`, `head.anchor`, `op.outcome_resolved` |

**Freshness and completeness (`head_fresh`, `run_complete`).** ANCHORED keeps
its meaning: the keys and the end of the log match values held outside the
folder. It does not say that the value is the run's *latest* head: a pinned
head hash or a saved cosigned head shows where the log ended when it was
saved, so a coherent rollback to it (the log genuinely ending at the
anchored entry, presented after the run went on) passes every check, as the
custody experiment measured. The derived dimensions make that visible.

- `head_fresh` **passes** only when the witness's signed run status was
  checked (`head.witness`, signed-status rule) and its `status_at` is within
  `MaxWitnessStatusSkew` = **2 minutes** of `Options.WitnessRunFetchedAt`
  (the CLI's `--witness-url` sets it; the window is inclusive at both ends:
  signed exactly 2 min before or after the fetch is fresh, 2 min 1 s is
  not), and the cosigned head it names carries the witness's extension
  proof. A pass says only that the witness's statement is current: whether
  the log ends at the head the status names is `anchored_head`'s question
  (the status may name an earlier entry, a prefix of the log) and whether a
  later segment continued the run is `run_complete`'s, so its reason calls
  the head anchor "the witness's current view of the run" only when the
  status names this log's last entry and no continuation. It **fails** when
  a run status was given with the witness's head but the witness's answer
  was refused (`head.witness` failed: stale, unsigned, tampered, another
  head, or the head document itself unreadable). It is **not_checked** for a
  pinned head (`--expect-head`), a saved cosigned head (`--witness FILE`, no
  status), a refused witness head given without a status (the reason says
  it was refused, never that no anchor was given), a status given without
  the head it names (not read), a status given without its fetch time (its
  age is not bounded), a head cosigned without an extension proof, no head
  anchor at all, or the anchors switched off. For a pinned or
  saved head that does anchor the log, `missing` says: "Head not shown to be
  fresh: ... the freshness rests on whoever saved it; a coherent rollback to
  the anchored head ... or a withheld later restart segment cannot be ruled
  out".
- `run_complete` **passes** only when `head_fresh` passes, the status names
  no later segment continuing the run (`continued_by` empty), the log end is
  anchored (`anchored_head` passes), no check failed or was switched off, and
  no operation is left `UNCERTAIN` or `RECONCILIATION_REQUIRED` or (build 3)
  holds a verified capability with no outcome after it. It **fails**
  when the evidence shows the run is not complete as given: a continuation
  outside the verified chain, a head anchor mismatch, any failed check, or an
  operation whose outcome the log does not settle (an honest admission by
  the gateway, or a gateway that stopped after issuing a capability, but the
  run's record is not complete). It is **not_checked** otherwise (no fresh status,
  a switched-off check, or a log that goes on after the witness's latest
  cosigned head).
- **Outage rule.** The verifier never falls back: when `--witness-url`
  cannot fetch the head or the status, the CLI exits 2 (I/O error, no
  verdict), and a refused status fails `head.witness`. The gateway, by
  contrast, goes on while the witness is down and records
  `WITNESS_UNAVAILABLE` (`missing` lists it); the heads after the last
  successful push are not cosigned, so `anchored_head` and `run_complete`
  cannot pass until the witness has cosigned the end again.
- Latest-run completeness therefore needs a fresh signed run status
  (`--witness-url`); pins and saved heads support ANCHORED, never
  `run_complete`.

**Classification evidence (per operation).** Every `operations[]` item has
`classification_evidence`: which signatures bind the decision the
operation's classification (its flag, escalation mode and fired rules) is
read from, by lifecycle state. `counts.classification_evidence` counts the
operations per class.

| `classification_evidence` | lifecycle state | bound by |
|---|---|---|
| `issuer_adapter` | executed with an EFFECT_EXECUTED entry (a confirming RECONCILED changes nothing), or only according to a RECONCILED-committed entry that carries the adapter's genuine effect receipt, bound to the consumed capability and its decision hash | the capability (issuer) and the adapter receipt, which both sign the FINAL decision hash (`op.receipts_bound`) |
| `issuer_only_reconciled` | executed only according to a RECONCILED-committed entry without an adapter receipt | the capability alone: no adapter receipt is required on that path (one that is attached is checked, `op.receipts_bound`) |
| `issuer_only_unresolved` | left `UNCERTAIN` / `RECONCILIATION_REQUIRED` after a verified capability, or (build 3) `pending` with a verified capability and no outcome after it (see below the lifecycle table) | the capability alone; whether the effect happened is unsettled |
| `issuer_only_no_effect` | a verified capability, no effect (RECONCILED `not_committed`, or refused after the capability) | the capability alone |
| `audit_only` | no verified capability (denied, blocked, refused before a capability, pending before a capability, e.g. awaiting approval), and every operation of the unbound-flags ablation | the audit entries alone (with replay, the snapshot other capabilities pin) |

The class names the strongest binding the state provides when the
operation's checks pass; an operation with failing checks is not bound by
it. When any executed operation is `issuer_only_reconciled`, `missing`
lists it ("... executed only according to a RECONCILED entry without an
adapter receipt ...: for each, no adapter receipt binds the decision it
rests on, so its classification ... rests on the capability issuer's
signature alone"). The gateway attaches the adapter's receipt to RECONCILED
when the adapter had signed an APPLIED receipt before the failure
(after_receipt_before_audit, audit_append, head_replace) and the gateway
still holds it: it is kept in memory only, so a gateway restarted on its
journal reconciles without it, and such a genuine recovery stays
`issuer_only_reconciled` (`TestFlaggedOperationRecoveryVerifies` in
`cmd/agentgate-eval`, real gateway). An operation left
unresolved after a verified capability now keeps the flag of the decision
that capability binds: `flagged` is true with the outcome unconfirmed (its
`status` is `uncertain` / `reconciliation_required`), it is counted in
`counts.flagged` and in `counts.flagged_unconfirmed`, and its
`op.outcome_resolved` warning and `missing` entry say so. (Before
2026-10-10 the flag of such an operation dropped out of the report and of
`counts.flagged`. The report format and its `format` value did not change,
so `counts.flagged` and `operations[].flagged` of reports made before and
after that date are not directly comparable: an experiment write-up that
counts flagged operations must say which build verified, and can subtract
`counts.flagged_unconfirmed` to get the old meaning.) In the unbound-flags
ablation the flag of an unresolved operation is the one the log's policy
entries state, and the texts say so instead of naming the capability.

**Lifecycle states.** Where an operation's classification is bound, and
which keys (A audit, I issuer, X adapter, P provider; "status" = a
provider-signed status observation, which the prototype's status endpoint
gives any local caller) were the smallest tested set that let an editor pass (corrected 2026-10-10: tested, not proved), in the bound design without a head
anchor (a head anchor taken after the edit point detects every row's
rewrite). Tested with real signatures on the fixture
(`internal/auditverify/lifecycle_test.go`); the compromise grid does not
contain these operators.

| state | where the flag, mode and rules are bound | keys to change them in place | keys to switch to a weaker state | what the verifier reports |
|---|---|---|---|---|
| executed, EFFECT_EXECUTED + adapter receipt | FINAL hash in the capability (I) and the adapter receipt (X); entry details, RECONCILED and CALL_RESULT `flagged` compared with the values | A+I+X in every replay setting (simulation grid; with real signatures A+I is detected, L3 "execution kept"); unbound design: A without replay | A alone: to unresolved (L1); A+status: to reconciled-only, classification unchanged (L2); A+I+status: to reconciled-only with the classification changed (L3 without replay, L4 full verifier) | `executed`, `issuer_adapter` |
| executed, RECONCILED-committed only | FINAL hash in the capability (I); RECONCILED and its call's CALL_RESULT must state the flag; when RECONCILED carries the adapter's receipt, also the receipt (X) | converting an EFFECT_EXECUTED into this state: A+I+status (P instead of status where the status endpoint is authenticated), in every verifier setting: L3 without replay; L4 under the full verifier with the snapshot forged and restated and every execution converted. The editor drops the adapter receipt: keeping the genuine one fails `op.receipts_bound` (it cites the original capability and decision, `TestReconciledAdapterReceipt`), and the receipt is not required. An operation that is genuinely in this state, `issuer_adapter` only through a receipt on its RECONCILED entry, needs only A+I: the provider's signed status is already in the log, so no new status (and no P) is needed even where the status endpoint is authenticated | A alone: to unresolved (delete the RECONCILED; the journal commit is then a warning, `TestHiddenReconciliationIsAGap`); A alone also drops the optional adapter receipt (`issuer_adapter` to `issuer_only_reconciled`) | `executed`, `issuer_only_reconciled` and a Missing entry; `issuer_adapter` when a bound adapter receipt is attached, which is weaker than `issuer_adapter` through EFFECT_EXECUTED (see the note below the table) |
| unresolved (UNCERTAIN / RECONCILIATION_REQUIRED, verified capability) | FINAL hash in the capability (I) | A+I without replay (L1b); the full verifier's replay catches the plain edit | A alone: delete the capability; accepted when the provider journal shows no commit (the operation becomes `audit_only` and its flag is no longer reported), fails `provider.matches_audit` when it shows one | `uncertain` / `reconciliation_required`, `flagged` from the capability (outcome unconfirmed), `issuer_only_unresolved`, warning, Missing entry, `run_complete` fail |
| not committed (RECONCILED `not_committed`, provider ABSENT) | FINAL hash in the capability (I) | A+I, as for unresolved (not separately tested) | faking ABSENT for a committed effect needs P and is contradicted by the provider journal or an earlier execution (`op.outcome_resolved`, `provider.matches_audit`) | `not_committed`, `issuer_only_no_effect` |
| no capability (denied, blocked, refused, pending before a capability; a pending operation that holds a capability is `issuer_only_unresolved` since build 3, see below the table) | audit entries only; with replay and `policy.snapshot_bound` the snapshot is pinned by the other operations' capabilities (I) | without replay A; with replay the snapshot must be forged and restated, which re-signs every capability and breaks every adapter receipt: A+I+X (simulation grid) or A+I+status with every execution converted (as in L4) | (already the weakest) | `audit_only` |

**Two kinds of `issuer_adapter`.** An operation is `issuer_adapter` either
through EFFECT_EXECUTED (the adapter receipt is required there: removing it
fails `op.receipts_bound`) or only through a RECONCILED-committed entry that
carries the adapter's receipt (optional there). The second kind is weaker:
the audit key alone can drop the receipt (the operation becomes
`issuer_only_reconciled`), and the audit and issuer keys together can then
change its classification without fetching any new status, because the
provider's signed status is already in the log; an authenticated status
endpoint does not change that. A write-up that counts `issuer_adapter`
operations must not count the second kind among those whose smallest tested key set is A+I+X (or
+P) to be reclassified. The gateway produces it for recoveries without a
restart after after_receipt_before_audit and audit_append (the adapter's
receipt is kept in memory only, so after a restart the same recovery is
`issuer_only_reconciled`).

**Pending with a capability (build 3).** An operation whose latest verified
capability is followed by no outcome (no EFFECT_EXECUTED, no RECONCILED, no
CALL_RESULT of scope `operation` with status `COMMITTED` or `REJECTED`, no
EFFECT_FAILED for a dispatch that sent nothing, no refusal; a PENDING status,
an EFFECT_FAILED reporting `UNCERTAIN`, AGENT_* entries and other calls'
answers settle nothing), and that is not left `UNCERTAIN` /
`RECONCILIATION_REQUIRED` by a CALL_RESULT, is never silently omitted: it is
reported `pending` with `issuer_only_unresolved`, an `op.outcome_resolved`
warning that says what the provider journal shows, a Missing entry of kind
`unresolved`, `run_complete` fail, and it is counted in `counts.unresolved`
(and, when the decision its capability binds flagged it, reported flagged
and counted in `counts.flagged_unconfirmed`). Genuine sources: a gateway
killed between the capability and the dispatch intent whose operation was
never retried (the kill suite's fresh-ID controls), a dead segment verified
alone, a live verification taken while a call is in flight. Before build 3
such an operation was `issuer_only_no_effect` with no warning and no Missing
entry. When the provider journal holds a commit for it, `provider.matches_audit`
still fails (unchanged; the gateway admitted no uncertainty), and its
message now names the capability and says that only the outcome entry is
missing (`TestPendingCapabilityIsIncomplete`).

Conflicting histories (each tested, `TestLifecycleConflictingHistories`):
an execution followed by a provider-signed ABSENT reconciliation fails
`op.outcome_resolved` and `provider.matches_audit`; a RECONCILED-committed
entry inserted before the genuine execution fails `op.single_use`; a
reconciliation carrying another operation's observation fails
`op.outcome_resolved` and `provider.matches_audit`; the same commit
reconciled twice is accepted when both records state the same flag (no
second effect is counted) and fails `op.requires_policy` when they
contradict each other; an execution restated UNCERTAIN in the same call
fails `op.outcome_resolved`, restated RECONCILIATION_REQUIRED is accepted
with a warning (still executed and `issuer_adapter`, `run_complete` fail);
removing or replacing the adapter receipt fails `op.receipts_bound`; a
reconciled commit without a verified capability fails `op.outcome_resolved`.
An adapter receipt on a RECONCILED entry (`TestReconciledAdapterReceipt`):
the operation's own genuine receipt is accepted (`issuer_adapter`), on an
entry that records the effect or confirms an execution; another
operation's genuine receipt fails `op.receipts_bound`; a receipt whose
payload was edited fails `artifact.signature` and `op.receipts_bound`.
**Dated and justified reconciliations (build 3).** Until build 2 the
verifier neither dated the status observation (one dated 2027 was accepted)
nor required a preceding unresolved status. Build 3 requires both
(`op.outcome_resolved`, §2): the observation must be dated no later than
the RECONCILED entry's time and, for a `committed` outcome, no earlier than
the capability's issue time (5 s of tolerance each; a `not_committed`
observation gets the upper bound only, see §2), and a RECONCILED entry that
records an effect needs a reason to reconcile after the capability (an
unresolved status of another call or an EFFECT_FAILED reporting UNCERTAIN
before it, another call's unresolved answer racing it, or a restart between
the capability and it). The form tested as accepted before (an observation
fetched after the run, no unresolved status) now fails
(`TestLifecycleL2ReconciledCommitClassification`,
`TestReconciledStatusDate`, `TestReconciledNeedsAReason`). What this does
not change: every record the order rule reads is signed by the audit key
alone, and the provider's status endpoint answers any local caller, so an
editor who obtains the observation while the run goes on (or appends the
RECONCILED entry at the log's end, dated after a late observation, and so
re-dates nothing; converting an execution in place needs an observation
fetched during the run, since every later entry would otherwise have to be
re-dated after it) and writes an UNCERTAIN status before it still converts
an execution with the same keys as before (A+status to keep the flag,
A+I+status to change it), where "status" now means a provider-signed status
obtained while the run went on; the lifecycle tests now model that careful
editor (observation dated at the execution), and their key sets and counts
are unchanged. The verifier still reports such a conversion and a genuine
recovery alike as `issuer_only_reconciled`. An adapter-signed
reconciliation receipt and an authenticated status endpoint would close
the path; they are not built.

**Missing.** `missing` lists the gaps of this evidence in a fixed order (a
simulation's note first, §9): no keys anchor ("a complete re-signing with
substitute keys cannot be ruled out") or, when a keys anchor was given and
does not match, a keys anchor MISMATCH (never worded as a missing anchor),
or (build 3, a run of several segments) keys anchored for the newest
segment only (`keys.anchor`, §2);
no head anchor ("a coherent rollback to an earlier signed prefix cannot be
ruled out"), a head anchor MISMATCH, an unusable witness head, or a witness
that covers only a prefix; a head anchor not shown to be fresh (pinned or
saved head, above); policy not replayed
and why; no delegation grant in flag mode; decisions without cumulative
totals; every operation left `UNCERTAIN` or `RECONCILIATION_REQUIRED`, or
(build 3) holding a verified capability with no outcome (with its
capability-bound flag when flagged); executed operations whose
classification rests on the issuer key alone; `WITNESS_UNAVAILABLE` gaps;
the unbound-flags ablation; switched-off checks. `missing_kinds` gives the
kind of each entry, in the same order: `unresolved` (an operation left
`UNCERTAIN` / `RECONCILIATION_REQUIRED`, or pending with a verified
capability and no outcome), `freshness` (the head anchor not
shown to be fresh), `issuer_only` (executed operations classified on the
issuer key alone) or `other` (everything else, a simulation's note
included). Every folder verified with a pinned or saved head lists the
freshness gap, so "the report lists a missing item" no longer singles
anything out: count by kind (the crash experiment's
`segments_with_missing_items_by_kind`).

**Assumptions.** `assumptions` lists what no evidence folder can show:
complete mediation (no bypass path), single-machine key custody, how the
policy snapshot is bound (and that a run without one is simply not replayed),
simulated providers, and (build 3) one clock: the status-date rule of
`op.outcome_resolved` compares times the provider, the capability issuer and
the audit recorder stamped, also across a restart, so components on separate
hosts whose clocks differ by more than 5 s could make it fail genuine
evidence (entry times themselves are compared only within a segment).

**Determinism.** Independent items are verified on `Options.Workers`
goroutines; results are buffered per item and applied in item order, so the
report is byte-identical for every worker count apart from `checked_at`.

## 2. Checks

Notation: *entry #n (STAGE)* is the audit line with `seq` n.
`H(label, x)` is `SHA-256(label || 0x00 || x)`. Every section states the
inputs, the predicate a passing item satisfies, and what a failure means.

### Run files

### `verifier.error`
Group: Run files · Dimension: structural · Mechanism: (always evaluated)

- Inputs: none (panic guard around the whole verification).
- Predicate: the verifier ran to completion. The item exists only when a
  panic was recovered.
- Failure: the verifier met input it could not process; the evidence cannot be
  trusted. The fuzz target `FuzzRunFiles` treats any occurrence as a bug.

### `files.present`
Group: Run files · Dimension: structural · Mechanism: files

- Inputs: `audit.jsonl`, `head.json`, `keys.json`, `run.json`,
  `provider-journal.json`.
- Predicate (per file): the file exists, is at most its size limit (256 MiB
  for `audit.jsonl`, 32 MiB for the others), parses as JSON, and is
  unambiguous: every member name appears once per object, no two names differ
  only in letter case, and names are lower case except ISO 4217 currency codes
  (three letters A-Z, e.g. `"AED"` keys of budgets and per-currency limits)
  that do not fold to a member the verifier decodes into a struct (`kid`,
  `alg`, `seq`, `pid`, `exp`, `nbf`).
- Failure: the file is missing, oversized, unreadable or ambiguous; dependent
  checks report the file as unavailable.

### `files.run_id`
Group: Run files · Dimension: structural · Mechanism: files

- Inputs: `run_id` of run.json, head.json, keys.json, the journal and every
  entry.
- Predicate: each names the run's ID (run.json's, else head.json's, else the
  first entry's).
- Failure: evidence from another run was mixed in.

### `keys.valid`
Group: Run files · Dimension: structural · Mechanism: files

- Inputs: keys.json.
- Predicate (per key): public key is standard base64 of 32 bytes; `alg` is
  empty or `Ed25519`; `role` is one of `AUDIT_LOG`, `CAPABILITY_ISSUER`,
  `SIMULATOR_PROVIDER`, `ADAPTER_MESSAGE`, `ADAPTER_DOCUMENT`,
  `ADAPTER_FINANCIAL`, `APPROVAL_AUTHORITY` (alias `DEV_APPROVAL_AUTHORITY`),
  `DELEGATION_AUTHORITY`; `kid` is 64 hex characters and unique; the audit
  key's kid is SHA-256 of its public key; exactly one `AUDIT_LOG` key. A
  non-audit kid that matches no known derivation is a warning.
- Failure: a key with an unknown role or algorithm, a malformed or duplicate
  kid, or not exactly one audit key; signatures by such keys are not trusted.

### `keys.hash`
Group: Run files · Dimension: structural · Mechanism: files

- Inputs: keys.json bytes, run.json `keys_sha256`, RUN_STARTED
  `details.keys_sha256`.
- Predicate: SHA-256 of keys.json equals both recorded values.
- Failure: the key list was replaced after the run started (or a record is
  missing).

### `files.run_record`
Group: Run files · Dimension: structural · Mechanism: files

- Inputs: run.json bytes, RUN_STARTED details, every POLICY_DECISION
  `policy_hash`.
- Predicate: SHA-256 of run.json equals RUN_STARTED `run_sha256` (older runs:
  policy hash/name, simulator origin and catalog counts equal what RUN_STARTED
  recorded); every POLICY_DECISION names run.json's policy hash.
- Failure: run.json (policy, catalog, snapshot, grant copy, identity) was
  changed after the run started. Note: this binding rests on the audit key.

### `files.continuity`
Group: Run files · Dimension: structural · Mechanism: files

- Inputs: run.json `continues` and RUN_STARTED `details.continues` of every
  segment that continues an earlier one (`{"run_id", "dir", "final_head",
  "keys_sha256"}`, optional `final_seq`; §8); the earlier segment's folder
  (`dir`, relative to this one), its run ID, the hash (and seq) of its last
  audit entry and the SHA-256 of its keys.json.
- Predicate (per continuation): both records are present, well-formed and
  equal; `dir` is a relative path to an existing folder that is not already
  part of the chain; that folder names run `run_id`, its log ends with entry
  hash `final_head` (and seq `final_seq`, when given) and its keys.json hashes
  to `keys_sha256`. Evaluated only for a run that continues an earlier
  segment (or whose RUN_STARTED says it does).
- Failure: the earlier segment is missing, was truncated, extended or
  rewritten after the restart, or its keys were replaced; or the continuation
  record was removed from run.json or differs from the signed RUN_STARTED.
  The operations that started in the missing part then fail their own checks.

### `keys.anchor`
Group: Run files · Dimension: anchored_keys · Mechanism: anchors

- Inputs: SHA-256 of keys.json; `Options.ExpectKeysSHA256` (CLI
  `--expect-keys`); a verified witness head's `keys_sha256` (`--witness`).
  For a run of several segments (§8) also the SHA-256 of every earlier
  segment's keys.json, `Options.ExpectEarlierKeysSHA256` (CLI
  `--expect-earlier-keys`), `Options.ExpectHead`, and the witness head's and
  run status's state (`head.witness`).
- Predicate: each given anchor equals SHA-256 of keys.json (of the folder
  given, the newest segment). Without any anchor the item is a warning.
  Earlier segments (build 3): their keys.json files are named only by the
  continuation record in the newest segment's RUN_STARTED entry, which its
  audit key alone signs, so the newest segment's keys anchor does not cover
  them. They are anchored when (a) every earlier segment's keys.json hashes
  to one of the fingerprints given in `ExpectEarlierKeysSHA256`; or (b) the
  newest segment's log is anchored from outside, which fixes its RUN_STARTED
  entry and, through `files.continuity`, every earlier continuation record:
  `ExpectHead` equals its last entry, or a witness head checked as an
  extension (`extension_verified`) cosigned one of its entries; or (c) the
  witness's signed run status was checked, whose `continues` must equal the
  newest segment's record (`head.witness`, continuation linkage). When pins
  are given, every one must be 64 hex characters, every earlier segment's
  keys.json must hash to one of them and every pin must match a segment of
  the chain (a pin equal to the newest segment's fingerprint is accepted);
  pins given for a run of one segment fail. When the newest segment's keys
  are anchored, no pin is given for the earlier segments and neither (b) nor
  (c) holds, the item adds a **warning** and `anchored_keys` is
  `not_checked` ("Only the newest segment's keys.json is anchored"), with
  the Missing entry "Keys anchored for the newest segment only". The verdict
  and the assurance level do not change (ANCHORED needs a head anchor, and a
  head anchor anchors the earlier segments too); the pass item says how the
  earlier segments' keys are anchored.
- Failure: these are not the keys the run started with; every signature that
  verifies against this keys.json proves nothing about the original run; or
  an earlier segment's keys.json is none of the fingerprints pinned for the
  earlier segments (an earlier segment made up or re-signed with keys of its
  own), a pin matches no segment of the chain (a pinned segment is missing),
  a pin is malformed, or pins were given for a run with no earlier segment.
  Warning: a complete re-signing with substitute keys cannot be ruled out;
  or (several segments) only the newest segment's keys are anchored.
- Tested (`TestEarlierSegmentKeysAnchor`, `TestEarlierSegmentKeyPinsRefused`):
  a restart whose segment 1 is replaced by one signed with keys of its own
  (`fixture.RestartOptions.FirstSegmentKeySeed`; the newest keys.json is
  byte-identical) verifies with the newest keys pin alone, reported as
  above, and fails `keys.anchor` with the genuine segment-1 pin and
  `head.anchor` with the genuine head pin.

### Log integrity

### `chain.entry_hash`
Group: Log integrity · Dimension: structural · Mechanism: hash-chain

- Inputs: every line of audit.jsonl.
- Predicate: the line is exactly
  `{"entry_hash":"…","signature":"…","entry":{…}}` (rebuilt byte for byte
  from its members) and `entry_hash = hex(H("AgentGate/AuditEntry/v1",
  ENTRY_JSON))` over the stored entry bytes.
- Failure: a line is unreadable or ambiguous, or an entry was modified after
  it was written.

### `chain.signature`
Group: Log integrity · Dimension: structural · Mechanism: entry-signatures

- Inputs: every entry hash and signature; the AUDIT_LOG key.
- Predicate: Ed25519 signature over `"AgentGate/AuditEntrySig/v1" || 0x00 ||
  raw32(entry_hash)` verifies with the audit key.
- Failure: the entry was written or re-hashed by someone without the audit
  key.

### `chain.links`
Group: Log integrity · Dimension: structural · Mechanism: hash-chain

- Inputs: consecutive entries.
- Predicate: `seq` starts at 1 and increases by 1; `prev_hash` is 64 zeros for
  entry #1 and the previous line's `entry_hash` otherwise.
- Failure: an entry was deleted, inserted or reordered.

### `chain.time`
Group: Log integrity · Dimension: structural · Mechanism: (always evaluated)

- Inputs: every entry `time`.
- Predicate: RFC 3339 and never earlier than the previous entry.
- Failure: a malformed or backwards timestamp.

### `head.signature`
Group: Log integrity · Dimension: structural · Mechanism: signed-head

- Inputs: head.json; the AUDIT_LOG key.
- Predicate: head.json names the audit kid and its signature over
  `"AgentGate/AuditHead/v1" 0x00 run_id 0x00 decimal(seq) 0x00 entry_hash`
  verifies.
- Failure: the checkpoint was edited or forged.

### `head.matches`
Group: Log integrity · Dimension: structural · Mechanism: signed-head

- Inputs: head.json, the last line.
- Predicate: head.json's seq and entry hash are the last entry's.
- Failure: the log was truncated, extended without the recorder, or its end
  replaced. (A coherent rollback that also restores the earlier head.json
  passes this check; only `head.anchor` detects it.)

### `head.anchor`
Group: Log integrity · Dimension: anchored_head · Mechanism: anchors

- Inputs: the last entry hash; `Options.ExpectHead` (`--expect-head`); a
  verified witness head (`--witness`, `--witness-url`); the witness's run
  status `Options.WitnessRun` (`--witness-url` only, see below).
- Predicate: a pinned head equals the last entry's hash; a witness head's
  entry #k is in the log with the cosigned hash, k is the last entry, and the
  witness checked that the head extends its earlier cosigned heads
  (`extension_verified`); when the run status was given, it names no later
  segment continuing the run (`continued_by` is empty). Without any anchor
  the item is a warning; a witness head that is a proper prefix of the log is
  a warning (the later entries are not anchored); a witness head cosigned
  without an extension proof is a warning (it could belong to a forked or
  rewritten log ending at that entry, so it anchors the keys but not the
  head). In a run of several segments (§8) the anchors apply to the newest
  segment; earlier segments are anchored through the `continues` pins of the
  segment after them.
- Withheld restart segment: after a gateway restart the run goes on in a new
  segment, which the witness registers as the continuation of the run and
  then closes the run (no later head of it is cosigned). Shown only the
  earlier folder, the verifier would fetch that run's latest cosigned head,
  genuinely its last entry, and report ANCHORED. The witness's signed run
  status (`GET /runs/{id}`, `internal/headwitness` `RunStatus`) shows the
  continuation: `continued_by` names the segment. A segment that continues
  the newest folder given is never part of the verified chain, so when the
  status names one, head.anchor **fails** (a mismatch, not a missing anchor:
  `anchored_head` is `fail` and `missing` says "Head anchor MISMATCH"). The
  status is used only when `head.witness` accepted it: signed by the
  witness key, describing the same latest head as the cosigned head given,
  and fresh (the signed-status rule under `head.witness`); an unsigned,
  tampered or stale status is a mismatch there, never a fallback to
  "not consulted". Limitation: a cosigned head saved to a file
  (`--witness FILE`, `Options.WitnessHead` alone) carries no run status, so
  a withheld later segment is then not ruled out; the passing item says so
  ("The witness's run status was not consulted").
  Measured before this check existed: `--witness-url` on the earlier folder
  alone reported ANCHORED in 20/20 custody runs, although the witness
  recorded `continued_by` in 20/20 (`docs/paper/data/revision/custody/`
  `RESULTS.md` §4); the custody runner now verifies that case with the live
  head and status (`agentgate-eval custody`, variant "continuation segment
  withheld").
- Freshness: the witness head must be the witness's LATEST cosigned head,
  fetched at verification time (`GET /runs/{id}/latest`; CLI `--witness-url`
  fetches it, `--witness FILE` must hold a copy taken just before). The
  evidence cannot show whether a cosigned head is the latest one: an older
  cosigned head whose entry ends the log (a coherent rollback to it, with
  its genuine head.json) verifies as ANCHORED. Measured in the latest custody
  run: a stale witness head accepted the coherent rollback as ANCHORED in
  20/20 runs (`docs/paper/data/revision/RESULTS_REVISION.md` §2.3,
  `custody/rollback_by_anchor.csv`). Since 2026-10-10 such a verification
  still says ANCHORED but reports `head_fresh` and `run_complete`
  `not_checked` and the `missing` entry "Head not shown to be fresh" (§1,
  `TestSavedHeadIsAnchoredButNotFresh`); only the witness's fresh signed run
  status makes `head_fresh` pass.
- Failure: the log no longer ends where the anchor says (rollback, truncation
  or rewrite); for the witness: the log is shorter than the cosigned entry,
  the cosigned entry has a different hash, or the witness's run status says
  a later segment continued the run (that segment was withheld). Warning: a
  rollback to an earlier, genuinely signed checkpoint (after the witnessed
  entry) cannot be ruled out.

### `head.witness`
Group: Log integrity · Dimension: anchored_head · Mechanism: anchors

- Inputs: `Options.WitnessHead` (the witness's cosigned head document, at most
  1 MiB; CLI `--witness FILE` or `--witness-url URL`, which fetches
  `URL/runs/{run id}/latest` from a loopback address), `Options.WitnessPublicKey`
  (`--witness-key`, from outside the folder), keys.json; with `--witness-url`
  also `Options.WitnessRun`, the witness's signed run status
  (`URL/runs/{run id}`, at most 1 MiB; a failed fetch of either answer exits
  2, never a silent fallback), and `Options.WitnessRunFetchedAt`, the time
  the CLI received it.
- Predicate: the document is unambiguous JSON of format
  `agentgate-witness-cosigned-head/v1` whose embedded head is
  `agentgate-audit-head/v1`; `witness_kid` = SHA-256 of the given witness key
  (and `witness_public_key`, when present, is that key); `witness_signature`
  verifies over `"AgentGate/WitnessCosign/v1" 0x00 run_id 0x00 keys_sha256
  0x00 audit_kid 0x00 decimal(head.seq) 0x00 head.entry_hash 0x00 head.time
  0x00 head.signature 0x00 decimal(index) 0x00 ("1"|"0" extension_verified)
  0x00 witnessed_at` (internal/headwitness `CosignMessage`); it names this run;
  the head names the registered audit kid; and when keys.json is the
  registered one, the head carries the audit key's own signature.
- Signed-status rule (a run status given with the head, `--witness-url`):
  it is unambiguous JSON of format `agentgate-witness-run-status/v2` (build
  3: a run registered with an enrollment key; `enrollment_kid` is required
  and must be 64 hex, the SHA-256 of the gateway enrollment key that signed
  the run's registration, CONTRACTS.md "Witness enrollment") or
  `agentgate-witness-run-status/v1` (earlier witnesses, or a run registered
  before enrollment; it must carry no `enrollment_kid`);
  `witness_kid` = SHA-256 of the given witness key and `witness_public_key`
  is that key; `witness_signature` verifies with it over
  `LABEL 0x00 run_id 0x00 keys_sha256 0x00
  audit_kid 0x00 audit_public_key 0x00 ("1"|"0" keys_file_verified) 0x00
  registered_at 0x00 continues.run_id 0x00 continues.final_head 0x00
  continues.keys_sha256 0x00 continued_by 0x00 decimal(latest_index) 0x00
  decimal(latest_seq) 0x00 latest_entry_hash 0x00 status_at`, followed for
  v2 by `0x00 enrollment_kid`, with LABEL `"AgentGate/WitnessRunStatus/v2"`
  for v2 and `"AgentGate/WitnessRunStatus/v1"` for v1
  (internal/headwitness `RunStatusMessage`; the `continues` fields are empty
  when absent). Because each format has its own label, `enrollment_kid`
  cannot be stripped from a v2 status (relabelled v1 it no longer verifies)
  or added to a v1 status (a v1 status carrying one is refused as
  malformed, even when the witness key signed it as a 16th field), and a v2
  status signed under the v1 label does not verify. Format v2 exists so that
  a verifier built before build 3 reports an unknown format for a status
  naming the enrollment key, rather than a signature that does not verify.
  The checked `enrollment_kid` is reported (`anchors.witness.enrollment_kid`);
  it is not compared with an enrollment key given out of band. The status is
  for this run, registers the same `keys_sha256` and
  `audit_kid` as the cosigned head, is not continued by itself; its latest
  head (`latest_index`, `latest_seq`, `latest_entry_hash`) is exactly the
  cosigned head given (a status naming another head describes another
  moment; the CLI fetches both again, up to 3 times, when the status names a
  newer head); `status_at` is not before the head's `witnessed_at`; and when
  `Options.WitnessRunFetchedAt` is set (the CLI sets it) `status_at` is
  within `MaxWitnessStatusSkew` (2 minutes) of it. The freshness bound is
  what makes the signature useful: an older genuine status of a closed run
  differs from the current one only in `continued_by` and `status_at`, so a
  replayed one would hide the continuation. An unsigned status (the earlier
  `agentgate-witness-run/v1` registration), one whose signature does not
  verify (for example with `continued_by` removed), or one that breaks any
  other part of the rule is a **mismatch**: `head.witness` fails and the
  witness anchors nothing. In a key-compromise simulation with `WITNESS`
  (§9) the status signature is accepted unverified like the cosignature;
  the other parts of the rule still apply. Without the fetch time (a caller
  of `VerifyRun` that leaves it zero; the custody runner's live anchor
  passes it since 2026-10-10) freshness is not checked; the status is then
  only ordered after the cosigned head. Its `continued_by` is judged by
  `head.anchor`.
- Continuation linkage (build 3, part of the signed-status rule): the
  status's `continues` (`run_id`, `final_head`, `keys_sha256`; all empty or
  absent counts as none) must equal the verified chain's continuation record
  of the newest segment (run.json `continues`, which `files.continuity` ties
  to RUN_STARTED; RUN_STARTED's own record when run.json has none), or both
  must be absent; and `continued_by` must not name a run of the verified
  chain (an earlier segment). The witness accepts a continuation only on top
  of the earlier run's final cosigned head and only when the segment's first
  pushed entry is a RUN_STARTED carrying the same `continues`
  (`internal/headwitness` checkContinuation, checkContinuesEntry), so its
  record is the continuation the gateway really made. A mismatch means the
  chain presented is not the one the witness saw (an earlier segment
  substituted, invented or withheld) and fails `head.witness`.
- Failure: the document (or the run status given with it) is not an
  authentic, consistent and current witness statement about this run and is
  not used as an anchor (both anchors fall back to their pins or warnings).

### Signed artifacts

### `artifact.signature`
Group: Signed artifacts · Dimension: structural · Mechanism: artifact-signatures

- Inputs: every COSE artifact in every entry; keys.json.
- Predicate: COSE_Sign1 `Tag(18)[protected bstr, {}, payload bstr, sig]`,
  deterministic decoding (no duplicate keys, no indefinite lengths), empty
  unprotected header, 64-byte signature; the protected header contains only
  labels 1 (alg = -8, EdDSA), 2 (crit, if present exactly `[-65537]`), 3
  (content type), 4 (32-byte kid) and -65537 (profile version, if present 1);
  the content type is the artifact's; the kid is in keys.json with the role
  the artifact requires; the Ed25519 signature over
  `["Signature1", protected, h'', payload]` verifies.

  | artifact | content type | role |
  |---|---|---|
  | `capability_token` | `application/agentgate-cap+cwt` | CAPABILITY_ISSUER |
  | `provider_receipt` | `application/agentgate-provider-receipt+cbor` | SIMULATOR_PROVIDER |
  | `provider_status` | `application/agentgate-provider-status+cbor` | SIMULATOR_PROVIDER |
  | `effect_receipt` | `application/agentgate-effect-receipt+cbor` | ADAPTER_* of the effect type |
  | `signed_request_state`, `signed_decision` | DEV approval types | APPROVAL_AUTHORITY |
  | `delegation_grant` | `application/agentgate-delegation+cbor` | DELEGATION_AUTHORITY |

- Failure: the artifact was altered, forged or signed by a key of the wrong
  role. On a refusal stage (MCP_REJECTED, REQUEST_REJECTED, APPROVAL_*,
  POLICY_FINAL_REFUSED, EFFECT_FAILED, CALL_RESULT, AGENT_RECEIVED) a bad
  artifact is a warning: it is evidence of what was refused, not authority.
  In a run of several segments every artifact is verified with the keys.json
  of its own segment.

### `artifact.effect_digest`
Group: Signed artifacts · Dimension: structural · Mechanism: artifact-signatures

- Inputs: `effect_cbor` artifacts; REQUEST_VALIDATED entries.
- Predicate: `hex(H("AgentGate/EffectObject/v1", effect_cbor))` equals the
  entry's `effect_digest`; the bytes decode as an effect of the entry's
  operation and effect type; every REQUEST_VALIDATED carries effect bytes.
- Failure: the action shown is not the action that was fingerprinted.

### `artifact.effect_readable`
Group: Signed artifacts · Dimension: structural · Mechanism: artifact-signatures

- Inputs: `details.effect` (the readable view) and the effect bytes.
- Predicate: every leaf present on both sides agrees (type, strings, numbers,
  booleans, byte strings as hex or base64, list lengths).
- Failure: what humans were shown differs from what was fingerprinted.

### Authorization chain

### `op.requires_validation`
Group: Authorization chain · Dimension: structural · Mechanism: bindings

- Inputs: per operation, its lines in order.
- Predicate: every POLICY_DECISION, CAPABILITY_ISSUED, EFFECT_EXECUTED and
  RECONCILED-committed entry names an operation and follows a
  REQUEST_VALIDATED of the same operation and effect digest.
- Failure: a gateway step was never checked against the schema and catalog.

### `op.requires_policy`
Group: Authorization chain · Dimension: decisions_authenticated · Mechanism: bindings

- Inputs: per capability: the latest POLICY_DECISION and POLICY_FINAL of the
  operation; per execution (EFFECT_EXECUTED, or a RECONCILED-committed entry
  that records the effect): the POLICY_FINAL whose `decision_hash` the
  consumed capability signs (`policy_decision_hash`) and the PRE decision that
  FINAL confirms, never simply the latest ones (decisions appended after the
  capability are signed only by the audit key); their
  `decision_value`/`decision_hash`, CALL_RESULT `flagged`, run.json
  `policy.escalation` and `policy_snapshot.kind`.
- Predicate: a non-denying PRE (`allow_flagged` counts as allowing) and an
  allowing FINAL for the same effect precede it; the FINAL value hashes to its
  `decision_hash` under `AgentGate/DEVFinalDecision/v1`, its field 3 is the
  hash of a logged PRE value of this operation that hashes correctly under
  `AgentGate/DEVPreDecision/v1`; both name this operation, effect type and
  policy, PRE and FINAL policy hashes are equal (version pinning); the FINAL
  shape fits the PRE outcome; and the flag, outcome, escalation mode and fired
  rule IDs stated by the entries (outcome, `decision`, `flagged`,
  `escalation`, reason rule IDs and FLAG outcomes, FINAL `flagged`,
  `human_approved`, `overlay_root`, the executing CALL_RESULT's `flagged`,
  and the recovery records' `flagged`, below) equal what the values commit
  to; a flagged decision needs run mode `flag`;
  the capability's decision is a POLICY_FINAL recorded for the operation; and
  an operation-table PRE value (`DEV_PRE`) appears only in a run that records
  neither an escalation mode nor a `content` policy snapshot.
  Decision values are closed: keys 0-9 (0-10 for the human-approved FINAL)
  have fixed meanings; keys from 10 (11) upwards are the extension range
  (the gateway uses only field 20, the delegation block, §4), covered by the
  hash but never read for the flag. A content PRE value with fields 0-6 only
  is the unbound-flags ablation's shape and fails here outside
  `Options.UnboundFlags`.
- Escalation mode against run.json (non-replay, the same comparison in both
  designs): the mode a content-policy PRE decision was made in must be
  run.json's `policy.escalation`, and a flagged decision needs mode `flag`.
  The bound design reads the mode and the flag from the decision value (bound
  into the capability; the details must also equal the value); the
  unbound-flags ablation reads them from the entry's details
  (`details.escalation`, absent = `human`; `flagged` / outcome
  `allow_flagged`), the only place its values leave them. Only where the mode
  is read from differs, so a bound-versus-unbound difference in the
  flag-binding experiment measures the decision-hash binding and not this
  comparison (`TestEscalationModeCheckIsSymmetric`). An operation-table value
  (`DEV_PRE`) has no mode in either design.
- Recovery records state the flag (2026-10-10): every RECONCILED entry with
  outcome `committed` must say `flagged=true` exactly when the decision its
  effect rests on flagged the action: for an entry that records the effect
  (no EFFECT_EXECUTED before it), the decision the consumed capability
  binds; for one that confirms an execution already recorded, that
  execution's decision. The same holds for the CALL_RESULT of the call that
  recorded a reconciled effect (the call its `call_id` names, or without call
  IDs the first CALL_RESULT after it), exactly as for an executing call, and
  (from the second 2026-10-10 change) for the CALL_RESULT of the call whose
  RECONCILED entry confirms an execution already recorded (the call its
  `call_id` names; a confirming entry without a call ID, written by
  `Composition.Reconcile`, has no CALL_RESULT). Replayed answers state it
  too: a CALL_RESULT of scope `call` that answers `COMMITTED` (the
  operation's stored result returned to an exact retry, in the same process
  or after a restart) must say `flagged=true` exactly when the decision the
  operation's effect rests on (its first execution or reconciled commit)
  flagged the action. The gateway copies the flag from the operation's
  ledger entry into all of them. The verifier reports the flag from the
  bound decision in any case; the rule keeps a recovery record or a replayed
  answer from restating the classification where only the audit key signs.
  A mismatch is a failing item of this check
  (`TestRecoveryRecordsStateTheBoundFlag`,
  `TestReplayedAndConfirmingAnswersStateTheBoundFlag`). An unresolved
  CALL_RESULT (`UNCERTAIN`, `RECONCILIATION_REQUIRED`) is not compared: a
  retry that is still unresolved is answered without the flag by the
  gateway. Neither is a call-scope refusal or a replayed `REJECTED` (no
  effect rests on a decision there; the gateway states no flag on a stored
  refusal).
- Failure: the decision the capability commits to is not the one the log
  describes (a stripped or invented flag, re-made values, a relabelled
  approval, a recovery record, reconciling call or replayed answer that drops
  or invents the flag) or cannot be opened, or a decision's mode contradicts run.json
  (a flagged decision recorded under mode `deny` in a flag-mode run is
  detected whatever keys the attacker holds: it needs mode `flag`). With
  `Options.UnboundFlags` (ablation only) the values are compared only on
  operation, effect, policy and outcome, the flag is read from the details,
  and the mode comparison above uses the details.

### `op.approval_bound`
Group: Authorization chain · Dimension: decisions_authenticated · Mechanism: bindings

- Inputs: APPROVAL_REQUESTED / APPROVAL_VERIFIED artifacts; capabilities of
  approval-gated operations (human mode).
- Predicate: the signed request and decision name this operation, effect
  digest and a logged PRE hash; the decision is APPROVED, answers that request
  (approval ID, state hash), was made inside the approval window, before the
  capability (5 s tolerance) and not followed by a refusal of the operation
  (a call-scope refusal, such as a concurrent mismatching resume refused as
  APPROVAL_CONFLICT with scope `call`, does not count); FINAL says
  `human_approved`.
- Failure: an approval-gated capability rests on no valid approval for this
  exact action.

### `op.capability_bound`
Group: Authorization chain · Dimension: decisions_authenticated · Mechanism: bindings

- Inputs: CAPABILITY_ISSUED `capability_token` (verified), the operation's
  validated request, POLICY_FINAL, POLICY_DECISION.
- Predicate: the token names this operation, effect type and adapter
  audience, the validated effect digest, `policy_decision_hash` = POLICY_FINAL
  `decision_hash`, `policy_hash` = the PRE's policy hash, the logged cti; its
  window is at most 60 s. Confirmation key (build 3): its `cnf` claim is a
  map with exactly one member, 3, a 32-byte key ID; that key ID is listed in
  keys.json (the capability's segment) with the `ADAPTER_*` role of the
  capability's effect type; CAPABILITY_ISSUED `details.confirmation_kid`,
  when logged, names the same key; and the adapter receipt of the effect
  (on EFFECT_EXECUTED, and on a RECONCILED entry that carries one) is signed
  with that key (its COSE kid; reported on the receipt's entry, only for a
  capability that passed). The gateway puts the adapter signer's key ID in
  `cnf`: the key whose proof of possession the registry demands at consume
  and the key that signs the effect receipt (`internal/devcomposition`
  issuance and dispatch). With one key per adapter role the receipt rule
  follows from the cnf rule and `artifact.signature`; it matters when
  keys.json lists several keys for one adapter role.
- Failure: the capability authorises something other than the decided
  action, or was issued to another key than the adapter of its effect type,
  or the adapter that executed is not the one it was issued to.

### `op.receipts_bound`
Group: Authorization chain · Dimension: decisions_authenticated · Mechanism: bindings

- Inputs: EFFECT_EXECUTED `provider_receipt` and `effect_receipt` (verified),
  the operation's capability; the `effect_receipt` a RECONCILED-committed
  entry carries (2026-10-10), the provider receipt its status observation
  names.
- Predicate: both receipts name this operation, effect digest and type; the
  adapter receipt cites this provider receipt (`H("AgentGate/SimulatorReceipt/v1/cose", …)`),
  the capability's cti and token hash and its policy decision hash; provider
  references agree. On RECONCILED the adapter receipt is optional (the
  gateway attaches it when the adapter signed before the failure); when
  attached, it must verify, name this operation, effect digest and type,
  report outcome `APPLIED`, cite the provider receipt the status
  observation names (`stored_simulator_receipt_object_hash`) and the
  capability's cti, token hash and policy decision hash (the FINAL decision
  the effect rests on). On an entry that records the effect (no
  EFFECT_EXECUTED before it) a bound receipt makes the operation
  `issuer_adapter` (§1) and spends its cti for the cross-operation
  `op.single_use` check; on one that confirms an execution the cti was
  already spent there.
- Failure: the execution is not tied to the capability and action it claims,
  or a RECONCILED entry carries an adapter receipt for another operation,
  capability, decision or provider receipt, or one that does not verify
  (which `artifact.signature` also reports).

### `op.single_use`
Group: Authorization chain · Dimension: structural · Mechanism: bindings

- Inputs: EFFECT_EXECUTED and RECONCILED-committed entries.
- Predicate: at most one effect per operation (a RECONCILED entry confirming
  the receipt of an EFFECT_EXECUTED is the same effect) and per capability cti.
- Failure: one authorisation produced several effects.

### `op.no_effect_when_refused`
Group: Authorization chain · Dimension: structural · Mechanism: bindings

- Inputs: per operation, refusals (MCP/REQUEST rejected, DENY, human reject,
  APPROVAL_* errors, FINAL refused, CALL_RESULT denied/refused unless it
  reports `UNCERTAIN` or `RECONCILIATION_REQUIRED`) and later effects. An
  MCP_REJECTED, REQUEST_REJECTED, APPROVAL_CONFLICT or CALL_RESULT with
  `details.scope` = `call` refused one request only (a malformed call, the
  operation ID reused with other content, or a resume whose approval does
  not match the pending action, possibly while the operation itself was
  running) and is not a refusal of the operation: it neither stops the
  operation here nor voids its approval (`op.approval_bound`), and the
  report keeps the operation's status (a pending operation stays
  `pending`).
- Predicate: an effect after a refusal follows a newer FINAL and a newer,
  bound capability.
- Failure: an effect happened although the operation was stopped.

### Policy and delegation

### `policy.snapshot_bound`
Group: Policy and delegation · Dimension: policy_replayed · Mechanism: bindings

- Inputs: run.json `policy_snapshot` (§3) as the replay reads it, its
  `name`, `version`, `organization_name`, `rules`, `hash_domain` and
  `policy_hash`; run.json `policy.hash`; the policy-hash claim (-70009) of
  every capability that verifies; the policy hash of every decision value
  that opens (PRE field 5, FINAL field 6); run.json `catalog`; the
  `registry_snapshot_object_hash` of every validated effect.
- Predicate: the content policy hash recomputed from the snapshot (§3,
  "Recomputing the policy hash") equals every capability's policy-hash claim,
  every decision value's policy hash, and the snapshot's `policy_hash` and
  run.json's `policy.hash` when present; the recipe's members are present and
  the shingle hash label is the gateway's
  (`AgentGate/ConfidentialShingle/v1`, which the hash does not cover). The
  values hashed are exactly those the replay uses (limits, currencies,
  `max_recipients`, mode, `deny_zero_amount`, shingle words and hashes).
  Catalog facts: run.json's `catalog` recomputes (§3, "Catalog commitment")
  to the catalog commitment every validated effect carries, and the
  snapshot's documents (blob digest -> classification) and recipients (ID ->
  external) are the catalog's. Evaluated whenever the snapshot is replayable
  or of kind `content`, or the run shows the revision's gateway (keys.json
  lists a `DELEGATION_AUTHORITY` key, the run records a grant, or a decision
  value names one); such a run must record a usable snapshot and a catalog.
- Failure: the snapshot the replay would use is not the policy the
  capabilities were issued under (an audit-key holder rewrote a limit, the
  mode, a shingle or a rule), a member was removed so it cannot be
  recomputed, or the catalog facts (the classification of a message
  attachment, which the effect names only by digest) were changed. Not
  evaluated for a run that records no snapshot and shows no sign of the
  revision's gateway (older runs, the operation table): `policy_replayed` is
  then `not_checked`, never `pass`. Limit: the snapshot is bound to the policy
  the issuer signed, not to the policy the organisation intended; and removing
  the whole snapshot from an older-format run cannot be told apart from a run
  that never had one. This check also carries the refusal of a missing or
  unusable snapshot in a revision run: with it switched off (the
  `no-snapshot-bound-only` configuration of `agentgate-eval compromise`), an
  audit-key holder who deletes the snapshot switches the replay off, and the
  run is reported VERIFIED/CONSISTENT with `policy_replayed` `not_checked`.
  The evaluation's forging attacker keeps a valid snapshot (§9), so that
  configuration measures a valid-snapshot forger; one who deletes the
  snapshot reaches the `no-replay` outcome.

### `policy.replay`
Group: Policy and delegation · Dimension: policy_replayed · Mechanism: bindings

- Inputs: run.json `policy_snapshot` (§3), the run's delegation grant and
  walk (§4), every POLICY_DECISION with its decision value and details, the
  effect bytes of the operation's validated request.
- Predicate (per content-policy decision): re-evaluating the rules below on
  the canonical effect gives exactly the logged PRE outcome
  (`ALLOW_BASE`/`REQUIRE_APPROVAL`/`DENY`), flag, escalation mode, set of fired
  rule IDs and each reason's effective outcome, in both the decision value and
  the details; and the effect's catalog facts (recipient `external` flags,
  document classifications, attachment digests) agree with the snapshot.
  - Every firing rule is reported; the most restrictive wins (DENY >
    escalated > ALLOW). ESCALATE produces FLAG (mode flag), REQUIRE_APPROVAL
    (mode human, also an empty mode) or DENY (mode deny).
  - Messages: MSG-HIDDEN-EXTERNAL (DENY, external BCC), MSG-CONFIDENTIAL-OUT
    (DENY, confidential/restricted attachment and any external recipient),
    MSG-EXTERNAL (ESCALATE, external To/CC), MSG-RESTRICTED-ATTACH
    (ESCALATE, restricted attachment, all internal), MSG-BULK (ESCALATE, more
    than `max_recipients`), MSG-CONFIDENTIAL-TEXT (DENY with any external
    recipient, else ESCALATE: the subject, a line break and the body together
    contain a shingle whose hash the snapshot lists, after the normalization
    of §3, which removes punctuation and symbols), MSG-INTERNAL (ALLOW, only
    when nothing else fired).
  - Documents: DOC-RESTRICTED (DENY), DOC-CONFIDENTIAL-OUT (DENY),
    DOC-CONFIDENTIAL (ESCALATE), DOC-INTERNAL-OUT (ESCALATE),
    DOC-DOWNLOAD-OUT (ESCALATE, download by an external recipient of a
    non-public document), DOC-PUBLIC / DOC-INTERNAL (ALLOW, only when nothing
    else fired).
  - Financial: FIN-CURRENCY (DENY, currency not in `allowed_currencies`),
    FIN-ZERO (DENY, amount 0; only when the snapshot says
    `deny_zero_amount`), FIN-HARD-LIMIT (DENY, amount > hard limit of its
    currency), FIN-APPROVAL-LIMIT (ESCALATE, auto < amount ≤ hard), FIN-AUTO
    (ALLOW, only when nothing else fired). Both limits are inclusive; no
    exchange rate is applied. With per-currency limits a currency outside them
    has no limits (only FIN-CURRENCY, and FIN-ZERO, fire); with the single
    pre-revision pair the limits apply in every currency.
  - Delegation (only for decisions after the DELEGATION_GRANTED entry), all
    DENY and reported in addition to the content rules: DEL-SCOPE (effect type,
    a recipient or the payee not in the grant), DEL-EXPIRED (decided outside
    `[nbf, exp]`), DEL-REVOKED (a DELEGATION_REVOKED precedes the decision),
    DEL-BUDGET (currency not in `budgets`, or the decision's lower bound
    (`delegation.accounting`) + this amount exceeds the budget), DEL-COUNT
    (lower bound + 1 exceeds `max_counts` of the effect type). Where the log
    cannot decide a delegation rule (a decision within 1 s of a window edge,
    or a budget that only the upper bound would exceed), the rule is accepted
    whether or not it fired. When the run records a grant
    that does not verify, every DEL-* rule is accepted either way
    (`delegation.grant` fails instead).
  - Operation-table decisions (`DEV_PRE`) have no content rules. In a run
    whose run.json records an escalation mode or a `content` policy snapshot
    the gateway never makes one, so such a value fails this check (it would
    otherwise escape the replay). In any other run it is counted as not
    replayed: the dimension is then `not_checked` and `missing` says how many
    decisions were skipped, never `pass`.
- Failure: the logged decision does not follow from the recorded policy and
  effect: a dropped or invented rule, a wrong outcome or flag, or a decision
  made under other parameters than the snapshot. Not evaluated (dimension
  `not_checked`, entry in `missing`) when run.json has no snapshot or it lacks
  `max_recipients` or currency limits (in a revision run that is a
  `policy.snapshot_bound` failure). So with `policy.snapshot_bound` switched
  off, deleting the snapshot switches this replay off: an audit-key holder
  who removes `policy_snapshot` from run.json (and restates `run_sha256`)
  gets VERIFIED / CONSISTENT with `policy_replayed` `not_checked`, not a
  failure. Trust: the parameters it replays are the
  ones `policy.snapshot_bound` ties to the issuer-signed policy hash; without
  that check (an ablation) they rest on RUN_STARTED `run_sha256`, i.e. on the
  audit key alone.

### `delegation.grant`
Group: Policy and delegation · Dimension: delegation_respected · Mechanism: bindings

- Inputs: the first DELEGATION_GRANTED entry and its `delegation_grant`
  artifact; run.json `delegation.signed_grant` (or `delegation_grant`);
  run.json `identity`; the grant ID and grant hash every decision under the
  grant records; when no grant is recorded at all, the delegation block
  (field 20) of every logged PRE and FINAL decision value and the roles in
  keys.json.
- Predicate: the artifact verifies (DELEGATION_AUTHORITY) and decodes as a
  version-1 grant with an ID and `nbf ≤ exp`; it names the run's tenant and
  agent; run.json's copy is byte-identical; the entry's and every decision's
  `grant_id` is the grant's and their `grant_hash` is one of its accepted
  hash: `hex(H("AgentGate/DelegationGrant/v1/body", payload))`, the body hash
  of the signed grant (`devcomposition.DelegationGrantHash`).
- Failure: autonomous actions are not tied to an authentic grant (forged,
  altered, for another agent, or cited wrongly). A run.json copy without the
  log entry also fails. A run that records no grant fails when a decision
  value names one (those values are bound into capabilities, so the audit key
  alone cannot remove the block) or when keys.json lists a
  DELEGATION_AUTHORITY key: the grant was removed from the evidence. Only
  when neither points to a grant is the dimension `not_checked` ("the run
  records no delegation grant").

### `delegation.window`
Group: Policy and delegation · Dimension: delegation_respected · Mechanism: bindings

- Inputs: grant `nbf`/`exp`; entry times of allowing POLICY_DECISIONs, FINAL
  allows and CAPABILITY_ISSUED entries under the grant; allowing decisions
  recorded before the grant.
- Predicate: each lies within `[nbf − 1 s, exp + 1 s]` (unix seconds of the
  entry time); no action was allowed before the grant was recorded.
- Failure: an action was authorised outside the delegation's validity.

### `delegation.scope`
Group: Policy and delegation · Dimension: delegation_respected · Mechanism: bindings

- Inputs: the effect of every operation executed (EFFECT_EXECUTED or
  RECONCILED committed) under the grant.
- Predicate: its effect type, every recipient (to, cc, bcc, document
  recipients) and its payee are listed in the grant, and the effect's
  principal is the grant's delegate.
- Failure: an executed action was outside the delegation.

### `delegation.budget`
Group: Policy and delegation · Dimension: delegation_respected · Mechanism: bindings

- Inputs: the committed totals recomputed from the executed operations under
  the grant (amount per currency, count per effect type).
- Predicate: every committed currency has a budget and its total ≤ the
  budget; every count ≤ `max_counts` of its effect type (an effect type
  without an entry is unlimited).
- Failure: the autonomous actions together exceeded what was delegated
  (whatever the gateway logged).

### `delegation.accounting`
Group: Policy and delegation · Dimension: delegation_respected · Mechanism: bindings

- Inputs: per decision under the grant: `cumulative_before` /
  `cumulative_after` from the decision value's delegation block (field 20,
  keys 3 / 4) and, when logged, from `details.delegation`; every *hold* (the
  reservation an allowing decision made) of the other operations and how it
  ended (§4, "The walk").
- Interval (independent of the order concurrent calls were logged in): a
  decision checked the totals after its call's REQUEST_VALIDATED entry was
  written and before its POLICY_DECISION entry was; a hold was reserved
  before its own POLICY_DECISION entry was written; a release happened after
  the operation's previous entry and before the CALL_RESULT that answers it.
  So another operation's hold *certainly* counts when its POLICY_DECISION
  precedes the decision's REQUEST_VALIDATED and it cannot have been released
  before the decision; it *possibly* counts when its REQUEST_VALIDATED
  precedes the decision's POLICY_DECISION and it was not certainly released
  before. lower = Σ certain holds, upper = Σ possible holds. For calls that
  do not overlap, lower = upper: the exact total the gateway must state
  (committed plus every open reservation, UNCERTAIN operations included).
  An approval nobody resumed may be given back silently 60 s or more after
  its decision (§7), so it counts only as possible after that.
- Predicate: for every total the decision states (the gateway states the
  totals of the action's own currency and effect type) the logged `before`
  lies in [lower, upper]; `after` = `before` + this action (its amount in its
  currency, one count of its effect type) for an allowing decision, and
  `before` or `before` + this action for a denial; decision value and details
  agree. An allowing decision of an operation that still holds the
  reservation an earlier decision made (a retry or resume decided again) is
  compared with that earlier decision's interval, because the gateway then
  answers with the totals of the first decision (and the replay's DEL-BUDGET
  / DEL-COUNT use the same interval); across a restart (§8) such a
  re-decision is accepted anywhere from 0 to the widest bound, because the
  restored reservation carries the totals of the moment it was restored.
  Overspending is caught independently of these intervals by
  `delegation.budget` (final committed totals).
- Failure: the gateway's own budget accounting is wrong or was edited.
  Omitted (with an entry in `missing`) when no decision records totals.

### `delegation.revocation`
Group: Policy and delegation · Dimension: delegation_respected · Mechanism: bindings

- Inputs: DELEGATION_REVOKED entries (`details.grant_id`); allowing decisions,
  FINAL allows and capabilities after the first revocation.
- Predicate: a revocation names the run's grant and follows it; after it,
  no decision under the grant allows anything and no FINAL allow or
  capability is issued (an effect of a capability issued before the
  revocation may still complete).
- Failure: something was authorised under a revoked grant.

### Provider reconciliation

### `provider.signature`
Group: Provider reconciliation · Dimension: provider_reconciled · Mechanism: provider-reconciliation

- Inputs: every journal entry of provider-journal.json.
- Predicate: `signed_receipt` is base64 of a provider receipt that verifies
  (SIMULATOR_PROVIDER) and whose `commit_seq` is the listed one.
- Failure: the provider's journal was altered.

### `provider.state_chain`
Group: Provider reconciliation · Dimension: provider_reconciled · Mechanism: provider-reconciliation

- Inputs: the journal receipts in order; journal header.
- Predicate: commits are numbered 1..n without gaps; each starts from the
  state the previous one ended in; outcomes are APPLIED; the header's
  `commit_seq` and `state_hash` match the last commit.
- Failure: commits were removed, reordered or invented.

### `provider.matches_audit`
Group: Provider reconciliation · Dimension: provider_reconciled · Mechanism: provider-reconciliation

- Inputs: journal receipts; EFFECT_EXECUTED `provider_receipt`s;
  RECONCILED entries' status observations.
- Predicate: every journal receipt is claimed by exactly one operation: byte
  identical to one EFFECT_EXECUTED receipt, or named (by
  `H("AgentGate/SimulatorReceipt/v1/cose", receipt)` =
  `stored_simulator_receipt_object_hash`) by a RECONCILED-committed entry of
  an operation that did not also execute it; every EFFECT_EXECUTED receipt
  with outcome APPLIED and every RECONCILED-committed receipt hash is in the
  journal; no RECONCILED-not_committed operation has a journal receipt. A
  journal receipt of an operation the gateway itself reported `UNCERTAIN` or
  `RECONCILIATION_REQUIRED` after a verified capability is not a failure here
  (`op.outcome_resolved` reports it). A journal receipt of an operation that
  holds a verified capability but no outcome entry at all (build 3: pending
  with a capability) still fails, because the gateway admitted no
  uncertainty; the message names the capability and says that only the
  outcome entry is missing (a dead segment verified without its
  continuation, or an execution removed).
- Failure: the provider performed an effect with no authorisation trail, a
  recorded effect never happened at the provider, or one effect is claimed
  twice.

### `op.outcome_resolved`
Group: Provider reconciliation · Dimension: provider_reconciled · Mechanism: provider-reconciliation

- Inputs: CALL_RESULT `details.status` (`REJECTED`, `PENDING`, `COMMITTED`,
  `UNCERTAIN`, `RECONCILIATION_REQUIRED`; older lower-case values are
  ignored); RECONCILED entries (component `gateway/reconciler`, outcome
  `committed` | `not_committed`, artifact `provider_status`, optionally
  `provider_receipt`); the provider journal.
- Predicate:
  - `COMMITTED` follows an execution or reconciled commit of the operation;
  - `REJECTED` is not reported for a call that recorded an execution;
  - a CALL_RESULT with `details.scope` = `call` answers that call only and
    leaves the operation as it was: a refusal of a conflicting request
    (`operation_id_conflict`: the same operation ID with other content, or a
    conflicting resume), or the operation's stored result replayed to a
    retry (`replayed`). It is accepted wherever it appears, because under
    concurrency it can be logged before or between another call's
    EFFECT_EXECUTED and that call's own CALL_RESULT, and it is never treated
    as the operation's refusal (`op.no_effect_when_refused`), as the
    executing call's answer (its `flagged`, `op.requires_policy`) or as a
    release of the operation's reservation (§4). What it states must hold: a
    `COMMITTED` answer needs an execution or reconciled commit of the
    operation, and a `REJECTED` answer with `dispatched` true cannot be given
    for an operation that was executed;
  - the executing call: the CALL_RESULT whose `details.call_id` the
    execution names. The gateway puts the `call_id` of the call on
    EFFECT_EXECUTED and on RECONCILED (when the reconciliation ran inside an
    MCP call; `Composition.Reconcile` outside any call records none), as
    well as on CALL_RESULT and MCP_REJECTED, so the answer is matched even
    when other calls of the operation are logged in between. For an
    execution without `call_id` (older runs) the positional rule applies:
    the first CALL_RESULT after it that is not another call's refusal;
  - `UNCERTAIN` is not reported for a call that recorded an execution;
  - a RECONCILED entry carries a verified provider status observation for this
    operation, effect digest and effect type (and the validated request),
    status APPLIED for `committed` (naming a stored receipt; an attached
    receipt must be that receipt) or ABSENT for `not_committed` (and the log
    recorded no execution), after a verified capability;
  - **status date (build 3)**: the observation's `observed_at` (Unix seconds,
    the provider's clock) is set, is at most the RECONCILED entry time + 5 s
    (both outcomes), and for `committed` is at least the capability's `iat`
    - 5 s (`clockToleranceSeconds`, the tolerance the approval checks use;
    the simulator's reading may be up to 2 s uncertain). This compares
    times stamped by three components (provider, issuer, recorder), also
    across a gateway restart, so it assumes they read one machine's clock
    (the report's "One clock" assumption); on separate hosts whose clocks
    differ by more than 5 s it could fail genuine evidence. Why the bounds
    hold on one machine: the gateway refuses an observation dated more than
    2 s ahead of its own clock (`internal/adapters` `SignedStatusVerifier`)
    and writes RECONCILED only after accepting one, and its recorder never
    dates an entry before the previous one, so the upper bound cannot fire
    on a genuine run; an APPLIED observation follows the provider's commit,
    which follows the dispatch, the adapter refuses a capability more than
    5 s before its `nbf` (= `iat`), and the provider's clock never goes back
    (the in-process simulator stops signing; the provider process clamps
    forward to its last reading), so the lower bound cannot fire on a
    genuine `committed`. The lower bound is not applied to `not_committed`:
    after a lost request or an expired dispatch lease the provider never saw
    the dispatch, so an OS clock stepped back by more than 5 s between the
    capability and the status query would date a genuine ABSENT answer
    before the capability (a false alarm); the bound would add little there
    (an editor can fetch an ABSENT answer within the tolerance before the
    capability anyway, and a commit it hides is still in the provider
    journal, `provider.matches_audit`). The lower bound needs a verified
    capability (without one the entry fails anyway);
  - **status order (build 3)**: a RECONCILED `committed` entry that records
    the effect (no execution of this operation with the receipt it names is
    logged before it) needs a reason to reconcile after the capability the
    effect rests on (the operation's latest capability): (a) an unresolved
    state of the operation logged before it, that is a CALL_RESULT of scope
    `operation` (or none) reporting `UNCERTAIN` or `RECONCILIATION_REQUIRED`,
    or an EFFECT_FAILED reporting `UNCERTAIN` (outcome `uncertain` or
    `details.status` `UNCERTAIN`); or (b) such a CALL_RESULT of another call
    (a different, non-empty `call_id`) logged after it (the gateway appends a
    call's CALL_RESULT after it releases the operation, so a concurrent
    exact retry can reconcile before the failed call's answer is written);
    or (c) a gateway restart between the capability and the entry (the entry
    is in a later segment than the capability: the process that dispatched
    died before it could record the outcome, as the kill suite's
    after_provider_response, after_receipt and before_effect_executed points
    leave it). An unresolved state with the same non-empty `call_id` as the
    RECONCILED entry never counts (build 3, round-5 fix): a call either
    dispatches or reconciles (`operationLifecycle.call`), so the reconciling
    call cannot have answered UNCERTAIN for a dispatch of its own; the
    gateway puts no `call_id` on EFFECT_FAILED, so this concerns
    CALL_RESULT. These are exactly the gateway's paths: it reconciles only an
    operation whose ledger status is `UNCERTAIN` or
    `RECONCILIATION_REQUIRED` (`operationLifecycle.reconcile`), which it
    sets only by answering that status (CALL_RESULT, preceded by an
    EFFECT_FAILED `UNCERTAIN` when the provider's answer was lost) or by
    replaying a journal with a dispatch intent and no outcome after a
    restart. Not covered: a confirming RECONCILED (the execution's adapter
    receipt already binds the decision and no second effect is counted) and
    `not_committed` (it records no effect). A RECONCILED entry that breaks
    only the date or the order rule fails here but still records what the
    provider signed, so the checks that read the effect still judge it.
  An operation whose last `UNCERTAIN` / `RECONCILIATION_REQUIRED` status is
  followed by no execution and no RECONCILED entry is a **warning**, which
  says whether the provider journal shows a commit for it; it appears in
  `missing` and the operation's status is `uncertain` /
  `reconciliation_required`. When a verified capability preceded it and the
  decision that capability binds flagged the action, the warning and the
  `missing` entry say so, and the operation is reported `flagged` with the
  outcome unconfirmed (`classification_evidence` `issuer_only_unresolved`,
  §1). An operation whose latest verified capability is followed by no
  outcome at all (§1, "Pending with a capability"; build 3) is a warning in
  the same way, with a Missing entry of kind `unresolved`. Still not
  required: an adapter receipt on the reconciliation path (when one is
  attached, `op.receipts_bound` checks it; leaving it out is accepted), so a
  commit settled by reconciliation rests on the audit and issuer keys plus
  the provider's signed status, and the order rule adds no key (every record
  it reads is signed by the audit key alone; §1, "Dated and justified
  reconciliations").
- Failure: a reported status contradicts the evidence, a reconciliation
  rests on nothing the provider signed, its observation is dated outside the
  run, or nothing in the log gives a reason to reconcile. Warning: the
  outcome of an operation is not settled by the audit log.

## 3. Policy snapshot format (run.json `policy_snapshot`)

The gateway writes `devcomposition.PolicySnapshot` (see its Go doc comment in
`internal/devcomposition/policy.go`, which also gives the recipe for
recomputing `policy_hash` from the snapshot). The verifier reads it
tolerantly: the gateway's member name first, a few aliases after it; unknown
members are ignored. `policy.snapshot` is accepted instead of
`policy_snapshot`.

| member (aliases) | content | required |
|---|---|---|
| `escalation` (`escalation_mode`) | `flag` \| `human` \| `deny`; falls back to run.json `policy.escalation`, then `human` | no |
| `max_recipients` | integer ≥ 1 (MSG-BULK) | yes |
| `currency_limits` (`per_currency_limits`, `limits`) | `[{"currency": "AED", "auto_minor": 500000, "hard_minor": 5000000}, …]` or an object keyed by currency; limit aliases `auto`, `auto_approve_limit_minor`, `auto_limit_minor` / `hard`, `hard_limit_minor` | yes, unless the global pair below is given |
| `allowed_currencies` (`currencies`) | list; defaults to the currencies of `currency_limits` | no |
| `auto_approve_limit_minor` (`auto_limit_minor`), `hard_limit_minor` | the single pre-revision limit pair, used when `currency_limits` is empty; it applies in every currency | no |
| `deny_zero_amount` | `true` when rule FIN-ZERO exists | no (absent: no FIN-ZERO) |
| `recipients` (`catalog.recipients`, run.json `catalog.recipients`) | `[{"principal_id" (`id`), "external": bool, …}]` | no |
| `documents` (…, run.json `catalog.documents`) | `[{"blob_sha256" (`sha256`), "classification", "filename", …}]` | no |
| `payee_ids` (`payees`, …, run.json `catalog.payees`) | list of IDs or `[{"id"}]` | no |
| `confidential_text` (`confidential_shingles`) | `{"shingle_words": 12, "hash_domain": "AgentGate/ConfidentialShingle/v1", "normalization": "…", "shingle_hashes": [hex…]}` (aliases `words`, `label`, `hashes`); or a plain list under `confidential_shingle_hashes` / `shingle_hashes` | no (absent: MSG-CONFIDENTIAL-TEXT never fires) |

Shingles (the snapshot's `normalization` member states the same in words):
the text of a message is its subject, a line break and its body. It is
normalized in this order: every Unicode punctuation (category P) and symbol
(category S) character is removed (Go `unicode.IsPunct` / `unicode.IsSymbol`,
replaced by nothing, so "2,150" becomes "2150"), NFC, lower case (Go
`strings.ToLower`), and the words are the runs of characters between Unicode
white space (Go `strings.Fields`); line breaks, repeated spaces and
punctuation do not matter. A shingle is `shingle_words` consecutive words
joined by single spaces; its hash is `hex(SHA-256(hash_domain || 0x00 ||
shingle))`. Only confidential or restricted text documents contribute
shingles, normalized the same way. Evidence of the earlier gateway, whose
`normalization` statement does not mention punctuation or symbols, is
replayed with its rule (NFC, lower case, white space only; punctuation part
of a word). This is verbatim-copy detection, not information-flow control:
a paraphrase or a changed word evades it. Note: the `normalization`
statement is not covered by the policy hash (open issue for the gateway: a
normalization version in field 12 would bind it).

**Recomputing the policy hash** (`policy.snapshot_bound`; re-implemented in
`internal/auditverify/binding.go` from the recipe in the `PolicySnapshot`
doc comment, not imported). `policy_hash = hex(H("AgentGate/DEVContentPolicy/v1",
CBOR))` where CBOR is the RFC 8949 core deterministic encoding of the
integer-keyed map

```
0: 1, 1: name, 2: version,
3: [{0: id, 1: effect_type, 2: outcome, 3: description} for each rule of "rules", in order],
4: auto_approve_limit_minor, 5: hard_limit_minor        (both 0 with per-currency limits),
6: allowed currencies (sorted), 7: max_recipients, 8: organization_name,
9: escalation                                           (only when not "human"),
10: [[currency, auto_minor, hard_minor], ...]           (only with per-currency limits; currency order),
11: true                                                (only with deny_zero_amount),
12: {0: shingle_words, 1: [shingle hash bytes, sorted]} (only with confidential_text)
```

The limits, currencies, mode, `max_recipients`, `deny_zero_amount` and
shingles are taken from what the replay parsed (whichever spelling it read),
so the hash covers exactly what the replay uses.

**Catalog commitment** (the demo's `registry_snapshot_object_hash`, carried
by every canonical effect): `H("AgentGate/DemoRegistrySnapshot/v1", CBOR)`
over the array of rows `["recipient", id, address, external]` for each
run.json `catalog.recipients` entry, then `["payee", id, display]` for each
payee, then `["document", filename, classification, sha256]` for each
document, in run.json order. The effect digest is signed through the
capability, both receipts and the provider journal, so a recomputed
commitment that matches ties every catalog fact (in particular the
classification of message attachments, which the policy hash does not cover)
to the run.

## 4. Delegation conventions the verifier reads

- Grant: COSE_Sign1 (`application/agentgate-delegation+cbor`, role
  DELEGATION_AUTHORITY) over the canonical CBOR of
  `devcomposition.DelegationGrant` (text keys `v`, `grant_id`, `issuer`,
  `tenant_id`, `delegate`, `purpose`, `effect_types`, `recipients`, `payees`,
  `budgets`, `max_counts`, `nbf`, `exp`). Grant hash:
  `H("AgentGate/DelegationGrant/v1/body", payload)`.
- DELEGATION_GRANTED entry: artifact `delegation_grant`; details `grant_id`,
  `grant_hash` and the grant's parameters. run.json: `"delegation":
  {"grant_id", "grant_hash", "authority_kid", "signed_grant": "<std base64
  COSE>"}`; the policy snapshot repeats the grant under `delegation`.
- DELEGATION_REVOKED entry: `details.grant_id` (or
  `details.delegation.grant_id`), recorded before the gateway revokes.
- Decisions under the grant: every PRE and FINAL value carries field 20, the
  delegation block `{0: grant_id (text), 1: grant_hash (32 bytes),
  2: evaluated_at (unix seconds), 3: cumulative_before, 4: cumulative_after}`,
  each cumulative being `{0: {currency: minor units}, 1: {effect type:
  count}}` for the action's own currency and effect type. A gateway may also
  log `details.delegation` = `{"grant_id", "grant_hash", "cumulative_before",
  "cumulative_after"}` with cumulatives `{"amounts": {…}, "counts": {…}}`;
  the demo's gateway does not.
- The walk: an allowing decision (ALLOW_BASE or REQUIRE_APPROVAL) reserves
  its action (a hold); EFFECT_EXECUTED or RECONCILED committed commits it
  (never released afterwards); POLICY_FINAL_REFUSED,
  APPROVAL_REJECTED/EXPIRED/CONFLICT, RECONCILED not_committed, an
  EFFECT_FAILED that is not `uncertain`, a CALL_RESULT that is denied,
  refused or `REJECTED`, and a re-decision that now denies release it,
  except a CALL_RESULT or an APPROVAL_CONFLICT with `details.scope` = `call`
  (a refusal of that call only, for example a resume whose approval does not
  match the pending action: the operation stays PENDING and keeps its
  reservation, and a matching resume may still complete it; the gateway
  releases only with an entry of scope `operation`). An entry without a
  scope (older runs) counts as a release. A release happened after the operation's
  previous entry (not a call-scope refusal) and before the next CALL_RESULT
  that answers the operation (at or after the releasing entry). `UNCERTAIN`
  (an EFFECT_FAILED with outcome `uncertain`, a CALL_RESULT with status
  UNCERTAIN) keeps it reserved until a RECONCILED entry settles it. The
  gateway also gives back, without a log entry, the reservation of an
  approval nobody resumed once its approval can no longer be used (the
  approval window plus 60 s, §7); such a hold counts only as possible from 60
  s after its decision until a POLICY_FINAL allows it. At a restart (§8) a
  hold still open at the end of its segment stays reserved when the
  operation was last reported UNCERTAIN or RECONCILIATION_REQUIRED (or
  commits later), is released when it was a pending approval, and may or
  may not have been restored otherwise. `delegation.accounting` derives each
  decision's interval from the holds (§2).

## 5. Options and CLI

| option | CLI | effect |
|---|---|---|
| `ExpectKeysSHA256` | `--expect-keys HEX` | keys anchor (pin) of the folder given (the newest segment) |
| `ExpectEarlierKeysSHA256` | `--expect-earlier-keys HEX[,HEX...]` (repeatable) | keys anchor (pins) of the earlier segments of a restarted run, each taken when that segment started; any order; every earlier segment must match one and each one a segment of the chain (`keys.anchor`, §2); the CLI refuses a value that is not 64 hex characters (exit 2) |
| `ExpectHead` | `--expect-head HEX` | head anchor (pin) |
| `WitnessHead`, `WitnessPublicKey` | `--witness FILE --witness-key KEY` (64 hex or base64) | keys and head anchors from the witness; a saved head carries no run status, so a withheld later segment is not ruled out (`head.anchor`) |
| `WitnessHead`, `WitnessRun`, `WitnessRunFetchedAt` | `--witness-url URL` | fetches the witness's latest cosigned head for this run (`GET URL/runs/{run id}/latest`) and its signed run status (`GET URL/runs/{run id}`, `continued_by`) now, loopback addresses only, no redirects, instead of a file (both again, up to 3 times, when the status names a newer head); a failed fetch exits 2; an unsigned, invalid or stale status fails `head.witness` (signed-status rule, §2). The human output adds a `witness run status` line under Trust anchors. Only this route can make `head_fresh` and `run_complete` pass (§1) |
| `Workers` | `--workers N` | parallelism; the report does not change |
| `AssumeCompromised` | `--assume-compromised ROLE[,ROLE...]` | key-compromise SIMULATION, not a verification (§9) |
| `UnboundFlags` | — | evaluation of the flag-binding ablation only |
| `DisableMechanisms`, `DisableChecks` | — | evaluation ablations only; caps assurance at CONSISTENT |

The run folder given is the newest segment of a run; earlier segments are
found through `continues` (§8). Report members added for them: `segments`
(each folder's run ID, entries, last entry and keys fingerprint, oldest
first); `anchors.earlier_segments`, `anchors.expected_earlier_keys_sha256`,
`anchors.earlier_keys_anchored` and `anchors.earlier_keys_anchored_by`
(`pins`, `head_pin`, `witness_head` or `witness_run_status`; build 3, all
omitted for a run of one folder without earlier pins);
`anchors.witness.enrollment_kid` (build 3, when the checked run status names
one); `simulation` and the `SIMULATED_` assurance prefix for §9. When only
the newest segment's keys are anchored, the human output's verdict note says
"Keys anchored for the newest segment only".

Mechanisms (for the ablation in `cmd/agentgate-eval`): files, hash-chain,
entry-signatures, signed-head, artifact-signatures, bindings (op.* except
op.outcome_resolved, policy.snapshot_bound, policy.replay, delegation.*),
provider-reconciliation
(provider.*, op.outcome_resolved), anchors (keys.anchor, head.anchor,
head.witness). `chain.time` and `verifier.error` are always evaluated.

Exit status of the CLI: 0 verified (warnings allowed), 1 failed, 2 usage or
I/O error. The human output ends with the verdict (a `VERIFIED` verdict is
followed by the reminder that it means only that no check failed), an
`ASSURANCE:` line, the nine dimensions (the seven check-based ones, then
`head_fresh` and `run_complete`) and the `Missing:` list, each entry of the
kinds `unresolved`, `freshness` and `issuer_only` tagged with its kind. Its
operations list marks a flagged operation left unresolved as "flagged for
audit, outcome unconfirmed", an operation whose classification rests on the
issuer key alone as "classification: issuer key only", an operation settled
by a RECONCILED entry as "reconciled", and ends with the counts per
classification evidence. Report members added on 2026-10-10:
`dimensions.head_fresh`, `dimensions.run_complete`,
`operations[].classification_evidence`, `counts.flagged_unconfirmed`,
`counts.classification_evidence`, `missing_kinds`; `counts.flagged` (and
`operations[].flagged`) now also count the flagged operations left
unresolved, with no change to the report's `format` value (§1).

## 6. Robustness

- Size limits: audit.jsonl 256 MiB, other evidence files 32 MiB, witness head
  1 MiB; CBOR decoding refuses duplicate map keys and indefinite lengths and
  limits nesting (32), arrays and maps (100,000 elements); JSON nesting is
  limited to 64 levels.
- Fuzz targets (`internal/auditverify/fuzz_test.go`): `FuzzParseLogLine`
  (a line is accepted only in the recorder's exact form; no panic),
  `FuzzCOSE` (artifact, payload, decision-value and effect decoding never
  panics; nothing that fails to parse ever verifies), `FuzzRunFiles` (any
  replacement of one evidence file or of the witness head yields a report,
  never an error or `verifier.error`). Crashers found are kept under
  `testdata/fuzz/` and run with every `go test`.
- Refusal-site mutation (`internal/auditverify/tools/refusalmutation`):
  deletes one `X.fail(...)` call at a time (replacing it by an assignment that
  keeps its arguments in use), runs the verifier test suites with
  `go test -overlay` and reports the kill score and the surviving sites.
  `-skip PATTERN` leaves tests out of every run (passed to `go test -skip`
  and recorded as `skipped_tests`): run it once with the full suite and once
  with the four tests written after earlier survivors were seen left out,
  `-skip "^(TestRefusalSites|TestDelegationRefusalSites|TestRestartProviderJournalCutBack|TestRestartContinuationRemovedFromRunRecord)$"`,
  and report both scores.

Since that build, three `fail` sites were added on 2026-10-10, so the
verifier now has 142 refusal sites; the derived dimensions, the
classification evidence and `missing_kinds` add none:

- the recovery-record flag rule (§2 `op.requires_policy`,
  `checkReconciledFlag` in `operations.go`), killed by
  `TestRecoveryRecordsStateTheBoundFlag` (and one case of
  `TestLifecycleConflictingHistories`);
- the adapter receipt on RECONCILED (§2 `op.receipts_bound`,
  `checkReconciledReceipt` in `operations.go`), killed only by
  `TestReconciledAdapterReceipt`;
- the replayed-answer flag rule (§2 `op.requires_policy`,
  `checkReplayedFlag` in `operations.go`), killed only by
  `TestReplayedAndConfirmingAnswersStateTheBoundFlag`. The same change also
  makes the existing executing-call flag site (`checkCallResultFlag`) apply
  to the call whose RECONCILED entry confirms an execution; that condition
  adds no site, and the same test is the only one that fails when it is
  removed.

(Corrected 2026-10-10 after the build-2 robustness run: the recovery-record
flag site, `operations.go:498`, is also killed by
`TestUnboundFlagsTextsNameTheLogNotTheCapability`, so it survives none of
the suite variants; `docs/paper/data/build2/robustness/RESULTS.md` §7.1.)

**Build 3 (round 5, 2026-10-20)** adds three `fail` sites, so the verifier
has **145** (`refusalmutation -list`; build 2: 142):

- the confirmed signer of an adapter receipt (§2 `op.capability_bound`,
  `checkConfirmedSigner` in `operations.go`, called from `checkReceipts` and
  `checkReconciledReceipt`), killed by `TestCapabilityConfirmationKey`;
- the status date and order failure of a RECONCILED entry that is otherwise
  usable (§2 `op.outcome_resolved`, `checkReconciled` in `reconcile.go`),
  killed by `TestReconciledStatusDate`, `TestReconciledNeedsAReason`,
  `TestLifecycleL2ReconciledCommitClassification`,
  `TestRound4ValidlySignedInconsistentFields` and
  `TestRestartSegmentStartingBeforeThePreviousEndVerifies`;
- the provider commit of an operation pending with a capability (§2
  `provider.matches_audit`, `provider.go`; split from the existing "no
  authorization trail" site, same verdict, its own wording), killed by
  `TestPendingCapabilityIsIncomplete`.

The new conditions (`problem` lines and branch conditions: the cnf shape,
listing, role and logged-kid rules; the status date bounds, tolerance and
undated case; the order rule's three reasons and their limits; the pending
rule and each entry that settles an outcome; the continuation linkage; the
segments note in `missing`) were each mutated by hand (37 mutants: the
condition removed, a boundary swapped, or the call deleted) and the suite
(`./internal/auditverify/`, `./cmd/agentgate-verify/`) run against each:
**37/37 killed**, after one test case was added for the cnf shape (a second
member next to the genuine key ID), which survived the first run. All of
these tests were written together with the code they test, so they are
post-hoc in the sense below: a build-3 refusal-site score without them
must add `TestReconciledStatusDate|TestReconciledNeedsAReason|TestPendingCapabilityIsIncomplete|TestCapabilityConfirmationKey|TestWitnessStatusContinuationLinkage|TestEarlierSegmentKeysAnchor|TestEarlierSegmentKeyPinsRefused|TestWitnessStatusEnrollmentKID|TestExpectEarlierKeysFlag`
to the skip pattern (the round-4 tests they changed,
`TestRound4ValidlySignedInconsistentFields`,
`TestLifecycleL2ReconciledCommitClassification` and
`TestRestartSegmentStartingBeforeThePreviousEndVerifies`, now also kill
build-3 sites). The table below is build 2's; build 3's numbers come with
its frozen robustness run.

**Round-5 review fixes (2026-10-20, later)** add five `fail` sites, all in
`keys.anchor` (`earlierPinsMatch` in `segments.go`: a malformed earlier
pin, earlier pins for a run of one segment, an earlier segment's keys.json
unavailable, an earlier segment matching no pin, a pin matching no
segment), so the verifier has **150** (`refusalmutation -list`). Run with
`-file segments.go`, all seven `segments.go` sites (the five new ones and
two `files.continuity` sites) are killed (7/7). The new conditions without
a `fail` call were mutated by hand through `go test -overlay` (14 mutants:
the `committed`-only lower bound, the same-call rule, each half of the
EFFECT_FAILED unresolved test, the RUN_STARTED fallback of the continuation
linkage, the v2 label, the v1-only label, the refusal of a v1 status that
carries `enrollment_kid`, the reported enrollment key, the v2
`enrollment_kid` shape, each of the three newest-log anchors and the
newest-only flag): **14/14 killed** by `TestReconciledStatusDate`,
`TestReconciledNeedsAReason`, `TestWitnessStatusContinuationLinkage`,
`TestWitnessStatusEnrollmentKID` and `TestEarlierSegmentKeysAnchor` (the
five run-status mutants were re-run on the strict v1/v2 rule, each format
under its own label, after the witness-enrollment fixes were merged; all
five are killed by `TestWitnessStatusEnrollmentKID`). These
tests are post-hoc too (listed in the pattern above);
`TestEarlierSegmentsNeedTheHeadAnchor` was replaced by
`TestEarlierSegmentKeysAnchor`.

These tests were written together with the site or condition they kill, so
for a build from 2026-10-10 on they are post-hoc for the refusal-site score
in the same sense as the four above: the honest run leaves out all seven,
`-skip "^(TestRefusalSites|TestDelegationRefusalSites|TestRestartProviderJournalCutBack|TestRestartContinuationRemovedFromRunRecord|TestRecoveryRecordsStateTheBoundFlag|TestReconciledAdapterReceipt|TestReplayedAndConfirmingAnswersStateTheBoundFlag)$"`,
and the report names the pattern used. `TestLifecycleConflictingHistories`
was written in the same change as the recovery-record rule and also kills
that site; a stricter variant adds it to the pattern (it kills older sites
too, so say which variant a score comes from). `TestCallScopeReplayedAnswers`
(older) now states the flag on its replayed commit of the flagged payment,
as the gateway does; it does not kill the replay site. (The end-to-end
tests of a flagged recovery through the real gateway,
`TestFlaggedOperationRecoveryVerifies` in `cmd/agentgate-eval`, and of a
flagged replay in the same process and after a restart,
`TestReplayedCommittedAnswersKeepTheFlag` in `internal/devcomposition`, are
in packages the tool does not run.)

Current results (updated 2026-10-10): frozen build 2 (commit `86643d7`,
built 2026-10-10 02:24:44 UTC; Windows 10, Go 1.26.6, local runs; regression
evidence, not a research result). Build 1's values (2026-10-08) are in
brackets. Full detail and raw data:
`docs/paper/data/build2/robustness/RESULTS.md`; build 1:
`docs/paper/data/revision/robustness/RESULTS.md`. Every score below names
its skip pattern.

| measurement | result |
|---|---|
| refusal-site mutation, full suite | 142 sites, 142 killed: kill score 1.000 [139/139] |
| **without the seven post-hoc tests** (the seven-test pattern above; the honest score) | **56/142 killed, kill score 0.394** (86 survived: 44 executed but unchecked, 42 never executed) |
| without build 1's four post-hoc tests | 58/142, 0.408 [51/139, 0.367] |
| without the seven and `TestLifecycleConflictingHistories` (the stricter variant) | 53/142, 0.373 |
| without only `TestRefusalSites` and `TestDelegationRefusalSites` | 60/142, 0.423 [53/139, 0.381] |
| without only the two restart tests | 140/142, 0.986 [137/139, 0.986] (`provider.go:150` journal cut back, `segments.go:308` continuation removed from run.json) |
| fuzzing (120 s per run, 12 workers, loaded machine; counts are lower bounds) | `FuzzParseLogLine` 15,781,402 executions, `FuzzCOSE` 18,383,289, `FuzzRunFiles` 13,758 over three runs; 0 crashers and 0 property failures in 34,178,449 executions [40,542,369] |
| statement coverage, `internal/auditverify` | suite 3,703/4,085 (90.6 %); without the seven post-hoc tests 3,571 (87.4 %); suite or fuzz inputs 3,761 (92.1 %) [3,525/3,919, 89.9 %] |
| checks with no site killed without the seven post-hoc tests | 7 of 38 (`artifact.effect_digest`, `artifact.effect_readable`, `delegation.window`, `files.run_id`, `head.signature`, `op.requires_validation`, `provider.signature`) [9 of 38 with the four-test pattern] |
| held-out mutation operators (frozen before the run; `docs/paper/data/build2/heldout/RESULTS.md`) | full suite 144/358 = 0.402 (delete a finding 63/164, swap a boundary 52/123, force an equality 29/71); without the four post-hoc tests 127/358 = 0.355 |

The honest score is 0.394: it leaves out every test written after the
surviving sites of an earlier round were seen, or together with the new
sites. Five of its kills come from tests written on 2026-10-10 outside the
seven-test pattern, after build 1's survivor list was published
(`TestLifecycleConflictingHistories` 3, `TestTimeStepsInsideASegment` 1,
and the recovery-record site above). It shows that attacks are detected, not
that every refusal is needed (a survivor usually means another check catches
the same tampering). 1.000 shows that every refusal site is now exercised,
not that the suite is complete against other kinds of mutation: against the
held-out operators the full suite kills 0.40.

Two `fail` sites pass a variable check ID and are filed under "id" by the
mutation tool: `provider.go:60` (the missing provider journal failing the
three `provider.*` checks) and `verify.go:783` (the missing audit.jsonl
failing every log check).

The witness code is measured: `head.witness` (`witness.go:214`, through which
every signed-status rule reports) and the withheld-segment site in
`head.anchor` are killed in all six suite variants by tests that are not
post-hoc (`TestWitnessRoleUnderSimulation`,
`TestWitnessStatusDetectsWithheldSegment`). The individual signed-status
rules are `problem` lines; the operator does not delete them one by one.

### Refusal conditions never executed

A refusal condition is a line that calls `fail` or `warn` or appends to
`problems`/`warnings`. Of 313 in build 2 (142 fail, 7 warn, 164 problem;
build 1: 299), **47 are executed by neither the test suite nor any fuzz
input** (build 1: 44), all `problem` lines. Each feeds a `fail` call that
other inputs do reach, so every check can fail; these particular reasons for
failing are untested. By file: `operations.go` 21 (4 of them new in
`checkReconciledReceipt`), `replay.go` 6, `delegation.go` 6, `segments.go`
6, `reconcile.go` 3, `verify.go` 2, `decisions.go`, `provider.go` and
`witness.go` 1 each. The full list with build 2's line numbers is
`docs/paper/data/build2/robustness/RESULTS.md` section 3
(`refusal_conditions.{json,csv}` in the same folder).

## 7. Limits the evidence and the checks do not cover

Stated so that no check result is read as more than it shows.

- **Pending approvals across a restart.** The approval authority keeps its
  pending requests in memory only. After a gateway restart on its operation
  journal a pending approval cannot be resumed (an exact retry starts a fresh
  approval request), and its delegation reservation is not restored. The log
  shows APPROVAL_REQUESTED without a decision; the verifier keeps that
  reservation open (§4), which can only widen `delegation.accounting`'s
  interval.
- **Abandoned approvals.** The gateway releases the reservation of an
  approval nobody resumed after the approval TTL (at most 120 s) plus 60 s,
  counted from PRE; nothing is logged for it (§4).
- **Revocation across a restart.** `Composition.RevokeDelegation` journals
  the revocation (record `delegation_revoked`, fsynced) before it takes
  effect, and the replay revokes the grant again, so a revoked grant stays
  revoked after a restart. The audit log's DELEGATION_REVOKED entry is what
  the verifier reads; the journal is operational state, not evidence.
- **head_replace is emulated in the demo.** The fault point head_replace
  (EFFECT_EXECUTED written, signed head not replaced) is real only with an
  audit sink that implements `devcomposition.HeadReplaceFaultSink`. The
  demo's sink does not (internal/audit has no per-entry "skip the head"
  write), so the experiment writes the entry and the head, then treats the
  step as failed: the gateway reports RECONCILIATION_REQUIRED, but the
  evidence on disk has a complete head. Results for that fault point show
  the status handling, not a torn head on disk.
- **Witness registration rests on the gateway's enrollment key, on one OS
  account (build 3; first come, first served until build 2).** Until build 2
  the witness bound a run ID to the first keys.json fingerprint registered
  for it and did not authenticate who registered (a false continuation
  registered first was verified ANCHORED, a build-2 result). Since build 3 it
  registers a run or a continuation only when the request is signed by a
  gateway enrollment key it was started with, a continuation only with the
  key that registered the run it continues (internal/headwitness/enrollment.go,
  CONTRACTS.md "Witness enrollment"), so a process without that key cannot
  take a run ID first or substitute a continuation; the demo also pins the
  witness key. The remaining risk: any process of the same OS user can read
  the enrollment key file and register like the gateway (the enrollment key
  and both pins are trust-on-first-use per custody folder). A verifier that
  uses `--witness` therefore trusts that the registration came from a holder
  of the enrollment key the run status names (`enrollment_kid`, reported as
  `anchors.witness.enrollment_kid`, shape-checked only, not compared with a
  key given out of band), not that the genuine gateway produced the run. If
  its registration fails, the demo refuses to start; it never runs
  unwitnessed silently.
- **Withheld segments need the live witness.** Only the witness's run status
  (`continued_by`, read by `--witness-url`) shows that a run went on in a
  later restart segment. The status is signed by the witness and must be
  current (signed within 2 minutes of the fetch), so whoever answers in the
  witness's place cannot strip `continued_by` or replay an older status
  without the witness key; it is as trustworthy as that key and the two
  machines' clocks (one machine here). A cosigned head saved to a file does
  not carry it, and pins taken when the first segment stopped
  (`--expect-keys`, `--expect-head`) do not show it either. Only the run's
  real final head (the newest segment's) or the live status detects the
  omission (`head.anchor`). A caller of `VerifyRun` that gives the status
  without `WitnessRunFetchedAt` gets no freshness check.
- **A keys pin of the newest segment does not anchor the earlier ones
  (found in round 5; reported since build 3, and closed when they are
  pinned).** `--expect-keys` covers the newest segment's keys.json; every
  earlier segment, keys included, is reached through the continuation record
  in the newest segment's RUN_STARTED, which its audit key alone signs. An
  editor holding that audit key can therefore present a made-up earlier
  segment signed with keys of its own (issuer and adapter keys included),
  move operations into it and re-chain the newest log; this also turns a
  run of one segment into a run of two. With `--expect-keys` alone such a
  folder still verifies (tested, `TestEarlierSegmentKeysAnchor`), but
  `keys.anchor` warns, `anchored_keys` is `not_checked` and Missing says
  "Keys anchored for the newest segment only", so the keys anchor of such a
  run is never reported as holding. It is ruled out (and `anchored_keys`
  passes) by pins of the earlier segments' keys taken when each started
  (`--expect-earlier-keys`; the made-up segment then fails `keys.anchor`), a
  pinned head of the newest segment, a witness head checked as an extension,
  or the witness's run status (continuation linkage, `head.witness`).
  Results stated for a keys anchor hold for a run of several segments only
  when `anchored_keys` passes, that is with one of these.
- **The status date assumes one clock (build 3).** Entry times are compared
  only within a segment, but `op.outcome_resolved` compares a provider
  status observation's time with the RECONCILED entry's time and, for a
  `committed` outcome, with its capability's issue time, which may lie in an
  earlier segment. It assumes that the provider, the capability issuer and
  the audit recorder read one machine's clock (5 s of tolerance); with
  separate hosts whose clocks differ by more than that, genuine evidence
  could fail (a false alarm, not a missed attack). On one machine the bounds
  cannot fire on a genuine run (§2); the `not_committed` lower bound, which
  an OS clock stepped back by more than 5 s could have made fire, is not
  applied.
- **Snapshot binding.** `policy.snapshot_bound` ties the replayed policy to
  the policy hash the capability issuer signed, not to the policy the
  organisation intended; and in a run that shows no sign of the revision's
  gateway, a removed snapshot cannot be told apart from one that never
  existed (`policy_replayed` is then `not_checked`).
- **Revocation under concurrency.** `delegation.revocation` and DEL-REVOKED
  place a decision after a revocation by log order. The gateway records
  DELEGATION_REVOKED before it revokes, so a decision logged shortly after
  the entry by a call that was already running may genuinely have been made
  before the ledger revoked. Not observed in the experiments (no revocation
  ran concurrently with agent calls).
- **The reconciliation path rests on the issuer key.** A commit settled by
  reconciliation (RECONCILED `committed` without EFFECT_EXECUTED) needs no
  adapter receipt. Since build 3 its status observation must be dated inside
  the run and an unresolved status (or a restart) must precede it, but the
  status endpoint answers any local caller and the unresolved status is
  signed by the audit key alone, so neither rule adds a key. So whoever holds
  the audit and issuer keys and obtains a provider-signed APPLIED status for
  an operation while the run goes on (or appends the RECONCILED entry at the
  log's end, after a late observation) can restate an executed operation as
  reconciled-only and change its classification: tested with real fixture
  signatures (in the careful form since build 3), accepted without
  replay for strip-flag, invent-flag and change-rules (L3) and under the full
  verifier with the snapshot forged and restated and every execution
  converted (L4). In the compromise grid's no-replay comparison the bound
  design's gain on this path is therefore A -> A+I, not A -> A+I+X: of the
  twelve no-replay cells where the designs differed (those three operators x
  {A, A+I} x anchors {none, keys}), the six A+I cells no longer differ when
  this path is open, and the six A-only cells remain. The verifier reports
  every such operation (`issuer_only_reconciled`, §1). An adapter receipt
  the RECONCILED entry carries is checked and, when bound, makes the
  operation `issuer_adapter`, but it is not required (the editor simply
  leaves it out), so this does not close the path; closing it needs an
  adapter-signed reconciliation receipt that the verifier requires, and an
  authenticated status endpoint (gateway work).
- **A flag lost by a recovering gateway fails; the gateway keeps it.** Until
  the 2026-10-10 gateway fix, the dispatch-intent journal record carried no
  flag and the flag returned only from the operation's later "recorded"
  record, so after a restart between the two the gateway reconciled a
  flagged operation without its flag (RECONCILED and the retry's
  CALL_RESULT said `flagged=false`; the OS-level crash suite saw it in 20 of
  its 40 committed flagged cells). The recovery-flag rule (§2
  `op.requires_policy`) reports such evidence as a failure; the verifier
  before 2026-10-10 accepted it without a warning while reporting the
  operation flagged. The gateway now journals the flag with the dispatch
  intent: `TestFlaggedOperationRecoveryVerifies` (`cmd/agentgate-eval`)
  runs a flagged payment through provider_response_lost, head_replace,
  after_receipt_before_audit and audit_append with no restart, a restart on
  the journal, and a restart on a journal cut after the dispatch intent, and
  every folder verifies ANCHORED; with the gateway's restore removed, the
  cut-journal cases fail `op.requires_policy`. Results from the frozen build
  (before the fix) keep the flag-loss behaviour. A second path lost the flag
  until the later 2026-10-10 fix: an exact retry of a committed flagged
  operation in the same process was answered from the coordinator's store,
  and its replayed CALL_RESULT (scope `call`) said nothing about the flag;
  the verifier did not compare call-scope answers and accepted it. The
  gateway now copies the ledger's flag onto every committed answer
  (`TestReplayedCommittedAnswersKeepTheFlag`, `internal/devcomposition`) and
  the verifier fails a replayed `COMMITTED` answer that drops or invents the
  flag (§2 `op.requires_policy`). Evidence from builds before that fix fails
  this rule wherever a flagged operation was retried in the same process
  after it committed.
- **REJECTED is final per gateway journal, not across a lost journal
  write.** A REJECTED answer with `dispatched` false says that nothing was
  sent; it does not say that no capability was consumed
  (`aborted_before_send` consumes it). When the gateway could not journal
  the outcome (a journal write failure) and is restarted, it may not know
  the operation and may run the same operation ID again with a new decision
  and capability; the verifier accepts that history (an effect after a
  refusal needs a newer FINAL and capability, `op.no_effect_when_refused`,
  and it has them) and reports the later commit (OS-level crash suite,
  journal write failure cell).
- **A lagging head.json fails closed.** head.json reverted to the previous
  genuine head while the log keeps a later, genuinely signed entry (a
  power-loss stand-in) fails `head.matches` in every later verification,
  although nothing was tampered with; the gateway's restart reads the final
  head from the log and goes on. The verifier does not tell a lagging head
  from a substituted one.
- **A whole deleted operation.** An audit-key holder can remove every entry
  of an operation that left no provider effect and no reservation (for
  example a denied request) and re-chain the log; only a head anchor detects
  it (the simulation equivalence test, "deleted denial").

## 8. Runs across a gateway restart (segments)

A restarted gateway cannot reopen its audit log: it opens a new evidence
folder (a segment) with new per-run keys, on the same operation journal and
provider. The new segment's run.json and its signed RUN_STARTED entry record
`"continues": {"run_id", "dir", "final_head", "keys_sha256"}` (`dir`
relative to the new folder, slash-separated; `final_seq` optional;
`internal/audit/continuation.go`). `VerifyRun` is given the newest segment
and follows the chain back (at most 64 segments, no loops):

- per segment: `files.*`, `keys.*`, `files.run_record`, `chain.*`,
  `head.signature`, `head.matches`, the artifacts (with that segment's
  keys.json) and `policy.snapshot_bound` / `policy.replay` (with that
  segment's run.json); file-level messages start with "Segment k (run …)",
  entry labels with "segment k entry #n";
- `files.continuity` ties each segment to the previous one's last entry and
  keys (§2), so the earlier segments are anchored by whatever anchors the
  newest one's log: the continuation record is in the newest segment's
  RUN_STARTED, which only its audit key signs. A pinned head (or a witness
  head checked as an extension) fixes that entry, and the witness's run
  status must register the same continuation (build 3, `head.witness`). A
  keys pin of the newest segment alone does not: an editor who holds its
  audit key could rewrite its RUN_STARTED to continue a made-up earlier
  segment with keys of its own and move operations there. Since build 3 the
  earlier segments' keys can be pinned too (`--expect-earlier-keys`, one
  fingerprint per earlier segment, taken when it started), and without such
  pins or an anchor of the newest log `keys.anchor` warns and
  `anchored_keys` is `not_checked` for a run of several segments (§2,
  `keys.anchor`; tested with a made-up segment 1, `TestEarlierSegmentKeysAnchor`);
- on one combined view of all segments in order: the operations (a
  capability or execution in an earlier segment, a replayed COMMITTED answer,
  a reconciliation after the restart), the delegation walk (the totals the
  restored ledger states; the grant is recorded again in every segment and
  must be the same signed grant), and the provider journal (each segment's
  journal is checked on its own; when both segments list the same provider
  key and name the same simulator (a provider that outlived the gateway), the
  later journal must start with every receipt of the earlier one; a provider
  that restarted with the gateway (a new key, as the demo's in-process
  simulator does) keeps a history of its own; the receipts of all journals
  are matched with the combined log);
- the anchors (`--expect-keys`, `--expect-head`, the witness head) belong to
  the newest segment; `--expect-earlier-keys` pins the earlier segments'
  keys. With a witness the demo registers each segment as the
  continuation of the run before it (`POST /runs` with `continues`), and the
  witness then closes the earlier run (its run status names the segment in
  `continued_by`). Given the witness's run status of the folder presented
  (`--witness-url`), `head.anchor` fails when it names a later segment: the
  folder presented is not the newest one, and the run went on in a segment
  that was withheld (§2, `head.anchor`).

Verified alone, an earlier segment is a complete run whose unfinished
operations are warnings (`UNCERTAIN`), never failures. Verified alone
without its `continues` record, a later segment would fail (this was the
cause of the 100/140 false alarms of the crash experiment). Checked on real
gateway evidence: the continuation segment of the demo self-test's restart
check (`internal/demo/segment.go`, a provider restarted with the gateway)
verifies as one run (34 checks passed, `files.continuity` included), where
the verifier without segments failed it (`op.outcome_resolved`).

## 9. Key-compromise simulation (`Options.AssumeCompromised`)

Purpose: measure what an attacker holding the signing keys of a set of
roles K could make the verifier accept (review comment 1, oracle
`docs/paper/oracle/`), without ever signing anything or handling a private
key. Under the standard assumption that Ed25519 signatures are
existentially unforgeable (EUF-CMA), a signature cannot be produced without
the key and can trivially be produced with it, so "the attacker holds K" is
modelled by accepting every signature attributed to a role in K without
verifying it. Everything else runs exactly as in a real verification:
parsing, every hash, the chain links, key roles and kids, every
cross-artifact binding, the policy replay, the delegation walk, the provider
journal and the anchors. A mutant only edits content and recomputes hashes
(`fixture.RewriteWithoutKey`, `fixture.EditCOSEPayload`,
`fixture.ReplaceKeysWithoutSigning`).

| role name | signatures accepted unverified |
|---|---|
| `AUDIT_LOG` | `chain.signature` (every entry), `head.signature`, the audit signature of the head inside a witness document |
| `CAPABILITY_ISSUER` | `capability_token` |
| `ADAPTER` | `effect_receipt` (ADAPTER_MESSAGE, ADAPTER_DOCUMENT, ADAPTER_FINANCIAL) |
| `SIMULATOR_PROVIDER` | `provider_receipt`, `provider_status`, the provider journal (`provider.signature`) |
| `DELEGATION_AUTHORITY` | `delegation_grant` |
| `APPROVAL_AUTHORITY` | `signed_request_state`, `signed_decision` (alias DEV_APPROVAL_AUTHORITY) |
| `WITNESS` | the witness cosignature and the signature of the witness's run status (`head.witness`) |

Names are case-insensitive; any other name makes `VerifyRun` return an error
(CLI exit 2). The kid must still be listed in keys.json with the role the
artifact requires. The replacement-key scenario ("all keys substituted") is
every role plus a keys.json whose public keys the mutator replaced: only the
keys anchor, or a head anchor (RUN_STARTED records the keys fingerprint),
catches it (`TestReplacementKeysNeedAnAnchor`).

Labelling: `Report.Simulation` = `{"assume_compromised": [...], "note":
"SIMULATION, NOT A VERIFICATION: ..."}`; `assurance` carries the prefix
`SIMULATED_` (`SIMULATED_FAILED`, `SIMULATED_CONSISTENT`,
`SIMULATED_ANCHORED`; `auditverify.AssuranceLevel` strips it); the note is
the first `missing` entry and an assumption; the pass line of every
signature check that skipped a signature says `SIMULATED: ...`; the CLI
prints the note under the header and a SIMULATION line above the verdict.
`verdict` stays VERIFIED/FAILED, so FAILED still means "detected even by an
attacker holding K".

Validation: `TestSimulationAgreesWithRealAuditKeyResigning` applies 10
audit-key edits (strip/invent flag, relabelled approval, appended decisions,
forged delegation totals, hidden reconciliation, misreported status, deleted
denial, edited readable view, and a raised limit in the run.json snapshot,
re-signed through RUN_STARTED) plus an unedited control to a fixture twice: re-signed with the fixture's real audit key, and left
unsigned under `AssumeCompromised=[AUDIT_LOG]`. Under every anchor condition
(none, keys, head, both) the two give the same verdict, assurance level and
failing checks with the same number of findings (44/44 cells).
`TestEachRoleUnderSimulation` shows for every key role an edit only that
role's signature protects (accepted with the role, `artifact.signature` /
`chain.signature` fails without it) and an edit another check still
catches.

### Mutation engine and the compromise runner

`internal/evalattack` writes the mutants for the simulation and
`agentgate-eval compromise` verifies them (results under
`docs/paper/data/revision/compromise/`). The engine edits content and
recomputes hashes only; it never signs and never reads, exports or generates
a private key. Every hash an edit changes is carried into everything that
names it (decision values, capability claims, effect receipts, approval
artifacts, provider receipts and the provider journal, entry details and
effect digests), each COSE envelope keeping its old signature bytes, so a
mutant is accepted only if the roles whose payloads changed are assumed
compromised.

- Operators: strip-flag, invent-flag, change-rules, change-escalation,
  swap-decisions (verbatim transplant), change-amount (the effect, its digest,
  the re-derived decision, the delegation totals of the target and of every
  later decision in the currency, and DEL-BUDGET of a later denial that the
  smaller total no longer exceeds), relabel-approved (the confirmed PRE and
  FINAL, and the whole approval round removed: first-round decision and
  validation, APPROVAL_*, HUMAN_DECISION, the approval_required answer and
  the resumed proposal). A consequence the evidence cannot follow (a denial
  that would now allow, an approval request the forged policy would not have
  made) is listed in `Mutant.Unrepaired`, never hidden.
- Snapshot variants: `plain` (the snapshot is left alone); `forge-snapshot`
  (one policy parameter rewritten so that the forged decision replays: the
  automatic limit raised to the target amount for strip-flag and
  relabel-approved, lowered below it for invent-flag, `max_recipients`
  lowered below the recipient count for change-rules; every other decision it
  reclassifies relabelled; the recorded policy hash kept, which
  `policy.snapshot_bound` refuses); `forge-restate` (as forge-snapshot, plus
  the policy hash recomputed from the forged snapshot with the gateway's
  recipe and restated in run.json, RUN_STARTED, every POLICY_DECISION, every
  decision value and capability claim, hence every decision hash, capability,
  effect receipt and approval artifact). change-escalation, swap-decisions,
  change-amount, and change-rules on a single-recipient message have no
  valid snapshot lever (not applicable).
- Key sets: none, audit, issuer, adapter, provider, delegation,
  audit+issuer, audit+issuer+adapter, audit+issuer+adapter+provider,
  audit+issuer+adapter+approval (restating the hash in a human-mode run
  reaches every signed approval request and decision), all-stolen,
  all-replaced (keys.json public keys substituted).
- Verifier configurations: `full`; `no-replay` (`policy.replay` off: a
  classification that cannot be replayed); `no-replay-no-snapshot`;
  `no-snapshot-bound-only` (`policy.snapshot_bound` off: the snapshot
  protected by the audit key only, see that check's limit). In
  `no-snapshot-bound-only`, deleting the snapshot switches the replay off:
  the run verifies CONSISTENT with `policy_replayed` `not_checked`, so an
  attacker who deletes the snapshot reaches the `no-replay` outcome. The
  runner's forging attacker keeps a valid snapshot, so its
  `no-snapshot-bound-only` cells measure a valid-snapshot forger only, not a
  snapshot deleter. A cell is
  detected only if every applicable variant is detected (the strongest
  attacker); the unmutated base runs are verified as clean controls.
