# Archive versions

Each archive version belongs to one frozen build of the six programs. Only
the newest version is distributed with the submission; the data of the
earlier builds are inside it (`docs/paper/data/revision/` for build 1,
`docs/paper/data/build2/` for build 2) so that every changed number can be
traced (`EXPECTED_TABLES.md`, "Version crosswalk, builds 1-3";
`SUPPLEMENTARY.md` S17).

## Version 4: build 3, documents only (2026-10-28)

- Same six binaries and the same data as version 3 (manifest SHA-256
  `0c436fc9...6968eb`); no experiment was rerun and no number changed.
- The paper's Section V letters changed in round 7 (Lessons for Designers
  moved to V-G; process kills, policy misuse, verifier tests and cost are
  now V-C to V-F). `EXPECTED_TABLES.md`, `SUPPLEMENTARY.md`,
  `REPRODUCIBILITY.md`, `regenerate_tables.py` and
  `test_artifact_scripts.py` use the new letters.

## Version 3: build 3 (2026-10-20)

- Six binaries built reproducibly from `git archive 8a30fd4` (manifest
  SHA-256 `0c436fc9...6968eb`, 1,870 entries); a reader's rebuild from this
  archive gives the same six binary hashes (`BINARIES_SHA256.txt`).
- New verifier checks: the date and order of each signed status reply,
  operations with a capability and no outcome reported as unresolved (run
  incomplete), the capability's `cnf` compared with the adapter receipt's
  signer, earlier segments' keys anchored only by their own anchor, the
  witness run status's continuation compared with the folder.
- Registration with the witness signed with an enrollment key; the gateway
  pins the witness key; witness run status v2.
- Every experiment rerun on build 3; the gateway's measurements equal build
  2's. New: `regenerate_tables.py` recomputes the paper's tables from the
  CSV and JSON data; the coverage map per check
  (`docs/paper/data/build3/robustness/coverage_map.md`); the full retry rule
  per state and the journal-failure chronology (`SUPPLEMENTARY.md` S5).

## Version 2: build 2 (2026-10-10)

- Six binaries (the process-kill test program added), built from commit
  `86643d7` in the working tree; not reproducible byte for byte (manifest
  SHA-256 `841a7c6f...b658`).
- The flag stated in recovery records and stored answers, and the two
  flag-loss fixes; three new verifier rules for those records.
- On 2026-10-19 the real-key tests were written and run on build 2's
  sources (test code only); they are part of build 3's commit.

## Version 1: build 1 (2026-10-08)

- Five binaries (manifest SHA-256 `188f83bd...121e`); the first frozen
  build of the key-theft simulation, in-process faults, concurrency,
  misuse, multi-process runs and cost.
