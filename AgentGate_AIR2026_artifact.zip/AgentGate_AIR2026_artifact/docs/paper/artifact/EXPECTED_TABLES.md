# Expected tables: every paper number, its file, field and population

For each table, figure and in-text number of the paper: the data file, the
field or filter, the value and the population it counts. Paths are relative
to `docs/paper/data/build3/` unless they start with `docs/`, `internal/` or
`cmd/`. Every value comes from **build 3**, the evaluated build: six
binaries built reproducibly on 2026-10-20 from commit `8a30fd4` (manifest
`build-manifest.txt`, original SHA-256
`0c436fc9fec8989638dccf4d3e62d609ec033a884d421b659f7ed820886968eb`). Values
of builds 1 and 2 appear only in the last two sections (the version
crosswalk), and each is labelled with its build. Nothing here was
recomputed by hand except where a row says "counted".

Rows marked **go test** come from the real-key tests and the other fixture
tests: test code compiled from the same commit, which creates its keys in
memory. Each of those tests asserts its own counts; run them with the
commands in `README.md` ("Real-key tests"). Every other row is recomputed
from the CSV and JSON files by `regenerate_tables.py` (see "How to check a
table yourself").

Contents: units · single accounting of the binding grid · number traps ·
headline numbers · Tables I-VIII and the in-text numbers of each section ·
build-3 checks · real-key tests · version crosswalk, builds 1-3 · S1.

## Units

One name per unit; the paper uses exactly these. Result files and test logs
written before the paper's wording was settled use other words, listed in
the last column.

| unit | definition | count | older name in files and logs |
|---|---|---|---|
| **attack** | one edit type, key set and anchor condition, under one verifier setting; verified in both designs | 7 x 12 x 4 = **336 per setting**: 168 without a head anchor (anchors none, keys: 84 + 84) and 168 with one (head, both) | "attack cell", "cell" |
| **outcome changed by binding** | an attack that the bound design detects and the unbound design accepts (strongest attacker; the same in all 10 repetitions) | full 0, no snapshot check 8, no replay 12, both off 12, of 336; all among the 168 without a head anchor | "binding flip"; `flips.csv` `kind=binding` |
| **strongest attacker** | an edit counts as detected only if every variant that applies (plain, forge-snapshot, forge-restate) is detected | -- | "strongest" in file names |
| **result** | one attack in one design under one verifier setting (the verifier's answer for it) | 672 per setting; **2,688** over the 4 settings; x 10 repetitions in `strongest.csv` (26,880 rows) | "design result", "cell" (`compromise/RESULTS.md`: "46/672 cells per run"), "cell-run" (result x repetition) |
| **labelled result** | a result the oracle labels: 10 key sets (all but replacement+approval and all genuine keys) | 7 x 10 x 4 x 2 = **560 per setting** = 280 attacks x 2 designs | oracle "560 cells" |
| **fixture** | a small synthetic run in the gateway's format, signed with keys created in memory | -- | "fixture run" |
| **fixture case** | one edit and key set applied to a fixture in one design | RS 34, RB 20, LR 35, LRR 13 | "case" in the tests |
| **fixture result** | one fixture case verified under one verifier setting and one anchor condition | 4 settings x 3 anchors (none, keys, head) = 12 per case in the real-key tests; 4 anchor conditions in the audit-key comparison (44) | "cells" in the `-v` logs and in `fixture-studies/round4_summary.json` |
| **verification** | one verifier run on one folder, anchor condition and setting | per experiment | |
| **edit-design-setting combination** | the unit of the fixture key-set simulation (`TestExtraKeySets`): no key-set or anchor axis | 7 x 2 x 4 = 56 | `extra_keysets_summary.json` `independent_cells` ("56 cells") |
| **fault run** | one in-process fault combination (fault point x retry kind x restart option x repetition) | flag-mode run 560 (the paper's); deny-mode run 280 (archive only) | "schedule" |
| **test case, test run** | process-kill tests: one test case (kill point, provider fault, simulated power-loss state, journal write failure, replay); a test run is one test case in one repetition | 39 test cases x 5 = **195 test runs**, 145 of them with a kill (135 exit 86 + 10 terminated) | `killsuite/summary.md`, `results.json`: "cells", "cell runs" (`totals.cells` = 195); "kill suite", "case run" |
| **operation** | one operation key; process-kill tests: 195 originals + 35 new-ID + 5 journal probes = 235 | per experiment | |
| **multi-process run** | a demo self-test with the provider and the witness as separate processes | 20 (15 flag, 5 deny) | "custody run" |
| **scenario repetition** | concurrency: one scenario in one repetition | 260 x 7 = 1,820 (sum over 7 runs) | |
| **case, request** | misuse: a hand-written case of one or more requests | 59 cases, 95 requests | |
| **line that makes a check fail, mutant, failure condition** | a verifier line that fails a check (one deletion mutant each); one altered copy of the verifier; a line that adds a fail, warn or problem reason | 150 lines; 385 mutants of three other kinds; 336 conditions | "refusal site", "held-out mutant", "refusal condition" |
| **tests added late** | tests written after undetected mutants were seen, or together with new code; the score without them is the one the paper quotes | 16 for the line deletions; 24 for the mutants of three other kinds | "post-hoc tests" |

Abbreviations: A audit, I issuer, X adapter (the three adapter keys
together), X_op the adapter key that signed the edited operation's receipt
(Xf financial, Xm message), X_all every adapter key whose receipt stays in
the log, P provider, s a signed status reply (the provider's signed answer
to a status lookup; any local process can obtain one in the prototype).
Evidence basis: F real-key tests on fixtures, S key-theft simulation, A
argued from the verifier code. Settings: full, no snapshot check
(`no-snapshot-bound-only`, `nsb`), no replay (`no-replay`), both off
(`no-replay-no-snapshot`, `nrns`).

## Single accounting of the binding grid

One table for every count of the key-theft grid, so that each denominator
can be traced. Source: `compromise/strongest.csv` (strongest attacker; the
same in all 10 repetitions; counted by `regenerate_tables.py`). Accepted
counts are results the verifier accepted; detected = subset size minus
accepted. With no reverse changes, changed = unbound accepted minus bound
accepted.

| setting | changed, of 336 | changed, of the 168 without a head anchor (none + keys) | changed, of the 168 with a head anchor | accepted, bound: all / no head / head | accepted, unbound: all / no head / head | reverse |
|---|---|---|---|---|---|---|
| full | 0 | 0 (0 + 0) | 0 | 23 / 23 / 0 | 23 / 23 / 0 | 0 |
| no snapshot check | 8 | 8 (4 + 4) | 0 | 23 / 23 / 0 | 31 / 31 / 0 | 0 |
| no replay | 12 | 12 (6 + 6) | 0 | 41 / 41 / 0 | 53 / 53 / 0 | 0 |
| both off | 12 | 12 (6 + 6) | 0 | 41 / 41 / 0 | 53 / 53 / 0 | 0 |

The same as detections (bound / unbound): of 336, 313 / 313, 313 / 305,
295 / 283, 295 / 283; of the 168 without a head anchor, 145 / 145,
145 / 137, 127 / 115, 127 / 115; of the 168 with one, 168 / 168 in every
setting. The 8 attacks changed without the snapshot check are 4 pairs
{strip-flag, invent-flag} x {A, A+I}, each with no anchor and with a keys
anchor; the 12 without replay are 6 pairs {strip-flag, invent-flag,
change-rules} x {A, A+I}, each with no anchor and with a keys anchor. The
repetitions show stability only; they are never a denominator.

## Number traps

- **Two halves of 336.** "12 of 336" and "12 of the 168 without a head
  anchor" count the same 12 attacks. A head anchor detects every attack that
  has one, because every edit changes the audit log, so binding can change
  outcomes only in the other half. The first mention gives both.
- **Missing entries.** Never cite "folders with a Missing entry"
  (`segments_with_missing_items`): every folder verified with a saved head
  lists a `freshness` entry, so that count equals the number of folders.
  Cite `segments_with_missing_items_by_kind` (`missing_by_kind`).
- **Flagged counts.** `counts.flagged` includes unresolved flagged
  operations; executed flagged operations = `counts.flagged` minus
  `counts.flagged_unconfirmed`.
- **Two different 46s.** 46 accepted results per run under the full verifier
  (23 bound + 23 unbound, all without a head anchor) are not the oracle's 46
  mismatches (514 of 560).
- **Two scores for each mutation experiment.** Always name the test set:
  the line deletions give 150 of 150 with the full suite and 63 of 150
  without the 16 tests added late; the mutants of three other kinds give 212
  of 385 with the full suite and 130 of 385 without the 24 tests written
  after lists of undetected mutants existed.
- **Process-kill numbers.** The earlier-build values are only the two
  flag-loss counts of `../build2/killsuite/prefix-earlier-build/` (190 test
  runs on an earlier build) and are labelled "earlier build".

## How to check a table yourself

- Everything below that is not marked **go test**:
  `py docs/paper/artifact/regenerate_tables.py docs/paper/data/build3`
  recomputes it from the CSV and JSON files and prints `RESULT: PASS` when
  every number matches (`REPRODUCIBILITY.md`, section 5).
- Table III and the headline counts from a fresh run: the quick check in
  `README.md` (`quick_check.py` recomputes them from a new one-repetition run
  of the key-theft simulation and compares every result with
  `compromise/strongest.csv`).
- Rows marked **go test**: the commands in `README.md` ("Real-key tests");
  each test asserts its counts.
- Any other row: open the file named in the row. JSON paths use dots; "row
  X" means the CSV row whose first columns are X.

## Headline numbers (abstract, I, V-A, VIII)

| key | value | file | field / filter | population |
|---|---|---|---|---|
| `compromise.flips.full` | 0 of 336 (0 of the 168 without a head anchor) | `compromise/flips_by_anchor.csv`; `compromise/analysis.json` | row `full`: `all` 0/336, `without_head_anchor` 0/168; `flip_counts` has no `full` key (= 0) | 7 edit types x 12 key sets x 4 anchor conditions, strongest attacker, 10 repetitions, all identical |
| `compromise.flips.nosnap` | 8 of 336 (8 of the 168) | same | row `no-snapshot-bound-only`: `all` 8/336, `without_head_anchor` 8/168 (none 4, keys 4); `flip_counts["no-snapshot-bound-only\|strongest\|binding\|all"]` = 8 | same; 4 distinct pairs {strip-flag, invent-flag} x {A, A+I} |
| `compromise.flips.noreplay` | 12 of 336, all among the 168 without a head anchor | same | row `no-replay`: `all` 12/336, `without_head_anchor` 12/168 (none 6, keys 6) | same |
| `compromise.flips.noreplay.distinct` | 6 pairs of edit type and key set, each with no anchor and with a keys anchor | `compromise/flips.csv` | `verifier_config=no-replay`: distinct (operator, keyset) = {strip-flag, invent-flag, change-rules} x {audit, audit+issuer} (counted) | |
| both checks off (`no-replay-no-snapshot`) | 12 of 336 (12 of the 168) | `compromise/flips_by_anchor.csv` | row `no-replay-no-snapshot` | |
| head-anchored attacks | 168 of 168 detected in both designs in every setting; 0 changed by binding | `compromise/flips_by_anchor.csv` | `with_head_anchor` 0/168 in every row; detections: `strongest.csv` (counted) | anchors head, both |
| detected attacks, bound / unbound, of 336 | full 313 / 313; no snapshot check 313 / 305; no replay 295 / 283; both off 295 / 283 | `compromise/strongest.csv` | result detected = `detected=true` in all 10 repetitions (counted by `quick_check.py`) | |
| detected, bound / unbound, of the 168 without a head anchor | 145 / 145; 145 / 137; 127 / 115; 127 / 115 (accepted 23 / 23; 23 / 31; 41 / 53) | same | anchors none and keys | changed = unbound accepted minus bound accepted (no reverse changes) |
| reverse changes | 0 | `compromise/flips_by_anchor.csv` column `reverse` | unbound detects, bound accepts | |
| `killsuite.caseruns` | 195 test runs (39 test cases x 5 repetitions), 145 with a kill | `killsuite/summary.md` | header "Cells: 195"; `results.json` `totals.cells` | |
| two flag-loss bugs | 2 (one after a kill between dispatch intent and outcome; one, with no kill, in a stored answer returned again within one process) | `../build2/killsuite/prefix-earlier-build/README.md`; `../build2/RESULTS_BUILD2.md` §0.3 row 1 | fixed before build 2; still fixed in build 3 (0 of 45 lost) | |
| reconciliation path: A+I with a signed status reply accepted | no replay 3 of 3 edit types (6 of 6 fixture results with the keys-anchor repeat); full verifier 2 edit types x 4 settings (8 of 8); real-key tests LR: in both designs and every setting | `fixture-studies/lifecycle.csv`; `fixture-studies/RESULTS.md` §2.3, §2.4 | tests `TestLifecycleL3AuditIssuerConversionWithoutReplay`, `TestLifecycleL4FullVerifierAllReconciled`, `TestRound4LifecycleRealVsSimulation`; the status reply is dated within its operation and follows an unresolved status (build-3 rules) | fixtures, real keys |
| real-key tests vs the simulation (**go test**) | same verdict, assurance level and failing checks in 1,196 of 1,196 results where the simulation can represent the key set | `fixture-studies/RESULTS.md` §2.1; `fixture-studies/round4_summary.json`; `fixture-studies/simulation_agreement.csv` | 44 (audit-key comparison) + 336 (RS, exact) + 240 (RB) + 420 (LR) + 156 (LRR) | 33 of the cases are the attacker who left untouched every record it could not sign (20 RB + 13 LRR) |
| simulation overstates one adapter key (**go test**) | of 72 results with one of the three adapter keys, the simulation accepted 40 that the real-key tests detected | `fixture-studies/RESULTS.md` §2.1 | RS partial-adapter rows; REAL accepts 0 of 72; bracketed 72/72 by the simulation without ADAPTER | 6 RS cases x 12 |

## Table I (lifecycle): smallest tested key sets that changed the classification

Bound design, no head anchor (a head anchor detected every tested change:
136/136 RS, 80/80 RB, 0 of 120 LR acceptances with a head anchor, 52/52
LRR). Each entry with its evidence basis and source; test codes as in
`fixture-studies/RESULTS.md` §2.4 (RS, RB, LR, LRR, LH, NC, SF real-key
tests; L1, L1b, L2, L3, L4, CH, RA, RR, UD, CE, SA fixture tests). The full
evidence-basis table with every test code: `SUPPLEMENTARY.md` S7.

| row (classification signed by) | No replay | Full verifier | Downgrade (less protected status) |
|---|---|---|---|
| COMMITTED via adapter receipt (issuer, adapter) | A+I+X_op, F: RS M1 (A+I+Xf passes a payment edit in no-replay and nrns); RS/RB M3 (a message edit needs Xm, a payment edit Xf). Smaller sets detected with no signature failing: RB M1 (A: `op.capability_bound` + `op.requires_policy`; A+I: `op.receipts_bound`; A+Xf: all three; each VERIFIED once those checks are off). Grid (S; the simulation's adapter role is every adapter key): `compromise/strongest.csv`, `no-replay`, bound, strip-/invent-flag accepted from `audit+issuer+adapter` | A+I+X_all, F,S: RS M2 (A+I+X forge-restate passes in all 4 settings); RB M2 (A+I+Xf alone, message receipts genuine: `op.receipts_bound` x2 in all 4 settings); grid: `strongest.csv`, `full`, strip-/invent-flag accepted only from `audit+issuer+adapter` with `forge-restate` | A: UNCERTAIN, flag kept, warning, `run_complete` fail (L1, F); A+s: reconciled, flag kept, in the form that meets the build-3 date and order rules (L2 careful form, VERIFIED 4/4; the build-2 form is now FAILED 4/4, F); A+I+s: reconciled, flag changed (LR convert, L3, L4, F) |
| COMMITTED via RECONCILED (issuer) | A+I+s, F: LR convert (A+I passes no-replay and nrns); L3 (6 of 6). A detected (LRR converted: `op.capability_bound`, `op.outcome_resolved`) | A+I+s, F: LR forge-restate with every execution converted (passes all 4 settings); L4 (8 of 8) | A: UNCERTAIN, run incomplete (LH: RECONCILED deleted, VERIFIED, `issuer_only_unresolved`, `run_complete` fail, F) |
| executed, then confirmed by RECONCILED (issuer, adapter) | A+I+X_op, F: LR confirm (A+I+Xf passes no-replay and nrns); A+I detected by `op.receipts_bound` alone (LRR confirmed) | A+I+X_op, F: LR confirm-rest (forge-restate, other executions converted; passes all 4 settings); LRR confirm-rest | A+s: drop the execution, giving row 2 (same shape as L2 / LR convert, F) |
| UNCERTAIN, RECONCILIATION_REQUIRED (issuer; warning) | A+I, F: LR downgrade (passes no-replay and nrns); L1b. A detected (LRR downgraded: `op.capability_bound`, `provider.matches_audit`) | A+I, F: LR downgrade-rest | A: no capability, accepted (`audit_only`) only if the provider never committed (UD, F); else detected, `provider.matches_audit` (CH) |
| REJECTED or PENDING after a capability (issuer) | A+I, A: `requirePolicy`, `classificationEvidence` (the decision is capability-bound as for UNCERTAIN) | A+I, A | A: UNCERTAIN (CE: the genuine state after the RECONCILED is deleted, F); PENDING with a capability is reported as unresolved, so the run is incomplete (build 3: `TestPendingCapabilityIsIncomplete` 4/4 forms, F; process-kill tests: 10 such operations, `killsuite/RESULTS.md` §5) |
| no capability (audit key only) | A, F: NC (accepted as `audit_only` in no-replay and nrns) | A+I(+X), A: `checkSnapshotBinding` (the attacker must restate the snapshot hash the issuer signed into every capability, plus X for kept receipts); the plain edit is caught by replay (NC: `policy.replay` in full and nsb, F) | none; A deletes the whole operation, VERIFIED unless a head anchor is given (SA "deleted denial", real = simulation, F) |
| note: unbound design | A without replay: row 1 RS/RB M1 unbound (A, A+I, A+Xf accepted); row 2 LR convert unbound (A+s); row 3 LR confirm unbound; row 4 LR downgrade unbound (all F); rows 5-6 A | as bound: row 1 RS M2 unbound (A+I+X passes; Xf alone detected, RB M2 unbound); row 2 LR unbound forge-restate (A+I+s, all settings) (F); rows 3-6 A | |
| note: "smaller tested sets were detected with no signature failing" | RB (240 of 240 fixture results with no signature check failing), LRR (156 of 156) | | |
| note: s | a signed status reply dated no later than 5 s after its entry and, for a commit, no earlier than 5 s before its capability was issued; a reconciled commit needs an unresolved status or a restart in the log (`internal/auditverify/reconcile.go`; `fixture-studies/RESULTS.md` §2.5) | | |

## Figure 2 caption (evidence chain)

| statement | source |
|---|---|
| bound design: with k_A alone, keeping the genuine κ and ρ_E fails `op.capability_bound` and `op.requires_policy`, with no signature failing (real-key tests) | **go test** RB M1, bound, strip-flag/plain, A held, genuine I and Xf records kept: failing checks without replay `op.capability_bound`, `op.requires_policy`; VERIFIED once the binding checks are off (`fixture-studies/RESULTS.md` §2.1; the case lines in `fixture-studies/logs/`, study s7) |
| with replay, a forged snapshot restates h_P, so with an adapter receipt the smallest tested set is A+I+X in both designs, with the key of every receipt left in the log (key-theft simulation, real-key tests) | `compromise/strongest.csv`, `verifier_config=full`, strip-/invent-flag, evading variant `forge-restate` from `audit+issuer+adapter`; **go test** RS M2 (A+I+X passes, both designs) and RB M2 (A+I+Xf detected by `op.receipts_bound` x2) |

## Table II (properties: fields that must agree, checks, evidence)

| cell | value | file | field / filter | population |
|---|---|---|---|---|
| P1 evidence | 140 of 140 edits made without keys detected without anchors | `custody/tamper_lab.csv` | all rows except the rollback: `naive_verdict=FAILED` | 20 multi-process runs x 7 edits without keys |
| P2 holds if | receipt path: {A, I, X_op} not all held; reconciliation path: {A, I} | Table I; `fixture-studies/RESULTS.md` §2.4 | | |
| P2 field edits | 7 of 7 detected (F) | **go test** `TestRound4ValidlySignedInconsistentFields` | claim "classification binding": detected 7, accepted 0 (`fixture-studies/signed_fields.csv`) | 7 validly signed single-field edits, full verifier, keys anchor |
| P2 counterexample | snapshot forger with A+I+X passes every check but the head anchor (both designs, F,S); A+I+s on the reconciliation path (F) | `compromise/strongest.csv` (full, forge-restate); RS M2; LR, L4 | | |
| P3 evidence | every stolen key set without A+I+X+P detected (F,S) | `compromise/strongest.csv`: change-amount accepted only from `audit+issuer+adapter+provider`; **go test** RS M4 (A+I+Xf detected with `provider.signature`, `provider.state_chain`; A+I+Xf+P passes without replay, `policy.replay` catches it in full and nsb); RB M4 (A+I+Xf, genuine provider receipt: `op.receipts_bound`) | | grid: 7 edit types x 12 key sets; RS/RB M4: 2 designs |
| P3 field edits | 15 of 20 detected (F); unchecked (n): request digests and idempotency keys of the adapter receipt, adapter ID, outcome, capability tenant and subject; the capability's `cnf` is now checked (2 new cases, detected) | **go test** SF | claim "effect binding": detected 15, accepted 5 | 20 field edits |
| P4 evidence / counterexample | one commit removed: 20 of 20 detected with the provider's journal, 0 of 20 with the folder's | `custody/rollback_by_anchor.csv` | rows `coherent rollback + provider journal from the provider process`, anchors none and keys: detected 20; rows `coherent rollback`: detected 0 | 20 multi-process runs |
| P4 field edits | 11 of 18 detected (F); unchecked: request digests and idempotency keys (n); accounting fields: state hash, commit count, provider reference, row hash, commit time (w); the first commit's `state_before_hash` (w); the status reply's date is now checked (dated 2030 and dated before the capability: detected) | **go test** SF | claim "provider evidence": detected 11, accepted 7 | 18 field edits |
| P5 evidence | 20 of 20 with a saved final head or the live witness status | `custody/rollback_by_anchor.csv`; `custody/RESULTS.md` §3 | rows `head pinned` / `witness latest via --witness-url` | 20 multi-process runs |
| P5 counterexample | 0 of 20 with a keys anchor or an out-of-date saved head (ANCHORED); a continuation forged with the enrollment key is ANCHORED (1 of 1, F) | `custody/rollback_by_anchor.csv`; `fixture-studies/RESULTS.md` §2.6 | `keys pinned` rows V1, V3, V4: 0; `stale witness head (#k)` V1: 0, assurance `VERIFIED/ANCHORED x20`; **go test** `TestEnrollmentKeyHolderRegistersLikeTheGateway` | |
| P6 evidence | replacement keys: 14 of 14 edit-design pairs detected with either anchor, 8 of 14 with none (S) | `compromise/replacement_keys.csv` | `keyset=all-replaced`, full: none 8, keys 14, head 14, both 14 (counted) | 7 edit types x 2 designs per anchor condition |
| P6 counterexample | all genuine keys stolen: a keys anchor adds nothing (8 of 14, as none); a head anchor detects 14 of 14 (S) | same | `keyset=all-stolen`, full: none 8, keys 8, head 14, both 14 | same |
| P7 evidence | Table V; 1,820 of 1,820 concurrency repetitions | `concurrency/analysis/scenario_repetitions.csv` | `safety_holds` and `harness_invariant_holds` both true | 7 runs, 260 repetitions x 7 scenarios |
| P7 counterexample | a new ID commits again (400 of 1,120 in process); after a failed journal write, 5 operations committed once each after 10 REJECTED answers (two per operation: scope "operation", then the stored answer with scope "call") | `crash/crash.json` `totals.business_duplicates`=400; `killsuite/results.json` `totals.rejected_answers_then_effect_after_restart`=10; chronology: `killsuite/journal_chronology.md` | | in-process flag run; process-kill tests (journal-write-failure case, 5 repetitions x 2 answers) |
| approval link field edits | 12 of 17 detected (F); unchecked (w): the approval record's lists (FINAL field 8, capability -70013, receipt `authorization_artifact_hashes`), their hash (the overlay root, not recomputed), the approver | **go test** SF (human-approval fixture) | claim "approval lineage": detected 12, accepted 5 | 17 field edits |
| field edits in all | 45 of 62 detected with exactly the expected checks and no signature failing; 17 accepted (VII L4) | **go test** SF | per claim 15 / 7 / 11 / 12 detected, 5 / 0 / 7 / 5 accepted | 62 subtests |

## Table III (outcomes changed by binding, by path, anchor and setting)

The paper's Table III prints the rows marked "paper"; the other rows were
moved out of the paper for space and are kept here and in `SUPPLEMENTARY.md`
S2 and S4. Receipt-path rows: `compromise/strongest.csv` (strongest
attacker), 10 repetitions, 0 of 2,688 results unstable
(`compromise/analysis.json` `unstable_cells` = []). Key sets: smallest
accepted key set, bound / unbound (one entry: both alike), anchors none or
keys, genuine keys. F marks: real-key fixture results that also passed
(without replay with X_op only).

| row | full | no snapshot check | no replay | filter and F sources |
|---|---|---|---|---|
| no head anchor (168): changed (paper) | 0 | 8 | 12 (6 pairs) | `compromise/flips_by_anchor.csv` column `without_head_anchor`; pairs counted from `flips.csv` |
| no head anchor (168): detected, bound / unbound (paper) | 145 / 145 | 145 / 137 | 127 / 115 | `strongest.csv`, anchors none and keys (counted by `quick_check.py`) |
| no head anchor: flag edits, smallest key set (paper) | A+I+X_all F,S | A+I+X_all F / A | A+I+X_op F / A F | grid: the rows strip-flag, invent-flag and change-rules below; X_all and X_op from RS M2 and RS/RB M1, M3 (real-key tests) |
| head anchor (168): changed (paper) | 0 | 0 | 0 | column `with_head_anchor` |
| head anchor (168): detected, bound / unbound (paper) | 168 / 168 | 168 / 168 | 168 / 168 | `strongest.csv`, anchors head and both |
| all 336: changed (paper) | 0 | 8 | 12 | column `all` |
| all 336: detected, bound / unbound | 313 / 313 | 313 / 305 | 295 / 283 | `strongest.csv` |
| strip-flag, invent-flag | A+I+X F | A+I+X F / A | A+I+X F / A F | full and nsb: `forge-restate` evades from `audit+issuer+adapter`; nsb unbound: `forge-snapshot` from `audit`. F: full and nsb RS M2 (both designs, all 4 settings); no replay bound RS M1 A+I+Xf (payment), unbound RS M1 / RB M1 A |
| change-rules | -- (how we wrote the edit, C1) | -- | A+I+X F / A | F: RS M3 bound change-rules A+I+Xm (a message, accepted without replay); unbound A: grid only |
| change-escalation | -- | -- | -- | detected with every key set (`op.requires_policy`) |
| swap-decisions | -- | -- | -- | |
| change-amount | A+I+X+P | A+I+X+P | A+I+X+P F | F: RS M4 A+I+Xf+P (accepted without replay; `policy.replay` detects in full and nsb) |
| relabel-approved | -- (how we wrote the edit, C2) | -- | A+I+X | grid only (the approval key was never used with real keys) |
| reconciliation path, no head anchor: smallest key set (paper; real-key tests, no forge-snapshot variant) | A+I+s | A+I+s | A+I+s / A+s | `fixture-studies/lifecycle.csv`: L4 (full and every setting, 8/8), L3 (no replay, 6/6); LR (both designs, every setting; unbound A+s); the reply dated within its operation and an earlier unresolved status signed with the audit key (L2 careful form 4/4) |
| reconciliation path, head anchor (paper) | detected | detected | detected | LR: 0 of 120 acceptances with a head anchor; LRR 52/52 |
| oracle agreement, of 560 labelled results: main version | 514 | 522 | 546 | `compromise/oracle_agreement.csv`, `attacker=strongest`, `reading=primary`, column `agree` |
| oracle agreement: alternative versions combined after the run | 540 | 536 | 560 | same file: full `snapshot_bound+mode_checked`; no snapshot check `mode_checked`; no replay `mode_checked` |

Both checks off matched no replay in every row (changed 12, detections
295 / 283, 127 / 115). Footnote a of the paper's table (change-amount took
A+I+X+P in every setting; relabel-approved took A+I+X without replay; the
other edits were never accepted, some because of how we wrote them): the
per-edit rows above; C1 and C2 are explained in `SUPPLEMENTARY.md` S4.

## In-text numbers of V intro and V-A

| key | value | file | field | population |
|---|---|---|---|---|
| frozen build | build 3: six binaries built reproducibly; the manifest's source and binary hashes unchanged before and after each experiment | `build-manifest.txt`; each experiment's `build-manifest.txt` | 1,870 entries re-hashed, 0 different | |
| real-key tests are test code from the same sources | compiled from commit `8a30fd4`; the 241 repository files they share with the frozen binaries are hash-equal to the manifest | `fixture-studies/build-manifest.txt`; `fixture-studies/RESULTS.md` | 67 test-only files hashed there | |
| 12 key sets; 4 anchor conditions; 7 edit types | | `compromise/RESULTS.md`; `strongest.csv` | | |
| `compromise.stable` | across 10 repetitions no result changed: 0 of 2,688 (336 attacks, 2 designs, 4 settings) | `compromise/analysis.json` | `unstable_cells` = [] | |
| no single key but the audit key got an edit accepted | | `compromise/strongest.csv` | single-key sets issuer, adapter, provider, delegation (and none): every result detected; accepted results occur only for key sets containing audit, plus all-replaced (counted) | |
| real-key tests: 4 settings and 3 anchor conditions; 1,196 results; 33 cases with untouched unsigned records; 72 / 40 (**go test**) | see the headline rows | `fixture-studies/RESULTS.md` §2.1 | RS, RB, LR, LRR, SA | |
| full verifier, real keys: passed only with every adapter key whose receipt stays in the log (**go test**) | RS M2 A+I+X passes; RB M2 A+I+Xf: `op.receipts_bound` x2 (the two message receipts) | `fixture-studies/RESULTS.md` §2.1, §2.4 | | |
| reconciliation relabeling needs a reply fetched while the operation was open and an earlier unresolved status; a relabeling that kept the flag and lacked both was detected in 4 of 4 settings (**go test**) | L2 build-2 form FAILED 4/4 (only `op.outcome_resolved`); L2 careful form VERIFIED 4/4 | `fixture-studies/lifecycle.csv`; `fixture-studies/RESULTS.md` §2.3 | | fixtures, real keys |
| `lifecycle.L3.A_detected / .AI_accepted` | 3 of 3 / 3 of 3 edit types (6 of 6 fixture results with the keys-anchor repeat) | `fixture-studies/lifecycle.csv` | `TestLifecycleL3AuditIssuerConversionWithoutReplay`, converted rows | |
| `lifecycle.L4.accepted` | strip- and invent-flag in all 4 settings (8 of 8) | same | `TestLifecycleL4FullVerifierAllReconciled` | |
| histories: 21 of 27 detected, 6 accepted | CH 12 (9 detected, 3 accepted) + LH 15 (12 detected, 3 accepted; **go test**, the same with replay off 15/15); none of the 6 changed a classification, and the report described each | `fixture-studies/lifecycle.csv` (`TestLifecycleConflictingHistories`); `fixture-studies/lifecycle_histories.csv` | | full verifier, keys anchor |
| human approval: relabel-approved without replay passed with A+I+X (no approval key) | | `compromise/strongest.csv` | `relabel-approved`, `no-replay` | |
| `compromise.oracle.mismatch.total` / `.snapshot` / `.mode` / `.targets` | 46 / 8 / 14 / 24 (C1 14 + C2 10) | `compromise/oracle_mismatches.csv` | `verifier_config=full`, `attacker=strongest`, `reading=primary`, counted by `cause`: S1 8, A3 14, C1 14, C2 10 | 560 labelled results |
| oracle agreement 514 / 540 | | `compromise/oracle_agreement.csv` | see Table III | 560 per setting |
| `compromise.controls.ok` / `.total` | 1,280 / 1,280 | `compromise/base_controls.csv`, `compromise/controls.csv`; `compromise/RESULTS.md` | unedited runs VERIFIED, real and with all roles assumed stolen | 40 base runs x 2 (real, all roles) x 4 anchors x 4 settings |
| `resign.audit.agree` | 44 / 44 | `fixture-studies/simulation_agreement.csv`; `compromise/validation_sim_vs_real.txt` | `TestSimulationAgreesWithRealAuditKeyResigning` (same verdict, assurance, failing checks with counts) | 10 audit-key edits + 1 unedited control x 4 anchors (part of the 1,196) |
| `keysets.combinations` / `.pairs` / `.verifications` (archive only) | 56 / 88 / 616 | `fixture-studies/extra_keysets_summary.json` | `independent_cells`, `independent_cell_variant_pairs`, `independent_verifications` | edit-design-setting combinations (7 x 2 x 4), simulation on fixtures |
| `keysets.AX_eq_A` / `AP_eq_A` / I+X accepted (archive only) | 56/56 / 56/56 / 0 of 56 | same | `tallies.cells.ax_equals_a`, `ap_equals_a`, `accepted_IX` | same |
| correction before build 1 | a trial run before build 1 showed the unbound design lacked an escalation-mode check; adding it removed outcomes favoring binding | `SUPPLEMENTARY.md` S4 | 23 of 308 no-replay changes then, 7 from the missing check | 2026-10-07 run, 11 key sets |

## Table IV (rollback and withheld segments, 20 multi-process runs)

Source: `custody/rollback_by_anchor.csv` (column `detected`, of 20) and
`custody/RESULTS.md` §3. V1 = R1 (rollback to #168, journal from the
folder), V2 = R2 (R1 with the journal from the provider process), V3 = R3
(rollback to #177, no commit removed), V4 = R7 (segment rolled back to its
own head #3), V5 = R5 (segment withheld). Population: 20 multi-process runs
(15 flag, 5 deny). The result files say "stale" for out-of-date and "pinned"
for saved.

| anchor | V1 | V2 | V3 | V4 | V5 |
|---|---|---|---|---|---|
| none | 0 | 20 | 0 | 0 | 0 |
| keys anchor only | 0 | 20 | 0 | 0 | 0 |
| out-of-date witness head, saved | 0 (ANCHORED) | 20 | 0 | 0 (ANCHORED) | 0 |
| latest witness head, saved | 20 | 20 | 20 | 20 | 0 (ANCHORED) |
| latest witness head and live signed status | 20 | 20 | 20 | 20 | 20 |
| saved final head (genuine) | 20 | 20 | 20 | 20 | 20 |

## In-text numbers of V-B

| key | value | file | field | population |
|---|---|---|---|---|
| replacement keys, detection framing | all keys replaced: full verifier 8 of 14 without anchors (no replay 4 of 14), 14 of 14 with either anchor; all genuine keys stolen: keys anchor 8 of 14, head anchor 14 of 14 | `compromise/replacement_keys.csv` | `keyset=all-replaced` / `all-stolen`, detected per anchor column (counted); accepted = 14 minus detected (6 full, 10 no replay, without anchors) | 7 edit types x 2 designs per anchor condition |
| `custody.runs` | 20 (15 flag, 5 deny) | `custody/repeats.csv` | | |
| `custody.keyless.detected` / `.total` | 140 / 140 | `custody/tamper_lab.csv` | Table II P1 | 20 runs x 7 edits without keys |
| `custody.alterations` | 180 of 180 refused | `custody/status_probe_summary.json`; `custody/RESULTS.md` | relay that changed the witness's answers | |
| `custody.clean.ok` / `.total` | 120 / 120 (20 unedited runs passed under all 6 anchor conditions) | `custody/rollback_by_anchor.csv` | unedited runs accepted under all six anchor conditions | 20 runs x 6 anchors |
| `custody.enroll.refused` | 200 of 200 registrations or continuations not signed with the enrollment key refused; the genuine run stayed ANCHORED | `custody/repeats_summary.json` `enrollment`; `custody/RESULTS.md` §4 | `eval_enrollment_probes_refused` (5 per run) + `probe_unsigned_registrations` (5 per run, all 403 `enrollment`) | 20 multi-process runs x 10 probes |
| false registrations, real-key tests (**go test**) | 19 of 19 registrations without the enrollment key refused; a witness status naming another continuation than the folder's failed the witness check (7 of 7); a continuation forged with the enrollment key was ANCHORED (1 of 1) | `fixture-studies/registration_enrollment_cases.csv`; `fixture-studies/round5_cases.csv`; `fixture-studies/RESULTS.md` §2.5, §2.6 | `TestPreemptionWithoutTheEnrollmentKeyIsRefused`, `TestFalseContinuationWithoutTheEnrollmentKeyIsRefused`, `TestASecondEnrolledGatewayCannotContinueTheRun`, `TestEnrollmentKeyHolderRegistersLikeTheGateway`, `TestWitnessStatusContinuationLinkage` | fixtures, real witness service in the test process |
| `custody.revoked` | 20 of 20 | `custody/repeats.csv` column `revision_checks_passed` (9/9 in each of the 20 runs); `custody/custody.json` `selftest_revision_checks` | the self-test check "Revoking the grant stops the next action (DEL-REVOKED)" is one of the nine; across the gateway restart the revocation is restored | 20 multi-process runs (Table V note) |
| `head_fresh` pass | 180 of 180 with the live witness (command line); 0 of 1,300 with any other anchor | `custody/dimensions_by_cell.csv` | | |
| `run_complete` pass | 20 of 20 clean whole runs with the live witness; 0 of 1,300 edited; fails clean evidence 0 of 120 | same | | |
| out-of-date status window | statuses signed 135-611.3 s before the fetch refused 40 of 40 | `custody/status_probe_summary.json` | `replayed_status_age_s`; cells `replayed-pair` | |
| witness behavior | stopping the witness blocked no payment (one `WITNESS_UNAVAILABLE` entry); verifying against it gave an error | `custody/RESULTS.md` | | 20 runs |

## Table V (guarantee violations: in-process faults and process kills)

In process: the **flag-mode run only** (`crash/crash.json`): 7 fault points
x 2 retry kinds x 2 restart options x 20 repetitions = 560 fault runs, 1,120
plain ALLOW operations (none flagged). A deny-mode run (280 fault runs, 560
operations, 10 repetitions) is in `crash/deny/` and not in the table.
Process kills: `killsuite/results.json` and `summary.md`: 39 test cases x 5
= 195 test runs (145 with a kill: 135 exit 86, 10 terminated), 235
operations (195 originals + 35 new-ID + 5 journal probes).

| row | unit | in-process | file / field | process kills | file / field |
|---|---|---|---|---|---|
| two provider effects for one operation | operations | 0 of 1,120 | `crash.json` `totals.duplicate_effects_per_operation_id` / `totals.operations` | 0 of 235 | `totals.operations_with_more_than_one_effect` / `totals.operations` |
| REJECTED while the provider held an effect | REJECTED answers | 0 of 480 | `crash/crash.csv` (480 of 2,240 answers; all `dispatched=false`: 240 `dispatch_refused`, 240 `aborted_before_send`); `totals.rejected_while_effect_exists`=0 | 0 of 30 | `totals.rejected_while_provider_holds_effect`=0; 30 REJECTED answers |
| COMMITTED without a provider effect | COMMITTED answers | 0 of 1,120 | `totals.committed_without_effect` | 0 of 185 | `totals.committed_without_effect`; 185 COMMITTED answers |
| a provider effect without an outcome entry | effects | 0 of 1,360 | `totals.evidence_gaps`=0; 1,360 effects | -- | |
| UNCERTAIN after reconciliation | operations | 0 of 1,120 | `totals.unresolved_after_reconcile` | 0 of 225 | `totals.unresolved_after_reconcile_not_deliberate`; 225 = operations outside the 10 deliberate ones |
| an operation dispatched twice | test runs | -- | | 0 of 195 | `totals.cells_with_redispatch`=0 (counted per test run, so no operation of 235) |
| flag lost in a recovery record or stored answer | flagged commits | -- | | 0 of 45 | `totals.flag_lost`=0, `totals.flag_cells_committed`=45 |
| reported: no final status | operations | -- | | 15 | `totals.undecided_after_reconcile`=15 (10 with a capability, the original operations of the two pre-dispatch new-ID controls, reported unresolved, run incomplete; 5 journal probes without one, refused before they were journaled; 5 unlisted: `unlisted_after_reconcile`) |
| note: deliberately unresolved | operations | | | 10 | `totals.unresolved_after_reconcile_deliberate` (lookups that always failed 5, refused restart 5) |
| note: REJECTED twice, then committed once after a failed journal write | operations / answers | | | 5 operations, 10 answers | `totals.rejected_answers_then_effect_after_restart` (5 test runs x 2) |
| note: revoked grant across a restart | multi-process runs | 20 of 20 | see V-B `custody.revoked` | | |

## In-text numbers of V-C

| key | value | file | field | population |
|---|---|---|---|---|
| `crash.fault_points` / `crash.reps` | 7 / 20 | `crash/crash.csv` | 7 fault points x 2 retry x 2 restart x 20 | flag-mode run only |
| `crash.ops` / `crash.schedules` / `crash.folders` | 1,120 / 560 / 840 | `crash.json` `totals.operations`, `schedules`, `totals.segments_verified` | 840 of 840 ANCHORED (`totals.segments_anchored`) | same |
| same-ID retries | 320 reconciled (unresolved operations, 0 new effects), 240 returned the stored answer (replayed, scope call) | `crash/crash.csv` | | same (archive S5) |
| `crash.freshid_again` | 400 of 1,120 | `crash.json` `totals.business_duplicates` | | same |
| crash Missing by kind | freshness 840/840, unresolved 160, issuer_only 160, other 0 | `crash.json` `totals.segments_with_missing_items_by_kind` | never cite `segments_with_missing_items` (840) | same |
| crash classification evidence | issuer_adapter 1,040, issuer_only_reconciled 320, issuer_only_no_effect 320 (of 1,680 operation views) | `crash/cli_crosscheck.csv` | final segment, anchors none | same |
| kill points / disk states | 7 marked kill points, 6 distinct disk states | `killsuite/results.json` `kill_points`; `SUPPLEMENTARY.md` S12 | before_effect_executed leaves the same state as after_receipt | |
| test-case composition | 21 kill cases, 4 human, 8 provider faults, 4 simulated power-loss states, 1 journal write failure, 1 same-process replay = 39 | `killsuite/results.json` (groups); S12 | | |
| `killsuite.unstable` | 0 of 39 test cases varied across repetitions | `killsuite/results.csv` | | |
| `killsuite.seg1.pma` | 50 of 155 first segments verified alone fail `provider.matches_audit` | `killsuite/results.json` `totals.failing_checks`; `killsuite/summary.md` | a kill between the provider's commit and any outcome entry; 155 = the 150 restarted test runs + the 5 refused restarts | |
| `killsuite.class.reconciled` | 75 operations rest on the issuer key alone (`issuer_only_reconciled`; 50 after a restart, 25 provider-fault reconciliations) | `results.json` `totals.classification_evidence` | other classes (S12): issuer_adapter 85, issuer_only_no_effect 10, issuer_only_unresolved 15, not reported 10 | original operations, newest folder |
| `killsuite.undecided` / with a capability | 15 / 10 | `totals.undecided_after_reconcile` | 10 with a capability (reported unresolved, run incomplete), 5 journal probes | |
| `killsuite.flagged_committed` / `.flag_lost` | 45 / 0 (in 195 test runs) | `totals.flag_cells_committed`, `totals.flag_lost` | recovery entries 60, stored answers 20 (`killsuite/RESULTS.md` §4) | |
| `killsuite.prefix.flagged_committed` / `.flag_lost` | 40 / 20 (in 190 test runs; earlier build and its verifier) | `../build2/killsuite/prefix-earlier-build/results.json`, `README.md` | label "an earlier build"; that verifier accepted these folders | the suite's first commit, build-1 gateway and verifier |
| journal write failure | 5 of 5 repetitions: REJECTED (scope operation), stored REJECTED (scope call), restart, one commit; the verifier accepted each history as ANCHORED without a warning | `killsuite/journal_chronology.md`, `journal_chronology.json`; `killsuite/RESULTS.md` §7 | | journal-write-failure case |
| `conc.runs` / `conc.reps` / `conc.scen_reps` | 7 (2 with the race detector) / 260 / 1,820 | `concurrency/analysis/runs.tsv`, `scenario_repetitions.csv` | 8 or 32 callers; 33,040 calls | |
| `conc.conflict.committed` / `.rejected_call` | 260 / 4,460 | same, scenario `conflicting-reuse` | REJECTED/`operation_id_conflict`, scope `call` | |

## Table VI (request outcomes in flag mode)

Source: `misuse/misuse.csv` (one row per request; `category`, `grant`,
`class`, `status`), `misuse/misuse_by_category.md` (grouping made after the
run; labels unchanged, `misuse/misuse_category_map.csv`) and
`misuse/misuse_table.csv` (`mode=flag`). Flag mode, 3 repetitions,
identical, and identical in builds 1, 2 and 3. Columns: blocked (by a rule
or the grant) / allowed, flagged / allowed, no flag / invalid (refused while
parsing).

| row | n | blocked | allowed, flagged | allowed, no flag | invalid |
|---|---|---|---|---|---|
| legitimate | 29 | 0 | 1 | 28 | 0 |
| needing review | 10 | 0 | 10 | 0 | 0 |
| harmful, under a grant | 40 | 24 | 3 | 13 | 0 |
| covered by a rule or grant limit (content only 10, DEL-* only 11, both 3) | 24 | 24 | 0 | 0 | 0 |
| split payments within the budget (12 x AED 5,000.00) | 12 | 0 | 0 | 12 | 0 |
| wrong purpose (AED 4,999.99, allowed payee) | 1 | 0 | 0 | 1 | 0 |
| confidential near-copy or paraphrase (generic MSG-EXTERNAL flag only) | 3 | 0 | 3 | 0 | 0 |
| harmful, rerun without a grant (USD #7, #8 and releases #4, #5, which a grant blocked) | 4 | 0 | 0 | 4 | 0 |
| all harmful | 44 | 24 | 3 | 17 | 0 |
| malformed | 12 | 2 | 0 | 0 | 10 |

## In-text numbers of V-D

| key | value | file | field | population |
|---|---|---|---|---|
| cases / requests | 59 / 95; one expected outcome later revised (the comma case; no category changed) | `misuse/misuse.csv`; labels in `cmd/agentgate-eval/misuse.go` | | hand-written set |
| `misuse.rejected_noeffect` | 36 of 36 REJECTED answers without an effect (deny mode 50 of 50) | `misuse/misuse.csv`; `misuse/misuse_analysis.json` `modes.deny.status_contract` | REJECTED with `dispatched: false` | flag mode |
| flagged commits | 14 of 59 committed requests (10 needing review, 3 harmful, 1 legitimate) | `misuse/misuse.csv` | | |
| policy coverage | of 44 harmful, 40 under a grant: 24 blocked, 3 allowed with only the generic flag, 13 without a flag (12 split, 1 wrong purpose); 4 reruns without a grant all unflagged; 17 of 44 unflagged in all | `misuse/misuse.csv` (counted by `grant` and `class`); `misuse_analysis.json` `modes.flag.tallies.harmful.by_observed` = 24 / 3 / 17 | 17 = 13 under a grant + 4 reruns without a grant | 44 harmful requests (40 distinct kinds + 4 reruns of grant-blocked ones) |
| split payments | 12 x AED 5,000 = AED 60,000 within the grant's budget; the single AED 60,000 request was denied | `misuse/RESULTS.md` §3 | | |
| confidential text | 5 of 8 blocked by MSG-CONFIDENTIAL-TEXT; the 3 others allowed with only the generic MSG-EXTERNAL flag (the 3 flagged harmful requests) | `misuse/misuse.csv` | near-verbatim copies only; no information-flow claim | 8 external leak attempts |

## Table VII (cost per call and per audit append)

Paired rows: primary run R2 (least-loaded payment run), 500 paired trials.
The stage rows were moved out of the paper (they are in `SUPPLEMENTARY.md`
S6); the paper keeps the whole append and the witness update. The quoted
stage run is the one with the fewest appends over 10 ms (`per_call.appends_over_10ms`:
run1 0, run2 2, run3 8), so run1.

| row | value (ms) | file | field | population |
|---|---|---|---|---|
| checking (policy, grant, capability, receipts) | 3.14 [3.05, 3.25] | `baseline/analysis.json` (run `primary` = R2) | `runs.primary.paired_differences`, policy-only minus direct; `baseline/RESULTS.md` §2 | R2: 500 paired trials, 10 blocks of 50, seed 20261007, 10,000 resamples |
| signing and flushing the audit log | 11.77 [11.53, 11.95] | same | full minus policy-only | same |
| total of the two | 14.95 [14.73, 15.30] | same | full minus direct | same |
| operation journal | 3.77 [3.54, 3.89] | same | full+journal minus full | same |
| flagging (a request the policy flags) | 0.22 [0.07, 0.38] | same | full-flagged minus full | same |
| encode, hash and sign (entry and head), mean | 0.08 (83.0 us: encode+hash 42.7, signing 40.3) | `baseline/stagecost/run1/stagecost.json` `groups`; `baseline/stagecost/summary.csv` rows `run1` | archive S6 | `TestStageCost` run1, 10,000 appends (separate instrumented benchmark) |
| log line write and flush, mean | 0.45 (445.1 us: write 10.8, fsync 434.3) | same | archive S6 | same |
| head: temporary file write, flush and rename, mean | 1.23 (1,229.3 us: 209.2 + 770.9 + 249.2) | same | 69.9 % of an append | same |
| directory flush | none on Windows (0.1 us, the call returns at once) | same | archive S6 | same |
| one audit append, mean (six per call) | 1.75 (1,751.3 us) | `stagecost.json` `append_uninstrumented` | staged total 1,757.5 us | same |
| witness update, head save per call, mean, not in timings | 2.2 (run3 means: push 1.26 + save 0.96) | `baseline/stagecost/run3/witnesspush.json` `rows`; `baseline/RESULTS.md` §7 | medians 1.21 + 0.93 | `TestWitnessPushCost` run3 (no disk slowdown), 2,000 updates |

## In-text numbers of V-F

| key | value | file | field | population |
|---|---|---|---|---|
| `baseline.runs` / `baseline.calls` | six runs (R1-R5 payments, M1 messages), 62,500 calls, none failed or dropped | the observation CSVs of the six runs (`baseline/`, `baseline/repeats/R*/`, `baseline/message/`) | 0 of 62,500 measured and 0 of 4,100 warm-up calls failed | the 62,500 are the total over six runs |
| `baseline.trials` | 500 paired trials (Table VII) | `baseline/analysis.json` `runs.primary` | | R2 |
| `baseline.p99.1` / `baseline.p99.16` | 24.58 / 238.28 ms (five-run medians) | `baseline/analysis.json` `runs.*.concurrent[config=full, clients=1\|16].p99_us`; `baseline/RESULTS.md` §4 | R2 alone 32.31 / 194.97; R2's sequential p99 21.86 ms | median of R1-R5, closed loop |
| `baseline.recorded.calls_s` | 88.2 calls/s from 4 clients on (five-run median) | `baseline/analysis.json` | pooled median of 15 cells (R1-R5 x 4 / 8 / 16 clients) | R1-R5 |
| `stage.append.mean` / `stage.ceiling` | 1.75 ms / about 95 calls/s (1 / (6 x 1.75 ms)) | `baseline/stagecost/run1/stagecost.json` | six flushed appends per call, one at a time (no group commit) | stage run1 |
| `baseline.recorded.mean16` | Little's law 16 / 92.70 = 172.6 ms predicted, 170.3 ms observed mean | `baseline/analysis.json`, `baseline/baseline.json` | R2 at 16 clients: `throughput_calls_per_s` 92.70 | R2 only (the run of Table VII; within 1.7 % in every full cell) |
| `stage.head` vs `stage.log` | 1.23 > 0.45 ms | as Table VII | replacing the head costs more than flushing the log line | stage run1 |
| `stage.cpu` share | 83.0 / 1,757.5 = 4.7 % of an append ("computation 5 %") | `baseline/stagecost/run1/stagecost.json` | | stage run1 |
| `baseline.alloc_per_call` / `baseline.peak_ws` | 3,040 KiB per call (full) / peak working set at most 87.6 MiB | `baseline/analysis.json` | allocation volume is not resident memory (archive S6) | 1 client, five-run median / process-wide maximum |
| storage | consumer 2 TB NVMe SSD, NTFS, 4,096-byte clusters, 97.5 % full; write-cache setting not determinable without administrator rights; Defender real-time protection on | `baseline/RESULTS.md`; `RESULTS_BUILD3.md` §0.4 | | |
| flagging added under 0.4 ms in every build | build 1 -0.27, build 2 -0.07 [-0.13, 0.01], build 3 0.22 [0.07, 0.38] | `baseline/RESULTS.md` §2; `baseline/comparison-builds.csv` | | primary runs |

## V-E (verifier robustness, mutants of three other kinds, partial Python verifier) and VII L4

Each mutation score names its test set. Full suite = every test. "Without
the 16 tests added late" = the skip pattern of `docs/demo/VERIFIER_CHECKS.md`
§6 (`kill_score_without_posthoc.json`). "Without the 24" = without the 4
tests added late in build 1 and the 20 tests written after build 2's lists
of undetected mutants were published (variant v2d of `heldout/`).

| key | value | file | field | population |
|---|---|---|---|---|
| `robust.fuzz.inputs` | 33,639,381 inputs, 0 crashes or failed properties | `robustness/fuzz_summary.json` | | 3 targets, 5 runs x 120 s, 12 workers |
| `robust.kill.full` | 150 of 150 deletions of a line that makes a check fail detected | `robustness/kill_score_full.json` `sites`, `killed` | | 150 lines in a 100-file source copy of `8a30fd4`; full suite |
| `robust.nolate` | 63 of 150 = 0.420 | `robustness/kill_score_without_posthoc.json` | the four-test pattern gives 73/150 (`kill_score_without_posthoc4.json`, archive only) | same lines; without the 16 tests added late |
| `robust.late` | 16 = 4 tests from the first list + 12 added since | `robustness/kill_score_without_posthoc.json` `skipped_tests`; `docs/demo/VERIFIER_CHECKS.md` §6 | the list: `robustness/RESULTS.md` §1 | |
| `heldout.full` (v1) | 212 of 385 = 0.551 (delete a reported problem 106/177, shift a boundary 60/132, force a comparison equal 46/76) | `heldout/heldout_summary.json` `v1_full/<operator>` | | one mutant per place in the non-test `.go` files directly under `internal/auditverify` (not `fixture/`, `tools/`); full suite |
| `heldout.nolate` (v2d) | 130 of 385 = 0.338 (59/177, 53/132, 18/76) | `heldout/heldout_summary.json` `v2d_without_posthoc4_new20/<operator>` | the rule fixed in advance (section 0 of the frozen definitions) asks for this one | same mutants; without the 24 tests written after lists of undetected mutants existed |
| `heldout.late` | 24 = 4 + 20 | `heldout/test_names.json`; `heldout/new20_kills.json` | | |
| other test sets (archive only) | without the 4: 196/385 = 0.509; without the 7: 190/385 = 0.494; without the 16: 174/385 = 0.452; build 1's verifier and its own suite (`f01d1c9`), without the 4: 111/336 = 0.330 | `heldout_summary.json` `v2_without_posthoc4/*`, `v2b_without_posthoc7/*`, `v2c_without_posthoc16/*`, `v3_f01d1c9/*` | | |
| `robust.cov` | 91.6 % (3,935 of 4,295 statements) | `robustness/coverage_summary.json` | 87.5 % without the 16 tests added late | `internal/auditverify` + `cmd/agentgate-verify`, full suite |
| `robust.unexec` / `robust.cond` (VII L4) | 29 of 336 failure conditions never reached by tests or fuzzing; all 29 are problem lines (29 of 177) | `robustness/refusal_conditions.json` `counts`, `by_kind` | 336 = 150 fail + 9 warn + 177 problem lines (8.6 %) | |
| coverage map per check | 38 checks; every line that makes a check fail executed and detected by the full suite; 6 checks with no line detected without the 16 tests added late; the 29 never-reached conditions belong to 11 checks | `robustness/coverage_map.md`, `coverage_map.csv`, `coverage_map.json` (archive S14) | | |
| `subset.check_ids` | parts of 15 of the 38 checks: `files.present`, `keys.hash`, `files.run_record`, `chain.entry_hash`, `chain.signature`, `chain.links`, `head.signature`, `head.matches`, `keys.anchor`, `head.anchor`, `artifact.signature` (capabilities and adapter receipts only), `op.requires_policy`, `op.capability_bound`, `op.receipts_bound`, `policy.snapshot_bound` | `docs/paper/artifact/SUBSET_VERIFIER.md` "What the subset checks" | not covered: `policy.replay`, six `delegation.*`, `provider.signature`, `provider.state_chain`, `provider.matches_audit`, `op.outcome_resolved`, `op.approval_bound`, `op.requires_validation`, `op.single_use`, `op.no_effect_when_refused`, `artifact.effect_digest`, `artifact.effect_readable`, `keys.valid`, `files.run_id`, `chain.time`, `files.continuity`, `head.witness`, and the build-3 rules (and `verifier.error`, its own crash report) | |
| `subset.agree` / `subset.total` | 296 / 296 | `subset-corpus/subset-result.json` `summary.agree`, `summary.verifications` | | 74 folders (2 clean + 16 tamper-lab + 56 mutants) x 4 anchors; corpus fixed before any Python run |
| `subset.binding_folders` / `go_detected` / `go_accepted` / `flips` | 42 / 26 / 16 / 6 | same, `summary.binding_relevant`, `summary.binding_flips_go` | the same 6 pairs changed by binding in both implementations (archive only) | 42 binding-relevant folders |
| vectors | 80 checks pass (encodings, signatures, log chaining only) | `docs/paper/artifact/check_vectors.py` output | | |
| `verifier.check_ids` | 38 | `docs/demo/VERIFIER_CHECKS.md`; `robustness/check_counts.json` | | |

## VII Limitations

| key | value | source |
|---|---|---|
| L4 field edits | 45 of 62 detected with exactly the expected checks; 17 accepted, touching fields no check reads (S11) | **go test** SF; `fixture-studies/signed_fields.csv`; `docs/demo/FIELD_CHECK_MAP.md` "Unchecked fields at a glance" |
| L4 never-reached failure conditions | 29 of 336 | `robustness/refusal_conditions.json` |
| L6 status reply date | the verifier now refuses a reply dated more than 5 s after its entry, or, for a commit, more than 5 s before its capability (dated 2027 and dated 2030: detected); a reply that reports no commit may be dated any time before | **go test** `TestReconciledStatusDate` (10 cases: 5 refused, 5 accepted); `fixture-studies/round5_cases.csv` |
| L6 status window; capability step | 2 min to the nanosecond; a step below the registry's last reading stops issuance; a 61 s jump between issue and use stops dispatch | **go test** `fixture-studies/RESULTS.md` §3; S13 |
| L8 split payments | 12 | Table VI |

## VIII Conclusion and Artifact Availability

| key | value | source |
|---|---|---|
| conclusion: binding changed outcomes | 0 of 336 (0 of the 168 without a head anchor); 12 of 336, all among the 168 | headline rows |
| `manifest.sha256` | `0c436fc9fec8989638dccf4d3e62d609ec033a884d421b659f7ed820886968eb` (paper: first 16 hex digits `0c436fc9fec89896`) | `build-manifest.README.md`; `RESULTS_BUILD3.md` §0.1 |
| `archive.sha256` | printed by `build_artifact.py` and written next to the zip as `<zip>.sha256` (the archive cannot contain its own digest); the full digest goes on the submission form | submission form |
| `quick.minutes` | about 2 min: `README.md`, "Quick check" | README |

## Build-3 checks

The checks and the witness registration that build 3 added (paper III-E),
with the evidence for each. All rows are **go test** except where a data
file is named.

| check | rule | evidence | population |
|---|---|---|---|
| status reply date (`op.outcome_resolved`) | a signed status reply must be dated no later than 5 s after its entry and, for a commit, no earlier than 5 s before its capability was issued | `TestReconciledStatusDate`: 5 refused, 5 accepted; on genuine evidence 0 of 640 RECONCILED entries outside the bounds (`crash/RESULTS.md`), 0 of 115 rejected (`killsuite/reconciled_dates.md`), 260 of 260 pass (`concurrency/RESULTS.md`) | 10 fixture cases |
| status reply order (`op.outcome_resolved`) | a reconciled commit needs an unresolved status or a restart in the log; the reconciling call's own answer is no reason | `TestReconciledNeedsAReason`: 6 refused, 8 accepted; crash 480 of 480 genuine reconciliations have a reason | 14 fixture cases |
| unresolved operations (`op.outcome_resolved`, run completeness) | an operation with a verified capability and no outcome is reported unresolved, with a warning, and the run is incomplete | `TestPendingCapabilityIsIncomplete`: 4 reported, 4 controls, 2 refused; process-kill tests: warning in 100 of 365 folders, `run_complete` fail 115 (`killsuite/RESULTS.md` §5) | 10 fixture cases |
| capability key confirmation (`op.capability_bound`) | the capability's `cnf` must name the key that signed the adapter receipt | `TestCapabilityConfirmationKey`: 7 refused, 1 control; SF 2 more; genuine evidence 1,680 of 1,680 (crash), 3,640 of 3,640 (concurrency) | 8 fixture cases |
| witness continuation linkage (`head.witness`) | the witness run status's `continues` field must match the folder's segments | `TestWitnessStatusContinuationLinkage`: 7 refused, 3 controls | 10 fixture cases |
| earlier-segment keys (`keys.anchor`) | a keys anchor of the newest segment no longer anchors earlier segments' keys; they need their own keys anchor (`--expect-earlier-keys`), a head anchor or the witness | `TestEarlierSegmentKeysAnchor`, `TestEarlierSegmentKeyPinsRefused`; a made-up earlier segment is accepted with the newest keys anchor alone and reported as not anchored (gap, Table II P2/P3 text) | 17 fixture cases |
| registration with the witness | the witness accepts a registration or a continuation only if it is signed with an enrollment key; the verifier accepts only a witness key given in advance | `custody/repeats_summary.json`: 200 of 200 unsigned registrations refused; s3a 19 of 19 refused, 1 of 1 forged with the enrollment key ANCHORED; s3c 68 refusals | 20 multi-process runs; fixtures |
| run status v2 | the witness's signed run status names the enrollment key (`enrollment_kid`) | multi-process runs 40 of 40 v2; `TestWitnessStatusEnrollmentKID`, `TestWitnessRunStatusV2`: 17 refused, 4 accepted, 1 control | |

## Real-key tests (go test)

Every paper number that rests on the real-key tests, with the test that
asserts it. Run: `go test -count=1 -v -run 'TestRound4|TestResignHeld' ./internal/auditverify/`
(10 top-level tests, 77 subtests; `fixture-studies/logs/s7-round4.gotest.log`).

| paper location | number | test (file) | population |
|---|---|---|---|
| V-A: real keys matched the simulation | 336 of 336 exact (verdict, assurance, failing checks with counts) | `TestRound4RealSignaturesAgreeWithSimulation` (RS; `round4_signed_attacks_test.go`) | 34 cases x 4 settings x 3 anchors = 408 fixture results, 888 verifications; exact on the 28 cases (336) the simulation can express |
| V-A: the simulation overstates one adapter key | 72 fixture results bracketed 72/72; the simulation with one adapter role accepts 40, real keys 0 | RS | the 6 partial-adapter cases |
| V-A: untouched unsigned records | 240 of 240 exact; no signature check failing; 24 accepted (unbound M1, no replay); 80/80 head detected; 14 detected cases VERIFIED once the binding checks are off | `TestRound4RationalAttackerBinding` (RB) | 20 cases, 240 fixture results, 494 verifications |
| V-A, Table I: lifecycle | 420 of 420 exact; 120 accepted, none with a head anchor | `TestRound4LifecycleRealVsSimulation` (LR; `round4_lifecycle_test.go`) | 35 cases, 420 fixture results, 840 verifications |
| V-A, Table I: lifecycle, untouched unsigned records | 156 of 156 exact; no signature check failing; 52/52 head detected; with the binding checks off 4 VERIFIED, 9 still fail one provider-side check | `TestRound4LifecycleRationalAttacker` (LRR) | 13 cases, 156 fixture results, 325 verifications |
| III-D, V-A: histories | 12 of 15 detected, 3 accepted and reported; no replay gives the same 15/15 | `TestRound4LifecycleHistories` (LH) | 15 histories, full verifier, keys anchor |
| Table I row 6 | denial restated with A: detected (`policy.replay`) in full and nsb, accepted as `audit_only` in no-replay and nrns | `TestRound4NoCapabilityReclassifiedInPlace` (NC) | 1 case x 4 settings |
| Table II, VII L4 | 45 detected (15 effect, 7 classification, 11 provider, 12 approval), 17 accepted (5 / 0 / 7 / 5); first-commit `state_before_hash` accepted | `TestRound4ValidlySignedInconsistentFields` (SF; `round4_signed_fields_test.go`) | 62 single-field edits, full verifier, keys anchor |
| V-A: 1,196 results | 44 + 336 + 240 + 420 + 156 | SA, RS, RB, LR, LRR (derived) | |
| helper safety (README) | an unedited run comes back byte-identical (2 fixture modes); every refusal leaves the folder unchanged | `TestResignHeldLeavesAGenuineRunUnchanged`, `TestResignHeldRefusesNonFixtureKeys` | |
| totals | 10 top-level tests, 77 subtests, 0 failures | `go test -v` log | |

## Version crosswalk, builds 1-3

The paper's "Versions and counting" paragraph and archive S17 in one table:
every value that differs between builds, with its unit, denominator and
cause. Source: `RESULTS_BUILD3.md` §3 (and `../build2/RESULTS_BUILD2.md`
§0.3, `../revision/RESULTS_REVISION.md` for builds 1 and 2). Causes: *new
code* (verifier, witness or build code changed), *changed tests* (tests
added or changed), *counting rule* (a changed pattern, unit or summary
statistic), *new measurement* (the value moved without a code, test or rule
change, for example machine state), *correction* (an earlier number or
wording was wrong).

| build | date | source | identified by |
|---|---|---|---|
| build 1 | 2026-10-08 | five binaries; compiled files equal commit `2d32506` | manifest SHA-256 `188f83bd...121e` (1,809 entries) |
| build 2 | 2026-10-10 | six binaries from commit `86643d7` (working tree, not reproducible) | manifest SHA-256 `841a7c6f...b658` (1,868 entries) |
| build 3 | 2026-10-20 | six reproducible binaries from `git archive 8a30fd4` | manifest SHA-256 `0c436fc9...6968eb` (1,870 entries) |

| quantity | unit and denominator | build 1 | build 2 | build 3 (paper) | cause | file and field (build 3) |
|---|---|---|---|---|---|---|
| changed by binding, full verifier | attacks, strongest attacker, the same in 10/10 repetitions; 336 per setting = 168 without + 168 with a head anchor | 0/336 | 0/336 (0/168 without a head anchor) | 0/336 (0/168; 0/168 with a head anchor) | none: all 51,840 result rows equal in the three builds; printing the 168 half is a counting rule | `compromise/flips_by_anchor.csv` |
| changed by binding, no replay | as above | 12/336 | 12/336 (12/168 without, 0/168 with) | 12/336 (12/168 without, 0/168 with) | none; the same 12 attacks (6 pairs x 2 anchor conditions) | same |
| changed by binding, no snapshot check | as above | 8/336 | 8/336 (8/168) | 8/336 (8/168) | none | same |
| detections per design | attacks, of 336 and of each 168 | 313/313, 313/305, 295/283 | same | same | none | `compromise/strongest.csv` |
| lines that make a check fail, detected by the full suite | lines (one deletion mutant each) | 139/139 | 142/142 | 150/150 | new code: 3 lines in build 2; 9 added and 1 removed in build 3 | `robustness/kill_score_full.json` |
| the same without the tests added late | lines; the pattern is named | 51/139 (4-test pattern) | 56/142 (7-test); 58/142 (4-test) | 63/150 (16-test); 71/150 (7-test); 73/150 (4-test) | counting rule (4 -> 7 -> 16 tests), changed tests, new code | `robustness/kill_score_without_posthoc*.json` |
| failure conditions never reached | fail, warn and problem lines; reached by the full suite or any fuzz input | 44/299 | 47/313 (142 fail, 7 warn, 164 problem) | 29/336 (150 fail, 9 warn, 177 problem) | new code (+14, then +25 conditions), changed tests, new measurement (fuzz variation) | `robustness/refusal_conditions.json` |
| statement coverage | verifier statements, full suite | 89.9 % | 90.6 % (3,703/4,085) | 91.6 % (3,935/4,295) | new code, changed tests | `robustness/coverage_summary.json` |
| fuzz inputs | executions, 3 targets, 5 runs x 120 s | 40,542,369 | 34,178,449 | 33,639,381 | new measurement (loaded machine; not comparable) | `robustness/fuzz_summary.json` |
| checks | documented check IDs | 38 | 38 | 38 | none | `robustness/check_counts.json` |
| mutants of three other kinds, full suite | mutants; detected / all, build errors and timeouts left out (0) | not run | 144/358 = 0.402 | 212/385 = 0.551 | changed tests (44 more detected by the 20 tests written after build 2's lists were published), new code (+29, -2 places) | `heldout/heldout_summary.json` `v1_full` |
| the same without the tests written after lists of undetected mutants existed | as above | not run | 127/358 (without 4) | 130/385 (without 24; v2d) | counting rule (the 20 newer tests also left out) and new code; on the 356 places builds 2 and 3 share, exactly build 2's result (125 detected) | `heldout_summary.json` `v2_without_posthoc4`, `v2d_without_posthoc4_new20` |
| build 1's verifier and its own suite | as above, without the 4 | 111/336 (measured in build 2) | 111/336 | 111/336 | none (identical on all 336 mutants) | `heldout_summary.json` `v3_f01d1c9` |
| signing and flushing the audit log | ms per call, paired median, 500 trials, block 95 % CI | 11.40 [11.35, 11.47] (R3) | 11.29 [11.19, 11.43] (R2) | 11.77 [11.53, 11.95] (R2) | new measurement: no code on the timed path changed; build 3: Defender platform update, more background CPU, more drive slowdowns (ten runs of the same build-3 binary: 11.27-12.03) | `baseline/analysis.json` |
| checking / total / journal / flagging | as above | 3.32 / 14.69 / 3.20 / -0.27 | 3.18 / 14.46 / 3.43 / -0.07 | 3.14 / 14.95 / 3.77 / 0.22 | new measurement | same |
| throughput from 4 clients on | calls/s, pooled median of 15 cells (R1-R5 x 4, 8, 16 clients) | 94.3 (per client count 94.2-94.4) | 92.5 | 88.2 | new measurement; disk 96 % -> 97.4 % -> 97.5 % full; build 1's text quoted per-client-count medians | `baseline/analysis.json`; `baseline/comparison-builds.csv` |
| Little's law at 16 clients | ms, R2 | -- | printed 173 / 170 (mixed runs) -> 171.8 / 169.6 | 172.6 / 170.3 | correction (build 2), new measurement (build 3) | `baseline/analysis.json`, `baseline.json` |
| one audit append | ms, mean of the quoted stage run | -- | 1.70 (run2) | 1.75 (run1) | new measurement (byte-identical test binary) | `baseline/stagecost/run1/stagecost.json` |
| witness update per call | ms, run3 means | -- | 2.4 | 2.2 | new measurement | `baseline/stagecost/run3/witnesspush.json` |
| re-dispatch in the process-kill tests | test runs | -- | printed 0 of 235 -> 0 of 195 | 0 of 195 | correction (unit) | `killsuite/results.json` |
| unflagged harmful requests | harmful requests | 17/44 | 17/44 = 13/40 + 4 | 17/44 = 13/40 + 4 | none (misuse identical in all builds); both sets printed | `misuse/misuse.csv` |
| flag lost after kills | flagged commits | 20 of 40 in 190 test runs (earlier build) | 0 of 45 in 195 | 0 of 45 in 195 | new code (bug fixes before build 2) | `killsuite/results.json` |
| validly signed field edits accepted | single-field edits, real keys | -- | 18/59 | 17/62 | new code (`cnf` check, status date: 4 edits now detected) and changed tests (+3 edits) | `fixture-studies/signed_fields.csv` |
| status reply dated 2027 | fixture, A + status | accepted | accepted | detected (FAILED 4/4) | new code | `fixture-studies/lifecycle.csv` |
| first registration with the witness | unsigned registrations | anchored | anchored | refused (200/200; 19/19) | new code | `custody/repeats_summary.json`; `fixture-studies/registration_enrollment_cases.csv` |
| operations with a capability and no outcome reported without a warning | operations | -- | 10 | 0 (reported unresolved; warning in 100 of 365 folders) | new code | `killsuite/RESULTS.md` §5 |
| journal-failure answers | operations; REJECTED answers | -- | 5; 10, then one commit each | the same, with the chronology (scope operation, then the stored answer with scope call) | explained (new measurement of the chronology) | `killsuite/journal_chronology.md` |
| real-key agreement | results where the simulation can represent the key set | -- | 1,152 (written after the build-2 freeze) | 1,196 (44 + 1,152) | changed tests (part of build 3's commit) | `fixture-studies/RESULTS.md` §2.1 |
| oracle agreement | labelled results, full verifier | 514/560; 540/560 | same | same | none | `compromise/oracle_agreement.csv` |
| replacement keys | edit-design pairs | 8/14 none, 14/14 with an anchor | same | same | none | `compromise/replacement_keys.csv` |
| multi-process runs | rollback, keyless edits, head_fresh, run_complete | as build 2 | 20 runs; 140/140; 180/180 | same; plus 200/200 registrations refused | new code (registration) | `custody/` |

**Per cause.** *Counting:* the 0, 8 and 12 changed outcomes of 336 all lie
among the 168 attacks without a head anchor, because a head anchor detected
the rest; printing both halves changed no count. *New code (build 1 -> 2):*
the flag in recovery records and stored answers, the two bug fixes, three
new lines that make a check fail, the process-kill tests
(`../build2/RESULTS_BUILD2.md` §0.3). *New code (build 2 -> 3):* the status
date and order rules, unresolved operations reported, the capability `cnf`
check, the earlier-segment keys rule, registration with the witness and run
status v2, the reproducible build (`RESULTS_BUILD3.md` §0.3, ten numbered
changes). *Changed tests:* tests added for the real-key study and for the
build-3 checks detect and reach more of the old lines. *New measurement:*
costs and throughput come from separate sessions as the disk filled and the
virus scanner changed; the timed code did not change. *Correction:* two
build-2 values first mixed runs or units (Little's law; re-dispatches).

## SUPPLEMENTARY S1 (implementation size)

| key | value | file |
|---|---|---|
| `loc.*` | five binaries: 87,174 non-test code lines in 217 files (enforcement path 22,517; provider and witness 2,634; verifier 8,965; demo, UI and harness 17,212; linked persistence code 25,521; other linked support 10,325). With the process-kill test program (3,797 lines, 11 files): 90,971 in 228 files | `docs/paper/artifact/loc_build3.csv` (counted 2026-10-21 on the build-3 tree with `docs/paper/response/tcb/tcb_loc.py`; build 2: 86,138 / 215 files, six binaries 89,935 / 226) |
