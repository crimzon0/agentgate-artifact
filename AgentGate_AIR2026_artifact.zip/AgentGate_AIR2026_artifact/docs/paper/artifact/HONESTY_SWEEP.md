# Honesty sweep of the archived documents (2026-10-10)

Before the archive digest is taken, every archived Markdown document was
searched for wording that can claim more than the evidence shows:

```
grep -n -i -E "need|took|proof|fresh head|three keys|of 336|independent|re-signs|misread|every member necessary|consent artifact|crash safe|power-loss test" FILE
```

**Files searched (39):** `docs/paper/data/build2/RESULTS_BUILD2.md` and
every `docs/paper/data/build2/*/RESULTS.md` (11) plus
`killsuite/prefix-earlier-build/README.md`;
`docs/paper/data/revision/RESULTS_REVISION.md` and every
`docs/paper/data/revision/*/RESULTS.md` (7);
`docs/paper/data/revision/robustness/HELDOUT_OPERATORS.md`;
`docs/paper/data/revision/baseline/STAGE_COST.md`;
`cmd/agentgate-killsuite/README.md`; every `docs/demo/*.md` (8); every
`docs/paper/artifact/*.md` except this log (8).

**Rule.** A living document (specification, guide, archive document) was
fixed in place, with "corrected 2026-10-10" where the change is not obvious.
A frozen record (an experiment's results as written, the pre-registered
held-out operators, the 2026-10-07 revision contract) kept its text: a dated
correction note was added at the top instead. 337 lines carry a hit after
the fixes; each is listed below, under a fix, a correction note or the
reason it was kept.

## 1. Fixed in place

| file | what it said | what it says now |
|---|---|---|
| `docs/paper/data/build2/RESULTS_BUILD2.md` §2.1 | "flag edits need audit+issuer+adapter, every member necessary; change-amount needs ...; the delegation key is never needed" | the smallest tested key sets that passed (receipt path, not a proof); every smaller tested set was detected |
| `RESULTS_BUILD2.md` §3.2 (major 6) | quoted FIELD_CHECK_MAP's "redundant (honest provider)" reason | notes the 2026-10-10 rename to "provider accounting" (the provider is a role an attacker may hold) |
| `RESULTS_BUILD2.md` §4.1 item 6 | "flag edits of an executed operation need audit+issuer+adapter" | "passed only with" (the smallest tested set, not a proof) |
| `docs/paper/data/build2/baseline/RESULTS.md` §9 | the p50 change explained by "Little's law" | Little's law relates the mean latency |
| `docs/paper/artifact/SUBSET_VERIFIER.md` "Binding-relevant rows" | "with the issuer and adapter keys the attacker re-signs whatever the binding checks" | the simulation skips the issuer and adapter signature checks; nothing is re-signed |
| `SUBSET_VERIFIER.md` "What an agreement shows" | "which classification edits need the issuer and adapter keys" | "accepted only when the issuer and adapter signatures are also assumed compromised" (smallest tested key set) |
| `SUBSET_VERIFIER.md` "Not in the subset", "How to run", "Status" | no mention of build 2's new Go rules; "the archive does not contain these files yet"; smoke-test numbers only | the build-2 rules the subset does not port; the files are in the archive; the final build-2 run (296/296, 42/42, manifest `a9f9d178...`) |
| `docs/demo/VERIFIER_CHECKS.md` dimensions table | `run_complete` asks for a "fresh head" | "a fresh signed run status" |
| `VERIFIER_CHECKS.md` "Lifecycle states" | "which keys ... an editor needs" | "were the smallest tested set that let an editor pass (tested, not proved)"; this header also qualifies the "needs" in the table's cells (lines 197, 199) |
| `VERIFIER_CHECKS.md` "Two kinds of `issuer_adapter`" | "those that need A+I+X" | "those whose smallest tested key set is A+I+X" |
| `VERIFIER_CHECKS.md` §1 lifecycle notes | did not say that a conversion and a genuine recovery look alike | the verifier neither dates the status observation nor requires a preceding unresolved status, so it reports an unjustified conversion and a genuine recovery alike as issuer-only |
| `VERIFIER_CHECKS.md` §6 | build 1's robustness numbers (139 sites, 0.367, 44/299, 9 checks) "not re-measured"; the recovery-flag site's killing tests incomplete | build 2's numbers (142 sites, 56/142 = 0.394 with the seven-test pattern, 47/313, 7 of 38 checks; held-out 144/358); the site is also killed by `TestUnboundFlagsTextsNameTheLogNotTheCapability` |
| `docs/demo/FIELD_CHECK_MAP.md` | reason "redundant (honest provider)": "the provider is trusted not to lie (provider compromise is out of scope)" | reason "provider accounting": a provider-key holder can make these fields disagree with the effect digest undetected; provider-key results rest only on the receipt signature, effect digest and journal matching |
| `FIELD_CHECK_MAP.md` | header "unchanged since the frozen build of 2026-10-08"; adapter receipt "only on EFFECT_EXECUTED"; CALL_RESULT flag only for the executing call; `observed_at` "not needed"; `head_fresh` "not built"; witness `continues` "redundant"; "P3 already needs the adapter key" | build-2 rules (receipt on RECONCILED, flag on replayed and reconciling answers and on RECONCILED); `observed_at` deferred (dated 2027 accepted; no preceding unresolved status required); freshness reported, not enforced; `continues` never compared; a "Never compared" list (row, state-delta, request-digest and idempotency hashes, `observed_at`, `cnf`, `continues`, tenant, approver); "P3 rests on the adapter-signed effect digest" |
| `docs/demo/ARCHITECTURE.md` §3 | "Removing or inventing a flag therefore needs the capability issuer's and the adapter's keys as well as the audit key" | accepted, among the tested key sets, only with those keys for an operation executed with an adapter receipt; through reconciliation the audit and issuer keys sufficed |
| `ARCHITECTURE.md` §5 | "a second, independently signed record" | "a second record, signed with the provider's own key" |
| `ARCHITECTURE.md`, `PRESENTER_GUIDE.md`, `GLOSSARY.md` | "seven dimensions"; head anchor "fresh if fetched from the witness when verifying" | seven dimensions plus two derived (freshness, run completeness); VERIFIED is the legacy verdict; freshness defined as in the paper (a live run status dated within 2 minutes of fetching); new glossary rows: freshness, run completeness, classification evidence, receipt and reconciliation paths, cell run, fixture, structural attack model |
| `PRESENTER_GUIDE.md` "Run log" | "you cannot remove, reorder or edit a line without it showing ... the log contains its own proof" | "without the audit key nobody can ...; with the audit key, only an anchor held elsewhere exposes it"; "its own signed evidence" |
| `PRESENTER_GUIDE.md` closing | "the evidence can be verified independently" | "checked offline by a separate verifier that imports no gateway code" |
| `cmd/agentgate-killsuite/README.md` | the parent "starts a fresh provider in its own process" | "inside its own (the parent's) process, not `agentgate-provider`" |
| `docs/demo/CONTRACTS.md` "Agent results and operation status" | finality of an operation-scope REJECTED after a lost journal write not stated as such | new paragraph: `aborted_before_send` is scope `operation` and final only once its outcome record is journaled; after a lost journal write a restarted gateway may commit the key once, and the verifier accepts that history without a warning (kill suite: 10 REJECTED answers followed by a commit) |

Already correct when checked (no change): `CONTRACTS.md` CALL_RESULT row
(replayed COMMITTED answers carry the flag) and the reservation rule (only
an operation-scope REJECTED releases it); `VERIFIER_CHECKS.md` pending
class (a pending operation with a capability is `issuer_only_no_effect`, no
warning, ignored by `run_complete`; only "pending before a capability" is
`audit_only`; the "no capability" row now says so explicitly) and the two
kinds of `issuer_adapter`; the build-2 copies of
`docs/paper/data/build2/crash/cli_crosscheck.py` and `cells.py`, which
already compare Missing entries kind by kind (freshness handled) and report
the derived dimensions separately (840/840 agree with and without pins). The
build-1 copies under `docs/paper/data/revision/crash/` are left as they were:
they belong to build 1's output, which has no Missing kinds. Kill-suite
acceptance: flag preservation is reported, not part of the acceptance
verdict; the suite's README and the archive README say so.

## 2. Correction notes added at the top (record unchanged)

| file | what the note corrects |
|---|---|
| `docs/paper/data/revision/RESULTS_REVISION.md` (build 1) | key-set "needs / necessary / minimal" = smallest tested set, receipt path only; X = three adapter keys, one process; "independent oracle" = same authors, written without opening the verifier; "independent Python checker" = second implementation of the encodings, 80 checks; "of 336" includes 168 head-anchored cells |
| `docs/paper/data/revision/compromise/RESULTS.md` (build 1) | the same key-set wording ("every member necessary", "keys never needed"), "independent oracle", "of 336" |
| `docs/paper/data/build2/compromise/RESULTS.md` | the same key-set wording; flips stated over 168 cells in the paper |
| `docs/paper/data/build2/fixture-studies/RESULTS.md` | "keys needed" = smallest key set the fixture tests tried; X only in the simulation |
| `docs/paper/data/build2/RESULTS_BUILD2.md` | the same key-set wording in quotations from the experiment files (three own sentences fixed in place) |
| `docs/paper/data/revision/baseline/RESULTS.md` (build 1) | Little's law relates the mean, not the p50 |
| `docs/paper/data/revision/robustness/HELDOUT_OPERATORS.md` (frozen, commit `be5e88c`; SHA-256 before the note `6337730a...6b59`) | §7.10 presents as found "two unflagged H3 sites that a line join misreads"; in the campaign data both sites have their own coverage block, ran and were killed, so a line join gives the same answer there: a possible misreading, not a measured one |
| `docs/demo/REVISION_CONTRACT.md` (2026-10-07) | "the attacker re-signs exactly what its keys allow": as built, a structural simulation, nothing re-signed; "independently written oracle" = same authors |

## 3. Kept, with the reason

**negation: "not a proof", "not independent", "never call it independent"** (54 lines): `docs/demo/ARCHITECTURE.md` 169, 390; `docs/demo/GLOSSARY.md` 39, 46; `docs/paper/artifact/README.md` 66, 381; `docs/paper/artifact/SCHEMAS.md` 23; `docs/paper/artifact/SUBSET_VERIFIER.md` 12, 14, 80; `docs/paper/artifact/SUPPLEMENTARY.md` 9, 45, 709; `docs/paper/data/build2/RESULTS_BUILD2.md` 5, 270, 361, 621, 1023, 1431, 1557, 1560, 1561, 1625, 1692; `docs/paper/data/build2/compromise/RESULTS.md` 4, 435; `docs/paper/data/build2/concurrency/RESULTS.md` 49, 381; `docs/paper/data/build2/crash/RESULTS.md` 256, 315; `docs/paper/data/build2/fixture-studies/RESULTS.md` 5; `docs/paper/data/build2/killsuite/RESULTS.md` 341, 344; `docs/paper/data/build2/misuse/RESULTS.md` 224, 292; `docs/paper/data/build2/robustness/RESULTS.md` 346; `docs/paper/data/build2/subset-corpus/RESULTS.md` 13, 232, 234, 235; `docs/paper/data/revision/RESULTS_REVISION.md` 4, 6, 175, 1006, 1010; `docs/paper/data/revision/compromise/RESULTS.md` 4, 187; `docs/paper/data/revision/concurrency/RESULTS.md` 30, 273; `docs/paper/data/revision/crash/RESULTS.md` 169, 213; `docs/paper/data/revision/misuse/RESULTS.md` 159, 241; `docs/paper/data/revision/robustness/RESULTS.md` 186.

**technical term: extension proof, proof of possession** (9 lines): `docs/demo/ARCHITECTURE.md` 166, 275, 304; `docs/demo/CONTRACTS.md` 691; `docs/demo/PRESENTER_GUIDE.md` 598; `docs/demo/VERIFIER_CHECKS.md` 117, 456; `docs/paper/data/revision/RESULTS_REVISION.md` 856; `docs/paper/data/revision/custody/RESULTS.md` 384.

**duration ("took N s")** (16 lines): `docs/paper/artifact/EXPECTED_TABLES.md` 274; `docs/paper/artifact/README.md` 107; `docs/paper/data/build2/concurrency/RESULTS.md` 353, 368, 464; `docs/paper/data/build2/crash/RESULTS.md` 344; `docs/paper/data/build2/heldout/RESULTS.md` 496; `docs/paper/data/build2/robustness/RESULTS.md` 451; `docs/paper/data/build2/subset-corpus/RESULTS.md` 266; `docs/paper/data/revision/baseline/RESULTS.md` 161; `docs/paper/data/revision/baseline/STAGE_COST.md` 52, 195, 196; `docs/paper/data/revision/compromise/RESULTS.md` 179; `docs/paper/data/revision/concurrency/RESULTS.md` 259; `docs/paper/data/revision/crash/RESULTS.md` 216.

**verifier reason category "not needed" (no claim rests on the field)** (34 lines): `docs/demo/FIELD_CHECK_MAP.md` 48, 77, 85, 90, 92, 121, 151, 154, 172, 191, 219, 236, 246, 262, 268, 295, 313, 314, 333, 343, 344, 350, 352, 357, 363, 380, 381, 390, 400, 419, 438, 489, 492; `docs/paper/data/build2/RESULTS_BUILD2.md` 1509.

**policy, approval or UI requirement (e.g. "needs approval", "needs mode flag", "Needs a human")** (22 lines): `cmd/agentgate-killsuite/README.md` 113, 198; `docs/demo/ARCHITECTURE.md` 350; `docs/demo/CONTRACTS.md` 386, 507, 508; `docs/demo/FIELD_CHECK_MAP.md` 217, 392; `docs/demo/PRESENTER_GUIDE.md` 89, 393, 452, 465, 648, 653; `docs/demo/VERIFIER_CHECKS.md` 642, 654, 697, 1058, 1488; `docs/paper/artifact/SUBSET_VERIFIER.md` 38; `docs/paper/data/build2/RESULTS_BUILD2.md` 768; `docs/paper/data/build2/fixture-studies/RESULTS.md` 249.

**requirement of a measurement or tool (test builds, env vars, a fresh status, a reboot)** (60 lines): `docs/demo/CONTRACTS.md` 171, 821; `docs/demo/FIELD_CHECK_MAP.md` 101, 144; `docs/demo/GLOSSARY.md` 34; `docs/demo/PRESENTER_GUIDE.md` 68, 235; `docs/demo/RESEARCH_NEXT_STEPS.md` 51, 61; `docs/demo/REVISION_CONTRACT.md` 21; `docs/demo/VERIFIER_CHECKS.md` 140, 1410, 1434, 1451; `docs/paper/artifact/PROVENANCE.md` 82; `docs/paper/artifact/README.md` 65, 323; `docs/paper/artifact/SUBSET_VERIFIER.md` 97; `docs/paper/data/build2/RESULTS_BUILD2.md` 39, 279, 559, 560, 743, 895, 1210, 1397, 1399, 1745, 1752, 1755, 1759; `docs/paper/data/build2/concurrency/RESULTS.md` 266, 420; `docs/paper/data/build2/custody/RESULTS.md` 463; `docs/paper/data/build2/fixture-studies/RESULTS.md` 111, 507, 523, 525; `docs/paper/data/build2/heldout/RESULTS.md` 443; `docs/paper/data/build2/killsuite/RESULTS.md` 162, 259; `docs/paper/data/build2/misuse/RESULTS.md` 315; `docs/paper/data/build2/robustness/RESULTS.md` 38, 448, 449; `docs/paper/data/build2/subset-corpus/RESULTS.md` 276; `docs/paper/data/revision/RESULTS_REVISION.md` 85, 573, 1043, 1045, 1047; `docs/paper/data/revision/compromise/RESULTS.md` 34, 84; `docs/paper/data/revision/concurrency/RESULTS.md` 298; `docs/paper/data/revision/crash/RESULTS.md` 132; `docs/paper/data/revision/misuse/RESULTS.md` 269, 276; `docs/paper/data/revision/robustness/RESULTS.md` 30, 325, 326.

**test or field name** (7 lines): `docs/demo/VERIFIER_CHECKS.md` 1580; `docs/paper/artifact/EXPECTED_TABLES.md` 116, 117; `docs/paper/artifact/SCHEMAS.md` 103; `docs/paper/data/build2/compromise/RESULTS.md` 124; `docs/paper/data/revision/RESULTS_REVISION.md` 287; `docs/paper/data/revision/compromise/RESULTS.md` 139.

**counting or code-separation wording ("independent cells", "independent of", "independently signed/held")** (42 lines): `docs/demo/ARCHITECTURE.md` 134, 442; `docs/demo/CONTRACTS.md` 443; `docs/demo/PRESENTER_GUIDE.md` 91, 296, 385, 576; `docs/demo/RESEARCH_NEXT_STEPS.md` 12; `docs/demo/REVISION_CONTRACT.md` 9, 76, 138; `docs/demo/VERIFIER_CHECKS.md` 279, 957, 983; `docs/paper/artifact/README.md` 348; `docs/paper/artifact/SUBSET_VERIFIER.md` 11; `docs/paper/artifact/SUPPLEMENTARY.md` 714; `docs/paper/data/build2/RESULTS_BUILD2.md` 498, 622, 813, 1526, 1623; `docs/paper/data/build2/concurrency/RESULTS.md` 197, 348; `docs/paper/data/build2/custody/RESULTS.md` 534; `docs/paper/data/build2/fixture-studies/RESULTS.md` 87, 262, 263, 506; `docs/paper/data/build2/killsuite/RESULTS.md` 345; `docs/paper/data/build2/subset-corpus/RESULTS.md` 5; `docs/paper/data/revision/RESULTS_REVISION.md` 742, 850, 1007; `docs/paper/data/revision/compromise/RESULTS.md` 481; `docs/paper/data/revision/concurrency/RESULTS.md` 89, 129; `docs/paper/data/revision/custody/RESULTS.md` 120, 155, 459, 498, 546.

**a count that is not a flip count ("0 of 336 compared fields", "336 of 336 compile")** (5 lines): `docs/paper/data/build2/crash/RESULTS.md` 72, 176; `docs/paper/data/revision/RESULTS_REVISION.md` 671; `docs/paper/data/revision/crash/RESULTS.md` 112; `docs/paper/data/revision/robustness/HELDOUT_OPERATORS.md` 263.

**attack description ("re-signs everything with substitute keys", "never re-signs", "re-chains and re-signs" on fixtures)** (8 lines): `docs/demo/ARCHITECTURE.md` 372; `docs/demo/REVISION_CONTRACT.md` 4, 137; `docs/demo/VERIFIER_CHECKS.md` 200; `docs/paper/artifact/README.md` 171; `docs/paper/data/build2/fixture-studies/RESULTS.md` 79; `docs/paper/data/build2/robustness/RESULTS.md` 367; `docs/paper/data/revision/robustness/RESULTS.md` 199.

**scope statement ("production crash safety" is a non-claim)** (1 lines): `docs/paper/artifact/README.md` 383.

**key-set wording ("needs", "needed", "necessary") in a file with a correction note at the top** (39 lines): `docs/paper/data/build2/RESULTS_BUILD2.md` 437, 493, 494, 495, 1302, 1369, 1420; `docs/paper/data/build2/compromise/RESULTS.md` 212, 214, 215; `docs/paper/data/build2/fixture-studies/RESULTS.md` 4, 133, 215, 242, 244, 250, 253, 293, 298; `docs/paper/data/revision/RESULTS_REVISION.md` 355, 390, 393, 394, 448, 464, 471, 1002; `docs/paper/data/revision/compromise/RESULTS.md` 278, 314, 336, 342, 344, 356, 358, 359, 426, 427, 450, 454.

**flip count "of 336" in a file whose correction note gives the reading over the 168 cells without a head anchor** (9 lines): `docs/paper/data/build2/compromise/RESULTS.md` 23, 24, 26, 27; `docs/paper/data/revision/RESULTS_REVISION.md` 9; `docs/paper/data/revision/compromise/RESULTS.md` 6, 24, 30, 35.

**the two sites of HELDOUT_OPERATORS 7.10 (correction note at the top)** (3 lines): `docs/paper/data/revision/robustness/HELDOUT_OPERATORS.md` 8, 9, 568.
**Reviewed one by one and kept** (28 lines):

| file:line | words | why it stays |
|---|---|---|
| `docs/demo/ARCHITECTURE.md:404` | "proofing" | part of an unrelated word |
| `docs/demo/PRESENTER_GUIDE.md:127`, `:361` | "needed" | no approval or flag was needed by the policy (policy statement) |
| `docs/demo/PRESENTER_GUIDE.md:535` | "ANCHORED needs the keys fingerprint and a trusted head" | the definition of the assurance level |
| `docs/demo/RESEARCH_NEXT_STEPS.md:59` | "no independent custody" | negation |
| `docs/demo/VERIFIER_CHECKS.md:104` | "extension proof" | technical term (line break) |
| `docs/demo/VERIFIER_CHECKS.md:197`, `:199` | "needs only A+I", "needs P" | cells of the lifecycle table, whose header now says "the smallest tested set ... (tested, not proved)" |
| `docs/demo/VERIFIER_CHECKS.md:1345` | "not that every refusal is needed" | negation about refusal sites |
| `docs/paper/artifact/SUBSET_VERIFIER.md:283` | "not a proof that fewer keys cannot succeed" | the correction itself |
| `docs/paper/artifact/SUPPLEMENTARY.md:361`, `:518` | "needed a second approval" | approval requirement (kill suite, human cells) |
| `docs/paper/artifact/SUPPLEMENTARY.md:693` | "misreads" | quotes the frozen text it corrects |
| `docs/paper/artifact/SUPPLEMENTARY.md:737`, `:743`, `:748`, `:749` | "needs a mode", "would still need separate custodians", "would be needed", "needs administrator rights" | requirements of the planned (not built) deployment |
| `docs/paper/data/build2/RESULTS_BUILD2.md:499` | "616 independent verifications" | count of distinct verifications (non-overlapping), not custody |
| `docs/paper/data/build2/RESULTS_BUILD2.md:838` | "not a proof for all interleavings" | negation (quoted caveat) |
| `docs/paper/data/build2/baseline/RESULTS.md:391` | "none needs the build to explain it" | about timing differences between builds |
| `docs/paper/data/build2/killsuite/RESULTS.md:106` | "needed a second approval" | approval requirement |
| `docs/paper/data/revision/RESULTS_REVISION.md:397`, `:944` | "independent oracle", "independent Python checker" | frozen record; corrected by its top note (items 4 and 5) |
| `docs/paper/data/revision/RESULTS_REVISION.md:483` | "not from a proof" | negation |
| `docs/paper/data/revision/RESULTS_REVISION.md:1049` | "again independently at 04:30 UTC" | a second check of build 1's archive, made later; no claim about independence of people |
| `docs/paper/data/revision/compromise/RESULTS.md:320`, `:321`, `:386` | "every member necessary", "independent oracle" | frozen record; corrected by its top note |

## 4. Words that were searched and not found

"three keys", "consent artifact", "crash safe" (as a claim; the only hit is
the non-claim "production crash safety") and "power-loss test" occur in no
archived document.

## 5. How to repeat the sweep

`python` over the files listed above with the pattern of the grep command;
the classification used for section 3 is the list of reasons there. Repeat
after any later edit of an archived document and before taking the archive
digest (`build_artifact.py` prints it last).
