# The frozen oracle: what it is, when it was fixed, what changed after

The key-compromise study compares the verifier with an **oracle**: expected
outcomes written from the specification before any edit was verified. This
file states which file that is, when it was fixed, that it was never edited,
how the "post-hoc sensitivity" figures are made, and which verifier rules
and edit-engine changes were added after the first build's run. Written
2026-10-10 for the review archive.

## 1. The file

| item | value |
|---|---|
| file | `docs/paper/oracle/expected.json` (with `README.md`, `binding_model.md` and the generator `generate_expected.py` in the same folder) |
| SHA-256 | `62d726608e7beb9428ffddf9120799ee8592639521508e053532f5bc876343d9` |
| cells | 560: 7 operators x 10 key sets x 4 anchor conditions (none, keys, head, both) x 2 designs (bound, unbound) |
| per cell | a primary prediction (`expected`) and four single-assumption alternative readings (`no_snapshot_forgery`, `snapshot_bound`, `mode_checked`, `receipt_decision_unchecked`) |
| key sets not in the oracle | "all genuine keys stolen" and "audit+issuer+adapter+approval", added to the grid later; the oracle covers 10 of the grid's 12 key sets |
| written from | the specification and one gateway source file, without opening the verifier or the edit engine (oracle README, "Method") |

## 2. When it was fixed

- **Committed** in commit `56bab94` at 2026-10-07 18:52:53 UTC (git commit
  time). The file in that commit has the SHA-256 above.
- **Never edited.** `git log -- docs/paper/oracle` lists that one commit
  only. The oracle README's changelog has one entry: "2026-10-07: initial
  labels (primary reading plus four alternative readings), written before
  any R6.1 mutant was verified." Its rule: "never change a label just
  because a result disagrees".
- **First verification against it.** The earliest compromise run started
  at 2026-10-07 20:38:56 UTC
  (`docs/paper/data/revision/compromise/previous-run-2026-10-07/RESULTS.md`),
  about 1 h 46 min after the commit. Every later run used the same file:

| run | when (UTC) | build | where |
|---|---|---|---|
| first run, 11 key sets | 2026-10-07 20:38:56-20:48:42 | development tree before the frozen build | `docs/paper/data/revision/compromise/previous-run-2026-10-07/` |
| rerun on the compromise build | 2026-10-07 22:45:42-22:52:11 | compromise build (`d73aa73`) | `docs/paper/data/revision/compromise/previous-build/` |
| **build 1** (first frozen build) | 2026-10-08 02:28:17-02:43:11 | five binaries, manifest `188f83bd...121e` | `docs/paper/data/revision/compromise/` |
| **build 2** (the evaluated build) | 2026-10-10 02:27:17-02:43:57 | six binaries, manifest `841a7c6f...b658` | `docs/paper/data/build2/compromise/` |

**What this does and does not show.** The times are git commit times and
the runners' own clocks. There is no trusted timestamp: a git date is
self-reported. The provenance of the order (oracle first, results later)
rests on the project's version history, which is released with the
camera-ready version or given to the chairs on request.

## 3. How the oracle is compared, and what "post-hoc sensitivity" means

`docs/paper/data/build2/compromise/analyze_compromise.py` (byte-identical to
build 1's copy) joins every grid cell that uses one of the oracle's 10 key
sets with the oracle on (operator, key set, anchors, design). It reports
agreement for every reading and both attackers in `oracle_agreement.csv`
and every disagreeing cell, with a named cause, in `oracle_mismatches.csv`.

- **Primary.** The oracle's own `expected` label. The paper reports it.
- **Post-hoc sensitivity.** Two combinations of frozen alternative readings
  (`snapshot_bound+mode_checked`, `no_snapshot_forgery+mode_checked`) and,
  per verifier setting, the reading that matches the verifier as built
  (`MAPPED` in the script: full + strongest attacker ->
  `snapshot_bound+mode_checked`; no snapshot check + strongest attacker ->
  `mode_checked`; the no-replay settings have no mapped reading, so the
  paper uses `mode_checked`, the reading the script prints for them). These
  combinations were chosen **after** the first results were seen. They use
  only labels that were frozen on 2026-10-07; no label was changed. The
  paper calls them "post-hoc sensitivity", never "agreement".

Build-2 values (strongest attacker, of 560 labelled design results; identical in build 1):

| verifier setting | primary | post-hoc sensitivity (reading) | mismatches of the primary reading, by cause |
|---|---|---|---|
| full | 514 | 540 (`snapshot_bound+mode_checked`) | 46: snapshot assumed unchecked (S1) 8, escalation mode assumed unchecked (A3) 14, target limits C1 14 and C2 10 |
| no snapshot check | 522 | 536 (`mode_checked`) | 38: A3 14, C1 14, C2 10 |
| no replay | 546 | 560 (`mode_checked`) | 14: A3 14 |

Every mismatch of the primary reading is a cell the verifier detected and
the oracle expected to pass (`verifier_detected_oracle_undetected` = the
disagree count in every primary row). All 1,888 disagreeing (configuration x
reading x attacker) rows have a named cause; 0 are unexplained
(`build2/compromise/RESULTS.md`).

## 4. Changes before the first build's run (freeze to build 1)

Between the oracle commit and build 1 (whose compiled files equal those of
commit `2d32506`), the verifier and the edit engine changed in these
commits (non-test sources of `internal/auditverify` and
`internal/evalattack`; cumulative diff:
`oracle/post_freeze_diffs/oracle_freeze_to_build1_cumulative.diff`):

| commit | UTC | subject |
|---|---|---|
| `d73aa73` | 2026-10-07 22:08 | revision 2b: compromise simulation, restart segments, false-alarm fixes, reruns |
| `d4dc908` | 2026-10-08 00:44 | revision: snapshot-forging attacker, witness segments, 30 s lease, rewritten paper |
| `ac5b71a` | 2026-10-08 02:01 | revision cleanup: withheld-segment detection, call-scope conflicts, final-build reruns |
| `261c0f3` | 2026-10-08 04:54 | revision final: signed witness status, single frozen build, final paper (commits the tree build 1 was built from) |

The one change these commits made because of a result: the first run
(20:38 UTC) reported 23 of 308 no-replay flips, 16 predicted by the oracle
and 7 caused by an escalation-mode check that the unbound design lacked.
Making that check symmetric removed those 7 and the 4 predicted
change-escalation flips, leaving 12. The correction strengthened the
unbound design and removed flips that favoured binding. The oracle was not
changed; its change-escalation predictions now disagree with the verifier
(cause A3 above).

## 5. Changes after the first build's run (build 1 to build 2)

Build 1's results had been seen (and published in the earlier manuscript)
before these changes. The oracle was not changed. Diffs of the non-test
sources of `internal/auditverify` and `internal/evalattack`, one file per
commit, are in `oracle/post_freeze_diffs/` (cumulative:
`build1_to_build2_cumulative.diff`, `git diff 2d32506 86643d7`).

| # | commit | UTC | what changed | diff file |
|---|---|---|---|---|
| 1 | `afe8730` | 2026-10-10 00:34 | **verifier**: reports weaker evidence explicitly (per-operation classification evidence, the derived dimensions `head_fresh` and `run_complete`, the flag of an unresolved operation, `flagged_unconfirmed`); adds the **recovery-record flag rule** (`checkReconciledFlag`, part of `op.requires_policy`: a RECONCILED commit and its call's CALL_RESULT must state the bound flag) | `2026-10-10T0034Z_afe8730.diff` |
| 2 | `2bac58e` | 2026-10-10 00:50 | **edit engine correction**: `rewriteDecision` now also rewrites the flag on RECONCILED-committed records (`reconciledCommits`), so a flag edit stays consistent with rule 1 | `2026-10-10T0050Z_2bac58e.diff` |
| 3 | `d084ef9` | 2026-10-10 01:25 | **verifier**: an adapter receipt attached to a RECONCILED entry is checked (`checkReconciledReceipt`, part of `op.receipts_bound`) and, when bound, makes the operation `issuer_adapter`; `missing_kinds`; reporting fixes | `2026-10-10T0125Z_d084ef9.diff` |
| 4 | `682d37e` | 2026-10-10 02:07 | **verifier**: the **replayed-answer flag rule** (`checkReplayedFlag`, part of `op.requires_policy`): a replayed COMMITTED answer, and the call whose RECONCILED entry confirms an execution, must state the bound flag | `2026-10-10T0207Z_682d37e.diff` |

**Effect on the compromise results: none measured.** Build 2 reproduced
build 1 in all 51,840 result rows (verdict, assurance, failing checks in
order). The reason is that no mutated operation of the grid has a recovery
or replay record: the base runs' replayed and reconciled operations are
unflagged, no mutant touches them, and the only RECONCILED record carries
no adapter receipt (`build2/compromise/RESULTS.md` section 4). So the grid
does not test rules 1, 3 and 4; the fixture studies do
(`build2/fixture-studies/`). One engine gap remains, found by reading the
code and not exercised: `rewriteDecision` does not rewrite call-scope
replayed COMMITTED answers, so a flag edit aimed at a replayed operation
would be caught by `checkReplayedFlag`. That would be a consequence of the
engine, not a strength of the verifier.

## 6. Where to look

- Oracle and its method: `docs/paper/oracle/README.md`, `binding_model.md`.
- Comparison script and outputs: `docs/paper/data/build2/compromise/`
  (`analyze_compromise.py`, `oracle_agreement.csv`, `oracle_mismatches.csv`,
  `analysis.json` key `mismatch_cause_counts`).
- The quick route that re-runs the comparison on one repetition:
  `README.md`, "Quick check of the central result".
