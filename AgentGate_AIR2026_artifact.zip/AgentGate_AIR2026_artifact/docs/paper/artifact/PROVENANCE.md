# Provenance of the code in this archive

**For review only.** No licence is granted for this code yet. Reviewers may
build, run and inspect it to assess the submission; no other rights are
granted. The Go modules under `vendor/` remain under their own licences (each
module's licence file is kept next to it; versions are pinned in `go.mod`,
`go.sum` and `vendor/modules.txt`).

## Where the code comes from

The project's repository history begins on 2026-08-16 (commit `6b8c3c8`).
It has two periods, separated by a handover on 2026-10-01:

| period | git range | what it contains |
|---|---|---|
| **before the handover** (the earlier research prototype) | commits `6b8c3c8..9b45b50` (2026-08-16 to 2026-09-01), plus uncommitted work that was preserved unchanged in snapshot commit `298cf42` on 2026-10-01 | a broader prototype written for this project in this repository with an AI coding agent (OpenAI Codex) directed by the project team: canonical CBOR and domain-separated hashing, effect objects, capability and control-point logic, adapters, the provider simulator, the MCP boundary, COSE signing, approval and evidence stores, and many components that are **not** in this archive (database-backed runtime, cloud deployment paths, academic staging, passkey approval, Rust components) |
| **after the handover** | commits `1461b7c..86643d7` (2026-10-01 to 2026-10-10) | written with a second AI coding agent (Claude Code) directed by the project team: the demonstration demo, the signed hash-chained audit log, the offline verifier and tamper lab, most of the development gateway composition (`internal/devcomposition`), the evaluation harness, and the revisions for the two reviews (explicit operation outcomes and the operation journal, the delegation grant, policy replay, separate provider and witness processes, evidence segments across a restart, the key-compromise simulation and its mutation engine, the oracle and the test vectors; for the second review the OS-level kill suite `cmd/agentgate-killsuite`, the flag in recovery records and replayed answers, the verifier's classification evidence and freshness outputs, the lifecycle, key-set, registration and clock tests, the held-out mutation operators, the subset verifier and its corpus generator) |

The Go sources of this archive are the ones compiled into **build 2**, the
single frozen build behind every result of the paper: six binaries built on
2026-10-10 at 02:24:44 UTC from commit `86643d7`
(`docs/paper/data/build2/RESULTS_BUILD2.md` §0; manifest
`docs/paper/data/build2/build-manifest.txt`, original SHA-256
`841a7c6fd3c6ea5790692c7bb3be27e783e6ad803ef5adeb39d26b792534b658`).
`docs/paper/artifact/check_build_manifest.py` compares them with that
manifest. Test files, the verifier's test fixture
(`internal/auditverify/fixture`), the test-vector and corpus generators and
the refusal-mutation tool are not compiled into the six binaries and are not
listed in the manifest; `TEST_FILES_SHA256.txt` lists them by SHA-256.
Four test-only files were written after the freeze (2026-10-19, same agent
and team): the fixture helper `internal/auditverify/fixture/held.go` and the
real-signature tests `internal/auditverify/round4_*_test.go`. They compile
against the unchanged frozen sources, are not in the build-2 commit and are
marked `added-after-freeze` in `TEST_FILES_SHA256.txt`
(`docs/paper/data/build2/fixture-studies/ADDED_AFTER_FREEZE.md`).
The earlier build (build 1: five binaries, 2026-10-08, manifest
`188f83bd...121e`, `docs/paper/data/revision/`) produced the results of the
earlier manuscript; build 2 repeated every one of its measurements with the
same numbers.

**Pre-fix evidence.** The flag-loss bug that a real kill exposed is
documented by a kill-suite run on an earlier build (the build-1 gateway and
verifier plus the first version of the suite):
`docs/paper/data/build2/killsuite/prefix-earlier-build/` (its README names
both binaries by SHA-256). That verifier accepted the affected folders. No
number of the paper comes from it except the two counts labelled "an
earlier build".

No third-party source code is copied into the project's own packages (no
third-party licence or copyright headers occur in the included sources, and
the dashboard assets in `internal/demo/assets` use no external libraries).
Third-party code enters only through the vendored Go modules.

## What this archive reuses from the prototype

The table is generated from git at packaging time
(`docs/paper/artifact/build_artifact.py`): every included source and
specification file is classified by whether it existed before the handover
(in `9b45b50` or in the `298cf42` snapshot) and whether its content
(git blob) changed after the handover. `provenance_files.csv` lists every
file with its class and line count.

| component | files | lines | pre-handover, unchanged (files / lines) | pre-handover, modified after (files / lines) | new after the handover (files / lines) |
|---|---|---|---|---|---|
| `cmd/agentgate-demo` | 1 | 368 | 0 / 0 | 0 / 0 | 1 / 368 |
| `cmd/agentgate-eval` | 22 | 9925 | 0 / 0 | 0 / 0 | 22 / 9925 |
| `cmd/agentgate-killsuite` | 13 | 5598 | 0 / 0 | 0 / 0 | 13 / 5598 |
| `cmd/agentgate-provider` | 4 | 1422 | 0 / 0 | 0 / 0 | 4 / 1422 |
| `cmd/agentgate-verify` | 2 | 1423 | 0 / 0 | 0 / 0 | 2 / 1423 |
| `cmd/agentgate-witness` | 1 | 167 | 0 / 0 | 0 / 0 | 1 / 167 |
| `docs/demo` | 8 | 4905 | 0 / 0 | 0 / 0 | 8 / 4905 |
| `docs/paper/artifact` | 25 | 12899 | 0 / 0 | 0 / 0 | 25 / 12899 |
| `docs/paper/oracle` | 4 | 12934 | 0 / 0 | 0 / 0 | 4 / 12934 |
| `go.mod` | 1 | 73 | 1 / 73 | 0 / 0 | 0 / 0 |
| `go.sum` | 1 | 197 | 1 / 197 | 0 / 0 | 0 / 0 |
| `internal (root)` | 1 | 278 | 1 / 278 | 0 / 0 | 0 / 0 |
| `internal/*/migrations (SQL embedded by internal/migrationassets.go)` | 26 | 8851 | 26 / 8851 | 0 / 0 | 0 / 0 |
| `internal/adapters` | 45 | 16366 | 45 / 16366 | 0 / 0 | 0 / 0 |
| `internal/approval` | 30 | 9781 | 30 / 9781 | 0 / 0 | 0 / 0 |
| `internal/audit` | 6 | 2961 | 0 / 0 | 0 / 0 | 6 / 2961 |
| `internal/auditverify` | 50 | 22029 | 0 / 0 | 0 / 0 | 50 / 22029 |
| `internal/auditverify/fixture` | 9 | 3218 | 0 / 0 | 0 / 0 | 9 / 3218 |
| `internal/auditverify/tools` | 2 | 1789 | 0 / 0 | 0 / 0 | 2 / 1789 |
| `internal/authoritylimits` | 1 | 18 | 1 / 18 | 0 / 0 | 0 / 0 |
| `internal/canon` | 3 | 549 | 3 / 549 | 0 / 0 | 0 / 0 |
| `internal/capability` | 50 | 19622 | 46 / 17106 | 2 / 2341 | 2 / 175 |
| `internal/controlpoint` | 34 | 10182 | 32 / 8788 | 1 / 1103 | 1 / 291 |
| `internal/dbgrant` | 2 | 1076 | 2 / 1076 | 0 / 0 | 0 / 0 |
| `internal/dbmigrate` | 9 | 4378 | 9 / 4378 | 0 / 0 | 0 / 0 |
| `internal/demo` | 30 | 15369 | 0 / 0 | 0 / 0 | 30 / 15369 |
| `internal/devapproval` | 5 | 2001 | 1 / 15 | 3 / 1902 | 1 / 84 |
| `internal/devcomposition` | 28 | 14402 | 2 / 43 | 4 / 2916 | 22 / 11443 |
| `internal/effects` | 3 | 696 | 1 / 122 | 1 / 512 | 1 / 62 |
| `internal/evalattack` | 11 | 3771 | 0 / 0 | 0 / 0 | 11 / 3771 |
| `internal/evidence` | 50 | 24516 | 50 / 24516 | 0 / 0 | 0 / 0 |
| `internal/headwitness` | 14 | 5080 | 0 / 0 | 0 / 0 | 14 / 5080 |
| `internal/identity` | 8 | 1739 | 8 / 1739 | 0 / 0 | 0 / 0 |
| `internal/mcp` | 19 | 2632 | 16 / 1995 | 1 / 392 | 2 / 245 |
| `internal/opjournal` | 2 | 393 | 0 / 0 | 0 / 0 | 2 / 393 |
| `internal/provenance` | 8 | 3406 | 8 / 3406 | 0 / 0 | 0 / 0 |
| `internal/signed` | 3 | 491 | 3 / 491 | 0 / 0 | 0 / 0 |
| `internal/simulator` | 7 | 4072 | 7 / 4072 | 0 / 0 | 0 / 0 |
| `internal/webauthnclient` | 2 | 196 | 2 / 196 | 0 / 0 | 0 / 0 |
| `internal/witnessprotocol` | 6 | 923 | 6 / 923 | 0 / 0 | 0 / 0 |
| `schemas` | 36 | 5580 | 36 / 5580 | 0 / 0 | 0 / 0 |
| `scripts` | 2 | 911 | 0 / 0 | 0 / 0 | 2 / 911 |
| `test-vectors` | 53 | 3207 | 53 / 3207 | 0 / 0 | 0 / 0 |
| `testdata` | 151 | 4006 | 151 / 4006 | 0 / 0 | 0 / 0 |
| **total** | 788 | 244400 | 541 / 117772 | 12 / 9166 | 235 / 117462 |

Reading the table:

- *pre-handover, unchanged*: byte-identical to the 2026-10-01 snapshot;
  inherited prototype code used as it was.
- *pre-handover, modified after*: inherited files changed after the handover
  (for example the MCP status mapping and the gateway composition for the
  revision).
- *new after the handover*: written from 2026-10-01 on.

The inherited packages contain more than the demo executes: for example
`internal/capability`, `internal/controlpoint`, `internal/evidence` and
`internal/approval` also hold database-backed stores and migrations
(compiled because of package-level references, not used by the demo, which
keeps its stores in memory plus the fsynced operation journal). The
security-critical path the evaluation exercises is the development gateway
(`internal/devcomposition`) over `internal/canon`, `internal/effects`,
`internal/signed`, `internal/capability` (in-memory registry),
`internal/controlpoint` (in-memory store), `internal/adapters`,
`internal/simulator` and `internal/mcp`, recorded by `internal/audit` and
checked by `internal/auditverify`, which imports no gateway package.

## Test files left out

These test files of included packages need archived packages or code that
are not part of this archive (they test prototype features outside the
demo), so they were left out. Every other test file of the included packages
is present, together with the repository-level inputs those tests read
(`test-vectors/`, `schemas/`, three items of `testdata/`).

- `internal/dbgrant/manifest_test.go` (reads the source files of archived packages (`internal/policy`, `internal/runtimecomponents`))
- `internal/evidence/migration_sequence_integration_test.go` (imports `agentgate/internal/oauthauthority`)
- `internal/evidence/research_selected_query_pg_test.go` (imports `agentgate/internal/academicstagingdb`)
- `internal/evidence/tail_recovery_v5_test.go` (scans the whole repository's source and expects call sites in archived packages)
- `internal/approval/declassification_rust_vector_test.go` (imports `agentgate/internal/policy`)
- `internal/capability/adapter_snapshot_bootstrap_test.go` (imports `agentgate/internal/policy`)
- `internal/capability/prepared_final_policy_wire_test.go` (imports `agentgate/internal/policy`)
- `internal/capability/prepared_final_tx_owner_release_test.go` (runs `go list ./cmd/gateway`, an archived prototype command)
- `internal/adapters/research_capture_bound_windows_test.go` (imports `agentgate/internal/researchcapture`)
- `internal/adapters/research_capture_windows_test.go` (imports `agentgate/internal/researchcapture`)
- `internal/adapters/tail_v5_private_integration_test.go` (scans the whole repository's source and expects call sites in archived packages)
- `internal/controlpoint/finalization_diagnostics_test.go` (imports `agentgate/internal/witness`)
- `internal/controlpoint/finalization_test.go` (imports `agentgate/internal/witness`)
- `internal/simulator/evaluation_observer_http_test.go` (imports `agentgate/internal/researchobserver`)
- `docs/paper/data/build2/fixture-studies/probe/zz_fixture_study_probe_test.go` (uses test helpers defined in one of the files above)
- `docs/paper/data/build3/fixture-studies/probe/zz_earlier_keys_probe_test.go` (uses test helpers defined in one of the files above)
- `docs/paper/data/build3/fixture-studies/probe/zz_fixture_study_probe_test.go` (uses test helpers defined in one of the files above)
- `docs/paper/data/build3/fixture-studies/probe/zz_pending_probe_test.go` (uses test helpers defined in one of the files above)
- `internal/adapters/dispatch_receipt_store_v5_test.go` (uses test helpers defined in one of the files above)
- `internal/adapters/reconciliation_prepare_response_v5_test.go` (uses test helpers defined in one of the files above)
- `internal/adapters/reconciliation_receipt_store_v5_test.go` (uses test helpers defined in one of the files above)
- `internal/capability/adapter_recovery_catalog_v5_test.go` (uses test helpers defined in one of the files above)
- `internal/capability/adapter_snapshot_sql_postgres_test.go` (uses test helpers defined in one of the files above)
- `internal/adapters/recovery_response_v5_test.go` (uses test helpers defined in one of the files above)
- `internal/capability/adapter_recovery_execution_v5_test.go` (uses test helpers defined in one of the files above)
- `internal/capability/adapter_reconciliation_status_unknown_test.go` (uses test helpers defined in one of the files above)

## Machine-specific data

Recorded experiment data were produced on one Windows desktop. In unsigned
text files the archive replaces absolute local paths with `<repo>` (the
repository), `<scratch>` (the experiment work directory) or `<home>`, and the
machine name with `review-host`; owner names in one tar archive's headers are
reset. Signed evidence cannot be edited without breaking its signatures, so
the evidence is written with the name `review-host` from the start: the demo
and the evaluation harness take `-host-label review-host`, and every signed
evidence file in this archive (the sample bundles in `samples/` and the
signed files under `docs/paper/data/`) was produced that way (see
`samples/README.md`); the archive builder refuses to finish if the machine
name occurs in any file. The one signed folder of the superseded 2026-10-07
concurrency run, which was made without the label and names the machine, is
withheld
(`docs/paper/data/revision/concurrency/previous-build/2026-10-07/n32/evidence-r22/WITHHELD.md`).
The kill suite's journal-write-failure folders are not in the archive at all:
their signed `journal_unavailable` entry embeds the absolute path of the
journal file. The Windows user name occurs by chance inside one 64-character
SHA-256 digest of `docs/paper/data/build2/killsuite/results.json`, which
cannot be edited without corrupting the record.

## Private keys

The archive contains no private signing key of any run: the per-run keys
exist only in the memory of the process that made the run, the provider's and
witness's own key stores stay in the build's scratch folder, and the demo has
no key-export option (an evaluation-only export was removed on 2026-10-07; the
key-compromise study simulates key possession instead,
`docs/demo/VERIFIER_CHECKS.md` §9). The archive builder refuses to finish if
a key store, a PEM private key or key-export code is found. The only private
keys in the archive are fixed test keys inside test code and test vectors
(for example the published RFC 8032 test keys of `test_vectors.json`); none
of them signs any evidence bundle.
