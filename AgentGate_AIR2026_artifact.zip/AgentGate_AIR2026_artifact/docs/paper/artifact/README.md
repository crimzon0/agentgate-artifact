# AgentGate: artifact

Anonymous archive for the submission "AgentGate: A Verifiable Gateway for
Classifying and Auditing Autonomous Agent Actions". Archive version 4 (build
3). **For review only; no licence is granted** (see `PROVENANCE.md`).

AgentGate is a gateway between an AI agent and three simulated services:
sending an external message, releasing a document and creating a payment
request. It classifies each tool call as allowed, flagged for audit or
denied. An action that may run gets a signed, single-use permit (a
*capability*), and the *adapter*, the connector to the service, uses it once
and signs a receipt. Every step goes into a signed, hash-linked log, which
an offline verifier checks later. The paper asks when it helps to sign the
classification into the capability (*binding*), compared with re-running the
policy from a signed copy (*replay*) and comparing the log with a copy of its
last entry kept elsewhere (a *head anchor*). All providers are simulated: no
real messages, documents or money.

Terms: `docs/paper/artifact/SUPPLEMENTARY.md`, S10 (glossary, with a map from
the older names that some result files and logs use). Units (attack, result,
fixture case, test run, ...): `docs/paper/artifact/EXPECTED_TABLES.md`,
"Units".

## Contents of this README

Getting and checking the archive · contents · prerequisites · rebuild and
compare the binaries · quick check (2 min) · regenerate every table ·
real-key tests · one process-kill test · registration with the witness and
one multi-process run · the partial Python verifier · verify sample
evidence · all tests · test vectors · data formats · reproduce every
experiment · the evaluated build · versions · limits · fresh-unzip check ·
not included.

## Getting the archive and checking it

**Where.** The archive is the single file `AgentGate_AIR2026_artifact.zip`.
It is uploaded with the submission as supplementary material. The authors
may also place the same file in an anonymous repository and give its link
on the submission form; the file and its digest are the same either way.
Nothing in the archive needs network access, an account or a key.

**Digest.** The archive cannot contain its own SHA-256 (writing it inside
would change it). The full digest is in the file next to the zip,
`AgentGate_AIR2026_artifact.zip.sha256` (written by `build_artifact.py`), and
on the submission form. Check it before unpacking, with both files in one
folder:

```
sha256sum -c AgentGate_AIR2026_artifact.zip.sha256   # expected: AgentGate_AIR2026_artifact.zip: OK
```

Without `sha256sum` (Windows): `certutil -hashfile AgentGate_AIR2026_artifact.zip SHA256`
prints the same 64 hex digits as the `.sha256` file.

Inside the archive, `SHA256SUMS.txt` lists every other file (LF line ends);
after unpacking, check it from the archive folder with
`sha256sum -c SHA256SUMS.txt` (expected: every line `OK`). Every file in the
zip carries the same fixed timestamp, so that the zip is reproducible; it is
not the build date.

## Contents

| path | what it is |
|---|---|
| `cmd/agentgate-demo` | the gateway with the scripted agent, dashboard, self-test and tamper lab |
| `cmd/agentgate-verify` | the offline verifier (imports no gateway package) |
| `cmd/agentgate-provider`, `cmd/agentgate-witness` | the simulated provider and the head witness as separate processes |
| `cmd/agentgate-eval` | the evaluation harness (key-theft simulation, in-process faults, concurrency, misuse, multi-process runs, cost) |
| `cmd/agentgate-killsuite` | the process-kill tests: kills and restarts real gateway processes (`cmd/agentgate-killsuite/README.md`) |
| `internal/` | the packages these six programs compile (closure from `go list -deps`), with their tests; `internal/auditverify/fixture` is the verifier's test fixture (synthetic runs, keys created in memory) |
| `vendor/`, `go.mod`, `go.sum` | vendored dependencies at fixed versions: the archive builds without network access |
| `test-vectors/`, `schemas/`, `testdata/` | inputs read by the tests of the inherited packages |
| `scripts/demo.ps1`, `scripts/demo.sh` | launchers for the demo and the self-test |
| `docs/demo/` | specifications: `CONTRACTS.md` (formats, statuses, policy), `VERIFIER_CHECKS.md` (all 38 checks, lifecycle states, the key-theft simulation), `FIELD_CHECK_MAP.md` (which check reads which field, and every unchecked field), `GLOSSARY.md` (engineering glossary, older names), `ARCHITECTURE.md`, `PRESENTER_GUIDE.md` and older working notes |
| `docs/paper/oracle/` | the expected outcomes of the key-theft simulation, fixed before any edit was verified (560 labelled results per verifier setting); see `docs/paper/artifact/ORACLE_FREEZE.md` |
| `docs/paper/data/build3/` | **the data of the evaluated build**: raw outputs as CSV and JSON, analysis scripts and a `RESULTS.md` per experiment; `RESULTS_BUILD3.md` collects every result and reconciles builds 1, 2 and 3 (§3); `build-manifest.txt` identifies the build; `robustness/coverage_map.md` is the coverage map per check |
| `docs/paper/data/build2/`, `docs/paper/data/revision/` | the data of build 2 (2026-10-10) and build 1 (2026-10-08), kept for the version crosswalk; the paper's two "earlier build" counts come from `docs/paper/data/build2/killsuite/prefix-earlier-build/` |
| `docs/paper/artifact/` | this README; `EXPECTED_TABLES.md` (every paper number with its file, field and population, the single accounting of the binding grid, the version crosswalk); `regenerate_tables.py` (recomputes them); `REPRODUCIBILITY.md` (exact commands); `SUPPLEMENTARY.md` (material moved out of the paper, S1-S17); `SCHEMAS.md` (output files and fields); `ORACLE_FREEZE.md` and `oracle/post_freeze_diffs/`; `HONESTY_SWEEP.md` (wording corrections in older archived documents); `quick_check.py`; the partial Python verifier (`subset_verifier.py`, `SUBSET_VERIFIER.md`, `corpusgen/`); the test vectors, their generator and checker; `check_build_manifest.py`; `algorithm_mediate.tex` (the request path as pseudocode); `loc_build3.csv` and `loc_build2.csv` (code lines per file); `VERSION`, `CHANGELOG.md`; `build_artifact.py`, which built this archive, and `test_artifact_scripts.py` |
| `samples/` | clean, edited and restart (two-segment) evidence folders with their anchors and the verifier's expected output (`samples/README.md`) |
| `PROVENANCE.md`, `provenance_files.csv` | which code predates the project's 2026-10-01 handover and which is new |
| `TEST_FILES_SHA256.txt` | every test file and test-only source, by SHA-256, and whether it equals the build-3 commit's copy |
| `BINARIES_SHA256.txt`, `BUILD_CHECK.txt` | the SHA-256 of the six binaries this archive rebuilds, and the comparison with the build-3 manifest |
| `SHA256SUMS.txt` | SHA-256 of every file in the archive |

## Prerequisites

- **Windows 10 or 11, x64**, for the commands as written (the evaluated
  binaries were built and run there). The Go code also builds on Linux and
  macOS; the stage-cost benchmark (`TestStageCost`) is Windows only.
- **Go 1.26.6** (`go version` must say go1.26.6 for the binary hashes and
  the standard-library hashes to apply). Nothing is downloaded: the
  dependencies are vendored, and an empty module cache is enough.
- **Python 3**, standard library only, for the analysis scripts, the quick
  check, `regenerate_tables.py` and the partial Python verifier. numpy and
  matplotlib only to redraw the baseline charts.
- About 2 GB of free disk for the build cache and one experiment's work
  folder.
- **Seeds.** The experiments are scripts that draw fresh keys, identifiers
  and timestamps on every run, so no seed is needed to reproduce their
  outcomes; repetitions show stability, not independent samples. The one
  random analysis, the bootstrap of the cost experiment, uses seed 20261007
  and 10,000 resamples (`docs/paper/data/build3/baseline/analyze_baseline.py`).
  The fixture tests derive their keys in memory from a fixed label
  (`internal/auditverify/fixture`), so their results repeat exactly.

The zip unpacks into `AgentGate_AIR2026_artifact/`; run every command from
that folder (`cd AgentGate_AIR2026_artifact`). Commands are for bash; on
Windows, binaries end in `.exe` (type `bin/agentgate-verify.exe` where a
binary is passed as an argument), and Python is usually `py`. Give each route
its own empty output folders, as below, so that no run overwrites another.

## Rebuild and compare the binaries

The six binaries are not in the archive; you build them from its source.
Build 3 was built reproducibly, so your binaries must have exactly the
SHA-256 values of the evaluated build.

```
export CGO_ENABLED=0 GOFLAGS=-mod=vendor GOPROXY=off GOTOOLCHAIN=local GOWORK=off GOENV=off GOOS=windows GOARCH=amd64 GOAMD64=v1
go build -trimpath -buildvcs=false -ldflags=-buildid= -o bin/ ./cmd/agentgate-demo ./cmd/agentgate-verify ./cmd/agentgate-provider ./cmd/agentgate-witness ./cmd/agentgate-eval ./cmd/agentgate-killsuite
sha256sum -c BINARIES_SHA256.txt                                                       # expected: 6 lines OK
python docs/paper/artifact/check_build_manifest.py --bin bin docs/paper/data/build3/build-manifest.txt
```

PowerShell: `$env:CGO_ENABLED='0'; $env:GOFLAGS='-mod=vendor'; $env:GOPROXY='off'; $env:GOTOOLCHAIN='local'; $env:GOWORK='off'; $env:GOENV='off'; $env:GOOS='windows'; $env:GOARCH='amd64'; $env:GOAMD64='v1'`
and the same `go build` line. The provider and witness binaries must sit
next to `agentgate-demo` and `agentgate-eval`.

Expected: `sha256sum -c` prints `OK` for the six binaries, and
`check_build_manifest.py` ends with `RESULT: PASS (sources and binaries: 6
given)`: 0 of the 258 module files, 385 third-party files and 1,221
standard-library files differ, and the six binaries equal the manifest's.
The binary hashes are:

| binary | SHA-256 |
|---|---|
| agentgate-demo.exe | `1ec5dfc9d63f2ed786abb86b7a02e940816287c77e20dca35d4d8977163d6f53` |
| agentgate-verify.exe | `04038f9f71196b35bbd232b794523a9654e342184e9ab7ef89979685862f432f` |
| agentgate-provider.exe | `a7329c9d2a53e7814c1b865f59c2fac55a9fea83f3c24376a8292a8e014a6e39` |
| agentgate-witness.exe | `e33555540c12939516bc2dcd5a9d3dbff83ee95029f04e4019378aef1d20821a` |
| agentgate-eval.exe | `cc4b96130398f877243431d4ccc84290561e48e00539aeafc67654c122e6768e` |
| agentgate-killsuite.exe | `23ddf21ba7702a18256e9b700e95062b430fca6d84a75ce9ab7e0fc49f3eeb47` |

`python docs/paper/artifact/check_build_manifest.py --rebuild docs/paper/data/build3/build-manifest.txt`
does the same build in a temporary folder with the flags and environment the
manifest records, and compares. What each flag does, and what we checked:
`docs/paper/artifact/REPRODUCIBILITY.md`, section 2. The command builds
Windows x64 binaries on any system; builds on other machines and host
systems are untested. To run the routes below on Linux or macOS, build a
second set without the three target variables (its hashes differ).

## Quick check of the central result (about 2 min)

This repeats the key-theft simulation (one repetition instead of ten) and
compares it with the recorded build-3 result.

```
bin/agentgate-eval -host-label review-host compromise -runs 1 -out OUT-quick -work WORK-quick
python docs/paper/data/build3/compromise/analyze_compromise.py OUT-quick
python docs/paper/artifact/quick_check.py OUT-quick
```

Expected: `quick_check.py` prints `RESULT: PASS` and exits 0. An *attack* is
one edit type, key set and anchor condition (7 x 12 x 4 = 336 per verifier
setting), verified in both designs; binding *changed the outcome* of an
attack if the bound design detected it and the unbound design accepted it
(strongest attacker). The script checks:

- outcomes changed by binding per verifier setting, of 336 attacks: full
  verifier 0, no snapshot check 8, no replay 12, both checks off 12; the same
  counts among the 168 attacks without a head anchor and 0 among the 168
  with one; 6 distinct pairs of edit type and key set without replay;
- detected attacks per design (bound / unbound), of 336: full 313 / 313, no
  snapshot check 313 / 305, no replay 295 / 283, both off 295 / 283; of the
  168 without a head anchor: 145 / 145, 145 / 137, 127 / 115, 127 / 115;
- every one of the 2,688 results (336 attacks x 2 designs x 4 settings)
  equals the recorded `docs/paper/data/build3/compromise/strongest.csv`;
- the oracle agreement printed by the analyzer, of 560 labelled results:
  main version 514 with the full verifier; alternative versions 540 (full),
  536 (no snapshot check), 560 (no replay).

`python docs/paper/artifact/quick_check.py docs/paper/data/build3/compromise`
runs the same checks on the recorded data alone (no build needed). This is
the key-theft simulation: the verifier skips the signature checks of the
roles the attacker holds, and nothing is re-signed (the real-key tests below
check it).

## Regenerate every table

```
python docs/paper/artifact/regenerate_tables.py docs/paper/data/build3 --quiet
```

Expected: the last line is `RESULT: PASS` (exit 0). The script recomputes
every number of `EXPECTED_TABLES.md` that has machine-readable data (162
table rows, 759 values and claims) from the CSV and JSON files in
`docs/paper/data/build3` (never from a `RESULTS.md`), compares each with the
document, and lists the 100 rows it does not recompute, with the reason:
rows marked **go test** (asserted by the tests below), the version crosswalk
(earlier builds), definitions and prose. `--json OUT.json` writes every
comparison. The tests of the script: `python docs/paper/artifact/test_artifact_scripts.py`
(53 tests, `OK`).

## Real-key tests

No run's private key is in this archive, and no tool or command re-signs a
run folder. The tests below create keys in memory, write small synthetic
runs in the gateway's format (*fixtures*) and sign edits of them with real
Ed25519 keys. Fixture results are not gateway runs of the frozen binaries,
and all keys are held in one process. The test files are part of commit
`8a30fd4`, the commit of build 3 (`internal/auditverify/fixture/held.go`,
`internal/auditverify/round4_{signed_attacks,signed_fields,lifecycle}_test.go`;
their names are kept from when they were written).

Only `fixture.ResignHeld` signs. Its keys are derived in memory from a fixed
label; it refuses a folder whose `keys.json` lists any key that is not the
fixture's key of that role, a folder with any signed record or provider
journal receipt naming a foreign key, and a key set without the audit key,
and it writes nothing unless every check passed (a refused call leaves the
folder byte for byte as it was). Nothing reads, writes or exports a key.
`fixture.RestoreUnheld` (the attacker who leaves the records it cannot sign
untouched) signs nothing.

Set the build environment first (`export GOFLAGS=-mod=vendor GOPROXY=off
GOTOOLCHAIN=local`). All real-key tests at once (about 20 s with
compilation):

```
go test -count=1 -v -run 'TestRound4|TestResignHeld' ./internal/auditverify/ > realkey.log; tail -1 realkey.log
grep -c -- '^--- PASS' realkey.log        # 10 top-level tests
grep -c -- '^    --- PASS' realkey.log    # 77 subtests (62 field edits + 15 histories)
grep -c -- '--- FAIL' realkey.log         # 0
```

Expected: the last line `ok  agentgate/internal/auditverify`, 10 top-level
tests and 77 subtests PASS, none FAIL. Each test asserts its counts and fails
if any differs. The summary lines of the `-v` log (the logs say "cells" for
fixture results: one fixture case under one verifier setting and one anchor
condition, 4 x 3 = 12 per case):

| code | test | expected summary in the `-v` log | paper |
|---|---|---|---|
| RS | `TestRound4RealSignaturesAgreeWithSimulation` | `34 cases (0 not applicable), 408 cells, 888 verifications`; `agreement: exact 336/336; partial-adapter bracket ... 72/72`; `REAL accepted 96 ...; partial cells: SIM with ADAPTER accepts 40, REAL 0; head anchor detected 136/136` | V-A: 336 of the 1,196 results; the 72 / 40 overstatement; Table III F marks |
| RB | `TestRound4RationalAttackerBinding` | `20 cases, 240 cells, 494 verifications ...; exact agreement 240/240; REAL accepted 24; head anchor detected 80/80` | V-A; Tables I-III: smaller key sets detected with no signature failing |
| SF | `TestRound4ValidlySignedInconsistentFields` (62 subtests) | `approval lineage detected 12, UNCHECKED accepted 5`; `classification binding detected 7, UNCHECKED accepted 0`; `effect binding detected 15, UNCHECKED accepted 5`; `provider evidence detected 11, UNCHECKED accepted 7` (45 detected, 17 accepted) | Table II field edits 7 of 7, 15 of 20, 11 of 18, 12 of 17; VII L4 |
| LR | `TestRound4LifecycleRealVsSimulation` | `35 cases, 420 cells, 840 verifications; exact agreement 420/420` | V-A; Table I |
| LRR | `TestRound4LifecycleRationalAttacker` | `13 of 35 cases, 156 cells, 325 verifications ...; exact agreement 156/156; ... head anchor detected 52; binding ablation VERIFIED in 4/13` | V-A; Table I |
| LH | `TestRound4LifecycleHistories` (15 subtests) | 15 histories: 12 detected, 3 accepted (an optional provider receipt removed, a deleted RECONCILED reported as UNCERTAIN, a genuine ABSENT given twice) | III-D, V-A: 21 of 27 histories detected (with the 12 conflicting histories of the lifecycle tests) |
| NC | `TestRound4NoCapabilityReclassifiedInPlace` | `full:FAILED [policy.replay]`, `no-replay:VERIFIED`, `no-replay-no-snapshot:VERIFIED`, `no-snapshot-bound:FAILED [policy.replay]`, evidence `audit_only` | Table I, last row |
| -- | `TestRound4LogOnlyProviderEditLeavesJournal`, `TestResignHeldLeavesAGenuineRunUnchanged`, `TestResignHeldRefusesNonFixtureKeys` | PASS (a log-only provider edit leaves the journal; an unedited run comes back byte-identical; every refusal leaves the folder unchanged) | -- |

The paper's "1,196 results" are 44 (the audit-key comparison
`TestSimulationAgreesWithRealAuditKeyResigning`, below) + 336 (RS, exact) +
240 (RB) + 420 (LR) + 156 (LRR); its "33 cases in which the attacker left
untouched every record it could not sign" are 20 (RB) + 13 (LRR). The
recorded logs: `docs/paper/data/build3/fixture-studies/logs/` (study s7);
the counts per case: `fixture-studies/round4_summary.json`,
`signed_fields.csv`, `lifecycle_histories.csv`.

**The build-3 checks** (status reply date and order, unresolved operations,
capability `cnf`, earlier-segment keys, witness continuation and run status
v2):

```
go test -count=1 -v -run '^(TestReconciledStatusDate|TestReconciledNeedsAReason|TestPendingCapabilityIsIncomplete|TestCapabilityConfirmationKey|TestEarlierSegmentKeysAnchor|TestEarlierSegmentKeyPinsRefused|TestWitnessStatusContinuationLinkage|TestWitnessStatusEnrollmentKID|TestWitnessRunStatusV2)$' ./internal/auditverify/
```

Expected: `ok`, 9 top-level tests and 70 subtests PASS. They assert 91
cases: 50 refused, 23 accepted, 8 reported incomplete, 10 controls
(`fixture-studies/round5_cases.csv`; per rule: `EXPECTED_TABLES.md`,
"Build-3 checks").

**Other fixture tests** (lifecycle, key sets, clocks, simulation check):

```
go test -count=1 -v -run '^(TestSimulationAgreesWithRealAuditKeyResigning|TestEachRoleUnderSimulation)$' ./internal/auditverify/
go test -count=1 -v -run 'TestLifecycle|TestRecoveryRecords|TestReconciledAdapterReceipt|TestReplayedAndConfirming' ./internal/auditverify/
go test -count=1 -v -run 'TestExtraKeySets' ./internal/auditverify/
go test -count=1 -v -run '^TestFlaggedOperationRecoveryVerifies$' ./cmd/agentgate-eval/
```

| test | what it shows (recorded: `docs/paper/data/build3/fixture-studies/`) |
|---|---|
| `TestSimulationAgreesWithRealAuditKeyResigning` | 44 of 44 fixture results identical with real audit-key re-signing (10 edits and one unedited control, 4 anchor conditions): same verdict, assurance and failing checks |
| lifecycle tests (L1, L1b, L2, L3, L4, 12 conflicting histories, adapter receipt on RECONCILED, flag rules of recovery records and stored answers) | on the reconciliation path the audit and issuer keys with a signed status reply sufficed in every verifier setting (L3 6/6, L4 8/8); the build-2 form of L2 (a reply dated 2027 with no unresolved status before it) is now detected 4/4, the form that meets the date and order rules passes 4/4; 9 of 12 conflicting histories detected, 3 accepted with the flag kept and the weaker evidence reported |
| `TestExtraKeySets` | **simulation** on fixtures: A+X and A+P were accepted exactly where A was in all 56 edit-design-setting combinations; I+X never (0 of 56) |
| `TestFlaggedOperationRecoveryVerifies` | the real gateway in process: flagged recovery at 4 fault points x 3 retry paths, 12 of 12 pass, the flag kept |

The full list of the 12 fixture studies, with every test name, is
`docs/paper/data/build3/fixture-studies/run_studies.sh` (79 top-level tests,
243 subtests, all PASS).

## One process-kill test

```
bin/agentgate-killsuite run -verify bin/agentgate-verify.exe -reps 1 -host-label review-host -only kill/after_receipt/flag-message/same-id -out OUT-kill -work WORK-kill
```

A real gateway child process commits a flagged message, is killed after the
provider committed and the receipts were signed but before the
`EFFECT_EXECUTED` entry was written, and is restarted from disk; the exact
retry reconciles. Expected on the console and in `OUT-kill/summary.md`:
`acceptance yes`; `effects 1`; answers `NO_ANSWER` then
`COMMITTED/reconciled`; segment 1 verified alone `FAILED`
(`provider.matches_audit`: the killed process wrote no outcome entry after
the provider's commit, the expected verdict for this state) with an
`op.outcome_resolved` warning (since build 3 an operation with a capability
and no outcome is reported unresolved); the newest segment with the chain
followed `VERIFIED/ANCHORED`; `flag preserved yes`; classification evidence
`issuer_only_reconciled` (the adapter receipt was kept in memory only, so
the recovery depends on the issuer key). It takes under a second. The
program's own output calls a test case a "cell". The recorded run (39 test
cases x 5 repetitions = 195 test runs, 145 of them with a kill) is
`docs/paper/data/build3/killsuite/summary.md`; two test-run folders are in
`docs/paper/data/build3/killsuite/samples/`.

A process kill is not a power loss: the kernel's file cache survives, so a
killed process never loses a write it made. Flag preservation is reported,
not part of the acceptance verdict (45 of 45 flagged commits kept the flag
in the recorded run).

## Registration with the witness, and one multi-process run

The registration tests, with a real witness service in the test process and
fixtures:

```
go test -count=1 -v -run '^(TestRealWitnessAnchorsAGenuineRestart|TestPreemptionWithoutTheEnrollmentKeyIsRefused|TestFalseContinuationWithoutTheEnrollmentKeyIsRefused|TestASecondEnrolledGatewayCannotContinueTheRun|TestEnrollmentKeyHolderRegistersLikeTheGateway)$' ./internal/headwitness/
```

Expected: `ok`, 5 top-level tests and 6 subtests PASS. Every registration or
continuation not signed with the run's enrollment key is refused (19 of 19),
and the genuine run stays ANCHORED. The last test is a counterexample, not a
defence: a continuation forged with the gateway's enrollment private key is
VERIFIED and ANCHORED. In the prototype that key is stored under the same
user account as the gateway, so registration stops a process that cannot
read the key, not an attacker who controls the account.

One multi-process run, with the provider and the witness as separate
processes (about 3 s):

```
bin/agentgate-eval -host-label review-host custody -out OUT-custody -work WORK-custody
```

Expected: `custody: self-test passed; 36 verifications`; in
`OUT-custody/custody.md`: enrollment probes refused with the enrollment
error 5 of 5, the witness's state unchanged; the rollback is detected by the
witness's latest head (`head.anchor`) and accepted as ANCHORED from the
out-of-date witness head (#168), with `head_fresh` / `run_complete`
`not_checked` and a `freshness` entry; the live witness (`--witness-url`)
gives `head_fresh` pass. The recorded 20 runs: `docs/paper/data/build3/custody/`.
Its outside probe `custody/scripts/probe.py` sends registrations with and
without the enrollment key; for the signed ones,
`custody/scripts/enroll_sig.py` reads the enrollment key that the run on
your own machine created and signs the registration requests with it. That
script contains no key and re-signs no evidence.

## The partial Python verifier

`docs/paper/artifact/subset_verifier.py` is a second verifier in Python
(standard library only), written by the same authors from the specification
and the Go sources, sharing no code. It checks **parts of 15 of the 38
checks**, each only in part (the exact rule per check: `SUBSET_VERIFIER.md`,
"What the subset checks"):

| checks (in part) | what it verifies |
|---|---|
| `files.present`, `keys.hash`, `files.run_record` | the four run files exist and parse; the hashes of keys.json and run.json match the run's first entry; decisions name run.json's policy hash |
| `chain.entry_hash`, `chain.signature`, `chain.links` | every log line's hash, audit-key signature and link |
| `head.signature`, `head.matches` | the signed head and that it names the last entry |
| `keys.anchor`, `head.anchor` | the keys and head anchors given on the command line |
| `artifact.signature` | **capabilities and adapter receipts only** (COSE_Sign1, key role, Ed25519); not provider receipts, grants or approval records |
| `op.requires_policy`, `op.capability_bound`, `op.receipts_bound`, `policy.snapshot_bound` | the four binding checks: decision values opened and compared with the entries, capability and receipt bound to the FINAL hash, effect and policy hash, the snapshot hash recomputed |

**Not covered** (22 checks and the build-3 rules): `policy.replay`; the six
`delegation.*` checks; `provider.signature`, `provider.state_chain`,
`provider.matches_audit`, `op.outcome_resolved` (provider journal, receipts,
status replies, reconciliation, and the build-3 date and order rules);
`op.approval_bound`; `op.requires_validation`, `op.single_use`,
`op.no_effect_when_refused`; `artifact.effect_digest`,
`artifact.effect_readable`; `keys.valid`; `files.run_id`, `chain.time`,
`files.continuity` (restart segments) and `head.witness` (including the
continuation linkage). It reports its own crashes as `verifier.error`, the
38th ID, and computes no assurance levels, freshness or run completeness. On
a set of 74 folders fixed before any Python run it matched the Go verifier
in 296 of 296 verifications (74 x 4 anchor conditions). Its expectations are
the Go verifier's outcomes on our edit engine's mutants, so agreement shows
a faithful port, not independent confirmation. To run it: "Reproduce every
experiment" below, row "partial Python verifier".

## Verify sample evidence

```
bin/agentgate-verify samples/flag-run                       # VERIFIED, assurance CONSISTENT (no anchors)
bin/agentgate-verify --expect-keys <keys_sha256> --expect-head <head_entry_hash> samples/flag-run   # ANCHORED, head_fresh not_checked
bin/agentgate-verify --witness samples/flag-run-anchors/witness-head.json --witness-key <key> samples/flag-run
bin/agentgate-verify --expect-keys <keys_sha256> --expect-head <head_entry_hash> samples/flag-run-tamper-lab/rollback-8   # FAILED
bin/agentgate-verify samples/flag-run-restart/<newest segment folder>   # two segments across a gateway restart, verified as one run
bin/agentgate-verify samples/crash-restart/segment-2         # a restart of the in-process fault experiment
```

The anchor values are in `samples/flag-run-anchors/anchors.json` (the
witness key in `witness-key.txt`; for the restart folders in
`samples/*-restart-anchors/`); `samples/expected/` holds the verifier's
output for every folder and anchor condition. The report answers three
separate questions: is the evidence internally consistent and anchored (the
assurance level: `FAILED`, `CONSISTENT`, `ANCHORED`), is the anchoring head
the latest (freshness, `head_fresh`), and is the run complete (run
completeness, `run_complete`). The older summary verdict `VERIFIED`, kept
for compatibility, answers none of them: it means only that no check failed.
A saved witness head does not show that a later restart segment was
withheld; `--witness-url` against the live witness does. Exit status: 0
verified, 1 failed, 2 usage error.

## All tests

```
go test -count=1 ./...
```

Every included package's tests (a few minutes). The core ones:
`./internal/audit/ ./internal/auditverify/... ./internal/devcomposition/
./internal/demo/ ./internal/headwitness/ ./internal/opjournal/ ./cmd/...`.
A few tests of inherited packages that need archived code are not included
(`PROVENANCE.md`). On Windows, if the archive is extracted into a deep
folder, `go test` may stop with "fork/exec ...vet.exe: The directory name is
invalid" (the path-length limit when Go starts `vet` inside `vendor/`); add
`-vet=off` or extract to a shorter path.

## Test vectors

```
python docs/paper/artifact/check_vectors.py                 # second implementation of the encodings, standard library only
go run ./docs/paper/artifact/vectorgen -out vectors.json   # regenerates the file byte for byte:
cmp vectors.json docs/paper/artifact/test_vectors.json       # (Windows: fc /b)
```

`test_vectors.json` holds domain-separated SHA-256 hashes, deterministic
CBOR (valid and must-fail encodings), key-ID derivations, a canonical effect
and its digest, a COSE_Sign1 / Ed25519 signed delegation grant and canonical
audit-log lines with their head and keys.json, all produced by the project's
own code. The Python checker, by the same authors, recomputes them with
hashlib, its own CBOR encoder and its own RFC 8032 Ed25519 verifier (80
checks). It covers encodings, signatures and log chaining only, not the
verifier's 38 checks.

## Data formats

Every experiment folder under `docs/paper/data/build3/` has a `RESULTS.md`
(what was run, the key numbers, the comparison with build 2, the caveats), a
`build-manifest.txt` (the build it ran on and the manifest checks before and
after) and its raw results as CSV and JSON. The files that
`regenerate_tables.py` reads:

| folder | machine-readable results |
|---|---|
| `compromise/` | `strongest.csv` (one row per result and repetition), `flips.csv`, `flips_by_anchor.csv`, `results.csv` (all 51,840 rows), `analysis.json`, `oracle_agreement.csv`, `oracle_mismatches.csv`, `replacement_keys.csv`, `controls.csv`, `base_controls.csv` |
| `fixture-studies/` | `lifecycle.csv`, `lifecycle_histories.csv`, `signed_fields.csv`, `round5_cases.csv`, `registration_enrollment_cases.csv`, `simulation_agreement.csv`, `extra_keysets_summary.json`, `round4_summary.json`, `tests.csv`, `logs/` |
| `custody/` | `tamper_lab.csv`, `rollback_by_anchor.csv`, `dimensions_by_cell.csv`, `repeats.csv`, `repeats_summary.json`, `status_probe_summary.json`, `custody.json` |
| `crash/` | `crash.json`, `crash.csv`, `cli_crosscheck.csv`, `deny/crash.json` |
| `killsuite/` | `results.json`, `results.csv`, `journal_chronology.json`, `reconciled_dates.csv` |
| `concurrency/` | `analysis/runs.tsv`, `analysis/scenario_repetitions.csv`, `analysis/summary.json` |
| `misuse/` | `misuse.csv`, `misuse_category_map.csv`, `misuse_table.csv`, `misuse_analysis.json` |
| `robustness/` | `fuzz_summary.json`, `kill_score_*.json`, `refusal_conditions.json`, `coverage_summary.json`, `coverage_map.csv`, `coverage_map.json`, `check_counts.json` |
| `heldout/` | `heldout_summary.json`, `heldout_summary.csv`, `heldout_mutants.csv`, `heldout_survivors.csv` |
| `subset-corpus/` | `subset-result.json` |
| `baseline/` | `analysis.json`, `baseline.json`, the observation CSVs of the six runs (`baseline-*.csv`, `repeats/R*/`, `message/`), `stagecost/run*/stagecost.json`, `stagecost/run*/witnesspush.json`, `comparison-builds.csv` |

Output fields: `docs/paper/artifact/SCHEMAS.md`. Paths recorded in the data
appear as `<repo>`, `<work>`, `<scratch>` and `<home>`, and the machine name
as `review-host` (see `PROVENANCE.md`).

## Reproduce every experiment

Each command writes JSON, CSV and Markdown into `OUT`; `WORK` receives the
evidence folders (large). The recorded run of each, with its exact
parameters and caveats, is `docs/paper/data/build3/<experiment>/RESULTS.md`.
All are local measurements of this prototype with simulated providers.

| experiment | command (recorded data in `docs/paper/data/build3/`) |
|---|---|
| key-theft simulation and binding comparison | `bin/agentgate-eval -host-label review-host compromise -runs 10 -out OUT -work WORK`; then `python docs/paper/data/build3/compromise/analyze_compromise.py OUT` and `python docs/paper/data/build3/compromise/base_controls.py WORK bin/agentgate-verify.exe OUT` -> `compromise/` |
| real-key and other fixture tests | the `go test` commands above; the full list: `fixture-studies/run_studies.sh` -> `fixture-studies/` |
| partial Python verifier on a fixed set of folders | `go run ./docs/paper/artifact/corpusgen -out CORPUS -make-base -host-label review-host`, record the manifest hash outside the set, then `python docs/paper/artifact/subset_verifier.py --corpus CORPUS/manifest.json --expect-manifest-sha256 HEX --out CORPUS/subset-result.json` -> `subset-corpus/` (`SUBSET_VERIFIER.md`) |
| in-process faults | `bin/agentgate-eval -host-label review-host crash -out OUT -work WORK -repeat 20` (flag mode: the paper's 560 fault runs) and `... -repeat 10 -escalation deny` (280 fault runs, archive only) -> `crash/` |
| process-kill tests | `bin/agentgate-killsuite run -verify bin/agentgate-verify.exe -reps 5 -host-label review-host -out OUT -work WORK` (39 test cases x 5 = 195 test runs); `killsuite/recount_from_disk.py`, `reverify_dimensions.py`, `analyze.py` -> `killsuite/` |
| concurrency | `bin/agentgate-eval -host-label review-host concurrency -out OUT -work WORK -repeat 50 -n 8` (also `-n 32`, `GOMAXPROCS=1`, a `go build -race` binary) -> `concurrency/` |
| multi-process runs, freshness and run completeness | `bin/agentgate-eval -host-label review-host custody -out OUT -work WORK` (20 times; outside probes: `custody/scripts/`) -> `custody/` |
| policy misuse | `bin/agentgate-eval -host-label review-host misuse -out OUT -work WORK` and `... -escalation deny`; `misuse/analyze_misuse.py` -> `misuse/` |
| testing the verifier (fuzzing, line deletion, coverage) | `go test -run='^$' -fuzz=FuzzParseLogLine -fuzztime=120s ./internal/auditverify/` (also `FuzzCOSE`, `FuzzRunFiles`); `go run ./internal/auditverify/tools/refusalmutation -out kill_score.json` once with the full suite and once with the skip pattern of the 16 tests added late (`docs/demo/VERIFIER_CHECKS.md` §6); scripts in `robustness/scripts/` -> `robustness/` |
| mutants of three other kinds | `go run ./internal/auditverify/tools/refusalmutation -operator OP` with OP one of `append`, `boundary`, `equality`; definitions fixed in `docs/paper/data/revision/robustness/HELDOUT_OPERATORS.md`; scripts in `heldout/scripts/` -> `heldout/` |
| cost | `bin/agentgate-eval -host-label review-host baseline -out OUT -work WORK` (messages: `-workload message -configs direct,policy-only,full,full+journal`); the whole session: `baseline/tools/run_session.sh`; `python docs/paper/data/build3/baseline/analyze_baseline.py` -> `baseline/` |
| cost of one audit append; witness update (Windows; both skip unless their flag is given) | `go test -count=1 -v -run '^TestStageCost$' ./internal/audit/ -stagecost=10000 -stagecost.warmup=200 -stagecost.work=DIR -stagecost.out=OUT` and `go test -count=1 -v -run '^TestWitnessPushCost$' ./internal/headwitness/ -witnesspush=2000 -witnesspush.warmup=50 -witnesspush.out=OUT` -> `baseline/stagecost/` |

What repeats: outcome counts, verdicts, assurance levels and failing checks.
What does not: evidence files (fresh keys and identifiers on every run) and
times, which depend on the machine, its disk and its load.

## The evaluated build

Every result of the paper comes from **build 3**: six binaries (demo,
verifier, harness, provider, witness, process-kill tests) built on
2026-10-20 at 14:49 UTC with Go 1.26.6 (windows/amd64, offline) from
`git archive` of commit `8a30fd4`, not from a working tree. They were built
twice, in two folders of different name and depth with separate empty build
caches, and the six binaries were byte-identical. The manifest
`docs/paper/data/build3/build-manifest.txt` lists the SHA-256 of the six
binaries and of every file compiled into them: 258 module files, 385
third-party files and 1,221 standard-library files (1,870 entries). The
original manifest's SHA-256 is
`0c436fc9fec8989638dccf4d3e62d609ec033a884d421b659f7ed820886968eb` (the paper
prints `0c436fc9fec89896`); the copy here replaces local paths by `<repo>`
(`build-manifest.README.md`), so its own hash differs. Every experiment
re-hashed all 1,870 entries before and after its runs and found 0 different
(each experiment's `build-manifest.txt`). Tests and test-only tools were
compiled from the same commit; their files are listed in
`TEST_FILES_SHA256.txt` (all `same` as the commit).

`BUILD_CHECK.txt` records how `build_artifact.py` rebuilt the six binaries
from this archive's own files and compared them with the manifest: equal,
byte for byte. The sample evidence in `samples/` was produced by those
binaries (`samples/binaries_sha256.txt`).

What changed since build 2 (ten numbered changes:
`docs/paper/data/build3/RESULTS_BUILD3.md` §0.3): the verifier dates each
signed status reply against its operation and requires a reason (an
unresolved status or a restart) before a reconciled commit; it reports every
operation with a capability and no outcome as unresolved, which makes the
run incomplete; it compares the capability's `cnf` with the key that signed
the adapter receipt; a keys anchor of the newest segment no longer anchors
earlier segments' keys; the witness registers a run or continuation only
when it is signed with an enrollment key, the gateway pins the witness key,
and the witness run status (v2) names the enrollment key and is compared
with the folder's segments; and the binaries are built reproducibly. The
gateway itself (policy, capability, adapters, journal, audit log) did not
change. Every build-2 measurement that was repeated gave the same verdicts
and counts; the differences are listed in `EXPECTED_TABLES.md`, "Version
crosswalk, builds 1-3" (also `SUPPLEMENTARY.md` S17).

## Versions

`docs/paper/artifact/VERSION` holds the archive version (4) and
`docs/paper/artifact/CHANGELOG.md` lists what changed between versions:
version 1 = build 1 (2026-10-08), version 2 = build 2 (2026-10-10) and the
real-key tests first run on its sources (2026-10-19), version 3 = build 3
(2026-10-20), version 4 = build 3 with the documents matched to the
round-7 paper (2026-10-28). Only version 4 is distributed with the submission; the data of
builds 1 and 2 are inside it for the crosswalk. The project's version
history is available on request and at camera-ready.

**Independent reproduction: not done.** Every experiment ran on one machine,
by the authors. A reader's rerun with this archive is the first independent
one. The partial Python verifier is by the same authors and does not count
as one.

## Limits

- **Roles, not key holders.** Key counts count signing roles, not
  separately held keys: X is the three adapter keys, X_op the one that
  signed the edited operation's receipt, and X_all every adapter key whose
  receipt stays in the log. The prototype holds the audit, issuer and
  adapter keys in one process on one machine and one user account; the
  provider and the witness are separate processes, not separate key holders.
  Any benefit that needs separate key holders is a modeled benefit, not a
  property the prototype provides. The real-key tests also hold every key in
  one process.
- **The reconciliation path.** An effect can also be recorded as committed
  through reconciliation, on a signed status reply instead of an adapter
  receipt. An insider with the audit and issuer keys and a signed status
  reply (any local process can obtain one in this prototype) can relabel an
  executed operation as reconciled and change its classification, in both
  designs and every verifier setting (fixtures, real keys). Since build 3
  this needs a reply fetched while the operation was open and an earlier
  unresolved status, which the audit key can write; it adds no key. On that
  path binding's gain without replay is from A to A+I, not to A+I+X_op.
- **Registration with the witness.** It stops a process that cannot read
  the enrollment key, not an attacker who controls the gateway's account: a
  continuation forged with the enrollment key was ANCHORED. A made-up
  earlier segment is accepted with the newest segment's keys anchor alone
  and reported as not anchored.
- **Key-theft simulation.** The grid simulates key theft by skipping the
  signature checks of the roles the attacker holds; nothing is re-signed.
  On fixtures, edits were re-signed with audit, issuer, financial and
  message adapter and provider keys created in memory; the paper's Tables
  I-III mark the entries that also passed with real keys (F). Never used
  for real: the approval key, a document adapter key (the fixture has no
  document operation) and replacement keys with a new run ID. The attacker
  who leaves unheld records untouched is one choice of evidence per case,
  not a search. The reconciliation path was tested only on fixtures;
  deleting an executed operation is argued. No edit rewrote both segments of
  a restarted run. The no-snapshot-check setting covers only attackers who
  keep a valid snapshot.
- **Unchecked fields.** Validly signed edits of one field were detected in 45
  of 62 cases with exactly the expected checks; the 17 accepted ones touched
  fields no check reads (`docs/demo/FIELD_CHECK_MAP.md`; why each cannot
  change a claimed property, or which property it weakens:
  `SUPPLEMENTARY.md` S11).
- **Clocks.** Clock tests inject the capability-registry and delegation
  clocks in unit tests; no OS clock was changed. Freshness assumes that the
  witness's and the verifier's clocks agree within 2 minutes; the status
  reply dates assume that provider, issuer and log writer read one clock;
  grant expiry and the 60 s capability lifetime hold only under an honest
  gateway clock.
- **Process kills are not power loss.** The process-kill tests kill
  processes at marked points; power-loss states were simulated, and flush
  order on Windows was checked by reading the code only. The provider was
  restarted only after a clean shutdown, never while an operation was
  unresolved; only one journal write failure position was tested
  (`SUPPLEMENTARY.md` S5).
- **The partial Python verifier** is by the same authors and covers parts of
  15 of the 38 checks (above); agreement shows a faithful port, not
  independent confirmation.
- **Scope.** The experiments do not establish correct organizational
  policy, informed consent, power-loss durability, production crash safety,
  separate key holders or resistance to a fully compromised host. These are
  single-machine measurements of a prototype, not evidence of production
  readiness. More per experiment: each `RESULTS.md`, and `RESULTS_BUILD3.md`
  §4 and §5.

## Fresh-unzip check

Run on 2026-10-21 on the build machine (Windows 10, 12 CPUs), in an empty
folder outside the source tree, with only the zip and its `.sha256` file, Go
1.26.6 offline with an empty module cache and an empty build cache (the
build used `vendor/` only; the module cache stayed empty) and Python 3. All
routes passed:

- `sha256sum -c AgentGate_AIR2026_artifact.zip.sha256`: OK; after
  unpacking, `sha256sum -c SHA256SUMS.txt`: 3,848 of 3,848 files OK;
- cold build of the six binaries: 14 s; `sha256sum -c BINARIES_SHA256.txt`:
  6 of 6 OK; `check_build_manifest.py --bin bin
  docs/paper/data/build3/build-manifest.txt`: 0 of 258 module, 385
  third-party and 1,221 standard-library files differ, `RESULT: PASS
  (sources and binaries: 6 given)`, so the rebuilt binaries are byte for
  byte those of the evaluated build;
- quick check: `RESULT: PASS` (key-theft run 34 s, both scripts under 1 s):
  0 / 8 / 12 / 12 of 336 attacks changed by binding, all among the 168
  without a head anchor; detections 313 / 313, 313 / 305, 295 / 283,
  295 / 283 of 336; 0 of 2,688 results different from `strongest.csv`;
  oracle agreement 514 / 540 / 536 / 560; the same checks on the recorded
  data alone also `RESULT: PASS`;
- `regenerate_tables.py docs/paper/data/build3`: 162 table rows, 759 values
  and claims, 0 mismatches, `RESULT: PASS`;
- real-key tests (19 s with compilation): `ok`, 10 top-level tests and 77
  subtests PASS, 0 FAIL, every summary line as in the table above; the
  build-3 check tests: `ok`, 9 top-level tests and 70 subtests; the
  registration tests: `ok`, 5 top-level tests and 6 subtests;
- one process-kill test (under a second): `acceptance yes`, 1 effect, flag
  kept, segment 1 alone FAILED on `provider.matches_audit`, the newest
  segment VERIFIED/ANCHORED;
- one multi-process run (about 3 s): `self-test passed; 36 verifications`,
  enrollment probes refused 5 of 5, the rollback ANCHORED from the
  out-of-date witness head (#168);
- the commands of "Verify sample evidence": the verdicts and assurance
  levels stated there;
- `test_artifact_scripts.py`: 53 tests OK; the test vectors: 80 of 80;
  `TEST_FILES_SHA256.txt`: 233 of 233 test files and test-only sources the
  same as in commit `8a30fd4`.

## Not included

- The six binaries: rebuild them from the archive ("Rebuild and compare the
  binaries"); their hashes are in `BINARIES_SHA256.txt` and the manifest.
- The experiments' evidence folders (hundreds of MB; regenerate them with
  the commands above). One restart of the in-process fault experiment is
  included as `samples/crash-restart/`, and two process-kill test-run
  folders under `docs/paper/data/build3/killsuite/samples/`. The mutants of
  the key-theft simulation and the fixtures of the real-key tests are made
  and verified in memory and never stored.
- The process-kill tests' journal-write-failure folders: their signed
  `journal_unavailable` entry contains the absolute path of the journal
  file, which cannot be removed without breaking the signature
  (`killsuite/journal_chronology.md` gives the chronology with the path
  replaced).
- The signed folder of one repetition of the superseded 2026-10-07
  concurrency run, which names the machine (`WITHHELD.md` in its place).
- Any private signing key of a run (see `PROVENANCE.md`, "Private keys").
- The archived parts of the earlier prototype that the six programs do not
  compile, and the paper's sources.
