# Reproducing the binaries, the results and the tables

This page lists the exact commands to rebuild the six AgentGate binaries of
build 3, check every hash, rerun each experiment and recompute each table of
the paper, and it says what a reader cannot reproduce independently. Run
every command from the archive root (`AgentGate_AIR2026_artifact/`), or from
the repository root. `DATA` stands for `docs/paper/data/build3`, the data
folder of the evaluated build.

Everything is offline. Needed: Go 1.26.6, Python 3 (standard library only),
Windows 10 or 11 on x64 for the commands as written (the experiments ran
there). On Windows the binaries end in `.exe` and Python is usually `py`.

## 1. What can be reproduced, and how

| item | how | expected |
|---|---|---|
| the archive itself | `sha256sum -c AgentGate_AIR2026_artifact.zip.sha256` (next to the zip) | `OK` |
| every file in the archive | `sha256sum -c SHA256SUMS.txt` | every line `OK` |
| the source of the frozen binaries | `check_build_manifest.py` re-hashes every compiled file against the build-3 manifest (section 3) | 0 files differ |
| the six binaries, byte for byte | rebuild with the command of section 2 and compare with `BINARIES_SHA256.txt` and the manifest | 6 of 6 equal |
| each experiment's outcome counts | rerun it (section 4); counts, verdicts and failing checks repeat, times do not | the values of `DATA/<experiment>/RESULTS.md` |
| each table and number of the paper that has machine-readable data | `regenerate_tables.py DATA` (section 5) | `RESULT: PASS` |

## 2. Rebuild the binaries

Build 3 was built so that the binaries depend only on the source, the Go
version and the target (windows/amd64), not on the folder, the machine or
the build cache. In the archive:

```
export CGO_ENABLED=0 GOFLAGS=-mod=vendor GOPROXY=off GOTOOLCHAIN=local GOWORK=off GOENV=off GOOS=windows GOARCH=amd64 GOAMD64=v1
go build -trimpath -buildvcs=false -ldflags=-buildid= -o bin/ ./cmd/agentgate-demo ./cmd/agentgate-verify ./cmd/agentgate-provider ./cmd/agentgate-witness ./cmd/agentgate-eval ./cmd/agentgate-killsuite
sha256sum -c BINARIES_SHA256.txt
python docs/paper/artifact/check_build_manifest.py --bin bin docs/paper/data/build3/build-manifest.txt
```

PowerShell: `$env:CGO_ENABLED='0'; $env:GOFLAGS='-mod=vendor'; $env:GOPROXY='off'; $env:GOTOOLCHAIN='local'; $env:GOWORK='off'; $env:GOENV='off'; $env:GOOS='windows'; $env:GOARCH='amd64'; $env:GOAMD64='v1'`,
then the same `go build` line, then `Get-FileHash bin\*.exe` and compare with
`BINARIES_SHA256.txt`.

Expected: six `OK` lines from `sha256sum -c`, and from
`check_build_manifest.py` the last line `RESULT: PASS (sources and binaries:
6 given)`. The six hashes are those of the build-3 manifest (also listed in
`README.md`, "Rebuild and compare the binaries").

In the repository (which has the git history), the frozen build itself is
made by `docs/paper/build/make_build.py`:

```
py docs/paper/build/make_build.py --commit 8a30fd4 --out DIR
```

It takes `git archive 8a30fd4` (never the working tree), vendors the modules
from the offline module cache, builds in two folders of different name and
depth with separate empty build caches, stops unless both give identical
binaries, and writes `DIR/MANIFEST.txt`. Its six binary hashes equal those
of `docs/paper/data/build3/build-manifest.txt` (checked 2026-10-21; see
"The checks we ran" below).

What each part of the build command does:

- `-trimpath` removes the build folder and the Go installation folder from
  the binaries (file names in them become module paths).
- `-buildvcs=false` leaves out the version-control stamp (commit and
  "modified" flag), which differs between a repository and an unpacked
  archive.
- `-ldflags=-buildid=` leaves out the build ID, which is derived from the
  Go tools' own IDs and so depends on how the Go installation was built.
- `GOFLAGS=-mod=vendor` builds from `vendor/`; a build from a module cache
  records each dependency's checksum in the binary and so gives other
  bytes.
- `CGO_ENABLED=0` makes the result independent of whether a C compiler is
  installed (none of the six binaries uses C code; the setting is recorded
  in the binary).
- `GOOS=windows GOARCH=amd64 GOAMD64=v1` fix the target (recorded in the
  binary), so the command gives the same Windows x64 binaries, with `.exe`,
  on any host; without them Go builds for the host.
- `GOENV=off` ignores settings saved with `go env -w` (for example
  `GOEXPERIMENT` or `GOFIPS140`, which would change the bytes).

`BINARIES_SHA256.txt` lists the hashes of the binaries that
`build_artifact.py` built from the archive's own files, and
`BUILD_CHECK.txt` says which manifest they were compared with and the
result. `build_artifact.py` refuses to write the archive unless the six
built binaries are exactly the six the build-3 manifest lists, with the same
hashes, so a match also links a reader's binaries to the frozen ones.

```
python docs/paper/artifact/check_build_manifest.py --rebuild docs/paper/data/build3/build-manifest.txt
```

builds the six binaries again in a temporary folder with the flags and
environment the manifest records (an empty module cache, a new build cache
and `GOENV=off`) and compares their SHA-256 with it. In the repository it
first copies `go.mod`, `go.sum` and the source folders to the temporary
folder and vendors them from `$GOMODCACHE`. The last line says what was
checked: `RESULT: PASS (sources and binaries: 6 rebuilt)`; `RESULT: FAIL`
(exit 1) if a file or binary differs or is missing, or if a manifest that
says `reproducible build: yes` does not list exactly the six binaries or
lacks the flags or the target; `RESULT: INCOMPLETE` (exit 1) if a binary
check was asked for but could not be done (`go version` is not go1.26.6, or
the manifest records no reproducible build, as build 2's); without
`--rebuild` or `--bin`, `RESULT: PASS (sources only; binaries not checked)`.

**The checks we ran.** On 2026-10-20 the frozen build was made twice by
`make_build.py`, in two folders of different name and depth, each with its
own empty build cache: 6 of 6 binaries byte-identical. The verifier rebuilt
from the robustness experiment's source copy with the same flags was
byte-identical to the frozen `agentgate-verify.exe`. On 2026-10-21
`make_build.py --commit 8a30fd4` was run again into a new folder, and
`build_artifact.py` and a fresh unzip of the archive (README, "Fresh-unzip
check") rebuilt the six binaries from the archive's `vendor/` with an empty
module cache; all gave the manifest's six hashes. A build from the module
cache instead of `vendor/` gives other hashes for every binary with
third-party code, which is why the command uses `vendor/`. Not tested: a
build on another machine or another operating system with `GOOS=windows
GOARCH=amd64` (Go's toolchain is designed to give the same bytes there, but
we did not check it) and a Go installation built from source.

## 3. Verify hashes

```
sha256sum -c AgentGate_AIR2026_artifact.zip.sha256                         # the archive (next to the zip)
sha256sum -c SHA256SUMS.txt                                                # every file in it
python docs/paper/artifact/check_build_manifest.py DATA/build-manifest.txt # compiled sources: module, vendor/, standard library
sha256sum -c BINARIES_SHA256.txt                                           # after building (section 2)
```

`check_build_manifest.py` re-hashes the module's own files (258), the
third-party files in `vendor/` (385) and, if `go version` says go1.26.6,
the standard library (1,221), and prints one line per group with the number
that differ. `TEST_FILES_SHA256.txt` lists every test file and test-only
source (they are not compiled into the binaries, so the manifest does not
list them) and whether each equals the build-3 commit's copy.

## 4. Rerun each experiment

Build the binaries first (section 2). Each command writes JSON, CSV and
Markdown into `OUT` and its evidence folders into `WORK`; give every run new,
empty folders. The recorded run of each, with its exact parameters and
caveats, is `DATA/<experiment>/RESULTS.md`; output fields are in
`SCHEMAS.md`.

| experiment | command | recorded in |
|---|---|---|
| key-theft simulation and binding comparison | `bin/agentgate-eval -host-label review-host compromise -runs 10 -out OUT -work WORK`, then `python DATA/compromise/analyze_compromise.py OUT` and `python DATA/compromise/base_controls.py WORK bin/agentgate-verify.exe OUT` | `DATA/compromise/` |
| in-process faults | `bin/agentgate-eval -host-label review-host crash -out OUT -work WORK -repeat 20` (deny mode: `-repeat 10 -escalation deny`) | `DATA/crash/` |
| process-kill tests | `bin/agentgate-killsuite run -verify bin/agentgate-verify.exe -reps 5 -host-label review-host -out OUT -work WORK` | `DATA/killsuite/` |
| concurrency | `bin/agentgate-eval -host-label review-host concurrency -out OUT -work WORK -repeat 50 -n 8` (also `-n 32`, `GOMAXPROCS=1`, and a `go build -race` binary) | `DATA/concurrency/` |
| multi-process runs, freshness and run completeness | `bin/agentgate-eval -host-label review-host custody -out OUT -work WORK` (outside probes: `DATA/custody/scripts/`) | `DATA/custody/` |
| policy misuse | `bin/agentgate-eval -host-label review-host misuse -out OUT -work WORK` and the same with `-escalation deny`, then `python DATA/misuse/analyze_misuse.py` | `DATA/misuse/` |
| cost | `bin/agentgate-eval -host-label review-host baseline -out OUT -work WORK` (messages: `-workload message -configs direct,policy-only,full,full+journal`), then `python DATA/baseline/analyze_baseline.py` | `DATA/baseline/` |
| cost of one audit append, witness update (Windows) | `go test -count=1 -v -run '^TestStageCost$' ./internal/audit/ -stagecost=10000 -stagecost.warmup=200 -stagecost.work=DIR -stagecost.out=OUT`; `go test -count=1 -v -run '^TestWitnessPushCost$' ./internal/headwitness/ -witnesspush=2000 -witnesspush.warmup=50 -witnesspush.out=OUT` | `DATA/baseline/stagecost/` |
| testing the verifier | `go test -run='^$' -fuzz=FuzzParseLogLine -fuzztime=120s ./internal/auditverify/` (also `FuzzCOSE`, `FuzzRunFiles`); `go run ./internal/auditverify/tools/refusalmutation -out kill_score.json` with the full suite and with the skip pattern of the 16 tests added late (`docs/demo/VERIFIER_CHECKS.md` section 6); the coverage map: `DATA/robustness/scripts/` | `DATA/robustness/` |
| mutants of three other kinds | `go run ./internal/auditverify/tools/refusalmutation -operator OP` for OP in `append`, `boundary`, `equality` | `DATA/heldout/` |
| partial Python verifier on a fixed set of folders | `go run ./docs/paper/artifact/corpusgen -out CORPUS -make-base -host-label review-host`; record the set's manifest hash outside it; `python docs/paper/artifact/subset_verifier.py --corpus CORPUS/manifest.json --expect-manifest-sha256 HEX --out CORPUS/subset-result.json` | `DATA/subset-corpus/` |
| real-key and other fixture tests | the `go test` commands of `README.md` ("Real-key tests"; the full list is `DATA/fixture-studies/run_studies.sh`) | `DATA/fixture-studies/` |

What repeats and what does not: every run draws fresh keys, identifiers and
timestamps, so evidence files never repeat byte for byte. Outcome counts,
verdicts, assurance levels and failing checks repeat (the key-theft
simulation recorded 0 of 2,688 results changing across its 10 repetitions;
the process-kill tests 0 of 39 test cases). Times, throughput and memory
depend on the machine, its disk and its load and will differ. The one
random analysis, the cost experiment's bootstrap, uses seed 20261007 and
10,000 resamples.

## 5. Recompute each table

```
python docs/paper/artifact/regenerate_tables.py DATA            # every comparison, then a summary
python docs/paper/artifact/regenerate_tables.py DATA --quiet    # mismatches and the summary only
```

Expected: `SUMMARY: 162 table rows checked (759 values recomputed from the
data and claims; 2 constants of this script compared), 100 not recomputed;
0 mismatches` and `RESULT: PASS` (exit 0).

The script recomputes each number of `EXPECTED_TABLES.md` that has
machine-readable data from the CSV and JSON files in `DATA` (never from a
`RESULTS.md`), prints the value the document gives next to the recomputed
one, and exits 1 on any difference, on a claim that does not hold, on a
document row it cannot find or whose cell prints fewer numbers than
expected, on a data file it cannot read, or when the document has a
Supplementary S1 row and there is no `docs/paper/artifact/loc_build3.csv`;
it exits 2 if `DATA`, the document or a `--loc` file named on the command
line does not exist. Decimal values are compared at the precision the
document prints. Two printed numbers are constants of the script, not data
(the 1 of "1 / (6 x 1.75 ms)" and the 16 clients of Little's law); they are
compared too, marked `*`, and not counted as recomputed. What it covers:

| paper table or section | recomputed from |
|---|---|
| headline numbers, the single accounting, Table III (outcomes changed by binding, detections, smallest accepted key sets per edit type and setting, oracle agreement), V-A numbers | `compromise/strongest.csv`, `oracle_agreement.csv`, `oracle_mismatches.csv`, `controls.csv`, `base_controls.csv`, `analysis.json` |
| Table II (P1, P4-P7 counts), Table IV, V-B numbers including registration with the witness | `custody/tamper_lab.csv`, `rollback_by_anchor.csv`, `repeats.csv`, `repeats_summary.json`, `status_probe_summary.json`, `dimensions_by_cell.csv`; replacement keys from `compromise/strongest.csv` |
| Table V, V-C numbers including the journal-failure chronology | `crash/crash.json`, `crash.csv`, `cli_crosscheck.csv`, `deny/crash.json`; `killsuite/results.json`, `results.csv`, `journal_chronology.json`; `concurrency/analysis/runs.tsv`, `scenario_repetitions.csv` |
| Table VI, V-D numbers | `misuse/misuse.csv`, `misuse_category_map.csv`, `misuse_table.csv`, `misuse_analysis.json` |
| Table VII, V-F numbers | `baseline/analysis.json`, `baseline.json`, the observation CSVs of the six runs, the quoted stage run (the one with the fewest appends over 10 ms: run1) `stagecost/run1/stagecost.json`, `stagecost/run3/witnesspush.json` |
| V-E, VII L4, the coverage map | `robustness/*.json`, `coverage_map.json`, `heldout/heldout_summary.json`, `subset-corpus/subset-result.json` |
| lifecycle fixture tests (L3, L4, conflicting histories, key-set simulation, audit-key comparison) | `fixture-studies/lifecycle.csv`, `extra_keysets_summary.json`, `simulation_agreement.csv` |
| build-3 manifest entry count; Supplementary S1 | `build-manifest.txt`; `docs/paper/artifact/loc_build3.csv` |

It ends with the rows it does not recompute, by reason: rows marked **go
test** (the real-key tests and the other fixture tests assert their own
counts; run them with the commands of `README.md`), the version crosswalk
(it repeats checked numbers or quotes builds 1 and 2), Table I (key sets
argued from those tests), definitions, and rows whose source is prose, code
or a test log (for example the two flag-loss bugs, the archive digest).

`quick_check.py` (README, "Quick check") recomputes Table III from a fresh
one-repetition run of the key-theft simulation, so it checks the experiment
and not only the recorded data. The tests of these scripts:
`python docs/paper/artifact/test_artifact_scripts.py` (53 tests).

## 6. What cannot be reproduced independently

- **No independent reproduction yet.** Every experiment ran on one machine,
  by the authors. A reader's rerun is the first independent one; nothing in
  this archive replaces it.
- **The second verifier is not independent.** `subset_verifier.py` was
  written by the same authors from the same specification and checks parts
  of 15 of the 38 checks. Its agreement with the Go verifier (296 of 296
  verifications) shows that two implementations agree; it does not validate
  the expected outcomes, and a misunderstanding shared by both would not
  show. The oracle of expected outcomes was also written by the authors
  (fixed before the runs, `ORACLE_FREEZE.md`).
- **Builds 1 and 2 cannot be rebuilt byte for byte.** They were built with a
  plain `go build` inside the repository, so their binaries contain the
  absolute build path and the version-control stamp. What links them to
  their source is their manifests' lists of compiled files. Only build 3,
  the evaluated build, is reproducible.
- **Timings belong to one machine.** Latency, throughput, memory and the
  stage costs come from one Windows machine with a 97.5 % full consumer
  NVMe disk; a rerun elsewhere gives other values. The stage-cost benchmark
  runs on Windows only.
- **One machine, one account.** The gateway, the provider and the witness
  run as separate processes but on one machine under one user account, with
  keys created per run. The archive cannot show separate key holders,
  because the prototype does not have them.
- **Process kills, not power loss.** The process-kill tests end processes;
  they do not cut power or test a disk's write cache.
- **Evidence differs on every run.** Fresh keys and identifiers mean a rerun
  never reproduces an evidence file; only counts and verdicts can match.
- **One evidence folder is withheld.** It records the machine's name inside
  signed data (`docs/paper/data/revision/.../WITHHELD.md`); its numbers are
  in the files next to it. The journal-write-failure folders are also left
  out (their signed entries contain an absolute local path).
