# Result schemas: every output file, its fields and units

For each experiment of `docs/paper/data/build2/`: the files a run writes,
the program or script that writes them, and the meaning and unit of the
fields the paper uses. The complete field list of each JSON object is the
Go struct named in the "written by" column (its `json:"..."` tags); the
field names below are the JSON names. Paths are relative to
`docs/paper/data/build2/` unless they start with `cmd/`, `internal/` or
`docs/`. Written 2026-10-10 for build 2.

## 1. Units of counting

| word | meaning | example |
|---|---|---|
| **attack cell** | one edit operator, one attacker key set and one anchor condition, under one verifier setting, evaluated in both designs (bound, unbound) | 7 x 12 x 4 = 336 attack cells per setting |
| **design result** | one attack cell in one design under one verifier setting (one row of `strongest.csv` per repetition) | 672 per setting; 2,688 per run over 4 settings |
| **labelled design result** | a design result the frozen oracle labels (10 of the 12 key sets) | 560 per setting |
| **fixture result** | one fixture case (edit, key set, design on a synthetic fixture run) verified under one setting and one anchor condition | 12 per case in the post-freeze tests (`ROUND4_SIGNED_ATTACKS.md`, which says "cells") |
| **variant** | one way of making an edit: `plain`, `forge-snapshot`, `forge-restate`; a design result is detected only if every applicable variant is detected (the strongest attacker) | `compromise/results.json` rows carry `variant` |
| **verification** | one run of the verifier on one folder, with one anchor condition and one verifier setting | 49,920 mutant verifications (compromise); 296 (subset corpus); 365 (kill suite) |
| **schedule** | one in-process fault combination: fault point x retry kind (same or fresh operation ID) x restart (none or journal) x repetition, on a fresh gateway with two operations | 560 schedules (crash) |
| **case run** | one kill-suite case (kill point, provider fault, power-loss surrogate, journal write failure or replay case) in one repetition; the suite's files call a case a "cell" | 39 cases x 5 = 195 case runs (145 with a kill) |
| **operation** | the unit that may produce at most one provider effect, named by (tenant, principal, operation ID); a fresh ID is a new operation | 1,120 (crash), 235 (kill suite), 10,740 (concurrency) |
| **call** | one MCP tool call; each ends in one status, whose scope says whether it speaks for the operation (`operation`) or for this call only (`call`) | 33,040 calls (concurrency); 2,240 answers (crash) |
| **scenario repetition** | one concurrency scenario (N simultaneous calls) in one repetition | 7 scenarios x 260 = 1,820 |
| **repetition** | a rerun of a deterministic script with new keys, identifiers and timestamps; it shows stability, not an independent sample | `-runs 10`, `-repeat 20`, `-reps 5` |
| **paired trial** | one call to every cost configuration back to back, in a rotated order; differences are taken within a trial | 500 trials in 10 blocks of 50 (baseline) |
| **custody run** | one demo self-test with the provider and the witness as separate processes, followed by an anchor matrix | 20 runs |

## 2. Fields shared by several experiments

**`environment`** (`cmd/agentgate-eval/common.go`, `environment`):
`go_version`, `goos`, `goarch`, `num_cpu`, `gomaxprocs`,
`clock_granularity_ms` (median observed step of Go's wall clock, ms; about
1 ms here), `started_at` (UTC, RFC 3339), `command` (the command line,
paths replaced).

**A verifier outcome** (`cmd/agentgate-eval/harness.go`, `verifyOutcome`):
`folder`, `anchors` (`none`, `pinned`, ...), `verdict` (`VERIFIED` = no check
failed, the legacy verdict; `FAILED`), `assurance` (`FAILED`, `CONSISTENT`,
`ANCHORED`; prefix `SIMULATED_` in a key-compromise simulation),
`failing_checks` (check IDs of `docs/demo/VERIFIER_CHECKS.md`), `findings`
(first failures, "check #seq: detail"), `dimensions` (the seven check-based
dimensions plus the derived `head_fresh` and `run_complete`, each `pass`,
`fail` or `not_checked`), `missing` (the gaps of the evidence, text),
`missing_by_kind` (counts per kind: `freshness`, `unresolved`, `issuer_only`,
`other`), `entries` (log entries), `operations` (operations in the report).
Detected means verdict FAILED; any VERIFIED, with any assurance, warning or
Missing entry, is acceptance.

**The verifier's JSON report** (`agentgate-verify --json`; Go type
`auditverify.Report`, `internal/auditverify/verify.go`): `verdict`,
`assurance`, `checks[]` (id, status pass/fail/warn/not_applicable, items),
`failures[]`, `warnings[]`, `dimensions`, `missing`, `missing_kinds` (one
kind per `missing` entry, same order), `assumptions`, `segments[]`,
`run_id`, `head_seq`, `head_hash`, `anchors`, `operations[]`
(per operation: `status`, `flagged`, `classification_evidence`, ...),
`counts` (`entries`, `flagged`, `flagged_unconfirmed`,
`classification_evidence` per class, ...), `simulation` when roles were
assumed compromised. Classification evidence classes: `issuer_adapter`,
`issuer_only_reconciled`, `issuer_only_unresolved`, `issuer_only_no_effect`,
`audit_only` (`docs/demo/VERIFIER_CHECKS.md` §1). Number trap: `counts.flagged`
includes unresolved flagged operations; executed flagged operations =
`counts.flagged` - `counts.flagged_unconfirmed`.

**`build-manifest.txt`** (every folder): the experiment's manifest checks
(UTC time, "checked 1868 files, 0 differ"), the binaries used by SHA-256,
and, for experiments that compiled tests, the test binaries and test-only
source files by SHA-256.

## 3. Per experiment

### compromise/ (key-compromise simulation and binding ablation)

Written by `agentgate-eval compromise` (`cmd/agentgate-eval/compromise.go`,
format `agentgate-compromise/v2`) and `analyze_compromise.py`.

| file | written by | one row / content | fields used (units) |
|---|---|---|---|
| `results.json`, `results.csv` | `compromiseRow` | one mutant verification (run, design, operator, key set, variant, anchors, verifier setting) | `run`, `design` (bound, unbound), `mode` (flag; human for relabel-approved), `operator`, `keyset` (12 key sets), `variant`, `anchors` (none, keys, head, both), `verifier_config` (full, no-replay, no-replay-no-snapshot, no-snapshot-bound-only), `verdict`, `assurance`, `detected` (bool), `simulated` (bool), `failing_checks`, `applied` (false when the operator or variant does not apply), `not_applicable` (why), `unrepaired` (what the engine could not make consistent) |
| `controls.csv` | `controlRow` | one verification of an unedited base run | `simulation` (`real` or `all-roles`), `anchors`, `verifier_config`, `verdict`, `assurance`, `failing_checks` |
| `strongest.csv` | `strongestCell` | one cell and run, strongest attacker | `run`, `design`, `mode`, `operator`, `keyset`, `anchors`, `verifier_config`, `variants` (applied), `detected` (true only if every applied variant was detected), `evading_variants`, `plain_detected` |
| `compromise.md` | the runner | human-readable summary | |
| `cells.csv`, `matrices.json` | `analyze_compromise.py` | one cell over all runs; operator x key set matrices | strongest and per-variant outcome, modal failing checks, oracle labels |
| `flips.csv` | same | cells whose outcome differs between bound and unbound (strongest attacker) | `kind` (binding = bound detected, unbound accepted), `bound_checks`, `oracle_primary_flip` |
| `flips_by_anchor.csv` | `breakdown.py` | flips per setting and anchor condition, "n/84" and "n/168" | |
| `keysets.json` | `analyze_compromise.py` | sufficient and minimal accepted key sets per operator | |
| `replacement_keys.csv` | same | all-replaced and all-stolen per anchor condition | `none`, `keys`, `head`, `both` = detected / undetected |
| `oracle_agreement.csv` | same | agreement per setting x reading x attacker | `agree`, `disagree` (of `total_cells` = 560), `verifier_detected_oracle_undetected` |
| `oracle_mismatches.csv` | same | every disagreeing cell | `cause` (S1 snapshot assumed unchecked; A3 mode assumed unchecked; C1, C2 target limits; F1 ...) |
| `analysis.json` | same | all of the above in one document | `flip_counts`, `unstable_cells`, `mismatch_cause_counts`, `controls` |
| `base_controls.csv/.json` | `base_controls.py` | the frozen `agentgate-verify` on the base runs | |

### fixture-studies/ (lifecycle, key sets, registration, clocks, flagged recovery)

Written by `go test -v` (test code only; `run_studies.sh`), parsed by
`analyze_fixture_studies.py`. Evidence labels: REAL-FX (real Ed25519
signatures with in-memory fixture keys), REAL-GW (the real gateway in
process), SIM (verifier-side simulation).

| file | content | fields |
|---|---|---|
| `logs/*.log` | the sanitized `go test -v` output of each study, twice (test binary and `go test`) | PASS lines, printed per-case outcomes |
| `tests.csv` | one top-level test | study, test, result, evidence label |
| `lifecycle.csv` | one printed lifecycle verification | `test`, `label`, `key_set`, `verifier_setting`, `anchors`, `verdict`, `assurance`, `failing_checks`, `run_flagged`, `run_flagged_unconfirmed`, `op_status`, `op_flagged`, `op_classification_evidence` |
| `extra_keysets_grid.csv`, `extra_keysets_summary.json` | A+X, A+P, I+X key sets (SIM) | `independent_cells` (56), `independent_cell_variant_pairs` (88), `independent_verifications` (616), `accepted_cells_per_setting`, `tallies` |
| `fixture_vs_frozen_grid.csv` | the fixture grid against the frozen 336-cell grid | agree / disagree per cell |
| `simulation_agreement.csv` | `TestSimulationAgreesWithRealAuditKeyResigning`, one row per edit and anchor condition | `edit`, `anchors`, `verdict`, `assurance`, `failing_checks_with_counts`, `same_as_build1_tree` |
| `summary.json` | the studies' counts | |

### subset-corpus/ (second implementation of a protocol subset)

Written by `corpusgen` (`docs/paper/artifact/corpusgen/main.go`) and
`subset_verifier.py --corpus` (`docs/paper/artifact/SUBSET_VERIFIER.md`).

| file | content | fields |
|---|---|---|
| `manifest.json` | the frozen corpus: every folder, its files by SHA-256, the Go verifier's expected outcome | per folder: `id`, `group`, `design`, `assume_compromised`, `applied`, `anchors` (per anchor condition), `files_sha256`, `expected` (the Go verifier's no-replay outcome), `go_full` (with replay) |
| `manifest.sha256`, `manifest-sha256-recorded.txt` | the manifest hash, recorded outside the corpus before any Python run | |
| `subset-result.json` | the comparison | `format`, `manifest_sha256`, `freeze_checked`, `setting` (no-replay), `summary` (`verifications`, `agree`, `binding_relevant` {verifications, agree, go_failed, go_accepted}, `binding_by_keyset`, `strongest_cells`, `binding_flips_go`, `binding_flips_subset`, `disagreements`), `rows[]` (`id`, `group`, `design`, `operator`, `keyset`, `variant`, `anchors`, `go_verdict`, `subset_verdict`, `agree`, `go_failing_checks`, `go_failing_subset_checks`, `subset_failing_checks`) |
| `rows.csv`, `flip_cells.csv`, `mutation_targets.csv`, `crosscheck-frozen-verify.json`, `ablations.json` | per-row table; flip cells; edited entries; the frozen `agentgate-verify` on the bound folders; post-hoc ablations of the subset | |

### crash/ (in-process faults, response loss, restart)

Written by `agentgate-eval crash` (`cmd/agentgate-eval/crash.go`). The
gateway object is abandoned inside one process; no process is killed.

| file | written by | content | fields used |
|---|---|---|---|
| `crash.json` | `crashResult` | `environment`, `escalation`, `totals`, `schedules[]` | `totals` (`crashTotals`): `operations`, `duplicate_effects_per_operation_id`, `business_duplicates` (same content committed under a fresh ID, by design), `rejected_while_effect_exists`, `committed_without_effect`, `unresolved_after_retry`, `unresolved_after_reconcile`, `evidence_gaps` (provider effect without an EFFECT_EXECUTED or RECONCILED-committed entry), `segments_verified`, `segments_anchored`, `segments_with_missing_items` (**do not cite**: equals the folder count since build 2), `segments_with_missing_items_by_kind` |
| | `crashSchedule` | one schedule | `fault_point`, `retry`, `restart`, `repeat`, `faults_fired`, `provider_commits`, `evidence_segments[]` (verifier outcomes), `operations[]`, `elapsed_ms` (ms, not a performance result) |
| | `crashCell` | one operation of a schedule | `effect` (financial, message), `first_call`, `retry_call` (`callResult`: `status`, `reason`, `dispatched`, `outcome`), `provider_effects_original_id`, `provider_effects_fresh_id`, `duplicate_effect_per_operation_id`, `rejected_while_effect_exists`, `committed_without_effect`, `original_state_after_retry`, `original_state_after_reconcile`, `effect_evidenced_in`, `evidence_gap` |
| `crash.csv`, `crash.md` | the runner | one operation per row (adds `segment1_missing_kinds`, `segment2_missing_kinds`) | |
| `reanalysis.json/.md` | `reanalyze_from_disk.py` | recount from the provider journals and audit logs on disk | |
| `cli_crosscheck.csv/.summary.json` | `cli_crosscheck.py` | the frozen `agentgate-verify` on every folder, with and without pins; Missing compared kind by kind, the nine dimensions compared | `agree_none`, `agree_pinned`, `derived_dimensions` |
| `crash.cells.*`, `crash.folders.csv`, `continuity_probes.csv`, `call_ids.txt`, `recovery_records.txt` | analysis scripts of the same names | | |
| `deny/` | the same in deny mode | | |

### killsuite/ (OS-level kills of real gateway processes)

Written by `agentgate-killsuite run` (`cmd/agentgate-killsuite/results.go`).

| file | written by | content | fields used |
|---|---|---|---|
| `results.json` | the suite | `environment`, `build` (results manifest: SHA-256 and VCS revision of the suite and of the verifier), `reps`, `elapsed_s` (not a performance result), `kill_points`, `totals`, `cells[]` | `totals` (`totals` struct): `cells` (cell runs), `operations`, `operations_with_more_than_one_effect`, `rejected_while_provider_holds_effect`, `provider_not_committed_while_provider_holds_effect`, `committed_without_effect`, `unresolved_after_reconcile_not_deliberate`, `unresolved_after_reconcile_deliberate`, `undecided_after_reconcile`, `unlisted_after_reconcile`, `cells_with_redispatch` (per cell), `rejected_answers_then_effect_after_restart`, `fresh_id_business_duplicates`, `kill_point_not_reached`, `restart_blocked`, `second_approval_required`, `flag_cells_committed`, `flag_preserved`, `flag_lost`, `flag_lost_in_recovery_entries`, `flag_lost_in_replay_entries`, `segment1_alone_verdicts`, `run_walk_verdicts`, `single_segment_verdicts`, `failing_checks`, `warning_checks`, `as_killed_verdicts`, `classification_evidence`, `acceptance_passed` |
| | `cellResult` | one cell run | `label` (group/point/path/retry), `rep`, `kill_reached`, `answers[]` (`segment`, `call`, `operation`, `result`), `provider_effects`, `dispatch_requests`, `status_lookups`, `segments[]` (`segmentOutcome`: `ended`, `kill_point`, `exit_code` (86 = killed by a fault hook), `pinned_head`, `verify`), `duplicate_effect`, `rejected_then_effect`, `undecided_operations`, `flag_expected`, `flag_in_outcome_entries`, `flag_in_recovery_entries`, `flag_in_replay_entries`, `flag_preserved`, `classification_evidence`, `second_approval_required`, `elapsed_ms` |
| `results.csv` | the suite | one cell run per row | |
| `summary.md` | the suite | acceptance measures (required 0), reported measures, verdict tables, per-cell outcome signatures | **source of every kill-suite number** |
| `recount.*`, `reverify.*`, `analysis.*` | `recount_from_disk.py`, `reverify_dimensions.py`, `analyze.py` | recount from disk; re-verification with the build-2 fields (`head_fresh`, `run_complete`, Missing kinds) | |
| `prefix-earlier-build/` | the suite on an earlier build | the pre-fix flag-loss evidence (earlier build and its verifier) | totals not comparable one to one |
| `samples/` | | two cell folders | |

### concurrency/

Written by `agentgate-eval concurrency` (`cmd/agentgate-eval/concurrency.go`,
`concurrencyResult`); seven runs in `n8/`, `n32/`, `gomaxprocs1-*/`,
`race-*/`, `replicate-n8/`; analysis in `analysis/`.

| object | fields used |
|---|---|
| `summary[]` (`concurrencySummaryRow`) | `scenario`, `repetitions`, `invariant_held`, `outcome_patterns`, `max_effects_per_operation_id`, `rejected_while_effect_exists`, `committed_without_effect` |
| `repetitions[].scenarios[]` (`raceScenario`) | `calls`, `status_counts`, `provider_effects`, `max_effects_per_operation_id`, `invariant_holds`; `raceCall`: `result`, `elapsed_ms` (ms) |
| `analysis/` | `analyze.py` outputs (safety, completion, journal transitions, lease slack in ms), `replay_scope.*`, `verifier_fields.*`, unit-test log |

### custody/ (anchors, restart segments, signed witness status, freshness)

Written by `agentgate-eval custody` (`cmd/agentgate-eval/custody.go`,
`custodyResult`) and the scripts in `custody/scripts/`.

| file | content | fields used |
|---|---|---|
| `custody.json/.csv/.md` | one canonical run: self-test checks (`custodyCheck`: `id`, `title`, `passed`), `facts` (`custodyFacts`), `verification_matrix[]` (`custodyCell`: `variant`, `anchors`, `tampered`, `verification` (a verifier outcome), `detected`, `accepted`, `anchored`, `false_alarm`) | |
| `repeats.csv`, `repeats_summary.json` | the 20 runs | `selftest_passed`, `revision_checks_passed` (x/9), witness and provider facts |
| `rollback_by_anchor.csv` | detections per rollback variant and anchor, of 20 | `detected`, `not_detected`, `accepted_clean`, `assurance (count)`, `failing checks (count)` |
| `cli_crosscheck.csv`, `dimensions_by_cell.csv` | the frozen CLI per cell, with `head_fresh` / `run_complete` | |
| `tamper_lab.csv` | 8 tamper-lab attacks x 20 runs | `naive_verdict`, `anchored_verdict`, `detected` |
| `status_probe.csv`, `status_probe_summary.json` | a relay that answers in the witness's place (280 cells) | outcomes, `head_fresh`, `run_complete`, replayed status age (s) |
| `witness_probe.json`, `evidence_facts.*`, `matrix_stability.csv`, `process_observation/` | probes, facts per run, stability, process lists | |

### misuse/ (policy misuse)

Written by `agentgate-eval misuse` (`cmd/agentgate-eval/misuse.go`,
`misuseResult`) and `analyze_misuse.py`.

| file | content | fields used |
|---|---|---|
| `misuse.json` (flag), `deny/misuse.json` | `tallies[]` (`misuseTally`: `category`, `total`, `by_class`, `matches_expectation`, `effects_committed`), `cases[]` with `steps[]` (`misuseStepResult`: `category`, `expected`, `result`, `fired_rules`, `deciding_rules`, `policy_decision`, `effect_committed`, `class` = blocked / flagged / permitted / invalid, `matches_expectation`, `harm`) | |
| `misuse_table.csv` | one request per row, both modes | `category` and `expected` set in `misuse.go` before the run; `observed`, `status`, `dispatched`, `fired_rules`, `blocked_by` |
| `misuse_by_category.csv/.md`, `misuse_category_map.csv` | the regrouping made after the run (labels unchanged) | |
| `misuse_analysis.json` | totals per mode, harm under a grant, blocked by rule family, CLI cross-check, repeat stability | |

### robustness/ (fuzzing, refusal-site mutation, coverage)

| file | written by | fields used |
|---|---|---|
| `fuzz_runs.csv`, `fuzz_summary.json` | `scripts/` around `go test -fuzz` | executions per target and run; crashers; property failures |
| `kill_score_*.json` | `internal/auditverify/tools/refusalmutation` (report format in its `main.go`) | `operator` (fail), `skipped_tests` (the skip pattern), `sites`, `killed`, `survived`, `build_errors`, `timeouts`, `kill_score` = killed / (killed + survived), `by_check`, `survivors[]`, `mutants[]` |
| `kill_attribution_*.json`, `kill_by_check.csv` | scripts | which test killed which site |
| `refusal_conditions.json/.csv` | `scripts/refusal_conditions.py` | `counts` (conditions 313, suite, suite without post-hoc tests, fuzz, neither), `by_kind` (fail, warn, problem), `never_executed[]` |
| `coverage_summary.json`, `coverage_by_file.csv` | `go test -coverprofile` | statements covered of 4,085 |
| `robustness_tests.csv`, `test_counts.json`, `check_counts.json` | scripts | test and check counts (38 check IDs) |

### heldout/ (held-out mutation operators, frozen before the run)

Written by `refusalmutation -operator append|boundary|equality` and
`heldout/scripts/`; definitions frozen in
`docs/paper/data/revision/robustness/HELDOUT_OPERATORS.md`.

| file | fields used |
|---|---|
| `heldout_summary.json/.csv` | per variant/operator (`v1_full`, `v2_without_posthoc4`, `v3_f01d1c9`, `v2b_without_posthoc7`): `sites`, `killed`, `survived`, `build_errors`, `timeouts`, `kill_score`, `survivors_by_group` (not executed, evaluation not shown, equivalent, executed but undetected), `splits`, `ceiling`, `by_file`, `by_func`, `by_class` |
| `heldout_mutants.csv` | one mutant per row (1,410 rows): `variant`, `operator`, `id` (file:line:column), `zero_operand`, `eval_not_shown`, `verifier_only`, `coverage`, `result`, `seconds`, `first_failure`, `survivor_group` |
| `heldout_survivors.csv`, `equivalence.csv` | survivors; the hand judgement of each equivalent mutant (one-line argument) |
| `ceilings.json`, `site_diff_f01d1c9_to_build2.json`, `build1_vs_build2.json`, `memory_incident.json`, `raw/` | |

### baseline/ (cost, load, per-stage cost, witness push)

| file | written by | fields used (units) |
|---|---|---|
| `baseline.json` (R2), `repeats/R*/`, `message/` | `agentgate-eval baseline` (`baselineResult`) | `sequential` (`trials`, `blocks`, `configs[]` with `latency` (`latencyStats`: `n`, `min_us`, `p50_us`, `p95_us`, `p99_us`, `max_us`, `mean_us`, microseconds), `paired_differences[]` (`compare`, `median_us`, CI bounds)), `concurrent[]` (`concurrentCell`: `clients`, `config`, `calls`, `throughput_calls_per_s`, `latency`, `cpu_ms_per_call`, `alloc_kib_per_call` (KiB of allocation volume, not resident memory)) |
| `analysis.json` | `analyze_baseline.py` (seed 20261007, 10,000 resamples) | `runs.<run>.paired_differences[]` (`median_us`, `median_ci95_blocks` (block bootstrap; the paper's interval), `median_ci95_trials`, `mean_us`), `runs.<run>.concurrent[]` (`p50_us`, `p99_us`, `throughput_calls_per_s`, `peak_working_set_mib`), `between_runs` |
| `cost/cost.json` | `agentgate-eval cost` (`costResult`) | per-entry append costs (us), `estimated_append_ms` |
| `stagecost/run*/stagecost.json` | `TestStageCost` (`internal/audit/stage_bench_test.go`) | `stages`, `groups` (median, p99, mean in us per stage group), `staged_total`, `append_uninstrumented`, `per_call`, `directory_fsync` |
| `stagecost/run*/witnesspush.json` | `TestWitnessPushCost` (`internal/headwitness/push_bench_test.go`) | `rows` (push per call, save per call, push per entry, save per entry: median, mean, p99 in ms) |
| `stagecost/summary.csv` | `stage_summary.py` | one row per run, kind and stage row |
| `load/`, `session-logs/`, `slow-calls.json` | load sampler, session logs, `slow_calls.py` | system load (cores), disk slowdowns located in time |

## 4. Where the paper's numbers are

`docs/paper/artifact/EXPECTED_TABLES.md` maps every table cell and in-text
number to a file and field of this list.
