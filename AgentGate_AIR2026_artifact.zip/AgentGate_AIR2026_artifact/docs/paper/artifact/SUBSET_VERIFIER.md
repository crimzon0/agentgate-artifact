# Subset verifier and adversarial corpus

`subset_verifier.py` is a second implementation of a **minimal protocol
subset** of the AgentGate verifier, in Python with the standard library
only. It was written by the same authors, ported from the specification and
the Go sources, and shares no code with them. `corpusgen/` writes a small
adversarial corpus of run folders and freezes the Go verifier's expected
outcome for each before the Python verifier ever sees it.

Together they are this revision's response to the request for an
independent end-to-end verifier on a selected adversarial corpus. They are
not independent in the sense of an outside team (see "What kind of second
implementation this is"). Where the paper mentions this verifier, it uses
the qualified description above, never "independent verifier" alone.

**It is not an implementation of the 38 checks** of
`docs/demo/VERIFIER_CHECKS.md`. It checks 15 of them, each only in part
(below). It never replays the policy, and it does not check `keys.valid`. A
PASSED from it is not a verdict of the full verifier.

## What the subset checks

Every check is named after the Go check it is a part of.

| check | what the subset verifies |
|---|---|
| `files.present` | audit.jsonl, head.json, keys.json and run.json exist and are unambiguous JSON (no duplicate member names); no size limits, no case-folding rule |
| `keys.hash` | SHA-256 of keys.json = run.json `keys_sha256` = RUN_STARTED `keys_sha256` |
| `files.run_record` | SHA-256 of run.json = RUN_STARTED `run_sha256`; every POLICY_DECISION names run.json's policy hash |
| `chain.entry_hash` | each line is exactly `{"entry_hash":…,"signature":…,"entry":…}` and `entry_hash = H("AgentGate/AuditEntry/v1", ENTRY_JSON)` over the stored bytes |
| `chain.signature` | Ed25519 audit-key signature over `"AgentGate/AuditEntrySig/v1" 0x00 raw32(entry_hash)` |
| `chain.links` | `seq` 1, 2, …; `prev_hash` zeros, then the previous entry hash |
| `head.signature` | head.json names the audit kid; signature over `"AgentGate/AuditHead/v1" 0x00 run_id 0x00 seq 0x00 entry_hash` |
| `head.matches` | head.json's seq and entry hash are the last entry's |
| `keys.anchor` | `--expect-keys` = SHA-256 of keys.json (warning without a pin) |
| `head.anchor` | `--expect-head` = the last entry hash (warning without a pin) |
| `artifact.signature` | **capability tokens and adapter effect receipts only**: COSE_Sign1 structure, protected header labels, content type, kid listed in keys.json with the role (CAPABILITY_ISSUER; the ADAPTER_* key of the effect type), Ed25519 over `["Signature1", protected, h'', payload]`; a bad artifact on a refusal stage is a warning |
| `op.requires_policy` | the classification binding: the FINAL decision value is opened (h_FIN recomputed under `AgentGate/DEVFinalDecision/v1` and equal to `decision_hash`), FINAL field 3 names a logged PRE of the operation whose value hashes correctly; operation, effect type, effect digest and policy hash agree; the FINAL shape fits the PRE outcome; outcome, decision, flag, escalation mode, fired rule IDs (and FLAG reasons) stated by the PRE and FINAL entries equal what the values commit to, as does the executing CALL_RESULT's `flagged`; the mode agrees with run.json and a flagged action needs mode flag. With `--unbound-flags` only operation, effect, policy and outcome are compared and the mode is read from the details, as in the Go ablation |
| `op.capability_bound` | the capability (which must verify) names this operation, effect type, adapter audience and validated effect digest; its `policy_decision_hash` (-70007) is the FINAL's `decision_hash` and the hash of the logged FINAL value; its policy hash (-70009) is the PRE's; cti; a window of at most 60 s |
| `op.receipts_bound` | the adapter receipt (which must verify) names this operation, effect digest and type; its `cti`, `capability_hash` (`H("AgentGate/Capability/v1/cose", token)`) and `policy_decision_hash` are the capability's; its `provider_receipt_hash` is the hash of the recorded provider receipt (the provider receipt's own signature and fields are not checked) |
| `policy.snapshot_bound` | the content policy hash recomputed from run.json's `policy_snapshot` (recipe in `VERIFIER_CHECKS.md` §3) equals the snapshot's `policy_hash`, run.json `policy.hash`, every verified capability's -70009 claim and every opened decision value's policy hash; the catalog commitment is not checked |

`verifier.error` reports any crash of the subset verifier as a failure.

**Not in the subset**: the policy replay (`policy.replay`), all six
`delegation.*` checks, `provider.*` and `op.outcome_resolved` (the provider
journal, provider receipts and status signatures, reconciliation),
`op.approval_bound` and the approval artifacts, `op.requires_validation`,
`op.single_use`, `op.no_effect_when_refused`, `artifact.effect_digest`,
`artifact.effect_readable`, `keys.valid` (key-ID derivations, roles),
`files.run_id`, `chain.time`, the catalog commitment, restart segments
(`files.continuity`) and the witness (`head.witness`); no assurance levels or
dimensions. The delegation grant, the provider receipt and the approval
signatures are never verified. Nor does it port anything build 2 added to
the Go verifier (2026-10-10): the recovery-record and replayed-answer flag
rules of `op.requires_policy` (a RECONCILED commit, its call's CALL_RESULT
and a replayed COMMITTED answer must state the bound flag), the adapter
receipt on a RECONCILED entry (`op.receipts_bound`), the derived dimensions
`head_fresh` and `run_complete`, per-operation classification evidence and
the Missing kinds. No corpus folder has a recovery or replay record of a
mutated operation, so the agreement says nothing about these Go rules.

**What kind of second implementation this is.**

- **No shared code.** The script imports no AgentGate code and does not call
  the Go verifier. It decodes CBOR, COSE and the decision values itself. It
  reuses only three pieces of `check_vectors.py`: domain-separated SHA-256,
  the CBOR length heads and the RFC 8032 Ed25519 verifier. `--self-test`
  checks them against RFC 8032 TEST 1 and the test vectors.
- **Ported logic.** It was written from `VERIFIER_CHECKS.md` and
  `CONTRACTS.md` by the same authors, with the Go sources open. The logic is
  ported from Go, not only the field numbers and shapes:
  - `snapshot_policy_hash` follows `auditverify/binding.go` and the snapshot
    readers of `snapshot.go`, alias lists included;
  - `_decision_binding` follows `preValueProblems` in `decisions.go` line by
    line.
- **What agreement means.** On the smoke corpus (Status), the subset's
  failing checks equal Go's failing checks, restricted to the subset's IDs,
  in 244 of the 252 verifications Go fails. Agreement therefore shows that
  the port is faithful. It is not independent confirmation of the Go logic:
  a mistake in the specification or in the Go design that the port copied
  would not show.
- **Same origin as Go.** The corpus mutants come from the Go mutation engine
  (`internal/evalattack`), and the expected outcomes are the Go verifier's,
  not the oracle's.

## The key-compromise simulation

`--assume-compromised ROLE[,ROLE...]` mirrors
`auditverify.Options.AssumeCompromised`: a signature attributed to one of
those roles is accepted without being verified (structure, content type,
kid and role are still checked), and the report carries a `simulation`
member. The role names are the Go ones (case-insensitive): `AUDIT_LOG`
(entry and head signatures), `CAPABILITY_ISSUER` (capability tokens),
`ADAPTER` (every ADAPTER_* key), and `SIMULATOR_PROVIDER`,
`DELEGATION_AUTHORITY`, `APPROVAL_AUTHORITY`, `WITNESS`, which the subset
accepts but never needs, since it verifies none of their signatures. An
unknown name is a usage error (exit 2). Nothing is signed anywhere.

## The corpus

`corpusgen` takes a fresh pair of flag-mode base runs, one per design (bound
and unbound):

- `-make-base` makes them exactly as `agentgate-eval compromise` does
  (`demo.HeadlessRun`, flag mode, `UnboundFlags` for the unbound design) and
  keeps the pins the demo held in memory. The runs are made in a temporary
  folder outside `-out`, which is removed at the end. Only their evidence
  files and their tamper-lab copies are copied into the corpus. The demo's
  self-test report and restart segments name local paths, so they are never
  copied, and a corpus can be shared with a double-blind venue;
- `-bound DIR -unbound DIR` takes existing run folders, for example the
  `flag-bound/<run>` and `flag-unbound/<run>` folders an `agentgate-eval
  compromise` work folder keeps. Their pins are read from the folders,
  which is equivalent only for untouched folders, so each base run must
  verify for real, with those pins, under the full Go verifier.

It writes:

| folder | content |
|---|---|
| `clean/bound`, `clean/unbound` | the base runs (evidence files only) |
| `tamper-lab/<design>/<attack>` | the base runs' eight tamper-lab copies, when the base run folder has its `tamper-lab/` sibling (always with `-make-base`) |
| `mutants/<design>-<operator>-<keyset>-<variant>` | `evalattack.MutateVariant` for strip-flag, invent-flag, change-rules x none, audit, audit+issuer, audit+issuer+adapter (the paper's {none, A, A+I, A+I+X}) x plain, forge-snapshot, forge-restate x bound, unbound: 72 rows; on gateway base runs change-rules has no snapshot lever (one recipient), so 16 rows are not applicable and 56 folders are written |
| `manifest.json` | every entry: folder, design, operator, key set, variant, the key set's `assume_compromised` roles, the engine's `unrepaired` notes, the genuine pins, `files_sha256` (the SHA-256 of every file of the folder, taken before the Go verifier read them), and the **expected** Go outcome (verdict, assurance, failing checks) per anchor condition none/keys/head/both |
| `manifest.sha256` | the SHA-256 of manifest.json (`<hex>  manifest.json`): the freeze |

The expected outcome is `auditverify.VerifyRun` with `DisableChecks
[policy.replay]` (the **no-replay** setting of `agentgate-eval compromise`: a
classification that cannot be replayed), `AssumeCompromised` set to the key
set's roles, `UnboundFlags` for the unbound design, and the anchor
condition's pins. `go_full`, the Go verdict with the replay on, is recorded
for information only; the subset never replays, so it is not compared.

## The freezing rule

The expected outcomes are computed and frozen before the Python verifier is
run on the corpus:

1. Run `corpusgen`. It writes `manifest.json` and `manifest.sha256` and
   prints the hash. Record that hash outside the corpus (in the results
   file, a commit or the run log) before running anything else on the
   corpus.
2. Run `subset_verifier.py --corpus` with `--expect-manifest-sha256` and the
   recorded hash. Before it verifies anything, it refuses with exit status 2
   when:
   - `manifest.sha256` is missing, or does not match the manifest;
   - the manifest does not match the recorded hash;
   - a folder does not hold exactly the files in its entry's
     `files_sha256`, with those hashes.

   The result's `freeze_checked` says what was checked. `manifest.sha256`
   alone shows only that the manifest and its hash file belong together;
   both could have been regenerated. Only the hash recorded beforehand
   shows that the outcomes were frozen first.
3. Report every disagreement as it is, with its explanation (the subset
   boundary, or a bug on one side). Do not regenerate the corpus, edit the
   manifest or change either verifier after seeing the results without
   reporting the earlier run and labelling the new one as a separate,
   post-hoc run. A Go-side bug means a fix, a new build and a rerun of the
   affected experiments.

## How to run

From the repository root (or the review archive's root), with the offline
Go toolchain. The review archive contains `subset_verifier.py`, this file
and `corpusgen/` (added to `build_artifact.py` on 2026-10-10).

```
go run ./docs/paper/artifact/corpusgen -out CORPUS -make-base
python docs/paper/artifact/subset_verifier.py --corpus CORPUS/manifest.json --expect-manifest-sha256 HEX --out CORPUS/subset-result.json
```

or, from the base runs of an `agentgate-eval compromise` work folder `W`:

```
go run ./docs/paper/artifact/corpusgen -out CORPUS -bound W/run-01/flag-bound/<run> -unbound W/run-01/flag-unbound/<run>
```

One folder:

```
python docs/paper/artifact/subset_verifier.py RUN_DIR --expect-keys HEX --expect-head HEX
python docs/paper/artifact/subset_verifier.py MUTANT_DIR --assume-compromised AUDIT_LOG,CAPABILITY_ISSUER
python docs/paper/artifact/subset_verifier.py UNBOUND_RUN_DIR --unbound-flags
python docs/paper/artifact/subset_verifier.py --self-test
```

A single verification prints a JSON report: `verdict` (PASSED or FAILED),
`failing_checks`, `warnings`, per check the passed, failed, warned and
simulated item counts with up to five messages, and `simulation` when roles
were assumed compromised. Exit status 0 passed, 1 failed, 2 usage or I/O
error.

`--corpus` prints, and with `--out` writes:

- the agreement per verification (Go FAILED versus subset FAILED);
- the agreement on the **binding-relevant** folders, each counted once,
  with a breakdown per key set; the keys-pinned repeats of those folders;
  and the other rows, separately (below);
- the agreement per group (clean, tamper-lab, mutant);
- the agreement per strongest-attacker cell (design, operator, key set,
  anchor condition, over all four anchor conditions). A cell counts as
  detected only when every applied snapshot variant is detected, as in
  `agentgate-eval compromise`;
- the distinct binding flips (operator and key set detected in the bound
  design, accepted in the unbound one, without anchors) found by each
  implementation, and whether the keys pin gives the same flips.

The exit status is 0 when every verdict agrees, 1 otherwise, and 2 when the
freeze does not hold. The rows also list, for diagnosis, the Go failing
checks that belong to the subset next to the subset's own. The failing-check
sets are not expected to match, since each subset check is narrower. The
result names the manifest by file name only, so it can be kept inside the
corpus without naming local paths.

**Binding-relevant rows.** These are the mutant folders with an attacker key
set (audit, audit+issuer, audit+issuer+adapter), each counted once, at the
anchor condition none. They are the rows where the classification binding
can decide the verdict. It decides it only where a binding flip appears:

- **The keys pin is not a separate condition here.** The mutants never edit
  keys.json, so pinning its hash cannot change a verdict. The keys-pinned
  verifications of these folders are reported as repeats, together with the
  number of folders whose verdict the pin changes (0 on the corpora under
  Status). Counting them as well would count each folder twice.
- **The audit+issuer+adapter rows do not depend on the binding.** For this
  key set the simulation skips the issuer and adapter signature checks too
  (nothing is re-signed; corrected wording 2026-10-10), so whatever the
  binding checks counts as validly signed, and in each of their
  operator/variant pairs the Go verdict is the same in both designs (`binding_by_keyset` gives the count of pairs that
  differ, 0 for this key set). Every flip is an audit or audit+issuer
  row.

All the other rows are easy to get right:

- clean runs;
- the fixed tamper-lab attacks;
- mutants with no key, which any signature check catches;
- head-anchored mutants: every edit changes the log, so the head pin
  catches it.

The paper reports the binding-relevant folders and the distinct flips apart
from the headline count.

Tests: `go test ./docs/paper/artifact/corpusgen/` runs the following.

- **Fixture corpus.** It builds a corpus from the fixture's bound and
  unbound revision runs and checks its shape, the freeze and every entry's
  `files_sha256`. Then it runs `subset_verifier.py` on the corpus (skipped
  without Python 3, or with `-short`). Every verdict must agree, the binding
  flips must be the same, and the binding-relevant folders must be reported
  once each, with their keys-pinned repeats changing no verdict.
  Exit status 2 is required for each of: a wrong recorded hash, a changed
  corpus file, a missing `manifest.sha256` and an edited manifest.
- **Tamper lab.** It builds a corpus whose base runs have a tamper-lab
  sibling folder, and requires the attack copies to be in it.
- **`-make-base`** (skipped with `-short`). It makes the two demo runs
  inside the test and checks that the temporary folder is removed. It also
  checks that only evidence files are copied and that no file in the corpus
  names the temporary folder, the home folder, the working directory, the
  module root or the host name (case-insensitive; names shorter than six
  characters are not searched). Then it runs `subset_verifier.py` on that
  corpus of demo runs (when Python 3 is there), and every verdict must
  agree.
- **Single folder.** It exercises the single-folder mode: anchors,
  `--unbound-flags`, the simulation label, an edited entry, a rewritten
  policy snapshot, and the pre-revision fixture runs in both modes.
- **Detail edit.** Under a simulated audit key, it removes the flag from the
  log details only and leaves the decision values alone. In the bound
  design both verifiers must fail it, Go included, on `op.requires_policy`.
  In the unbound design Go must say VERIFIED and the subset PASSED.

## What an agreement shows, and what it does not

Agreement means this: on this corpus and under the no-replay setting, a
port of the log chain, the head, the anchors, the issuer and adapter
signatures and the classification binding reaches the same verdict as the
Go verifier. That includes which classification edits are accepted only
when the issuer and adapter signatures are also assumed compromised in the
bound design, and with the audit key alone in the unbound one (the binding
flips; wording corrected 2026-10-10: "smallest tested key set", not a
proof that fewer keys cannot succeed).

It does not show:

- that the Go verifier is correct in general (the port follows the Go
  logic);
- anything about the policy replay or the delegation, provider and approval
  checks, which the subset leaves out;
- anything beyond the Go engine's mutants, since all the mutants come from
  it.

The key-compromise model is the same signature-abstracted simulation as in
the Go runner: held keys are modelled by skipping their signatures.

**`keys.valid` is not covered.** The subset only requires exactly one usable
`AUDIT_LOG` key in keys.json, and when a kid is listed twice it uses the last
entry. It does not check what Go's `keys.valid` checks: a kid listed twice,
an unknown role, an audit kid that is not the SHA-256 of its key. The corpus
never edits keys.json, so this gap cannot show in the agreement. Outside this
corpus, a keys.json with confused roles can pass the subset where Go fails it.

What the corpus exercises: on the smoke-test corpus (Status), a throwaway
copy of the subset verifier with signature verification switched off
disagreed with Go in
56 of 296 verifications and found none of the 6 distinct binding flips
(reported then as 12, each counted once without and once with the keys
pin), and one that
trusted the snapshot's stated policy hash instead of recomputing it
disagreed in 16. One without the comparison of log details with decision
values still agreed everywhere: the engine keeps details and values
consistent, so its mutants are caught by the signatures over the
propagated hashes. That comparison is covered by the detail-edit test
above, not by the corpus. With the replay on, the Go verdict differs from
the no-replay one in 24 of the 296 verifications; those are outside what the
subset can reproduce.

## Status

**Final run on frozen build 2** (2026-10-10; full record:
`docs/paper/data/build2/subset-corpus/RESULTS.md`). `corpusgen -make-base
-host-label review-host` wrote the corpus at 02:28:32-02:28:45 UTC; the
manifest SHA-256
`a9f9d178fb03a36e2b948e22f4f07b138d8f61c85d08fceba840453fb217765d` was
recorded outside the corpus at 02:28:57 UTC, before any Python run; the
comparison (02:29:15-02:29:44 UTC) checked it and all 372 corpus files.
Results: 296 of 296 verifications agree (clean 8/8, tamper-lab 64/64,
mutants 224/224); 42 of 42 binding-relevant folders agree (Go FAILED 26,
accepted 16); 212 of 212 other rows; 96 of 96 strongest-attacker cells; the
same 6 distinct binding flips in both implementations, no reverse flip; the
frozen `agentgate-verify` reproduces Go's full-verifier verdict in 148 of 148
bound-design verifications. Failing-check sets are equal on 244 of the 252
Go-FAILED verifications (the other 8 are `forge-approval-7`, where Go also
fails the approval artifact's signature, which the subset never verifies).

The text below describes the earlier smoke test and is kept as history.

Smoke test only, on a development build: the sources of commit `f01d1c9`
plus the files of commit `92fc597`, built with the offline Go 1.26.6 toolchain on
2026-10-10, not the frozen build. `corpusgen -make-base` made a fresh
bound/unbound base pair; manifest SHA-256
`4644d3268529084d30c2699f9c2b93a26cea99476670a897065d5bf2af04c25c` was
recorded before the Python run. Results:

- **All rows.** 296 of 296 verdicts agree.
- **Binding-relevant folders.** 42 of 42 agree; Go failed 26 of them and
  accepted 16. (The smoke run's summary counted each of these folders twice,
  without and with the keys pin, as 84 rows with 52 failed and 32 accepted.
  The mutants never edit keys.json, so the pin cannot change their
  verdicts; a fresh corpus checked in review gave the same verdict for all
  42 folders under both.)
- **Keys-pinned repeats.** The other 42 of those 84 rows; they repeat the
  folders above.
- **Other rows.** 212 of 212 agree: clean 8, tamper-lab 64, key-set-none
  mutants 56, head- or both-anchored mutants 84.
- **By group.** Clean 8/8, tamper-lab 64/64, mutants 224/224.
- **Cells and flips.** 96 of 96 strongest-attacker cells agree (over all
  four anchor conditions, so the keys-pinned cells repeat the unpinned ones
  here too). Both implementations find the same 6 distinct binding flips
  ({strip-flag, invent-flag, change-rules} x {audit, audit+issuer}, without
  anchors; reported then as 12, once more with the keys pin) and no reverse
  flip. The audit+issuer+adapter folders carry no flip: their Go verdict is
  the same in both designs.

That smoke corpus was made by the earlier corpusgen. Its hash file was named
`manifest.json.sha256`, its entries had no `files_sha256`, and its
`base-runs/` folder, inside the corpus, held self-test reports naming local
paths. The freeze checks of this version therefore refuse it as it is. The
final run on the final build uses this version, records the manifest hash
outside the corpus, and replaces these numbers (done: the final run above).

The `-make-base` test now repeats this on a fresh corpus of demo runs every
time it runs (a development check on whatever build is tested, not a
result). On 2026-10-10, on the revision branch, it gave the same counts: 296
of 296 agree; 42 binding-relevant folders (Go failed 26, accepted 16), whose
keys-pinned repeats change no verdict; per key set, the Go verdict differs
between the designs in 3 of 7 operator/variant pairs for audit, 3 of 7 for
audit+issuer and 0 of 7 for audit+issuer+adapter (4 of those 14 folders
detected in both designs, 10 accepted in both); 6 distinct flips on both
sides.
