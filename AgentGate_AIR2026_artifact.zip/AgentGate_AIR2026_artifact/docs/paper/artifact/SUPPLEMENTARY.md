# Supplementary material (S1-S17)

Material the paper refers to but does not print, for space. The paper cites
these sections as "archive S1" to "archive S17". Each item names its source.
Paths are relative to `docs/paper/data/build3/` unless they start with
`docs/`, `cmd/` or `internal/`. Every number comes from **build 3** (six
binaries built reproducibly on 2026-10-20 from commit `8a30fd4`; manifest
SHA-256 `0c436fc9...6968eb`) unless it is labelled with another build.

Abbreviations: A audit, I issuer, X adapter (the three adapter keys
together), X_op the adapter key that signed the edited operation's receipt
(Xf financial, Xm message), X_all every adapter key whose receipt stays in
the log, P provider, s a signed status reply (the provider's signed answer
to a status lookup; any local process can obtain one in the prototype). Key
sets are the smallest tested sets that passed, not proofs that fewer keys
cannot succeed. Evidence basis: F real-key tests on fixtures, S key-theft
simulation, A argued from the verifier code. Units (attack, result, fixture
case, fixture result, verification, fault run, test run, multi-process run):
S10 and `EXPECTED_TABLES.md`, "Units".

Contents: S1 implementation · S2 experiments · S3 worked forgery · S4
oracle mismatches · S5 request path, retries, journal failure, durability ·
S6 cost · S7 lifecycle and evidence basis · S8 misuse · S9 related work ·
S10 glossary · S11 unchecked fields · S12 process-kill tests · S13 clocks
and registration · S14 testing the verifier and the coverage map · S15
separate key holders · S16 real-key tests · S17 versions and counting.

## S1. Implementation inventory and size

Six programs implement AgentGate, all in Go 1.26 with the official MCP Go
SDK 1.7.0, COSE_Sign1 and CBOR Web Tokens:

| program | what it does |
|---|---|
| `agentgate-demo` | the gateway with the scripted agent, the dashboard, the self-test and the tamper lab |
| `agentgate-verify` | the offline verifier (imports no gateway package) |
| `agentgate-provider` | the simulated provider as a separate process |
| `agentgate-witness` | the head witness as a separate process |
| `agentgate-eval` | the evaluation harness (key-theft simulation, in-process faults, concurrency, misuse, multi-process runs, cost) |
| `agentgate-killsuite` | the process-kill tests: kills and restarts real gateway processes |

Code size. Source: `docs/paper/artifact/loc_build3.csv`, counted on
2026-10-21 on the build-3 tree with `docs/paper/response/tcb/tcb_loc.py`
(non-test Go files the toolchain compiles for windows/amd64; a code line has
a non-comment, non-blank character).

| part | packages | code lines |
|---|---|---|
| enforcement path (the executed gateway: `internal/devcomposition`, `canon`, `effects`, `signed`, `capability`, `controlpoint`, `adapters`, `simulator`, `mcp`, `audit`, `opjournal`, `devapproval`) | 12 | 22,517 |
| provider and witness processes (`cmd/agentgate-provider`, `cmd/agentgate-witness`, `internal/headwitness`) | 3 | 2,634 |
| verifier (`internal/auditverify`, `cmd/agentgate-verify`) | 2 | 8,965 |
| demo, UI and evaluation harness (`internal/demo`, `cmd/agentgate-demo`, `cmd/agentgate-eval`, `internal/evalattack`) | 4 | 17,212 |
| linked database code, never executed by the in-memory gateway (files importing a database driver) | | 25,521 |
| other linked support code of the earlier prototype | | 10,325 |
| **five programs** (demo, verifier, harness, provider, witness) | | **87,174** in 217 files |
| process-kill test program (`cmd/agentgate-killsuite`) | 1 | 3,797 in 11 files |
| **six programs** | | **90,971** in 228 files |

Build 2 (2026-10-10): 86,138 lines in 215 files for five programs, 89,935
in 226 for six. The two new files of build 3 are
`internal/headwitness/enrollment.go` and `pin.go`. Which code predates the
project's 2026-10-01 handover: `PROVENANCE.md`.

## S2. Experiments

All rows ran on build 3. "Process model" says what ran where; repetitions
show stability, not independent samples.

| experiment (paper) | scale and unit | process model | headline | data |
|---|---|---|---|---|
| key-theft simulation and binding comparison (V-A) | 336 attacks x 2 designs x 4 verifier settings = 2,688 results per repetition; 10 repetitions; 49,920 mutant verifications; 1,280 unedited controls | evaluation harness; base runs by the real gateway in process; verification in process (simulation: signature checks of the attacker's roles skipped) plus the frozen command-line verifier on the base runs | binding changed 0, 8 and 12 of 336 outcomes (full, no snapshot check, no replay), all among the 168 attacks without a head anchor (6 pairs without replay); detected bound / unbound of 336: 313 / 313, 313 / 305, 295 / 283; of the 168 without a head anchor: 145 / 145, 145 / 137, 127 / 115; 0 of 2,688 results unstable; 0 of 1,280 false alarms; all 51,840 result rows identical to builds 1 and 2 | `compromise/` |
| real-key tests (V-A, Tables I-III, VII) | 10 top-level tests, 77 subtests; 1,196 results compared with the simulation; 62 field edits; 15 histories | `go test` on fixtures re-signed by `fixture.ResignHeld` with in-memory audit, issuer, financial and message adapter and provider keys | real keys and the simulation agree in 1,196 of 1,196 comparable results; the simulation overstates a one-adapter-key attacker (40 of 72); field edits 45 detected, 17 accepted; histories 12 of 15 detected (S16) | `fixture-studies/` (study s7) |
| all fixture tests, the real-key tests included (V-A, V-B, VII) | 12 studies, 79 top-level tests, 243 subtests | `go test` on fixtures with real keys created in memory, the real gateway in process, or the verifier-side simulation | reconciliation path: A+I with a signed status reply accepted 6/6 fixture results (no replay) and 8/8 (full verifier, every execution converted); the build-3 date and order rules: 91 cases (50 refused, 23 accepted, 8 reported incomplete, 10 controls); registration without the enrollment key refused 19/19 | `fixture-studies/` |
| multi-process runs, freshness, run completeness (V-B) | 20 runs (15 flag, 5 deny) | demo self-test with the provider and the witness as separate processes on one machine and one user account | a later head detected every tested rollback; an out-of-date saved head was accepted as ANCHORED; `head_fresh` pass 180/180 only with the live witness; 200/200 registrations without the enrollment key refused | `custody/` |
| in-process faults (V-C) | flag-mode run: 560 fault runs, 1,120 operations (none flagged), 2,240 answers, 840 folders; a deny-mode run: 280 fault runs, 560 operations, 10 repetitions (archive only) | the gateway instance is dropped in memory without shutdown inside one process; no process is killed; the provider never restarts | 0 of 1,120 operations with two effects; 0 of 480 REJECTED answers with an effect; identical per fault run to build 2 | `crash/` |
| process-kill tests (V-C) | 39 test cases x 5 repetitions = 195 test runs (145 with a kill); 235 operations; 365 verifications | a parent process hosts the provider and kills and restarts real gateway child processes; every folder checked by the frozen verifier | every acceptance measure 0; flag kept 45/45; 5 false alarms on an untouched reverted-head state; operations with a capability and no outcome now reported unresolved | `killsuite/` |
| concurrency (V-C) | 7 runs, 260 repetitions x 7 scenarios = 1,820 scenario repetitions, 33,040 calls | evaluation harness, gateway in process, simultaneous MCP calls; two runs under Go's race detector | every guarantee 1,820/1,820; 0 race reports | `concurrency/` |
| policy misuse (V-D) | 59 hand-written cases, 95 requests, flag and deny mode, 3 repetitions | evaluation harness, gateway in process | harmful (44, hand-written), blocked / allowed with a flag / allowed without one: under a grant (40) 24 / 3 / 13; reruns without a grant (4) 0 / 0 / 4; all 24 / 3 / 17 | `misuse/` |
| testing the verifier (V-E) | 33,639,381 fuzz inputs; 150 lines that make a check fail | `go test` (fuzzing, coverage, the deletion tool) on a source copy of `8a30fd4` | 0 crashes; 150/150 with the full suite, 63/150 without the 16 tests added late | `robustness/` |
| mutants of three other kinds (V-E) | 385 mutants | the deletion tool with `go test -overlay` | full suite 212/385; without the 24 tests written after lists of undetected mutants existed 130/385 | `heldout/` |
| partial Python verifier (V-E) | 296 verifications on a fixed set of 74 folders | Python, standard library; set written by `corpusgen` | 296/296 agree; the same 6 pairs changed by binding | `subset-corpus/` |
| cost (V-F) | 6 runs; 500 paired trials in 10 blocks; 62,500 measured calls; closed loop 1-16 clients | evaluation harness, loopback provider in the same process, no witness, alone on the machine | signing and flushing the audit log 11.77 ms [11.53, 11.95] per call (paired median, block 95 % CI) | `baseline/` |
| stage cost and witness update (V-F) | 10,000 timed appends x 3 runs; 2,000 updates x 3 runs | `go test` benchmarks on the same disk | one audit append 1.75 ms, 70 % of it the head replacement; a witness update would add about 2.2 ms per call | `baseline/stagecost/` |
| flag loss before the fix (V-C) | 190 test runs | the process-kill tests on **an earlier build** (build-1 gateway and verifier) | 20 of 40 flagged commits lost the flag in recovery records; that verifier accepted them | `../build2/killsuite/prefix-earlier-build/` |

**Rows moved out of the paper's Table III.** Smallest accepted key set per
edit type, bound / unbound (anchors none or keys, genuine keys; F: also
passed in real-key tests):

| edit type | full | no snapshot check | no replay |
|---|---|---|---|
| strip-flag, invent-flag | A+I+X F | A+I+X F / A | A+I+X F / A F |
| change-rules | never accepted (C1, S4) | never accepted | A+I+X F / A |
| change-escalation | never accepted | never accepted | never accepted |
| swap-decisions | never accepted | never accepted | never accepted |
| change-amount | A+I+X+P | A+I+X+P | A+I+X+P F |
| relabel-approved | never accepted (C2, S4) | never accepted | A+I+X |

Detections of all 336 attacks, bound / unbound: full 313 / 313, no snapshot
check 313 / 305, no replay 295 / 283 (both off as no replay). The single
accounting of these counts: `EXPECTED_TABLES.md`.

## S3. Worked forgery: what stripping the flag must change, by design and key set

The example target is the flagged AED 12,400 payment request; strip-flag
rewrites it as a routine ALLOW under FIN-AUTO. Source: `compromise/cells.csv`
(key-theft simulation, anchors none, 10 repetitions, the same outcome in
all), with the real-key results named in the last column.

What the edit changes (Fig. 2 marks): the flag, mode and rules in the PRE
value (so h_PRE), and the flag in the FINAL value (so h_FIN). In the bound
design the capability κ (issuer key) and the effect receipt ρ_E (adapter
key) carry h_FIN, so the edit must re-sign them; in the unbound design only
audit-signed entries change. With replay, the plain edit fails replay; a
forged snapshot that makes the edit replay rewrites h_P everywhere
(forge-restate), which changes every capability and receipt.

The simulation's mutant leaves every edited record of a role the attacker
does not hold with its old (now invalid) signature, so its A and A+I results
in the bound design also fail `artifact.signature`; such a result shows only
that the key set is not enough. The last column gives the real-key results,
including the attacker who leaves the records of roles it does not hold
exactly as genuinely signed (RB; no signature check fails there, so the
failing checks are the binding evidence).

| verifier setting | design | A | A+I | A+I+X | real-key tests (fixtures) |
|---|---|---|---|---|---|
| full | bound | detected: plain fails `artifact.signature`, `op.capability_bound`, `op.receipts_bound`, `policy.replay`; forge-restate fails `artifact.signature`, `op.capability_bound`, `op.receipts_bound`, `op.outcome_resolved` | detected: forge-restate fails `artifact.signature`, `op.receipts_bound` | **accepted** (forge-restate) | A+I+X forge-restate passes in all 4 settings (RS M2); with A+I+Xf alone the genuine message receipts fail `op.receipts_bound` x2 (RB M2): the attacker needs X_all |
| full | unbound | detected: plain fails `policy.replay`, forge-snapshot `policy.snapshot_bound`, forge-restate the capability and receipt checks | detected | **accepted** (forge-restate) | as bound (RS M2, RB M2 unbound); the plain edit with real audit-key re-signing fails `policy.replay`, not `op.requires_policy` (`TestUnboundFlagsAblation`) |
| no replay | bound | detected: plain fails `artifact.signature`, `op.capability_bound`, `op.receipts_bound` | detected: plain fails `artifact.signature`, `op.receipts_bound` | **accepted** (plain, forge-restate) | RB M1: A fails `op.capability_bound` + `op.requires_policy`; A+I fails `op.receipts_bound`; A+Xf fails all three; each VERIFIED once those checks are off; A+I+Xf passes for the payment (RS M1). On the reconciliation path A+I+s passes (L3, L4, LR) |
| no replay | unbound | **accepted** (plain) | **accepted** (plain) | **accepted** | A, A+I and A+Xf accepted (RS M1, RB M1 unbound; `TestUnboundFlagsAblation`) |
| no snapshot check | bound | detected (as no replay, plus `policy.replay` on plain) | detected | **accepted** (forge-snapshot, forge-restate) | A+I+X forge-restate passes (RS M2, `nsb`) |
| no snapshot check | unbound | **accepted** (forge-snapshot) | **accepted** (forge-snapshot) | **accepted** | |

So with replay and the snapshot check, the smallest tested set that passed
is A+I+X in both designs on the receipt path, and with real keys the
attacker needs every adapter key whose receipt stays in the log (X_all).
Without replay it is A+I+X_op for the bound design and A for the unbound
one: the 12 outcomes changed by binding. On the reconciliation path the
bound design's smallest set is A+I with a signed status reply (S7).

## S4. Oracle mismatches and the first run

Source: `compromise/oracle_mismatches.csv` (full verifier, strongest
attacker, main version), `docs/paper/artifact/ORACLE_FREEZE.md`.

- **The 46 mismatches** (514 of 560 labelled results agree), every one a
  result the verifier detected and the oracle expected to pass: 8 from the
  oracle's assumption that the snapshot is unchecked (cause S1), all in the
  unbound design; 14 from an unchecked escalation mode (cause A3), bound 5
  and unbound 9; 24 from the limits of how we wrote two edits, C1 (14) and
  C2 (10).
- **How we wrote the edits (C1, C2).** These are the edits the paper's
  Table III footnote says were never accepted "because of how we wrote
  them". C1: the change-rules target message has one recipient, so no valid
  snapshot makes MSG-BULK fire, and replay detects every variant. C2: a
  forged snapshot that makes relabel-approved replay would also make two
  never-executed approval requests automatic, which the edit engine does not
  delete, so replay detects it.
- **Alternative versions.** After the run, two alternative versions written
  in advance were combined (snapshot checked and mode checked), which
  describe the verifier as built: 540 of 560 agree. The combination also
  predicts four of the C1 results, so the 20 remaining mismatches are C1 and
  C2, 10 each. No oracle label was changed.
- **The first run** (2026-10-07, before build 1, 11 key sets) reported 23 of
  308 changed outcomes without replay: 16 predicted by the oracle and 7
  caused by an escalation-mode check missing from the unbound design. Making
  the check the same in both designs removed those 7 and the 4 predicted
  change-escalation outcomes, leaving 12. The correction strengthened the
  unbound design and removed outcomes that favoured binding.
- **Controls.** 1,280 of 1,280 verifications of unedited runs VERIFIED
  (real: 600 CONSISTENT, 40 ANCHORED; simulated with all roles assumed
  stolen: 600 SIMULATED_CONSISTENT, 40 SIMULATED_ANCHORED); no false alarms.

## S5. Request path, retries, journal failure, durability

**The request path as pseudocode:** `docs/paper/artifact/algorithm_mediate.tex`
(compiles on its own). In words, for one call c with operation key o in flag
mode:

1. Normalize c into the effect e; refuse if it does not parse. d = H(L_E, canon(e)).
2. If o is journaled: answer REJECTED (ID conflict, scope call) if its
   digest differs; reconcile it if it is unresolved (UNCERTAIN or
   RECONCILIATION_REQUIRED); otherwise return its stored answer (exact
   retry, scope call).
3. Journal "received"; record REQUEST_VALIDATED.
4. PRE decision (reserves budget); record POLICY_DECISION; REJECTED on DENY.
5. FINAL decision (reuses the reservation); REJECTED if the policy hash or
   the PRE hash changed; record POLICY_FINAL with h_FIN.
6. Issue the capability κ (carries d, h_FIN, h_P); record CAPABILITY_ISSUED.
7. Use κ once, after the adapter proves it holds its key; journal
   "consumed"; journal the dispatch intent, with the flag; open the
   dispatch lease (30 s).
8. Lease expired before the first byte: UNCERTAIN; first byte refused:
   REJECTED, nothing sent. Send e with idempotency key o; no answer:
   UNCERTAIN.
9. The adapter verifies the provider receipt ρ_P and signs the effect
   receipt ρ_E; journal the outcome; record EFFECT_EXECUTED (if that fails:
   RECONCILIATION_REQUIRED); return COMMITTED.

Every return records CALL_RESULT (status, scope, reason, whether
dispatched, flag of the reported effect). Each step is flushed to the
operation journal on disk before the gateway acts on it. Reconcile asks the
provider for its signed status for o and records RECONCILED; it never sends
the request again.

**Retry rule for every state** (operation key = tenant, user, operation ID).
In every state: all calls for one key are serialized by an operation lock,
so an exact retry never runs at the same time as the dispatching call;
different content under a journaled ID is REJECTED (`operation_id_conflict`,
scope call), before and after a restart; a new operation ID always starts a
new operation and may commit the same content again (in-process faults:
400 of 1,120; process-kill tests: 25 of 35 new-ID test runs).

| state | exact retry in the same process | exact retry after a gateway restart (same journal) | tests |
|---|---|---|---|
| A. never seen, or "received" not journaled (for example a call refused because the journal is unavailable) | runs as a first call; if "received" cannot be written: REJECTED (`journal_unavailable`, scope call), no state kept | unknown to the gateway, so it runs as a new operation | process-kill journal case (the probe) |
| B. received, no dispatch intent, no outcome on disk (also an approval still pending) | waits for the lock, then gets the outcome of the running call | runs again from PRE: new PRE and FINAL, a new capability (and in human mode a new approval); may commit once | `TestRestartAfterCrashBeforeDispatchIntent` |
| C. dispatch intent on disk, no answer recorded | after the call: COMMITTED, REJECTED with a signed provider refusal, UNCERTAIN or RECONCILIATION_REQUIRED; never REJECTED without a signed provider answer | UNCERTAIN (`restart_after_dispatch`); the retry reconciles and never sends again; a different provider key leaves it UNCERTAIN (`provider_changed`) | lifecycle tests; process-kill kill points after the dispatch intent |
| D. provider committed, gateway outcome incomplete | a lost answer gives UNCERTAIN, missing evidence RECONCILIATION_REQUIRED; the retry reconciles: APPLIED gives COMMITTED (`reconciled`, scope operation) with a RECONCILED entry; later retries get the stored COMMITTED (scope call) | as C: reconciled to COMMITTED, no new request | `TestRestartReconcilesUncertainOperations`; kill points after_receipt, before/after_effect_executed |
| E. COMMITTED and recorded | stored COMMITTED (`replayed`, scope call), no request | answered from the journal, scope call | `TestRestartReturnsStoredOutcomes`, `TestReplayedAnswersAreCallScoped` |
| F1. REJECTED, scope operation, nothing sent, outcome on disk | stored REJECTED, scope call, never decided again | stored REJECTED, scope call | `replay_scope_test.go` ("aborted operation after the restart") |
| F2. as F1, but the outcome record could not be written | stored REJECTED from memory, scope call | becomes state B: runs again and may commit once (the journal-failure case below) | process-kill journal case |
| F3. REJECTED, scope operation, request sent (signed provider refusal or signed ABSENT) | stored REJECTED, scope call | outcome on disk: stored REJECTED; outcome lost: UNCERTAIN, then reconciliation gets ABSENT again (the provider keeps the refusal), so REJECTED again; never commits | provider-fault test cases |
| G. REJECTED, scope call (ID conflict, invalid request, journal unavailable, a stored refusal) | the operation keeps whatever state it has; the same refused content gets the same refusal | decided by the operation's journaled state | |
| H, I. UNCERTAIN or RECONCILIATION_REQUIRED (including an expired lease) | reconcile only: APPLIED gives COMMITTED; ABSENT gives REJECTED (`provider_not_committed`, scope operation); UNKNOWN, a failed lookup, a failed audit write or a different provider key keep the state (scope call); after 16 attempts, manual handling; never sends again | the journal keeps UNCERTAIN; reconcile as in the same process | lifecycle tests; process-kill provider faults |
| J. journal unavailable (whole gateway) | new operations: REJECTED (`journal_unavailable`, scope call); stored answers from memory; a state-B operation that runs again is refused before sending, with an answer kept in memory only; UNCERTAIN operations cannot reconcile (`reconciliation_unavailable`); in every case nothing is sent | records never written do not exist, so each operation follows its last journaled record | process-kill journal case only |

**Finality of an operation-scope REJECTED.** Such an answer says that no
effect existed for the operation key when it was given. It becomes final
only once its outcome record is on disk. If that write fails, a restarted
gateway treats the operation as never sent, and an exact retry may commit it
once; the verifier accepts that history without a warning
(`op.no_effect_when_refused` allows an effect after a refusal when a newer
FINAL and a newer valid capability follow). Nothing was sent the first time,
so this is still at most one effect.

**The journal-write-failure case** (`journal/read_only_at_consume`, 5 of 5
repetitions identical; `killsuite/journal_chronology.md`). The journal is
made read-only right after the capability is used, so the dispatch intent
cannot be written:

| # | segment | call | answer | scope | sent | provider effects at the answer |
|---|---|---|---|---|---|---|
| 1 | 1 | first call; the dispatch-intent write fails | REJECTED (`aborted_before_send`) | operation | no | 0 |
| 2 | 1 | a second operation during the failure, never journaled | REJECTED (`journal_unavailable`) | call | no | 0 |
| 3 | 1 | exact retry in the same process | REJECTED (`aborted_before_send`, the stored answer, `replayed`) | call | no | 0 |
| - | - | graceful close; restart on the same journal, which holds "received", "capability issued", "capability used" and no outcome | | | | |
| 4 | 2 | exact retry after the restart: a second capability, EFFECT_EXECUTED | COMMITTED | operation | yes | 1 |

So the "two REJECTED answers" per operation are answers 1 and 3: the
original refusal (scope operation) and its stored copy (scope call, which
never speaks for the operation). Each was true when given (0 effects at the
answer, 10 of 10). Every operation had exactly one effect (5 of 5), and no
REJECTED answer was given while the provider held an effect (0 of 30 in all
process-kill tests). The commit after the restart is consistent with R3
(one effect per operation key) and R4 (no answer false when given). What
does not hold is finality: the operation-scope answer could not be recorded.
A caller that treated answer 1 as final and retried under a new ID would
have paid twice. The signed CALL_RESULT of answer 2 contains the absolute
path of the journal file, so these folders are not in the anonymous archive;
`journal_chronology.md` shows the path as `<work>\<cell>`.

**What was and was not tested at the journal.** Only one failure position
was tested: the dispatch-intent write. Failures at capability issue, at
capability use, at the outcome record after a commit and at the
reconciliation query were not. No unit test covers the journal's
"unusable after a write failure" latch; in the tested case the failure
happens when the file is opened for appending, which does not set the latch.
(`docs/demo/CONTRACTS.md`, "Finality of an operation-scope REJECTED", cites
`replay_scope_test.go` "aborted before send" for a journal that fails
closed; that test refuses the capability use itself and involves no journal
failure.)

**Provider restarts.** Tested: `TestProviderRestartKeepsStateKeyAndIdempotency`
(graceful shutdown and restart on the same folder: same key, the same
journal byte for byte, a resent request gets the stored receipt, the state
chain continues across a second restart); `TestProviderStoredStateIsCheckedOnStart`
(a torn tail is cut, an edited record or an identity mismatch is refused);
the demo self-test with the provider process restarted together with the
gateway (the retried operation was already reconciled, so it is answered
from the journal); the 20 multi-process runs (the provider kept its key, its
journal matched the folder, and commits stayed equal after the gateway
replayed its operations). Not tested: a provider crash in the middle of a
request; a provider restart while a gateway operation is UNCERTAIN or
RECONCILIATION_REQUIRED, followed by reconciliation; the provider's stop on
a failed append; provider power loss; a provider that loses or rolls back
its store but keeps its key (it would sign ABSENT, and the gateway would
answer REJECTED); any provider restart inside the process-kill tests.
Assumed, not shown: the provider executes each idempotency key at most once,
answers status lookups truthfully and keeps its state across restarts.

**In-process fault points** (`crash/RESULTS.md`): none; before capability
use; after use; provider response lost; after the receipt, before the audit
entry; failed audit append; emulated failed head update (`head_replace`).
Each crossed with a same- or new-ID retry and restart none or journal, 20
repetitions (the paper's **flag-mode run**; its two operations per fault run
are a plain AED 400 request and an internal message, none flagged): 560
fault runs, 1,120 operations, 2,240 answers, 1,360 provider effects, 840
folders; every armed fault fired. Faults at capability use gave REJECTED
(240 `dispatch_refused`, 240 `aborted_before_send`; all not sent); a lost
response gave UNCERTAIN; faults after the receipt gave
RECONCILIATION_REQUIRED. Same-ID retries: 320 unresolved operations
reconciled (COMMITTED, 0 new effects), 240 got the stored answer (scope
call); new-ID retries committed again (400, by design). A **deny-mode run**
(280 fault runs, 560 operations, 10 repetitions; `crash/deny/`) gave the
same zeros; the paper cites only the flag-mode run. Classification evidence
of the 1,680 operation views: `issuer_adapter` 1,040,
`issuer_only_reconciled` 320, `issuer_only_no_effect` 320. Missing by kind:
`freshness` 840/840, `unresolved` 160, `issuer_only` 160. Build 3's rules on
this genuine evidence: 480 of 480 reconciled commits have a reason to
reconcile, 0 of 640 status replies are dated outside the 5 s bounds, and
1,680 of 1,680 capabilities name the adapter key that signed the receipt.
First segments passed alone because the dropped instance still recorded an
answer, unlike a killed process.

**Restart-tamper probes** (simulated audit-key holder): deleting,
truncating, rolling back, unlinking or swapping the first segment of a
restart was each detected 560/560 (2,800/2,800 in all); the clean copy
accepted 560/560. Earlier-segment keys: with the newest segment's keys
anchor alone the run is CONSISTENT with `anchored_keys` not checked (280 of
280); another repetition's earlier keys fingerprint fails `keys.anchor` (280
of 280).

**Partly written files and power loss** (`killsuite/RESULTS.md`,
`cmd/agentgate-killsuite/README.md`; flush order checked by reading the
code, since kills cannot test it). A kill is a process crash, not a power
cut: the kernel's file cache survives, so a killed process never loses a
write it made. Four simulated states stand in for power loss:

- A leftover temporary head file (`.head.json.tmp-*`) is ignored by the
  verifier: VERIFIED, no warning.
- A reverted head fails `head.matches` in segment 1 and in the whole run (5/5
  and 5/5), a permanent false alarm on an untouched crash state; its finding
  text reads like tampering. The restart itself proceeds (it takes the head
  from the log's last line, not from `head.json`). On Windows a power loss
  can leave this state (no directory flush).
- A partly written journal line (the first half of the last
  `operations.jsonl` record) is discarded and cut on open, and the restart
  proceeds (5/5).
- A partly written audit line makes the restarted gateway exit ("restart
  blocked"): the restart fails closed (5/5), the agent never gets an answer,
  and segment 1 is FAILED; the provider's effect stays unaccounted for until
  the folder is repaired by hand.

The code flushes journal and audit lines and the temporary head file before
acting on them; Windows has no directory flush, and the drive's flush
behavior is unknown. Not tested: flush ordering on real hardware, directory
entries, the drive cache.

**Lease history.** A shorter 2 s dispatch lease failed closed once in a run
before the frozen builds, so the lease is 30 s. Build 3: 0 lease expiries in
3,640 dispatches; minimum slack to the deadline 28,364.0 ms; maximum time
from capability use to dispatch intent 375.2 ms (load, not a performance
result).

**Revoked grant.** Stayed revoked across a gateway restart in 20 of 20
multi-process runs.

## S6. Cost: full table and stage detail

Source: `baseline/RESULTS.md`, `baseline/analysis.json`,
`baseline/stagecost/`. One machine (AMD Ryzen 5 7600X, 31.2 GiB, Windows 10
Pro), alone during the session (2026-10-20, 18:30-18:54 UTC).

**Variants.** *Direct*: normalizer, `adapters.Prepare`, adapter transport and
receipt check; no policy, grant, capability, receipt, journal or audit (a
lower bound, not a secure alternative). *Checking* (policy-only): + policy,
grant, capability, signed receipts. *Logging* (full): + signed hash-linked
audit log, a flush per entry, `head.json` replaced through a flushed
temporary file. *Full+journal*: + flushed operation journal. *Flagged*: an
AED 6,000.00 payment that FIN-APPROVAL-LIMIT flags.

**Design.** 500 paired trials in 10 blocks of 50, rotated order; closed
loop with 1, 2, 4, 8 and 16 clients, 400 calls per load level; six runs
(R1-R5 payments, M1 messages); R2 primary (lowest background load); 0 of
62,500 measured and 0 of 4,100 warm-up calls failed; 230/230 folders
ANCHORED; block (cluster) bootstrap, seed 20261007, 10,000 resamples.

| paired difference per call (R2) | median | block 95 % CI | trial 95 % CI | range R1-R5 | mean [block CI] |
|---|---|---|---|---|---|
| checking (policy-only - direct) | 3.14 ms | [3.05, 3.25] | [3.09, 3.21] | 3.13-3.20 | 3.26 [3.13, 3.42] |
| signing and flushing the audit log (full - policy-only) | 11.77 ms | [11.53, 11.95] | [11.61, 11.89] | 11.71-12.03 | 12.36 [11.80, 13.26] |
| total (full - direct) | 14.95 ms | [14.73, 15.30] | [14.85, 15.12] | 14.95-15.22 | 15.62 [14.94, 16.67] |
| operation journal (full+journal - full) | 3.77 ms | [3.54, 3.89] | [3.54, 3.89] | 3.63-3.77 | 3.80 [3.58, 4.07] |
| flagging (flagged - full) | 0.22 ms | [0.07, 0.38] | [0.07, 0.35] | 0.09-0.22 | -0.02 [-0.90, 0.61] |
| everything (full+journal - direct) | 18.70 ms | [18.37, 19.11] | [18.50, 18.83] | 18.61-18.99 | 19.42 [18.76, 20.35] |

Medians of different rows do not add. Flagging added under 0.4 ms in every
build (build 1 -0.27, build 2 -0.07, build 3 0.22); its sign follows the
disk's state after the journal's extra writes in the rotation, not the flag
(the flagged path's code is identical in builds 2 and 3). M1 (messages):
checking 3.34, logging 11.97, total 15.29, journal 3.69 ms.

**Tails, kept.** R2 sequential p50 / p95 / p99: full 16.31 / 19.51 / 21.86
ms, full+journal 20.01 / 23.99 / 27.33, flagged 16.56 / 19.83 / 25.25. Runs
without a sequential disk slowdown (R1, R2, R3, R5): full p99 20.71-24.29
ms; R4 coincided with a slowdown (full p99 101.5 ms). Under load (median of
five runs, p99): 1 client full 24.58 ms, 16 clients 238.28 ms (R2 alone:
32.31 / 194.97 ms).

**Throughput** (median of R1-R5, calls/s): full 56.5 / 78.4 / 88.2 / 91.4 /
86.3 at 1 / 2 / 4 / 8 / 16 clients; it levels off at 88.2 from 4 clients
(pooled median of 15 cells; cells outside R3's slowdown 76.9-92.7), 1.1
cores busy; full+journal 81.1; policy-only 742 at 16 (CPU-bound); direct
3,085 at 16. CPU per call at 1 client: direct 1.52, policy-only 6.09, full
13.48, full+journal 13.63 ms. Little's law holds within 1.7 % in every full
and full+journal cell; R2 at 16 clients: 16 / 92.70 = 172.6 ms against an
observed mean of 170.3 ms.

**Why it levels off.** One audit log per gateway; appends serialized by one
lock; each flushes `audit.jsonl` and replaces `head.json` through a flushed
temporary file; no batching of flushes (group commit); six entries per call.
6 x 1.751 ms = 10.5 ms of serialized disk work gives a ceiling of about 95
calls/s; the observed 88.2 calls/s means 11.3 ms per call, so the separately
timed appends explain about 93 %.

**One audit append, by stage** (`TestStageCost`, run1, the run with the
fewest appends over 10 ms (run1 0, run2 2, run3 8); 10,000 timed appends;
means; shares of the staged total): encode + hash 42.7 us (2.4 %), Ed25519
signing 40.3 us (2.3 %), log line write 10.8 us (0.6 %), log flush 434.3 us
(24.7 %), temporary head write 209.2 us (11.9 %), head flush 770.9 us
(43.9 %), head rename 249.2 us (14.2 %), directory flush 0.1 us (none on
Windows); staged total 1,757.5 us against an uninstrumented append of
1,751.3 us. Replacing `head.json` is 69.9 % of an append; computation
(encoding, hashing, signing) 4.7 %. These are the stage rows the paper's
Table VII no longer prints:

| stage (run1 means) | ms |
|---|---|
| encode, hash and sign (entry and head) | 0.08 |
| log line write and flush | 0.45 |
| head: temporary file write, flush and rename | 1.23 |
| directory flush | none on Windows |
| one audit append, uninstrumented | 1.75 |

Six consecutive appends: median 10.24 ms, about 87 % of the 11.77 ms
recording median (not an exact decomposition). The test binary is
byte-identical to build 2's, yet appends were 3 % slower on this day: the
machine changed (a Defender platform update on 2026-10-15, more background
CPU, more drive slowdowns), not the code. On NTFS a flush also forces
earlier metadata changes, so a stage's time is where an append waits, not
necessarily what it caused.

**Witness update** (`TestWitnessPushCost`, run3, the run without a disk
slowdown; in no reported latency): one update and head save per call about
2.2 ms (means 1.26 + 0.96; medians 1.21 + 0.93); one per entry about 10.6
ms. Registration with the enrollment key happens once per run, outside the
timed loop, and adds nothing per update.

**Storage and memory.** Consumer 2 TB NVMe SSD (KINGSTON SNV2S2000G), NTFS,
4,096-byte clusters, 47.3 GiB free (97.5 % full) at the start; device
write-cache setting not determinable without administrator rights; Defender
real-time protection on (platform 4.18.26090.9). Allocation per call 423 /
2,681 / 3,040 / 3,063 KiB (direct / policy-only / full / full+journal);
peak working set at most 87.6 MiB, peak Go heap at most 49.1 MiB.
Allocation volume is not resident memory. Any optimization (for example
group commit) must still flush a recorded step before the gateway acts on
it.

**Against builds 1 and 2.** Recording 11.40 (build 1), 11.29 (build 2),
11.77 ms (build 3); throughput 94.3, 92.5, 88.2 calls/s. No code on the
timed path changed between the builds. Ten runs of the same build-3 binary
on 2026-10-20 gave recording medians of 11.27-12.03 ms; quote ranges, or
quote build 3 with S17.

## S7. Lifecycle states: transition view and evidence basis

**Transition view.** A call passes validation, PRE, FINAL, capability issue
and a journaled dispatch intent; a receipt then makes it COMMITTED (receipt
path), a lost answer UNCERTAIN, and an exact retry logs the provider's
signed status reply (RECONCILED), which commits it (reconciliation path) or
settles it as REJECTED. In full: received -> validated -> PRE decision ->
(DENY: REJECTED, audit only) -> FINAL -> capability issued -> used ->
dispatch intent -> provider answer: receipt -> EFFECT_EXECUTED -> COMMITTED;
no answer or lease expired after use -> UNCERTAIN -> exact retry or
Reconcile: provider APPLIED -> RECONCILED committed -> COMMITTED (issuer
only after a restart); provider ABSENT -> RECONCILED not committed ->
REJECTED; provider UNKNOWN or lookup failure -> stays UNCERTAIN, never sent
again. Audit append failure after the receipt -> RECONCILIATION_REQUIRED ->
exact retry or Reconcile -> COMMITTED. Journal write failure at capability
use or dispatch intent -> REJECTED (`aborted_before_send`, nothing sent).
Human mode adds PENDING (an approval request waiting for the reviewer)
between the PRE decision and FINAL; an approval not yet used for a dispatch
does not survive a crash (15 of 20 human test runs needed a second
approval).

**Protected fields.** Flag, mode and fired rules are in v_PRE and v_FIN (and
so in h_FIN, which κ and ρ_E carry). The flag (not the mode or the rules) is
also stated on CALL_RESULT (the executing call, stored COMMITTED answers,
the reconciling or confirming call) and on RECONCILED; the dispatch intent
journals it. The agent's MCP answer never carries it.

**Evidence basis.** Source: `fixture-studies/RESULTS.md` §2.4 (the paper's
Table I is its bound-design summary), `docs/demo/VERIFIER_CHECKS.md` §1,
`killsuite/RESULTS.md`. "In place" = the keys that changed the
classification without changing the state: the smallest tested key set that
was accepted, not a proof that fewer keys cannot succeed. Plain = the edit
without snapshot forgery; forge-restate = the attacker who forges the
snapshot and rewrites the policy hash everywhere. A head anchor detected
every row (RS 136/136, RB 80/80, LRR 52/52; none of LR's 120 acceptances had
one). Labels: F real-key tests on fixtures, S the key-theft simulation, A
argued from the code. Test codes: RS `TestRound4RealSignaturesAgreeWithSimulation`,
RB `TestRound4RationalAttackerBinding`, LR `TestRound4LifecycleRealVsSimulation`,
LRR `TestRound4LifecycleRationalAttacker`, LH `TestRound4LifecycleHistories`,
NC `TestRound4NoCapabilityReclassifiedInPlace`, SF
`TestRound4ValidlySignedInconsistentFields`; L1
`TestLifecycleL1AuditKeyDowngradeToUnresolved`, L1b
`TestLifecycleL1bAuditIssuerUnresolvedStripFlag`, L2
`TestLifecycleL2ReconciledCommitClassification`, L3
`TestLifecycleL3AuditIssuerConversionWithoutReplay`, L4
`TestLifecycleL4FullVerifierAllReconciled`, CH
`TestLifecycleConflictingHistories`, RA `TestReconciledAdapterReceipt`, RR
`TestRecoveryRecordsStateTheBoundFlag`, UD
`TestLifecycleUnresolvedCapabilityDeletion`, CE
`TestClassificationEvidenceByLifecycleState`, SA
`TestSimulationAgreesWithRealAuditKeyResigning`. (The test names keep their
original words; "rational attacker" is the attacker who leaves unheld
records untouched.)

| state, reported as | in place: bound, no replay | in place: bound, full (forge-restate) | in place: unbound | downgrade to a less protected status | build 3 |
|---|---|---|---|---|---|
| **COMMITTED via receipt** (EFFECT_EXECUTED with an adapter receipt); `issuer_adapter` | **A+I+X_op**, F: RS/RB M1, M3; A, A+I and A+Xf are detected by the binding checks alone | plain: `policy.replay` (F). Forge-restate: **A+I+X over every adapter receipt left in the log**, F (RS/RB M2, LR confirm-rest) | no replay: **A** (F). Full: forge-restate A+I+X (F) | to reconciled with the flag kept: **A+s**, in the form that meets the date and order rules (L2 careful form, 4/4; the build-2 form is FAILED 4/4). To reconciled and reclassified: A+I+s (LR, L3 6/6, L4 8/8). To UNCERTAIN: A, flag kept (L1); reclassified: A+I (LR, L1b). To no capability or not committed: detected (CH, LH) | the status reply must be dated within the operation and follow an unresolved status; **key sets unchanged** |
| **COMMITTED via reconciliation** (no adapter receipt); `issuer_only_reconciled` plus a Missing `issuer_only` entry | **A+I+s**, F (LR convert, L3). A is detected without a signature failing (LRR) | forge-restate with every execution converted: **A+I+s**, F (LR, L4) | **A+s**, F (LR) | RECONCILED deleted, so UNCERTAIN: A; VERIFIED, `issuer_only_unresolved`, `run_complete` fail (LH). Other substitutions detected (LH) | the reply must be dated in [capability issue - 5 s, entry + 5 s] (`TestReconciledStatusDate`) and needs a reason to reconcile (`TestReconciledNeedsAReason`); dates of 2027 (L2) and 2030 (SF), accepted before build 3, are now detected |
| **reconciled with the adapter receipt attached**; `issuer_adapter` | with the receipt kept: A+I+X_op (A; RA, F 3/3 + 1). Dropping the receipt gives the row above | as the row above (F: LR, L4) | A (A) | as the row above | the receipt's signing key must be the capability's `cnf` key (`TestCapabilityConfirmationKey`, F) |
| **executed with a confirming RECONCILED**; `issuer_adapter` | **A+I+X_op**, F (LR confirm, LRR) | forge-restate with the others converted: A+I+X_op (F) | A (F) | execution deleted: as the reconciliation row; wrong flags and order: detected (CH, RR) | a confirming RECONCILED is not subject to the order rule |
| **UNCERTAIN or RECONCILIATION_REQUIRED with a capability**; `issuer_only_unresolved`, `flagged_unconfirmed`, warning, Missing, `run_complete` fail | **A+I**, F (LR downgrade, L1b). A detected (LRR) | forge-restate with the others converted: A+I (F) | A (F) | to no capability: A, `audit_only`, only if the provider never committed (UD). With a commit: detected (CH) | none |
| **PENDING with a capability, no outcome**; `pending`, `issuer_only_unresolved`, warning, Missing (`unresolved`), `run_complete` fail | removing the outcome needs A (F: 4/4 forms; 4/4 controls settled) | same | same | with a provider commit: FAILED `provider.matches_audit` (F: 2/2) | **new.** Build 2 reported the same 4 forms VERIFIED, `issuer_only_no_effect`, with no warning and no Missing entry; the process-kill tests had 10 such operations |
| **not committed** (genuine ABSENT); `issuer_only_no_effect` | A+I (A) | A | A (A) | RECONCILED deleted: A (genuine state); capability deleted: detected (LH) | an ABSENT dated after its entry fails; the lower bound does not apply |
| **no capability**; `audit_only` | **A**, F (NC) | plain: `policy.replay` (F: NC). With snapshot forgery: A | A (A) | deleting the operation: A, VERIFIED without a head anchor (F: SA) | none |

**What the table says.** In every state, a change the verifier accepts needs
the audit key, and a head anchor detects it. On the receipt path binding
raises the bound design's no-replay threshold from A to A+I+X_op, and the
smaller key sets are caught by the binding checks themselves, not by a
broken signature (RB). On the reconciliation path the threshold is A+I plus
a signed status reply, which needs no key; the build-3 date and order rules
add no key either (the audit key signs the earlier unresolved status), only
a timing requirement: the reply must have been fetched while the operation
was open. Under the full verifier the snapshot forger needs A+I plus the
adapter keys of exactly the receipts left in the log, which is none if every
execution is converted. Every accepted downgrade is reported as weaker
(`issuer_only_reconciled`, `issuer_only_unresolved`, `audit_only`, a Missing
entry, a warning, `run_complete` fail).

**Conflicting, mixed and substituted histories** (27 with valid signatures,
full verifier, keys anchor; 21 detected, 6 accepted, none of the 6 changing
a classification). The 12 conflicting histories (CH): 9 detected, 3
accepted with the flag kept and the evidence strength stated (a confirming
RECONCILED after an execution, `issuer_adapter`; the same commit reconciled
twice, `issuer_only_reconciled`, effects counted once; CALL_RESULT restated
RECONCILIATION_REQUIRED, warning, `run_complete` fail); a real provider-key
forgery of ABSENT (A+P) is detected. The 15 histories of LH, with records
deleted, moved, or replaced by another operation's genuine receipts or
replies: 12 detected, 3 accepted and reported (the attached provider receipt
removed from a genuine RECONCILED, class unchanged; the genuine RECONCILED
deleted, reported UNCERTAIN; a genuine ABSENT settled twice, idempotent);
the same with replay off (15/15). Full list: `fixture-studies/RESULTS.md`
§2.3.

## S8. Policy misuse: case families and details

Source: `misuse/RESULTS.md`, `misuse/misuse_by_category.md`. Identical in
builds 1, 2 and 3.

- **Case families** (59 cases, 95 requests): amounts around both limits in
  each currency (zero, negative, fractional, oversized, malformed); split
  payments; repeated releases; confidential text copies; payees, recipients
  and effect types outside the grant; revoked and expired grants; reruns
  without a grant.
- **Harmful, flag mode** (44, a hand-written set, not a sample; percentages
  describe this set only): 24 blocked (54.5 %), 3 allowed with a flag (6.8
  %), 17 allowed with no flag (38.6 %); blocked by content rules only 10, by
  DEL-* only 11, both 3 (deny: 13 / 10 / 4). **Split by grant** (Table VI):
  40 ran under a grant, 24 blocked / 3 allowed with only the generic
  MSG-EXTERNAL flag / 13 allowed without a flag (12 split payments, 1 wrong
  purpose); the 4 reruns without a grant repeat 4 requests that a grant
  blocked (USD 500.00 #7 and #8 by DEL-BUDGET, releases #4 and #5 by
  DEL-COUNT), all 4 unflagged; so 17 = 13 + 4, and the 44 count those 4
  request kinds twice. Remaining harm: 12 x AED 5,000.00 to one payee (AED
  60,000.00; the single AED 60,000.00 request was denied); AED 4,999.99 for
  the wrong purpose. Paired controls: 6/8 vs 8/8 (USD budget), 3/5 vs 5/5
  (release count). The grant variants of the 44: default 19, boundary 15,
  tight releases 2, scope 2, future 1, expired 1, none 4.
- **Confidential text:** 5 of 8 blocked by MSG-CONFIDENTIAL-TEXT; 3 of 8
  executed with only the generic MSG-EXTERNAL flag; 0 of 2 internal false
  positives. MSG-CONFIDENTIAL-TEXT matches near-verbatim text only; we claim
  no information-flow control. In deny mode the 3 paraphrase or near-copy
  messages are blocked only because deny mode refuses every external
  message.
- **Deny mode:** legitimate 1 of 29 blocked, as specified; harmful 27
  blocked, 17 allowed; 45 committed; REJECTED with nothing sent 50/50.
- **Labels:** written in `cmd/agentgate-eval/misuse.go` from the case
  definition before any misuse run (commit `997d607`); the earliest recorded
  run (2026-10-07, `56bab94`) carries all 95 labels as now; one expected
  outcome changed since (the comma case, `d73aa73`). The grouping of Table VI
  was made after the run; no label changed. Thresholds (AED 5,000.00 /
  50,000.00; USD 1,500.00 / 15,000.00; budgets AED 100,000.00 and USD
  3,000.00; maximum counts 3 or 10) are illustrative parameters of a
  fictitious organization, chosen so that tests fall on both sides; we test
  exact enforcement, not whether the limits are adequate.

## S9. Related work: rows not in the paper's table

Same columns and codes as the paper's related-work table (Y reported, P
partial, N not reported or excluded by the work's assumptions, -- outside
its aim): autonomous delegation | classification binding | separate key
holders | policy replay | crash recovery | real providers or agents.

| work | deleg. | binding | separate key holders | replay | recovery | real | why not in the paper's table |
|---|---|---|---|---|---|---|---|
| Delegation observability (Mishra and Sharad, 2026) | P (delegation ID) | -- | N | -- | -- | P | observability, not enforcement; discussed in the text |
| Actions with Receipts (Hu et al., 2026, concurrent) | -- | N | N | P | N | P | hashes claims with evidence, signs nothing; discussed in the text |
| CapLease (Xu et al., 2026) | N | -- | N | -- | Y | P | outside the paper's aim (recovery leases); discussed in the text |
| Progent (Shi et al., 2025) | P | -- | -- | -- | -- | Y | model-side privilege control; discussed in the text |
| CaMeL (Debenedetti et al., 2026) | P | -- | -- | -- | -- | Y | model-side defense; discussed in the text |

Notes on the paper's table: AgentGate's "separate key holders" is N because
the provider and witness keys are in separate processes but one user
account can read every key file, and the audit, issuer, adapter and
delegation keys share one process. AID-Guard carries its risk evaluation
into the capability under separate role keys, with no class for allowed but
flagged actions (binding P), keeps role keys on one trusted host (P) and
lets only a privileged party replay its policy (replay Y). CATP binds the
matched rule only (allow or deny) under one trusted key (binding P) and
checks the policy hash without re-running the policy (replay N). AIREP:
witness independence is specified and evaluated with test bindings (P).

## S10. Glossary

The paper's terms, in the order a reader meets them. The longer engineering
glossary `docs/demo/GLOSSARY.md` uses some older names (map at the end).

| term | meaning |
|---|---|
| effect | a change made through a tool: sending an external message, releasing a document or creating a financial request (which asks for a payment but does not pay) |
| operation, operation key | one intended effect, named by tenant, user and operation ID; retries of the same operation share the key |
| call, scope | one MCP tool call and its answer; scope "operation" means the answer speaks for the whole operation, scope "call" only for this call |
| policy, rules | 19 fixed content rules plus 5 delegation rules (`DEL-*`); each returns ALLOW, ESCALATE or DENY |
| escalation mode | what an ESCALATE result becomes: run flagged (flag mode, the default), wait for a person (human mode) or deny |
| audit classification | the flag, the fired rules and the escalation mode of a decision |
| PRE, FINAL | the two decisions of a call: on arrival, and again just before the capability is signed |
| capability | the issuer's signed, single-use permit for one effect, valid for at most 60 s |
| adapter | the connector to the service; it uses a capability once and signs an effect receipt |
| effect receipt, provider receipt | the adapter's signed record of an effect; the provider's signed record of a request |
| signed status reply | the provider's signed answer to a status lookup (APPLIED, ABSENT or UNKNOWN) |
| binding | signing a hash of the audit classification into the capability and the effect receipt (the bound design); the unbound design signs the policy hash and effect digest but not the classification |
| replay, policy snapshot | the verifier re-runs the fixed rules on each logged request from a stored copy of the policy (the snapshot), whose hash must equal the policy hash the issuer signed (the snapshot check) |
| audit log, head, final head | a hash chain of signed entries; after each entry the gateway signs a head naming it; the final head names the last one |
| run folder, run record | the evidence of a run (log, head, public keys, provider journal copy); the run's settings (mode, grant, snapshot) |
| keys anchor, head anchor | a fingerprint of the run's public-key file taken at run start; a head kept by another party (the saved final head) or countersigned by the witness |
| segment, continuation | after a restart the gateway starts a new segment of the log, whose first entry names the previous final head and keys fingerprint; the witness records it as the run's continuation |
| fresh, out-of-date | a head is fresh if it is the run's latest, which only the witness's live run status, fetched when verifying, can show |
| enrollment key | the key that signs a run's registration with the witness; the verifier accepts only a witness key given to it in advance |
| receipt path, reconciliation path | a commit confirmed by an adapter receipt; a commit confirmed by a status lookup (RECONCILED), where no adapter signs |
| verification levels | the assurance level (FAILED, CONSISTENT, ANCHORED), freshness and run completeness; the older summary verdict VERIFIED means only that no check failed |
| detected | the verifier's assurance level is FAILED; warnings do not count |
| insider | the main attacker: edits a copy of a finished run folder, holding a set of genuine signing keys |
| key-theft simulation | the verifier skips the signature checks of every role whose key the attacker holds; nothing is re-signed |
| real-key tests | fixture tests that re-sign edits with real keys created in memory |
| strongest attacker | an edit counts as detected only if every variant that applies is detected |
| attack | one edit type, key set and anchor condition: 7 x 12 x 4 = 336 per verifier setting |
| binding changed the outcome | the bound design detected the attack and the unbound design accepted it |
| result | one attack in one design under one verifier setting (2,688 over the four settings) |
| fixture, fixture case, fixture result | a small synthetic run signed with keys created in memory; one edit and key set applied to it in one design; its verification under one setting and anchor condition |
| verification | one verifier run on one folder, anchor condition and setting |
| fault run | one combination of injected faults in one process |
| test run | one process-kill test case in one repetition |
| multi-process run | a run with the provider and the witness as separate processes |
| line that makes a check fail, failure condition | a verifier line that fails a check (deleted once each, one mutant per line); a line that adds a fail, warn or problem reason |
| tests added late | tests written after undetected mutants were seen, or together with new code |
| partial Python verifier | a second implementation of 15 of the 38 checks, by the same authors |
| key holder | the party that holds a signing key; the prototype has one key holder for every key |

**Old name to paper name** (result files, test logs, the engineering
documents and earlier versions of this archive):

| old name | paper name |
|---|---|
| attack cell, cell | attack |
| binding flip, flip | outcome changed by binding |
| design result | result |
| labelled design result | labelled result |
| operator (edit operator) | edit type |
| issuer-checked snapshot | the snapshot check |
| structural simulation, structural attack model | key-theft simulation |
| real signatures, disposable keys, real-signature fixture tests | real-key tests |
| careful attacker, rational attacker | the attacker who leaves records it cannot sign untouched |
| status observation, status access | signed status reply |
| custody, custodian, independent custody | key holders, separate key holders |
| custody run | multi-process run |
| kill suite, OS-level kill suite, case, case run, cell run | process-kill tests, test case, test run |
| schedule | fault run |
| refusal site, refusal condition | line that makes a check fail, failure condition |
| post-hoc tests | tests added late |
| held-out operators, held-out mutants | mutants of three other kinds, fixed before any ran |
| subset verifier, second implementation | partial Python verifier |
| witness enrollment | registration with the witness (enrollment key) |
| pinned head, trusted final head | saved final head |
| stale head | out-of-date head |
| approval lineage, overlay root | approval link (the approval record's lists and their hash) |
| torn state | partly written file |
| abandoned gateway object | gateway instance dropped in memory without shutdown |
| no-grant controls | reruns without a grant |
| invariant | guarantee |
| mediation | checking |
| signed durable recording | signing and flushing the audit log |
| legacy verdict | the older summary verdict VERIFIED |

## S11. Unchecked fields

The full map is `docs/demo/FIELD_CHECK_MAP.md` ("Unchecked fields at a
glance"). **Validly signed field edits** (real-key tests,
`TestRound4ValidlySignedInconsistentFields`; one field of one record of a
genuine fixture made inconsistent, every affected record re-signed with the
fixture key of its role, full verifier, keys anchor): 62 edits, 45 detected
with exactly the expected failing checks and no signature check failing, 17
accepted (`fixture-studies/signed_fields.csv`). Per claim (the rows of the
paper's Table II):

| claim | detected | accepted (unchecked) | what the accepted edits touched |
|---|---|---|---|
| effect binding (P3) | 15 | 5 | adapter receipt request digest and idempotency key; adapter ID and outcome; capability tenant (-70001) and subject (2) |
| classification binding (P2) | 7 | 0 | -- |
| provider evidence (P4) | 11 | 7 | status reply request digest and idempotency key; provider receipt request digest, idempotency key and row hash; status state hash and commit count; status provider reference; provider receipt adapter ID and commit time; **the first commit's `state_before_hash`** |
| approval link (human mode) | 12 | 5 | FINAL field 8, capability -70013, adapter receipt `authorization_artifact_hashes`, the overlay root together with `details.overlay_root` (not recomputed), the approver |

Against build 2 (59 edits, 41 detected, 18 accepted): two new edits of the
capability's `cnf` (naming a key that `keys.json` does not list, or the
message adapter key on a payment) and one status reply dated before its
capability are detected; the status reply dated 2030, accepted in build 2,
is now detected. The same 62 edits on the build-2 verifier give 41 detected
and 21 accepted, so the 4 differences come from the new verifier code.

**Why each unchecked field cannot change a claimed property, or which
property it weakens** ((n) and (w) in the paper's Table II):

| field | property | (n) / (w) | reason |
|---|---|---|---|
| request digests and idempotency keys of adapter receipts and status replies | P3, P4 | n | the verifier ties each record to its operation through the effect digest and operation ID; these fields would only show which request bytes were sent |
| capability tenant and subject | P3 | n | inside the effect digest, which the capability, both receipts and the log all carry |
| adapter ID of the adapter receipt and of the provider receipt | P3, P4 | n | fixed by the signing key's role and by the key the capability's `cnf` names |
| adapter receipt outcome | P3 | n | the checks use the effect digest, the operation ID and the provider receipt instead |
| provider accounting fields: status state hash and commit count, provider reference, provider receipt row hash, commit time | P4 | w | they cannot add or hide a journaled commit, but a provider-key holder can make them disagree with the effect digest, so provider-key results depend only on the receipt signature, the effect digest and journal matching |
| the first commit's `state_before_hash` | P4 | w | no initial state is in the evidence, so nothing shows the provider's state before its first commit (`provider.state_chain` compares only later commits) |
| the approval record's lists (FINAL field 8, capability -70013, receipt `authorization_artifact_hashes`) and their hash (the overlay root) | approval link | w | the approval link covers operation, effect digest, PRE hash and request (`op.approval_bound`), not these lists |
| the approver | approval link | w | an unauthenticated local click; who approved is not shown (paper L8) |

**Checked since build 3:** the status reply's date and order, the
capability's `cnf`, the witness run status's `continues` field, operations
with a capability and no outcome (reported unresolved, the run incomplete),
and the earlier segments' keys (S14 and `EXPECTED_TABLES.md`, "Build-3
checks"). Other limits: the verifier assumes that only content sets a flag,
and recovery records state the flag but not the mode or the rules.

**Still future work:** recomputing the provider receipt's fields from the
journal rows, checks of the approval record's lists, an adapter-signed
reconciliation record, an authenticated provider status endpoint.

## S12. Process-kill tests: cases, outcomes and classification evidence

Source: `killsuite/summary.md`, `killsuite/RESULTS.md`, `killsuite/results.json`,
`cmd/agentgate-killsuite/README.md`. The program's own files call a test
case a "cell" and a test run a "cell run".

- **Test cases** (39 x 5 = 195 test runs, 145 of them with a kill). The
  cases cover kills, human approvals, a same-process replay, simulated
  power-loss states, a journal write failure and eight provider faults (lost
  response, signed no-effect status, late delivery, unknown or failed
  lookup). Kills: 7 marked kill points (before_consume, after_consume,
  after_provider_response, after_receipt, before_effect_executed,
  after_effect_executed, before_call_result; six distinct disk states, since
  before_effect_executed leaves the same state as after_receipt) x {ALLOW
  payment same ID, FLAG message same ID, payment new-ID control} = 21. Human
  (AED 12,400.00): pending, approved (both ended by `TerminateProcess` from
  the parent, not at a marked point), after_consume, after_receipt = 4.
  Provider faults without a kill = 8 (lost response on the payment and on
  the flagged message, certified no effect through a signed ABSENT, UNKNOWN
  then APPLIED, late delivery before the lookup, late delivery after ABSENT
  (the late request refused with HTTP 409), lookup failure x3, lookup that
  always fails). Simulated power-loss states = 4 (partly written journal
  line, partly written audit line, reverted head, leftover temporary head).
  Journal write failure = 1. Same-process replay of a flagged message = 1.
- **Totals:** 235 operations (195 original, 35 new-ID, 5 journal probes),
  220 requests sent, 210 provider effects, 455 answers (185 COMMITTED, 30
  REJECTED, 70 UNCERTAIN, 35 approval requests, 135 no answer because the
  process died), 135 segments killed with exit 86, 10 terminated, 5 restarts
  refused; 365 verifications. A recount from disk found 0 disagreements in
  195 test runs; every kill point was reached (145/145); every test case
  gave the same result in 5 of 5 repetitions.
- **Acceptance measures (all 0):** operation IDs with more than one effect
  0/235; REJECTED while the provider held an effect 0/30;
  REJECTED/`provider_not_committed` while the provider holds an effect 0/15;
  COMMITTED without an effect 0/185; unresolved after Reconcile, not
  deliberate 0/225; sent or effect-holding operations not COMMITTED or
  REJECTED after Reconcile, not deliberate 0/210; test runs with an
  operation ID sent more than once 0/195; requests for no operation of the
  case 0; kill points not reached 0. Every provider-fault operation was sent
  exactly once (40 requests); no UNCERTAIN operation was sent again.
- **Reported, not required:** deliberately unresolved 10 (lookup that always
  fails 5: stays UNCERTAIN, VERIFIED/ANCHORED with an `op.outcome_resolved`
  warning, `run_complete` fail; partly written audit line 5: restart
  refused); no final status 15 (the original operation of the two
  pre-dispatch new-ID controls, 10: since build 3 reported unresolved, with a
  warning, a Missing `unresolved` entry and `run_complete` fail; the journal
  probe, 5: refused before it was journaled, unlisted, `audit_only`);
  REJECTED answers later followed by a commit 10 (S5); new-ID duplicates 25
  of 35 new-ID test runs (by design); human test runs needing a second
  approval 15 of 20.
- **Classification evidence** of the original operation (newest folder):
  `issuer_adapter` 85, `issuer_only_reconciled` 75 (50 after a restart, 25
  provider-fault reconciliations without a restart), `issuer_only_unresolved`
  15, `issuer_only_no_effect` 10, not reported 10 (newest folder FAILED). No
  committed RECONCILED entry carried an adapter receipt (0/105).
- **Verdicts:** segment 1 alone 95/155 VERIFIED/ANCHORED, 60 FAILED (50
  `provider.matches_audit` after a kill between the provider's commit and
  any outcome entry; 5 `head.matches` reverted head; 5 partly written audit
  line); whole run 145/150 (the 5 failures are the reverted head); single
  segment 40/40; untouched as-killed copies 20/20. The verdicts and failing
  checks equal build 2's in all 365 folders. New reporting of build 3: an
  `op.outcome_resolved` warning in 100 of 365 folders (build 2: 5), 95 of
  them operations with a capability and no outcome; `run_complete` fail
  115/365 (build 2: 70); `flagged_unconfirmed` 1 in 25 segment-1 folders.
  All 115 genuine RECONCILED entries pass the build-3 date and order rules.
- **Journal write failure:** S5 (chronology table).
- **Flag preservation:** 45 flagged committed test runs; the flag kept in
  85/85 outcome entries, 60/60 recovery entries (10 same process, 50 after a
  restart), 20/20 stored answers (10 same process, 10 after a restart); the
  verifier reports the operation flagged 45/45; stored CALL_RESULT scope
  call 35/35. The agent's MCP answer carries no `flagged` member (0/185), so
  preservation is measured on the audit entries and the verifier report.
  Flag preservation is reported, not part of the acceptance verdict.
- **The two flag-loss bugs.** Building the process-kill tests exposed two
  ways the gateway's own records dropped the flag: a kill between the
  dispatch intent and the outcome record, and, with no kill, a stored
  committed answer returned again within one process. The verifier's report
  still showed the flag, read from the signed decision, but it did not
  compare these records. Both are fixed: the dispatch intent, the
  CALL_RESULT entries of stored answers and the reconciliation entry state
  the flag (not the mode or the rules; the agent's answer never carries
  it), and the verifier now fails a recovery record or stored answer that
  does not state it.
- **Earlier build** (`../build2/killsuite/prefix-earlier-build/`): 190 test
  runs on the program's first commit (`f5cdc2a`; gateway and verifier =
  build 1 plus the program); 20 of 40 committed flagged test runs lost the
  flag in the restarted gateway's RECONCILED and CALL_RESULT entries; that
  build's verifier accepted those folders. Its acceptance rules were
  tightened afterwards, so its totals are not comparable one to one.
- **Limits:** a process kill is not a power loss (the kernel file cache
  survives, so a killed process never loses a write it made); power loss is
  approximated by the four simulated states; kills hit marked points only;
  the provider runs in the parent and is never restarted; no witness; the
  human cases drive the approval relay's real handlers in process with a
  synthetic request (no browser, no TLS connection).

## S13. Clock and registration tests

Source: `fixture-studies/RESULTS.md` §2.5, §2.6, §3 (test logs in
`fixture-studies/logs/`), `custody/RESULTS.md` §4.

**Registration with the witness** (since build 3; real witness service in
the test process, fixtures with real keys; and the 20 multi-process runs):

- The witness registers a run or a continuation only when the request is
  signed with an enrollment key it was started with. Without that key every
  attempt was refused: 19 of 19 in the fixture tests (preemption of a run ID
  before and after the genuine registration, unsigned, signed with the
  attacker's own key or with the gateway's key ID over the attacker's
  signature; false continuations built from public facts; a continuation by
  a second enrolled gateway), and 200 of 200 in the multi-process runs (100
  probes of the evaluation harness and build 2's 100 registration probes
  sent unchanged). With the key, the witness's older rules still decide
  (build 2's answers 100 of 100).
- The genuine registration and folder stayed ANCHORED (6 of 6), and after a
  refused false continuation the genuine continuation was ANCHORED over 2
  segments.
- **Counterexample:** a continuation forged with the gateway's enrollment
  private key (fresh keys for every role, the grant copied from the public
  log) was accepted as VERIFIED and ANCHORED over 2 segments, and the
  genuine continuation was then refused. In the prototype the enrollment
  key is stored under the same user account as the gateway, so registration
  stops a process that cannot read that key, not an attacker who controls
  the account. ANCHORED shows that this key signed the registration, not who
  held it.
- The verifier accepts only a witness key given to it in advance, and the
  gateway pins the key of the first witness it uses (16 concurrent first
  pins: exactly 1 wins). A witness run status naming another continuation
  than the folder's fails `head.witness` (7 of 7). The run status v2 names
  the enrollment key (`enrollment_kid`); a status with that field removed,
  altered, or relabelled as v1 is refused (17 cases).

**Gateway clocks** (unit-level injection of the capability-registry and
delegation clocks; no OS clock changed):

- A step 30 s below the registry's last reading: REJECTED
  (`capability_refused`); nothing issued or sent.
- +61 s between issue and use (past the 60 s capability lifetime): REJECTED
  (`dispatch_refused`), 0 commits; +48 s: committed once.
- Expired grant revived, in process: the grant ends at +600 s; a payment at
  +900 s is denied (DEL-EXPIRED); rolled back to +0 s, still at or above the
  registry's floor, the next payment commits (a denied call never reads the
  registry clock, and the delegation window has no floor).
- Expired grant revived, across a restart: restarted on the same journal at
  +0 s, the restore ignores the journaled capability expiry (+500 s); a new
  payment commits under the expired grant.
- The audit writer clamps a backward step to the previous entry's time, so a
  revival leaves no trace in the log.

**Verifier time windows** (fixture witness key): a witness status fetched
exactly 2 min (or 2 min minus 1 s) after signing is accepted (4/4); 2 min
plus 1 ns or plus 1 s is refused (4/4, `head.witness`). A backward step of 1
s or 1 ns inside a segment fails `chain.time`; +48 h fails
`delegation.window`. Accepted, as documented gaps: a witness clock 1 min
behind the head time; a restart segment starting 1 min before the previous
one ends; a recorded issue-to-execution gap longer than the capability
lifetime (the verifier never compares entry times with a capability's
validity). Entry times are compared only within a segment and with the
grant's window, never across segments or with the witness's clock. Since
build 3 each signed status reply is dated against its operation (no later
than 5 s after its entry and, for a commit, no earlier than 5 s before its
capability), assuming the provider, the issuer and the log writer read one
clock.

## S14. Testing the verifier, the coverage map, the partial Python verifier

Sources: `robustness/RESULTS.md`, `robustness/coverage_map.md`,
`heldout/RESULTS.md`, `docs/paper/data/revision/robustness/HELDOUT_OPERATORS.md`,
`subset-corpus/RESULTS.md`, `docs/paper/artifact/SUBSET_VERIFIER.md`. The
data files keep the older names (refusal sites, refusal conditions, post-hoc
tests, held-out operators, subset verifier; S10).

**Fuzzing:** 33,639,381 inputs in 5 runs of 120 s with 12 workers over three
targets (`FuzzParseLogLine`, `FuzzCOSE`, `FuzzRunFiles`), 0 crashes or failed
properties; replaying 1,391 generated inputs and 150 seeds also gave 0
failures. Properties: no panic; a line accepted only in the recorder's exact
form; input that does not parse never verifies; any single-file replacement
yields a report. They check crashes, errors and exact-form parsing, not
semantic acceptance.

**Deleting the lines that make a check fail:** 150 lines (build 2: 142; 9
added and 1 removed in build 3: the capability `cnf` signer, the status date
and order, the pending commit, and five earlier-segment key lines); full
suite 150/150. Without the 16 tests added late (`docs/demo/VERIFIER_CHECKS.md`
§6: 4 written after undetected deletions were first seen, 3 written with
build 2's new lines and 9 with build 3's): 63/150 = 0.420. With build 2's
seven-test pattern 71/150; with build 1's four-test pattern 73/150. Six of
the 63 come from the real-key tests, written after build 2's list of
undetected deletions existed; without them 57/150. Of the 8 lines new in
build 3, 7 are not detected without the late tests, by design (their tests
were written with the code). 6 of 38 checks have no line detected without
the late tests (`artifact.effect_digest`, `artifact.effect_readable`,
`delegation.window`, `files.run_id`, `head.signature`,
`op.requires_validation`). This is a regression suite for these deletions,
not adequacy against arbitrary verifier bugs.

**Failure conditions:** 336 lines (150 fail, 9 warn, 177 problem); 29 (8.6
%) never reached by tests or fuzzing, all of them problem lines, so each
only adds a reason to a check that other inputs do make fail. None of the 25
conditions added in build 3 is among them; 18 of build 2's 47 are now
reached. Statement coverage 3,935/4,295 (91.6 %); without the 16 tests added
late 87.5 %.

**Coverage map per check** (`robustness/coverage_map.md`, `coverage_map.csv`,
`coverage_map.json`; one row per check ID): the lines that make each check
fail, which deletions the full suite and the suite without the late tests
detect, the check's failure conditions (fail / warn / problem) and how many
were never reached, and the tests that cover it. Every one of the 38 checks
has at least one such line, and every line is reached and detected by the
full suite. The 29 never-reached conditions sit in 11 checks:
`op.receipts_bound` 6 (4 of them the adapter receipt attached to a
RECONCILED entry), `policy.replay` 6, `files.continuity` 5,
`delegation.grant` 3, `delegation.scope` 2, `op.outcome_resolved` 2, and one
each in `chain.links`, `op.requires_policy`, `op.approval_bound`,
`op.capability_bound` and `delegation.accounting`. For the checks build 3
changed: `op.outcome_resolved` 22 of 25 conditions reached (the 2 never
reached are older than build 3), `op.capability_bound` 18 of 19,
`head.witness` 26 of 31 by tests (fuzzing reaches the other 5),
`keys.anchor` 12 of 12, `provider.matches_audit` 7 of 7.

**Mutants of three other kinds**, defined and fixed before any of them ran
(commit `103a438`; an addendum fixed before the campaign adds reporting rows
and a third variant; no kind or place changed):

- **delete a reported problem** (`append`): delete one finding line, or a
  group of findings;
- **shift a comparison boundary by one** (`boundary`): swap `<` and `<=`,
  `>` and `>=`;
- **make a hash or byte comparison always equal** (`equality`).

| test set | delete a problem | shift a boundary | force equal | all |
|---|---|---|---|---|
| full suite | 106/177 | 60/132 | 46/76 | 212/385 = 0.551 |
| without the 24 tests written after lists of undetected mutants existed (the rule fixed in advance) | 59/177 | 53/132 | 18/76 | 130/385 = 0.338 |
| without the 4 tests added late in build 1 | 102/177 | 59/132 | 35/76 | 196/385 = 0.509 |
| build 1's verifier and its own suite (`f01d1c9`), without the 4 | 52/153 | 43/117 | 16/66 | 111/336 = 0.330 |

The full-suite score rose from build 2's 144/358 only because of the 20
tests written after build 2's lists were published (44 more mutants
detected, each with one of those tests as the first failing test) and the
new code (+29 places, -2). Without those 20 tests, on the 356 places builds
2 and 3 share, the result is exactly build 2's (125 detected). Build 1's
verifier and suite gave the same 111/336 in builds 2 and 3, mutant for
mutant. Undetected with the full suite, 173: 46 never executed, 48 whose
evaluation the coverage data cannot show, 14 equivalent (judged by hand, one
person, one pass), 65 executed but not detected (typically a signed field
that the tests change only together with another field). No test was
written or changed in response to any result of this campaign. 0 build
errors and 0 timeouts.

**Partial Python verifier** (by the same authors, ported from the
specification and the Go sources, sharing no code): parts of 15 of the 38
checks: `files.present`, `keys.hash`, `files.run_record`,
`chain.entry_hash`, `chain.signature`, `chain.links`, `head.signature`,
`head.matches`, `keys.anchor`, `head.anchor`, `artifact.signature`
(capabilities and adapter receipts only), `op.requires_policy`,
`op.capability_bound`, `op.receipts_bound`, `policy.snapshot_bound`. It
skips policy replay, key validity, the build-3 rules and the delegation,
provider, outcome, approval, single-use, restart and witness evidence (its
own crashes are reported as `verifier.error`). Set of folders: 2 clean + 16
tamper-lab + 56 mutant folders, each under 4 anchor conditions = 296
verifications; its manifest SHA-256 (`d0400304...046e7c`) was recorded
outside the set before any Python run. Results: 296/296 agree;
binding-relevant folders 42/42 (Go FAILED 26, accepted 16); the same 6 pairs
changed by binding; the frozen `agentgate-verify` reproduces 148/148
bound-design verifications. Its expectations are the Go verifier's outcomes
on our edit engine's mutants, so agreement shows a faithful port, not
independent confirmation. No folder of the set touches a reconciled
operation, so agreement says nothing about the build-3 rules.

## S15. Separate key holders: what is implemented and what is future work

The paper's binding result needs separate holders of the audit, issuer and
adapter keys. The prototype keeps all of them in one process on one machine
under one user account; the provider and witness are separate processes,
not separate key holders.

**Implemented in build 3, on one OS user account:**

- **Registration with an enrollment key.** The witness is started with the
  gateway's enrollment public key (`-enroll-key`) and registers a run, or a
  continuation, only when the request is signed with that key; a
  first-come registration no longer anchors anyone (S13).
- **A fixed witness key.** The gateway pins the key of the first witness it
  uses, and the verifier accepts only a witness key given to it in advance.
- **Limit.** The enrollment key is stored under the same user account as
  the gateway, so any process of that account can register like the
  gateway (S13, counterexample).

**Future work, not built or measured:**

- **Accounts.** Three local accounts besides the gateway's: `witness` (runs
  `agentgate-witness` and holds its key), `provider` (runs
  `agentgate-provider`) and `auditor` (runs `agentgate-verify`, holds the
  anchors and fetches the live witness status). None is an administrator.
  The enrollment key would be held by the organization, not by the gateway's
  account.
- **Key folders.** One folder per account for its key store, with
  inherited permissions removed and read access for that account only. A
  test would check each denial (the gateway account opening the witness key
  file must fail).
- **Attach by URL.** The demo starts the provider and the witness itself.
  The deployment needs a mode that attaches to an already-running provider
  and witness by URL, so that their accounts, not the gateway's, own them.
- **Split signing.** The audit, issuer and adapter keys (and the delegation
  key) stay in the one gateway process unless signing is split into
  separate services. Until then binding's gain without replay (from A to
  A+I+X_op on the receipt path) is a modeled benefit of that architecture,
  not a property the prototype provides. An adapter-signed reconciliation
  record and an authenticated provider status endpoint are separate
  future-work items.
- **Administrators.** An administrator of the machine can read every key
  regardless of permissions, so separate accounts separate ordinary
  accounts, not administrators; separate hosts would be needed for that.

## S16. Real-key tests

Source: `fixture-studies/RESULTS.md` §2.1-§2.4, `fixture-studies/round4_summary.json`,
`fixture-studies/signed_fields.csv`, `fixture-studies/lifecycle_histories.csv`
and the log `fixture-studies/logs/s7-round4.gotest.log`; how to run them:
`README.md`, "Real-key tests".

**What and when.** Test code in commit `8a30fd4`, the commit of build 3: the
fixture helper `internal/auditverify/fixture/held.go` and three test files.
They were first run on build 2's sources (2026-10-19) and rerun on build 3;
their output is line for line the same except the field edits that build
3's new checks now detect. They are not compiled into any of the six
programs; the 241 repository files they share with the frozen programs are
hash-equal to the build-3 manifest (`fixture-studies/build-manifest.txt`).
Fixtures only: synthetic, in process, no gateway program, no OS process, no
clock; all keys held in one process.

**Signing safety.** Only `fixture.ResignHeld` signs, with the fixture's own
keys derived in memory from a fixed label. Before computing or writing
anything it refuses a folder whose `keys.json` lists a key that is not the
fixture's key of that role, a folder with any signed record or provider
journal receipt naming a foreign key, and a key set without the audit key;
it writes only when nothing failed (asserted: a refused call leaves the five
evidence files unchanged). On an unedited fixture it changes no byte (both
fixture modes). `fixture.RestoreUnheld` signs nothing. No key is read from
or written to disk, nothing exports a key, and no command or program
re-signs a run folder.

**Method.** Each mutant comes from the simulation's edit engine
(`internal/evalattack`) and is verified twice: REAL, a copy re-signed with
exactly the roles held (for example the financial adapter key alone), with
no simulation; SIM, the unsigned mutant under the simulation's role groups
(A, I, ADAPTER = all adapter keys, P). Where every broken signature belongs
to a held role (or to a role the simulation does not assume), REAL and SIM
must agree exactly: verdict, assurance level, failing checks and finding
counts. The attacker of RB and LRR leaves every record of a role it does not
hold exactly as genuinely signed and re-signs the rest; no signature check
fails there, so the failing checks are binding evidence.

| test | fixture cases | fixture results (4 settings x 3 anchors) | result |
|---|---|---|---|
| RS `TestRound4RealSignaturesAgreeWithSimulation` | 34: M1 binding chain (strip-/invent-flag x 2 designs x A, A+I, A+Xf, A+I+Xf), M2 full-verifier forger (forge-restate, A+I+X and A+I+Xf), M3 partial adapter, M4 provider key | 408 (888 verifications) | exact agreement 336/336; the 72 results of 6 partial-adapter cases bracketed 72/72 by the simulation without ADAPTER, while the simulation with ADAPTER accepts 40 of them and REAL 0 (it overstates a one-adapter-key attacker); REAL accepted 96; head anchor 136/136 |
| RB `TestRound4RationalAttackerBinding` | 20 cases with unheld records left untouched | 240 (494) | exact 240/240; no signature check failing; REAL accepted 24 (all unbound M1 without replay); head anchor 80/80; each of the 14 detected cases VERIFIED once `op.requires_policy`, `op.capability_bound` and `op.receipts_bound` are off |
| LR `TestRound4LifecycleRealVsSimulation` | 35 (convert, downgrade, confirm, each also with every other execution converted, after strip-flag, invent-flag or change-rules) | 420 (840) | exact 420/420; REAL accepted 120, none with a head anchor |
| LRR `TestRound4LifecycleRationalAttacker` | 13 lifecycle cases with unheld records left untouched | 156 (325) | exact 156/156; no signature check failing; head anchor 52/52; with the binding checks off 4 VERIFIED, 9 still fail one provider-side check |
| LH `TestRound4LifecycleHistories` | 15 histories (full verifier, keys anchor) | 30 verifications | 12 detected, 3 accepted and reported; the same with replay off (15/15) |
| NC `TestRound4NoCapabilityReclassifiedInPlace` | a denial restated with A | 4 settings | detected by `policy.replay` in full and nsb; accepted as `audit_only` in no-replay and nrns |
| SF `TestRound4ValidlySignedInconsistentFields` | 62 single-field edits | 62 (full, keys anchor) | 45 detected, 17 accepted (S11) |

**What the paper takes from them.** (1) Wherever the simulation can
represent the key set, real keys and the simulation gave the same verdict,
assurance level and failing checks in all 1,196 results compared (44
audit-key results of `TestSimulationAgreesWithRealAuditKeyResigning` + 336
RS + 240 RB + 420 LR + 156 LRR; 33 of the cases leave unheld records
untouched). (2) Without replay, the bound design's receipt-path threshold
is A+I+X_op: A, A+I and A+Xf are each detected by the binding checks alone,
A+I+Xf passes a payment edit and A+I+Xm a message edit; the unbound design
needs A. (3) Under the full verifier the snapshot forger needs every adapter
key whose receipt stays in the log (X_all). (4) On the reconciliation path
A+I with a signed status reply suffices in both designs and every setting;
A alone is detected. (5) A head anchor detected every rewrite. (6) The
simulation's single adapter role overstates an attacker holding one adapter
key, so its A+I+X results are an upper bound for that attacker.

**Limits.** The attacker who leaves unheld records untouched is one choice
of evidence per case, not a search. The fixture has no document operation,
so the document adapter key was never used; nor were the approval key and
replacement keys with a new run ID. These are assertions on chosen cases,
not attack rates. They do not show separate key holders or the behavior of
a production provider.

## S17. Versions and counting

The paper's "Versions and counting" paragraph in full: every value that
differs between builds, with its build, unit and denominator, cause and
file. The same table is in `EXPECTED_TABLES.md` ("Version crosswalk, builds
1-3"); the source is `RESULTS_BUILD3.md` §3.

Causes: *new code* (verifier, witness or build code changed), *changed tests* (tests added or changed), *counting rule* (a changed pattern, unit or summary statistic), *new measurement* (the value moved without a code, test or rule change, for example machine state), *correction* (an earlier number or wording was wrong).

| build | date | source | identified by |
|---|---|---|---|
| build 1 | 2026-10-08 | five binaries; compiled files equal commit `2d32506` | manifest SHA-256 `188f83bd...121e` (1,809 entries) |
| build 2 | 2026-10-10 | six binaries from commit `86643d7` (working tree, not reproducible) | manifest SHA-256 `841a7c6f...b658` (1,868 entries) |
| build 3 | 2026-10-20 | six reproducible binaries from `git archive 8a30fd4` | manifest SHA-256 `0c436fc9...6968eb` (1,870 entries) |

| quantity | unit and denominator | build 1 | build 2 | build 3 (paper) | cause | file and field (build 3) |
|---|---|---|---|---|---|---|
| changed by binding, full verifier | attacks, strongest attacker, the same in 10/10 repetitions; 336 per setting = 168 without + 168 with a head anchor | 0/336 | 0/336 (0/168 without a head anchor) | 0/336 (0/168; 0/168 with a head anchor) | none: all 51,840 result rows equal in the three builds; printing the 168 half is a counting rule | `compromise/flips_by_anchor.csv` |
| changed by binding, no replay | as above | 12/336 | 12/336 (12/168 without, 0/168 with) | 12/336 (12/168 without, 0/168 with) | none; the same 12 attacks (6 pairs x 2 anchor conditions) | same |
| changed by binding, no snapshot check | as above | 8/336 | 8/336 (8/168) | 8/336 (8/168) | none | same |
| detections per design | attacks, of 336 and of each 168 | 313/313, 313/305, 295/283 | same | same | none | `compromise/strongest.csv` |
| lines that make a check fail, detected by the full suite | lines (one deletion mutant each) | 139/139 | 142/142 | 150/150 | new code: 3 lines in build 2; 9 added and 1 removed in build 3 | `robustness/kill_score_full.json` |
| the same without the tests added late | lines; the pattern is named | 51/139 (4-test pattern) | 56/142 (7-test); 58/142 (4-test) | 63/150 (16-test); 71/150 (7-test); 73/150 (4-test) | counting rule (4 -> 7 -> 16 tests), changed tests, new code | `robustness/kill_score_without_posthoc*.json` |
| failure conditions never reached | fail, warn and problem lines; reached by the full suite or any fuzz input | 44/299 | 47/313 (142 fail, 7 warn, 164 problem) | 29/336 (150 fail, 9 warn, 177 problem) | new code (+14, then +25 conditions), changed tests, new measurement (fuzz variation) | `robustness/refusal_conditions.json` |
| statement coverage | verifier statements, full suite | 89.9 % | 90.6 % (3,703/4,085) | 91.6 % (3,935/4,295) | new code, changed tests | `robustness/coverage_summary.json` |
| fuzz inputs | executions, 3 targets, 5 runs x 120 s | 40,542,369 | 34,178,449 | 33,639,381 | new measurement (loaded machine; not comparable) | `robustness/fuzz_summary.json` |
| checks | documented check IDs | 38 | 38 | 38 | none | `robustness/check_counts.json` |
| mutants of three other kinds, full suite | mutants; detected / all, build errors and timeouts left out (0) | not run | 144/358 = 0.402 | 212/385 = 0.551 | changed tests (44 more detected by the 20 tests written after build 2's lists were published), new code (+29, -2 places) | `heldout/heldout_summary.json` `v1_full` |
| the same without the tests written after lists of undetected mutants existed | as above | not run | 127/358 (without 4) | 130/385 (without 24; v2d) | counting rule (the 20 newer tests also left out) and new code; on the 356 places builds 2 and 3 share, exactly build 2's result (125 detected) | `heldout_summary.json` `v2_without_posthoc4`, `v2d_without_posthoc4_new20` |
| build 1's verifier and its own suite | as above, without the 4 | 111/336 (measured in build 2) | 111/336 | 111/336 | none (identical on all 336 mutants) | `heldout_summary.json` `v3_f01d1c9` |
| signing and flushing the audit log | ms per call, paired median, 500 trials, block 95 % CI | 11.40 [11.35, 11.47] (R3) | 11.29 [11.19, 11.43] (R2) | 11.77 [11.53, 11.95] (R2) | new measurement: no code on the timed path changed; build 3: Defender platform update, more background CPU, more drive slowdowns (ten runs of the same build-3 binary: 11.27-12.03) | `baseline/analysis.json` |
| checking / total / journal / flagging | as above | 3.32 / 14.69 / 3.20 / -0.27 | 3.18 / 14.46 / 3.43 / -0.07 | 3.14 / 14.95 / 3.77 / 0.22 | new measurement | same |
| throughput from 4 clients on | calls/s, pooled median of 15 cells (R1-R5 x 4, 8, 16 clients) | 94.3 (per client count 94.2-94.4) | 92.5 | 88.2 | new measurement; disk 96 % -> 97.4 % -> 97.5 % full; build 1's text quoted per-client-count medians | `baseline/analysis.json`; `baseline/comparison-builds.csv` |
| Little's law at 16 clients | ms, R2 | -- | printed 173 / 170 (mixed runs) -> 171.8 / 169.6 | 172.6 / 170.3 | correction (build 2), new measurement (build 3) | `baseline/analysis.json`, `baseline.json` |
| one audit append | ms, mean of the quoted stage run | -- | 1.70 (run2) | 1.75 (run1) | new measurement (byte-identical test binary) | `baseline/stagecost/run1/stagecost.json` |
| witness update per call | ms, run3 means | -- | 2.4 | 2.2 | new measurement | `baseline/stagecost/run3/witnesspush.json` |
| re-dispatch in the process-kill tests | test runs | -- | printed 0 of 235 -> 0 of 195 | 0 of 195 | correction (unit) | `killsuite/results.json` |
| unflagged harmful requests | harmful requests | 17/44 | 17/44 = 13/40 + 4 | 17/44 = 13/40 + 4 | none (misuse identical in all builds); both sets printed | `misuse/misuse.csv` |
| flag lost after kills | flagged commits | 20 of 40 in 190 test runs (earlier build) | 0 of 45 in 195 | 0 of 45 in 195 | new code (bug fixes before build 2) | `killsuite/results.json` |
| validly signed field edits accepted | single-field edits, real keys | -- | 18/59 | 17/62 | new code (`cnf` check, status date: 4 edits now detected) and changed tests (+3 edits) | `fixture-studies/signed_fields.csv` |
| status reply dated 2027 | fixture, A + status | accepted | accepted | detected (FAILED 4/4) | new code | `fixture-studies/lifecycle.csv` |
| first registration with the witness | unsigned registrations | anchored | anchored | refused (200/200; 19/19) | new code | `custody/repeats_summary.json`; `fixture-studies/registration_enrollment_cases.csv` |
| operations with a capability and no outcome reported without a warning | operations | -- | 10 | 0 (reported unresolved; warning in 100 of 365 folders) | new code | `killsuite/RESULTS.md` §5 |
| journal-failure answers | operations; REJECTED answers | -- | 5; 10, then one commit each | the same, with the chronology (scope operation, then the stored answer with scope call) | explained (new measurement of the chronology) | `killsuite/journal_chronology.md` |
| real-key agreement | results where the simulation can represent the key set | -- | 1,152 (written after the build-2 freeze) | 1,196 (44 + 1,152) | changed tests (part of build 3's commit) | `fixture-studies/RESULTS.md` §2.1 |
| oracle agreement | labelled results, full verifier | 514/560; 540/560 | same | same | none | `compromise/oracle_agreement.csv` |
| replacement keys | edit-design pairs | 8/14 none, 14/14 with an anchor | same | same | none | `compromise/replacement_keys.csv` |
| multi-process runs | rollback, keyless edits, head_fresh, run_complete | as build 2 | 20 runs; 140/140; 180/180 | same; plus 200/200 registrations refused | new code (registration) | `custody/` |

**Per cause.** *Counting:* the 0, 8 and 12 changed outcomes of 336 all lie
among the 168 attacks without a head anchor, because a head anchor detected
the rest; printing both halves changed no count. *New code (build 1 -> 2):*
the flag in recovery records and stored answers, the two bug fixes, three
new lines that make a check fail, the process-kill tests
(`../build2/RESULTS_BUILD2.md` §0.3). *New code (build 2 -> 3):* the status
date and order rules, unresolved operations reported, the capability `cnf`
check, the earlier-segment keys rule, registration with the witness and run
status v2, the reproducible build (`RESULTS_BUILD3.md` §0.3, ten numbered
changes). *Changed tests:* tests added for the real-key study and for the
build-3 checks detect and reach more of the old lines. *New measurement:*
costs and throughput come from separate sessions as the disk filled and the
virus scanner changed; the timed code did not change. *Correction:* two
build-2 values first mixed runs or units (Little's law; re-dispatches).
