#!/usr/bin/env python3
"""Build the anonymous, reproducible archive of AgentGate.

    python docs/paper/artifact/build_artifact.py --scratch DIR --identifying TERMS.txt
        [--build-data DIR] [--scratch-hint PATH] [--samples-from DIR] [--crash-sample DIR] [--out ZIP]

The evaluated build is the data folder --build-data (default: the newest
docs/paper/data/build<N>/ with a build-manifest.txt). It must lie under
docs/paper/data, so that the archive carries the manifest the binaries are
compared with; its commit (the manifest's `HEAD` hash) is the one
TEST_FILES_SHA256.txt compares test files with, and
docs/paper/artifact/loc_<folder name>.csv, when it exists, is shipped next to
loc_build2.csv.

Steps (all offline):

 1. stage the Go source closure of the six binaries (demo, verifier,
    provider, witness, evaluation harness and OS-level kill suite; plus the
    refusal-mutation tool, the verifier test fixture, the test-vector
    generator and the subset corpus generator), determined with `go list
    -deps`; test files that need archived packages outside the closure are
    left out;
 2. stage the specifications (docs/demo: CONTRACTS, VERIFIER_CHECKS,
    FIELD_CHECK_MAP, GLOSSARY, ...), the oracle, the raw data and scripts
    (docs/paper/data, including the evaluated build's data folder and its
    build-manifest.txt), the artifact files (docs/paper/artifact: README,
    EXPECTED_TABLES, SCHEMAS, ORACLE_FREEZE with oracle/post_freeze_diffs,
    SUPPLEMENTARY, HONESTY_SWEEP, the subset verifier, quick_check.py, the
    moved Algorithm 1), the kill suite's README and scripts/demo.*,
    replacing absolute local paths and the machine name in unsigned text
    files; refuse to continue if the staged copy of the manifest records
    another reproducible build than the original; write TEST_FILES_SHA256.txt
    (every test file and test-only source, by SHA-256, and whether it equals
    the evaluated build's commit's copy or was added after it); refuse to
    continue if a file the paper's post-freeze real-signature evidence needs
    (REQUIRED_IN_ARCHIVE: the fixture helper, the three real-signature test
    files, ROUND4_SIGNED_ATTACKS.md and ADDED_AFTER_FREEZE.md) is missing or
    was dropped;
 3. vendor the Go modules (`go mod vendor`, from the local module cache) so
    the archive builds without network access;
 4. build the six binaries from the staged tree unchanged, reproducibly
    (vendor mode, an empty module cache, CGO_ENABLED=0, GOENV=off, target
    windows/amd64 (GOAMD64=v1), `go build -trimpath -buildvcs=false
    -ldflags=-buildid=`; when the evaluated build's manifest records a
    reproducible build, exactly its flags and environment), compare their
    SHA-256 with that manifest and stop unless the six built binaries are
    exactly the six it lists, byte for byte (a manifest without a
    reproducible build, such as build 2's, is reported as not comparable; one
    that says `reproducible build: yes` with a malformed record stops the
    build), and write BINARIES_SHA256.txt (the hashes a reviewer's rebuild
    must give, `sha256sum -c` format) and BUILD_CHECK.txt (the build command,
    the manifest's path and SHA-256 in the archive, and the comparison's
    result);
    generate sample evidence bundles with these binaries (or, with
    --samples-from, reuse bundles only if their binaries_sha256.txt equals
    this build's BINARIES_SHA256.txt): run the demo
    self-test with `-host-label review-host`
    (the signed audit entries and run.json name the host; the label replaces
    the machine name) in flag mode with the provider and witness processes
    (clean run, its restart continuation segment, tamper lab, witness
    anchors), in human-approval mode, in deny mode and in the unbound-flags
    ablation; optionally copy one restart schedule of the crash experiment
    (--crash-sample, a folder written by `agentgate-eval -host-label
    review-host crash`, two segments and the operation journal); record the
    verifier's output for each bundle and anchor condition, and the
    binaries' hashes (samples/binaries_sha256.txt);
 5. write provenance_files.csv (git history: code from before the
    2026-10-01 handover vs code written after it) and the summary table in
    PROVENANCE.md;
 6. refuse to continue if any term of the --identifying file (author names,
    e-mail user parts, institution; kept outside the archive), the local user
    or machine name, or an absolute home path is left outside vendor/, or if
    any private signing key (a key file of the provider or witness process,
    PEM private key, the removed experiment key-export format) or key-export
    code is in the archive;
 7. write SHA256SUMS.txt and the zip, and print the zip's SHA-256 (full,
    and the 16-hex prefix the paper prints).

The environment variables GO (go binary) and GOMODCACHE (module cache for
the vendoring step) may be set; defaults are the repository's offline
toolchain and cache.
"""

import argparse
import csv
import getpass
import hashlib
import io
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tarfile
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import check_build_manifest  # noqa: E402  (same folder; standard library only)

ROOT_NAME = "AgentGate_AIR2026_artifact"
ROOTS = [
    "./cmd/agentgate-demo", "./cmd/agentgate-verify", "./cmd/agentgate-provider",
    "./cmd/agentgate-witness", "./cmd/agentgate-eval", "./cmd/agentgate-killsuite",
    "./internal/auditverify/tools/refusalmutation", "./internal/auditverify/fixture",
    "./docs/paper/artifact/vectorgen", "./docs/paper/artifact/corpusgen",
]
# The six binaries of every frozen build (build 2 and later: the manifest lists exactly these).
BINARIES = list(check_build_manifest.BINARIES)
# Files the paper's post-freeze, test-only real-signature evidence needs; the build
# stops if one is missing from the staged archive (for example a test dropped by
# compile_tests). They were written after the build-2 freeze and are not in the
# build-2 commit (with build 2 as the evaluated build, TEST_FILES_SHA256.txt marks
# them "added-after-freeze").
REQUIRED_IN_ARCHIVE = (
    "internal/auditverify/fixture/held.go",
    "internal/auditverify/round4_signed_attacks_test.go",
    "internal/auditverify/round4_signed_fields_test.go",
    "internal/auditverify/round4_lifecycle_test.go",
    "docs/paper/data/build2/fixture-studies/ROUND4_SIGNED_ATTACKS.md",
    "docs/paper/data/build2/fixture-studies/ADDED_AFTER_FREEZE.md",
)
# Packages that are compiled only into tests or tools, never into the six binaries.
TEST_ONLY_PREFIXES = ("internal/auditverify/fixture/", "internal/auditverify/tools/",
                      "docs/paper/artifact/vectorgen/", "docs/paper/artifact/corpusgen/")
# Repository-level test inputs that tests of the included (inherited) packages read.
EXTRA_TEST_DATA = ["test-vectors", "schemas", "testdata/academic-local-key-manifest-v1",
                   "testdata/reconciliation-v3-parser-v1", "testdata/webauthn-client-data.json"]
# Test files of included packages that inspect archived code outside this archive.
EXCLUDED_TESTS = {
    "internal/capability/prepared_final_tx_owner_release_test.go": "runs `go list ./cmd/gateway`, an archived prototype command",
    "internal/dbgrant/manifest_test.go": "reads the source files of archived packages (`internal/policy`, `internal/runtimecomponents`)",
    "internal/adapters/tail_v5_private_integration_test.go": "scans the whole repository's source and expects call sites in archived packages",
    "internal/evidence/tail_recovery_v5_test.go": "scans the whole repository's source and expects call sites in archived packages",
}
# Files of docs/paper/artifact/ copied into the archive (vectorgen/ comes with the source closure).
ARTIFACT_FILES = ("test_vectors.json", "check_vectors.py", "check_build_manifest.py", "build_artifact.py", "README.md", "PROVENANCE.md",
                  "subset_verifier.py", "SUBSET_VERIFIER.md", "EXPECTED_TABLES.md", "SCHEMAS.md", "ORACLE_FREEZE.md",
                  "SUPPLEMENTARY.md", "HONESTY_SWEEP.md", "quick_check.py", "algorithm_mediate.tex", "loc_build2.csv",
                  "regenerate_tables.py", "REPRODUCIBILITY.md", "test_artifact_scripts.py", "VERSION", "CHANGELOG.md")
# The reproducible build (docs/paper/artifact/REPRODUCIBILITY.md): with these flags and
# this environment (and GOENV=off, which check_build_manifest.build_env always adds),
# the binaries depend only on the source, the Go version and the target, not on the
# folder, the machine or the build cache. A manifest that records a reproducible build
# (`reproducible build: yes`) supplies its own flags and environment instead.
REPRODUCIBLE_FLAGS = ["-trimpath", "-buildvcs=false", "-ldflags=-buildid="]
REPRODUCIBLE_ENV = {"CGO_ENABLED": "0", "GOFLAGS": "-mod=vendor", "GOPROXY": "off", "GOTOOLCHAIN": "local", "GOWORK": "off",
                    "GOOS": "windows", "GOARCH": "amd64", "GOAMD64": "v1"}
# Folders of docs/paper/artifact/ copied whole (diffs of the verifier and edit engine after the oracle freeze).
ARTIFACT_DIRS = ("oracle/post_freeze_diffs",)
# Single documents outside docs/ that the archive README and the paper cite.
EXTRA_DOCS = ("cmd/agentgate-killsuite/README.md",)
CODEX_LAST_COMMIT = "9b45b50"   # last commit of the original (pre-handover) history, 6b8c3c8..9b45b50
HANDOVER_SNAPSHOT = "298cf42"   # snapshot of the pre-handover working tree, 2026-10-01
TEXT_SUFFIXES = {".json", ".csv", ".md", ".txt", ".log", ".py", ".sh", ".ps1", ".tsv", ".jsonl", ".sha256", ".go", ".mod", ".sum", ".js", ".css", ".html", ".svg", ".sql", ".tex", ".diff"}
WITHHELD = {
    "docs/paper/data/revision/concurrency/previous-build/2026-10-07/n32/evidence-r22":
        "Withheld from the anonymous archive: this is the signed evidence of the one\n"
        "deviating repetition of the superseded 2026-10-07 concurrency run (n32, repetition\n"
        "22, cross-tool-reuse). Its signed audit entries and run.json record the name of the\n"
        "machine that ran the experiment (that run did not use -host-label), and they\n"
        "cannot be edited without breaking the signatures. Every call, status and timing of\n"
        "that repetition is in ../concurrency.json, and the analysis outputs in ../../analysis/\n"
        "(order-work-*.txt, lease.txt) were computed from this folder.\n",
}
# Terms that must not appear in the archive (case-insensitive) come from the file
# given with --identifying (names, e-mail user parts, institution; one per line;
# keep that file outside the archive), plus the local user and host names.
GENERIC_PATH = re.compile(r"(?i)(?:\b[a-z]:(?:\\\\|\\|/)+users(?:\\\\|\\|/)+[^\\/<\s\"']+|/home/[a-z0-9_.-]+|/Users/[A-Za-z0-9_.-]+)")


def log(*args):
    print("[artifact]", *args, flush=True)


def run(cmd, cwd, env, check=True, capture=True):
    result = subprocess.run(cmd, cwd=cwd, env=env, capture_output=capture, text=True, encoding="utf-8", errors="replace")
    if check and result.returncode != 0:
        sys.stderr.write(result.stdout or "")
        sys.stderr.write(result.stderr or "")
        raise SystemExit("command failed (%d): %s" % (result.returncode, " ".join(cmd)))
    return result


def go_env(repo, mod_mode, modcache=None):
    env = dict(os.environ)
    env["GOPROXY"] = "off"
    env["GOTOOLCHAIN"] = "local"
    env["GOFLAGS"] = "-mod=" + mod_mode
    env["GOMODCACHE"] = modcache or os.environ.get("GOMODCACHE") or str(repo / ".tools/go-host-cache-20260916/mod")
    env.pop("GOWORK", None)
    return env


def go_binary(repo):
    return os.environ.get("GO") or str(repo / ".tools/go-1.26.6/bin/go.exe")


def go_list(repo, go, env, patterns):
    out = run([go, "list", "-deps", "-json"] + patterns, repo, env).stdout
    decoder, index, packages = json.JSONDecoder(), 0, []
    while index < len(out):
        while index < len(out) and out[index].isspace():
            index += 1
        if index >= len(out):
            break
        obj, index = decoder.raw_decode(out, index)
        packages.append(obj)
    return packages


IMPORT_RE = re.compile(r'"(agentgate/[^"]+)"')


def imports_of(path):
    text = path.read_text(encoding="utf-8", errors="replace")
    head = text.split("\nfunc ", 1)[0]
    return set(IMPORT_RE.findall(head))


# --- 1. source closure -----------------------------------------------------------------

def stage_sources(repo, stage, go, env):
    packages = [p for p in go_list(repo, go, env, ROOTS) if (p.get("Module") or {}).get("Main")]
    in_closure = {p["ImportPath"] for p in packages}
    copied, withheld_tests = [], []
    for p in packages:
        pdir = Path(p["Dir"])
        rel = pdir.relative_to(repo)
        names = []
        for key in ("GoFiles", "CgoFiles", "IgnoredGoFiles", "SFiles", "HFiles", "EmbedFiles", "TestEmbedFiles", "XTestEmbedFiles"):
            names += p.get(key) or []
        tests = (p.get("TestGoFiles") or []) + (p.get("XTestGoFiles") or [])
        tests += [n for n in (p.get("IgnoredGoFiles") or []) if n.endswith("_test.go")]
        names = [n for n in names if not n.endswith("_test.go")]
        for name in sorted(set(tests)):
            relname = str(rel / name).replace("\\", "/")
            outside = {i for i in imports_of(pdir / name) if i not in in_closure and not i.startswith(p["ImportPath"] + "/")}
            if outside:
                withheld_tests.append((relname, "imports " + ", ".join("`%s`" % i for i in sorted(outside))))
            elif relname in EXCLUDED_TESTS:
                withheld_tests.append((relname, EXCLUDED_TESTS[relname]))
            else:
                names.append(name)
        for name in sorted(set(names)):
            src = pdir / name
            dst = stage / rel / name
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            copied.append(str(rel / name).replace("\\", "/"))
        for key in ("EmbedPatterns", "TestEmbedPatterns", "XTestEmbedPatterns"):
            for pattern in p.get(key) or []:
                for match in pdir.glob(pattern):
                    sources = [match] if match.is_file() else [f for f in match.rglob("*") if f.is_file()]
                    for src in sources:
                        dst = stage / rel / src.relative_to(pdir)
                        dst.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(src, dst)
        testdata = pdir / "testdata"
        if testdata.is_dir():
            shutil.copytree(testdata, stage / rel / "testdata", dirs_exist_ok=True)
    extra = repo / "internal/auditverify/tools/refusalmutation/results"
    if extra.is_dir():
        shutil.copytree(extra, stage / "internal/auditverify/tools/refusalmutation/results", dirs_exist_ok=True)
    for name in EXTRA_TEST_DATA:
        src = repo / name
        if src.is_dir():
            shutil.copytree(src, stage / name, dirs_exist_ok=True)
            copied += [f.relative_to(repo).as_posix() for f in sorted(src.rglob("*")) if f.is_file()]
        else:
            (stage / name).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, stage / name)
            copied.append(name)
    for name in ("go.mod", "go.sum", "scripts/demo.ps1", "scripts/demo.sh"):
        (stage / name).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(repo / name, stage / name)
    return sorted(in_closure), copied, withheld_tests


def compile_tests(stage, go, env):
    """Drop staged test files that no longer compile (they use helpers from a left-out file)."""
    dropped = []
    for _ in range(8):
        result = run([go, "test", "-vet=off", "-count=1", "-run", "^$", "./..."], stage, env, check=False)
        if result.returncode == 0:
            return dropped
        text = (result.stdout or "") + (result.stderr or "")
        files = set(re.findall(r"^(\S+_test\.go):\d+:\d+:", text, re.M))
        if not files:
            sys.stderr.write(text)
            raise SystemExit("test compilation failed outside a test file")
        for name in sorted(files):
            path = stage / name.replace("\\", "/")
            if path.exists():
                path.unlink()
                dropped.append(path.relative_to(stage).as_posix())
    raise SystemExit("tests still do not compile after dropping")


# --- 2. documents and data ---------------------------------------------------------------

SEP = r"(?:\\\\|\\|/)+"   # one or more path separators, also JSON-escaped backslashes


def path_regex(path):
    """An absolute path in any separator style, plus the Git Bash /c/... form."""
    parts = [x for x in re.split(r"[\\/]+", str(path)) if x]
    if not parts:
        return None
    rest = SEP.join(re.escape(x) for x in parts[1:])
    alts = []
    if re.fullmatch(r"[A-Za-z]:", parts[0]):
        alts.append(re.escape(parts[0]) + SEP + rest)
        alts.append("/" + parts[0][0] + "/" + "/".join(re.escape(x) for x in parts[1:]))
    else:
        alts.append("/" + "/".join(re.escape(x) for x in parts))
    return re.compile("(?i)(?:" + "|".join(alts) + ")")


def build_replacements(repo, scratch_hint):
    reps = [(path_regex(repo), "<repo>")]
    if scratch_hint:
        reps.append((path_regex(Path(scratch_hint).resolve()), "<scratch>"))
    reps.append((path_regex(Path.home()), "<home>"))
    host = socket.gethostname()
    if host:
        reps.append((re.compile(re.escape(host), re.I), "review-host"))
    user = getpass.getuser()
    if user:
        reps.append((re.compile(r"(?<![0-9A-Za-z])" + re.escape(user) + r"(?![0-9A-Za-z])"), "<user>"))
    # Any other home folder path (e.g. one a runner already rewrote to
    # <home>\...) becomes <home> too, so no account folder name remains.
    reps.append((GENERIC_PATH, "<home>"))
    return [(p, r) for p, r in reps if p is not None]


def sanitize_text(data, replacements):
    text = data.decode("utf-8")
    for pattern, replacement in replacements:
        text = pattern.sub(replacement, text)
    return text.encode("utf-8")


def copy_tree_sanitized(src_root, dst_root, rel_base, replacements, report):
    for src in sorted(src_root.rglob("*")):
        if src.is_dir():
            continue
        rel = src.relative_to(rel_base).as_posix()
        if any(rel == w or rel.startswith(w + "/") for w in WITHHELD):
            continue
        dst = dst_root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        data = src.read_bytes()
        if src.suffix.lower() in TEXT_SUFFIXES:
            try:
                new = sanitize_text(data, replacements)
            except UnicodeDecodeError:
                new = data
            if new != data:
                report.append(rel)
            dst.write_bytes(new)
        elif src.name.endswith(".tar.gz"):
            dst.write_bytes(repack_tar(data))
            report.append(rel + " (tar owner names reset)")
        else:
            dst.write_bytes(data)
    for w, note in WITHHELD.items():
        if (rel_base / w).exists() and w.startswith(src_root.relative_to(rel_base).as_posix()):
            (dst_root / w).mkdir(parents=True, exist_ok=True)
            (dst_root / w / "WITHHELD.md").write_text(note, encoding="utf-8")


def repack_tar(data):
    src = tarfile.open(fileobj=io.BytesIO(data), mode="r:gz")
    out = io.BytesIO()
    with tarfile.open(fileobj=out, mode="w:gz", format=tarfile.PAX_FORMAT) as dst:
        for member in src.getmembers():
            member.uname, member.gname, member.uid, member.gid = "user", "user", 0, 0
            member.pax_headers = {}
            dst.addfile(member, src.extractfile(member) if member.isfile() else None)
    return out.getvalue()


def stage_documents(repo, stage, replacements, artifact_files=ARTIFACT_FILES):
    sanitized = []
    for src in sorted((repo / "docs/demo").glob("*.md")):
        dst = stage / "docs/demo" / src.name
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(sanitize_text(src.read_bytes(), replacements))
    copy_tree_sanitized(repo / "docs/paper/oracle", stage, repo, replacements, sanitized)
    copy_tree_sanitized(repo / "docs/paper/data", stage, repo, replacements, sanitized)
    artifact = repo / "docs/paper/artifact"
    for name in artifact_files:
        dst = stage / "docs/paper/artifact" / name
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(sanitize_text((artifact / name).read_bytes(), replacements))
    for folder in ARTIFACT_DIRS:
        copy_tree_sanitized(artifact / folder, stage, repo, replacements, sanitized)
    for name in EXTRA_DOCS:
        dst = stage / name
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(sanitize_text((repo / name).read_bytes(), replacements))
    shutil.copy2(artifact / "README.md", stage / "README.md")
    return sanitized


def write_test_hashes(repo, stage, commit, manifest_rel):
    """TEST_FILES_SHA256.txt: every test file and test-only source of the archive.

    They are not compiled into the six binaries, so the evaluated build's
    manifest (manifest_rel) does not list them; the paper says they are in the
    archive by SHA-256. The last column says whether the file equals its copy in
    the commit the evaluated build was built from (`commit`); files written
    after that commit say "added-after-freeze" (not in that commit) or
    "changed"."""
    at_build = git_tree(repo, commit)
    rows = []
    for path in sorted(p for p in stage.rglob("*") if p.is_file()):
        rel = path.relative_to(stage).as_posix()
        if rel.startswith("vendor/") or not rel.endswith(".go"):
            continue
        if not (rel.endswith("_test.go") or rel.startswith(TEST_ONLY_PREFIXES)):
            continue
        data = path.read_bytes()
        blob = hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()
        same = "same" if at_build.get(rel) == blob else ("changed" if rel in at_build else "added-after-freeze")
        rows.append("%s  %s  %s" % (hashlib.sha256(data).hexdigest(), rel, same))
    header = ["# Test files and test-only sources in this archive (SHA-256, path, compared with commit %s," % commit[:7],
              "# the commit of the evaluated build, %s)." % manifest_rel,
              "# None of them is compiled into the six binaries, so that manifest does not list them. Each",
              "# experiment that compiled tests records its test build in its own build-manifest.txt",
              "# (fixture-studies, robustness, heldout, subset-corpus, compromise, baseline).",
              "# same = byte-identical to that commit's file; changed = edited after it;",
              "# added-after-freeze = added after that commit, not in it (test-only; for the real-signature",
              "# tests written after the build-2 freeze: docs/paper/data/build2/fixture-studies/ADDED_AFTER_FREEZE.md)."]
    (stage / "TEST_FILES_SHA256.txt").write_text("\n".join(header + rows) + "\n", encoding="utf-8")
    return len(rows)


# --- 3. vendoring -------------------------------------------------------------------------

def vendor(stage, go, repo):
    env = go_env(repo, "mod")
    run([go, "mod", "vendor"], stage, env)
    empty = stage.parent / "empty-modcache"
    empty.mkdir(exist_ok=True)
    run([go, "build", "./..."], stage, go_env(repo, "vendor", str(empty)))


# --- 4. sample bundles --------------------------------------------------------------------

HOST_LABEL = "review-host"   # recorded as the host in the sample evidence (-host-label)


def recorded_build(manifest_text):
    """check_build_manifest.reproducible_build, stopping the archive build on a
    manifest that says `reproducible build: yes` with a malformed record."""
    try:
        return check_build_manifest.reproducible_build(manifest_text)
    except check_build_manifest.ManifestError as err:
        raise SystemExit("the evaluated build's manifest says `reproducible build: yes` but its record is malformed: %s" % err)


def evaluated_build(repo, build_data):
    """(data folder, manifest path, manifest text) of the evaluated build.

    The folder must lie under docs/paper/data (so that the archive carries its
    manifest) and hold build-manifest.txt."""
    data_root = (repo / "docs/paper/data").resolve()
    folder = Path(build_data).resolve() if build_data else check_build_manifest.default_manifest().parent.resolve()
    if not folder.is_relative_to(data_root) or folder == data_root:
        raise SystemExit("--build-data must be a build folder under docs/paper/data (the archive must carry the manifest "
                         "its binaries are compared with): %s" % folder)
    manifest = folder / "build-manifest.txt"
    if not manifest.is_file():
        raise SystemExit("no build-manifest.txt in the evaluated build's data folder %s" % folder)
    return folder, manifest, manifest.read_text(encoding="utf-8")


def build_commit(manifest_text):
    """The commit a frozen build was built from: the manifest's `HEAD <hash>`."""
    m = re.search(r"^repository: .*?\bHEAD ([0-9a-f]{7,40})\b", manifest_text, re.M)
    if not m:
        raise SystemExit("the evaluated build's manifest names no commit (`repository: ... HEAD <hash>`)")
    return m.group(1)


def artifact_files(repo, build_name):
    """ARTIFACT_FILES plus the evaluated build's code-line CSV (Supplementary S1), when it exists."""
    loc = "loc_%s.csv" % build_name
    if loc not in ARTIFACT_FILES and (repo / "docs/paper/artifact" / loc).is_file():
        return ARTIFACT_FILES + (loc,)
    return ARTIFACT_FILES


def staged_manifest(stage, repo, manifest, original_text):
    """The archive's copy of the evaluated build's manifest (path in the archive,
    text). Stops if it is missing or records another reproducible build than
    the original (the path replacement must not touch the build record)."""
    rel = manifest.resolve().relative_to(repo.resolve()).as_posix()
    copy = stage / rel
    if not copy.is_file():
        raise SystemExit("the evaluated build's manifest is missing from the staged archive: " + rel)
    text = copy.read_text(encoding="utf-8")
    if recorded_build(text) != recorded_build(original_text):
        raise SystemExit("the archive's copy of %s records another build than the original" % rel)
    return rel, text


def build_sample_binaries(stage, scratch, go, repo, manifest_text):
    """Build the six binaries from the staged tree as it is (no overlay),
    reproducibly: the evaluated build's recorded flags and environment when its
    manifest records a reproducible build, else REPRODUCIBLE_FLAGS/_ENV."""
    bin_dir = scratch / "sample-bin"
    if bin_dir.exists():
        shutil.rmtree(bin_dir)
    bin_dir.mkdir(parents=True)
    recorded = recorded_build(manifest_text)
    flags, environment = (recorded[0], recorded[1]) if recorded else (REPRODUCIBLE_FLAGS, REPRODUCIBLE_ENV)
    env = check_build_manifest.build_env(environment, modcache=stage.parent / "empty-modcache")
    command = [go, "build"] + flags + ["-o", str(bin_dir) + os.sep] + ["./cmd/" + b for b in BINARIES]
    run(command, stage, env)
    shown = "%s go build %s -o bin/ %s" % (" ".join("%s=%s" % kv for kv in sorted(dict(environment, GOENV="off").items())),
                                           " ".join(flags), " ".join("./cmd/" + b for b in BINARIES))
    return bin_dir, shown


def compare_with_manifest(bin_dir, manifest_text, stage, manifest_label="the evaluated build's manifest", command=""):
    """Compare the binaries built from the staged tree with the evaluated
    build's manifest; write BINARIES_SHA256.txt and BUILD_CHECK.txt. Returns a
    one-line summary. Stops unless the built files are exactly the six the
    manifest lists and each has the listed SHA-256."""
    built = sorted(p for p in bin_dir.iterdir() if p.is_file())
    lines = ["%s  bin/%s" % (check_build_manifest.sha256(p), p.name) for p in built]
    (stage / "BINARIES_SHA256.txt").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    recorded = recorded_build(manifest_text)
    if recorded is None:
        summary = "the evaluated build's manifest records no reproducible build; its binaries cannot be compared with this rebuild"
    else:
        listed = {Path(name).name for name, _ in recorded[2]}
        names = {p.name for p in built}
        if not built or names != listed:
            raise SystemExit("the binaries built from the staged archive are not the ones the evaluated build's manifest lists "
                             "(built: %s; listed: %s)" % (", ".join(sorted(names)) or "none", ", ".join(sorted(listed))))
        rows = check_build_manifest.compare_binaries(recorded[2], bin_dir)
        bad = [(name, status) for name, status, _ in rows if status != "same"]
        if bad:
            raise SystemExit("binaries built from the staged archive differ from the evaluated build's manifest: %s"
                             % ", ".join("%s %s" % b for b in bad))
        summary = "%d of %d binaries built from the staged archive are byte-identical to the evaluated build" % (len(rows), len(rows))
    record = ["Binaries built by build_artifact.py from this archive's own files (hashes: BINARIES_SHA256.txt).",
              "build command: %s" % (command or "(not recorded)"),
              "compared with: %s" % manifest_label,
              "result: %s" % summary]
    (stage / "BUILD_CHECK.txt").write_text("\n".join(record) + "\n", encoding="utf-8", newline="\n")
    return summary


SAMPLE_BINARIES = "binaries_sha256.txt"   # in samples/: the hashes of the binaries that produced the bundles


def check_reused_samples(samples_from, stage):
    """--samples-from: reuse sample bundles only if the binaries that produced
    them (their binaries_sha256.txt) are the ones built from this archive
    (BINARIES_SHA256.txt), so that the archive README's statement holds."""
    record = Path(samples_from) / SAMPLE_BINARIES
    if not record.is_file():
        raise SystemExit("--samples-from %s: the bundles record no binaries (%s); regenerate them with this build"
                         % (samples_from, SAMPLE_BINARIES))
    if record.read_bytes() != (stage / "BINARIES_SHA256.txt").read_bytes():
        raise SystemExit("--samples-from %s: the bundles were produced by other binaries than the ones built from this archive "
                         "(%s differs from BINARIES_SHA256.txt); regenerate them" % (samples_from, SAMPLE_BINARIES))


def exe(bin_dir, name):
    path = bin_dir / name
    return str(path.with_suffix(".exe")) if os.name == "nt" else str(path)


def run_folders(runs_dir):
    """The run folder a self-test wrote, and the continuation segment its
    restart check opened next to it (run.json `continues`), if any."""
    primary, segments = [], []
    for p in sorted(runs_dir.iterdir()):
        if not (p.is_dir() and p.name.startswith("run-")):
            continue
        record = json.loads((p / "run.json").read_text(encoding="utf-8"))
        (segments if record.get("continues") else primary).append(p)
    if len(primary) != 1 or len(segments) > 1:
        raise SystemExit("expected one run folder and at most one continuation segment in %s, found %d and %d"
                         % (runs_dir, len(primary), len(segments)))
    return primary[0], (segments[0] if segments else None)


ANCHOR_NOTE = ("trust anchors as the demo prints them (keys fingerprint at startup, final head when it stops), "
               "read here from the folder's own keys.json and head.json; in a real deployment they are held outside the run folder")


def folder_anchors(folder, note=ANCHOR_NOTE):
    keys_sha = hashlib.sha256((folder / "keys.json").read_bytes()).hexdigest()
    head = json.loads((folder / "head.json").read_text(encoding="utf-8"))
    return {"run_id": folder.name, "keys_sha256": keys_sha, "head_seq": head["seq"], "head_entry_hash": head["entry_hash"], "note": note}


RUN_FILES = ("audit.jsonl", "head.json", "keys.json", "run.json", "provider-journal.json", "operations.jsonl")


def copy_run_files(src, dst):
    """Copy only the evidence files of one run folder (never key stores)."""
    dst.mkdir(parents=True, exist_ok=True)
    for name in RUN_FILES:
        if (src / name).is_file():
            shutil.copy2(src / name, dst / name)


def generate_samples(bin_dir, scratch, samples, replacements, crash_sample=None):
    work = scratch / "sample-work"
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True)
    if samples.exists():
        shutil.rmtree(samples)
    samples.mkdir(parents=True)
    runs = [
        ("flag-run", ["-selftest", "-external-provider", "-witness"], "autonomous flag mode, provider and witness as separate processes"),
        ("human-run", ["-selftest", "-escalation", "human"], "human-approval mode (approvals given by the self-test's scripted reviewer)"),
        ("deny-run", ["-selftest", "-escalation", "deny"], "deny mode (escalated actions are refused)"),
        ("unbound-flags-run", ["-selftest", "-unbound-flags"], "flag mode in the flag-binding ablation (decision values do not commit flag, mode or fired rules)"),
    ]
    summary = []
    for name, args, what in runs:
        runs_dir = work / name
        result = run([exe(bin_dir, "agentgate-demo")] + args + ["-host-label", HOST_LABEL, "-runs-dir", str(runs_dir)], work, dict(os.environ), check=False)
        console = (result.stdout or "") + (result.stderr or "")
        folder, segment = run_folders(runs_dir)
        dst = samples / name
        copy_run_files(folder, dst)
        (dst / "selftest-console.txt").write_bytes(sanitize_text(console.encode("utf-8"), replacements))
        report = folder / "selftest-report.json"
        if report.exists():
            (dst / "selftest-report.json").write_bytes(sanitize_text(report.read_bytes(), replacements))
        anchors = folder_anchors(folder)
        anchor_dst = samples / (name + "-anchors")
        anchor_dst.mkdir(exist_ok=True)
        witness_dir = runs_dir / "custody" / "anchors" / folder.name
        if witness_dir.is_dir():
            # Only the witness's cosigned head and its PUBLIC key; the
            # witness's and provider's key stores under custody/ stay out.
            for fname in ("witness-head.json", "witness-key.txt"):
                if (witness_dir / fname).is_file():
                    anchor_dst.joinpath(fname).write_bytes((witness_dir / fname).read_bytes())
            anchors["witness_files"] = sorted(f.name for f in anchor_dst.iterdir() if f.name.startswith("witness-"))
        (anchor_dst / "anchors.json").write_text(json.dumps(anchors, indent=2) + "\n", encoding="utf-8")
        tamper = runs_dir / "tamper-lab" / folder.name
        if name == "flag-run" and tamper.is_dir():
            for attack in sorted(p for p in tamper.iterdir() if p.is_dir()):
                copy_run_files(attack, samples / "flag-run-tamper-lab" / attack.name)
        if name == "flag-run" and segment is not None:
            # The restart check's continuation segment refers to the run by its
            # folder name (run.json "continues".dir, signed), so both keep
            # their original names here.
            restart = samples / "flag-run-restart"
            copy_run_files(folder, restart / folder.name)
            copy_run_files(segment, restart / segment.name)
            seg_anchors = folder_anchors(segment, "anchors of the newest segment, read from its own keys.json and head.json; "
                                         "the earlier segment is anchored through the signed `continues` record")
            seg_anchors["segments"] = [folder.name, segment.name]
            seg_anchor_dst = samples / "flag-run-restart-anchors"
            seg_anchor_dst.mkdir(exist_ok=True)
            seg_witness_dir = runs_dir / "custody" / "anchors" / segment.name
            if seg_witness_dir.is_dir():
                # The segment's cosigned head as the witness returned it after
                # the restart check registered the continuation, and the
                # witness PUBLIC key; never the witness's key store.
                for fname in ("witness-head.json", "witness-key.txt"):
                    if (seg_witness_dir / fname).is_file():
                        seg_anchor_dst.joinpath(fname).write_bytes((seg_witness_dir / fname).read_bytes())
                seg_anchors["witness_files"] = sorted(f.name for f in seg_anchor_dst.iterdir() if f.name.startswith("witness-"))
            (seg_anchor_dst / "anchors.json").write_text(json.dumps(seg_anchors, indent=2) + "\n", encoding="utf-8")
        summary.append({"bundle": name, "mode": what, "selftest_exit": result.returncode,
                        "selftest_summary": next((l.strip() for l in console.splitlines() if "SELF-TEST" in l), ""),
                        "restart_segment": segment.name if segment is not None else ""})
    if crash_sample:
        src = Path(crash_sample)
        segs = sorted(p for p in src.iterdir() if p.is_dir() and p.name.startswith("segment-"))
        if len(segs) != 2:
            raise SystemExit("--crash-sample must be a restart schedule folder with segment-1 and segment-2: " + str(src))
        dst = samples / "crash-restart"
        for seg in segs:
            copy_run_files(seg, dst / seg.name)
        if (src / "operations.jsonl").is_file():
            shutil.copy2(src / "operations.jsonl", dst / "operations.jsonl")
        (samples / "crash-restart-anchors").mkdir(exist_ok=True)
        pins = {seg.name: folder_anchors(seg, "read from the segment's own keys.json and head.json (the crash harness pins the same values in memory)") for seg in segs}
        pins["schedule"] = src.name
        (samples / "crash-restart-anchors" / "anchors.json").write_text(json.dumps(pins, indent=2) + "\n", encoding="utf-8")
        summary.append({"bundle": "crash-restart", "mode": "one restart schedule of the crash experiment (%s): two evidence segments across a gateway restart on the operation journal" % src.name,
                        "selftest_exit": "", "selftest_summary": "copied from `agentgate-eval -host-label review-host crash` evidence", "restart_segment": "segment-2"})
    return summary


def verify_samples(bin_dir, samples, replacements):
    verify = exe(bin_dir, "agentgate-verify")
    expected = samples / "expected"
    expected.mkdir(exist_ok=True)
    rows = []

    def one(label, folder, extra):
        result = run([verify, "--json", "--workers", "1"] + extra + [folder], samples, dict(os.environ), check=False)
        out = result.stdout
        (expected / (label + ".json")).write_bytes(sanitize_text(out.encode("utf-8"), replacements))
        text = run([verify, "--workers", "1"] + extra + [folder], samples, dict(os.environ), check=False).stdout
        (expected / (label + ".txt")).write_bytes(sanitize_text(text.encode("utf-8"), replacements))
        try:
            report = json.loads(out)
            verdict, assurance = report.get("verdict"), report.get("assurance")
            failed = sorted({f.get("id") for f in report.get("failures") or [] if isinstance(f, dict)})
        except json.JSONDecodeError:
            verdict, assurance, failed = "ERROR", "", []
        rows.append({"label": label, "folder": folder, "anchors": " ".join(extra) or "none", "exit": result.returncode,
                     "verdict": verdict, "assurance": assurance, "failed_checks": failed})

    for name in ("flag-run", "human-run", "deny-run", "unbound-flags-run"):
        anchors = json.loads((samples / (name + "-anchors") / "anchors.json").read_text(encoding="utf-8"))
        pins = ["--expect-keys", anchors["keys_sha256"], "--expect-head", anchors["head_entry_hash"]]
        one(name + "--no-anchors", name, [])
        one(name + "--keys-and-head-pinned", name, pins)
        if name == "flag-run":
            one(name + "--keys-pinned-only", name, pins[:2])
            witness_head = samples / "flag-run-anchors" / "witness-head.json"
            witness_key = samples / "flag-run-anchors" / "witness-key.txt"
            if witness_head.exists() and witness_key.exists():
                key = witness_key.read_text(encoding="utf-8").strip().split()[-1]
                one(name + "--witness-anchor", name, ["--witness", "flag-run-anchors/witness-head.json", "--witness-key", key])
            for attack in sorted(p.name for p in (samples / "flag-run-tamper-lab").iterdir() if p.is_dir()):
                folder = "flag-run-tamper-lab/" + attack
                one("tamper-" + attack + "--no-anchors", folder, [])
                one("tamper-" + attack + "--keys-and-head-pinned", folder, pins)
    restart_anchors = samples / "flag-run-restart-anchors" / "anchors.json"
    if restart_anchors.exists():
        a = json.loads(restart_anchors.read_text(encoding="utf-8"))
        first, newest = a["segments"]
        seg_pins = ["--expect-keys", a["keys_sha256"], "--expect-head", a["head_entry_hash"]]
        one("flag-run-restart--no-anchors", "flag-run-restart/" + newest, [])
        one("flag-run-restart--keys-and-head-pinned", "flag-run-restart/" + newest, seg_pins)
        one("flag-run-restart--earlier-run-head-pinned", "flag-run-restart/" + newest,
            ["--expect-head", json.loads((samples / "flag-run-anchors" / "anchors.json").read_text(encoding="utf-8"))["head_entry_hash"]])
        seg_witness_head = samples / "flag-run-restart-anchors" / "witness-head.json"
        seg_witness_key = samples / "flag-run-restart-anchors" / "witness-key.txt"
        if seg_witness_head.exists() and seg_witness_key.exists():
            key = seg_witness_key.read_text(encoding="utf-8").strip().split()[-1]
            one("flag-run-restart--witness-anchor", "flag-run-restart/" + newest,
                ["--witness", "flag-run-restart-anchors/witness-head.json", "--witness-key", key])
    crash_anchors = samples / "crash-restart-anchors" / "anchors.json"
    if crash_anchors.exists():
        a = json.loads(crash_anchors.read_text(encoding="utf-8"))
        for seg in ("segment-1", "segment-2"):
            p = a[seg]
            one("crash-restart-" + seg + "--no-anchors", "crash-restart/" + seg, [])
            one("crash-restart-" + seg + "--keys-and-head-pinned", "crash-restart/" + seg,
                ["--expect-keys", p["keys_sha256"], "--expect-head", p["head_entry_hash"]])
    (expected / "summary.json").write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")
    return rows


def write_samples_readme(samples, runs, rows):
    lines = [
        "# Sample evidence bundles",
        "",
        "Generated by `docs/paper/artifact/build_artifact.py` from the source in this archive,",
        "built unchanged. The demo self-test ran with `-host-label review-host`, so the signed",
        "audit entries and run.json record `review-host` instead of the machine's name. Each",
        "bundle holds the evidence files of the run folder the demo self-test wrote",
        "(`audit.jsonl`, `head.json`, `keys.json`, `run.json`, `provider-journal.json`,",
        "`operations.jsonl`), plus its `selftest-report.json` and console output (local paths",
        "replaced). No private key is included: the provider's and witness's own key stores",
        "stay in the build's scratch folder, and the demo has no key-export option.",
        "`%s` lists the SHA-256 of the binaries that produced the bundles; it equals the" % SAMPLE_BINARIES,
        "archive's `BINARIES_SHA256.txt` (the archive builder refuses reused bundles made by other binaries).",
        "",
        "| bundle | what it is | self-test |",
        "|---|---|---|",
    ]
    for r in runs:
        status = ("exit %s: %s" % (r["selftest_exit"], r["selftest_summary"] or "(no summary line)")) if r["selftest_exit"] != "" else r["selftest_summary"]
        lines.append("| `%s/` | %s | %s |" % (r["bundle"], r["mode"], status))
    lines += [
        "| `flag-run-tamper-lab/` | the tamper lab's eight attacked copies of `flag-run` (edit a value, delete an entry, re-hash the chain without the audit key, truncate, swap a provider receipt, hide an operation, forge an approval, coherent rollback to an earlier genuine checkpoint) | |",
        "| `flag-run-restart/` | `flag-run` and the continuation segment its restart check wrote after rebuilding the gateway on the operation journal; both keep their original folder names because the segment's signed run.json refers to the earlier folder by name (`continues.dir`). Verify the newest folder: the verifier walks both segments as one run | |",
        "| `<bundle>-anchors/` | `anchors.json`: the keys fingerprint (SHA-256 of keys.json at start) and the final head (seq, entry hash), as the demo prints them; for `flag-run` also the witness's cosigned head (`witness-head.json`) and the witness public key (`witness-key.txt`); for the restart bundles the newest segment's anchors, and for `flag-run-restart` also the segment's cosigned head as the witness returned it after the continuation was registered (`witness-head.json`, `witness-key.txt`); a saved witness head file cannot show that a later segment was withheld (only `--witness-url` against the live witness can) | |",
        "",
        "None of the tamper-lab attacks uses a signing key. Validly re-signed mutations are",
        "studied by `agentgate-eval compromise` as a key-compromise **simulation** (the",
        "mutation engine edits content and recomputes hashes, the verifier accepts the",
        "signatures of the attacker's key roles without checking them); its mutants are",
        "generated in memory and not stored, so none is included here. The",
        "`unbound-flags-run` bundle is evidence of the ablated design: the default verifier",
        "refuses it (`op.requires_policy`), and only the evaluation option `UnboundFlags` (no",
        "CLI flag) accepts it.",
        "",
        "## Expected verifier results",
        "",
        "Run from this folder, e.g. `agentgate-verify --expect-keys K --expect-head H flag-run`.",
        "Full outputs (text and JSON) are in `expected/<label>.txt|json`; `expected/summary.json`",
        "lists them all.",
        "",
        "| label | folder | anchors | exit | verdict | assurance | failing checks |",
        "|---|---|---|---|---|---|---|",
    ]
    for row in rows:
        anchors = row["anchors"]
        if "--expect-head" in anchors and "--expect-keys" in anchors:
            anchors = "keys + head pinned"
        elif "--expect-head" in anchors:
            anchors = "head pinned (the earlier run's final head)" if "earlier-run" in row["label"] else "head pinned"
        else:
            anchors = "keys pinned" if "--expect-keys" in anchors else ("witness head" if "--witness" in anchors else "none")
        lines.append("| %s | `%s` | %s | %s | %s | %s | %s |" % (row["label"], row["folder"], anchors, row["exit"], row["verdict"], row["assurance"],
                                                          ", ".join(row["failed_checks"]) or "-"))
    (samples / "README.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


# --- 5. provenance ----------------------------------------------------------------------------

def git_tree(repo, rev):
    out = run(["git", "ls-tree", "-r", rev], repo, dict(os.environ)).stdout
    tree = {}
    for line in out.splitlines():
        meta, path = line.split("\t", 1)
        tree[path] = meta.split()[2]
    return tree


def provenance(repo, stage, copied_sources, artifact_files=ARTIFACT_FILES):
    codex = git_tree(repo, CODEX_LAST_COMMIT)
    snap = git_tree(repo, HANDOVER_SNAPSHOT)
    head = git_tree(repo, "HEAD")
    paths = [p for p in copied_sources if not p.startswith("vendor/")]
    paths += [p.relative_to(stage).as_posix() for p in (stage / "docs/demo").glob("*.md")]
    paths += [p.relative_to(stage).as_posix() for p in (stage / "docs/paper/oracle").rglob("*") if p.is_file()]
    paths += ["go.mod", "go.sum", "scripts/demo.ps1", "scripts/demo.sh"]
    paths += ["docs/paper/artifact/" + n for n in artifact_files]
    paths += list(EXTRA_DOCS)
    paths = sorted(set(paths))
    proc = subprocess.run(["git", "hash-object", "--stdin-paths"], cwd=repo, input="\n".join(paths) + "\n", capture_output=True, text=True, check=True)
    blobs = dict(zip(paths, proc.stdout.split()))
    rows = []
    for path in paths:
        wt = blobs[path]
        if path in codex:
            origin = "pre-handover (commits 6b8c3c8..9b45b50, 2026-08-16..09-01)"
        elif path in snap:
            origin = "pre-handover (uncommitted work snapshotted in 298cf42, 2026-10-01)"
        else:
            origin = "post-handover (2026-10-01 or later)"
        if path in snap:
            if wt == snap[path]:
                status = "unchanged since the handover"
            elif head.get(path) == wt:
                status = "modified after the handover (committed)"
            elif head.get(path) == snap[path]:
                status = "modified after the handover (uncommitted revision work)"
            else:
                status = "modified after the handover (committed and uncommitted)"
        else:
            if path not in head:
                status = "new (uncommitted revision work)"
            elif head[path] == wt:
                status = "new (committed)"
            else:
                status = "new (committed, then changed in uncommitted revision work)"
        lines = (repo / path).read_bytes().count(b"\n")
        rows.append({"path": path, "origin": origin, "status": status, "lines": lines})
    return rows


def provenance_table(rows):
    def component(path):
        parts = path.split("/")
        if parts[0] == "internal" and path.endswith(".sql"):
            return "internal/*/migrations (SQL embedded by internal/migrationassets.go)"
        if parts[0] in ("cmd", "internal") and len(parts) > 2:
            if parts[1] == "auditverify" and len(parts) > 3 and parts[2] in ("fixture", "tools"):
                return "/".join(parts[:3])
            return "/".join(parts[:2])
        if parts[0] == "internal":
            return "internal (root)"
        if parts[0] == "docs":
            return "/".join(parts[:3]) if len(parts) > 3 else "/".join(parts[:2])
        return parts[0]
    groups = {}
    for row in rows:
        key = component(row["path"])
        g = groups.setdefault(key, {"files": 0, "lines": 0, "pre_unchanged": 0, "pre_modified": 0, "new": 0,
                                    "lines_pre_unchanged": 0, "lines_pre_modified": 0, "lines_new": 0})
        g["files"] += 1
        g["lines"] += row["lines"]
        if row["origin"].startswith("pre"):
            kind = "pre_unchanged" if row["status"].startswith("unchanged") else "pre_modified"
        else:
            kind = "new"
        g[kind] += 1
        g["lines_" + kind] += row["lines"]
    out = ["| component | files | lines | pre-handover, unchanged (files / lines) | pre-handover, modified after (files / lines) | new after the handover (files / lines) |",
           "|---|---|---|---|---|---|"]
    total = {k: 0 for k in ("files", "lines", "pre_unchanged", "pre_modified", "new", "lines_pre_unchanged", "lines_pre_modified", "lines_new")}
    for key in sorted(groups):
        g = groups[key]
        for k in total:
            total[k] += g[k]
        out.append("| `%s` | %d | %d | %d / %d | %d / %d | %d / %d |" % (key, g["files"], g["lines"], g["pre_unchanged"], g["lines_pre_unchanged"],
                                                                      g["pre_modified"], g["lines_pre_modified"], g["new"], g["lines_new"]))
    out.append("| **total** | %d | %d | %d / %d | %d / %d | %d / %d |" % (total["files"], total["lines"], total["pre_unchanged"], total["lines_pre_unchanged"],
                                                                       total["pre_modified"], total["lines_pre_modified"], total["new"], total["lines_new"]))
    return "\n".join(out)


# --- 6. identifier scan ---------------------------------------------------------------------

ALNUM = set(b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")


def scan(stage, terms):
    """Problems: identifying terms or absolute home paths in the project's files.
    Third-party files under vendor/ are reported separately (maintainers' contact
    addresses, language tables) and do not stop the build."""
    problems, coincidences, third_party = [], [], []
    patterns = [(t, re.compile(re.escape(t.encode()), re.I)) for t in terms]
    for path in sorted(stage.rglob("*")):
        if not path.is_file():
            continue
        data = path.read_bytes()
        rel = path.relative_to(stage).as_posix()
        vendored = rel.startswith("vendor/")
        if not vendored:
            for m in GENERIC_PATH.finditer(data.decode("utf-8", "replace")):
                problems.append((rel, "absolute home path", m.group(0)))
        for word, pattern in patterns:
            for m in pattern.finditer(data):
                start, end = m.start(), m.end()
                # Embedded in the middle of a long run of letters and digits
                # (a hash, a key or a signature): a coincidence, not a name.
                left = start
                while left > 0 and data[left - 1] in ALNUM:
                    left -= 1
                right = end
                while right < len(data) and data[right] in ALNUM:
                    right += 1
                context = data[max(0, start - 30):end + 30].decode("utf-8", "replace").replace("\n", " ")
                embedded = left < start and right > end and right - left >= 16
                if embedded:
                    coincidences.append((rel, word, context))
                elif vendored:
                    third_party.append((rel, word, context))
                else:
                    problems.append((rel, word, context))
    return problems, coincidences, third_party


# Private signing keys must never enter the archive. Data and documents may not
# contain a key store of the provider or witness process (member
# "private_key_seed"), a PEM private key or the experiment key-export format
# that was removed on 2026-10-07 ("agentgate-experiment-keys"); Go sources may
# not contain the removed key-export code. The provider and witness sources
# that define their own key store format (they keep their key in their own
# directory) are expected and listed. The RFC 8032 test keys in
# test_vectors.json are published test vectors, not keys of any run.
# A key store holds the member with a value ("private_key_seed": "<base64>");
# a script that only names the member (the build-3 multi-process probe
# custody/scripts/enroll_sig.py reads the enrollment key a run created on the
# reader's machine and signs witness registration requests with it; it holds
# no key and re-signs no evidence) is listed, not refused.
KEY_DATA_MARKERS = [b"PRIVATE KEY-----", b"agentgate-experiment-keys"]
KEY_SEED_VALUE = re.compile(rb'"private_key_seed"\s*:\s*"[A-Za-z0-9+/=_-]{16,}"')
KEY_CODE_MARKERS = [b"agentgate-experiment-keys", b"ExportKeysFile", b"ExportKeysPath", b"-export-keys", b"export-keys"]


def scan_keys(stage):
    problems, key_store_sources = [], []
    for path in sorted(stage.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(stage).as_posix()
        if rel.startswith("vendor/"):
            continue
        data = path.read_bytes()
        if path.suffix == ".go":
            for marker in KEY_CODE_MARKERS:
                if marker in data:
                    problems.append((rel, marker.decode()))
            if b"private_key_seed" in data:
                key_store_sources.append(rel)
        elif rel != "docs/paper/artifact/build_artifact.py":
            for marker in KEY_DATA_MARKERS:
                if marker in data:
                    problems.append((rel, marker.decode()))
            if KEY_SEED_VALUE.search(data):
                problems.append((rel, "private_key_seed with a value (a key store)"))
            elif b"private_key_seed" in data:
                key_store_sources.append(rel)
        if path.name in ("provider-key.json", "witness-key.json"):
            problems.append((rel, "key store file"))
    return problems, key_store_sources


# --- 7. zip --------------------------------------------------------------------------------

def write_sums(stage):
    lines = []
    for path in sorted(p for p in stage.rglob("*") if p.is_file() and p.name != "SHA256SUMS.txt"):
        lines.append("%s  %s" % (hashlib.sha256(path.read_bytes()).hexdigest(), path.relative_to(stage).as_posix()))
    (stage / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    return len(lines)


def write_zip(stage, out):
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        out.unlink()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(p for p in stage.rglob("*") if p.is_file()):
            rel = ROOT_NAME + "/" + path.relative_to(stage).as_posix()
            info = zipfile.ZipInfo(rel, date_time=(2026, 10, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            mode = 0o755 if path.suffix in (".sh", ".py") else 0o644
            info.external_attr = (0o100000 | mode) << 16
            z.writestr(info, path.read_bytes(), compresslevel=9)


def main():
    repo = Path(__file__).resolve().parents[3]
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--scratch", required=True, help="work directory outside the repository")
    parser.add_argument("--out", default=str(repo / "output/artifact/AgentGate_AIR2026_artifact.zip"))
    parser.add_argument("--samples-from", help="reuse sample bundles generated by an earlier archive build (a samples/ folder); "
                        "refused unless its binaries_sha256.txt equals this build's BINARIES_SHA256.txt")
    parser.add_argument("--scratch-hint", default="", help="an absolute scratch path that appears in recorded data, replaced by <scratch>")
    parser.add_argument("--identifying", help="file of terms that must not appear in the archive (one per line; keep it outside the archive)")
    parser.add_argument("--build-data", help="data folder of the evaluated build under docs/paper/data, whose build-manifest.txt the rebuilt "
                        "binaries are compared with and whose commit TEST_FILES_SHA256.txt compares test files with "
                        "(default: the newest docs/paper/data/build<N>/)")
    parser.add_argument("--crash-sample", help="a restart schedule folder of the crash experiment (segment-1, segment-2, operations.jsonl) written with -host-label review-host, copied to samples/crash-restart")
    args = parser.parse_args()
    # The evaluated build first: a wrong --build-data stops the build before any work.
    build_dir, manifest, manifest_text = evaluated_build(repo, args.build_data)
    recorded_build(manifest_text)
    commit = build_commit(manifest_text)
    files = artifact_files(repo, build_dir.name)
    log("evaluated build: %s (commit %s; %s)" % (manifest.relative_to(repo).as_posix(), commit[:7],
                                                  "reproducible build recorded" if recorded_build(manifest_text) else "no reproducible build recorded"))
    scratch = Path(args.scratch).resolve()
    stage = scratch / "stage" / ROOT_NAME
    if stage.parent.exists():
        shutil.rmtree(stage.parent)
    stage.mkdir(parents=True)
    go = go_binary(repo)
    replacements = build_replacements(repo, args.scratch_hint or str(scratch.parent))

    log("1. source closure")
    closure, copied, withheld_tests = stage_sources(repo, stage, go, go_env(repo, "readonly"))
    log("   %d packages, %d files; %d test files left out (need archived packages)" % (len(closure), len(copied), len(withheld_tests)))
    log("2. documents and data")
    sanitized = stage_documents(repo, stage, replacements, files)
    log("   %d files had local paths or the machine name replaced" % len(sanitized))
    manifest_rel, staged_text = staged_manifest(stage, repo, manifest, manifest_text)
    manifest_label = "%s (SHA-256 of the archive's copy: %s)" % (manifest_rel, check_build_manifest.sha256(stage / manifest_rel))
    log("   evaluated build's manifest in the archive: %s" % manifest_label)
    log("3. vendoring")
    vendor(stage, go, repo)
    dropped = compile_tests(stage, go, go_env(repo, "vendor", str(stage.parent / "empty-modcache")))
    if dropped:
        log("   tests dropped because they no longer compile:", dropped)
    log("   %d test files and test-only sources listed in TEST_FILES_SHA256.txt (compared with commit %s)"
        % (write_test_hashes(repo, stage, commit, manifest_rel), commit[:7]))
    missing = [p for p in REQUIRED_IN_ARCHIVE if not (stage / p).is_file()]
    if missing:
        raise SystemExit("files of the post-freeze real-signature evidence are missing from the archive: " + ", ".join(missing))
    added = [l.split("  ")[1] for l in (stage / "TEST_FILES_SHA256.txt").read_text(encoding="utf-8").splitlines()
             if l.endswith("  added-after-freeze")]
    log("   post-freeze evidence staged (%d files); added after commit %s: %s" % (len(REQUIRED_IN_ARCHIVE), commit[:7], ", ".join(added) or "none"))
    log("4. reproducible build and sample bundles")
    bin_dir, build_command = build_sample_binaries(stage, scratch, go, repo, staged_text)
    log("   built from the staged tree: %s" % build_command)
    log("   %s; BINARIES_SHA256.txt and BUILD_CHECK.txt written" % compare_with_manifest(bin_dir, staged_text, stage, manifest_label, build_command))
    samples = stage / "samples"
    if args.samples_from:
        check_reused_samples(args.samples_from, stage)
        shutil.copytree(args.samples_from, samples)
        sample_rows = json.loads((samples / "expected/summary.json").read_text(encoding="utf-8"))
        runs = json.loads((samples / "runs.json").read_text(encoding="utf-8"))
    else:
        runs = generate_samples(bin_dir, scratch, samples, replacements, args.crash_sample)
        (samples / "runs.json").write_text(json.dumps(runs, indent=2) + "\n", encoding="utf-8")
        shutil.copy2(stage / "BINARIES_SHA256.txt", samples / SAMPLE_BINARIES)
        sample_rows = verify_samples(bin_dir, samples, replacements)
        write_samples_readme(samples, runs, sample_rows)
        if (scratch / "samples-last").exists():
            shutil.rmtree(scratch / "samples-last")
        shutil.copytree(samples, scratch / "samples-last")
    for r in runs:
        log("   %s: exit %s, %s" % (r["bundle"], r["selftest_exit"], r["selftest_summary"]))
    log("   %d verifier outputs recorded" % len(sample_rows))
    log("5. provenance")
    rows = provenance(repo, stage, copied, files)
    with open(stage / "provenance_files.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["path", "origin", "status", "lines"])
        writer.writeheader()
        writer.writerows(rows)
    provenance_md = (repo / "docs/paper/artifact/PROVENANCE.md").read_text(encoding="utf-8")
    table = provenance_table(rows)
    withheld_lines = ["- `%s` (%s)" % (p, reason) for p, reason in withheld_tests]
    withheld_lines += ["- `%s` (uses test helpers defined in one of the files above)" % p for p in dropped]
    withheld_text = "\n".join(withheld_lines) or "- none"
    provenance_md = provenance_md.replace("<!-- provenance-table -->", table).replace("<!-- withheld-tests -->", withheld_text)
    (stage / "PROVENANCE.md").write_text(provenance_md, encoding="utf-8")
    (stage / "docs/paper/artifact/PROVENANCE.md").write_text(provenance_md, encoding="utf-8")
    log("6. identifier scan")
    terms = [t.strip() for t in Path(args.identifying).read_text(encoding="utf-8").splitlines()
             if t.strip() and not t.startswith("#")] if args.identifying else []
    terms += [getpass.getuser(), socket.gethostname()]
    problems, coincidences, third_party = scan(stage, sorted({t for t in terms if t}))
    log("   %d terms checked; %d coincidences inside hashes or signatures; %d hits in vendored third-party files" % (len(set(terms)), len(coincidences), len(third_party)))
    for rel, word, context in third_party:
        log("   third-party (vendor):", rel, repr(context))
    if problems:
        for rel, word, context in problems:
            log("   IDENTIFYING:", rel, word, repr(context))
        raise SystemExit("identifying strings left in the archive; fix them first")
    key_problems, key_store_sources = scan_keys(stage)
    log("   private-key scan: %d problems; sources that define or read a key store format (no key inside): %s"
        % (len(key_problems), ", ".join(key_store_sources) or "none"))
    if key_problems:
        for rel, marker in key_problems:
            log("   PRIVATE KEY:", rel, marker)
        raise SystemExit("private key material or key-export code in the archive; fix it first")
    log("7. checksums and zip")
    count = write_sums(stage)
    write_zip(stage, Path(args.out))
    size = Path(args.out).stat().st_size
    log("   %d files, %s (%.1f MB)" % (count + 1, args.out, size / 1e6))
    digest = hashlib.sha256(Path(args.out).read_bytes()).hexdigest()
    # The archive cannot state its own digest (that would change it), so it goes
    # into a detached file next to the zip, the submission form and the paper.
    # LF line end, so that `sha256sum -c <zip>.sha256` reads it on every platform.
    with open(args.out + ".sha256", "w", encoding="utf-8", newline="\n") as f:
        f.write("%s  %s\n" % (digest, Path(args.out).name))
    log("   archive SHA-256 %s (paper prints the prefix %s); written to %s.sha256" % (digest, digest[:16], args.out))
    log("   take this digest only after the last document change; rebuild after every edit")


if __name__ == "__main__":
    main()
