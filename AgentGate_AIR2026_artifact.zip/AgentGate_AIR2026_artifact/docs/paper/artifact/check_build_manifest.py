#!/usr/bin/env python3
"""Compare this source tree, and optionally rebuilt or given binaries, with the
manifest of a frozen build (docs/paper/data/build<N>/build-manifest.txt).

    python docs/paper/artifact/check_build_manifest.py [MANIFEST] [--rebuild] [--bin DIR] [--work DIR]

MANIFEST defaults to the build-manifest.txt of the newest docs/paper/data/build<N>/
folder. Build 2's (docs/paper/data/build2/build-manifest.txt) is a copy of its
MANIFEST.txt (SHA-256 of the original:
841a7c6fd3c6ea5790692c7bb3be27e783e6ad803ef5adeb39d26b792534b658; the copy
replaces the repository path on line 3 by <repo>, so its own hash differs).
A manifest lists the SHA-256 of the six binaries and of every file compiled into
them (build 2: 256 module, 385 third-party, 1,221 standard-library files). Build
1's manifest is docs/paper/data/revision/baseline/source-manifest.txt (five
binaries). This script always re-hashes

  - the module's own files (paths relative to the archive root),
  - the third-party files, found under vendor/ (module path without its
    @version), or in $GOMODCACHE when there is no vendor/ folder,
  - the standard-library files, in `go env GOROOT`, only if `go version`
    reports the manifest's toolchain (go1.26.6); otherwise they are skipped.

Binaries. A manifest whose build was reproducible says so (`reproducible build:
yes`) and records the build flags and environment (`build flags:`, `build
environment:`, which must name the target GOOS and GOARCH); the binaries then
depend only on the source, the toolchain version and that target, not on the
folder, the machine or the build cache. Such a manifest must list exactly the
six binaries (BINARIES, with `.exe` when GOOS=windows), each once, as
`HEX *bin/NAME` or in the two-space `sha256sum` form `HEX  bin/NAME`; a
manifest that says `reproducible build: yes` but lacks any of this is refused
(RESULT: FAIL), never read as a shorter list.

  --rebuild  builds the binaries again from this tree with exactly the recorded
             flags and environment (vendor mode, an empty module cache, a new
             build cache and GOENV=off, so that no `go env -w` setting of the
             user applies, in a temporary folder) and compares their SHA-256
             with the manifest. In a tree without vendor/ (the repository) it
             first copies go.mod, go.sum and the source folders to the
             temporary folder and runs `go mod vendor` there from $GOMODCACHE.
  --bin DIR  compares the binaries in DIR (for example a frozen build's bin/)
             with the manifest.

A manifest without those lines (build 1, build 2: a plain `go build` inside the
repository, which embeds the build path and the version-control stamp) cannot
be compared with rebuilt binaries; the script says so and checks the sources
only. The environment variable GO names the go command (default: go on PATH).

Exit status 0 when every checked file and binary matches (the last line says
whether binaries were checked); 1 when a file or binary differs or is missing,
when the manifest's reproducible-build record is malformed, or when --rebuild
or --bin was asked for and could not be done (RESULT: INCOMPLETE: the go
command is not the manifest's toolchain, or the manifest records no
reproducible build); 2 on a usage error. Standard library only.
"""
import argparse
import hashlib
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
DEFAULT_TOOLCHAIN = "go1.26.6"
# The six binaries of a frozen build, in build order.
BINARIES = ("agentgate-demo", "agentgate-verify", "agentgate-provider", "agentgate-witness", "agentgate-eval",
            "agentgate-killsuite")
# One manifest entry: SHA-256, then ` *name` (binary mode) or `  name` (sha256sum text mode).
ENTRY_RE = re.compile(r"^([0-9a-fA-F]{64}) [ *](\S.*?)[ \t\r]*$", re.M)


class ManifestError(ValueError):
    """A manifest says `reproducible build: yes` but its record is incomplete or wrong."""


def entries(text):
    """[(sha256 in lower case, name)] of every hash line of a manifest."""
    return [(digest.lower(), name) for digest, name in ENTRY_RE.findall(text)]


def decode_module_path(path):
    """Module-cache case encoding: '!x' stands for 'X'."""
    return re.sub(r"!([a-z])", lambda m: m.group(1).upper(), path)


def go_command():
    return os.environ.get("GO") or "go"


def toolchain_of(text):
    m = re.search(r"^toolchain: .*?\b(go\d+\.\d+(?:\.\d+)?)\b", text, re.M)
    return m.group(1) if m else DEFAULT_TOOLCHAIN


def go_version():
    try:
        return subprocess.run([go_command(), "version"], capture_output=True, text=True, check=True).stdout.strip()
    except (OSError, subprocess.CalledProcessError) as err:
        return "no go command (%s)" % err


def goroot(toolchain):
    version = go_version()
    if (toolchain + " ") not in version:
        return None, "go version is not %s: %s" % (toolchain, version)
    root = subprocess.run([go_command(), "env", "GOROOT"], capture_output=True, text=True, check=True).stdout.strip()
    return Path(root), ""


def default_manifest():
    builds = []
    for d in (ROOT / "docs/paper/data").glob("build*"):
        m = re.fullmatch(r"build(\d+)", d.name)
        if m and (d / "build-manifest.txt").is_file():
            builds.append((int(m.group(1)), d / "build-manifest.txt"))
    return max(builds)[1] if builds else ROOT / "docs/paper/data/build2/build-manifest.txt"


# --- the reproducible build recorded in a manifest -----------------------------------------

def expected_binaries(environment):
    """The published names a reproducible build must list for its target."""
    suffix = ".exe" if environment.get("GOOS") == "windows" else ""
    return ["bin/" + b + suffix for b in BINARIES]


def reproducible_build(text):
    """(flags, environment, binaries) of a reproducible manifest; None for a
    manifest that does not say `reproducible build: yes` (build 1, build 2).

    binaries: [(published name like 'bin/agentgate-demo.exe', SHA-256)], in
    BINARIES order. Raises ManifestError when the manifest says `reproducible
    build: yes` but lacks the flags, the environment or its target (GOOS,
    GOARCH), or does not list exactly the six expected binaries, each once."""
    if not re.search(r"^reproducible build: yes\s*$", text, re.M):
        return None
    flags = re.search(r"^build flags: (.+)$", text, re.M)
    env = re.search(r"^build environment: (.+)$", text, re.M)
    if not flags or not flags.group(1).split():
        raise ManifestError("no `build flags:` line")
    if not env:
        raise ManifestError("no `build environment:` line")
    environment = dict(re.findall(r"\b([A-Z][A-Z0-9_]*)=(\S+)", env.group(1).split("(")[0]))
    missing = [k for k in ("GOOS", "GOARCH") if k not in environment]
    if missing:
        raise ManifestError("the build environment does not name the target (%s)" % ", ".join(missing))
    listed = [(name, digest) for digest, name in entries(text) if name.startswith("bin/")]
    names = [name for name, _ in listed]
    want = expected_binaries(environment)
    duplicates = sorted({n for n in names if names.count(n) > 1})
    if duplicates:
        raise ManifestError("binaries listed more than once: %s" % ", ".join(duplicates))
    if set(names) != set(want):
        missing, extra = sorted(set(want) - set(names)), sorted(set(names) - set(want))
        raise ManifestError("the manifest lists %d binaries, not the six expected for GOOS=%s (missing: %s; unexpected: %s)"
                            % (len(names), environment["GOOS"], ", ".join(missing) or "none", ", ".join(extra) or "none"))
    digests = dict(listed)
    return flags.group(1).split(), environment, [(name, digests[name]) for name in want]


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def compare_binaries(expected, bin_dir):
    """[(name, 'same'|'differs'|'missing', actual)] for the manifest's binaries."""
    rows = []
    for name, digest in expected:
        path = Path(bin_dir) / Path(name).name
        if not path.is_file():
            rows.append((name, "missing", ""))
            continue
        actual = sha256(path)
        rows.append((name, "same" if actual == digest else "differs", actual))
    return rows


def source_dirs(text):
    """Top-level folders of the module files the manifest lists."""
    dirs = set()
    for _, name in entries(text):
        if not name.startswith(("bin/", "$GOROOT/", "$GOMODCACHE/")) and "/" in name:
            dirs.add(name.split("/", 1)[0])
    return sorted(dirs)


def build_env(environment, gocache=None, modcache=None):
    """The environment of a reproducible build: this process's environment
    without any GO*, CGO_ENABLED, CC or CXX variable, then the recorded
    `environment`, GOENV=off (no `go env -w` file of the user, which could set
    GOEXPERIMENT, GOFIPS140 or GOAMD64), and the given caches."""
    env = {k: v for k, v in os.environ.items() if not k.startswith("GO") and k not in ("CGO_ENABLED", "CC", "CXX")}
    env.update(environment)
    env["GOENV"] = "off"
    if gocache is not None:
        env["GOCACHE"] = str(gocache)
    if modcache is not None:
        env["GOMODCACHE"] = str(modcache)
    return env


def rebuild(text, root, work, log=print):
    """Build the manifest's binaries from `root` as the manifest records; return the bin folder."""
    flags, environment, binaries = reproducible_build(text)
    vendored = (root / "vendor" / "modules.txt").is_file()
    if not vendored and not os.environ.get("GOMODCACHE"):
        raise SystemExit("--rebuild in a tree without vendor/ needs GOMODCACHE (the module cache) to vendor from")
    empty = work / "empty-modcache"
    empty.mkdir(parents=True, exist_ok=True)
    env = build_env(environment, work / "gocache", empty)
    src = root
    if not vendored:
        src = work / "src"
        log("  no vendor/ here: copying go.mod, go.sum and %s to %s and vendoring from $GOMODCACHE" % (", ".join(source_dirs(text)), src))
        src.mkdir(parents=True)
        for name in ("go.mod", "go.sum"):
            shutil.copy2(root / name, src / name)
        for d in source_dirs(text):
            shutil.copytree(root / d, src / d)
        venv = {k: v for k, v in os.environ.items() if k not in ("GOFLAGS", "GOWORK")}
        venv.update({"GOFLAGS": "-mod=mod", "GOPROXY": "off", "GOTOOLCHAIN": "local", "GOWORK": "off"})
        result = subprocess.run([go_command(), "mod", "vendor"], cwd=src, env=venv, capture_output=True, text=True)
        if result.returncode != 0:
            sys.stderr.write(result.stdout + result.stderr)
            raise SystemExit("go mod vendor failed (%d)" % result.returncode)
    bin_dir = work / "bin"
    bin_dir.mkdir(parents=True, exist_ok=True)
    packages = ["./cmd/" + Path(name).stem for name, _ in binaries]
    cmd = [go_command(), "build"] + flags + ["-o", str(bin_dir) + os.sep] + packages
    log("  %s %s" % (" ".join("%s=%s" % kv for kv in sorted(dict(environment, GOENV="off").items())), " ".join(cmd[1:])))
    result = subprocess.run(cmd, cwd=src, env=env, capture_output=True, text=True)
    if result.returncode != 0:
        sys.stderr.write(result.stdout + result.stderr)
        raise SystemExit("rebuild failed (%d)" % result.returncode)
    return bin_dir


# --- sources ----------------------------------------------------------------------------------

def check_sources(text, groot, why_not):
    vendor = ROOT / "vendor"
    modcache = Path(os.environ.get("GOMODCACHE", "")) if not vendor.is_dir() else None
    counts = {"module": [0, 0], "third-party": [0, 0], "standard library": [0, 0]}
    skipped = {"binary": 0, "standard library": 0, "third-party": 0}
    bad = []
    for digest, name in entries(text):
        if name.startswith("bin/"):
            skipped["binary"] += 1
            continue
        if name.startswith("$GOROOT/"):
            group = "standard library"
            if groot is None:
                skipped[group] += 1
                continue
            path = groot / name[len("$GOROOT/"):]
        elif name.startswith("$GOMODCACHE/"):
            group = "third-party"
            rest = name[len("$GOMODCACHE/"):]
            if modcache is None and vendor.is_dir():
                module, _, file = rest.partition("@")
                path = vendor / decode_module_path(module) / file.split("/", 1)[1]
            elif modcache and str(modcache):
                path = modcache / rest
            else:
                skipped[group] += 1
                continue
        else:
            group = "module"
            path = ROOT / name
        counts[group][0] += 1
        try:
            actual = hashlib.sha256(path.read_bytes()).hexdigest()
        except OSError:
            actual = "missing"
        if actual != digest:
            counts[group][1] += 1
            bad.append((group, name, "missing" if actual == "missing" else "differs"))
    for group, (checked, differ) in counts.items():
        if checked:
            print("  %-16s %4d files checked, %d differ" % (group, checked, differ))
    if skipped["standard library"]:
        print("  standard library %4d files skipped (%s)" % (skipped["standard library"], why_not))
    if skipped["third-party"]:
        print("  third-party      %4d files skipped (no vendor/ and no GOMODCACHE)" % skipped["third-party"])
    for group, name, why in bad:
        print("  %s: %s (%s)" % (why.upper(), name, group))
    return bad, skipped["binary"]


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("manifest", nargs="?", help="build manifest (default: the newest docs/paper/data/build<N>/build-manifest.txt)")
    parser.add_argument("--rebuild", action="store_true", help="rebuild the binaries reproducibly and compare them with the manifest")
    parser.add_argument("--bin", help="compare the binaries in this folder with the manifest")
    parser.add_argument("--work", help="folder for --rebuild (default: a new temporary folder, removed afterwards)")
    args = parser.parse_args(argv)
    manifest = Path(args.manifest) if args.manifest else default_manifest()
    if not manifest.is_file():
        print("no manifest: %s" % manifest, file=sys.stderr)
        return 2
    text = manifest.read_text(encoding="utf-8")
    toolchain = toolchain_of(text)
    groot, why_not = goroot(toolchain)
    print("manifest:", manifest.resolve().relative_to(ROOT).as_posix() if manifest.resolve().is_relative_to(ROOT) else manifest)
    bad, listed = check_sources(text, groot, why_not)
    try:
        repro, malformed = reproducible_build(text), ""
    except ManifestError as err:
        repro, malformed = None, str(err)
    binary_problems = 0   # binaries that differ or are missing, or a malformed manifest
    not_done = []         # binary checks that were asked for and could not be done
    compared = []         # "6 given", "6 rebuilt"
    if malformed:
        print("  binaries         NOT CHECKED: the manifest says `reproducible build: yes` but its record is malformed: %s" % malformed)
        binary_problems += 1
    elif not (args.rebuild or args.bin):
        how = "use --rebuild or --bin DIR" if repro else "this manifest's build was not reproducible"
        print("  binaries         %4d listed, not checked (%s)" % (listed, how))
    elif repro is None:
        print("  binaries         %4d listed, NOT CHECKED: this manifest records no reproducible build (no `reproducible build: yes`, "
              "build flags and environment); its binaries embed the build path and the version-control stamp, so rebuilt binaries differ" % listed)
        not_done.append("this manifest records no reproducible build")
    else:
        flags, environment, expected = repro
        targets = []
        if args.bin:
            targets.append(("given", Path(args.bin)))
        work_root = None
        if args.rebuild:
            if groot is None:
                print("  binaries         NOT REBUILT: %s" % why_not)
                not_done.append("not rebuilt: " + why_not)
            else:
                work_root = Path(args.work).resolve() if args.work else Path(tempfile.mkdtemp(prefix="agentgate-rebuild-"))
                work_root.mkdir(parents=True, exist_ok=True)
                print("  rebuilding with the manifest's flags in %s" % work_root)
                targets.append(("rebuilt", rebuild(text, ROOT, work_root)))
        for label, folder in targets:
            rows = compare_binaries(expected, folder)
            for name, status, actual in rows:
                print("  binary %-8s %-28s %s%s" % (label, name, status, (" (" + actual + ")") if status == "differs" else ""))
                binary_problems += status != "same"
            compared.append("%d %s" % (len(rows), label))
        if work_root is not None and not args.work:
            shutil.rmtree(work_root, ignore_errors=True)
    if bad or binary_problems:
        what = "malformed reproducible-build record" if malformed else "%d binaries" % binary_problems
        print("RESULT: FAIL (%d source files, %s)" % (len(bad), what))
        return 1
    if not_done:
        print("RESULT: INCOMPLETE (sources match; binaries asked for but not checked: %s)" % "; ".join(not_done))
        return 1
    print("RESULT: PASS (%s)" % ("sources and binaries: " + ", ".join(compared) if compared else "sources only; binaries not checked"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
