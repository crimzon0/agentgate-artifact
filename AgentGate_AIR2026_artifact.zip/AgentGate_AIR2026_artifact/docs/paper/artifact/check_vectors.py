#!/usr/bin/env python3
"""Independent check of docs/paper/artifact/test_vectors.json.

Python 3 standard library only. Nothing here imports or calls AgentGate code:
the SHA-256 vectors are recomputed with hashlib, the deterministic CBOR is
re-encoded by the small encoder below, and the Ed25519 signatures are checked
by the small RFC 8032 verifier below (calibrated against RFC 8032 TEST 1
first).

    python docs/paper/artifact/check_vectors.py [path/to/test_vectors.json]

Exit status 0 when every check passes, 1 otherwise.
"""

import base64
import hashlib
import json
import sys
from pathlib import Path

FAILURES = []
PASSES = 0


def check(condition, what):
    global PASSES
    if condition:
        PASSES += 1
    else:
        FAILURES.append(what)
        print("FAIL:", what)


def domain_hash(label, data):
    return hashlib.sha256(label.encode("ascii") + b"\x00" + data).digest()


# --- deterministic CBOR encoder (RFC 8949 section 4.2.1) ----------------------

def head(major, n):
    if n < 24:
        return bytes([(major << 5) | n])
    for info, size in ((24, 1), (25, 2), (26, 4), (27, 8)):
        if n < (1 << (8 * size)):
            return bytes([(major << 5) | info]) + n.to_bytes(size, "big")
    raise ValueError("integer too large")


def as_int(x):
    return int(x) if isinstance(x, str) else x


def encode_typed(v):
    (kind,) = [k for k in v if k != "content"] if "tag" in v else list(v)
    if kind == "uint":
        return head(0, as_int(v["uint"]))
    if kind == "nint":
        return head(1, -1 - as_int(v["nint"]))
    if kind == "bytes":
        b = bytes.fromhex(v["bytes"])
        return head(2, len(b)) + b
    if kind == "text":
        b = v["text"].encode("utf-8")
        return head(3, len(b)) + b
    if kind == "bool":
        return b"\xf5" if v["bool"] else b"\xf4"
    if kind == "array":
        return head(4, len(v["array"])) + b"".join(encode_typed(i) for i in v["array"])
    if kind == "map":
        pairs = sorted((encode_typed(k), encode_typed(val)) for k, val in v["map"])
        keys = [k for k, _ in pairs]
        if len(set(keys)) != len(keys):
            raise ValueError("duplicate map key")
        return head(5, len(pairs)) + b"".join(k + val for k, val in pairs)
    if kind == "tag":
        return head(6, v["tag"]) + encode_typed(v["content"])
    raise ValueError("unknown typed value %r" % (v,))


def encode_json_value(x):
    """Plain JSON (ints, strings, lists, objects) -> deterministic CBOR."""
    if isinstance(x, bool):
        return b"\xf5" if x else b"\xf4"
    if isinstance(x, int):
        return head(0, x) if x >= 0 else head(1, -1 - x)
    if isinstance(x, str):
        b = x.encode("utf-8")
        return head(3, len(b)) + b
    if isinstance(x, list):
        return head(4, len(x)) + b"".join(encode_json_value(i) for i in x)
    if isinstance(x, dict):
        pairs = sorted((encode_json_value(k), encode_json_value(v)) for k, v in x.items())
        return head(5, len(pairs)) + b"".join(k + v for k, v in pairs)
    raise ValueError("unsupported JSON value %r" % (x,))


def bstr(b):
    return head(2, len(b)) + b


# --- Ed25519 (RFC 8032), verification and key derivation only -----------------

P = 2**255 - 19
L = 2**252 + 27742317777372353535851937790883648493
D = (-121665 * pow(121666, P - 2, P)) % P
SQRT_M1 = pow(2, (P - 1) // 4, P)


def point_add(a, b):
    x1, y1, z1, t1 = a
    x2, y2, z2, t2 = b
    A = (y1 - x1) * (y2 - x2) % P
    B = (y1 + x1) * (y2 + x2) % P
    C = t1 * 2 * D * t2 % P
    Dd = z1 * 2 * z2 % P
    E, F, G, H = B - A, Dd - C, Dd + C, B + A
    return (E * F % P, G * H % P, F * G % P, E * H % P)


def scalar_mult(s, pt):
    q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            q = point_add(q, pt)
        pt = point_add(pt, pt)
        s >>= 1
    return q


def recover_x(y, sign):
    if y >= P:
        return None
    x2 = (y * y - 1) * pow(D * y * y + 1, P - 2, P) % P
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (P + 3) // 8, P)
    if (x * x - x2) % P != 0:
        x = x * SQRT_M1 % P
    if (x * x - x2) % P != 0:
        return None
    if (x & 1) != sign:
        x = P - x
    return x


GY = 4 * pow(5, P - 2, P) % P
GX = recover_x(GY, 0)
G = (GX, GY, 1, GX * GY % P)


def point_encode(pt):
    x, y, z, _ = pt
    zi = pow(z, P - 2, P)
    x, y = x * zi % P, y * zi % P
    return (y | ((x & 1) << 255)).to_bytes(32, "little")


def point_decode(b):
    if len(b) != 32:
        return None
    y = int.from_bytes(b, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    x = recover_x(y, sign)
    if x is None:
        return None
    return (x, y, 1, x * y % P)


def public_from_seed(seed):
    h = hashlib.sha512(seed).digest()
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return point_encode(scalar_mult(a, G))


def ed25519_verify(public, message, signature):
    if len(public) != 32 or len(signature) != 64:
        return False
    A = point_decode(public)
    R = point_decode(signature[:32])
    if A is None or R is None:
        return False
    s = int.from_bytes(signature[32:], "little")
    if s >= L:
        return False
    k = int.from_bytes(hashlib.sha512(signature[:32] + public + message).digest(), "little") % L
    return point_encode(scalar_mult(s, G)) == point_encode(point_add(R, scalar_mult(k, A)))


# --- the checks ------------------------------------------------------------------

def check_calibration(v):
    c = v["ed25519_calibration"]
    seed = bytes.fromhex(c["seed_hex"])
    check(public_from_seed(seed).hex() == c["public_key_hex"], "RFC 8032 TEST 1 public key derivation")
    check(ed25519_verify(bytes.fromhex(c["public_key_hex"]), b"", bytes.fromhex(c["signature_hex"])),
          "RFC 8032 TEST 1 signature verifies")
    bad = bytearray(bytes.fromhex(c["signature_hex"]))
    bad[0] ^= 1
    check(not ed25519_verify(bytes.fromhex(c["public_key_hex"]), b"", bytes(bad)), "a flipped signature bit is rejected")


def check_domain_hashes(v):
    for row in v["domain_hash"]["vectors"]:
        got = domain_hash(row["label"], bytes.fromhex(row["data_hex"])).hex()
        check(got == row["sha256_hex"], "domain hash: %s" % row["name"])


def check_cbor(v):
    for row in v["cbor"]["vectors"]:
        check(encode_typed(row["value"]).hex() == row["cbor_hex"], "CBOR: %s" % row["name"])
    for row in v["cbor"]["must_fail"]:
        if "canonical_value" in row:
            canonical = encode_typed(row["canonical_value"]).hex()
            check(canonical == row["canonical_hex"], "CBOR must-fail equivalent re-encodes: %s" % row["name"])
            check(canonical != row["cbor_hex"], "CBOR must-fail bytes differ from the canonical encoding: %s" % row["name"])


def check_key_ids(v):
    k = v["key_ids"]
    public = bytes.fromhex(k["public_key_hex"])
    cose_key = encode_typed(k["cose_key"]["value"])
    check(cose_key.hex() == k["cose_key"]["cbor_hex"], "COSE_Key re-encodes")
    built = encode_typed({"map": [[{"uint": 1}, {"uint": 1}], [{"uint": 3}, {"nint": -8}],
                                  [{"nint": -1}, {"uint": 6}], [{"nint": -2}, {"bytes": public.hex()}]]})
    check(built == cose_key, "COSE_Key is {1:1, 3:-8, -1:6, -2:public key}")
    check(hashlib.sha256(cose_key).hexdigest() == k["cose_key"]["kid_hex"], "COSE KID = SHA-256(COSE_Key)")
    check(hashlib.sha256(public).hexdigest() == k["audit_key"]["kid_hex"], "audit KID = SHA-256(public key)")


def check_effect(v):
    e = v["effect_object"]
    raw = encode_typed(e["value"])
    check(raw.hex() == e["cbor_hex"], "effect object re-encodes")
    check(domain_hash(e["label"], raw).hex() == e["digest_hex"], "effect digest")


def check_cose(v):
    c = v["cose_sign1"]
    seed = bytes.fromhex(c["signer_seed_hex"])
    public = public_from_seed(seed)
    check(public.hex() == c["signer_public_hex"], "COSE signer public key from seed")
    cose_key = encode_typed({"map": [[{"uint": 1}, {"uint": 1}], [{"uint": 3}, {"nint": -8}],
                                     [{"nint": -1}, {"uint": 6}], [{"nint": -2}, {"bytes": public.hex()}]]})
    kid = hashlib.sha256(cose_key).digest()
    check(kid.hex() == c["signer_kid_hex"], "COSE signer KID")
    payload = bytes.fromhex(c["payload_hex"])
    check(encode_typed(c["payload_value"]) == payload, "COSE payload re-encodes from its typed value")
    check(encode_json_value(c["grant_json"]) == payload, "COSE payload is the canonical CBOR of the grant JSON")
    protected = bytes.fromhex(c["protected_hex"])
    expected_protected = encode_typed({"map": [
        [{"uint": 1}, {"nint": -8}],
        [{"uint": 2}, {"array": [{"nint": -65537}]}],
        [{"uint": 3}, {"text": c["content_type"]}],
        [{"uint": 4}, {"bytes": kid.hex()}],
        [{"nint": -65537}, {"uint": 1}]]})
    check(protected == expected_protected, "COSE protected header {1:-8, 2:[-65537], 3:type, 4:KID, -65537:1}")
    sig_structure = head(4, 4) + encode_json_value("Signature1") + bstr(protected) + bstr(b"") + bstr(payload)
    check(sig_structure.hex() == c["sig_structure_hex"], "COSE Sig_structure")
    signature = bytes.fromhex(c["signature_hex"])
    check(ed25519_verify(public, sig_structure, signature), "COSE Ed25519 signature verifies")
    envelope = head(6, 18) + head(4, 4) + bstr(protected) + head(5, 0) + bstr(payload) + bstr(signature)
    check(envelope.hex() == c["cose_sign1_hex"], "COSE_Sign1 envelope encoding")
    check(domain_hash(c["body_hash_label"], payload).hex() == c["body_hash_hex"], "COSE body hash")
    check(domain_hash(c["object_hash_label"], envelope).hex() == c["object_hash_hex"], "COSE object hash")


def check_audit(v):
    a = v["audit_log"]
    public = bytes.fromhex(a["signer_public_hex"])
    check(public_from_seed(bytes.fromhex(a["signer_seed_hex"])) == public, "audit signer public key from seed")
    check(hashlib.sha256(public).hexdigest() == a["signer_kid_hex"], "audit signer KID")
    prev = "0" * 64
    effect = v["effect_object"]
    for index, line in enumerate(a["lines"], start=1):
        record = json.loads(line)
        prefix = '{"entry_hash":"%s","signature":"%s","entry":' % (record["entry_hash"], record["signature"])
        check(line.startswith(prefix) and line.endswith("}"), "audit line %d layout" % index)
        entry_json = line[len(prefix):-1].encode("utf-8")
        entry_hash = domain_hash("AgentGate/AuditEntry/v1", entry_json)
        check(entry_hash.hex() == record["entry_hash"], "audit line %d entry hash" % index)
        entry = json.loads(entry_json)
        check(entry["seq"] == index and entry["prev_hash"] == prev, "audit line %d chains to its predecessor" % index)
        message = b"AgentGate/AuditEntrySig/v1\x00" + entry_hash
        check(ed25519_verify(public, message, base64.b64decode(record["signature"])), "audit line %d signature" % index)
        row = a["entries"][index - 1]
        check(row["entry_json"].encode("utf-8") == entry_json and row["signature_message_hex"] == message.hex(),
              "audit line %d matches its entries[] row" % index)
        if "effect_cbor" in entry["artifacts"]:
            check(base64.b64decode(entry["artifacts"]["effect_cbor"]).hex() == effect["cbor_hex"],
                  "audit line %d effect_cbor artifact is the effect object" % index)
            check(entry["effect_digest"] == effect["digest_hex"], "audit line %d effect_digest" % index)
        prev = record["entry_hash"]
    h = json.loads(a["head_json"])
    check(h["seq"] == len(a["lines"]) and h["entry_hash"] == prev and h["run_id"] == a["run_id"], "head names the last entry")
    check(h["kid"] == a["signer_kid_hex"], "head KID")
    message = ("AgentGate/AuditHead/v1\x00%s\x00%d\x00%s" % (h["run_id"], h["seq"], h["entry_hash"])).encode("utf-8")
    check(message.hex() == a["head_message_hex"], "head message")
    check(ed25519_verify(public, message, base64.b64decode(h["signature"])), "head signature")
    keys = json.loads(a["keys_json"])
    check(hashlib.sha256(a["keys_json"].encode("utf-8")).hexdigest() == a["keys_sha256_hex"], "keys.json SHA-256")
    check(keys["keys"][0]["kid"] == a["signer_kid_hex"] and base64.b64decode(keys["keys"][0]["public_key"]) == public,
          "keys.json lists the audit key")


def main():
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name("test_vectors.json")
    v = json.loads(path.read_text(encoding="utf-8"))
    check(v.get("format") == "agentgate-test-vectors/v1", "format")
    for step in (check_calibration, check_domain_hashes, check_cbor, check_key_ids, check_effect, check_cose, check_audit):
        step(v)
    print("%d checks passed, %d failed" % (PASSES, len(FAILURES)))
    return 1 if FAILURES else 0


if __name__ == "__main__":
    sys.exit(main())
