// Command corpusgen writes the adversarial corpus for the subset verifier
// docs/paper/artifact/subset_verifier.py (a second implementation by the
// same authors, ported from the specification and the Go sources, sharing no
// code; see docs/paper/artifact/SUBSET_VERIFIER.md): a pair of fresh, clean
// base runs in flag mode (bound and unbound design), their tamper-lab copies
// when the base runs come with them, and mutants written by
// internal/evalattack for strip-flag, invent-flag and change-rules x the
// attacker key sets none, audit, audit+issuer and audit+issuer+adapter x
// every snapshot variant x both designs.
//
//	go run ./docs/paper/artifact/corpusgen -out CORPUS -make-base
//	go run ./docs/paper/artifact/corpusgen -out CORPUS -bound RUN_DIR -unbound RUN_DIR
//
// -make-base makes the two base runs the way agentgate-eval compromise does
// (demo.HeadlessRun, flag mode, bound and unbound) and keeps the genuine pins
// the demo held in memory. It makes them in a temporary folder outside
// -out and removes that folder at the end: only the evidence files of the
// base runs and of their tamper-lab copies go into the corpus, never the
// demo's self-test report or restart segments, which name local paths.
// -bound and -unbound take existing, fresh run folders instead (for example
// the flag-bound and flag-unbound base runs an agentgate-eval compromise work
// folder keeps); their pins are then read from the folders, which is
// equivalent only for untouched folders, so each base run must first verify,
// for real and with those pins, under the full Go verifier.
//
// The engine edits content and recomputes hashes only: nothing is signed, and
// no private key is read, written or generated here. Every mutant is
// verified by the Go verifier (auditverify.VerifyRun) under the key-compromise
// simulation of its key set (Options.AssumeCompromised) in the no-replay
// setting (DisableChecks policy.replay, as agentgate-eval compromise's
// no-replay configuration), with UnboundFlags for the unbound design, for the
// anchor conditions none, keys, head and both. Those outcomes go into
// manifest.json as the expected outcomes, together with every folder, the
// SHA-256 of each of its files (files_sha256, taken before the Go verifier
// reads them), its roles and its pins; manifest.sha256 freezes them before
// the Python verifier is ever run on the corpus. The verdict with
// policy.replay on is recorded next to them for information only (go_full).
package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"os/signal"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"agentgate/internal/audit"
	"agentgate/internal/auditverify"
	"agentgate/internal/demo"
	"agentgate/internal/evalattack"
)

const (
	manifestFormat = "agentgate-subset-corpus/v1"
	manifestFile   = "manifest.json"
	// manifestHashFile holds the manifest's SHA-256 ("<hex>  manifest.json",
	// the sha256sum format): the freeze subset_verifier.py --corpus checks.
	manifestHashFile = "manifest.sha256"
	// selfTestReport is the demo's self-test report in a run folder: not
	// evidence (the verifier never reads it), and it names local paths, so it
	// is not copied into the corpus.
	selfTestReport = "selftest-report.json"
)

// The corpus matrix (SUBSET_VERIFIER.md): the three classification edits of
// the flag-binding ablation, the attacker key sets {none, A, A+I, A+I+X} and
// every snapshot variant.
var (
	corpusOperators = []evalattack.Operator{evalattack.OpStripFlag, evalattack.OpInventFlag, evalattack.OpChangeRules}
	corpusKeySets   = []evalattack.KeySet{evalattack.KSNone, evalattack.KSAudit, evalattack.KSAuditIssuer, evalattack.KSAuditIssuerAdapter}
	corpusVariants  = evalattack.Variants
	// anchorConditions are the anchor conditions of agentgate-eval compromise.
	anchorConditions = []string{"none", "keys", "head", "both"}
	// noReplay is the Go verifier setting the expected outcomes are computed
	// under: a classification that cannot be replayed.
	noReplay = []string{auditverify.CheckPolicyReplay}
)

// base is one clean base run of the corpus.
type base struct {
	design  string // "bound" or "unbound"
	unbound bool
	dir     string // the clean copy inside the corpus
	runID   string
	keys    string // genuine keys pin (SHA-256 of keys.json)
	head    string // genuine head pin (hash of the last entry)
	pins    string // "harness" (demo.HeadlessRun memory) or "folder"
	tamper  string // the base run's tamper-lab folder ("" when it has none)
}

// outcome is the Go verifier's result for one anchor condition.
type outcome struct {
	Verdict       string   `json:"verdict"`
	Assurance     string   `json:"assurance"`
	FailingChecks []string `json:"failing_checks"`
}

// entry is one corpus folder (or one mutant the engine could not apply).
type entry struct {
	ID                string             `json:"id"`
	Group             string             `json:"group"` // clean | tamper-lab | mutant
	Design            string             `json:"design"`
	UnboundFlags      bool               `json:"unbound_flags"`
	Dir               string             `json:"dir,omitempty"`
	Operator          string             `json:"operator,omitempty"`
	KeySet            string             `json:"keyset,omitempty"`
	Variant           string             `json:"variant,omitempty"`
	Attack            string             `json:"attack,omitempty"`
	AssumeCompromised []string           `json:"assume_compromised"`
	Applied           bool               `json:"applied"`
	NotApplicable     string             `json:"not_applicable,omitempty"`
	Unrepaired        []string           `json:"unrepaired,omitempty"`
	Anchors           map[string]string  `json:"anchors,omitempty"`
	FilesSHA256       map[string]string  `json:"files_sha256,omitempty"` // file name -> SHA-256 (hex) of the folder's files
	Expected          map[string]outcome `json:"expected,omitempty"`
	GoFull            map[string]string  `json:"go_full,omitempty"`
}

type baseInfo struct {
	Dir        string `json:"dir"`
	RunID      string `json:"run_id"`
	KeysSHA256 string `json:"keys_sha256"`
	FinalHead  string `json:"final_head"`
	PinsSource string `json:"pins_source"`
}

type manifest struct {
	Format           string              `json:"format"`
	Generator        string              `json:"generator"`
	CreatedAt        string              `json:"created_at"`
	Setting          string              `json:"setting"`
	DisabledChecks   []string            `json:"go_disabled_checks"`
	AnchorConditions []string            `json:"anchor_conditions"`
	Operators        []string            `json:"operators"`
	KeySets          []string            `json:"keysets"`
	Variants         []string            `json:"variants"`
	Bases            map[string]baseInfo `json:"bases"`
	Note             string              `json:"note"`
	Entries          []entry             `json:"entries"`
}

const manifestNote = "expected: the Go verifier (auditverify.VerifyRun) under the no-replay setting (policy.replay off), " +
	"with Options.AssumeCompromised set to the entry's roles (a key-compromise SIMULATION: those roles' signatures are accepted unverified) " +
	"and UnboundFlags for the unbound design, per anchor condition (keys/head pins in 'anchors'). " +
	"The mutation engine edited content and recomputed hashes only; nothing was signed. " +
	"These outcomes were computed by corpusgen before any run of the Python subset verifier, on the files whose SHA-256 is in each entry's files_sha256; " +
	"manifest.sha256 freezes them. go_full is the Go verdict with policy.replay on, for information only."

func main() {
	if err := run(os.Args[1:], os.Stdout); err != nil {
		fmt.Fprintln(os.Stderr, "corpusgen:", err)
		os.Exit(1)
	}
}

func run(args []string, stdout io.Writer) error {
	set := flag.NewFlagSet("corpusgen", flag.ContinueOnError)
	set.SetOutput(stdout)
	out := set.String("out", "", "corpus directory to create (must not exist or be empty)")
	boundDir := set.String("bound", "", "fresh flag-mode base run folder of the bound design")
	unboundDir := set.String("unbound", "", "fresh flag-mode base run folder of the unbound design")
	makeBase := set.Bool("make-base", false, "make fresh base runs with demo.HeadlessRun instead of -bound/-unbound")
	hostLabel := set.String("host-label", "review-host", "with -make-base: the machine name recorded in the evidence")
	if err := set.Parse(args); err != nil {
		return err
	}
	switch {
	case set.NArg() > 0:
		return fmt.Errorf("unexpected argument %q", set.Arg(0))
	case *out == "":
		return errors.New("-out is required")
	case *makeBase && (*boundDir != "" || *unboundDir != ""):
		return errors.New("give either -make-base or -bound and -unbound, not both")
	case !*makeBase && (*boundDir == "" || *unboundDir == ""):
		return errors.New("give -bound and -unbound (fresh base run folders), or -make-base")
	}
	if err := prepareOut(*out); err != nil {
		return err
	}
	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt)
	defer cancel()

	// -make-base makes the base runs in a temporary folder outside the corpus:
	// the raw demo output (self-test report, restart segment) names local
	// paths. Only evidence files are copied out of it, and it is removed at
	// the end (the tamper-lab copies are read from it until then).
	var scratch string
	if *makeBase {
		dir, err := os.MkdirTemp("", "corpusgen-base-")
		if err != nil {
			return err
		}
		scratch = dir
		defer os.RemoveAll(scratch)
	}

	var bases []base
	for _, design := range []string{"bound", "unbound"} {
		b := base{design: design, unbound: design == "unbound", dir: filepath.Join(*out, "clean", design)}
		var src string
		if *makeBase {
			fmt.Fprintf(stdout, "base run %s ...\n", design)
			res, err := demo.HeadlessRun(ctx, demo.HeadlessOptions{
				RunsDir: filepath.Join(scratch, "flag-"+design), Escalation: "flag",
				UnboundFlags: b.unbound, HostLabel: *hostLabel,
			})
			if err != nil {
				return fmt.Errorf("base run %s: %w", design, err)
			}
			src, b.keys, b.head, b.pins = res.RunDir, res.KeysSHA256, res.FinalHead, "harness"
		} else {
			src = map[string]string{"bound": *boundDir, "unbound": *unboundDir}[design]
		}
		if err := copyRunFiles(src, b.dir); err != nil {
			return fmt.Errorf("copy base run %s: %w", design, err)
		}
		if b.pins == "" {
			keys, head, err := folderPins(b.dir)
			if err != nil {
				return fmt.Errorf("base run %s: %w", design, err)
			}
			b.keys, b.head, b.pins = keys, head, "folder"
		}
		b.runID = filepath.Base(filepath.Clean(src))
		if tamper := filepath.Join(filepath.Dir(filepath.Clean(src)), "tamper-lab", b.runID); isDir(tamper) {
			b.tamper = tamper
		}
		if err := checkBase(b); err != nil {
			return err
		}
		bases = append(bases, b)
	}

	m := manifest{
		Format: manifestFormat, Generator: "docs/paper/artifact/corpusgen", CreatedAt: time.Now().UTC().Format(time.RFC3339),
		Setting: "no-replay", DisabledChecks: noReplay, AnchorConditions: anchorConditions,
		Operators: names(corpusOperators), KeySets: names(corpusKeySets), Variants: names(corpusVariants),
		Bases: map[string]baseInfo{}, Note: manifestNote,
	}
	for _, b := range bases {
		m.Bases[b.design] = baseInfo{Dir: rel(*out, b.dir), RunID: b.runID, KeysSHA256: b.keys, FinalHead: b.head, PinsSource: b.pins}
		e, err := verifiedEntry(*out, b, entry{ID: "clean/" + b.design, Group: "clean", Dir: b.dir, Applied: true}, nil)
		if err != nil {
			return err
		}
		m.Entries = append(m.Entries, e)
	}
	for _, b := range bases {
		attacks, err := tamperAttacks(b)
		if err != nil {
			return err
		}
		for _, attack := range attacks {
			dir := filepath.Join(*out, "tamper-lab", b.design, attack)
			if err := copyRunFiles(filepath.Join(b.tamper, attack), dir); err != nil {
				return fmt.Errorf("copy tamper-lab %s/%s: %w", b.design, attack, err)
			}
			e, err := verifiedEntry(*out, b, entry{ID: "tamper-lab/" + b.design + "/" + attack, Group: "tamper-lab", Dir: dir, Attack: attack, Applied: true}, nil)
			if err != nil {
				return err
			}
			m.Entries = append(m.Entries, e)
		}
	}
	for _, b := range bases {
		for _, op := range corpusOperators {
			for _, ks := range corpusKeySets {
				for _, variant := range corpusVariants {
					id := fmt.Sprintf("%s-%s-%s-%s", b.design, op, ks, variant)
					e := entry{ID: "mutant/" + id, Group: "mutant", Operator: string(op), KeySet: string(ks), Variant: string(variant)}
					dir := filepath.Join(*out, "mutants", id)
					mutant, err := evalattack.MutateVariant(b.dir, dir, op, ks, variant)
					if err != nil {
						if !evalattack.NotApplicable(err) {
							return fmt.Errorf("mutate %s: %w", id, err)
						}
						e.Design, e.UnboundFlags, e.NotApplicable = b.design, b.unbound, err.Error()
						e.AssumeCompromised = []string{}
						m.Entries = append(m.Entries, e)
						continue
					}
					e.Dir, e.Applied, e.Unrepaired = dir, true, mutant.Unrepaired
					if e, err = verifiedEntry(*out, b, e, mutant.AssumeCompromised); err != nil {
						return err
					}
					m.Entries = append(m.Entries, e)
				}
			}
		}
	}

	digest, err := writeManifest(*out, m)
	if err != nil {
		return err
	}
	printSummary(stdout, *out, m, digest)
	return nil
}

// prepareOut creates the corpus directory, which must not hold anything yet
// (a corpus is never mixed with an earlier one).
func prepareOut(dir string) error {
	entries, err := os.ReadDir(dir)
	switch {
	case err == nil && len(entries) > 0:
		return fmt.Errorf("%s is not empty; give a new corpus directory", dir)
	case err != nil && !os.IsNotExist(err):
		return err
	}
	return os.MkdirAll(dir, 0o755)
}

// copyRunFiles copies the regular files of one run folder (not the self-test
// report) into dst.
func copyRunFiles(src, dst string) error {
	items, err := os.ReadDir(src)
	if err != nil {
		return err
	}
	if err := os.MkdirAll(dst, 0o755); err != nil {
		return err
	}
	copied := 0
	for _, item := range items {
		if !item.Type().IsRegular() || item.Name() == selfTestReport {
			continue
		}
		data, err := os.ReadFile(filepath.Join(src, item.Name()))
		if err != nil {
			return err
		}
		if err := os.WriteFile(filepath.Join(dst, item.Name()), data, 0o644); err != nil {
			return err
		}
		copied++
	}
	if _, err := os.Stat(filepath.Join(dst, audit.LogFile)); err != nil {
		return fmt.Errorf("%s holds no %s (not a run folder)", src, audit.LogFile)
	}
	return nil
}

// folderPins reads the pins of an untouched base run from its folder: the
// SHA-256 of keys.json and the hash of the last audit entry.
func folderPins(dir string) (keys, head string, err error) {
	data, err := os.ReadFile(filepath.Join(dir, audit.KeysFile))
	if err != nil {
		return "", "", err
	}
	sum := sha256.Sum256(data)
	stored, err := audit.ReadLog(dir)
	if err != nil {
		return "", "", err
	}
	if len(stored) == 0 {
		return "", "", fmt.Errorf("%s has an empty audit log", dir)
	}
	return hex.EncodeToString(sum[:]), stored[len(stored)-1].EntryHash, nil
}

// checkBase requires a base run to verify for real (no simulation, every
// check on) and anchored by its pins, in flag mode, with a policy snapshot.
func checkBase(b base) error {
	report, err := auditverify.VerifyRun(b.dir, auditverify.Options{ExpectKeysSHA256: b.keys, ExpectHead: b.head, UnboundFlags: b.unbound})
	if err != nil {
		return fmt.Errorf("verify base run %s: %w", b.design, err)
	}
	if report.Verdict != auditverify.VerdictVerified || report.Assurance != auditverify.AssuranceAnchored {
		return fmt.Errorf("base run %s does not verify for real with its pins (%s / %s, failing %s): give a fresh, untouched run folder",
			b.design, report.Verdict, report.Assurance, strings.Join(failingCheckIDs(report), ", "))
	}
	var record struct {
		Policy struct {
			Escalation string `json:"escalation"`
		} `json:"policy"`
		Snapshot *struct {
			UnboundFlags *bool `json:"unbound_flags"`
		} `json:"policy_snapshot"`
	}
	data, err := os.ReadFile(filepath.Join(b.dir, audit.RunFile))
	if err != nil {
		return err
	}
	if err := json.Unmarshal(data, &record); err != nil {
		return fmt.Errorf("base run %s: run.json: %w", b.design, err)
	}
	switch {
	case record.Policy.Escalation != "flag":
		return fmt.Errorf("base run %s was made in escalation mode %q, not flag", b.design, record.Policy.Escalation)
	case record.Snapshot == nil:
		return fmt.Errorf("base run %s records no policy snapshot", b.design)
	case record.Snapshot.UnboundFlags != nil && *record.Snapshot.UnboundFlags != b.unbound:
		// The gateway records the design in the snapshot (the fixture does not).
		return fmt.Errorf("base run %s: its policy snapshot says unbound_flags=%t", b.design, *record.Snapshot.UnboundFlags)
	}
	return nil
}

// tamperAttacks lists the attack folders of a base run's tamper lab.
func tamperAttacks(b base) ([]string, error) {
	if b.tamper == "" {
		return nil, nil
	}
	items, err := os.ReadDir(b.tamper)
	if err != nil {
		return nil, err
	}
	var out []string
	for _, item := range items {
		if item.IsDir() {
			out = append(out, item.Name())
		}
	}
	sort.Strings(out)
	return out, nil
}

// verifiedEntry fills e's design, roles, pins, the SHA-256 of its files and
// the Go verifier's outcomes on those files.
func verifiedEntry(root string, b base, e entry, roles []string) (entry, error) {
	e.Design, e.UnboundFlags = b.design, b.unbound
	e.AssumeCompromised = append([]string{}, roles...)
	e.Anchors = map[string]string{"keys": b.keys, "head": b.head}
	digests, err := folderDigests(e.Dir)
	if err != nil {
		return e, fmt.Errorf("%s: %w", e.ID, err)
	}
	e.FilesSHA256 = digests
	e.Expected, e.GoFull = map[string]outcome{}, map[string]string{}
	for _, condition := range anchorConditions {
		for _, full := range []bool{false, true} {
			options := auditverify.Options{AssumeCompromised: roles, UnboundFlags: b.unbound}
			if !full {
				options.DisableChecks = noReplay
			}
			if condition == "keys" || condition == "both" {
				options.ExpectKeysSHA256 = b.keys
			}
			if condition == "head" || condition == "both" {
				options.ExpectHead = b.head
			}
			report, err := auditverify.VerifyRun(e.Dir, options)
			if err != nil {
				return e, fmt.Errorf("verify %s (%s): %w", e.ID, condition, err)
			}
			if full {
				e.GoFull[condition] = report.Verdict
			} else {
				e.Expected[condition] = outcome{Verdict: report.Verdict, Assurance: report.Assurance, FailingChecks: failingCheckIDs(report)}
			}
		}
	}
	e.Dir = rel(root, e.Dir)
	return e, nil
}

// folderDigests returns the SHA-256 (hex) of every file of a corpus folder,
// by file name. Corpus folders hold regular files only; anything else is an
// error, so that the manifest describes the whole folder.
func folderDigests(dir string) (map[string]string, error) {
	items, err := os.ReadDir(dir)
	if err != nil {
		return nil, err
	}
	out := map[string]string{}
	for _, item := range items {
		if !item.Type().IsRegular() {
			return nil, fmt.Errorf("%s holds %s, which is not a regular file", dir, item.Name())
		}
		data, err := os.ReadFile(filepath.Join(dir, item.Name()))
		if err != nil {
			return nil, err
		}
		sum := sha256.Sum256(data)
		out[item.Name()] = hex.EncodeToString(sum[:])
	}
	return out, nil
}

// failingCheckIDs lists the IDs of a report's failing checks, once each, in
// report order (as agentgate-eval does).
func failingCheckIDs(report auditverify.Report) []string {
	seen := map[string]bool{}
	out := []string{}
	for _, check := range report.Failures {
		if !seen[check.ID] {
			seen[check.ID] = true
			out = append(out, check.ID)
		}
	}
	return out
}

// writeManifest writes manifest.json and manifest.sha256 (the freeze) and
// returns the manifest's SHA-256.
func writeManifest(dir string, m manifest) (string, error) {
	data, err := json.MarshalIndent(m, "", "  ")
	if err != nil {
		return "", err
	}
	data = append(data, '\n')
	if err := os.WriteFile(filepath.Join(dir, manifestFile), data, 0o644); err != nil {
		return "", err
	}
	sum := sha256.Sum256(data)
	digest := hex.EncodeToString(sum[:])
	if err := os.WriteFile(filepath.Join(dir, manifestHashFile), []byte(digest+"  "+manifestFile+"\n"), 0o644); err != nil {
		return "", err
	}
	return digest, nil
}

func printSummary(stdout io.Writer, dir string, m manifest, digest string) {
	counts := map[string]int{}
	failed := map[string]int{}
	notApplicable := 0
	for _, e := range m.Entries {
		if !e.Applied {
			notApplicable++
			continue
		}
		counts[e.Group]++
		for _, condition := range anchorConditions {
			if e.Expected[condition].Verdict == auditverify.VerdictFailed {
				failed[e.Group]++
			}
		}
	}
	fmt.Fprintf(stdout, "corpus %s: %d clean, %d tamper-lab, %d mutant folders (%d mutants not applicable)\n",
		dir, counts["clean"], counts["tamper-lab"], counts["mutant"], notApplicable)
	for _, group := range []string{"clean", "tamper-lab", "mutant"} {
		fmt.Fprintf(stdout, "  %-10s Go no-replay FAILED in %d of %d verifications\n", group, failed[group], counts[group]*len(anchorConditions))
	}
	fmt.Fprintf(stdout, "manifest %s frozen: SHA-256 %s\n", filepath.Join(dir, manifestFile), digest)
}

func rel(root, path string) string {
	r, err := filepath.Rel(root, path)
	if err != nil {
		return filepath.ToSlash(path)
	}
	return filepath.ToSlash(r)
}

func isDir(path string) bool {
	info, err := os.Stat(path)
	return err == nil && info.IsDir()
}

func names[T ~string](items []T) []string {
	out := make([]string, len(items))
	for i, item := range items {
		out[i] = string(item)
	}
	return out
}
