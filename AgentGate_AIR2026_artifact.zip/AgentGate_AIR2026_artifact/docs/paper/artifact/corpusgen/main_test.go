package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"maps"
	"os"
	"os/exec"
	"path/filepath"
	"slices"
	"strings"
	"testing"

	"agentgate/internal/audit"
	"agentgate/internal/auditverify"
	"agentgate/internal/auditverify/fixture"
)

// fixtureBases writes a bound and an unbound revision fixture run (synthetic
// runs in the gateway's format, signed by the fixture with keys it generates
// in memory) and returns their folders.
func fixtureBases(t *testing.T) (bound, unbound string) {
	t.Helper()
	bound, unbound = filepath.Join(t.TempDir(), "bound"), filepath.Join(t.TempDir(), "unbound")
	if _, err := fixture.WriteWith(bound, fixture.Options{Revision: true}); err != nil {
		t.Fatal(err)
	}
	if _, err := fixture.WriteWith(unbound, fixture.Options{Revision: true, UnboundFlags: true}); err != nil {
		t.Fatal(err)
	}
	return bound, unbound
}

func buildCorpus(t *testing.T) (string, manifest) {
	t.Helper()
	bound, unbound := fixtureBases(t)
	out := filepath.Join(t.TempDir(), "corpus")
	var stdout bytes.Buffer
	if err := run([]string{"-out", out, "-bound", bound, "-unbound", unbound}, &stdout); err != nil {
		t.Fatalf("corpusgen: %v\n%s", err, stdout.String())
	}
	data, err := os.ReadFile(filepath.Join(out, manifestFile))
	if err != nil {
		t.Fatal(err)
	}
	var m manifest
	if err := json.Unmarshal(data, &m); err != nil {
		t.Fatal(err)
	}
	return out, m
}

// TestCorpusFromFixtureRuns builds a corpus and checks its shape, the freeze
// and the expected outcomes that do not depend on the verifier's details.
func TestCorpusFromFixtureRuns(t *testing.T) {
	out, m := buildCorpus(t)
	if m.Format != manifestFormat || m.Setting != "no-replay" || len(m.DisabledChecks) != 1 || m.DisabledChecks[0] != auditverify.CheckPolicyReplay {
		t.Fatalf("manifest header: %+v", m)
	}
	data, err := os.ReadFile(filepath.Join(out, manifestFile))
	if err != nil {
		t.Fatal(err)
	}
	frozen, err := os.ReadFile(filepath.Join(out, manifestHashFile))
	if err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256(data)
	if got := strings.Fields(string(frozen)); len(got) != 2 || got[0] != hex.EncodeToString(sum[:]) || got[1] != manifestFile {
		t.Fatalf("manifest.sha256 = %q, want the manifest's SHA-256", frozen)
	}
	for _, design := range []string{"bound", "unbound"} {
		info := m.Bases[design]
		if info.PinsSource != "folder" || len(info.KeysSHA256) != 64 || len(info.FinalHead) != 64 {
			t.Fatalf("base %s: %+v", design, info)
		}
	}

	byGroup := map[string]int{}
	roles := map[string]string{"none": "", "audit": "AUDIT_LOG", "audit+issuer": "AUDIT_LOG,CAPABILITY_ISSUER", "audit+issuer+adapter": "ADAPTER,AUDIT_LOG,CAPABILITY_ISSUER"}
	applied := 0
	for _, e := range m.Entries {
		byGroup[e.Group]++
		if e.Group == "mutant" && e.Applied {
			if want, ok := roles[e.KeySet]; !ok || strings.Join(e.AssumeCompromised, ",") != want {
				t.Errorf("%s: assume_compromised %v for key set %q", e.ID, e.AssumeCompromised, e.KeySet)
			}
		}
		if !e.Applied {
			if e.Dir != "" || e.NotApplicable == "" || e.Expected != nil {
				t.Errorf("%s: a mutant that did not apply has a folder or outcomes", e.ID)
			}
			continue
		}
		applied++
		if _, err := os.Stat(filepath.Join(out, filepath.FromSlash(e.Dir), audit.LogFile)); err != nil {
			t.Errorf("%s: %v", e.ID, err)
		}
		// The manifest records every file of the folder, with its SHA-256.
		if digests, err := folderDigests(filepath.Join(out, filepath.FromSlash(e.Dir))); err != nil || len(e.FilesSHA256) == 0 || !maps.Equal(digests, e.FilesSHA256) {
			t.Errorf("%s: files_sha256 %v, folder %v (%v)", e.ID, e.FilesSHA256, digests, err)
		}
		if len(e.Expected) != len(anchorConditions) || len(e.GoFull) != len(anchorConditions) {
			t.Errorf("%s: outcomes for %d/%d anchor conditions", e.ID, len(e.Expected), len(e.GoFull))
		}
		for _, condition := range anchorConditions {
			got := e.Expected[condition]
			switch {
			case e.Group == "clean" && got.Verdict != auditverify.VerdictVerified:
				t.Errorf("%s (%s): a clean base run is expected %s %v", e.ID, condition, got.Verdict, got.FailingChecks)
			case e.Group == "mutant" && e.KeySet == "none" && got.Verdict != auditverify.VerdictFailed:
				t.Errorf("%s (%s): a mutant with no key is expected %s", e.ID, condition, got.Verdict)
			case e.Group == "mutant" && (condition == "head" || condition == "both") && got.Verdict != auditverify.VerdictFailed:
				// Every edit changes the log, so the head pin catches it.
				t.Errorf("%s (%s): a mutant is accepted with a head anchor", e.ID, condition)
			}
		}
		if e.Group == "clean" && e.Expected["both"].Assurance != auditverify.AssuranceConsistent {
			// no-replay switches a check off, which caps the assurance at CONSISTENT
			t.Errorf("%s: assurance %s with both pins under no-replay, want CONSISTENT", e.ID, e.Expected["both"].Assurance)
		}
	}
	wantMutants := 2 * len(corpusOperators) * len(corpusKeySets) * len(corpusVariants)
	if byGroup["clean"] != 2 || byGroup["mutant"] != wantMutants || byGroup["tamper-lab"] != 0 {
		t.Fatalf("entries per group %v, want 2 clean and %d mutant rows (the fixture has no tamper lab)", byGroup, wantMutants)
	}
	if applied < 2+2*len(corpusOperators)*len(corpusKeySets) {
		t.Fatalf("only %d corpus folders: the engine applied too few mutants to the fixture", applied)
	}
}

// TestRefusesBaseThatDoesNotVerify: a base run whose log was edited is not
// accepted as a clean run.
func TestRefusesBaseThatDoesNotVerify(t *testing.T) {
	bound, unbound := fixtureBases(t)
	path := filepath.Join(bound, audit.LogFile)
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, bytes.Replace(data, []byte(`"outcome":"ok"`), []byte(`"outcome":"OK"`), 1), 0o644); err != nil {
		t.Fatal(err)
	}
	err = run([]string{"-out", filepath.Join(t.TempDir(), "corpus"), "-bound", bound, "-unbound", unbound}, &bytes.Buffer{})
	if err == nil || !strings.Contains(err.Error(), "does not verify") {
		t.Fatalf("an edited base run was accepted (err %v)", err)
	}
}

// TestRefusesSwappedDesigns: the unbound design's run is not accepted as the
// bound base run.
func TestRefusesSwappedDesigns(t *testing.T) {
	bound, unbound := fixtureBases(t)
	err := run([]string{"-out", filepath.Join(t.TempDir(), "corpus"), "-bound", unbound, "-unbound", bound}, &bytes.Buffer{})
	if err == nil || !(strings.Contains(err.Error(), "does not verify") || strings.Contains(err.Error(), "unbound_flags")) {
		t.Fatalf("swapped base runs were not refused for their design (err %v)", err)
	}
}

// TestCorpusCopiesTheTamperLab: a base run with a tamper-lab sibling folder
// (tamper-lab/<run>/<attack>, as the demo writes it) has its attack copies in
// the corpus, with their files' SHA-256 and the Go outcomes.
func TestCorpusCopiesTheTamperLab(t *testing.T) {
	bound, unbound := fixtureBases(t)
	for _, src := range []string{bound, unbound} {
		attack := filepath.Join(filepath.Dir(src), "tamper-lab", filepath.Base(src), "edit-value-1")
		if err := copyRunFiles(src, attack); err != nil {
			t.Fatal(err)
		}
		path := filepath.Join(attack, audit.LogFile)
		data, err := os.ReadFile(path)
		if err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(path, bytes.Replace(data, []byte(`"outcome":"ok"`), []byte(`"outcome":"OK"`), 1), 0o644); err != nil {
			t.Fatal(err)
		}
	}
	out := filepath.Join(t.TempDir(), "corpus")
	if err := run([]string{"-out", out, "-bound", bound, "-unbound", unbound}, &bytes.Buffer{}); err != nil {
		t.Fatal(err)
	}
	data, err := os.ReadFile(filepath.Join(out, manifestFile))
	if err != nil {
		t.Fatal(err)
	}
	var m manifest
	if err := json.Unmarshal(data, &m); err != nil {
		t.Fatal(err)
	}
	found := 0
	for _, e := range m.Entries {
		if e.Group != "tamper-lab" {
			continue
		}
		found++
		if e.Attack != "edit-value-1" || e.Dir != "tamper-lab/"+e.Design+"/edit-value-1" || len(e.FilesSHA256) == 0 {
			t.Errorf("tamper-lab entry %+v", e)
		}
		for _, condition := range anchorConditions {
			if got := e.Expected[condition]; got.Verdict != auditverify.VerdictFailed {
				t.Errorf("%s (%s): an edited entry is expected %s", e.ID, condition, got.Verdict)
			}
		}
	}
	if found != 2 {
		t.Fatalf("%d tamper-lab entries, want 2", found)
	}
}

// TestMakeBaseKeepsLocalPathsOutOfTheCorpus runs -make-base: the base runs
// are made outside -out (in a temporary folder that is removed afterwards),
// only evidence files are copied, the tamper-lab copies come along, and no
// file in the corpus names the temporary folder.
func TestMakeBaseKeepsLocalPathsOutOfTheCorpus(t *testing.T) {
	if testing.Short() {
		t.Skip("makes two demo runs and a full corpus")
	}
	before, _ := filepath.Glob(filepath.Join(os.TempDir(), "corpusgen-base-*"))
	out := filepath.Join(t.TempDir(), "corpus")
	var stdout bytes.Buffer
	if err := run([]string{"-out", out, "-make-base"}, &stdout); err != nil {
		t.Fatalf("corpusgen -make-base: %v\n%s", err, stdout.String())
	}
	if after, _ := filepath.Glob(filepath.Join(os.TempDir(), "corpusgen-base-*")); len(after) > len(before) {
		t.Errorf("the temporary base-run folder was left behind: %v", after)
	}
	top, err := os.ReadDir(out)
	if err != nil {
		t.Fatal(err)
	}
	for _, item := range top {
		switch item.Name() {
		case "clean", "tamper-lab", "mutants", manifestFile, manifestHashFile:
		default:
			t.Errorf("unexpected %s in the corpus", item.Name())
		}
	}
	needles := localNeedles(t)
	err = filepath.WalkDir(out, func(path string, item os.DirEntry, err error) error {
		if err != nil || item.IsDir() {
			return err
		}
		if item.Name() == selfTestReport {
			t.Errorf("%s was copied into the corpus", path)
		}
		data, err := os.ReadFile(path)
		if err != nil {
			return err
		}
		lower := bytes.ToLower(data)
		for _, needle := range needles {
			if bytes.Contains(lower, []byte(needle)) {
				t.Errorf("%s names a local path or the host name (%s)", path, needle)
				break
			}
		}
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	data, err := os.ReadFile(filepath.Join(out, manifestFile))
	if err != nil {
		t.Fatal(err)
	}
	var m manifest
	if err := json.Unmarshal(data, &m); err != nil {
		t.Fatal(err)
	}
	groups := map[string]int{}
	for _, e := range m.Entries {
		if e.Applied {
			groups[e.Group]++
		}
	}
	if groups["clean"] != 2 || groups["tamper-lab"] == 0 || groups["mutant"] == 0 || m.Bases["bound"].PinsSource != "harness" {
		t.Fatalf("corpus entries %v, bases %+v", groups, m.Bases)
	}
	t.Logf("%s", stdout.String())
	// The subset verifier on this corpus of demo runs (the gateway's own
	// evidence, not the fixture's): every verdict must agree (exit status 0).
	if interpreter := python(); interpreter != "" {
		sum := sha256.Sum256(data)
		output, err := exec.Command(interpreter, filepath.Join("..", "subset_verifier.py"), "--corpus", filepath.Join(out, manifestFile),
			"--expect-manifest-sha256", hex.EncodeToString(sum[:])).CombinedOutput()
		if err != nil {
			t.Fatalf("subset_verifier.py on the demo-run corpus: %v\n%s", err, output)
		}
		t.Logf("%s", output)
	}
}

// localNeedles returns what no corpus file may contain, lower-cased for a
// case-insensitive search: the temporary folder, the home folder, the working
// directory and the module root (each as written natively, with forward
// slashes and with JSON-escaped backslashes) and the host name. Needles
// shorter than six bytes are skipped so that they cannot match by chance.
func localNeedles(t *testing.T) []string {
	t.Helper()
	wd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	places := []string{os.TempDir(), wd, moduleRoot(t, wd)}
	if home, err := os.UserHomeDir(); err == nil {
		places = append(places, home)
	}
	var needles []string
	for _, place := range places {
		clean := filepath.Clean(place)
		needles = append(needles, clean, filepath.ToSlash(clean), strings.ReplaceAll(clean, `\`, `\\`))
	}
	if host, err := os.Hostname(); err == nil {
		needles = append(needles, host)
	}
	var out []string
	for _, needle := range needles {
		if needle = strings.ToLower(needle); len(needle) >= 6 && !slices.Contains(out, needle) {
			out = append(out, needle)
		}
	}
	return out
}

// moduleRoot returns the nearest folder at or above dir that holds go.mod.
func moduleRoot(t *testing.T, dir string) string {
	t.Helper()
	for current := dir; ; {
		if _, err := os.Stat(filepath.Join(current, "go.mod")); err == nil {
			return current
		}
		parent := filepath.Dir(current)
		if parent == current {
			t.Fatalf("no go.mod at or above %s", dir)
		}
		current = parent
	}
}

func TestUsageErrors(t *testing.T) {
	nonEmpty := t.TempDir()
	if err := os.WriteFile(filepath.Join(nonEmpty, "x"), nil, 0o644); err != nil {
		t.Fatal(err)
	}
	for _, args := range [][]string{
		{},
		{"-out", filepath.Join(t.TempDir(), "c")},
		{"-out", filepath.Join(t.TempDir(), "c"), "-bound", "a"},
		{"-out", filepath.Join(t.TempDir(), "c"), "-make-base", "-bound", "a", "-unbound", "b"},
		{"-out", nonEmpty, "-bound", "a", "-unbound", "b"},
		{"-out", filepath.Join(t.TempDir(), "c"), "-bound", "a", "-unbound", "b", "extra"},
	} {
		if err := run(args, &bytes.Buffer{}); err == nil {
			t.Errorf("run(%q) succeeded", args)
		}
	}
}

// python returns a Python 3 interpreter, or "" when there is none.
func python() string {
	for _, name := range []string{"python3", "python"} {
		path, err := exec.LookPath(name)
		if err != nil {
			continue
		}
		if out, err := exec.Command(path, "-c", "import sys; print(sys.version_info[0])").Output(); err == nil && strings.TrimSpace(string(out)) == "3" {
			return path
		}
	}
	return ""
}

// TestSubsetVerifierAgreesOnFixtureCorpus runs the Python subset verifier (a
// second implementation by the same authors, sharing no code) on a fixture
// corpus after the manifest was frozen and requires every verdict to agree
// with the Go verifier's expected outcome. The freeze must hold: a wrong
// recorded hash, a changed corpus file, a missing manifest.sha256 and an
// edited manifest are each refused with exit status 2.
func TestSubsetVerifierAgreesOnFixtureCorpus(t *testing.T) {
	interpreter := python()
	if interpreter == "" {
		t.Skip("no Python 3 interpreter on PATH")
	}
	if testing.Short() {
		t.Skip("runs the Python verifier on a corpus")
	}
	out, m := buildCorpus(t)
	script := filepath.Join("..", "subset_verifier.py")
	manifestPath := filepath.Join(out, manifestFile)
	manifestData, err := os.ReadFile(manifestPath)
	if err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256(manifestData)
	recorded := hex.EncodeToString(sum[:])
	resultPath := filepath.Join(t.TempDir(), "result.json")
	cmd := exec.Command(interpreter, script, "--corpus", manifestPath, "--expect-manifest-sha256", recorded, "--out", resultPath)
	output, err := cmd.CombinedOutput()
	if err != nil {
		t.Fatalf("subset_verifier.py --corpus: %v\n%s", err, output)
	}
	t.Logf("%s", output)
	var result struct {
		Manifest string `json:"manifest"`
		Freeze   struct {
			HashFileMatches bool `json:"hash_file_matches"`
			ExpectedMatches bool `json:"expected_sha256_matches"`
			FilesChecked    int  `json:"entry_files_checked"`
		} `json:"freeze_checked"`
		Summary struct {
			Verifications int      `json:"verifications"`
			Disagree      int      `json:"disagree"`
			Disagreements []string `json:"disagreements"`
			FlipsGo       []string `json:"binding_flips_go"`
			FlipsSubset   []string `json:"binding_flips_subset"`
			FlipsGoKeys   []string `json:"binding_flips_go_keys_pin"`
			Binding       struct {
				Verifications int `json:"verifications"`
				Agree         int `json:"agree"`
			} `json:"binding_relevant"`
			KeysRepeat struct {
				Verifications int `json:"verifications"`
				GoChanged     int `json:"go_verdict_changed"`
				SubsetChanged int `json:"subset_verdict_changed"`
			} `json:"binding_keys_repeat"`
			Other struct {
				Verifications int `json:"verifications"`
			} `json:"other_rows"`
		} `json:"summary"`
	}
	data, err := os.ReadFile(resultPath)
	if err != nil {
		t.Fatal(err)
	}
	if err := json.Unmarshal(data, &result); err != nil {
		t.Fatal(err)
	}
	if result.Summary.Verifications == 0 || result.Summary.Disagree != 0 {
		t.Fatalf("subset verifier: %d verifications, %d disagreements: %v", result.Summary.Verifications, result.Summary.Disagree, result.Summary.Disagreements)
	}
	if len(result.Summary.FlipsGo) == 0 || strings.Join(result.Summary.FlipsGo, " ") != strings.Join(result.Summary.FlipsSubset, " ") {
		t.Fatalf("binding flips: Go %v, subset %v", result.Summary.FlipsGo, result.Summary.FlipsSubset)
	}
	if result.Manifest != manifestFile || !result.Freeze.HashFileMatches || !result.Freeze.ExpectedMatches || result.Freeze.FilesChecked == 0 {
		t.Fatalf("result names manifest %q, freeze %+v", result.Manifest, result.Freeze)
	}
	// Each binding-relevant folder counts once; its keys-pinned verification
	// is a repeat whose verdict the pin cannot change (no mutant edits
	// keys.json), so the flips at the keys pin are the same.
	b, repeat := result.Summary.Binding, result.Summary.KeysRepeat
	if b.Verifications == 0 || b.Agree != b.Verifications || repeat.Verifications != b.Verifications ||
		b.Verifications+repeat.Verifications+result.Summary.Other.Verifications != result.Summary.Verifications {
		t.Fatalf("binding-relevant rows %+v, keys-pinned repeats %+v, of %d", b, repeat, result.Summary.Verifications)
	}
	if repeat.GoChanged != 0 || repeat.SubsetChanged != 0 || !slices.Equal(result.Summary.FlipsGoKeys, result.Summary.FlipsGo) {
		t.Fatalf("the keys pin changed binding-relevant verdicts: %+v, flips %v at the pin, %v without", repeat, result.Summary.FlipsGoKeys, result.Summary.FlipsGo)
	}

	refused := func(what, want string, extra ...string) {
		t.Helper()
		cmd := exec.Command(interpreter, append([]string{script, "--corpus", manifestPath}, extra...)...)
		output, err := cmd.CombinedOutput()
		if exit, ok := err.(*exec.ExitError); !ok || exit.ExitCode() != 2 || !strings.Contains(string(output), want) {
			t.Fatalf("%s was not refused with exit status 2 and %q (err %v)\n%s", what, want, err, output)
		}
	}
	// A hash recorded before the run that is not the manifest's.
	refused("a wrong recorded hash", "not to the recorded", "--expect-manifest-sha256", strings.Repeat("0", 64))
	// A corpus file changed after the freeze.
	var mutant string
	for _, e := range m.Entries {
		if e.Group == "mutant" && e.Applied {
			mutant = filepath.Join(out, filepath.FromSlash(e.Dir), audit.HeadFile)
			break
		}
	}
	original, err := os.ReadFile(mutant)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(mutant, append(append([]byte{}, original...), ' '), 0o644); err != nil {
		t.Fatal(err)
	}
	refused("a changed corpus file", "not the file the expected outcomes were computed on")
	if err := os.WriteFile(mutant, original, 0o644); err != nil {
		t.Fatal(err)
	}
	// A missing manifest.sha256.
	hashPath := filepath.Join(out, manifestHashFile)
	frozen, err := os.ReadFile(hashPath)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.Remove(hashPath); err != nil {
		t.Fatal(err)
	}
	refused("a missing manifest.sha256", "cannot be read")
	if err := os.WriteFile(hashPath, frozen, 0o644); err != nil {
		t.Fatal(err)
	}
	// An edited manifest.
	if err := os.WriteFile(manifestPath, bytes.Replace(manifestData, []byte(`"FAILED"`), []byte(`"VERIFIED"`), 1), 0o644); err != nil {
		t.Fatal(err)
	}
	refused("an edited manifest", "frozen")
}

// subsetReport is the part of a subset_verifier.py report the tests read.
type subsetReport struct {
	Verdict       string   `json:"verdict"`
	FailingChecks []string `json:"failing_checks"`
	Simulation    *struct {
		AssumeCompromised []string `json:"assume_compromised"`
	} `json:"simulation"`
}

// verifySubset runs subset_verifier.py on one folder and returns its exit
// status and report (nil when it printed none).
func verifySubset(t *testing.T, interpreter string, args ...string) (int, *subsetReport, string) {
	t.Helper()
	cmd := exec.Command(interpreter, append([]string{filepath.Join("..", "subset_verifier.py")}, args...)...)
	var stdout, stderr bytes.Buffer
	cmd.Stdout, cmd.Stderr = &stdout, &stderr
	err := cmd.Run()
	code := 0
	if exit, ok := err.(*exec.ExitError); ok {
		code = exit.ExitCode()
	} else if err != nil {
		t.Fatal(err)
	}
	var report subsetReport
	if json.Unmarshal(stdout.Bytes(), &report) != nil {
		return code, nil, stderr.String()
	}
	return code, &report, stderr.String()
}

// TestSubsetVerifierCLI checks the single-folder mode: exit statuses, the
// unbound-flags option, anchors, the simulation label and edits the subset
// must catch without any help from the Go verifier.
func TestSubsetVerifierCLI(t *testing.T) {
	interpreter := python()
	if interpreter == "" {
		t.Skip("no Python 3 interpreter on PATH")
	}
	bound, unbound := fixtureBases(t)
	keys, head, err := folderPins(bound)
	if err != nil {
		t.Fatal(err)
	}
	expectFailing := func(report *subsetReport, check string) {
		t.Helper()
		for _, id := range report.FailingChecks {
			if id == check {
				return
			}
		}
		t.Errorf("failing checks %v, want %s among them", report.FailingChecks, check)
	}

	if code, report, stderr := verifySubset(t, interpreter, bound, "--expect-keys", keys, "--expect-head", head); code != 0 || report == nil || report.Verdict != "PASSED" {
		t.Fatalf("clean bound run: exit %d, report %+v, %s", code, report, stderr)
	}
	if code, report, _ := verifySubset(t, interpreter, unbound, "--unbound-flags"); code != 0 || report.Verdict != "PASSED" {
		t.Fatalf("clean unbound run with --unbound-flags: exit %d, %+v", code, report)
	}
	// The original (pre-revision) runs in both modes: no false alarm on a
	// human-approved capability or a run without a policy snapshot.
	for _, mode := range []string{fixture.EscalationHuman, fixture.EscalationFlag} {
		dir := filepath.Join(t.TempDir(), mode)
		if _, err := fixture.WriteWith(dir, fixture.Options{Escalation: mode}); err != nil {
			t.Fatal(err)
		}
		if code, report, stderr := verifySubset(t, interpreter, dir); code != 0 || report.Verdict != "PASSED" {
			t.Fatalf("clean %s-mode fixture run: exit %d, %+v %s", mode, code, report, stderr)
		}
	}
	// Without --unbound-flags the ablated decision values bind no flag.
	code, report, _ := verifySubset(t, interpreter, unbound)
	if code != 1 || report.Verdict != "FAILED" {
		t.Fatalf("unbound run without --unbound-flags: exit %d, %+v", code, report)
	}
	expectFailing(report, "op.requires_policy")
	// Wrong pins.
	code, report, _ = verifySubset(t, interpreter, bound, "--expect-keys", strings.Repeat("0", 64), "--expect-head", strings.Repeat("1", 64))
	if code != 1 {
		t.Fatalf("wrong pins: exit %d", code)
	}
	expectFailing(report, "keys.anchor")
	expectFailing(report, "head.anchor")
	// The simulation is labelled, and an unknown role is a usage error.
	if code, report, _ := verifySubset(t, interpreter, bound, "--assume-compromised", "adapter,audit_log"); code != 0 || report.Simulation == nil ||
		strings.Join(report.Simulation.AssumeCompromised, ",") != "AUDIT_LOG,ADAPTER" {
		t.Fatalf("simulation: exit %d, %+v", code, report)
	}
	if code, _, stderr := verifySubset(t, interpreter, bound, "--assume-compromised", "ISSUER"); code != 2 || !strings.Contains(stderr, "unknown role") {
		t.Fatalf("unknown role: exit %d, %s", code, stderr)
	}

	// An edited value in one entry: its hash no longer matches.
	edited := filepath.Join(t.TempDir(), "edited")
	if err := copyRunFiles(bound, edited); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(edited, audit.LogFile)
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, bytes.Replace(data, []byte(`"outcome":"ok"`), []byte(`"outcome":"OK"`), 1), 0o644); err != nil {
		t.Fatal(err)
	}
	code, report, _ = verifySubset(t, interpreter, edited)
	if code != 1 {
		t.Fatalf("edited entry: exit %d", code)
	}
	expectFailing(report, "chain.entry_hash")
	// A rewritten policy snapshot (one limit raised) under a simulated audit
	// key: the recomputed policy hash differs from what the issuer signed.
	snap := filepath.Join(t.TempDir(), "snapshot")
	if err := copyRunFiles(bound, snap); err != nil {
		t.Fatal(err)
	}
	runPath := filepath.Join(snap, audit.RunFile)
	runData, err := os.ReadFile(runPath)
	if err != nil {
		t.Fatal(err)
	}
	var record map[string]any
	if err := json.Unmarshal(runData, &record); err != nil {
		t.Fatal(err)
	}
	snapshot, _ := record["policy_snapshot"].(map[string]any)
	limit, ok := snapshot["max_recipients"].(float64)
	if !ok {
		t.Fatal("the fixture's policy snapshot has no max_recipients")
	}
	snapshot["max_recipients"] = limit + 1
	changed, err := json.MarshalIndent(record, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(runPath, changed, 0o644); err != nil {
		t.Fatal(err)
	}
	code, report, _ = verifySubset(t, interpreter, snap, "--assume-compromised", "AUDIT_LOG")
	if code != 1 {
		t.Fatalf("rewritten snapshot: exit %d", code)
	}
	expectFailing(report, "policy.snapshot_bound")
	expectFailing(report, "files.run_record")
	if code, _, _ := verifySubset(t, interpreter, filepath.Join(t.TempDir(), "missing")); code != 2 {
		t.Fatalf("missing folder: exit %d, want 2", code)
	}
}

// TestDetailEditIsCaughtByTheClassificationBinding: an audit-key holder
// (simulated) who removes the flag from the log details only, leaving the
// decision values alone, is caught by op.requires_policy in the bound design
// by both verifiers. The engine's mutants never do this (it keeps details and
// values consistent, so signatures catch them), so the corpus alone does not
// exercise this comparison. The unbound design reads the flag from the
// details: both verifiers must agree there too.
func TestDetailEditIsCaughtByTheClassificationBinding(t *testing.T) {
	interpreter := python()
	if interpreter == "" {
		t.Skip("no Python 3 interpreter on PATH")
	}
	for _, unbound := range []bool{false, true} {
		dir := filepath.Join(t.TempDir(), "run")
		written, err := fixture.WriteWith(dir, fixture.Options{Revision: true, UnboundFlags: unbound})
		if err != nil {
			t.Fatal(err)
		}
		target := written.Operations["flagged"]
		err = fixture.RewriteWithoutKey(dir, func(entries []fixture.Entry) []fixture.Entry {
			for i := range entries {
				e := &entries[i]
				if e.OperationID != target {
					continue
				}
				switch e.Stage {
				case "POLICY_DECISION":
					e.Outcome = "allow"
					e.Details["flagged"] = false
					delete(e.Details, "reasons")
				case "POLICY_FINAL", "CALL_RESULT":
					if _, ok := e.Details["flagged"]; ok {
						e.Details["flagged"] = false
					}
				}
			}
			return entries
		})
		if err != nil {
			t.Fatal(err)
		}
		roles := []string{auditverify.CompromiseAuditLog}
		report, err := auditverify.VerifyRun(dir, auditverify.Options{AssumeCompromised: roles, DisableChecks: noReplay, UnboundFlags: unbound})
		if err != nil {
			t.Fatal(err)
		}
		args := []string{dir, "--assume-compromised", "AUDIT_LOG"}
		if unbound {
			args = append(args, "--unbound-flags")
		}
		_, subset, stderr := verifySubset(t, interpreter, args...)
		if subset == nil {
			t.Fatalf("no subset report: %s", stderr)
		}
		goFailed, subsetFailed := report.Verdict == auditverify.VerdictFailed, subset.Verdict == "FAILED"
		t.Logf("unbound=%t: Go %s %v, subset %s %v", unbound, report.Verdict, failingCheckIDs(report), subset.Verdict, subset.FailingChecks)
		if goFailed != subsetFailed {
			t.Fatalf("unbound=%t: Go %s, subset %s", unbound, report.Verdict, subset.Verdict)
		}
		if unbound {
			// The ablation reads the flag from the details, so both accept.
			if report.Verdict != auditverify.VerdictVerified || subset.Verdict != "PASSED" {
				t.Fatalf("unbound design: Go %s %v, subset %s %v; want VERIFIED and PASSED", report.Verdict, failingCheckIDs(report), subset.Verdict, subset.FailingChecks)
			}
			continue
		}
		if !slices.Contains(failingCheckIDs(report), auditverify.CheckRequiresPolicy) {
			t.Fatalf("bound design: Go did not catch the detail edit with op.requires_policy (%v)", failingCheckIDs(report))
		}
		if !subsetFailed || !slices.Contains(subset.FailingChecks, "op.requires_policy") {
			t.Fatalf("bound design: the detail edit was not caught by op.requires_policy (%v)", subset.FailingChecks)
		}
	}
}

// TestSubsetVerifierSelfTest runs the Python verifier's own vector checks.
func TestSubsetVerifierSelfTest(t *testing.T) {
	interpreter := python()
	if interpreter == "" {
		t.Skip("no Python 3 interpreter on PATH")
	}
	output, err := exec.Command(interpreter, filepath.Join("..", "subset_verifier.py"), "--self-test").CombinedOutput()
	if err != nil || !strings.Contains(string(output), "self-test: passed") {
		t.Fatalf("subset_verifier.py --self-test: %v\n%s", err, output)
	}
}
