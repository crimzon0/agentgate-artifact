#!/usr/bin/env python3
"""Quick check of the central result (README). Standard library only.
    python docs/paper/artifact/quick_check.py OUT [REFERENCE_DIR]
OUT: written by `agentgate-eval compromise -runs 1 -out OUT` (and optionally by
`analyze_compromise.py OUT`); REFERENCE_DIR defaults to docs/paper/data/build3/compromise
(the evaluated build). An attack is one edit type, key set and anchor condition
(7 x 12 x 4 = 336 per verifier setting), verified in both designs. Binding changed the
outcome of an attack if the bound design detects it and the unbound design accepts it
(strongest attacker). The script counts these per verifier setting over all 336
attacks, over the 168 without a head anchor and over the 168 with one, counts
detections per design over 336 and over the 168 without a head anchor, and compares
every result (attack x design x setting) with the record. Exit 0 if all match, else 1.
It reads data only; it never signs or verifies evidence."""
import csv, os, sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
SETTINGS = ("full", "no-snapshot-bound-only", "no-replay", "no-replay-no-snapshot")
# Outcomes changed by binding, of 336 attacks; every one is among the 168 without a head anchor.
EXPECTED_FLIPS = {"full": 0, "no-snapshot-bound-only": 8, "no-replay": 12, "no-replay-no-snapshot": 12}
EXPECTED_DISTINCT_NO_REPLAY = 6   # edit type x key set, keys anchor collapsed
# Detected attacks per design (bound, unbound): of 336, and of the 168 without a head anchor.
EXPECTED_DETECTED = {"full": ((313, 313), (145, 145)), "no-snapshot-bound-only": ((313, 305), (145, 137)),
                     "no-replay": ((295, 283), (127, 115)), "no-replay-no-snapshot": ((295, 283), (127, 115))}
EXPECTED_ORACLE = {("full", "strongest", "primary"): 514, ("full", "strongest", "snapshot_bound+mode_checked"): 540,
                   ("no-snapshot-bound-only", "strongest", "mode_checked"): 536, ("no-replay", "strongest", "mode_checked"): 560}
CELL = ("design", "mode", "operator", "keyset", "anchors", "verifier_config")
NO_HEAD = ("none", "keys")


def outcomes(path):
    """result -> set of (detected, evading variants, plain detected) over all runs."""
    seen = defaultdict(set)
    with open(path, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            seen[tuple(r[k] for k in CELL)].add((r["detected"], r["evading_variants"], r["plain_detected"]))
    return seen


def detected(out):
    return bool(out) and all(o[0] == "true" for o in out)


def accepted(out):
    return bool(out) and all(o[0] == "false" for o in out)


def flips(cells):
    """Changed outcomes per setting: all 336, the 168 without a head anchor, the 168 with one; distinct no-replay pairs."""
    every, no_head, head, pairs = defaultdict(int), defaultdict(int), defaultdict(int), set()
    for (design, mode, op, ks, anchors, cfg), out in cells.items():
        if design != "bound" or not detected(out):
            continue
        if accepted(cells.get(("unbound", mode, op, ks, anchors, cfg), set())):
            every[cfg] += 1
            if anchors in NO_HEAD:
                no_head[cfg] += 1
                if cfg == "no-replay":
                    pairs.add((op, ks))
            else:
                head[cfg] += 1
    return every, no_head, head, len(pairs)


def detections(cells):
    """(design, setting) -> (detected of all attacks, detected of those without a head anchor, attacks)."""
    det, det_nh, total = defaultdict(int), defaultdict(int), defaultdict(int)
    for (design, mode, op, ks, anchors, cfg), out in cells.items():
        total[(design, cfg)] += 1
        if detected(out):
            det[(design, cfg)] += 1
            if anchors in NO_HEAD:
                det_nh[(design, cfg)] += 1
    return det, det_nh, total


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    out = sys.argv[1]
    ref = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, "..", "data", "build3", "compromise")
    problems = []
    mine, recorded = outcomes(os.path.join(out, "strongest.csv")), outcomes(os.path.join(ref, "strongest.csv"))
    unstable = [c for c, o in mine.items() if len(o) > 1]
    differ = [c for c in recorded if mine.get(c) != recorded[c]]
    print("results: %d here, %d recorded; unstable here: %d; outcome differs from the record: %d"
          % (len(mine), len(recorded), len(unstable), len(differ)))
    problems += ["result differs: %s" % "/".join(c) for c in differ[:10]] + (["unstable results"] if unstable else [])
    every, no_head, head, distinct = flips(mine)
    for cfg in SETTINGS:
        want = EXPECTED_FLIPS[cfg]
        print("changed by binding, %-23s %2d of 336 attacks; %2d of the 168 without a head anchor; %d of the 168 with one (recorded %d, %d, 0)"
              % (cfg, every[cfg], no_head[cfg], head[cfg], want, want))
        if (every[cfg], no_head[cfg], head[cfg]) != (want, want, 0):
            problems.append("changed by binding %s: %d / %d / %d, expected %d / %d / 0" % (cfg, every[cfg], no_head[cfg], head[cfg], want, want))
    print("distinct pairs of edit type and key set changed without replay: %d (recorded %d)" % (distinct, EXPECTED_DISTINCT_NO_REPLAY))
    problems += ["distinct pairs"] * (distinct != EXPECTED_DISTINCT_NO_REPLAY)
    det, det_nh, total = detections(mine)
    for cfg in SETTINGS:
        (wb, wu), (wbn, wun) = EXPECTED_DETECTED[cfg]
        got = (det[("bound", cfg)], det[("unbound", cfg)], det_nh[("bound", cfg)], det_nh[("unbound", cfg)])
        print("detected, bound / unbound, %-23s %3d / %3d of %d; no head anchor %3d / %3d of 168 (recorded %d / %d; %d / %d)"
              % (cfg, got[0], got[1], total[("bound", cfg)], got[2], got[3], wb, wu, wbn, wun))
        if got != (wb, wu, wbn, wun) or total[("bound", cfg)] != 336 or total[("unbound", cfg)] != 336:
            problems.append("detections %s" % cfg)
    agreement = os.path.join(out, "oracle_agreement.csv")
    if os.path.exists(agreement):   # written by analyze_compromise.py
        with open(agreement, newline="", encoding="utf-8") as f:
            got = {(r["verifier_config"], r["attacker"], r["reading"]): int(r["agree"]) for r in csv.DictReader(f)}
        for key, want in EXPECTED_ORACLE.items():
            print("oracle agreement %-58s %s of 560 labelled results (recorded %d)" % ("/".join(key), got.get(key), want))
            problems += ["oracle %s" % "/".join(key)] * (got.get(key) != want)
    print("RESULT:", "PASS" if not problems else "FAIL\n  " + "\n  ".join(problems))
    sys.exit(0 if not problems else 1)


if __name__ == "__main__":
    main()
