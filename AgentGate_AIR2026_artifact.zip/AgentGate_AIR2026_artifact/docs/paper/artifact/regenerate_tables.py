#!/usr/bin/env python3
"""Recompute the paper's tables and numbers from the recorded data of one frozen
build and compare them with docs/paper/artifact/EXPECTED_TABLES.md.

    python docs/paper/artifact/regenerate_tables.py [DATA_DIR] [--expected FILE]
        [--loc FILE] [--quiet] [--json OUT]

DATA_DIR is the data folder of the build (default docs/paper/data/build3, the
evaluated build; an earlier build's folder can be given, but EXPECTED_TABLES.md
holds build-3 values). FILE defaults to
docs/paper/artifact/EXPECTED_TABLES.md; --loc to docs/paper/artifact/loc_<name of
DATA_DIR>.csv (Supplementary S1), when it exists.

For each number it recomputes, the script reads the CSV and JSON files the
experiments wrote (never their Markdown reports), counts or averages them
itself, and compares the result with the number printed in EXPECTED_TABLES.md:
the numbers of one table cell, in the order the cell prints them, against the
recomputed values. Decimal values are compared at the precision the document
prints (half-up or half-even rounding both accepted); a few totals that the
document adds from rounded parts carry a stated tolerance. A row is found by its
section heading and its first cell, a value by its column header, so an edited
document is checked as written. The few numbers that are constants of this
script rather than data (a formula's literal such as the 1 of "1 / (6 x 1.75
ms)", or a selection such as Little's law's 16 clients) are compared too, marked
with * and counted separately, not as recomputed values.

Every table row of EXPECTED_TABLES.md is either checked or listed at the end as
"not recomputed", with the reason: numbers that come from the real-key tests and
the other fixture tests (rows marked "go test"; each test asserts its own counts,
see README.md), numbers that come from prose, code or an earlier build, and rows
that repeat a checked number (version crosswalk).

Exit status: 0 when every recomputed number matches; 1 when a number differs, a
claim does not hold, a row the script needs is missing from the document or has
fewer numbers than expected, a data file cannot be read, or the document has a
Supplementary S1 row and there is no code-line CSV; 2 when the data folder, the
document or a --loc file given on the command line does not exist. It reads
files only: it never runs a binary, signs, or verifies evidence. Standard
library only.
"""

import argparse
import csv
import json
import re
import statistics
import sys
from collections import Counter, defaultdict
from decimal import ROUND_HALF_EVEN, ROUND_HALF_UP, Decimal, InvalidOperation
from functools import lru_cache
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
SETTINGS = ("full", "no-snapshot-bound-only", "no-replay", "no-replay-no-snapshot")
NO_HEAD = ("none", "keys")
POOL_FROM_CLIENTS = 4   # V-F: throughput "from 4 clients up"


# --- the document ---------------------------------------------------------------

def norm(text):
    """A table cell or heading without Markdown emphasis and code marks."""
    return re.sub(r"\s+", " ", text.replace("`", "").replace("**", "")).strip()


def split_row(line):
    body = line.strip()
    if body.startswith("|"):
        body = body[1:]
    if body.endswith("|"):
        body = body[:-1]
    cells, cur, i = [], "", 0
    while i < len(body):
        ch = body[i]
        if ch == "\\" and i + 1 < len(body) and body[i + 1] == "|":
            cur += "|"
            i += 2
            continue
        if ch == "|":
            cells.append(cur.strip())
            cur = ""
        else:
            cur += ch
        i += 1
    cells.append(cur.strip())
    return cells


class Doc:
    """The tables of EXPECTED_TABLES.md, by section heading and first cell."""

    def __init__(self, path):
        self.path = path
        self.rows = []      # (section, headers, cells)
        section, headers, previous = "", None, ""
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.startswith("## "):
                section, headers = norm(line[3:]), None
                continue
            if not line.startswith("|"):
                headers, previous = None, ""
                continue
            cells = split_row(line)
            if all(re.fullmatch(r":?-{3,}:?", c) for c in cells if c):
                headers = [norm(c) for c in split_row(previous)]
                continue
            if headers is not None:
                self.rows.append((section, headers, cells))
            previous = line
        self.used = set()

    def find(self, section, key):
        """The one row whose section heading starts with `section` and whose
        first cell is `key` (or starts with `key` followed by a space)."""
        cands = [r for r in self.rows if r[0].startswith(section)]
        exact = [r for r in cands if norm(r[2][0]) == key]
        if not exact:
            exact = [r for r in cands if norm(r[2][0]).startswith(key + " ")]
        if len(exact) != 1:
            raise LookupError("%d rows for %r in section %r" % (len(exact), key, section))
        self.used.add((exact[0][0], norm(exact[0][2][0])))
        return exact[0]

    def cell(self, section, key, column):
        sec, headers, cells = self.find(section, key)
        if column is None:
            return cells[0]
        name, _, nth = column.partition("#")
        found = [i for i, h in enumerate(headers) if h == name or h.startswith(name)]
        if len(found) >= int(nth or 1):
            i = found[int(nth or 1) - 1]
            return cells[i] if i < len(cells) else ""
        raise LookupError("no column %r in section %r (columns: %s)" % (column, sec, ", ".join(headers)))


NUM_RE = re.compile(r"(?<![\w.#§$])(\d{1,3}(?:,\d{3})+|\d+)(\.\d+)?(?!\w)")


def numbers(text):
    """The numbers a cell prints, in order, as decimal strings: thousands
    separators dropped, a minus sign kept only where it is not a range dash.
    Tokens glued to letters (R2, M1, S1, run2, hashes) are not numbers."""
    out = []
    for m in NUM_RE.finditer(text):
        token = m.group(1).replace(",", "") + (m.group(2) or "")
        start = m.start()
        if start > 0 and text[start - 1] == "-" and (start == 1 or not text[start - 2].isalnum()):
            token = "-" + token
        out.append(token)
    return out


def matches(doc_token, value, tol=None):
    try:
        want = Decimal(doc_token)
        got = Decimal(str(value))
    except (InvalidOperation, ValueError):
        return False
    if tol is not None:
        return abs(got - want) <= Decimal(str(tol))
    places = -want.as_tuple().exponent if want.as_tuple().exponent < 0 else 0
    quantum = Decimal(1).scaleb(-places)
    return any(got.quantize(quantum, rounding=mode) == want for mode in (ROUND_HALF_UP, ROUND_HALF_EVEN))


# --- the report -------------------------------------------------------------------

class Report:
    def __init__(self, doc, quiet=False):
        self.doc, self.quiet = doc, quiet
        self.results = []   # dicts
        self.numbers_checked = 0      # values recomputed from the data, and claims
        self.constants_compared = 0   # constants of this script compared with the document (Report.num `fixed`)

    def _emit(self, ok, label, detail):
        self.results.append({"ok": ok, "label": label, "detail": detail})
        if not ok or not self.quiet:
            print("  [%s] %s: %s" % ("OK" if ok else "MISMATCH", label, detail))

    def num(self, section, key, column, values, idx=None, tol=None, note="", fixed=()):
        """Compare the numbers of one cell (positions idx, default all) with values.

        `fixed` lists the indexes into `values` that are constants of this
        script (a selection or a formula's literal, such as the 16 clients of
        Little's law), not values read from the data: they are compared with
        the document like the others but not counted as recomputed."""
        label = "%s / %s / %s" % (section, key, column or "row label")
        try:
            text = self.doc.cell(section, key, column)
        except LookupError as err:
            self._emit(False, label, "row not found in %s (%s)" % (self.doc.path.name, err))
            return
        doc_nums = numbers(text)
        positions = list(range(len(values))) if idx is None else list(idx)
        if len(positions) != len(values) or (positions and max(positions) >= len(doc_nums)):
            self._emit(False, label, "the cell prints %s; expected %d numbers at positions %s"
                       % (doc_nums, len(values), positions))
            return
        if isinstance(tol, (int, float)) or tol is None:
            tols = [tol] * len(values)
        else:
            tols = list(tol)
        picked = [doc_nums[p] for p in positions]
        ok = all(matches(d, v, t) for d, v, t in zip(picked, values, tols))
        self.numbers_checked += len(values) - len(set(fixed))
        self.constants_compared += len(set(fixed))
        shown = ", ".join(fmt(v) + ("*" if i in fixed else "") for i, v in enumerate(values))
        notes = ([note] if note else []) + (["* constant of this script, not read from the data"] if fixed else [])
        extra = (" (" + "; ".join(notes) + ")") if notes else ""
        self._emit(ok, label, "document %s | data %s%s" % (", ".join(picked), shown, extra))

    def text(self, section, key, column, want, got, note=""):
        """Compare a non-numeric cell (already reduced to a canonical form)."""
        label = "%s / %s / %s" % (section, key, column)
        ok = want == got
        self.numbers_checked += 1
        self._emit(ok, label, "document %r | data %r%s" % (want, got, (" (" + note + ")") if note else ""))

    def claim(self, label, holds, detail="", row=None):
        """A statement of the document without a number to compare; `row`
        (section, first cell) names the document row that makes it."""
        if row is not None:
            try:
                self.doc.find(*row)
            except LookupError as err:
                self._emit(False, "claim: " + label, "row not found in %s (%s)" % (self.doc.path.name, err))
                return
        self.numbers_checked += 1
        self._emit(bool(holds), "claim: " + label, ("holds" if holds else "DOES NOT HOLD") + ((" (" + detail + ")") if detail else ""))

    def missing_data(self, label, err):
        self._emit(False, label, "data not readable: %s" % err)

    @property
    def failures(self):
        return [r for r in self.results if not r["ok"]]


def fmt(v):
    if isinstance(v, (float, Decimal)) and v != int(v):
        text = "%.4f" % Decimal(str(v)).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)
        return text.rstrip("0").rstrip(".")
    return str(int(v)) if isinstance(v, (float, Decimal)) else str(v)


# --- data access --------------------------------------------------------------------

class Data:
    def __init__(self, root):
        self.root = root

    @lru_cache(maxsize=None)
    def csv(self, rel):
        with open(self.root / rel, newline="", encoding="utf-8") as f:
            return list(csv.DictReader(f))

    @lru_cache(maxsize=None)
    def tsv(self, rel):
        with open(self.root / rel, newline="", encoding="utf-8") as f:
            return list(csv.DictReader(f, delimiter="\t"))

    @lru_cache(maxsize=None)
    def json(self, rel):
        return json.loads((self.root / rel).read_text(encoding="utf-8"))

    def text(self, rel):
        return (self.root / rel).read_text(encoding="utf-8")


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def ms(us):
    """Microseconds (as recorded) to milliseconds, exact decimal."""
    return Decimal(str(us)) / 1000


# --- key-compromise grid --------------------------------------------------------

ROLE_LETTER = {"audit": "A", "issuer": "I", "adapter": "X", "provider": "P", "delegation": "D", "approval": "Ap"}
ROLE_ORDER = ["audit", "issuer", "adapter", "provider", "delegation", "approval"]


def keyset_roles(name):
    if name == "none":
        return frozenset()
    if name == "all-stolen":
        return frozenset(ROLE_ORDER)
    if name == "all-replaced":
        return None
    return frozenset(name.split("+"))


def keyset_label(roles):
    return "+".join(ROLE_LETTER[r] for r in ROLE_ORDER if r in roles)


class Grid:
    """compromise/strongest.csv: one row per design result and repetition."""

    def __init__(self, data):
        self.rows = data.csv("compromise/strongest.csv")
        self.cells = defaultdict(set)
        self.outcomes = defaultdict(set)
        for r in self.rows:
            key = (r["design"], r["mode"], r["operator"], r["keyset"], r["anchors"], r["verifier_config"])
            self.cells[key].add(r["detected"])
            self.outcomes[key].add((r["detected"], r["evading_variants"], r["plain_detected"]))
        self.runs = sorted({r["run"] for r in self.rows})
        self.operators = sorted({k[2] for k in self.cells})
        self.keysets = sorted({k[3] for k in self.cells})
        self.anchors = sorted({k[4] for k in self.cells})
        self.mode_of = {k[2]: k[1] for k in self.cells}

    def detected(self, design, op, ks, anchors, cfg):
        return self.cells.get((design, self.mode_of[op], op, ks, anchors, cfg)) == {"true"}

    def accepted(self, design, op, ks, anchors, cfg):
        return self.cells.get((design, self.mode_of[op], op, ks, anchors, cfg)) == {"false"}

    def attack_cells(self, cfg, anchors=None):
        return [(op, ks, a) for op in self.operators for ks in self.keysets for a in self.anchors
                if anchors is None or a in anchors]

    def flips(self, cfg, anchors=None):
        return [(op, ks, a) for op, ks, a in self.attack_cells(cfg, anchors)
                if self.detected("bound", op, ks, a, cfg) and self.accepted("unbound", op, ks, a, cfg)]

    def reverse(self, cfg):
        return [(op, ks, a) for op, ks, a in self.attack_cells(cfg)
                if self.accepted("bound", op, ks, a, cfg) and self.detected("unbound", op, ks, a, cfg)]

    def detections(self, design, cfg, anchors=None):
        return sum(self.detected(design, op, ks, a, cfg) for op, ks, a in self.attack_cells(cfg, anchors))

    def unstable(self):
        return [k for k, o in self.outcomes.items() if len(o) > 1]

    def smallest(self, design, op, cfg):
        """Minimal accepted genuine key sets (anchors none), as the paper writes them."""
        accepted = []
        for ks in self.keysets:
            roles = keyset_roles(ks)
            if roles is None:
                continue
            if self.accepted(design, op, ks, "none", cfg):
                accepted.append(roles)
        minimal = [r for r in accepted if not any(o < r for o in accepted)]
        if not minimal:
            return "--"
        return " or ".join(sorted(keyset_label(r) for r in minimal))


def doc_keysets(text):
    """'A+I+X F / A F' -> ('A+I+X', 'A'); '-- (target limit C1)' -> ('--', '--')."""
    text = re.sub(r"\([^)]*\)", "", norm(text))
    parts = [re.sub(r"\bF\b", "", p).strip() for p in text.split(" / ")]
    parts = [re.sub(r"\s+", " ", p) for p in parts]
    return (parts[0], parts[0]) if len(parts) == 1 else (parts[0], parts[1])


# --- the checks -------------------------------------------------------------------------

def check_compromise(rep, data):
    g = Grid(data)
    ops, kss, anchors = len(g.operators), len(g.keysets), len(g.anchors)
    per_setting = len(g.attack_cells("full"))
    no_head = len(g.attack_cells("full", NO_HEAD))
    by_anchor = Counter(a for _, _, a in g.attack_cells("full"))
    flips = {cfg: len(g.flips(cfg)) for cfg in SETTINGS}
    flips_nh = {cfg: len(g.flips(cfg, NO_HEAD)) for cfg in SETTINGS}
    flips_h = {cfg: len(g.flips(cfg, ("head", "both"))) for cfg in SETTINGS}
    flips_by = {cfg: Counter(a for _, _, a in g.flips(cfg)) for cfg in SETTINGS}
    distinct_nr = sorted({(op, ks) for op, ks, a in g.flips("no-replay", NO_HEAD)})
    det = {(d, cfg): g.detections(d, cfg) for d in ("bound", "unbound") for cfg in SETTINGS}
    det_nh = {(d, cfg): g.detections(d, cfg, NO_HEAD) for d in ("bound", "unbound") for cfg in SETTINGS}
    det_h = {(d, cfg): g.detections(d, cfg, ("head", "both")) for d in ("bound", "unbound") for cfg in SETTINGS}
    designs = len({k[0] for k in g.cells})
    settings = len({k[5] for k in g.cells})
    head_cells = per_setting - no_head

    print("\n== Key-compromise grid (compromise/strongest.csv: %d rows, %d repetitions) ==" % (len(g.rows), len(g.runs)))
    U = "Units"
    rep.claim("compromise/strongest.csv holds the bound and unbound designs under the four verifier settings",
              {k[0] for k in g.cells} == {"bound", "unbound"} and {k[5] for k in g.cells} == set(SETTINGS),
              "designs %s; settings %s" % (sorted({k[0] for k in g.cells}), sorted({k[5] for k in g.cells})))
    rep.num(U, "attack", "count", [ops, kss, anchors, per_setting, no_head, by_anchor["none"], by_anchor["keys"], per_setting - no_head])
    rep.num(U, "outcome changed by binding", "count", [flips["full"], flips["no-snapshot-bound-only"], flips["no-replay"], flips["no-replay-no-snapshot"], per_setting, no_head])
    rep.num(U, "result", "count", [per_setting * designs, per_setting * designs * settings, settings, len(g.runs), len(g.rows)])
    oracle = {(r["verifier_config"], r["attacker"], r["reading"]): r for r in data.csv("compromise/oracle_agreement.csv")}
    labelled = int(oracle[("full", "strongest", "primary")]["total_cells"])
    labelled_keysets = labelled // (ops * anchors * designs)
    rep.num(U, "labelled result", "count", [ops, labelled_keysets, anchors, designs, labelled, labelled // designs, designs])

    H = "Headline numbers"
    rep.num(H, "compromise.flips.full", "value", [flips["full"], per_setting, flips_nh["full"], no_head])
    rep.num(H, "compromise.flips.nosnap", "value", [flips["no-snapshot-bound-only"], per_setting, flips_nh["no-snapshot-bound-only"], no_head])
    rep.num(H, "compromise.flips.nosnap", "field / filter",
            [flips["no-snapshot-bound-only"], per_setting, flips_nh["no-snapshot-bound-only"], no_head,
             flips_by["no-snapshot-bound-only"]["none"], flips_by["no-snapshot-bound-only"]["keys"]], idx=range(6))
    rep.num(H, "compromise.flips.noreplay", "value", [flips["no-replay"], per_setting, no_head])
    rep.num(H, "compromise.flips.noreplay", "field / filter",
            [flips["no-replay"], per_setting, flips_nh["no-replay"], no_head, flips_by["no-replay"]["none"], flips_by["no-replay"]["keys"]])
    rep.claim("every attack changed by binding without replay is among the attacks without a head anchor", flips_h["no-replay"] == 0 and flips_nh["no-replay"] == flips["no-replay"])
    rep.num(H, "compromise.flips.noreplay.distinct", "value", [len(distinct_nr)])
    rep.claim("the distinct pairs changed by binding without replay are {strip-flag, invent-flag, change-rules} x {audit, audit+issuer}",
              set(distinct_nr) == {(o, k) for o in ("strip-flag", "invent-flag", "change-rules") for k in ("audit", "audit+issuer")},
              ", ".join("%s/%s" % p for p in distinct_nr))
    rep.num(H, "both checks off (no-replay-no-snapshot)", "value", [flips["no-replay-no-snapshot"], per_setting, flips_nh["no-replay-no-snapshot"], no_head])
    head_all = min(det_h[(d, cfg)] for d in ("bound", "unbound") for cfg in SETTINGS)
    rep.num(H, "head-anchored attacks", "value", [head_all, head_cells, max(flips_h.values())])
    rep.num(H, "detected attacks, bound / unbound, of 336", "value",
            [det[(d, cfg)] for cfg in SETTINGS for d in ("bound", "unbound")])
    acc = [no_head - det_nh[(d, cfg)] for cfg in ("full", "no-snapshot-bound-only", "no-replay") for d in ("bound", "unbound")]
    rep.num(H, "detected, bound / unbound, of the 168 without a head anchor", "value",
            [det_nh[(d, cfg)] for cfg in SETTINGS for d in ("bound", "unbound")] + acc)
    reverse = sum(len(g.reverse(cfg)) for cfg in SETTINGS)
    rep.num(H, "reverse changes", "value", [reverse])

    SA = "Single accounting"
    rows_sa = {"full": "full", "no snapshot check": "no-snapshot-bound-only", "no replay": "no-replay", "both off": "no-replay-no-snapshot"}
    for key, cfg in rows_sa.items():
        acc = {d: (per_setting - det[(d, cfg)], no_head - det_nh[(d, cfg)], head_cells - det_h[(d, cfg)]) for d in ("bound", "unbound")}
        rep.num(SA, key, "changed, of 336", [flips[cfg]])
        rep.num(SA, key, "changed, of the 168 without a head anchor (none + keys)",
                [flips_nh[cfg], flips_by[cfg]["none"], flips_by[cfg]["keys"]])
        rep.num(SA, key, "changed, of the 168 with a head anchor", [flips_h[cfg]])
        rep.num(SA, key, "accepted, bound: all / no head / head", list(acc["bound"]))
        rep.num(SA, key, "accepted, unbound: all / no head / head", list(acc["unbound"]))
        rep.num(SA, key, "reverse", [len(g.reverse(cfg))])
    T3 = "Table III"
    col = {"full": "full", "no snapshot check": "no-snapshot-bound-only", "no replay": "no-replay"}
    rows = {"strip-flag, invent-flag": ("strip-flag", "invent-flag"), "change-rules": ("change-rules",),
            "change-escalation": ("change-escalation",), "swap-decisions": ("swap-decisions",),
            "change-amount": ("change-amount",), "relabel-approved": ("relabel-approved",)}
    for key, operators in rows.items():
        for column, cfg in col.items():
            try:
                want = doc_keysets(rep.doc.cell(T3, key, column))
            except LookupError as err:
                rep._emit(False, "%s / %s / %s" % (T3, key, column), "row not found (%s)" % err)
                continue
            for op in operators:
                got = (g.smallest("bound", op, cfg), g.smallest("unbound", op, cfg))
                rep.text(T3, key, column, want, got, note=op if len(operators) > 1 else "smallest accepted key sets, bound / unbound, anchors none")
    for column, cfg in col.items():
        rep.num(T3, "no head anchor (168): detected, bound / unbound", column, [det_nh[("bound", cfg)], det_nh[("unbound", cfg)]])
        rep.num(T3, "head anchor (168): changed", column, [flips_h[cfg]])
        rep.num(T3, "head anchor (168): detected, bound / unbound", column, [det_h[("bound", cfg)], det_h[("unbound", cfg)]])
        rep.num(T3, "all 336: changed", column, [flips[cfg]])
        rep.num(T3, "all 336: detected, bound / unbound", column, [det[("bound", cfg)], det[("unbound", cfg)]])
    rep.num(T3, "no head anchor (168): changed", "full", [flips_nh["full"]])
    rep.num(T3, "no head anchor (168): changed", "no snapshot check", [flips_nh["no-snapshot-bound-only"]])
    rep.num(T3, "no head anchor (168): changed", "no replay", [flips_nh["no-replay"], len(distinct_nr)])
    primary = {cfg: int(oracle[(cfg, "strongest", "primary")]["agree"]) for cfg in SETTINGS}
    main_row = "oracle agreement, of 560 labelled results: main version"
    rep.num(T3, main_row, "full", [primary["full"]])
    rep.num(T3, main_row, "no snapshot check", [primary["no-snapshot-bound-only"]])
    rep.num(T3, main_row, "no replay", [primary["no-replay"]])
    alt_row = "oracle agreement: alternative versions combined after the run"
    rep.num(T3, alt_row, "full", [int(oracle[("full", "strongest", "snapshot_bound+mode_checked")]["agree"])])
    rep.num(T3, alt_row, "no snapshot check", [int(oracle[("no-snapshot-bound-only", "strongest", "mode_checked")]["agree"])])
    rep.num(T3, alt_row, "no replay", [int(oracle[("no-replay", "strongest", "mode_checked")]["agree"])])
    same = all(g.smallest(d, op, "no-replay") == g.smallest(d, op, "no-replay-no-snapshot") for d in ("bound", "unbound") for op in g.operators)
    same = same and flips["no-replay"] == flips["no-replay-no-snapshot"] and all(
        det[(d, "no-replay")] == det[(d, "no-replay-no-snapshot")] and det_nh[(d, "no-replay")] == det_nh[(d, "no-replay-no-snapshot")]
        for d in ("bound", "unbound"))
    rep.claim("Table III: both checks off matched no replay in every row", same)

    V = "In-text numbers of V intro"
    rep.num(V, "12 key sets; 4 anchor conditions; 7 edit types", None, [kss, anchors, ops])
    rep.num(V, "compromise.stable", "value", [len(g.runs), len(g.unstable()), per_setting * designs * settings, per_setting, designs, settings])
    analysis = data.json("compromise/analysis.json")
    rep.claim("compromise/analysis.json unstable_cells is empty", analysis.get("unstable_cells") == [])
    single = ("none", "issuer", "adapter", "provider", "delegation")
    single_ok = all(g.detected(d, op, ks, a, cfg) for d in ("bound", "unbound") for op in g.operators for ks in single
                    for a in g.anchors for cfg in SETTINGS)
    acc_sets = {ks for (d, m, op, ks, a, cfg), o in g.cells.items() if o != {"true"}}
    rep.claim("no single key but the audit key got an edit accepted (single-key sets always detected; accepted only with audit or all-replaced)",
              single_ok and all("audit" in ks or ks in ("all-stolen", "all-replaced") for ks in acc_sets),
              "key sets with an accepted design result: " + ", ".join(sorted(acc_sets)),
              row=(V, "no single key but the audit key got an edit accepted"))
    rep.claim("relabel-approved without replay is accepted with A+I+X (no approval key) in both designs",
              all(g.smallest(d, "relabel-approved", "no-replay") == "A+I+X" for d in ("bound", "unbound")),
              row=(V, "human approval: relabel-approved without replay passed with A+I+X (no approval key)"))
    mism = [r for r in data.csv("compromise/oracle_mismatches.csv")
            if r["verifier_config"] == "full" and r["attacker"] == "strongest" and r["reading"] == "primary"]
    cause = Counter(r["cause"] for r in mism)
    rep.num(V, "compromise.oracle.mismatch.total / .snapshot / .mode / .targets", "value",
            [len(mism), cause["S1"], cause["A3"], cause["C1"] + cause["C2"], cause["C1"], cause["C2"]])
    rep.num(V, "compromise.oracle.mismatch.total / .snapshot / .mode / .targets", "field", [cause["S1"], cause["A3"], cause["C1"], cause["C2"]])
    rep.num(V, "oracle agreement 514 / 540", None, [primary["full"], int(oracle[("full", "strongest", "snapshot_bound+mode_checked")]["agree"])])
    controls = data.csv("compromise/controls.csv")
    base = data.csv("compromise/base_controls.csv")
    ok_controls = sum(r["verdict"] == "VERIFIED" for r in controls)
    rep.num(V, "compromise.controls.ok / .total", "value", [ok_controls, len(controls)])
    rep.num(V, "compromise.controls.ok / .total", "population",
            [len(base), len({r["simulation"] for r in controls}), len({r["anchors"] for r in controls}), len({r["verifier_config"] for r in controls})])

    # Replacement and all-stolen key sets (strongest attacker), per anchor condition.
    def repl(ks, cfg, a):
        return sum(g.detected(d, op, ks, a, cfg) for d in ("bound", "unbound") for op in g.operators)
    pairs = designs * ops
    B = "In-text numbers of V-B"
    rep.num(B, "replacement keys, detection framing", "value",
            [repl("all-replaced", "full", "none"), pairs, repl("all-replaced", "no-replay", "none"), pairs,
             min(repl("all-replaced", "full", "keys"), repl("all-replaced", "full", "head")), pairs,
             repl("all-stolen", "full", "keys"), pairs, repl("all-stolen", "full", "head"), pairs])
    rep.num(B, "replacement keys, detection framing", "field",
            [pairs, pairs - repl("all-replaced", "full", "none"), pairs - repl("all-replaced", "no-replay", "none")])
    T2 = "Table II"
    rep.num(T2, "P6 evidence", "value", [min(repl("all-replaced", "full", a) for a in ("keys", "head", "both")), pairs, repl("all-replaced", "full", "none"), pairs])
    rep.num(T2, "P6 counterexample", "value", [repl("all-stolen", "full", "keys"), pairs, repl("all-stolen", "full", "head"), pairs])
    rep.claim("P6: with all genuine keys stolen a keys anchor adds nothing (keys = none)", repl("all-stolen", "full", "keys") == repl("all-stolen", "full", "none"))
    rep.claim("P3 (grid part; the RS/RB M4 parts are real-key tests): change-amount is accepted only with audit+issuer+adapter+provider (or all genuine keys) in every setting",
              all(g.smallest(d, "change-amount", cfg) == "A+I+X+P" for d in ("bound", "unbound") for cfg in SETTINGS),
              row=(T2, "P3 evidence"))
    rep.claim("P2 counterexample: with the full verifier a snapshot forger with A+I+X passes strip-/invent-flag in both designs (no head anchor)",
              all(g.accepted(d, op, "audit+issuer+adapter", "none", "full") for d in ("bound", "unbound") for op in ("strip-flag", "invent-flag")),
              row=(T2, "P2 counterexample"))
    C = "VIII Conclusion"
    rep.num(C, "conclusion: binding changed outcomes", "value", [flips["full"], per_setting, flips_nh["full"], no_head, flips["no-replay"], per_setting, no_head])


def check_fixture_studies(rep, data):
    print("\n== Fixture studies (fixture-studies/) ==")
    life = data.csv("fixture-studies/lifecycle.csv")
    l3 = [r for r in life if r["test"] == "TestLifecycleL3AuditIssuerConversionWithoutReplay" and "converted" in r["label"]]
    op_of = lambda r: r["label"].split()[1]
    a_rows = [r for r in l3 if r["key_set"] == "A+status"]
    ai_rows = [r for r in l3 if r["key_set"] == "A+I+status"]
    ops = sorted({op_of(r) for r in l3})
    a_det_ops = [o for o in ops if all(r["verdict"] == "FAILED" for r in a_rows if op_of(r) == o)]
    ai_acc_ops = [o for o in ops if all(r["verdict"] == "VERIFIED" for r in ai_rows if op_of(r) == o)]
    ai_acc = sum(r["verdict"] == "VERIFIED" for r in ai_rows)
    l4 = [r for r in life if r["test"] == "TestLifecycleL4FullVerifierAllReconciled" and r["key_set"] == "A+I+status"]
    l4_acc = sum(r["verdict"] == "VERIFIED" for r in l4)
    l4_ops = sorted({op_of(r) for r in l4})
    l4_settings = sorted({r["verifier_setting"] for r in l4})
    ch = [r for r in life if r["test"] == "TestLifecycleConflictingHistories"]
    ch_det = sum(r["verdict"] == "FAILED" for r in ch)
    H = "Headline numbers"
    rep.num(H, "reconciliation path: A+I with a signed status reply accepted", "value",
            [len(ai_acc_ops), len(ops), ai_acc, len(ai_rows), len(l4_ops), len(l4_settings), l4_acc, len(l4)], idx=range(8))
    V = "In-text numbers of V intro"
    rep.num(V, "lifecycle.L3.A_detected / .AI_accepted", "value",
            [len(a_det_ops), len(ops), len(ai_acc_ops), len(ops), ai_acc, len(ai_rows)])
    rep.num(V, "lifecycle.L4.accepted", "value", [len(l4_settings), l4_acc, len(l4)])
    rep.num(V, "histories: 21 of 27 detected, 6 accepted", "value", [len(ch), ch_det, len(ch) - ch_det], idx=range(3))
    ks = data.json("fixture-studies/extra_keysets_summary.json")
    rep.num(V, "keysets.combinations / .pairs / .verifications (archive only)", "value",
            [ks["independent_cells"], ks["independent_cell_variant_pairs"], ks["independent_verifications"]])
    t = ks["tallies"]["cells"]
    rep.num(V, "keysets.AX_eq_A / AP_eq_A / I+X accepted (archive only)", "value",
            [t["ax_equals_a"], t["ax_equals_a_of"], t["ap_equals_a"], t["ap_equals_a_of"], t["accepted_IX"], t["total"]])
    # The fixture key-set simulation uses the grid's operators and designs; its
    # summary gives the settings and, per setting and key set, "accepted/cells".
    grid = data.csv("compromise/strongest.csv")
    operators, designs = len({r["operator"] for r in grid}), len({r["design"] for r in grid})
    per_setting = ks["accepted_cells_per_setting"]
    denominators = {int(v.split("/")[1]) for by_keyset in per_setting.values() for v in by_keyset.values()}
    rep.num("Units", "edit-design-setting combination", "count", [operators, designs, len(per_setting), ks["independent_cells"]])
    rep.claim("the key-set simulation's cells are operators x designs per setting, over every setting",
              denominators == {operators * designs} and operators * designs * len(per_setting) == ks["independent_cells"],
              "cells per setting %s; %d settings; %d cells" % (sorted(denominators), len(per_setting), ks["independent_cells"]))
    sim = data.csv("fixture-studies/simulation_agreement.csv")
    log = data.text("compromise/validation_sim_vs_real.txt")
    passed = "--- PASS: TestSimulationAgreesWithRealAuditKeyResigning" in log
    rep.num(V, "resign.audit.agree", "value", [len(sim) if passed else 0, len(sim)])


def check_custody(rep, data):
    print("\n== Custody (custody/) ==")
    tl = data.csv("custody/tamper_lab.csv")
    keyless = [r for r in tl if r["attack"] != "rollback"]
    det = sum(r["naive_verdict"] == "FAILED" for r in keyless)
    runs = len({r["run"] for r in tl})
    attacks = len({r["attack"] for r in keyless})
    T2 = "Table II"
    rep.num(T2, "P1 evidence", "value", [det, len(keyless)])
    rep.num(T2, "P1 evidence", "population", [runs, attacks])
    rep.num("In-text numbers of V-B", "custody.keyless.detected / .total", "value", [det, len(keyless)])

    rb = {(r["variant"], r["anchors"]): r for r in data.csv("custody/rollback_by_anchor.csv")}
    V1, V2 = "coherent rollback", "coherent rollback + provider journal from the provider process"
    V3 = "coherent rollback to #k (no provider effect removed; probe)"
    V4 = "continuation segment rolled back to its earlier cosigned head (both folders)"
    V5 = "continuation segment withheld (earlier folder presented as the whole run)"
    anchor_rows = {
        "none": {V1: "none", V2: "none", V3: "none", V4: "none", V5: "none"},
        "keys anchor only": {V1: "keys pinned", V2: "keys pinned", V3: "keys pinned", V4: "keys pinned (segment)", V5: "keys pinned"},
        "out-of-date witness head, saved": {V1: "stale witness head (#k)", V2: "stale witness head (#k)", V3: "stale witness head (#k)",
                                      V4: "stale segment witness head (#k)", V5: "stale witness head (#k)"},
        "latest witness head, saved": {V1: "witness latest cosigned head", V2: "witness latest cosigned head", V3: "witness latest cosigned head",
                                       V4: "segment's witness latest cosigned head (saved)", V5: "witness latest cosigned head"},
        "latest witness head and live signed status": {v: "witness latest via --witness-url" for v in (V1, V2, V3, V4, V5)},
        "saved final head (genuine)": {V1: "head pinned", V2: "head pinned", V3: "head pinned", V4: "head pinned (segment)",
                                       V5: "head pinned = run's final head (segment)"},
    }
    T4 = "Table IV"
    for row, by_variant in anchor_rows.items():
        for column, variant in zip(("V1", "V2", "V3", "V4", "V5"), (V1, V2, V3, V4, V5)):
            r = rb[(variant, by_variant[variant])]
            rep.num(T4, row, column, [int(r["detected"])])
            try:
                text = rep.doc.cell(T4, row, column)
            except LookupError:
                continue
            if "ANCHORED" in text:
                rep.claim("Table IV %s / %s: the undetected runs verify ANCHORED" % (row, column),
                          int(r["not_detected"]) > 0 and "ANCHORED" in r["assurance (count)"], r["assurance (count)"])
    rep.num(T2, "P4 evidence / counterexample", "value",
            [int(rb[(V2, "none")]["detected"]), int(rb[(V2, "none")]["runs"]), int(rb[(V1, "none")]["detected"]), int(rb[(V1, "none")]["runs"])])
    p5 = min(int(rb[(v, anchor_rows["saved final head (genuine)"][v])]["detected"]) for v in (V1, V2, V3, V4, V5))
    p5 = min(p5, min(int(rb[(v, "witness latest via --witness-url")]["detected"]) for v in (V1, V2, V3, V4, V5)))
    rep.num(T2, "P5 evidence", "value", [p5, int(rb[(V1, "none")]["runs"])])
    p5c = max(int(rb[(v, anchor_rows["keys anchor only"][v])]["detected"]) for v in (V1, V3, V4))
    p5c = max(p5c, int(rb[(V1, "stale witness head (#k)")]["detected"]))
    rep.num(T2, "P5 counterexample", "value", [p5c, int(rb[(V1, "none")]["runs"])], idx=range(2))
    rep.claim("P5: the out-of-date saved witness head verifies ANCHORED on the rolled-back run (V1)",
              "VERIFIED/ANCHORED" in rb[(V1, "stale witness head (#k)")]["assurance (count)"])

    B = "In-text numbers of V-B"
    repeats = data.csv("custody/repeats.csv")
    modes = Counter(r["mode"] for r in repeats)
    rep.num(B, "custody.runs", "value", [len(repeats), modes["flag"], modes["deny"]])
    rep.num("Units", "multi-process run", "count", [len(repeats), modes["flag"], modes["deny"]])
    enroll = data.json("custody/repeats_summary.json").get("enrollment") or {}

    def tally_probes(answers, refused_code):
        # {"403:enrollment 403:enrollment ...": runs} -> (refused, sent)
        sent = refused = 0
        for pattern, runs in answers.items():
            codes = pattern.split()
            sent += len(codes) * runs
            refused += sum(c == refused_code for c in codes) * runs
        return refused, sent
    probe_refused, probe_sent = tally_probes(enroll.get("probe_unsigned_registrations", {}), "403:enrollment")
    eval_refused = eval_sent = 0
    for frac, runs in (enroll.get("eval_enrollment_probes_refused") or {}).items():
        k, n = (int(x) for x in frac.split("/"))
        eval_refused += k * runs
        eval_sent += n * runs
    rep.num(B, "custody.enroll.refused", "value", [eval_refused + probe_refused, eval_sent + probe_sent])
    checks = data.json("custody/custody.json").get("selftest_revision_checks") or []
    # A run passed the revision checks when its "passed/total" names every check of the self-test.
    revoked = sum(r["revision_checks_passed"] == "%d/%d" % (len(checks), len(checks)) for r in repeats)
    rep.num(B, "custody.revoked", "value", [revoked, len(repeats)])
    rep.num("Table V", "note: revoked grant across a restart", "in-process", [revoked, len(repeats)])
    tally = Counter(r["revision_checks_passed"] for r in repeats)
    common, runs_common = tally.most_common(1)[0] if tally else ("0/0", 0)
    passed_checks, total_checks = (int(x) for x in common.split("/"))
    rep.num(B, "custody.revoked", "file", [passed_checks, total_checks, runs_common], idx=range(3),
            note="revision_checks_passed: " + ", ".join("%s x%d" % kv for kv in sorted(tally.items())))
    rep.claim("the revocation check is one of the self-test revision checks that revision_checks_passed counts",
              len(checks) == total_checks and any("revok" in (c.get("title", "") + c.get("id", "")).lower() for c in checks),
              "custody.json lists %d revision checks" % len(checks))
    clean_variant = "continuation segment (newest folder; earlier folder followed)"
    clean = [r for (v, a), r in rb.items() if v == clean_variant and int(r["rejected_wrong_anchor"]) == 0]
    clean_ok = sum(int(r["accepted_clean"]) for r in clean)
    clean_total = sum(int(r["runs"]) for r in clean)
    rep.num(B, "custody.clean.ok / .total", "value", [clean_ok, clean_total, len(repeats), len(clean)])
    rep.claim("no false alarm on clean custody evidence", sum(int(r["false_alarm"]) for r in rb.values()) == 0)

    probe = data.json("custody/status_probe_summary.json")
    altered = [c for c in probe["by_cell"] if c["answer"] not in ("relay",) and "status-withheld" not in c["answer"]]
    refused = sum(n for c in altered for o, n in c["outcomes"].items() if o in ("refused", "detected"))
    rep.num(B, "custody.alterations", "value", [refused, sum(c["runs"] for c in altered)])
    replayed = [c for c in probe["by_cell"] if c["answer"] == "replayed-pair"]
    replayed_refused = sum(n for c in replayed for o, n in c["outcomes"].items() if o in ("refused", "detected"))
    age = probe["replayed_status_age_s"]
    rep.num(B, "out-of-date status window", "value", [age[0], age[1], replayed_refused, sum(c["runs"] for c in replayed)])

    # head_fresh and run_complete over the CLI verifications.
    hf = Counter()
    for r in data.csv("custody/dimensions_by_cell.csv"):
        if r["source"] != "CLI":
            continue
        live = "--witness-url" in r["anchors"]
        clean_cell = r["variant"] == clean_variant
        wrong_run = "wrong run" in r["anchors"]
        for part in r["assurance|head_fresh|run_complete (count over runs)"].split(";"):
            m = re.match(r"\s*([A-Z]+)\|(\w+)\|(\w+) x(\d+)", part)
            if not m:
                continue
            _, fresh, complete, n = m.group(1), m.group(2), m.group(3), int(m.group(4))
            hf["all"] += n
            hf["live" if live else "other"] += n
            if fresh == "pass":
                hf["fresh_pass_live" if live else "fresh_pass_other"] += n
            if clean_cell and not wrong_run:
                hf["clean"] += n
                if complete == "fail":
                    hf["complete_fail_clean"] += n
                if live and complete == "pass":
                    hf["complete_pass_clean_live"] += n
                if live:
                    hf["clean_live"] += n
            elif not clean_cell and not wrong_run:
                hf["tampered"] += n
                if complete == "pass":
                    hf["complete_pass_tampered"] += n
    rep.num(B, "head_fresh pass", "value", [hf["fresh_pass_live"], hf["live"], hf["fresh_pass_other"], hf["other"]])
    rep.num(B, "run_complete pass", "value", [hf["complete_pass_clean_live"], hf["clean_live"], hf["complete_pass_tampered"], hf["tampered"],
                                              hf["complete_fail_clean"], hf["clean"]])


def check_crash(rep, data):
    print("\n== In-process crash, response loss and restart (crash/) ==")
    cj = data.json("crash/crash.json")
    t = cj["totals"]
    rows = data.csv("crash/crash.csv")
    fault_points = sorted({r["fault_point"] for r in rows})
    reps = max(int(r["repeat"]) for r in rows)
    answers = [(r["first_status"], r["first_reason"], r["first_dispatched"]) for r in rows] + \
              [(r["retry_status"], r["retry_reason"], r["retry_dispatched"]) for r in rows if r["retry_status"]]
    rejected = [a for a in answers if a[0] == "REJECTED"]
    reasons = Counter(a[1] for a in rejected)
    committed = [a for a in answers if a[0] == "COMMITTED"]
    effects = sum(int(r["effects_original_id"] or 0) + int(r["effects_fresh_id"] or 0) for r in rows)
    same_id = [r for r in rows if r["retry"] == "same-id"]
    replayed = [r for r in same_id if r["first_status"] in ("COMMITTED", "REJECTED") and r["retry_status"] == r["first_status"]]
    reconciled = [r for r in same_id if r["first_status"] in ("UNCERTAIN", "RECONCILIATION_REQUIRED") and r["retry_status"] == "COMMITTED"]
    reconciled_new_effects = sum(int(r["effects_original_id"]) - 1 for r in reconciled)
    T5 = "Table V"
    rep.num(T5, "two provider effects for one operation", "in-process", [t["duplicate_effects_per_operation_id"], t["operations"]])
    rep.num(T5, "REJECTED while the provider held an effect", "in-process", [t["rejected_while_effect_exists"], len(rejected)])
    rep.num(T5, "REJECTED while the provider held an effect", "file / field",
            [len(rejected), len(answers), reasons["dispatch_refused"], reasons["aborted_before_send"], t["rejected_while_effect_exists"]])
    rep.claim("every in-process REJECTED answer says dispatched=false", all(a[2] == "no" for a in rejected))
    rep.num(T5, "COMMITTED without a provider effect", "in-process", [t["committed_without_effect"], t["operations"]])
    rep.num(T5, "a provider effect without an outcome entry", "in-process", [t["evidence_gaps"], effects])
    rep.num(T5, "UNCERTAIN after reconciliation", "in-process", [t["unresolved_after_reconcile"], t["operations"]])
    D = "In-text numbers of V-C"
    rep.num(D, "crash.fault_points / crash.reps", "value", [len(fault_points), reps])
    rep.num(D, "crash.ops / crash.schedules / crash.folders", "value", [t["operations"], len(cj["schedules"]), t["segments_verified"]])
    rep.num(D, "crash.ops / crash.schedules / crash.folders", "field", [t["segments_anchored"], t["segments_verified"]])
    rep.num(D, "same-ID retries", "value", [len(reconciled), reconciled_new_effects, len(replayed)])
    rep.num(D, "crash.freshid_again", "value", [t["business_duplicates"], t["operations"]])
    mk = t["segments_with_missing_items_by_kind"]
    rep.num(D, "crash Missing by kind", "value", [mk["freshness"], t["segments_verified"], mk["unresolved"], mk["issuer_only"], mk["other"]])
    classes = Counter()
    for r in data.csv("crash/cli_crosscheck.csv"):
        final = (r["restart"] == "none" and r["segment"] == "1") or (r["restart"] != "none" and r["verified_as"].startswith("chain"))
        if final and r["anchors"] == "none":
            for part in r["cli_classification"].split():
                k, _, n = part.partition("=")
                classes[k] += int(n)
    rep.num(D, "crash classification evidence", "value",
            [classes["issuer_adapter"], classes["issuer_only_reconciled"], classes["issuer_only_no_effect"], sum(classes.values())])
    rep.num("Units", "fault run", "count", [len(cj["schedules"]), len(data.json("crash/deny/crash.json")["schedules"])])
    retries, restarts = sorted({r["retry"] for r in rows}), sorted({r["restart"] for r in rows})
    rep.claim("fault runs = fault points x retry kinds x restart options x repetitions",
              len(fault_points) * len(retries) * len(restarts) * reps == len(cj["schedules"]),
              "%d x %d x %d x %d" % (len(fault_points), len(retries), len(restarts), reps))


def check_killsuite(rep, data):
    print("\n== Process-kill tests (killsuite/) ==")
    res = data.json("killsuite/results.json")
    t, cells = res["totals"], res["cells"]
    cases = sorted({c["name"] for c in cells})
    reps = res["reps"]
    killed = [s for c in cells for s in c["segments"] if (s.get("ended") or "").startswith(("killed", "terminated"))]
    exit86 = sum(s.get("exit_code") == 86 for s in killed)
    terminated = sum((s.get("ended") or "").startswith("terminated") for s in killed)
    cells_with_kill = sum(any((s.get("ended") or "").startswith(("killed", "terminated")) for s in c["segments"]) for c in cells)
    roles = Counter(role for c in cells for role in c["provider_effects"])
    answers = Counter()
    for c in cells:
        for a in c["answers"]:
            answers[a["result"].get("status") or "none"] += 1
    U = "Units"
    kill_exit = Counter(s.get("exit_code") for s in killed if (s.get("ended") or "").startswith("killed")).most_common(1)[0][0]
    rep.num(U, "test case, test run", "count", [len(cases), reps, len(cells), cells_with_kill, exit86, kill_exit, terminated])
    rep.num(U, "operation", "definition", [roles["original"], roles["fresh"], roles["probe"], t["operations"]])
    rep.num("Headline numbers", "killsuite.caseruns", "value", [t["cells"], len(cases), reps, cells_with_kill])
    T5 = "Table V"
    rep.num(T5, "two provider effects for one operation", "process kills", [t["operations_with_more_than_one_effect"], t["operations"]])
    rep.num(T5, "REJECTED while the provider held an effect", "process kills", [t["rejected_while_provider_holds_effect"], answers["REJECTED"]])
    rep.num(T5, "COMMITTED without a provider effect", "process kills", [t["committed_without_effect"], answers["COMMITTED"]])
    outside = t["operations"] - t["unresolved_after_reconcile_deliberate"]
    rep.num(T5, "UNCERTAIN after reconciliation", "process kills", [t["unresolved_after_reconcile_not_deliberate"], outside])
    rep.num(T5, "an operation dispatched twice", "process kills", [t["cells_with_redispatch"], t["cells"]])
    rep.num(T5, "flag lost in a recovery record or stored answer", "process kills", [t["flag_lost"], t["flag_cells_committed"]])
    rep.num(T5, "reported: no final status", "process kills", [t["undecided_after_reconcile"]])
    probes = roles["probe"]
    rep.num(T5, "reported: no final status", "file / field#2",
            [t["undecided_after_reconcile"], t["undecided_after_reconcile"] - probes, probes, t["unlisted_after_reconcile"]])
    deliberate = Counter()
    for c in cells:
        if c["unresolved_after_reconcile"]:
            deliberate[c["group"]] += 1
    rep.num(T5, "note: deliberately unresolved", "process kills", [t["unresolved_after_reconcile_deliberate"]])
    rep.num(T5, "note: deliberately unresolved", "file / field#2", sorted(deliberate.values(), reverse=True), note="by case group: " + ", ".join("%s %d" % kv for kv in sorted(deliberate.items())))
    rje = [c for c in cells if c["rejected_then_effect"]]
    rep.num(T5, "note: REJECTED twice, then committed once after a failed journal write", "process kills", [len(rje), t["rejected_answers_then_effect_after_restart"]])
    rep.num(T5, "note: REJECTED twice, then committed once after a failed journal write", "file / field#2",
            [len(rje), t["rejected_answers_then_effect_after_restart"] // max(len(rje), 1)])
    rep.num("Table II", "P7 counterexample", "value", [data.json("crash/crash.json")["totals"]["business_duplicates"],
                                                       data.json("crash/crash.json")["totals"]["operations"], len(rje),
                                                       t["rejected_answers_then_effect_after_restart"]])
    D = "In-text numbers of V-C"
    rep.num(D, "kill points / disk states", "value", [sum(not k.get("external") for k in res["kill_points"])], idx=[0])
    groups = Counter(c["group"] for c in cells)
    per = {g: n // reps for g, n in groups.items()}
    rep.num(D, "test-case composition", "value", [per.get("kill", 0), per.get("human", 0), per.get("provider", 0), per.get("surrogate", 0),
                                             per.get("journal", 0), per.get("replay", 0), len(cases)])
    sig = defaultdict(set)
    for r in data.csv("killsuite/results.csv"):
        sig[r["cell"]].add(tuple(r[k] for k in ("answers", "state_after_reconcile", "effects_original", "effects_fresh",
                                                 "segment1_verdict", "segment1_failing", "segment2_verdict", "segment2_failing",
                                                 "flag_preserved", "classification_evidence", "undecided_operations",
                                                 "unsettled_with_dispatch_or_effect", "restart_blocked", "error")))
    rep.num(D, "killsuite.unstable", "value", [sum(len(s) > 1 for s in sig.values()), len(sig)])
    # First segments verified alone: every restarted test run, plus the refused restarts (segment 1 only).
    ks_rows = data.csv("killsuite/results.csv")
    seg1_alone = sum(1 for r in ks_rows if r["segment2_verdict"] or r["restart_blocked"].lower() in ("yes", "true"))
    rep.num(D, "killsuite.seg1.pma", "value", [t["failing_checks"].get("provider.matches_audit", 0), seg1_alone])
    ce = t["classification_evidence"]
    rec = [c for c in cells if c.get("classification_evidence") == "issuer_only_reconciled"]
    rec_provider = sum(c["group"] == "provider" for c in rec)
    rep.num(D, "killsuite.class.reconciled", "value", [ce["issuer_only_reconciled"], len(rec) - rec_provider, rec_provider])
    rep.num(D, "killsuite.class.reconciled", "field",
            [ce["issuer_adapter"], ce["issuer_only_no_effect"], ce["issuer_only_unresolved"], sum(v for k, v in ce.items() if k.startswith("not reported"))])
    pending = t["undecided_after_reconcile"] - probes
    rep.num(D, "killsuite.undecided / with a capability", "value", [t["undecided_after_reconcile"], pending])
    rep.num(D, "killsuite.flagged_committed / .flag_lost", "value", [t["flag_cells_committed"], t["flag_lost"], t["cells"]])
    rep.num(D, "killsuite.flagged_committed / .flag_lost", "field",
            [sum(c["recovery_entries"] for c in cells), sum(c["replay_entries"] for c in cells)], idx=range(2))
    # The earlier-build prefix run is kept with build 2's data; a later build's
    # folder may not repeat it.
    prefix = "killsuite/prefix-earlier-build/results.json"
    if (data.root / prefix).is_file():
        pre = data.json(prefix)["totals"]
    else:
        pre = read_json(data.root.parent / "build2" / prefix)["totals"]
    rep.num(D, "killsuite.prefix.flagged_committed / .flag_lost", "value", [pre["flag_cells_committed"], pre["flag_lost"], pre["cells"]])
    chron_path = data.root / "killsuite/journal_chronology.json"
    if chron_path.is_file():
        chron = data.json("killsuite/journal_chronology.json")
        want = [(1, "REJECTED", "operation", False), (1, "REJECTED", "call", True), (2, "COMMITTED", None, False)]

        def answers_of(r):
            out = []
            for e in r["audit"]:
                if e.get("stage") == "CALL_RESULT" and e.get("op") == "original":
                    out.append((e["segment"], e.get("status"), e.get("scope") if e.get("status") == "REJECTED" else None, bool(e.get("replayed"))))
            return out
        reps_ = chron["repetitions"]
        same = sum(answers_of(r) == want for r in reps_)
        rep.num(D, "journal write failure", "value", [same, len(reps_)], idx=[0, 1])


def check_concurrency(rep, data):
    print("\n== Concurrency (concurrency/) ==")
    runs = data.tsv("concurrency/analysis/runs.tsv")
    reps = data.csv("concurrency/analysis/scenario_repetitions.csv")
    race = sum("race" in r["binary"] for r in runs)
    total_reps = sum(int(r["repeat"]) for r in runs)
    scenarios = sorted({r["scenario"] for r in reps})
    held = sum(r["safety_holds"] == "true" and r["harness_invariant_holds"] == "true" for r in reps)
    calls = sum(int(r["calls"]) for r in reps)
    callers = sorted({int(r["n"]) for r in reps})
    conflict = [r for r in reps if r["scenario"] == "conflicting-reuse"]

    def count(pattern, status):
        m = re.search(r"(\d+)x %s" % status, pattern)
        return int(m.group(1)) if m else 0
    committed = sum(count(r["pattern"], "COMMITTED/") for r in conflict)
    rejected = sum(count(r["pattern"], "REJECTED/operation_id_conflict") for r in conflict)
    D = "In-text numbers of V-C"
    rep.num(D, "conc.runs / conc.reps / conc.scen_reps", "value", [len(runs), race, total_reps, len(reps)])
    rep.num(D, "conc.runs / conc.reps / conc.scen_reps", "field", callers + [calls])
    rep.num(D, "conc.conflict.committed / .rejected_call", "value", [committed, rejected])
    rep.num("Units", "scenario repetition", "count", [total_reps, len(scenarios), len(reps), len(runs)])
    rep.num("Table II", "P7 evidence", "value", [held, len(reps)], idx=[0, 1])


def check_misuse(rep, data):
    print("\n== Policy misuse (misuse/) ==")
    rows = data.csv("misuse/misuse.csv")
    groups = {(r["case"], r["step"], r["label"]): r for r in data.csv("misuse/misuse_category_map.csv")}
    table = {(r["case"], r["step"], r["label"]): r for r in data.csv("misuse/misuse_table.csv") if r["mode"] == "flag"}
    joined = []
    for r in rows:
        key = (r["case"], r["step"], r["label"])
        joined.append((r, groups[key], table[key]))
    rep.claim("the category map's observed outcomes equal misuse.csv", all(m["observed_flag"] == r["class"] for r, m, _ in joined))

    def tally(pred):
        sel = [(r, m, t) for r, m, t in joined if pred(r, m, t)]
        c = Counter(r["class"] for r, _, _ in sel)
        return [len(sel), c["blocked"], c["flagged"], c["permitted"], c["invalid"]]
    stop = "harmful: what the policy is built to stop"
    comp = "harmful: policy-compliant harm"
    T6 = "Table VI"
    cols = ("n", "blocked", "allowed, flagged", "allowed, no flag", "invalid")
    spec = [
        ("legitimate", lambda r, m, t: m["group_after_run"] == "legitimate"),
        ("needing review", lambda r, m, t: m["group_after_run"] == "for review"),
        ("harmful, under a grant", lambda r, m, t: m["group_after_run"] in (stop, comp)),
        ("covered by a rule or grant limit", lambda r, m, t: m["group_after_run"] == stop),
        ("split payments within the budget", lambda r, m, t: m["subgroup_after_run"].startswith("split payment")),
        ("wrong purpose", lambda r, m, t: m["subgroup_after_run"].startswith("wrong purpose")),
        ("confidential near-copy or paraphrase", lambda r, m, t: m["subgroup_after_run"].startswith("confidential paraphrase")),
        ("harmful, rerun without a grant", lambda r, m, t: m["group_after_run"] == "harmful: no-grant controls"),
        ("all harmful", lambda r, m, t: r["category"] == "harmful"),
        ("malformed", lambda r, m, t: m["group_after_run"] == "malformed"),
    ]
    for key, pred in spec:
        values = tally(pred)
        for column, value in zip(cols, values):
            rep.num(T6, key, column, [value])
    stopped = [t for r, m, t in joined if m["group_after_run"] == stop]
    by = Counter(t["blocked_by"] for t in stopped)
    rep.num(T6, "covered by a rule or grant limit", None, [by["content rules only"], by["delegation (DEL-*) only"], by["both"]])
    split = [r for r, m, t in joined if m["subgroup_after_run"].startswith("split payment")]
    rep.num(T6, "split payments within the budget", None, [len(split)], idx=[0])

    E = "In-text numbers of V-D"
    cases = {(r["group"], r["case"]) for r in rows}
    rep.num(E, "cases / requests", "value", [len(cases), len(rows)], idx=[0, 1])
    rej = [r for r in rows if r["status"] == "REJECTED"]
    rej_noeffect = sum(r["effect_committed"] == "no" for r in rej)
    deny = data.json("misuse/misuse_analysis.json")["modes"]["deny"]["status_contract"]
    rep.num(E, "misuse.rejected_noeffect", "value", [rej_noeffect, len(rej), deny["rejected_dispatched_false"] - deny["rejected_with_effect"], deny["rejected"]])
    committed = [r for r in rows if r["effect_committed"] == "yes"]
    fl = Counter(r["category"] for r in committed if r["class"] == "flagged")
    rep.num(E, "flagged commits", "value", [sum(fl.values()), len(committed), fl["review"], fl["harmful"], fl["legitimate"]])
    harmful = [(r, m) for r, m, t in joined if r["category"] == "harmful"]
    granted = [(r, m) for r, m in harmful if m["group_after_run"] in (stop, comp)]
    gc = Counter(r["class"] for r, m in granted)
    unflagged_granted = [(r, m) for r, m in granted if r["class"] == "permitted"]
    no_grant = [(r, m) for r, m in harmful if m["group_after_run"] == "harmful: no-grant controls"]
    rep.num(E, "policy coverage", "value",
            [len(harmful), len(granted), gc["blocked"], gc["flagged"], gc["permitted"],
             sum(m["subgroup_after_run"].startswith("split payment") for r, m in unflagged_granted),
             sum(m["subgroup_after_run"].startswith("wrong purpose") for r, m in unflagged_granted),
             len(no_grant), sum(r["class"] == "permitted" for r, m in harmful), len(harmful)])
    rep.claim("the reruns without a grant are all unflagged", all(r["class"] == "permitted" for r, m in no_grant))
    tallies = data.json("misuse/misuse_analysis.json")["modes"]["flag"]["tallies"]["harmful"]["by_observed"]
    rep.claim("misuse_analysis.json harmful by_observed = 24 / 3 / 17 as recounted",
              [tallies.get("blocked"), tallies.get("flagged"), tallies.get("permitted")] == [gc["blocked"], gc["flagged"], sum(r["class"] == "permitted" for r, m in harmful)])
    rep.num(E, "split payments", "value", [len(split)], idx=[0])
    leak = [r for r in rows if r["group"] == "confidential-text" and r["category"] == "harmful" and r["tool"] == "external_message.send"]
    leak_blocked = sum("MSG-CONFIDENTIAL-TEXT" in r["fired_rules"] and r["class"] == "blocked" for r in leak)
    leak_flagged = sum(r["class"] == "flagged" for r in leak)
    rep.num(E, "confidential text", "value", [leak_blocked, len(leak), leak_flagged, leak_flagged])
    rep.num("Units", "case, request", "count", [len(cases), len(rows)])
    rep.num("VII Limitations", "L8 split payments", "value", [len(split)])


def check_baseline(rep, data):
    print("\n== Baselines, load and cost (baseline/) ==")
    an = data.json("baseline/analysis.json")
    primary = an["runs"]["primary"]
    pd = {p["compare"]: p for p in primary["paired_differences"]}
    T7 = "Table VII"

    def paired(key, compare):
        p = pd[compare]
        lo, hi = p["median_ci95_blocks"]
        rep.num(T7, key, "value", [ms(p["median_us"]), ms(lo), ms(hi)])
    paired("checking (policy, grant, capability, receipts)", "policy-only - direct")
    paired("signing and flushing the audit log", "full - policy-only")
    paired("total of the two", "full - direct")
    paired("operation journal", "full+journal - full")
    paired("flagging (a request the policy flags)", "full-flagged - full")
    p = pd["policy-only - direct"]
    rep.num(T7, "checking (policy, grant, capability, receipts)", "population",
            [p["n_trials"], p["blocks"], p["n_trials"] // p["blocks"], an["seed"], an["bootstrap_resamples"]])
    # The quoted stage run: the one with the fewest uninstrumented appends over 10 ms
    # (build 2: run2; build 3: run1), the rule baseline/RESULTS.md section 5 states.
    stage_runs = sorted(p.name for p in (data.root / "baseline/stagecost").glob("run[0-9]*") if (p / "stagecost.json").is_file())
    quoted = min(stage_runs, key=lambda r: (data.json("baseline/stagecost/%s/stagecost.json" % r)["per_call"]["appends_over_10ms"], r))
    print("  quoted stage run: %s (fewest appends over 10 ms)" % quoted)
    sc = data.json("baseline/stagecost/%s/stagecost.json" % quoted)
    gr = {x["name"]: x for x in sc["groups"]}
    enc, sign = gr["encode + hash"]["mean_us"], gr["Ed25519 signing"]["mean_us"]
    write, fsync = gr["log line write"]["mean_us"], gr["log fsync"]["mean_us"]
    tmp, hfs, ren = gr["temp head write"]["mean_us"], gr["head fsync"]["mean_us"], gr["head rename"]["mean_us"]
    staged = sc["staged_total"]["mean_us"] if isinstance(sc.get("staged_total"), dict) else None
    head = Decimal(str(tmp)) + Decimal(str(hfs)) + Decimal(str(ren))
    cpu = Decimal(str(enc)) + Decimal(str(sign))
    log = Decimal(str(write)) + Decimal(str(fsync))
    sums = "a total the document adds from its rounded parts; tolerance 0.1 us"
    rep.num(T7, "encode, hash and sign (entry and head), mean", "value", [cpu / 1000, cpu, enc, sign], tol=[None, 0.1, None, None], note=sums)
    rep.num(T7, "log line write and flush, mean", "value", [log / 1000, log, write, fsync], tol=[None, 0.1, None, None], note=sums)
    rep.num(T7, "head: temporary file write, flush and rename, mean", "value", [head / 1000, head, tmp, hfs, ren], tol=[None, 0.1, None, None, None], note=sums)
    rep.num(T7, "head: temporary file write, flush and rename, mean", "field", [head / Decimal(str(staged)) * 100])
    rep.num(T7, "directory flush", "value", [gr["directory fsync"]["mean_us"]])
    ap = sc["append_uninstrumented"]["mean_us"]
    rep.num(T7, "one audit append, mean (six per call)", "value", [ms(ap), ap])
    rep.num(T7, "one audit append, mean (six per call)", "field", [staged])
    wp = {x["name"]: x for x in data.json("baseline/stagecost/run3/witnesspush.json")["rows"]}
    push, save = wp["push per call"], wp["save per call"]
    rep.num(T7, "witness update, head save per call, mean, not in timings", "value",
            [ms(Decimal(str(push["mean_us"])) + Decimal(str(save["mean_us"]))), ms(push["mean_us"]), ms(save["mean_us"])])
    rep.num(T7, "witness update, head save per call, mean, not in timings", "field", [ms(push["median_us"]), ms(save["median_us"])], idx=[0, 1])

    G = "In-text numbers of V-F"
    # Calls: every observation row of the six runs (warm-up rows separately).
    run_dirs = {"primary": "", "repeat-R1": "repeats/R1/", "repeat-R3": "repeats/R3/", "repeat-R4": "repeats/R4/",
                "repeat-R5": "repeats/R5/", "message": "message/"}
    measured = warm = failed = 0
    for name, sub in run_dirs.items():
        for f in ("baseline-concurrent.csv", "baseline-sequential.csv"):
            for r in data.csv("baseline/" + sub + f):
                if r["warmup"] == "yes":
                    warm += 1
                else:
                    measured += 1
                if not r["status"].startswith("COMMITTED"):
                    failed += 1
    rep.num(G, "baseline.runs / baseline.calls", "value", [measured])
    rep.num(G, "baseline.runs / baseline.calls", "field", [failed, measured, failed, warm])
    rep.num(G, "baseline.trials", "value", [pd["full - policy-only"]["n_trials"]])
    five = ["primary", "repeat-R1", "repeat-R3", "repeat-R4", "repeat-R5"]

    def conc(run, config, clients):
        return next(c for c in an["runs"][run]["concurrent"] if c["config"] == config and c["clients"] == clients)
    p99_1 = statistics.median(conc(r, "full", 1)["p99_us"] for r in five)
    p99_16 = statistics.median(conc(r, "full", 16)["p99_us"] for r in five)
    seq_full = next(c for c in data.json("baseline/baseline.json")["sequential"]["configs"] if c["config"] == "full")
    rep.num(G, "baseline.p99.1 / baseline.p99.16", "value", [ms(p99_1), ms(p99_16)])
    rep.num(G, "baseline.p99.1 / baseline.p99.16", "field",
            [ms(conc("primary", "full", 1)["p99_us"]), ms(conc("primary", "full", 16)["p99_us"]), ms(seq_full["latency"]["p99_us"])])
    # "From 4 clients up" (the document's definition): every client count of
    # the five runs' full-configuration cells from POOL_FROM_CLIENTS up.
    pool = sorted({c["clients"] for r in five for c in an["runs"][r]["concurrent"]
                   if c["config"] == "full" and c["clients"] >= POOL_FROM_CLIENTS})
    pooled_cells = [conc(r, "full", n) for r in five for n in pool]
    pooled = statistics.median(c["throughput_calls_per_s"] for c in pooled_cells)
    rep.num(G, "baseline.recorded.calls_s", "value", [pooled, min(pool)])
    rep.num(G, "baseline.recorded.calls_s", "field", [len(pooled_cells)] + pool)
    entries_per_call = sc["per_call"]["gateway_entries_per_call"]
    rep.num(G, "stage.append.mean / stage.ceiling", "value",
            [ms(ap), int(Decimal(1) / (entries_per_call * ms(ap) / 1000)), 1, entries_per_call, ms(ap)], fixed=[2])
    clients = 16   # Little's law at the 16-client cell of Table VII's run
    c16 = next(c for c in data.json("baseline/baseline.json")["concurrent"] if c["config"] == "full" and c["clients"] == clients)
    thr = conc("primary", "full", clients)["throughput_calls_per_s"]
    rep.num(G, "baseline.recorded.mean16", "value", [clients, thr, Decimal(clients) / Decimal(str(thr)) * 1000, ms(c16["latency"]["mean_us"])],
            fixed=[0])
    rep.num(G, "stage.head vs stage.log", "value", [head / 1000, log / 1000])
    rep.num(G, "stage.cpu share", "value", [cpu, staged, cpu / Decimal(str(staged)) * 100])
    alloc = statistics.median(conc(r, "full", 1)["alloc_kib_per_call"] for r in five)
    peak = max(c["peak_working_set_mib"] for r in an["runs"] for c in an["runs"][r]["concurrent"])
    rep.num(G, "baseline.alloc_per_call / baseline.peak_ws", "value", [round(alloc), peak])


def fuzz_seconds(text):
    """A `go test -fuzztime` duration such as '120s' or '2m' in seconds."""
    m = re.fullmatch(r"\s*(?:(\d+)m)?(?:(\d+(?:\.\d+)?)s)?\s*", text)
    if not m or not (m.group(1) or m.group(2)):
        raise ValueError("fuzztime %r is not a duration" % text)
    return Decimal(m.group(1) or 0) * 60 + Decimal(m.group(2) or 0)


def check_robustness(rep, data):
    print("\n== Verifier robustness, held-out operators, subset verifier (robustness/, heldout/, subset-corpus/) ==")
    F = "V-E"
    fz = data.json("robustness/fuzz_summary.json")
    execs = sum(v["execs"] for v in fz.values())
    targets = len({v["target"] for v in fz.values()})
    failures = sum(v["failures_reported"] + v["crasher_minimizations"] + v["testdata_crashers"] for v in fz.values())
    rep.num(F, "robust.fuzz.inputs", "value", [execs, failures])
    rep.claim("every fuzz run passed (passed true, exit code 0)", all(v["passed"] is True and v["exit_code"] == 0 for v in fz.values()),
              ", ".join("%s %s/%s" % (k, v["passed"], v["exit_code"]) for k, v in sorted(fz.items())))
    fuzztimes = sorted({fuzz_seconds(v["fuzztime"]) for v in fz.values()})
    rep.claim("every fuzz run had the same fuzz time", len(fuzztimes) == 1, "fuzztime %s s" % ", ".join(fmt(t) for t in fuzztimes))
    rep.num(F, "robust.fuzz.inputs", "population", [targets, len(fz), max(fuzztimes), max(v.get("workers", 0) for v in fz.values())])
    full = data.json("robustness/kill_score_full.json")
    nph = data.json("robustness/kill_score_without_posthoc.json")
    nph4 = data.json("robustness/kill_score_without_posthoc4.json")
    rep.num(F, "robust.kill.full", "value", [full["killed"], full["sites"]])
    rep.num(F, "robust.nolate", "value", [nph["killed"], nph["sites"], Decimal(nph["killed"]) / Decimal(nph["sites"])])
    rep.num(F, "robust.nolate", "field", [nph4["killed"], nph4["sites"]], idx=[0, 1])
    n7 = nph["skipped_tests"].count("|") + 1
    n4 = nph4["skipped_tests"].count("|") + 1
    rep.num(F, "robust.late", "value", [n7, n4, n7 - n4])
    ho = data.json("heldout/heldout_summary.json")

    def variant(v):
        parts = [ho["%s/%s" % (v, op)] for op in ("append", "boundary", "equality")]
        killed, sites = sum(p["killed"] for p in parts), sum(p["sites"] for p in parts)
        return killed, sites, parts
    k1, s1, p1 = variant("v1_full")
    rep.num(F, "heldout.full (v1)", "value", [k1, s1, Decimal(k1) / Decimal(s1)] + [x for p in p1 for x in (p["killed"], p["sites"])])
    kd, sd, pdd = variant("v2d_without_posthoc4_new20")
    rep.num(F, "heldout.nolate (v2d)", "value", [kd, sd, Decimal(kd) / Decimal(sd)] + [x for p in pdd for x in (p["killed"], p["sites"])])
    others = []
    for v in ("v2_without_posthoc4", "v2b_without_posthoc7", "v2c_without_posthoc16", "v3_f01d1c9"):
        k, s, _ = variant(v)
        others += [k, s, Decimal(k) / Decimal(s)]
    # The cell names each test set ("without the 4", "the 7", "the 16", "build 1's ... the 4"):
    # those counts sit at positions 0, 4, 8, 12 and 13 and are labels, not data.
    rep.num(F, "other test sets (archive only)", "value", others, idx=[1, 2, 3, 5, 6, 7, 9, 10, 11, 14, 15, 16])
    cov = data.json("robustness/coverage_summary.json")
    rep.num(F, "robust.cov", "value", [Decimal(cov["statements"]["suite"]) / Decimal(cov["denominator_statements"]) * 100,
                                            cov["statements"]["suite"], cov["denominator_statements"]])
    rep.num(F, "robust.cov", "field", [Decimal(cov["statements"]["suite_without_posthoc"]) / Decimal(cov["denominator_statements"]) * 100])
    rc = data.json("robustness/refusal_conditions.json")
    never = rc["counts"]["neither_suite_nor_fuzz"]
    kinds = rc["by_kind"]
    never_problem = kinds["problem"]["neither_suite_nor_fuzz"]
    rep.num(F, "robust.unexec / robust.cond (VII L4)", "value", [never, rc["counts"]["conditions"], never_problem, never_problem, kinds["problem"]["conditions"]])
    rep.num(F, "robust.unexec / robust.cond (VII L4)", "field",
            [rc["counts"]["conditions"], kinds["fail"]["conditions"], kinds["warn"]["conditions"], kinds["problem"]["conditions"],
             Decimal(never) / Decimal(rc["counts"]["conditions"]) * 100])
    rep.num("VII Limitations", "L4 never-reached failure conditions", "value", [never, rc["counts"]["conditions"]])
    rep.num("Units", "line that makes a check fail, mutant, failure condition", "count", [full["sites"], s1, rc["counts"]["conditions"]])
    sub = data.json("subset-corpus/subset-result.json")
    s = sub["summary"]
    rows = sub["rows"]
    folders = {r["id"] for r in rows}
    by_group = Counter(r["group"] for r in rows)
    anchors = len({r["anchors"] for r in rows})
    rep.num(F, "subset.agree / subset.total", "value", [s["agree"], s["verifications"]])
    rep.num(F, "subset.agree / subset.total", "population",
            [len(folders), by_group["clean"] // anchors, by_group["tamper-lab"] // anchors, by_group["mutant"] // anchors, anchors])
    b = s["binding_relevant"]
    rep.num(F, "subset.binding_folders / go_detected / go_accepted / flips", "value", [b["verifications"], b["go_failed"], b["go_accepted"], len(s["binding_flips_go"])])
    rep.claim("the partial Python verifier finds the same pairs changed by binding as the Go verifier", s["binding_flips_go"] == s["binding_flips_subset"])
    cm_path = data.root / "robustness/coverage_map.json"
    if cm_path.is_file():
        cm = data.json("robustness/coverage_map.json")
        tot = cm["totals_over_checks (a condition owned by k checks counts k times)"]
        never_by_check = cm["checks_with_never_executed_conditions"]
        rep.num(F, "coverage map per check", "value",
                [cm["checks"], len(cm["checks_with_no_site_killed_without_posthoc16"]), n7, sum(never_by_check.values()), len(never_by_check)])
        rep.claim("coverage map: every line that makes a check fail is executed and detected by the full suite",
                  tot["sites"] == tot["sites_executed_by_suite"] == tot["sites_killed_full"],
                  "%d sites, %d executed, %d detected" % (tot["sites"], tot["sites_executed_by_suite"], tot["sites_killed_full"]),
                  row=(F, "coverage map per check"))
    cc = data.json("robustness/check_counts.json")
    rep.num(F, "verifier.check_ids", "value", [cc["documented_checks"]])
    rep.claim("the documented check IDs equal those in checks.go", cc.get("same_set") is True)


def check_manifest(rep, data):
    print("\n== Build manifest (build-manifest.txt) ==")
    text = data.text("build-manifest.txt")
    # `HEX *name` or the two-space sha256sum form `HEX  name` (check_build_manifest.ENTRY_RE).
    entries = re.findall(r"^[0-9a-fA-F]{64} [ *](\S.*?)[ \t\r]*$", text, re.M)
    rep.num("In-text numbers of V intro", "frozen build", "field", [len(entries)], idx=[0])
    groups = Counter("binary" if e.startswith("bin/") else "stdlib" if e.startswith("$GOROOT/") else
                     "third-party" if e.startswith("$GOMODCACHE/") else "module" for e in entries)
    m = re.search(r"module (\d+), third-party (\d+), standard library (\d+)", text)
    rep.claim("the manifest's stated file counts equal its entries",
              m is not None and (int(m.group(1)), int(m.group(2)), int(m.group(3))) == (groups["module"], groups["third-party"], groups["stdlib"]),
              "binaries %d, module %d, third-party %d, standard library %d" % (groups["binary"], groups["module"], groups["third-party"], groups["stdlib"]))


LOC_ROW = ("SUPPLEMENTARY S1", "loc.*")


def check_loc(rep, path):
    if path is None or not path.is_file():
        try:
            rep.doc.find(*LOC_ROW)
        except LookupError:
            print("\n== Implementation size: no loc file and no %s row, skipped ==" % LOC_ROW[0])
            return
        print("\n== Implementation size: no loc file ==")
        rep._emit(False, "%s / %s / value" % LOC_ROW,
                  "no code-line CSV (%s) for the document's %s row; count the build's code lines first" % (path, LOC_ROW[0]))
        return
    print("\n== Implementation size (%s) ==" % path.name)
    with open(path, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    ks = [r for r in rows if r["package"].endswith("/cmd/agentgate-killsuite")]
    five = [r for r in rows if r not in ks]
    lines = lambda rs: sum(int(r["code_lines"]) for r in rs)
    role = lambda name: lines([r for r in five if r["role"] == name])
    rep.num(LOC_ROW[0], LOC_ROW[1], "value",
            [lines(five), len(five), role("enforcement_path"), role("custody_processes"), role("verifier"), role("demo_ui_harness"),
             role("linked_persistence"), role("linked_other"), lines(ks), len(ks), lines(rows), len(rows)])


# Rows a check above does not read, with the reason they are not recomputed.
def not_recomputed_reason(section, key, cells):
    joined = " ".join(cells)
    if "go test" in joined or section.startswith(("Real-key tests", "Build-3 checks")):
        return "real-key and other fixture tests: asserted by `go test` (README.md, 'Real-key tests')"
    if section.startswith(("Version crosswalk", "Version map", "Build 1 to build 2")):
        return "repeats a number checked above, or an earlier build's value (version crosswalk)"
    if section.startswith(("Table I ", "Figure 2", "Units")):
        return "qualitative (key sets, evidence bases, definitions) or covered by the rows checked above"
    return "source is prose, code or a test log, not a machine-readable data file"


CHECKS = (check_compromise, check_fixture_studies, check_custody, check_crash, check_killsuite,
          check_concurrency, check_misuse, check_baseline, check_robustness, check_manifest)


def run_checks(rep, data, loc):
    """Run every check; return the document rows no check read, by reason."""
    for fn in CHECKS:
        try:
            fn(rep, data)
        except (OSError, KeyError, ValueError, StopIteration, json.JSONDecodeError) as err:
            rep.missing_data(fn.__name__, "%s: %s" % (type(err).__name__, err))
    try:
        check_loc(rep, loc)
    except (OSError, KeyError, ValueError) as err:
        rep.missing_data("check_loc", "%s: %s" % (type(err).__name__, err))
    skipped = defaultdict(list)
    for section, headers, cells in rep.doc.rows:
        key = norm(cells[0])
        if (section, key) not in rep.doc.used:
            skipped[not_recomputed_reason(section, key, cells)].append("%s / %s" % (section, key))
    return skipped


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("data", nargs="?", default=str(REPO / "docs/paper/data/build3"), help="data folder of the build")
    parser.add_argument("--expected", default=str(HERE / "EXPECTED_TABLES.md"), help="the expected-tables document")
    parser.add_argument("--loc", help="code-line CSV for Supplementary S1 (default: loc_<data folder name>.csv next to this script)")
    parser.add_argument("--quiet", action="store_true", help="print only mismatches and the summary")
    parser.add_argument("--json", help="write every comparison to this JSON file")
    args = parser.parse_args(argv)
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    root = Path(args.data).resolve()
    if not root.is_dir() or not Path(args.expected).is_file():
        print("no data folder or expected-tables file: %s, %s" % (root, args.expected), file=sys.stderr)
        return 2
    if args.loc and not Path(args.loc).is_file():
        print("no code-line CSV: %s" % args.loc, file=sys.stderr)
        return 2
    doc = Doc(Path(args.expected).resolve())
    rep = Report(doc, quiet=args.quiet)
    loc = Path(args.loc) if args.loc else HERE / ("loc_%s.csv" % root.name)
    print("data: %s" % root)
    print("expected values: %s (%d table rows)" % (doc.path, len(doc.rows)))
    skipped = run_checks(rep, Data(root), loc)
    print("\n== Rows not recomputed (%d) ==" % sum(len(v) for v in skipped.values()))
    for reason, items in sorted(skipped.items()):
        print("  %s: %d rows" % (reason, len(items)))
        if not args.quiet:
            for item in items:
                print("    - %s" % item[:160])
    fails = rep.failures
    checked_rows = len(doc.used)
    print("\nSUMMARY: %d table rows checked (%d values recomputed from the data and claims; %d constants of this script compared), "
          "%d not recomputed; %d mismatches"
          % (checked_rows, rep.numbers_checked, rep.constants_compared, sum(len(v) for v in skipped.values()), len(fails)))
    for f in fails:
        print("  MISMATCH %s: %s" % (f["label"], f["detail"]))
    print("RESULT:", "PASS" if not fails else "FAIL")
    if args.json:
        Path(args.json).write_text(json.dumps({"data": str(root), "expected": str(doc.path), "results": rep.results,
                                               "not_recomputed": skipped}, indent=2) + "\n", encoding="utf-8")
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main())
