#!/usr/bin/env python3
"""Subset verifier for AgentGate run folders.

A second implementation of part of the verifier, by the same authors,
ported from the specification and the Go sources, sharing no code with them.
It is not independent: agreement with the Go verifier shows the port is
faithful, not that an outside party confirmed the Go logic.

Python 3 standard library only. Nothing here imports or calls AgentGate code
or the Go verifier: the run folder is read with json, hashlib and the CBOR
decoder below; domain-separated SHA-256, the CBOR length heads and the RFC
8032 Ed25519 verifier are reused from check_vectors.py in this folder.

It checks a SUBSET of the Go verifier's 38 checks (docs/demo/VERIFIER_CHECKS.md),
each one narrower than its Go namesake; SUBSET_VERIFIER.md says exactly what
each covers and what is left out (policy replay, delegation, the provider
journal and reconciliation, approvals, restart segments, the witness, the
catalog commitment, key-ID derivations, timestamps, ...):

    files.present  keys.hash  files.run_record
    chain.entry_hash  chain.signature  chain.links  head.signature  head.matches
    keys.anchor  head.anchor
    artifact.signature (capability tokens and adapter effect receipts only)
    op.requires_policy  op.capability_bound  op.receipts_bound  (the
        classification binding: h_FIN recomputed from the logged FINAL value)
    policy.snapshot_bound  (the policy hash recomputed from run.json)

Usage:

    python docs/paper/artifact/subset_verifier.py RUN_DIR [--expect-keys HEX]
        [--expect-head HEX] [--assume-compromised ROLE[,ROLE...]]
        [--unbound-flags] [--out FILE]
    python docs/paper/artifact/subset_verifier.py --corpus CORPUS/manifest.json
        [--expect-manifest-sha256 HEX] [--out FILE]
    python docs/paper/artifact/subset_verifier.py --self-test

A single verification prints a JSON report (verdict PASSED or FAILED and the
failing subset checks); exit status 0 passed, 1 failed, 2 usage or I/O error.
--assume-compromised mirrors the Go key-compromise simulation
(auditverify.Options.AssumeCompromised): signatures of those roles are
accepted without being verified, and the report is labelled as a simulation.
--corpus verifies every folder of a corpus written by
docs/paper/artifact/corpusgen and compares each verdict with the Go
verifier's expected outcome frozen in the manifest; exit status 0 when every
verdict agrees, 1 otherwise, 2 when the freeze does not hold: manifest.sha256
is missing or does not match the manifest, the manifest does not match
--expect-manifest-sha256 (the hash recorded outside the corpus before the
run), or a folder's files do not match the SHA-256 the manifest records for
them. Nothing is verified unless the freeze holds.
"""

import argparse
import base64
import hashlib
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from check_vectors import domain_hash, ed25519_verify, head as cbor_head, public_from_seed  # noqa: E402

FORMAT = "agentgate-subset-verify/v1"
CORPUS_FORMAT = "agentgate-subset-corpus/v1"

# Subset check IDs, in report order. Each is named after the Go check it is a
# part of; none of them is the whole Go check.
CHECKS = [
    "verifier.error",
    "files.present",
    "keys.hash",
    "files.run_record",
    "chain.entry_hash",
    "chain.signature",
    "chain.links",
    "head.signature",
    "head.matches",
    "keys.anchor",
    "head.anchor",
    "artifact.signature",
    "op.requires_policy",
    "op.capability_bound",
    "op.receipts_bound",
    "policy.snapshot_bound",
]

# Domain-separation labels (docs/demo/CONTRACTS.md, VERIFIER_CHECKS.md).
LABEL_ENTRY = "AgentGate/AuditEntry/v1"
LABEL_ENTRY_SIG = "AgentGate/AuditEntrySig/v1"
LABEL_HEAD = "AgentGate/AuditHead/v1"
LABEL_CAPABILITY_COSE = "AgentGate/Capability/v1/cose"
LABEL_PROVIDER_COSE = "AgentGate/SimulatorReceipt/v1/cose"
LABEL_PRE = "AgentGate/DEVPreDecision/v1"
LABEL_FINAL = "AgentGate/DEVFinalDecision/v1"
LABEL_POLICY = "AgentGate/DEVContentPolicy/v1"
LABEL_SHINGLE = "AgentGate/ConfidentialShingle/v1"
ZERO_HASH = "0" * 64

# Key-compromise simulation: accepted role names and the keys.json roles each
# covers (auditverify compromise.go). Only AUDIT_LOG, CAPABILITY_ISSUER and
# ADAPTER sign anything this subset verifies; the others are accepted so a
# role list from the Go runner can be passed unchanged.
COMPROMISE_ROLES = {
    "AUDIT_LOG": ["AUDIT_LOG"],
    "CAPABILITY_ISSUER": ["CAPABILITY_ISSUER"],
    "ADAPTER": ["ADAPTER_MESSAGE", "ADAPTER_DOCUMENT", "ADAPTER_FINANCIAL"],
    "SIMULATOR_PROVIDER": ["SIMULATOR_PROVIDER"],
    "DELEGATION_AUTHORITY": ["DELEGATION_AUTHORITY"],
    "APPROVAL_AUTHORITY": ["APPROVAL_AUTHORITY", "DEV_APPROVAL_AUTHORITY"],
    "WITNESS": [],
}

ADAPTER_ROLE = {
    "external_message.send": "ADAPTER_MESSAGE",
    "document.release": "ADAPTER_DOCUMENT",
    "financial_request.create": "ADAPTER_FINANCIAL",
}
AUDIENCE = {
    "external_message.send": "urn:agentgate:adapter:external-message:v1",
    "document.release": "urn:agentgate:adapter:document-release:v1",
    "financial_request.create": "urn:agentgate:adapter:financial-request:v1",
}
CONTENT_TYPE = {
    "capability_token": "application/agentgate-cap+cwt",
    "effect_receipt": "application/agentgate-effect-receipt+cbor",
}
# Stages that record a refusal: a bad artifact there is a warning (evidence of
# what was refused, not authority), as in the Go verifier.
REFUSAL_STAGES = {
    "MCP_REJECTED", "REQUEST_REJECTED", "APPROVAL_REJECTED", "APPROVAL_PENDING",
    "APPROVAL_EXPIRED", "APPROVAL_CONFLICT", "POLICY_FINAL_REFUSED", "EFFECT_FAILED",
    "CALL_RESULT", "AGENT_RECEIVED",
}
MAX_CAPABILITY_LIFETIME = 60
SIMULATION_NOTE = ("SIMULATION, NOT A VERIFICATION: signatures of the roles listed were accepted "
                   "without being verified, as if an attacker held their keys.")


# --- CBOR (RFC 8949): a strict decoder and a deterministic encoder ------------

class CBORError(ValueError):
    pass


class Tag:
    __slots__ = ("number", "value")

    def __init__(self, number, value):
        self.number, self.value = number, value


def cbor_decode(data):
    """Decodes one CBOR item that fills data exactly. Indefinite lengths,
    duplicate map keys, floats and unknown simple values are refused."""
    value, end = _cbor_item(data, 0, 0)
    if end != len(data):
        raise CBORError("trailing bytes after the CBOR item")
    return value


def _cbor_argument(data, pos, info):
    if info < 24:
        return info, pos
    size = {24: 1, 25: 2, 26: 4, 27: 8}.get(info)
    if size is None:
        raise CBORError("indefinite length or reserved additional information")
    if pos + size > len(data):
        raise CBORError("truncated CBOR")
    return int.from_bytes(data[pos:pos + size], "big"), pos + size


def _cbor_item(data, pos, depth):
    if depth > 32:
        raise CBORError("CBOR nested too deeply")
    if pos >= len(data):
        raise CBORError("truncated CBOR")
    initial = data[pos]
    pos += 1
    major, info = initial >> 5, initial & 31
    if major == 7:
        simple = {20: False, 21: True, 22: None}
        if info not in simple:
            raise CBORError("unsupported CBOR simple value or float")
        return simple[info], pos
    n, pos = _cbor_argument(data, pos, info)
    if major == 0:
        return n, pos
    if major == 1:
        return -1 - n, pos
    if major in (2, 3):
        if pos + n > len(data):
            raise CBORError("truncated CBOR string")
        raw = bytes(data[pos:pos + n])
        if major == 2:
            return raw, pos + n
        try:
            return raw.decode("utf-8"), pos + n
        except UnicodeDecodeError:
            raise CBORError("CBOR text is not UTF-8")
    if major == 4:
        items = []
        for _ in range(n):
            item, pos = _cbor_item(data, pos, depth + 1)
            items.append(item)
        return items, pos
    if major == 5:
        out = {}
        for _ in range(n):
            key, pos = _cbor_item(data, pos, depth + 1)
            if not isinstance(key, (int, str, bytes)) or isinstance(key, bool):
                raise CBORError("unsupported CBOR map key")
            if key in out:
                raise CBORError("duplicate CBOR map key")
            out[key], pos = _cbor_item(data, pos, depth + 1)
        return out, pos
    value, pos = _cbor_item(data, pos, depth + 1)
    return Tag(n, value), pos


def cbor_encode(x):
    """RFC 8949 core deterministic encoding of ints, bools, bytes, text, lists
    and maps (keys ordered by their encoded bytes)."""
    if isinstance(x, bool):
        return b"\xf5" if x else b"\xf4"
    if isinstance(x, int):
        return cbor_head(0, x) if x >= 0 else cbor_head(1, -1 - x)
    if isinstance(x, bytes):
        return cbor_head(2, len(x)) + x
    if isinstance(x, str):
        raw = x.encode("utf-8")
        return cbor_head(3, len(raw)) + raw
    if isinstance(x, (list, tuple)):
        return cbor_head(4, len(x)) + b"".join(cbor_encode(i) for i in x)
    if isinstance(x, dict):
        pairs = sorted((cbor_encode(k), cbor_encode(v)) for k, v in x.items())
        return cbor_head(5, len(pairs)) + b"".join(k + v for k, v in pairs)
    raise CBORError("cannot encode %r" % (x,))


# --- small helpers -----------------------------------------------------------

_SIGNATURE_CACHE = {}


def verify_signature(public, message, signature):
    """Ed25519 verification, memoized (a corpus repeats most signatures)."""
    key = (public, message, signature)
    if key not in _SIGNATURE_CACHE:
        _SIGNATURE_CACHE[key] = ed25519_verify(public, message, signature)
    return _SIGNATURE_CACHE[key]


def sha256_hex(data):
    return hashlib.sha256(data).hexdigest()


def op_text(raw):
    """A 16-byte operation ID as audit entries write it: unpadded base64url."""
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def hex_equal(raw, text):
    return isinstance(raw, bytes) and isinstance(text, str) and text != "" and raw.hex() == text.lower()


def short(text):
    text = text if isinstance(text, str) else (text.hex() if isinstance(text, bytes) else str(text))
    return text if len(text) <= 12 else text[:8] + "..."


def b64decode_std(text):
    if not isinstance(text, str):
        raise ValueError("not a base64 string")
    return base64.b64decode(text, validate=True)


def unique_pairs(pairs):
    """json object_pairs_hook that refuses duplicate member names."""
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError("duplicate JSON member %r" % key)
        out[key] = value
    return out


def load_json_bytes(raw):
    return json.loads(raw.decode("utf-8"), object_pairs_hook=unique_pairs)


def is_uint(x):
    return isinstance(x, int) and not isinstance(x, bool) and x >= 0


class Checks:
    """Per-check item results: pass/fail/warn counts and failure messages."""

    def __init__(self):
        self.items = {cid: {"pass": 0, "fail": [], "warn": [], "simulated": 0} for cid in CHECKS}

    def ok(self, cid, simulated=False):
        self.items[cid]["pass"] += 1
        if simulated:
            self.items[cid]["simulated"] += 1

    def fail(self, cid, message):
        self.items[cid]["fail"].append(message)

    def warn(self, cid, message):
        self.items[cid]["warn"].append(message)

    def status(self, cid):
        item = self.items[cid]
        if item["fail"]:
            return "fail"
        if item["warn"]:
            return "warn"
        if item["pass"]:
            return "pass"
        return "not_applicable"


# --- reading the run folder ----------------------------------------------------

class LogLine:
    __slots__ = ("index", "entry_hash", "signature", "entry_bytes", "entry", "layout_ok")

    def __init__(self, index):
        self.index = index
        self.entry_hash = self.signature = None
        self.entry_bytes = self.entry = None
        self.layout_ok = False

    @property
    def stage(self):
        return (self.entry or {}).get("stage", "")

    @property
    def op(self):
        return (self.entry or {}).get("operation_id", "") or ""

    @property
    def details(self):
        details = (self.entry or {}).get("details")
        return details if isinstance(details, dict) else {}

    def detail(self, name):
        value = self.details.get(name)
        return value if isinstance(value, str) else ""

    @property
    def seq(self):
        seq = (self.entry or {}).get("seq")
        return seq if is_uint(seq) else 0

    def label(self):
        return "entry #%d (%s)" % (self.seq or self.index, self.stage or "?")


def parse_log(raw, checks):
    lines = []
    parts = raw.split(b"\n")
    if parts and parts[-1] == b"":
        parts.pop()
    for index, data in enumerate(parts, start=1):
        line = LogLine(index)
        lines.append(line)
        try:
            record = load_json_bytes(data)
            line.entry_hash, line.signature = record.get("entry_hash"), record.get("signature")
            if not isinstance(line.entry_hash, str) or not isinstance(line.signature, str) or set(record) != {"entry_hash", "signature", "entry"}:
                raise ValueError("members are not exactly entry_hash, signature, entry")
            prefix = ('{"entry_hash":"%s","signature":"%s","entry":' % (line.entry_hash, line.signature)).encode("utf-8")
            if not data.startswith(prefix) or not data.endswith(b"}"):
                raise ValueError("the line is not laid out as the recorder writes it")
            line.entry_bytes = data[len(prefix):-1]
            entry = load_json_bytes(line.entry_bytes)
            if not isinstance(entry, dict):
                raise ValueError("the entry is not a JSON object")
            line.entry = entry
            line.layout_ok = True
        except (ValueError, UnicodeDecodeError) as err:
            checks.fail("chain.entry_hash", "line %d is unreadable or ambiguous: %s" % (index, err))
    return lines


class Run:
    """The files of one run folder, read once."""

    def __init__(self, directory, checks):
        self.dir = Path(directory)
        self.raw = {}
        self.audit_raw = self.keys = self.run = self.head = None
        for name in ("audit.jsonl", "head.json", "keys.json", "run.json"):
            path = self.dir / name
            try:
                self.raw[name] = path.read_bytes()
            except OSError as err:
                checks.fail("files.present", "%s cannot be read (%s)" % (name, err.strerror or err))
                continue
            if name == "audit.jsonl":
                continue
            try:
                parsed = load_json_bytes(self.raw[name])
                if not isinstance(parsed, dict):
                    raise ValueError("not a JSON object")
            except (ValueError, UnicodeDecodeError) as err:
                checks.fail("files.present", "%s is not unambiguous JSON (%s)" % (name, err))
                continue
            checks.ok("files.present")
            setattr(self, {"head.json": "head", "keys.json": "keys", "run.json": "run"}[name], parsed)
        self.lines = []
        if "audit.jsonl" in self.raw:
            checks.ok("files.present")
            self.lines = parse_log(self.raw["audit.jsonl"], checks)
        # keys.json: kid (lowercase hex) -> (role, public key bytes)
        self.key_by_kid = {}
        audit = []
        for item in (self.keys or {}).get("keys", []) if isinstance((self.keys or {}).get("keys"), list) else []:
            if not isinstance(item, dict):
                continue
            kid, role = item.get("kid"), item.get("role")
            try:
                public = b64decode_std(item.get("public_key"))
            except ValueError:
                continue
            if not isinstance(kid, str) or not isinstance(role, str) or len(public) != 32:
                continue
            self.key_by_kid[kid.lower()] = (role, public)
            if role == "AUDIT_LOG":
                audit.append((kid.lower(), public))
        self.audit_key = audit[0] if len(audit) == 1 else None
        self.audit_key_problem = "" if self.audit_key else "keys.json does not list exactly one usable AUDIT_LOG key"

    def run_started(self):
        for line in self.lines:
            if line.stage == "RUN_STARTED":
                return line
        return None

    def run_escalation(self):
        policy = (self.run or {}).get("policy")
        mode = policy.get("escalation") if isinstance(policy, dict) else None
        return mode if isinstance(mode, str) else ""

    def snapshot(self):
        run = self.run or {}
        snapshot = run.get("policy_snapshot")
        if isinstance(snapshot, dict):
            return snapshot
        policy = run.get("policy")
        if isinstance(policy, dict) and isinstance(policy.get("snapshot"), dict):
            return policy["snapshot"]
        return None


# --- COSE_Sign1 artifacts --------------------------------------------------------

class Artifact:
    __slots__ = ("name", "raw", "payload", "problem", "simulated")

    def __init__(self, name, raw):
        self.name, self.raw = name, raw
        self.payload = None
        self.problem = ""
        self.simulated = False

    def ok(self):
        return self.problem == ""


def parse_cose(raw):
    """Tag(18)[protected bstr, {} , payload bstr, signature bstr(64)] with the
    protected header AgentGate uses. Returns (protected, header, payload,
    signature) or raises ValueError."""
    item = cbor_decode(raw)
    if not isinstance(item, Tag) or item.number != 18:
        raise ValueError("is not a COSE_Sign1 object (CBOR tag 18)")
    parts = item.value
    if not isinstance(parts, list) or len(parts) != 4:
        raise ValueError("is not a 4-element COSE_Sign1 array")
    protected, unprotected, payload, signature = parts
    if not isinstance(protected, bytes) or not isinstance(unprotected, dict) or not isinstance(payload, bytes) or not isinstance(signature, bytes):
        raise ValueError("has COSE_Sign1 fields of the wrong type")
    if unprotected:
        raise ValueError("has unprotected headers")
    if len(signature) != 64:
        raise ValueError("has a %d-byte signature" % len(signature))
    header = cbor_decode(protected)
    if not isinstance(header, dict):
        raise ValueError("has an unreadable protected header")
    for label in header:
        if label not in (1, 2, 3, 4, -65537):
            raise ValueError("has the unknown protected header parameter %r" % (label,))
    if 2 in header and header[2] != [-65537]:
        raise ValueError("marks header parameters as critical that the verifier does not process")
    if -65537 in header and header[-65537] != 1:
        raise ValueError("declares an unknown AgentGate profile version")
    if header.get(1) != -8:
        raise ValueError("does not declare the EdDSA algorithm")
    if not isinstance(header.get(3), str):
        raise ValueError("has no content type")
    if not isinstance(header.get(4), bytes) or len(header[4]) != 32:
        raise ValueError("has no 32-byte key id")
    return protected, header, payload, signature


def verify_artifact(run, name, raw, effect_type, compromised_roles):
    artifact = Artifact(name, raw)
    try:
        protected, header, payload, signature = parse_cose(raw)
    except (ValueError, CBORError) as err:
        artifact.problem = str(err)
        return artifact
    if header[3] != CONTENT_TYPE[name]:
        artifact.problem = "has content type %r, not %r" % (header[3], CONTENT_TYPE[name])
        return artifact
    key = run.key_by_kid.get(header[4].hex())
    if key is None:
        artifact.problem = "is signed with key %s, which keys.json does not list" % short(header[4])
        return artifact
    role, public = key
    want = "CAPABILITY_ISSUER" if name == "capability_token" else ADAPTER_ROLE.get(effect_type)
    if want is None:
        artifact.problem = "belongs to the unknown effect type %r" % effect_type
        return artifact
    if role != want:
        artifact.problem = "is signed by a %s key, not a %s key" % (role, want)
        return artifact
    try:
        artifact.payload = cbor_decode(payload)
    except CBORError as err:
        artifact.payload = None
        artifact.problem = "has an unreadable payload (%s)" % err
        return artifact
    if role in compromised_roles:
        artifact.simulated = True
        return artifact
    sig_structure = cbor_encode(["Signature1", protected, b"", payload])
    if not verify_signature(public, sig_structure, signature):
        artifact.problem = "does not verify with key %s (%s)" % (short(header[4]), role)
    return artifact


# --- decision values --------------------------------------------------------------

class Decision:
    def __init__(self):
        self.tag = self.outcome = self.effect_type = ""
        self.operation_id = self.policy_hash = self.effect_digest = self.pre_hash = self.overlay_root = None
        self.escalation = ""
        self.flagged = False
        self.rules = []
        self.ablated = False


def open_decision(line, label):
    """Recomputes the decision hash from the logged value; returns (Decision,
    problem)."""
    text = line.detail("decision_value")
    if text == "":
        return None, "does not record its decision value"
    try:
        raw = b64decode_std(text)
    except ValueError:
        return None, "records a decision value that is not valid base64"
    recomputed = domain_hash(label, raw)
    if not hex_equal(recomputed, line.detail("decision_hash")):
        return None, "records a decision value that hashes to %s, not to its decision_hash %s" % (short(recomputed), short(line.detail("decision_hash")))
    try:
        fields = cbor_decode(raw)
    except CBORError:
        return None, "records a decision value that is not readable CBOR"
    if not isinstance(fields, dict) or not all(isinstance(k, int) for k in fields):
        return None, "records a decision value that is not an integer-keyed map"
    problem = None
    value = Decision()
    try:
        if fields.get(0) != 1 or isinstance(fields.get(0), bool):
            raise ValueError("is not version 1")
        value.tag = _text(fields, 1)
        if label == LABEL_FINAL:
            _parse_final(fields, value)
        else:
            _parse_pre(fields, value)
    except ValueError as err:
        problem = "records a decision value that " + str(err)
    return (None, problem) if problem else (value, "")


def _text(fields, key):
    value = fields.get(key)
    if not isinstance(value, str):
        raise ValueError("lacks text field %d" % key)
    return value


def _bytes(fields, key):
    value = fields.get(key)
    if not isinstance(value, bytes):
        raise ValueError("lacks byte-string field %d" % key)
    return value


def _texts(fields, key):
    value = fields.get(key)
    if not isinstance(value, list) or not all(isinstance(i, str) for i in value):
        raise ValueError("lacks text-list field %d" % key)
    return value


def _closed(fields, base, closed):
    """The fields below base (the extension range starts at base) must be
    the closed fields 0..closed-1."""
    kept = {k: v for k, v in fields.items() if k < base}
    for key in kept:
        if key < 0 or key >= closed:
            raise ValueError("has an unknown field %d" % key)
    return kept


def _parse_pre(fields, value):
    value.outcome, value.operation_id = _text(fields, 2), _bytes(fields, 3)
    value.effect_type, value.policy_hash = _text(fields, 4), _bytes(fields, 5)
    if value.tag == "DEV_PRE":
        if len(fields) != 6:
            raise ValueError("has the wrong number of fields for DEV_PRE")
        return
    if value.tag != "DEV_CONTENT_PRE":
        raise ValueError("has the unknown PRE tag %r" % value.tag)
    value.effect_digest = _bytes(fields, 6)
    kept = _closed(fields, 10, 10)
    if 7 not in kept and len(kept) == 7:
        value.ablated = True  # the unbound-flags ablation: fields 0-6 only
        return
    value.rules = _texts(fields, 7)
    if len(kept) == 8:
        value.escalation = "human"
    elif len(kept) == 10:
        value.escalation = _text(fields, 8)
        flagged = fields.get(9)
        if not isinstance(flagged, bool):
            raise ValueError("lacks its flag")
        value.flagged = flagged
    else:
        raise ValueError("has the wrong number of fields for DEV_CONTENT_PRE")


def _parse_final(fields, value):
    value.outcome, value.pre_hash, value.operation_id = _text(fields, 2), _bytes(fields, 3), _bytes(fields, 4)
    value.effect_type, value.policy_hash = _text(fields, 5), _bytes(fields, 6)
    if value.outcome != "ALLOW":
        raise ValueError("has outcome %r, not ALLOW" % value.outcome)
    closed = {"DEV_FINAL": 7, "DEV_FINAL_FLAGGED": 10, "DEV_FINAL_HUMAN_APPROVED": 11}.get(value.tag)
    if closed is None:
        raise ValueError("has the unknown FINAL tag %r" % value.tag)
    kept = _closed(fields, 11 if value.tag == "DEV_FINAL_HUMAN_APPROVED" else 10, closed)
    if len(kept) != closed:
        raise ValueError("has the wrong number of fields for %s" % value.tag)
    if value.tag == "DEV_FINAL_FLAGGED":
        value.escalation, value.flagged, value.rules = _text(fields, 7), fields.get(8), _texts(fields, 9)
        if value.escalation != "flag" or value.flagged is not True or not value.rules:
            raise ValueError("is not a complete DEV_FINAL_FLAGGED value")
    elif value.tag == "DEV_FINAL_HUMAN_APPROVED":
        value.overlay_root = _bytes(fields, 7)


def reason_rules(line):
    rules, flagged = [], 0
    reasons = line.details.get("reasons")
    for reason in reasons if isinstance(reasons, list) else []:
        reason = reason if isinstance(reason, dict) else {}
        rule_id = reason.get("rule_id")
        rules.append(rule_id if isinstance(rule_id, str) else "")
        if reason.get("outcome") == "FLAG":
            flagged += 1
    return sorted(rules), flagged


def mode_problems(seq, mode, flagged, run_mode):
    if mode and run_mode and mode != run_mode:
        return ["the decision at entry #%d was made in escalation mode %r, but run.json records mode %r" % (seq, mode, run_mode)]
    if flagged and run_mode != "flag":
        return ["the action is flagged for audit, but run.json records escalation mode %r, not flag" % run_mode]
    return []


# --- policy hash (VERIFIER_CHECKS.md section 3) ------------------------------------

def _first(obj, *names):
    for name in names:
        if name in obj:
            return obj[name]
    return None


def snapshot_policy_hash(snapshot, run_mode):
    """Recomputes the content policy hash from run.json's policy snapshot.
    Returns (hash bytes, None) or (None, problem)."""
    missing = []
    name, version = snapshot.get("name"), snapshot.get("version")
    if not isinstance(name, str) or not name or not isinstance(version, str) or not version:
        missing.append("the policy name or version")
    organization = snapshot.get("organization_name")
    if not isinstance(organization, str):
        missing.append("the organization name")
    domain = snapshot.get("hash_domain")
    if domain not in (None, "", LABEL_POLICY):
        missing.append("a content-policy hash domain")
    rules = snapshot.get("rules")
    rows = []
    if not isinstance(rules, list):
        missing.append("the rule list")
        rules = []
    for index, rule in enumerate(rules, start=1):
        rule = rule if isinstance(rule, dict) else {}
        row = {}
        for key, member in enumerate(("id", "effect_type", "outcome", "description")):
            if not isinstance(rule.get(member), str):
                missing.append("the %s of rule %d" % (member, index))
                break
            row[key] = rule[member]
        rows.append(row)

    escalation = _first(snapshot, "escalation", "escalation_mode")
    escalation = escalation if isinstance(escalation, str) and escalation else (run_mode or "human")
    if escalation not in ("flag", "human", "deny"):
        return None, "the unknown escalation mode %r" % escalation
    max_recipients = snapshot.get("max_recipients")
    if not is_uint(max_recipients) or not 1 <= max_recipients < 1 << 31:
        missing.append("max_recipients")

    # Limits: per-currency (list or object), else the single global pair.
    per_currency = {}
    limits = _first(snapshot, "currency_limits", "per_currency_limits", "limits")

    def read_pair(currency, entry):
        entry = entry if isinstance(entry, dict) else {}
        auto = _first(entry, "auto_minor", "auto", "auto_approve_limit_minor", "auto_limit_minor")
        hard = _first(entry, "hard_minor", "hard", "hard_limit_minor")
        if not isinstance(currency, str) or not currency or not is_uint(auto) or not is_uint(hard) or auto > hard:
            return False
        per_currency[currency] = (auto, hard)
        return True

    if isinstance(limits, dict):
        for currency, entry in limits.items():
            if not read_pair(currency, entry):
                missing.append("valid limits for currency %s" % currency)
    elif isinstance(limits, list):
        for entry in limits:
            if not read_pair((entry or {}).get("currency") if isinstance(entry, dict) else None, entry):
                missing.append("valid per-currency limits")
                break
    allowed = [c for c in (_first(snapshot, "allowed_currencies", "currencies") or []) if isinstance(c, str)]
    if not allowed:
        allowed = list(per_currency)
    if not allowed:
        missing.append("the allowed currencies")
    global_auto = _first(snapshot, "auto_approve_limit_minor", "auto_limit_minor")
    global_hard = snapshot.get("hard_limit_minor")
    global_pair = None
    if not per_currency and is_uint(global_auto) and is_uint(global_hard) and 0 < global_auto <= global_hard:
        global_pair = (global_auto, global_hard)
    currencies = {}
    for currency in allowed:
        if currency in per_currency:
            currencies[currency] = per_currency[currency]
        elif global_pair:
            currencies[currency] = global_pair
        else:
            missing.append("limits for currency %s" % currency)
    deny_zero = snapshot.get("deny_zero_amount") is True

    # Confidential-text shingles.
    has_shingles, words, shingle_label, hashes = False, 12, LABEL_SHINGLE, None
    hashes = _first(snapshot, "confidential_shingle_hashes", "shingle_hashes")
    group = _first(snapshot, "confidential_shingles", "confidential_text")
    if isinstance(group, dict):
        has_shingles = True
        w = _first(group, "words", "shingle_words", "size")
        if is_uint(w) and 1 <= w <= 1000:
            words = w
        label = _first(group, "hash_domain", "label", "hash_label")
        if isinstance(label, str) and label:
            shingle_label = label
        hashes = _first(group, "hashes", "shingle_hashes")
    elif isinstance(snapshot.get("confidential_shingles"), list):
        hashes = snapshot["confidential_shingles"]
    if isinstance(hashes, list):
        has_shingles = True
    w = snapshot.get("shingle_words")
    if is_uint(w) and 1 <= w <= 1000:
        words = w
    if has_shingles and shingle_label != LABEL_SHINGLE:
        missing.append("the gateway's shingle hash label")
    if missing:
        return None, "lacks " + " and ".join(missing)

    ordered = sorted(currencies)
    fields = {0: 1, 1: name, 2: version, 3: rows, 4: 0, 5: 0, 6: ordered, 7: max_recipients, 8: organization}
    if global_pair:
        fields[4], fields[5] = global_pair
    else:
        fields[10] = [[c, currencies[c][0], currencies[c][1]] for c in ordered]
    if escalation != "human":
        fields[9] = escalation
    if deny_zero:
        fields[11] = True
    if has_shingles:
        values = []
        for text in sorted({h.lower() for h in hashes or [] if isinstance(h, str)}):
            try:
                raw = bytes.fromhex(text)
            except ValueError:
                raw = b""
            if len(raw) != 32:
                return None, "a shingle hash %r that is not 32 bytes of hex" % short(text)
            values.append(raw)
        fields[12] = {0: words, 1: values}
    return domain_hash(LABEL_POLICY, cbor_encode(fields)), None


# --- the verification ----------------------------------------------------------------

def resolve_compromise(names):
    canonical, roles = [], set()
    for name in names:
        upper = name.strip().upper()
        if not upper:
            continue
        if upper not in COMPROMISE_ROLES:
            raise ValueError("unknown role %r (known: %s)" % (name, ", ".join(COMPROMISE_ROLES)))
        if upper not in canonical:
            canonical.append(upper)
        roles.update(COMPROMISE_ROLES[upper])
    canonical.sort(key=list(COMPROMISE_ROLES).index)
    return canonical, roles


def verify_run(directory, expect_keys="", expect_head="", assume_compromised=(), unbound_flags=False):
    """Verifies one run folder with the subset checks and returns the report
    (a dict)."""
    canonical, compromised = resolve_compromise(assume_compromised)
    checks = Checks()
    try:
        _verify(directory, checks, expect_keys.strip().lower(), expect_head.strip().lower(), compromised, unbound_flags)
    except Exception as err:  # the panic guard: any crash fails the run
        checks.fail("verifier.error", "the subset verifier could not process the evidence: %s: %s" % (type(err).__name__, err))
    failing = [cid for cid in CHECKS if checks.status(cid) == "fail"]
    report = {
        "format": FORMAT,
        "dir": str(directory),
        "verdict": "FAILED" if failing else "PASSED",
        "failing_checks": failing,
        "warnings": [cid for cid in CHECKS if checks.status(cid) == "warn"],
        "subset": "Checks a subset of the Go verifier's 38 checks (SUBSET_VERIFIER.md); PASSED is not a verdict of the full verifier.",
        "unbound_flags": bool(unbound_flags),
        "checks": [
            {"id": cid, "status": checks.status(cid), "passed": checks.items[cid]["pass"],
             "failed": len(checks.items[cid]["fail"]), "warned": len(checks.items[cid]["warn"]),
             "simulated": checks.items[cid]["simulated"],
             "messages": (checks.items[cid]["fail"] + checks.items[cid]["warn"])[:5]}
            for cid in CHECKS
        ],
    }
    if canonical:
        report["simulation"] = {"assume_compromised": canonical, "note": SIMULATION_NOTE}
    return report


def _verify(directory, checks, expect_keys, expect_head, compromised, unbound):
    run = Run(directory, checks)
    lines = run.lines
    started = run.run_started()
    audit_compromised = "AUDIT_LOG" in compromised

    # keys.hash and files.run_record: keys.json and run.json bound to RUN_STARTED.
    if "keys.json" in run.raw:
        keys_sha = sha256_hex(run.raw["keys.json"])
        recorded = [("run.json keys_sha256", (run.run or {}).get("keys_sha256")),
                    ("RUN_STARTED keys_sha256", started.details.get("keys_sha256") if started else None)]
        bad = [what for what, value in recorded if not isinstance(value, str) or value.lower() != keys_sha]
        if bad:
            checks.fail("keys.hash", "SHA-256 of keys.json is %s, which does not match %s" % (short(keys_sha), ", ".join(bad)))
        else:
            checks.ok("keys.hash")
    if "run.json" in run.raw:
        run_sha = sha256_hex(run.raw["run.json"])
        recorded = started.details.get("run_sha256") if started else None
        if not isinstance(recorded, str) or recorded.lower() != run_sha:
            checks.fail("files.run_record", "SHA-256 of run.json is %s, but RUN_STARTED records %s" % (short(run_sha), short(recorded or "(none)")))
        else:
            checks.ok("files.run_record")
        policy = (run.run or {}).get("policy")
        policy_hash = policy.get("hash") if isinstance(policy, dict) else None
        for line in lines:
            if line.stage == "POLICY_DECISION" and line.detail("policy_hash") and isinstance(policy_hash, str):
                if line.detail("policy_hash").lower() != policy_hash.lower():
                    checks.fail("files.run_record", "%s names policy %s, not run.json's %s" % (line.label(), short(line.detail("policy_hash")), short(policy_hash)))

    # chain.entry_hash, chain.signature, chain.links.
    prev = ZERO_HASH
    for position, line in enumerate(lines, start=1):
        if line.layout_ok:
            recomputed = domain_hash(LABEL_ENTRY, line.entry_bytes).hex()
            if recomputed != line.entry_hash:
                checks.fail("chain.entry_hash", "%s: the entry hashes to %s, not to its entry_hash %s" % (line.label(), short(recomputed), short(line.entry_hash)))
            else:
                checks.ok("chain.entry_hash")
            entry = line.entry
            if entry.get("seq") != position or isinstance(entry.get("seq"), bool) or entry.get("prev_hash") != prev:
                checks.fail("chain.links", "line %d: seq %r / prev_hash %s do not follow line %d" % (position, entry.get("seq"), short(str(entry.get("prev_hash"))), position - 1))
            else:
                checks.ok("chain.links")
        if line.signature is not None:
            # The key must be usable even when its holder is simulated, as in
            # head.signature below and in the Go simulation.
            if run.audit_key is None:
                checks.fail("chain.signature", "line %d cannot be checked: %s" % (position, run.audit_key_problem))
            elif audit_compromised:
                checks.ok("chain.signature", simulated=True)
            else:
                try:
                    signature = b64decode_std(line.signature)
                    message = LABEL_ENTRY_SIG.encode("ascii") + b"\x00" + bytes.fromhex(line.entry_hash)
                    good = len(bytes.fromhex(line.entry_hash)) == 32 and verify_signature(run.audit_key[1], message, signature)
                except ValueError:
                    good = False
                if good:
                    checks.ok("chain.signature")
                else:
                    checks.fail("chain.signature", "line %d: the audit-key signature does not verify" % position)
        prev = line.entry_hash if isinstance(line.entry_hash, str) else ""
    if "audit.jsonl" in run.raw and not lines:
        checks.fail("chain.links", "audit.jsonl has no entries")
    last = lines[-1] if lines else None

    # head.signature, head.matches.
    head = run.head
    if head is not None:
        seq, entry_hash, run_id = head.get("seq"), head.get("entry_hash"), head.get("run_id")
        kid = head.get("kid")
        if run.audit_key is None:
            checks.fail("head.signature", "head.json cannot be checked: %s" % run.audit_key_problem)
        elif not isinstance(kid, str) or kid.lower() != run.audit_key[0]:
            checks.fail("head.signature", "head.json names key %s, not the audit key" % short(str(kid)))
        elif not is_uint(seq) or not isinstance(entry_hash, str) or not isinstance(run_id, str):
            checks.fail("head.signature", "head.json lacks run_id, seq or entry_hash")
        elif audit_compromised:
            checks.ok("head.signature", simulated=True)
        else:
            message = ("%s\x00%s\x00%d\x00%s" % (LABEL_HEAD, run_id, seq, entry_hash)).encode("utf-8")
            try:
                good = verify_signature(run.audit_key[1], message, b64decode_std(head.get("signature")))
            except ValueError:
                good = False
            if good:
                checks.ok("head.signature")
            else:
                checks.fail("head.signature", "head.json's signature does not verify with the audit key")
        if last is None or seq != last.seq or entry_hash != last.entry_hash:
            checks.fail("head.matches", "head.json names entry #%r %s, but the log ends at #%s %s" % (seq, short(str(entry_hash)), last.seq if last else "-", short(last.entry_hash or "") if last else "-"))
        else:
            checks.ok("head.matches")

    # keys.anchor, head.anchor (pins from outside the folder).
    if "keys.json" in run.raw:
        if not expect_keys:
            checks.warn("keys.anchor", "no keys anchor given: a complete re-signing with substitute keys cannot be ruled out")
        elif sha256_hex(run.raw["keys.json"]) == expect_keys:
            checks.ok("keys.anchor")
        else:
            checks.fail("keys.anchor", "keys.json hashes to %s, not to the pinned %s" % (short(sha256_hex(run.raw["keys.json"])), short(expect_keys)))
    if not expect_head:
        checks.warn("head.anchor", "no head anchor given: a coherent rollback cannot be ruled out")
    elif last is not None and last.entry_hash == expect_head:
        checks.ok("head.anchor")
    else:
        checks.fail("head.anchor", "the log ends at %s, not at the pinned head %s" % (short(last.entry_hash or "") if last else "(empty)", short(expect_head)))

    # artifact.signature: capability tokens and adapter effect receipts.
    artifacts = {}
    for line in lines:
        found = line.entry.get("artifacts") if line.entry else None
        for name in ("capability_token", "effect_receipt"):
            if not isinstance(found, dict) or name not in found:
                continue
            try:
                raw = b64decode_std(found[name])
                artifact = verify_artifact(run, name, raw, (line.entry or {}).get("effect_type", ""), compromised)
            except ValueError:
                artifact = Artifact(name, b"")
                artifact.problem = "is not valid base64"
            artifacts[(line.index, name)] = artifact
            if artifact.ok():
                checks.ok("artifact.signature", simulated=artifact.simulated)
            elif line.stage in REFUSAL_STAGES:
                checks.warn("artifact.signature", "%s: the %s %s (a refusal stage: kept as evidence only)" % (line.label(), name, artifact.problem))
            else:
                checks.fail("artifact.signature", "%s: the %s %s" % (line.label(), name, artifact.problem))

    # The authorization chain per operation, in log order.
    run_mode = run.run_escalation()
    snapshot = run.snapshot()
    content_run = bool(run_mode) or (snapshot is not None and snapshot.get("kind") == "content")
    state = {}
    call_flags = {}  # (operation, call_id) -> the flag the executing capability's FINAL commits to
    for line in lines:
        if not line.layout_ok or not line.op:
            continue
        op = state.setdefault(line.op, {"validated": None, "pres": {}, "final": None, "capability": None})
        stage = line.stage
        if stage == "REQUEST_VALIDATED":
            op["validated"] = line
        elif stage == "POLICY_DECISION":
            op["pres"][line.detail("decision_hash").lower()] = line
        elif stage == "POLICY_FINAL" and (line.entry or {}).get("outcome") == "allow":
            op["final"] = line
        elif stage == "CAPABILITY_ISSUED":
            op["capability"] = _check_capability(line, op, artifacts.get((line.index, "capability_token")), checks, unbound, run_mode, content_run)
        elif stage == "EFFECT_EXECUTED":
            flag = _check_receipt(line, op, artifacts.get((line.index, "effect_receipt")), checks)
            if line.detail("call_id") and flag is not None:
                call_flags[(line.op, line.detail("call_id"))] = flag
        elif stage == "CALL_RESULT" and not unbound:
            flag = call_flags.get((line.op, line.detail("call_id")))
            stated = line.details.get("flagged")
            if flag is not None and isinstance(stated, bool):
                if stated != flag:
                    checks.fail("op.requires_policy", "%s records flagged=%s, but the decision value its capability binds says flagged=%s" % (line.label(), stated, flag))
                else:
                    checks.ok("op.requires_policy")

    # policy.snapshot_bound.
    _check_snapshot(run, snapshot, run_mode, lines, artifacts, checks)


def _check_capability(line, op, artifact, checks, unbound, run_mode, content_run):
    """op.capability_bound and op.requires_policy for one capability. Returns
    the capability state the execution checks use."""
    label = line.label()
    capability = {"line": line, "artifact": artifact, "claims": None, "final_flag": None}
    if artifact is None:
        checks.fail("op.capability_bound", "%s carries no capability_token" % label)
        return capability
    if not artifact.ok() or not isinstance(artifact.payload, dict):
        checks.fail("op.capability_bound", "%s: the capability token does not verify, so its claims cannot be trusted" % label)
        return capability
    claims = artifact.payload
    capability["claims"] = claims
    problems = []
    if not isinstance(claims.get(-70002), bytes) or op_text(claims[-70002]) != line.op:
        problems.append("the capability is for another operation")
    effect_type = (line.entry or {}).get("effect_type", "")
    if claims.get(-70003) != effect_type:
        problems.append("the capability is for a %r, not a %r" % (claims.get(-70003), effect_type))
    if AUDIENCE.get(claims.get(-70003)) and claims.get(3) != AUDIENCE[claims.get(-70003)]:
        problems.append("the capability's audience is not the adapter's")
    if not hex_equal(claims.get(-70004), (line.entry or {}).get("effect_digest", "")):
        problems.append("the capability authorizes another action than the entry records")
    validated = op["validated"]
    if validated is not None and not hex_equal(claims.get(-70004), (validated.entry or {}).get("effect_digest", "")):
        problems.append("the capability authorizes another action than the validated request (%s)" % validated.label())
    final = op["final"]
    final_value = None
    if final is None:
        problems.append("there is no POLICY_FINAL decision for it to bind")
    else:
        final_value, problem = open_decision(final, LABEL_FINAL)
        if not hex_equal(claims.get(-70007), final.detail("decision_hash")):
            problems.append("the capability binds policy decision %s, but POLICY_FINAL (%s) decided %s" % (short(claims.get(-70007) or b""), final.label(), short(final.detail("decision_hash"))))
        if problem:
            checks.fail("op.requires_policy", "the POLICY_FINAL at %s %s" % (final.label(), problem))
        else:
            # h_FIN recomputed from the logged value equals what the issuer signed.
            if final_value is not None and claims.get(-70007) != domain_hash(LABEL_FINAL, b64decode_std(final.detail("decision_value"))):
                problems.append("the capability's policy decision hash is not the hash of the logged FINAL value")
            policy_problems = _decision_binding(line, final, final_value, op, unbound, run_mode, content_run)
            if policy_problems:
                for problem in policy_problems:
                    checks.fail("op.requires_policy", "%s: %s" % (label, problem))
            else:
                checks.ok("op.requires_policy")
                capability["final_flag"] = final_value.flagged
    pre = _pre_for(final, final_value, op)
    if pre is not None and claims.get(-70009) is not None and not hex_equal(claims.get(-70009), pre.detail("policy_hash")):
        problems.append("the capability was issued under policy %s, but the policy decision (%s) names %s" % (short(claims.get(-70009)), pre.label(), short(pre.detail("policy_hash"))))
    cti = line.detail("cti")
    if cti and not hex_equal(claims.get(7), cti):
        problems.append("the entry's cti is not the token's")
    nbf, iat, exp = claims.get(5), claims.get(6), claims.get(4)
    if not (is_uint(nbf) and is_uint(iat) and is_uint(exp)) or nbf > iat or iat > exp or exp - iat > MAX_CAPABILITY_LIFETIME:
        problems.append("its validity window is not a short-lived window of at most %d seconds" % MAX_CAPABILITY_LIFETIME)
    if problems:
        checks.fail("op.capability_bound", "%s: %s" % (label, "; ".join(problems)))
    else:
        checks.ok("op.capability_bound")
    return capability


def _pre_for(final, final_value, op):
    if final is None:
        return None
    if final_value is not None:
        return op["pres"].get(final_value.pre_hash.hex())
    return op["pres"].get(final.detail("pre_decision_hash").lower())


def _decision_binding(line, final, final_value, op, unbound, run_mode, content_run):
    """The classification binding: the PRE value FINAL field 3 names, opened,
    and every statement of the log about the decision compared with the
    values (bound design), as in Go's op.requires_policy."""
    problems = []
    add = problems.append
    if op_text(final_value.operation_id) != line.op or final_value.effect_type != (line.entry or {}).get("effect_type"):
        add("the FINAL decision value at %s is for another operation or effect type" % final.label())
    if not hex_equal(final_value.pre_hash, final.detail("pre_decision_hash")):
        add("the FINAL value at %s confirms PRE %s, but its details name %s" % (final.label(), short(final_value.pre_hash), short(final.detail("pre_decision_hash"))))
    pre = op["pres"].get(final_value.pre_hash.hex())
    if pre is None:
        add("the FINAL value at %s confirms PRE %s, which is not a policy decision recorded for this operation" % (final.label(), short(final_value.pre_hash)))
        return problems
    value, problem = open_decision(pre, LABEL_PRE)
    if problem:
        add("the policy decision at %s %s" % (pre.label(), problem))
        return problems
    seq = pre.seq
    if op_text(value.operation_id) != pre.op or value.effect_type != (pre.entry or {}).get("effect_type"):
        add("the decision value at entry #%d is for another operation or effect type" % seq)
    if value.effect_digest is not None and not hex_equal(value.effect_digest, (pre.entry or {}).get("effect_digest", "")):
        add("the decision value at entry #%d is about another action" % seq)
    if not hex_equal(value.policy_hash, pre.detail("policy_hash")) or value.policy_hash != final_value.policy_hash:
        add("the PRE and FINAL values and entry #%d do not name the same policy" % seq)
    if value.tag == "DEV_PRE" and content_run:
        add("the decision value at entry #%d is an operation-table (DEV_PRE) decision in a content-policy run" % seq)
    if not ((value.outcome == "ALLOW_BASE" and final_value.tag in ("DEV_FINAL", "DEV_FINAL_FLAGGED")) or
            (value.outcome == "REQUIRE_APPROVAL" and final_value.tag == "DEV_FINAL_HUMAN_APPROVED")):
        add("a %s FINAL cannot follow the %s decision at entry #%d" % (final_value.tag, value.outcome, seq))
    if unbound:
        # Ablation: the values commit only operation, effect, policy and
        # outcome; the mode is compared with run.json from the details.
        if pre.detail("decision") != value.outcome:
            add("entry #%d records decision %r, but its decision value says %r" % (seq, pre.detail("decision"), value.outcome))
        if value.tag == "DEV_CONTENT_PRE":
            stated_flag = pre.details.get("flagged") is True or (pre.entry or {}).get("outcome") == "allow_flagged"
            problems.extend(mode_problems(seq, pre.detail("escalation") or "human", stated_flag, run_mode))
        return problems
    if value.ablated:
        add("the decision value at entry #%d commits to neither its fired rules nor the flag (the unbound-flags shape)" % seq)
        return problems
    if value.flagged != final_value.flagged:
        add("the decision values disagree on the flag (PRE %s, FINAL %s)" % (value.flagged, final_value.flagged))
    if final_value.tag == "DEV_FINAL_FLAGGED" and final_value.rules != value.rules:
        add("the FINAL names flagging rules %s, but the PRE fired %s" % (final_value.rules, value.rules))
    want = {"ALLOW_BASE": "allow", "REQUIRE_APPROVAL": "approval_required"}.get(value.outcome)
    if value.flagged:
        want = "allow_flagged"
    if (pre.entry or {}).get("outcome") != want:
        add("entry #%d records outcome %r, but its decision value says %r" % (seq, (pre.entry or {}).get("outcome"), want))
    if pre.detail("decision") != value.outcome:
        add("entry #%d records decision %r, but its decision value says %r" % (seq, pre.detail("decision"), value.outcome))
    if (pre.details.get("flagged") is True) != value.flagged:
        add("entry #%d records flagged=%s, but its decision value says flagged=%s" % (seq, pre.details.get("flagged"), value.flagged))
    if value.tag == "DEV_CONTENT_PRE":
        logged = pre.detail("escalation")
        if logged != value.escalation and not (value.escalation == "human" and logged == ""):
            add("entry #%d records escalation mode %r, but its decision value was made in mode %r" % (seq, logged, value.escalation))
        rules, flag_reasons = reason_rules(pre)
        if rules != value.rules:
            add("entry #%d gives reasons from rules %s, but its decision value commits to %s" % (seq, rules, value.rules))
        if (flag_reasons > 0) != value.flagged:
            add("entry #%d has %d FLAG reason(s), but its decision value says flagged=%s" % (seq, flag_reasons, value.flagged))
    if (final.details.get("flagged") is True) != final_value.flagged:
        add("the POLICY_FINAL at %s records flagged=%s, but its decision value says %s" % (final.label(), final.details.get("flagged"), final_value.flagged))
    approved = final_value.tag == "DEV_FINAL_HUMAN_APPROVED"
    if isinstance(final.details.get("human_approved"), bool) and final.details["human_approved"] != approved:
        add("the POLICY_FINAL at %s records human_approved=%s, but its decision value says %s" % (final.label(), final.details["human_approved"], approved))
    if approved and not hex_equal(final_value.overlay_root, final.detail("overlay_root")):
        add("the POLICY_FINAL at %s records another overlay root than its decision value binds" % final.label())
    problems.extend(mode_problems(seq, value.escalation, value.flagged, run_mode))
    return problems


def _check_receipt(line, op, artifact, checks):
    """op.receipts_bound for one execution (the adapter receipt only). Returns
    the flag of the FINAL value the consumed capability binds (None when it
    could not be established)."""
    label = line.label()
    problems = []
    capability = op["capability"]
    if artifact is None:
        problems.append("it carries no effect_receipt")
    elif not artifact.ok() or not isinstance(artifact.payload, dict):
        problems.append("its adapter receipt does not verify")
    else:
        body = artifact.payload
        if not isinstance(body.get("operation_id"), bytes) or op_text(body["operation_id"]) != line.op:
            problems.append("the adapter receipt is for another operation")
        if not hex_equal(body.get("effect_digest"), (line.entry or {}).get("effect_digest", "")):
            problems.append("the adapter receipt is for another action")
        if body.get("effect_type") not in (None, "", (line.entry or {}).get("effect_type")):
            problems.append("the adapter receipt is for a %r" % body.get("effect_type"))
        # The provider receipt is bound by its hash only; its signature is
        # outside the subset.
        provider = provider_raw(line)
        if provider is None or body.get("provider_receipt_hash") != domain_hash(LABEL_PROVIDER_COSE, provider):
            problems.append("the adapter receipt cites another provider receipt than the one recorded")
        if capability is None or capability["claims"] is None:
            problems.append("no verified CAPABILITY_ISSUED precedes it")
        else:
            claims = capability["claims"]
            if body.get("cti") != claims.get(7):
                problems.append("the adapter used another capability than the one issued at %s" % capability["line"].label())
            if body.get("capability_hash") != domain_hash(LABEL_CAPABILITY_COSE, capability["artifact"].raw):
                problems.append("the adapter receipt cites another capability token than the one issued at %s" % capability["line"].label())
            if body.get("policy_decision_hash") != claims.get(-70007):
                problems.append("the adapter receipt binds another policy decision than the capability")
    if problems:
        checks.fail("op.receipts_bound", "%s: %s" % (label, "; ".join(problems)))
        return None
    checks.ok("op.receipts_bound")
    return capability["final_flag"]


def provider_raw(line):
    """The bytes of an entry's provider_receipt artifact, or None."""
    found = (line.entry or {}).get("artifacts")
    try:
        return b64decode_std(found["provider_receipt"]) if isinstance(found, dict) and "provider_receipt" in found else None
    except ValueError:
        return None


def _check_snapshot(run, snapshot, run_mode, lines, artifacts, checks):
    revision = any(role == "DELEGATION_AUTHORITY" for role, _ in run.key_by_kid.values())
    if snapshot is None:
        if revision:
            checks.fail("policy.snapshot_bound", "run.json records no policy snapshot, although keys.json lists a DELEGATION_AUTHORITY key")
        return
    recomputed, problem = snapshot_policy_hash(snapshot, run_mode)
    if recomputed is None:
        checks.fail("policy.snapshot_bound", "run.json's policy snapshot %s, so its policy hash cannot be recomputed" % problem)
        return
    text = recomputed.hex()
    policy = (run.run or {}).get("policy")
    for what, value in (("the snapshot's policy_hash", snapshot.get("policy_hash")),
                        ("run.json policy.hash", policy.get("hash") if isinstance(policy, dict) else None)):
        if isinstance(value, str) and value and value.lower() != text:
            checks.fail("policy.snapshot_bound", "the snapshot recomputes to policy hash %s, but %s is %s" % (short(text), what, short(value)))
    for line in lines:
        if line.stage == "CAPABILITY_ISSUED":
            artifact = artifacts.get((line.index, "capability_token"))
            if artifact is None or not artifact.ok() or not isinstance(artifact.payload, dict):
                continue
            claim = artifact.payload.get(-70009)
            if not isinstance(claim, bytes) or claim != recomputed:
                checks.fail("policy.snapshot_bound", "%s: the issuer signed policy hash %s, but the snapshot recomputes to %s" % (line.label(), short(claim or b""), short(text)))
            else:
                checks.ok("policy.snapshot_bound")
        elif line.stage in ("POLICY_DECISION", "POLICY_FINAL") and line.detail("decision_value"):
            value, problem = open_decision(line, LABEL_PRE if line.stage == "POLICY_DECISION" else LABEL_FINAL)
            if problem:
                continue
            if value.policy_hash != recomputed:
                checks.fail("policy.snapshot_bound", "%s: its decision value commits to policy hash %s, but the snapshot recomputes to %s" % (line.label(), short(value.policy_hash), short(text)))
            else:
                checks.ok("policy.snapshot_bound")


# --- corpus mode -------------------------------------------------------------------

MANIFEST_HASH_FILE = "manifest.sha256"  # written by corpusgen next to manifest.json


def is_sha256_hex(text):
    return isinstance(text, str) and len(text) == 64 and all(c in "0123456789abcdef" for c in text)


def check_freeze(manifest_path, raw, expect_sha256):
    """The freeze: manifest.sha256 must exist and match the manifest, and so
    must the hash given with --expect-manifest-sha256 (recorded outside the
    corpus before the run). Returns (record, problem)."""
    digest = sha256_hex(raw)
    frozen = manifest_path.with_name(MANIFEST_HASH_FILE)
    try:
        fields = frozen.read_text(encoding="ascii").split()
    except (OSError, UnicodeDecodeError) as err:
        return None, "%s cannot be read (%s): without it the freeze of the expected outcomes cannot be checked" % (frozen.name, err)
    pinned = fields[0].lower() if fields else ""
    if not is_sha256_hex(pinned):
        return None, "%s holds no SHA-256" % frozen.name
    if pinned != digest:
        return None, "manifest %s hashes to %s, but %s pins %s: the expected outcomes were changed after they were frozen" % (manifest_path.name, digest, frozen.name, pinned)
    record = {"manifest_sha256": digest, "hash_file": frozen.name, "hash_file_matches": True,
              "expected_sha256": None, "expected_sha256_matches": None}
    if expect_sha256:
        expected = expect_sha256.strip().lower()
        if not is_sha256_hex(expected):
            return None, "--expect-manifest-sha256 is not a SHA-256 (64 hex digits)"
        if expected != digest:
            return None, "manifest %s hashes to %s, not to the recorded %s: the expected outcomes were changed after they were frozen" % (manifest_path.name, digest, expected)
        record["expected_sha256"], record["expected_sha256_matches"] = expected, True
    return record, ""


def check_entry_files(base, entries):
    """Every corpus folder must hold exactly the files the manifest records,
    with the recorded SHA-256 (corpusgen's files_sha256), so the expected
    outcomes describe the bytes verified here. Returns (files checked,
    problems)."""
    problems, checked = [], 0
    for entry in entries:
        if not entry.get("dir"):
            continue
        recorded = entry.get("files_sha256")
        if not isinstance(recorded, dict) or not recorded:
            problems.append("%s: the manifest records no files_sha256 for its folder" % entry.get("id"))
            continue
        folder = base / entry["dir"]
        try:
            names = sorted(item.name for item in folder.iterdir())
        except OSError as err:
            problems.append("%s: %s cannot be read (%s)" % (entry.get("id"), entry["dir"], err.strerror or err))
            continue
        if names != sorted(recorded):
            problems.append("%s: the folder holds %s, the manifest records %s" % (entry.get("id"), names, sorted(recorded)))
            continue
        for name in names:
            path = folder / name
            if not path.is_file() or sha256_hex(path.read_bytes()) != str(recorded[name]).lower():
                problems.append("%s: %s is not the file the expected outcomes were computed on" % (entry.get("id"), name))
            checked += 1
    return checked, problems


def run_corpus(manifest_path, out_path, expect_sha256=""):
    manifest_path = Path(manifest_path)
    raw = manifest_path.read_bytes()
    freeze, problem = check_freeze(manifest_path, raw, expect_sha256)
    if problem:
        print("subset_verifier: %s" % problem, file=sys.stderr)
        return 2
    digest = freeze["manifest_sha256"]
    manifest = load_json_bytes(raw)
    if not isinstance(manifest, dict) or manifest.get("format") != CORPUS_FORMAT:
        print("subset_verifier: %s is not a %s manifest" % (manifest_path.name, CORPUS_FORMAT), file=sys.stderr)
        return 2
    base = manifest_path.parent
    entries = manifest.get("entries", [])
    files_checked, problems = check_entry_files(base, entries)
    if problems:
        print("subset_verifier: %d corpus folder problem(s); nothing was verified:" % len(problems), file=sys.stderr)
        for line in problems[:20]:
            print("  " + line, file=sys.stderr)
        return 2
    freeze["entry_files_checked"] = files_checked
    conditions = manifest.get("anchor_conditions", ["none", "keys", "head", "both"])
    subset_ids = set(CHECKS)
    rows = []
    for entry in entries:
        if not entry.get("dir"):
            continue
        folder = base / entry["dir"]
        anchors = entry.get("anchors", {})
        for condition in conditions:
            expected = entry["expected"][condition]
            report = verify_run(
                folder,
                expect_keys=anchors.get("keys", "") if condition in ("keys", "both") else "",
                expect_head=anchors.get("head", "") if condition in ("head", "both") else "",
                assume_compromised=entry.get("assume_compromised") or [],
                unbound_flags=bool(entry.get("unbound_flags")),
            )
            go_failed = expected["verdict"] == "FAILED"
            py_failed = report["verdict"] == "FAILED"
            rows.append({
                "id": entry["id"], "group": entry.get("group", ""), "design": entry.get("design", ""),
                "operator": entry.get("operator", ""), "keyset": entry.get("keyset", ""), "variant": entry.get("variant", ""),
                "anchors": condition, "go_verdict": expected["verdict"], "subset_verdict": report["verdict"],
                "agree": go_failed == py_failed,
                "go_failing_checks": expected.get("failing_checks", []),
                "go_failing_subset_checks": [c for c in expected.get("failing_checks", []) if c in subset_ids],
                "subset_failing_checks": report["failing_checks"],
            })
    summary = summarize(rows)
    # Only the manifest's file name: a result written into the corpus must not
    # name local paths.
    result = {"format": "agentgate-subset-corpus-result/v1", "manifest": manifest_path.name, "manifest_sha256": digest,
              "freeze_checked": freeze, "setting": manifest.get("setting"), "summary": summary, "rows": rows}
    print_summary(freeze, summary, rows)
    if out_path:
        Path(out_path).write_text(json.dumps(result, indent=1) + "\n", encoding="utf-8")
    return 0 if summary["disagree"] == 0 else 1


def strongest(rows):
    """Per mutant cell (design, operator, key set, anchors): detected when every
    applied snapshot variant is detected (the strongest attacker evades)."""
    cells = {}
    for row in rows:
        if row["group"] != "mutant":
            continue
        key = (row["design"], row["operator"], row["keyset"], row["anchors"])
        cell = cells.setdefault(key, {"go": True, "subset": True})
        cell["go"] = cell["go"] and row["go_verdict"] == "FAILED"
        cell["subset"] = cell["subset"] and row["subset_verdict"] == "FAILED"
    return cells


def flips(cells, who, reverse=False, anchors="none"):
    """Distinct flips: strongest-attacker cells (operator/key set) detected in
    the bound design and accepted in the unbound one (reverse: the other way
    round), at one anchor condition. Each (operator, key set) is counted once:
    the keys-pinned cells repeat the unpinned ones (see binding_keys_repeat)."""
    out = []
    for (design, operator, keyset, condition), cell in sorted(cells.items()):
        if design != "bound" or condition != anchors:
            continue
        other = cells.get(("unbound", operator, keyset, condition))
        if other is not None and cell[who] != other[who] and cell[who] != reverse:
            out.append("%s/%s" % (operator, keyset))
    return out


BINDING_KEYSETS = ("audit", "audit+issuer", "audit+issuer+adapter")
# The binding-relevant rows are counted at the anchor condition "none" only,
# so each mutant folder counts once. The keys pin is not a separate condition
# on these rows: the mutants never edit keys.json, so the pin cannot change a
# verdict. The keys-pinned verifications are reported as a repeat (and the
# summary counts any folder whose verdict the pin does change).
BINDING_ANCHOR = "none"
BINDING_REPEAT_ANCHOR = "keys"
BINDING_RELEVANT = ("mutant folders with an attacker key set (audit, audit+issuer, audit+issuer+adapter), each "
                    "counted once (anchor condition none): the rows where the classification binding can decide "
                    "the verdict. It decides it only where a binding flip appears; binding_by_keyset says, per key "
                    "set, in how many operator/variant pairs the Go verdict differs between the two designs")


def binding_relevant(row):
    """A row that tests the classification binding, once per mutant folder.
    The other rows are easy to get right: clean runs, the fixed tamper-lab
    attacks, mutants with no key (any signature check catches them) and
    head-anchored mutants (every edit changes the log, so the head pin
    catches it); the keys-pinned rows repeat these (binding_keys_repeat)."""
    return row["group"] == "mutant" and row["keyset"] in BINDING_KEYSETS and row["anchors"] == BINDING_ANCHOR


def binding_keys_repeat(row):
    """The keys-pinned verification of a binding-relevant folder."""
    return row["group"] == "mutant" and row["keyset"] in BINDING_KEYSETS and row["anchors"] == BINDING_REPEAT_ANCHOR


def keys_repeat_summary(rows):
    """How often the keys pin changes the verdict of a binding-relevant folder
    (0 when no mutant edits keys.json), for each side."""
    unpinned = {r["id"]: r for r in rows if binding_relevant(r)}
    repeat = [r for r in rows if binding_keys_repeat(r)]
    changed = {"go": 0, "subset": 0}
    for row in repeat:
        base = unpinned.get(row["id"])
        if base is None:
            continue
        changed["go"] += (row["go_verdict"] == "FAILED") != (base["go_verdict"] == "FAILED")
        changed["subset"] += (row["subset_verdict"] == "FAILED") != (base["subset_verdict"] == "FAILED")
    return dict(tally(repeat), go_verdict_changed=changed["go"], subset_verdict_changed=changed["subset"])


def binding_by_keyset(rows):
    """Per attacker key set, over the binding-relevant folders: how many, the
    Go verdicts, and in how many (operator, variant) pairs present in both
    designs the Go verdict differs between bound and unbound. A key set whose
    pairs never differ does not depend on the binding on this corpus."""
    out = {}
    for keyset in BINDING_KEYSETS:
        mine = [r for r in rows if binding_relevant(r) and r["keyset"] == keyset]
        by_design = {}
        for row in mine:
            by_design[(row["design"], row["operator"], row["variant"])] = row["go_verdict"] == "FAILED"
        pairs = [(op, variant) for (design, op, variant) in by_design if design == "bound" and ("unbound", op, variant) in by_design]
        out[keyset] = dict(tally(mine), design_pairs=len(pairs),
                           design_pairs_differ=sum(by_design[("bound", op, v)] != by_design[("unbound", op, v)] for op, v in pairs))
    return out


def tally(rows):
    return {
        "verifications": len(rows),
        "agree": sum(r["agree"] for r in rows),
        "go_failed": sum(r["go_verdict"] == "FAILED" for r in rows),
        "go_accepted": sum(r["go_verdict"] != "FAILED" for r in rows),
        "subset_failed": sum(r["subset_verdict"] == "FAILED" for r in rows),
    }


def summarize(rows):
    groups = {}
    for row in rows:
        group = groups.setdefault(row["group"], {"verifications": 0, "agree": 0, "go_failed": 0, "subset_failed": 0})
        group["verifications"] += 1
        group["agree"] += row["agree"]
        group["go_failed"] += row["go_verdict"] == "FAILED"
        group["subset_failed"] += row["subset_verdict"] == "FAILED"
    cells = strongest(rows)
    return {
        "verifications": len(rows),
        "agree": sum(r["agree"] for r in rows),
        "disagree": sum(not r["agree"] for r in rows),
        # Report these apart: the headline agreement is dominated by rows any
        # reasonable verifier gets right, and the keys-pinned rows repeat the
        # binding-relevant folders.
        "binding_relevant": dict(tally([r for r in rows if binding_relevant(r)]), definition=BINDING_RELEVANT),
        "binding_by_keyset": binding_by_keyset(rows),
        "binding_keys_repeat": keys_repeat_summary(rows),
        "other_rows": tally([r for r in rows if not binding_relevant(r) and not binding_keys_repeat(r)]),
        "groups": groups,
        "strongest_cells": len(cells),
        "strongest_cells_agree": sum(c["go"] == c["subset"] for c in cells.values()),
        "binding_flips_go": flips(cells, "go"),
        "binding_flips_subset": flips(cells, "subset"),
        "reverse_flips_go": flips(cells, "go", reverse=True),
        "reverse_flips_subset": flips(cells, "subset", reverse=True),
        # The same flips at the keys pin; equal to the unpinned ones when the
        # pin changes no verdict.
        "binding_flips_go_keys_pin": flips(cells, "go", anchors=BINDING_REPEAT_ANCHOR),
        "binding_flips_subset_keys_pin": flips(cells, "subset", anchors=BINDING_REPEAT_ANCHOR),
        "disagreements": ["%s @%s: Go %s %s, subset %s %s" % (r["id"], r["anchors"], r["go_verdict"], r["go_failing_checks"], r["subset_verdict"], r["subset_failing_checks"])
                          for r in rows if not r["agree"]],
    }


def print_summary(freeze, summary, rows):
    if freeze.get("expected_sha256_matches"):
        print("manifest SHA-256 %s: matches %s and the hash recorded before this run (--expect-manifest-sha256)" % (
            freeze["manifest_sha256"], freeze["hash_file"]))
    else:
        print("manifest SHA-256 %s: matches %s in the corpus folder; compare it with the hash recorded before this run "
              "(or pass --expect-manifest-sha256) to show the expected outcomes were frozen first" % (
                  freeze["manifest_sha256"], freeze["hash_file"]))
    print("corpus files: %d match the SHA-256 the manifest records" % freeze.get("entry_files_checked", 0))
    print("%d verifications: %d agree, %d disagree" % (summary["verifications"], summary["agree"], summary["disagree"]))
    part = summary["binding_relevant"]
    print("  binding-relevant %4d mutant folders (each once, no anchor), %4d agree (Go FAILED %d, Go accepted %d)" % (
        part["verifications"], part["agree"], part["go_failed"], part["go_accepted"]))
    for keyset, part in summary["binding_by_keyset"].items():
        print("    %-22s %3d folders (Go FAILED %d, accepted %d); Go verdict differs between the designs in %d of %d operator/variant pairs" % (
            keyset, part["verifications"], part["go_failed"], part["go_accepted"], part["design_pairs_differ"], part["design_pairs"]))
    part = summary["binding_keys_repeat"]
    print("  keys-pinned      %4d repeats of those folders, %4d agree; the keys pin changes the verdict of %d (Go) and %d (subset) of them" % (
        part["verifications"], part["agree"], part["go_verdict_changed"], part["subset_verdict_changed"]))
    part = summary["other_rows"]
    print("  other rows       %4d verifications, %4d agree (Go FAILED %d, Go accepted %d)" % (
        part["verifications"], part["agree"], part["go_failed"], part["go_accepted"]))
    for name, group in sorted(summary["groups"].items()):
        print("  %-10s %4d verifications, %4d agree (Go FAILED %d, subset FAILED %d)" % (
            name, group["verifications"], group["agree"], group["go_failed"], group["subset_failed"]))
    print("strongest-attacker cells (all four anchor conditions): %d/%d agree" % (summary["strongest_cells_agree"], summary["strongest_cells"]))
    print("distinct binding flips (operator/key set, bound detected, unbound accepted, no anchor): Go %d, subset %d; reverse flips: Go %d, subset %d" % (
        len(summary["binding_flips_go"]), len(summary["binding_flips_subset"]),
        len(summary["reverse_flips_go"]), len(summary["reverse_flips_subset"])))
    print("  Go: %s" % (", ".join(summary["binding_flips_go"]) or "none"))
    print("  the same at the keys pin: %s" % ("yes" if summary["binding_flips_go_keys_pin"] == summary["binding_flips_go"]
                                              and summary["binding_flips_subset_keys_pin"] == summary["binding_flips_subset"] else "NO"))
    for line in summary["disagreements"][:40]:
        print("  DISAGREE", line)


# --- self-test -----------------------------------------------------------------------

def self_test():
    """Checks this file's own pieces against fixed vectors: CBOR round trips
    and refusals, RFC 8032 TEST 1, and, when test_vectors.json is next to
    this file, its COSE_Sign1 grant and audit-log lines through this file's
    COSE parser and chain checks."""
    failures = []

    def expect(condition, what):
        if not condition:
            failures.append(what)
            print("FAIL:", what)

    sample = {1: "a", -2: b"\x00\x01", "k": [True, False, 0, 23, 24, 255, 256, 2**40, -1, -25]}
    expect(cbor_decode(cbor_encode(sample)) == sample, "CBOR round trip")
    expect(cbor_decode(b"\xf6") is None, "CBOR null")
    expect(cbor_encode({10: 1, 1: 2, -1: 3}).hex() == "a301020a012003", "CBOR deterministic key order")
    for bad, what in ((b"\x9f\x01\xff", "indefinite array"), (b"\xa2\x01\x01\x01\x02", "duplicate key"),
                      (b"\xf9\x3c\x00", "float"), (b"\x01\x02", "trailing bytes"), (b"\x5a\x00\x00\x00\x09\x00", "truncated string")):
        try:
            cbor_decode(bad)
            expect(False, "CBOR refuses %s" % what)
        except CBORError:
            pass
    seed = bytes.fromhex("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60")
    public = bytes.fromhex("d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a")
    signature = bytes.fromhex("e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b")
    expect(public_from_seed(seed) == public, "RFC 8032 TEST 1 key")
    expect(verify_signature(public, b"", signature), "RFC 8032 TEST 1 signature")
    expect(not verify_signature(public, b"x", signature), "a changed message is refused")
    expect(resolve_compromise(["adapter", "AUDIT_LOG"])[0] == ["AUDIT_LOG", "ADAPTER"], "role names are case-insensitive and ordered")
    try:
        resolve_compromise(["ISSUER"])
        expect(False, "an unknown role is refused")
    except ValueError:
        pass

    # The corpus summary counts each binding-relevant folder once (anchor
    # none), reports the keys-pinned rows as a repeat and the flips as
    # distinct operator/key set pairs.
    def row(design, keyset, anchors, go_failed, subset_failed=None, operator="strip-flag"):
        subset_failed = go_failed if subset_failed is None else subset_failed
        return {"id": "%s-%s-%s-plain" % (design, operator, keyset), "group": "mutant", "design": design,
                "operator": operator, "keyset": keyset, "variant": "plain", "anchors": anchors,
                "go_verdict": "FAILED" if go_failed else "VERIFIED", "subset_verdict": "FAILED" if subset_failed else "PASSED",
                "agree": go_failed == subset_failed, "go_failing_checks": [], "subset_failing_checks": []}
    rows = []
    for anchors in ("none", "keys", "head"):
        pinned = anchors == "head"
        rows += [row("bound", "audit", anchors, True), row("unbound", "audit", anchors, pinned),
                 row("bound", "audit+issuer+adapter", anchors, pinned), row("unbound", "audit+issuer+adapter", anchors, pinned),
                 row("bound", "none", anchors, True), row("unbound", "none", anchors, True)]
    summary = summarize(rows)
    relevant, repeat = summary["binding_relevant"], summary["binding_keys_repeat"]
    expect((relevant["verifications"], relevant["go_failed"], relevant["go_accepted"]) == (4, 1, 3), "summary: binding-relevant folders counted once")
    expect((repeat["verifications"], repeat["go_verdict_changed"], repeat["subset_verdict_changed"]) == (4, 0, 0), "summary: keys-pinned repeats")
    expect(summary["other_rows"]["verifications"] == len(rows) - 8, "summary: other rows exclude the repeats")
    expect(summary["binding_flips_go"] == ["strip-flag/audit"] == summary["binding_flips_go_keys_pin"], "summary: distinct flips")
    by_keyset = summary["binding_by_keyset"]
    expect((by_keyset["audit"]["design_pairs_differ"], by_keyset["audit+issuer+adapter"]["design_pairs_differ"]) == (1, 0), "summary: per key set design differences")
    rows[1 + 6] = row("unbound", "audit", "keys", True)  # a keys pin that changes a verdict is counted
    expect(summarize(rows)["binding_keys_repeat"]["go_verdict_changed"] == 1, "summary: a verdict changed by the keys pin")

    vectors_path = Path(__file__).with_name("test_vectors.json")
    if vectors_path.exists():
        v = json.loads(vectors_path.read_text(encoding="utf-8"))
        c = v["cose_sign1"]
        envelope = bytes.fromhex(c["cose_sign1_hex"])
        protected, header, payload, sig = parse_cose(envelope)
        expect(header[3] == c["content_type"] and header[4].hex() == c["signer_kid_hex"], "test vector COSE header")
        expect(cbor_encode(["Signature1", protected, b"", payload]).hex() == c["sig_structure_hex"], "test vector Sig_structure")
        expect(verify_signature(bytes.fromhex(c["signer_public_hex"]), bytes.fromhex(c["sig_structure_hex"]), sig), "test vector COSE signature")
        expect(cbor_encode(cbor_decode(payload)) == payload, "test vector payload re-encodes")
        a = v["audit_log"]
        checks = Checks()
        lines = parse_log(("\n".join(a["lines"]) + "\n").encode("utf-8"), checks)
        expect(checks.status("chain.entry_hash") != "fail" and len(lines) == len(a["lines"]), "test vector audit lines parse")
        public = bytes.fromhex(a["signer_public_hex"])
        prev = ZERO_HASH
        for position, line in enumerate(lines, start=1):
            expect(domain_hash(LABEL_ENTRY, line.entry_bytes).hex() == line.entry_hash, "test vector line %d hash" % position)
            expect(line.entry["seq"] == position and line.entry["prev_hash"] == prev, "test vector line %d link" % position)
            message = LABEL_ENTRY_SIG.encode("ascii") + b"\x00" + bytes.fromhex(line.entry_hash)
            expect(verify_signature(public, message, b64decode_std(line.signature)), "test vector line %d signature" % position)
            prev = line.entry_hash
    else:
        print("note: test_vectors.json not found; vector checks skipped")
    print("self-test: %s" % ("FAILED (%d)" % len(failures) if failures else "passed"))
    return 1 if failures else 0


# --- command line ----------------------------------------------------------------------

def main(argv=None):
    parser = argparse.ArgumentParser(description=(
        "Subset verifier for AgentGate run folders (not all 38 checks; not keys.valid): a second implementation "
        "by the same authors, ported from the specification and the Go sources, sharing no code."))
    parser.add_argument("run_dir", nargs="?", help="the run folder to verify")
    parser.add_argument("--expect-keys", default="", help="keys anchor: pinned SHA-256 of keys.json (hex)")
    parser.add_argument("--expect-head", default="", help="head anchor: pinned hash of the last entry (hex)")
    parser.add_argument("--assume-compromised", default="", help="key-compromise SIMULATION: ROLE[,ROLE...] whose signatures are accepted unverified")
    parser.add_argument("--unbound-flags", action="store_true", help="evidence of the flag-binding ablation (decision values without flag, mode, rules)")
    parser.add_argument("--corpus", help="verify every folder of a corpusgen manifest and compare with the frozen Go outcomes")
    parser.add_argument("--expect-manifest-sha256", default="",
                        help="with --corpus: the manifest's SHA-256 as recorded before this run (outside the corpus); refused (exit 2) when it differs")
    parser.add_argument("--out", help="also write the JSON result to this file")
    parser.add_argument("--self-test", action="store_true", help="check this verifier's own pieces against fixed vectors")
    args = parser.parse_args(argv)
    if args.self_test:
        return self_test()
    if args.expect_manifest_sha256 and not args.corpus:
        print("subset_verifier: --expect-manifest-sha256 needs --corpus", file=sys.stderr)
        return 2
    if args.corpus:
        try:
            return run_corpus(args.corpus, args.out, args.expect_manifest_sha256)
        except Exception as err:  # a malformed manifest is a usage error (2), never a disagreement (1)
            print("subset_verifier: %s: %s" % (type(err).__name__, err), file=sys.stderr)
            return 2
    if not args.run_dir:
        parser.print_usage(sys.stderr)
        return 2
    if not os.path.isdir(args.run_dir):
        print("subset_verifier: %s is not a folder" % args.run_dir, file=sys.stderr)
        return 2
    try:
        report = verify_run(args.run_dir, args.expect_keys, args.expect_head,
                            [n for n in args.assume_compromised.split(",") if n.strip()], args.unbound_flags)
    except ValueError as err:
        print("subset_verifier: %s" % err, file=sys.stderr)
        return 2
    text = json.dumps(report, indent=1)
    print(text)
    if args.out:
        Path(args.out).write_text(text + "\n", encoding="utf-8")
    return 1 if report["verdict"] == "FAILED" else 0


if __name__ == "__main__":
    sys.exit(main())
