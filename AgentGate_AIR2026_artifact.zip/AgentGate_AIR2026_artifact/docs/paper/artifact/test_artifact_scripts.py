#!/usr/bin/env python3
"""Tests of the artifact scripts: regenerate_tables.py, check_build_manifest.py
and the reproducible-build parts of build_artifact.py.

    python docs/paper/artifact/test_artifact_scripts.py [-v]

Standard library only; reads docs/paper/data/build3 (and build 2's manifest) and writes only to
temporary folders. No test builds Go code or runs a binary: where a refusal
depends on a failing `go` command, the test names the Python interpreter as
the go command (it fails on `build` and `mod vendor` arguments). The
end-to-end rebuild is a manual step: REPRODUCIBILITY.md, "Rebuild the
binaries".
"""
import contextlib
import copy
import hashlib
import io
import os
import sys
import tempfile
import unittest
from decimal import Decimal
from pathlib import Path
from unittest import mock

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import build_artifact  # noqa: E402
import check_build_manifest as cbm  # noqa: E402
import regenerate_tables as rt  # noqa: E402

BUILD2 = HERE.parents[0] / "data" / "build2"
BUILD3 = HERE.parents[0] / "data" / "build3"   # the evaluated build, whose values EXPECTED_TABLES.md holds
EXPECTED = HERE / "EXPECTED_TABLES.md"


def quietly(fn, *args, **kwargs):
    out = io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(io.StringIO()):
        result = fn(*args, **kwargs)
    return result, out.getvalue()


class NumbersTest(unittest.TestCase):
    def test_cell_numbers_in_order(self):
        self.assertEqual(rt.numbers("0 of 336 (0 of the 168 without a head anchor)"), ["0", "336", "0", "168"])
        self.assertEqual(rt.numbers("3.18 [3.13, 3.25]"), ["3.18", "3.13", "3.25"])
        self.assertEqual(rt.numbers("1,152 of 1,152; 62,500 calls"), ["1152", "1152", "62500"])

    def test_minus_sign_but_not_range_dash(self):
        self.assertEqual(rt.numbers("-0.07 [-0.13, 0.01]"), ["-0.07", "-0.13", "0.01"])
        self.assertEqual(rt.numbers("statuses signed 135-584.5 s"), ["135", "584.5"])

    def test_labels_and_hashes_are_not_numbers(self):
        self.assertEqual(rt.numbers("R1-R5, S1 8, run2, `86643d7`, `841a7c6f...b658`, section 2.2"), ["8", "2.2"])
        self.assertEqual(rt.numbers("§2.2, cases #7 and #8, M1 and A3"), [])

    def test_matches_at_the_printed_precision(self):
        self.assertTrue(rt.matches("3.18", Decimal("3.1824")))
        self.assertTrue(rt.matches("11.29", Decimal("11.2855")))   # half-up
        self.assertTrue(rt.matches("0.394", Decimal(56) / Decimal(142)))
        self.assertFalse(rt.matches("3.18", Decimal("3.186")))
        self.assertFalse(rt.matches("336", 335))
        self.assertTrue(rt.matches("435.5", Decimal("435.41"), tol=0.1))
        self.assertFalse(rt.matches("435.5", Decimal("435.3"), tol=0.1))

    def test_fuzz_durations(self):
        self.assertEqual(rt.fuzz_seconds("120s"), 120)
        self.assertEqual(rt.fuzz_seconds("2m"), 120)
        self.assertEqual(rt.fuzz_seconds("1m30s"), 90)
        with self.assertRaises(ValueError):
            rt.fuzz_seconds("10000x")


class FakeData(rt.Data):
    """Build-3 data with one CSV's rows or one JSON file's content edited."""

    def __init__(self, root, rel, edit):
        super().__init__(root)
        self.rel, self.edit = rel, edit

    def csv(self, rel):
        rows = super().csv(rel)
        return self.edit(copy.deepcopy(rows)) if rel == self.rel else rows

    def json(self, rel):
        content = super().json(rel)
        return self.edit(copy.deepcopy(content)) if rel == self.rel else content


def run(doc_path=EXPECTED, data=None, loc=HERE / "loc_build3.csv"):
    doc = rt.Doc(doc_path)
    rep = rt.Report(doc, quiet=True)
    skipped, _ = quietly(rt.run_checks, rep, data or rt.Data(BUILD3), loc)
    return rep, skipped, doc


def edited_document(test, old, new):
    """A copy of EXPECTED_TABLES.md with `old` replaced by `new`, in a temporary folder."""
    text = EXPECTED.read_text(encoding="utf-8")
    test.assertIn(old, text)
    tmp = tempfile.TemporaryDirectory()
    test.addCleanup(tmp.cleanup)
    path = Path(tmp.name) / "EXPECTED_TABLES.md"
    path.write_text(text.replace(old, new), encoding="utf-8")
    return path


def labels(rep):
    return [f["label"] for f in rep.failures]


# Rows the script does not recompute because no data file holds them (the
# catch-all reason) or because they are qualitative. A check that stops
# reading a row moves it into one of these lists, so this test fails; update
# the lists when EXPECTED_TABLES.md changes.
PROSE_ROWS = [
    ("Headline numbers", "two flag-loss bugs"),
    ("Table II", "P2 holds if"),
    ("Table III", "no head anchor: flag edits, smallest key set (paper)"),
    ("Table III", "reconciliation path, no head anchor: smallest key set (paper; real-key tests, no forge-snapshot variant)"),
    ("Table III", "reconciliation path, head anchor (paper)"),
    ("In-text numbers of V intro", "real-key tests are test code from the same sources"),
    ("In-text numbers of V intro", "correction before build 1"),
    ("In-text numbers of V-B", "witness behavior"),
    ("In-text numbers of V-F", "storage"),
    ("In-text numbers of V-F", "flagging added under 0.4 ms in every build"),
    ("V-E", "heldout.late"),
    ("V-E", "subset.check_ids"),
    ("V-E", "vectors"),
    ("VIII Conclusion", "manifest.sha256"),
    ("VIII Conclusion", "archive.sha256"),
    ("VIII Conclusion", "quick.minutes"),
]
ROWS_CHECKED = 162
VALUES_CHECKED = 759   # values recomputed from the build-3 data, and claims


class RegenerateTablesTest(unittest.TestCase):
    def test_build3_matches_the_expected_tables(self):
        rep, skipped, doc = run()
        self.assertEqual(rep.failures, [])
        self.assertGreater(rep.numbers_checked, 600)
        code, out = quietly(rt.main, [str(BUILD3), "--quiet"])
        self.assertEqual(code, 0, out[-2000:])
        self.assertIn("RESULT: PASS", out)

    def test_rows_not_recomputed_are_exactly_the_listed_ones(self):
        rep, skipped, doc = run()
        self.assertEqual(len(doc.used), ROWS_CHECKED)
        prose_reason = rt.not_recomputed_reason("VIII Conclusion", "x", ["x"])
        want = sorted("%s / %s" % (s, rt.norm(c[0])) for s, _, c in doc.rows
                      if any(s.startswith(ps) and rt.norm(c[0]) == key for ps, key in PROSE_ROWS))
        self.assertEqual(len(want), len(PROSE_ROWS))
        self.assertEqual(sorted(skipped[prose_reason]), want)
        qualitative_reason = rt.not_recomputed_reason("Table I x", "x", ["x"])
        table1 = ["%s / %s" % (s, rt.norm(c[0])) for s, _, c in doc.rows if s.startswith("Table I ")]
        units = ["Units / " + k for k in ("strongest attacker", "fixture", "fixture case", "fixture result", "verification", "tests added late")]
        self.assertEqual(sorted(skipped[qualitative_reason]), sorted(units + table1))

    def test_a_changed_data_value_is_reported(self):
        # The bound design accepts one more attack without replay: one outcome changed by binding less.
        def edit(rows):
            for r in rows:
                if (r["design"], r["operator"], r["keyset"], r["anchors"], r["verifier_config"]) == \
                        ("bound", "strip-flag", "audit", "none", "no-replay"):
                    r["detected"] = "false"
            return rows
        rep, _, _ = run(data=FakeData(BUILD3, "compromise/strongest.csv", edit))
        joined = " ".join(labels(rep))
        self.assertIn("compromise.flips.noreplay", joined)
        self.assertIn("all 336: changed", joined)
        self.assertIn("Single accounting", joined)

    def test_a_changed_document_value_is_reported(self):
        old = "| all 336: detected, bound / unbound | 313 / 313 | 313 / 305 | 295 / 283 |"
        path = edited_document(self, old, old.replace("313 / 305", "313 / 306"))
        rep, _, _ = run(doc_path=path)
        self.assertEqual(labels(rep), ["Table III / all 336: detected, bound / unbound / no snapshot check"])
        code, out = quietly(rt.main, [str(BUILD3), "--quiet", "--expected", str(path)])
        self.assertEqual(code, 1)
        self.assertIn("RESULT: FAIL", out)

    def test_a_changed_key_set_in_table_iii_is_reported(self):
        path = edited_document(self, "| change-amount | A+I+X+P | A+I+X+P |", "| change-amount | A+I+X | A+I+X+P |")
        rep, _, _ = run(doc_path=path)
        self.assertEqual(labels(rep), ["Table III / change-amount / full"])

    def test_a_cell_with_fewer_numbers_is_reported(self):
        old = "| all 336: detected, bound / unbound | 313 / 313 | 313 / 305 | 295 / 283 |"
        path = edited_document(self, old, old.replace("313 / 305", "313"))
        rep, _, _ = run(doc_path=path)
        self.assertEqual(labels(rep), ["Table III / all 336: detected, bound / unbound / no snapshot check"])
        self.assertIn("expected 2 numbers", rep.failures[0]["detail"])

    def test_a_missing_document_row_is_reported(self):
        lines = [l for l in EXPECTED.read_text(encoding="utf-8").splitlines() if not l.startswith("| `compromise.flips.full`")]
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "EXPECTED_TABLES.md"
            path.write_text("\n".join(lines) + "\n", encoding="utf-8")
            rep, _, _ = run(doc_path=path)
            self.assertTrue(any("compromise.flips.full" in f["label"] and "row not found" in f["detail"] for f in rep.failures))

    def test_a_claim_that_no_longer_holds_is_reported(self):
        def edit(analysis):
            analysis["unstable_cells"] = ["bound/strip-flag/audit/none/full"]
            return analysis
        rep, _, _ = run(data=FakeData(BUILD3, "compromise/analysis.json", edit))
        self.assertEqual(labels(rep), ["claim: compromise/analysis.json unstable_cells is empty"])
        self.assertIn("DOES NOT HOLD", rep.failures[0]["detail"])

    def test_a_fuzz_failure_is_reported(self):
        def edit(summary):
            summary["FuzzCOSE"]["failures_reported"] = 1
            summary["FuzzCOSE"]["passed"] = False
            return summary
        rep, _, _ = run(data=FakeData(BUILD3, "robustness/fuzz_summary.json", edit))
        self.assertEqual(labels(rep), ["V-E / robust.fuzz.inputs / value", "claim: every fuzz run passed (passed true, exit code 0)"])

    def test_a_different_fuzz_time_is_reported(self):
        def edit(summary):
            for v in summary.values():
                v["fuzztime"] = "60s"
            return summary
        rep, _, _ = run(data=FakeData(BUILD3, "robustness/fuzz_summary.json", edit))
        self.assertEqual(labels(rep), ["V-E / robust.fuzz.inputs / population"])

    def test_a_failed_revision_check_is_reported(self):
        def edit(rows):
            rows[0]["revision_checks_passed"] = "8/9"
            return rows
        rep, _, _ = run(data=FakeData(BUILD3, "custody/repeats.csv", edit))
        self.assertEqual(sorted(labels(rep)), ["In-text numbers of V-B / custody.revoked / file",
                                               "In-text numbers of V-B / custody.revoked / value",
                                               "Table V / note: revoked grant across a restart / in-process"])

    def test_constants_are_compared_but_not_counted(self):
        rep, _, _ = run()
        self.assertEqual((rep.numbers_checked, rep.constants_compared), (VALUES_CHECKED, 2))
        path = edited_document(self, "Little's law 16 / 92.70", "Little's law 15 / 92.70")
        rep, _, _ = run(doc_path=path)
        self.assertEqual(labels(rep), ["In-text numbers of V-F / baseline.recorded.mean16 / value"])

    def test_counts_that_were_constants_follow_the_data(self):
        def more_checks(custody):
            custody["selftest_revision_checks"].append({"id": "extra", "title": "an added check", "passed": True})
            return custody

        def fewer_settings(summary):
            summary["accepted_cells_per_setting"].pop("no-replay")
            return summary

        def five_entries(stagecost):
            stagecost["per_call"]["gateway_entries_per_call"] = 5
            return stagecost

        def no_four_clients(analysis):
            for run_ in analysis["runs"].values():
                run_["concurrent"] = [c for c in run_["concurrent"] if not (c["config"] == "full" and c["clients"] == 4)]
            return analysis

        def three_settings(rows):
            return [r for r in rows if r["verifier_config"] != "no-replay-no-snapshot"]
        cases = [
            ("compromise/strongest.csv", three_settings, ["Units / result / count",
                                                          "claim: compromise/strongest.csv holds the bound and unbound designs under the four verifier settings"]),
            ("custody/custody.json", more_checks, ["In-text numbers of V-B / custody.revoked / value"]),
            ("fixture-studies/extra_keysets_summary.json", fewer_settings, ["Units / edit-design-setting combination / count"]),
            ("baseline/stagecost/run1/stagecost.json", five_entries, ["In-text numbers of V-F / stage.append.mean / stage.ceiling / value"]),
            ("baseline/analysis.json", no_four_clients, ["In-text numbers of V-F / baseline.recorded.calls_s / value",
                                                         "In-text numbers of V-F / baseline.recorded.calls_s / field"]),
        ]
        for rel, edit, want in cases:
            with self.subTest(rel):
                rep, _, _ = run(data=FakeData(BUILD3, rel, edit))
                for label in want:
                    self.assertIn(label, labels(rep))
        # The design-result count uses the settings found in the data (3 here), not four.
        rep, _, _ = run(data=FakeData(BUILD3, "compromise/strongest.csv", three_settings))
        detail = next(f["detail"] for f in rep.failures if f["label"] == "Units / result / count")
        self.assertIn("| data 672, 2016, 3, ", detail)

    def test_two_space_manifest_entries_are_counted(self):
        class TwoSpace(rt.Data):
            def text(self, rel):
                content = super().text(rel)
                return content.replace(" *", "  ") if rel == "build-manifest.txt" else content
        rep, _, _ = run(data=TwoSpace(BUILD3))
        self.assertEqual(rep.failures, [])

    def test_a_missing_data_file_is_reported(self):
        class NoCrash(rt.Data):
            def json(self, rel):
                if rel.startswith("crash/"):
                    raise FileNotFoundError(rel)
                return super().json(rel)
        rep, _, _ = run(data=NoCrash(BUILD3))
        self.assertTrue(any(f["label"] == "check_crash" for f in rep.failures))

    def test_a_missing_loc_file_fails_the_s1_row(self):
        rep, skipped, _ = run(loc=HERE / "loc_no-such-build.csv")
        self.assertEqual(labels(rep), ["SUPPLEMENTARY S1 / loc.* / value"])
        self.assertIn("no code-line CSV", rep.failures[0]["detail"])
        self.assertFalse(any("loc.*" in item for items in skipped.values() for item in items))
        # A document without a Supplementary S1 row needs no loc file.
        lines = [l for l in EXPECTED.read_text(encoding="utf-8").splitlines() if not l.startswith("| `loc.*`")]
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "EXPECTED_TABLES.md"
            path.write_text("\n".join(lines) + "\n", encoding="utf-8")
            rep, _, _ = run(doc_path=path, loc=None)
            self.assertEqual(rep.failures, [])

    def test_missing_inputs_exit_2(self):
        missing = str(HERE / "no-such-folder")
        for argv in ([missing], [str(BUILD3), "--expected", missing + ".md"], [str(BUILD3), "--loc", missing + ".csv"]):
            code, _ = quietly(rt.main, argv + ["--quiet"])
            self.assertEqual(code, 2, argv)


ZERO = hashlib.sha256(b"").hexdigest()


def six_binaries(folder, suffix=".exe"):
    """Write six fake binaries; return [(published name, SHA-256)]."""
    folder.mkdir(parents=True, exist_ok=True)
    out = []
    for name in cbm.BINARIES:
        data = name.encode()
        (folder / (name + suffix)).write_bytes(data)
        out.append(("bin/" + name + suffix, hashlib.sha256(data).hexdigest()))
    return out


HEAD = """AgentGate test build
repository: <repo> (branch test, HEAD 0123456789abcdef0123456789abcdef01234567; built from `git archive 0123456`)
toolchain: go version go1.26.6 windows/amd64; GOPROXY=off
reproducible build: yes
build flags: -trimpath -buildvcs=false -ldflags=-buildid=
build environment: CGO_ENABLED=0 GOFLAGS=-mod=vendor GOOS=windows GOARCH=amd64 GOAMD64=v1 (empty GOMODCACHE, empty GOCACHE)

## binaries (SHA-256 *file)
"""


def manifest(binaries, sep=" *", head=HEAD):
    return head + "".join("%s%s%s\n" % (digest, sep, name) for name, digest in binaries)


class CheckBuildManifestTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)
        self.binaries = six_binaries(self.dir / "bin")
        self.text = manifest(self.binaries)

    def tearDown(self):
        self.tmp.cleanup()

    def main(self, text, *args):
        path = self.dir / "MANIFEST.txt"
        path.write_text(text, encoding="utf-8")
        return quietly(cbm.main, [str(path)] + list(args))

    def test_reads_the_recorded_build(self):
        flags, env, binaries = cbm.reproducible_build(self.text)
        self.assertEqual(flags, ["-trimpath", "-buildvcs=false", "-ldflags=-buildid="])
        self.assertEqual(env, {"CGO_ENABLED": "0", "GOFLAGS": "-mod=vendor", "GOOS": "windows", "GOARCH": "amd64", "GOAMD64": "v1"})
        self.assertEqual(binaries, self.binaries)
        self.assertEqual(cbm.toolchain_of(self.text), "go1.26.6")

    def test_reads_both_hash_formats(self):
        self.assertEqual(cbm.reproducible_build(manifest(self.binaries, sep="  "))[2], self.binaries)
        mixed = HEAD + "".join("%s%s%s\n" % (d.upper() if i % 2 else d, "  " if i % 2 else " *", n)
                               for i, (n, d) in enumerate(self.binaries))
        self.assertEqual(cbm.reproducible_build(mixed)[2], self.binaries)
        self.assertEqual(cbm.entries("%s  cmd/x/main.go\r\n%s *$GOROOT/src/a.go\n" % (ZERO, ZERO)),
                         [(ZERO, "cmd/x/main.go"), (ZERO, "$GOROOT/src/a.go")])

    def test_build2_is_not_reproducible(self):
        self.assertIsNone(cbm.reproducible_build((BUILD2 / "build-manifest.txt").read_text(encoding="utf-8")))
        self.assertIsNone(cbm.reproducible_build(self.text.replace("reproducible build: yes\n", "")))

    def test_a_malformed_reproducible_manifest_is_refused(self):
        b = self.binaries
        cases = {
            "no binaries": manifest([]),
            "one of six": manifest(b[:1]),
            "five of six": manifest(b[1:]),
            "a seventh binary": manifest(b + [("bin/agentgate-extra.exe", ZERO)]),
            "a binary twice": manifest(b + b[:1]),
            "names without .exe for windows": manifest([(n[:-4], d) for n, d in b]),
            "no flags": self.text.replace("build flags: -trimpath -buildvcs=false -ldflags=-buildid=\n", ""),
            "empty flags": self.text.replace("build flags: -trimpath -buildvcs=false -ldflags=-buildid=", "build flags: "),
            "no environment": self.text.replace(self.text.splitlines()[5] + "\n", ""),
            "no GOOS": self.text.replace(" GOOS=windows", ""),
            "no GOARCH": self.text.replace(" GOARCH=amd64", ""),
        }
        for what, text in cases.items():
            with self.subTest(what):
                with self.assertRaises(cbm.ManifestError):
                    cbm.reproducible_build(text)

    def test_a_non_windows_target_lists_names_without_exe(self):
        head = HEAD.replace("GOOS=windows", "GOOS=linux")
        plain = [(n[:-4], d) for n, d in self.binaries]
        self.assertEqual(cbm.reproducible_build(manifest(plain, head=head))[2], plain)
        with self.assertRaises(cbm.ManifestError):
            cbm.reproducible_build(manifest(self.binaries, head=head))

    def test_compares_binaries(self):
        rows = cbm.compare_binaries(cbm.reproducible_build(self.text)[2], self.dir / "bin")
        self.assertEqual({s for _, s, _ in rows}, {"same"})
        (self.dir / "bin" / "agentgate-verify.exe").write_bytes(b"other")
        (self.dir / "bin" / "agentgate-demo.exe").unlink()
        rows = cbm.compare_binaries(cbm.reproducible_build(self.text)[2], self.dir / "bin")
        self.assertEqual([s for _, s, _ in rows][:2], ["missing", "differs"])

    def test_main_passes_matching_binaries_and_fails_on_a_differing_one(self):
        code, out = self.main(self.text, "--bin", str(self.dir / "bin"))
        self.assertEqual(code, 0, out)
        self.assertIn("RESULT: PASS (sources and binaries: 6 given)", out)
        code, out = self.main(manifest(self.binaries, sep="  "), "--bin", str(self.dir / "bin"))
        self.assertEqual(code, 0, out)
        (self.dir / "bin" / "agentgate-demo.exe").write_bytes(b"tampered")
        code, out = self.main(self.text, "--bin", str(self.dir / "bin"))
        self.assertEqual(code, 1, out)
        self.assertIn("differs", out)
        self.assertIn("RESULT: FAIL", out)

    def test_main_fails_on_a_malformed_manifest(self):
        for text in (manifest([]), manifest(self.binaries[:1])):
            for args in (["--bin", str(self.dir / "bin")], []):
                code, out = self.main(text, *args)
                self.assertEqual(code, 1, out)
                self.assertIn("malformed", out)
                self.assertIn("RESULT: FAIL", out)

    def test_main_without_binary_options_checks_sources_only(self):
        code, out = self.main(self.text)
        self.assertEqual(code, 0, out)
        self.assertIn("RESULT: PASS (sources only; binaries not checked)", out)

    def test_main_reports_a_binary_check_it_cannot_do_on_a_non_reproducible_manifest(self):
        text = self.text.replace("reproducible build: yes\n", "")
        for args in (["--bin", str(self.dir / "bin")], ["--rebuild"]):
            code, out = self.main(text, *args)
            self.assertEqual(code, 1, out)
            self.assertIn("NOT CHECKED", out)
            self.assertIn("RESULT: INCOMPLETE", out)

    def test_main_does_not_rebuild_with_another_toolchain(self):
        with mock.patch.object(cbm, "goroot", return_value=(None, "go version is not go1.26.6: go version go1.25.0")), \
                mock.patch.object(cbm, "rebuild", side_effect=AssertionError("rebuilt with the wrong toolchain")):
            code, out = self.main(self.text, "--rebuild")
            self.assertEqual(code, 1, out)
            self.assertIn("NOT REBUILT", out)
            self.assertIn("RESULT: INCOMPLETE", out)
            code, out = self.main(self.text, "--rebuild", "--bin", str(self.dir / "bin"))
            self.assertEqual(code, 1, out)
            self.assertIn("RESULT: INCOMPLETE", out)

    def test_main_compares_rebuilt_binaries(self):
        with mock.patch.object(cbm, "goroot", return_value=(self.dir, "")), \
                mock.patch.object(cbm, "rebuild", return_value=self.dir / "bin"):
            code, out = self.main(self.text, "--rebuild", "--work", str(self.dir / "work"))
        self.assertEqual(code, 0, out)
        self.assertIn("RESULT: PASS (sources and binaries: 6 rebuilt)", out)

    def test_main_without_the_manifest_exits_2(self):
        code, _ = quietly(cbm.main, [str(self.dir / "no-such-manifest.txt")])
        self.assertEqual(code, 2)

    def test_build_env_ignores_the_users_go_settings(self):
        user = {"GOFLAGS": "-mod=mod", "GOEXPERIMENT": "boringcrypto", "GOENV": "C:/go.env", "CC": "gcc", "CGO_ENABLED": "1", "PATH": "p"}
        with mock.patch.dict(os.environ, user, clear=True):
            env = cbm.build_env({"CGO_ENABLED": "0", "GOFLAGS": "-mod=vendor"}, "cache", "mods")
        self.assertEqual(env, {"PATH": "p", "CGO_ENABLED": "0", "GOFLAGS": "-mod=vendor", "GOENV": "off",
                               "GOCACHE": "cache", "GOMODCACHE": "mods"})

    def failing_go(self):
        """The Python interpreter as the go command: `python build ...` and `python mod vendor` fail."""
        return mock.patch.dict(os.environ, {"GO": sys.executable})

    def test_rebuild_stops_when_go_build_fails(self):
        root = self.dir / "tree"
        (root / "vendor").mkdir(parents=True)
        (root / "vendor" / "modules.txt").write_text("", encoding="utf-8")
        with self.failing_go(), self.assertRaises(SystemExit) as stop:
            quietly(cbm.rebuild, self.text, root, self.dir / "work", log=lambda *a: None)
        self.assertIn("rebuild failed", str(stop.exception))

    def test_rebuild_without_vendor_needs_the_module_cache(self):
        env = {k: v for k, v in os.environ.items() if k != "GOMODCACHE"}
        with mock.patch.dict(os.environ, env, clear=True), self.assertRaises(SystemExit) as stop:
            cbm.rebuild(self.text, self.dir / "tree-without-vendor", self.dir / "work", log=lambda *a: None)
        self.assertIn("GOMODCACHE", str(stop.exception))

    def test_rebuild_stops_when_vendoring_fails(self):
        root = self.dir / "tree"
        root.mkdir()
        (root / "go.mod").write_text("module agentgate\n", encoding="utf-8")
        (root / "go.sum").write_text("", encoding="utf-8")
        with self.failing_go(), mock.patch.dict(os.environ, {"GOMODCACHE": str(self.dir / "mods")}), \
                self.assertRaises(SystemExit) as stop:
            quietly(cbm.rebuild, self.text, root, self.dir / "work", log=lambda *a: None)
        self.assertIn("go mod vendor failed", str(stop.exception))


class BuildArtifactComparisonTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)
        self.bin = self.dir / "bin"
        self.stage = self.dir / "stage"
        self.stage.mkdir()
        self.binaries = six_binaries(self.bin)
        self.text = manifest(self.binaries)

    def tearDown(self):
        self.tmp.cleanup()

    def test_identical_binaries_pass_and_are_listed(self):
        summary = build_artifact.compare_with_manifest(self.bin, self.text, self.stage, "docs/paper/data/build9/build-manifest.txt", "go build x")
        self.assertIn("6 of 6", summary)
        sums = (self.stage / "BINARIES_SHA256.txt").read_text(encoding="utf-8").splitlines()
        self.assertEqual(sums, ["%s  %s" % (d, n) for n, d in sorted(self.binaries)])
        record = (self.stage / "BUILD_CHECK.txt").read_text(encoding="utf-8")
        self.assertIn("compared with: docs/paper/data/build9/build-manifest.txt", record)
        self.assertIn("build command: go build x", record)
        self.assertIn("result: 6 of 6", record)

    def test_a_two_space_manifest_is_compared(self):
        self.assertIn("6 of 6", build_artifact.compare_with_manifest(self.bin, manifest(self.binaries, sep="  "), self.stage))
        (self.bin / "agentgate-eval.exe").write_bytes(b"other")
        with self.assertRaises(SystemExit):
            build_artifact.compare_with_manifest(self.bin, manifest(self.binaries, sep="  "), self.stage)

    def test_a_differing_binary_stops_the_build(self):
        (self.bin / "agentgate-verify.exe").write_bytes(b"other")
        with self.assertRaises(SystemExit):
            build_artifact.compare_with_manifest(self.bin, self.text, self.stage)

    def test_a_missing_or_extra_built_binary_stops_the_build(self):
        (self.bin / "agentgate-extra.exe").write_bytes(b"extra")
        with self.assertRaises(SystemExit):
            build_artifact.compare_with_manifest(self.bin, self.text, self.stage)
        (self.bin / "agentgate-extra.exe").unlink()
        (self.bin / "agentgate-witness.exe").unlink()
        with self.assertRaises(SystemExit):
            build_artifact.compare_with_manifest(self.bin, self.text, self.stage)
        for p in self.bin.iterdir():
            p.unlink()
        with self.assertRaises(SystemExit):
            build_artifact.compare_with_manifest(self.bin, self.text, self.stage)

    def test_a_manifest_listing_fewer_binaries_stops_the_build(self):
        for text in (manifest([]), manifest(self.binaries[:1]), manifest(self.binaries[:5])):
            with self.assertRaises(SystemExit) as stop:
                build_artifact.compare_with_manifest(self.bin, text, self.stage)
            self.assertIn("malformed", str(stop.exception))

    def test_a_non_reproducible_manifest_is_reported_not_compared(self):
        summary = build_artifact.compare_with_manifest(self.bin, "no reproducible build here", self.stage)
        self.assertIn("cannot be compared", summary)
        self.assertTrue((self.stage / "BINARIES_SHA256.txt").is_file())
        self.assertIn("cannot be compared", (self.stage / "BUILD_CHECK.txt").read_text(encoding="utf-8"))

    def test_the_archive_contains_the_reproducibility_files(self):
        for name in ("regenerate_tables.py", "REPRODUCIBILITY.md", "test_artifact_scripts.py", "check_build_manifest.py"):
            self.assertIn(name, build_artifact.ARTIFACT_FILES)
            self.assertTrue((HERE / name).is_file(), name)
        self.assertEqual(build_artifact.BINARIES, list(cbm.BINARIES))
        self.assertEqual(build_artifact.REPRODUCIBLE_FLAGS, ["-trimpath", "-buildvcs=false", "-ldflags=-buildid="])
        for key, value in {"CGO_ENABLED": "0", "GOFLAGS": "-mod=vendor", "GOOS": "windows", "GOARCH": "amd64", "GOAMD64": "v1"}.items():
            self.assertEqual(build_artifact.REPRODUCIBLE_ENV[key], value, key)

    def test_reused_samples_must_come_from_the_same_binaries(self):
        samples = self.dir / "samples"
        samples.mkdir()
        (self.stage / "BINARIES_SHA256.txt").write_text("a  bin/agentgate-demo.exe\n", encoding="utf-8")
        with self.assertRaises(SystemExit):
            build_artifact.check_reused_samples(samples, self.stage)
        (samples / build_artifact.SAMPLE_BINARIES).write_text("b  bin/agentgate-demo.exe\n", encoding="utf-8")
        with self.assertRaises(SystemExit):
            build_artifact.check_reused_samples(samples, self.stage)
        (samples / build_artifact.SAMPLE_BINARIES).write_text("a  bin/agentgate-demo.exe\n", encoding="utf-8")
        build_artifact.check_reused_samples(samples, self.stage)


class KeyScanTest(unittest.TestCase):
    """build_artifact.scan_keys refuses key material, not code that names a key field."""

    def test_a_key_store_is_refused_and_a_reader_is_listed(self):
        with tempfile.TemporaryDirectory() as tmp:
            stage = Path(tmp)
            (stage / "data").mkdir()
            (stage / "data" / "reader.py").write_text('seed = doc["private_key_seed"]\n', encoding="utf-8")
            problems, sources = build_artifact.scan_keys(stage)
            self.assertEqual(problems, [])
            self.assertEqual(sources, ["data/reader.py"])
            (stage / "data" / "store.json").write_text('{"private_key_seed": "%s"}\n' % ("A" * 43 + "="), encoding="utf-8")
            (stage / "data" / "pem.txt").write_text("-----BEGIN " + "PRIVATE" + " KEY-----\n", encoding="utf-8")   # split so that this file holds no marker
            problems, _ = build_artifact.scan_keys(stage)
            self.assertEqual(sorted(rel for rel, _ in problems), ["data/pem.txt", "data/store.json"])


class EvaluatedBuildTest(unittest.TestCase):
    """build_artifact.py records and checks the evaluated build given with --build-data."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.repo = Path(self.tmp.name).resolve() / "repo"
        self.build3 = self.repo / "docs/paper/data/build3"
        self.build3.mkdir(parents=True)
        (self.repo / "docs/paper/artifact").mkdir(parents=True)
        self.text = manifest(six_binaries(self.repo / "bin"))
        (self.build3 / "build-manifest.txt").write_text(self.text, encoding="utf-8")

    def tearDown(self):
        self.tmp.cleanup()

    def test_the_build_folder_must_be_under_docs_paper_data_and_hold_a_manifest(self):
        folder, path, text = build_artifact.evaluated_build(self.repo, str(self.build3))
        self.assertEqual((folder, path, text), (self.build3, self.build3 / "build-manifest.txt", self.text))
        outside = self.repo / "singlebuild3"
        outside.mkdir()
        (outside / "build-manifest.txt").write_text(self.text, encoding="utf-8")
        for bad in (outside, self.repo / "docs/paper/data", self.repo / "docs/paper/data/build4"):
            with self.assertRaises(SystemExit):
                build_artifact.evaluated_build(self.repo, str(bad))

    def test_the_build_commit_comes_from_the_manifest(self):
        self.assertEqual(build_artifact.build_commit(self.text), "0123456789abcdef0123456789abcdef01234567")
        build2 = (BUILD2 / "build-manifest.txt").read_text(encoding="utf-8")
        self.assertEqual(build_artifact.build_commit(build2), "86643d751720e33e6fca36c739a4c8135361cd3c")
        with self.assertRaises(SystemExit):
            build_artifact.build_commit(self.text.replace("HEAD 0123456789abcdef0123456789abcdef01234567", "no commit"))

    def test_the_builds_loc_file_is_shipped_when_it_exists(self):
        self.assertEqual(build_artifact.artifact_files(self.repo, "build3"), build_artifact.ARTIFACT_FILES)
        (self.repo / "docs/paper/artifact/loc_build3.csv").write_text("package,role,code_lines\n", encoding="utf-8")
        self.assertEqual(build_artifact.artifact_files(self.repo, "build3"), build_artifact.ARTIFACT_FILES + ("loc_build3.csv",))
        self.assertEqual(build_artifact.artifact_files(self.repo, "build2"), build_artifact.ARTIFACT_FILES)

    def test_the_archive_copy_of_the_manifest_must_record_the_same_build(self):
        stage = Path(self.tmp.name) / "stage"
        manifest_path = self.build3 / "build-manifest.txt"
        with self.assertRaises(SystemExit):
            build_artifact.staged_manifest(stage, self.repo, manifest_path, self.text)
        copy_path = stage / "docs/paper/data/build3/build-manifest.txt"
        copy_path.parent.mkdir(parents=True)
        copy_path.write_text(self.text.replace("<repo>", "<home>/repo"), encoding="utf-8")
        rel, text = build_artifact.staged_manifest(stage, self.repo, manifest_path, self.text)
        self.assertEqual(rel, "docs/paper/data/build3/build-manifest.txt")
        self.assertIn("<home>/repo", text)
        digest = cbm.reproducible_build(self.text)[2][0][1]
        copy_path.write_text(self.text.replace(digest, ZERO), encoding="utf-8")
        with self.assertRaises(SystemExit):
            build_artifact.staged_manifest(stage, self.repo, manifest_path, self.text)

    def test_a_malformed_manifest_stops_the_archive_build(self):
        with self.assertRaises(SystemExit):
            build_artifact.recorded_build(manifest([]))
        self.assertIsNone(build_artifact.recorded_build("no reproducible build here"))


if __name__ == "__main__":
    unittest.main()
