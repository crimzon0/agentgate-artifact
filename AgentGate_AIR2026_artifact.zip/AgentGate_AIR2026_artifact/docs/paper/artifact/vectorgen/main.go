// Command vectorgen writes docs/paper/artifact/test_vectors.json: cross-
// implementation test vectors for AgentGate's evidence encodings, produced by
// the project's own code (internal/canon, internal/effects, internal/audit,
// internal/signed via devcomposition, internal/capability).
//
//	go run ./docs/paper/artifact/vectorgen -out docs/paper/artifact/test_vectors.json
//
// The output is deterministic: fixed inputs, a fixed clock and the RFC 8032
// test keys, so a re-run reproduces the file byte for byte.
//
// Audit lines come from a real audit.Log (internal/audit). That log signs with
// a fresh random key, so the program first checks every real signature against
// the documented message construction and then re-signs the same entry hashes
// with the fixed RFC 8032 key; ENTRY_JSON and every entry hash are exactly the
// bytes the implementation wrote. The independent check is
// docs/paper/artifact/check_vectors.py (Python standard library only).
package main

import (
	"bytes"
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"math/big"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"

	"agentgate/internal/audit"
	"agentgate/internal/canon"
	"agentgate/internal/capability"
	"agentgate/internal/devcomposition"
	"agentgate/internal/effects"
	"agentgate/internal/signed"

	"github.com/fxamacker/cbor/v2"
)

// RFC 8032 section 7.1, TEST 1 and TEST 2 secret keys (seeds).
const (
	rfc8032Test1Seed = "9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60"
	rfc8032Test1Pub  = "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a"
	rfc8032Test1Sig  = "e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b"
	rfc8032Test2Seed = "4ccd089b28ff96da9db6c346ec114e0f5b8a319f35aba624da8cf6ed4fb8a6fb"
)

func main() {
	out := flag.String("out", "docs/paper/artifact/test_vectors.json", "output file")
	flag.Parse()
	doc, err := build()
	if err != nil {
		fmt.Fprintln(os.Stderr, "vectorgen:", err)
		os.Exit(1)
	}
	var b bytes.Buffer
	enc := json.NewEncoder(&b)
	enc.SetEscapeHTML(false)
	enc.SetIndent("", "  ")
	if err := enc.Encode(doc); err != nil {
		fmt.Fprintln(os.Stderr, "vectorgen:", err)
		os.Exit(1)
	}
	if err := os.WriteFile(*out, b.Bytes(), 0o644); err != nil {
		fmt.Fprintln(os.Stderr, "vectorgen:", err)
		os.Exit(1)
	}
	fmt.Println("wrote", *out)
}

type object = map[string]any

func build() (object, error) {
	cborVectors, err := cborSection()
	if err != nil {
		return nil, fmt.Errorf("cbor: %w", err)
	}
	effect, effectDigest, err := effectSection()
	if err != nil {
		return nil, fmt.Errorf("effect: %w", err)
	}
	hashes, err := domainHashSection(effectDigest)
	if err != nil {
		return nil, fmt.Errorf("domain hashes: %w", err)
	}
	keys, err := kidSection()
	if err != nil {
		return nil, fmt.Errorf("kid: %w", err)
	}
	cose, err := coseSection()
	if err != nil {
		return nil, fmt.Errorf("cose: %w", err)
	}
	auditLog, err := auditSection(effect["cbor_hex"].(string), effectDigest)
	if err != nil {
		return nil, fmt.Errorf("audit: %w", err)
	}
	return object{
		"format":       "agentgate-test-vectors/v1",
		"generated_by": "go run ./docs/paper/artifact/vectorgen (deterministic; uses internal/canon, internal/effects, internal/audit, internal/signed, internal/capability, internal/devcomposition)",
		"checked_by":   "python docs/paper/artifact/check_vectors.py (standard library only: hashlib plus its own CBOR encoder and Ed25519 verifier)",
		"conventions": []string{
			"hex is lowercase; base64 is standard padded base64 (RFC 4648 section 4)",
			"typed CBOR values: {\"uint\":n} | {\"nint\":n} (n < 0) | {\"bytes\":hex} | {\"text\":s} | {\"bool\":b} | {\"array\":[...]} | {\"map\":[[key,value],...]} | {\"tag\":n,\"content\":v}; integers wider than 2^53 are decimal strings",
			"canonical CBOR is RFC 8949 section 4.2.1 core deterministic encoding (shortest heads, definite lengths, map keys sorted by the bytewise order of their encodings) with the project's extra rules: no floating point, no null, no tags except the top-level COSE_Sign1 tag 18, text in Unicode NFC",
		},
		"ed25519_calibration": object{
			"note":           "RFC 8032 section 7.1 TEST 1 (empty message), to calibrate an Ed25519 implementation before the project vectors",
			"seed_hex":       rfc8032Test1Seed,
			"public_key_hex": rfc8032Test1Pub,
			"message_hex":    "",
			"signature_hex":  rfc8032Test1Sig,
		},
		"domain_hash":      hashes,
		"cbor":             cborVectors,
		"key_ids":          keys,
		"effect_object":    effect,
		"cose_sign1":       cose,
		"audit_log":        auditLog,
	}, nil
}

// --- domain-separated hashes ---------------------------------------------------

func domainHashSection(effectDigest [32]byte) (object, error) {
	type input struct {
		name, label string
		data        []byte
	}
	inputs := []input{
		{"empty data", "AgentGate/AuditEntry/v1", nil},
		{"ascii data", "AgentGate/AuditEntry/v1", []byte(`{"seq":1}`)},
		{"zero byte inside the data", "AgentGate/EffectObject/v1", []byte{0x00, 0x01, 0x00}},
		{"confidential-text shingle (12 words, lower case, single spaces)", "AgentGate/ConfidentialShingle/v1",
			[]byte("the customer commits to a minimum annual volume of four thousand two")},
		{"decision label over a small canonical CBOR value", "AgentGate/DEVPreDecision/v1", mustEncode(map[int64]any{0: uint64(1), 1: "DEV_PRE"})},
		{"final-decision label, same bytes", "AgentGate/DEVFinalDecision/v1", mustEncode(map[int64]any{0: uint64(1), 1: "DEV_PRE"})},
	}
	vectors := make([]object, 0, len(inputs)+1)
	for _, in := range inputs {
		sum, err := canon.Hash(in.label, in.data)
		if err != nil {
			return nil, err
		}
		manual := sha256.Sum256(append(append([]byte(in.label), 0), in.data...))
		if manual != sum {
			return nil, fmt.Errorf("%s: canon.Hash differs from SHA-256(label||0x00||data)", in.name)
		}
		vectors = append(vectors, object{"name": in.name, "label": in.label, "data_hex": hex.EncodeToString(in.data), "sha256_hex": hex.EncodeToString(sum[:])})
	}
	// Labels the implementation refuses (the hash would be ambiguous).
	refused := []object{}
	for _, label := range []string{"", "Agent\x00Gate", "AgentGate/Ä/v1"} {
		if _, err := canon.Hash(label, []byte("x")); err == nil {
			return nil, fmt.Errorf("label %q unexpectedly accepted", label)
		}
		refused = append(refused, object{"label_hex": hex.EncodeToString([]byte(label)), "reason": refusalReason(label)})
	}
	return object{
		"construction":   "SHA-256( ASCII label || 0x00 || data ), label non-empty, ASCII, without NUL (internal/canon Hash)",
		"vectors":        vectors,
		"refused_labels": refused,
		"labels_used": []string{
			"AgentGate/AuditEntry/v1 (audit entry hash over ENTRY_JSON)",
			"AgentGate/AuditEntrySig/v1 (prefix of the signed message, not hashed)",
			"AgentGate/AuditHead/v1 (prefix of the signed head message, not hashed)",
			"AgentGate/EffectObject/v1 (effect digest over the canonical effect CBOR)",
			"AgentGate/DEVPreDecision/v1, AgentGate/DEVFinalDecision/v1 (decision hashes over canonical decision values)",
			"AgentGate/DEVContentPolicy/v1 (content policy hash)",
			"AgentGate/ConfidentialShingle/v1 (12-word shingle hashes in the policy snapshot)",
			"AgentGate/<Token>/v1/body and AgentGate/<Token>/v1/cose (COSE_Sign1 payload and envelope hashes, e.g. Token DelegationGrant)",
		},
	}, nil
}

func refusalReason(label string) string {
	switch {
	case label == "":
		return "empty label"
	case strings.IndexByte(label, 0) >= 0:
		return "label contains NUL"
	default:
		return "label is not ASCII"
	}
}

// --- deterministic CBOR ----------------------------------------------------------

func cborSection() (object, error) {
	type positive struct {
		name  string
		value any
	}
	positives := []positive{
		{"uint 0", uint64(0)},
		{"uint 23 (largest one-byte head)", uint64(23)},
		{"uint 24 (first two-byte head)", uint64(24)},
		{"uint 255", uint64(255)},
		{"uint 256", uint64(256)},
		{"uint 65535", uint64(65535)},
		{"uint 65536", uint64(65536)},
		{"uint 4294967296", uint64(4294967296)},
		{"uint 2^53-1 (largest JSON-safe amount)", uint64(effects.MaxJSONSafeInteger)},
		{"nint -1", int64(-1)},
		{"nint -8 (COSE alg EdDSA)", int64(-8)},
		{"nint -65537 (project version header label)", int64(-65537)},
		{"empty text", ""},
		{"text with non-ASCII NFC characters", "AED 1,250.00 · café"},
		{"empty byte string", []byte{}},
		{"byte string", []byte{0xde, 0xad, 0xbe, 0xef}},
		{"bool true", true},
		{"array of mixed items", []any{uint64(1), "two", []byte{3}, false}},
		{"map with integer keys (sorted by encoded bytes: positives before negatives)", map[int64]any{-65537: uint64(1), 4: []byte{0x01}, 1: int64(-8), 3: "application/x", 2: []int64{-65537}}},
		{"map with text keys (shorter encodings sort first)", map[string]any{"v": uint64(1), "tenant_id": "tenant.demo", "aa": uint64(2), "b": uint64(3)}},
		{"nested map", map[string]any{"budgets": map[string]uint64{"USD": 300000, "AED": 10000000}, "effect_types": []string{"financial_request.create"}}},
	}
	vectors := make([]object, 0, len(positives))
	for _, p := range positives {
		raw, err := canon.Encode(p.value)
		if err != nil {
			return nil, fmt.Errorf("%s: %w", p.name, err)
		}
		typed, err := typedFromCBOR(raw)
		if err != nil {
			return nil, fmt.Errorf("%s: %w", p.name, err)
		}
		var back any
		if err := canon.Decode(raw, &back); err != nil {
			return nil, fmt.Errorf("%s: decode: %w", p.name, err)
		}
		vectors = append(vectors, object{"name": p.name, "value": typed, "cbor_hex": hex.EncodeToString(raw)})
	}

	type negative struct {
		name, badHex, reason string
		equivalent           any
	}
	negatives := []negative{
		{"uint 10 in a two-byte head", "180a", "not the shortest head", uint64(10)},
		{"uint 255 in a three-byte head", "1900ff", "not the shortest head", uint64(255)},
		{"map keys out of order", "a2046161036162", "keys not in bytewise order of their encodings", map[int64]any{3: "b", 4: "a"}},
		{"duplicate map key", "a2036161036162", "duplicate key", nil},
		{"indefinite-length array", "9f0102ff", "indefinite length", []any{uint64(1), uint64(2)}},
		{"null", "f6", "null is forbidden", nil},
		{"array containing null", "8201f6", "null is forbidden", nil},
		{"float 1.0", "f93c00", "floating point is forbidden", nil},
		{"tag 1 (epoch time)", "c11a5f5e1000", "tags other than the top-level COSE_Sign1 tag 18 are forbidden", nil},
		{"text not in NFC (e + combining acute)", "6365cc81", "text is not Unicode NFC", nil},
		{"invalid UTF-8 text", "62c328", "invalid UTF-8", nil},
	}
	refused := make([]object, 0, len(negatives))
	for _, n := range negatives {
		bad, _ := hex.DecodeString(n.badHex)
		var v any
		if err := canon.Decode(bad, &v); err == nil {
			return nil, fmt.Errorf("negative vector %q was accepted", n.name)
		}
		row := object{"name": n.name, "cbor_hex": n.badHex, "reason": n.reason}
		if n.equivalent != nil {
			raw, err := canon.Encode(n.equivalent)
			if err != nil {
				return nil, err
			}
			typed, err := typedFromCBOR(raw)
			if err != nil {
				return nil, err
			}
			row["canonical_value"] = typed
			row["canonical_hex"] = hex.EncodeToString(raw)
		}
		refused = append(refused, row)
	}
	return object{
		"encoder":   "internal/canon Encode (fxamacker/cbor CoreDetEncOptions, nil containers as empty)",
		"decoder":   "internal/canon Decode: accepts only the unique deterministic encoding (decode, then re-encode and compare)",
		"vectors":   vectors,
		"must_fail": refused,
	}, nil
}

// --- key identifiers -------------------------------------------------------------

func kidSection() (object, error) {
	seed, _ := hex.DecodeString(rfc8032Test2Seed)
	private := ed25519.NewKeyFromSeed(seed)
	public := private.Public().(ed25519.PublicKey)
	coseKey := mustEncode(map[int64]any{1: int64(1), 3: int64(-8), -1: int64(6), -2: []byte(public)})
	kid, err := capability.DeriveKID(public)
	if err != nil {
		return nil, err
	}
	if sha256.Sum256(coseKey) != kid {
		return nil, errors.New("DeriveKID is not SHA-256 of the COSE_Key encoding")
	}
	typed, err := typedFromCBOR(coseKey)
	if err != nil {
		return nil, err
	}
	auditKID := sha256.Sum256(public)
	return object{
		"public_key_hex": hex.EncodeToString(public),
		"cose_key": object{
			"note":     "KID of every COSE_Sign1 signer (capability issuer, adapters, provider, delegation authority): SHA-256 of the canonical COSE_Key {1:1 (OKP), 3:-8 (EdDSA), -1:6 (Ed25519), -2:public key} (internal/capability DeriveKID)",
			"value":    typed,
			"cbor_hex": hex.EncodeToString(coseKey),
			"kid_hex":  hex.EncodeToString(kid[:]),
		},
		"audit_key": object{
			"note":    "KID of the AUDIT_LOG key in keys.json and head.json: SHA-256 of the raw 32-byte public key (internal/audit)",
			"kid_hex": hex.EncodeToString(auditKID[:]),
		},
	}, nil
}

// --- effect object ---------------------------------------------------------------

func effectSection() (object, [32]byte, error) {
	var operationID [16]byte
	for i := range operationID {
		operationID[i] = byte(0x10 + i)
	}
	var registry, provenance [32]byte
	registry = sha256.Sum256([]byte("vectorgen registry snapshot"))
	provenance = sha256.Sum256([]byte("vectorgen provenance root"))
	effect := effects.EffectObject{
		Version: 1, TenantID: "tenant.demo", PrincipalID: "agent.demo", OperationID: operationID,
		TaskID: "task.demo", RegistrySnapshotObjectHash: registry, BaseProvenanceRoot: provenance,
		EffectType: effects.FinancialRequestCreate,
		Financial: &effects.FinancialEffect{
			Adapter: "financial-request-v1", RequesterPrincipal: "agent.demo",
			PayeeID: "payee.office-supplies", PayeeDisplayName: "Office supplies vendor",
			AmountMinor: 125000, Currency: "AED", Purpose: "Printer paper and toner", State: "created",
		},
	}
	raw, err := effect.CanonicalBytes()
	if err != nil {
		return nil, [32]byte{}, err
	}
	digest, err := effect.Digest()
	if err != nil {
		return nil, [32]byte{}, err
	}
	parsed, err := effects.ParseCanonical(raw)
	if err != nil {
		return nil, [32]byte{}, fmt.Errorf("parse back: %w", err)
	}
	again, err := parsed.CanonicalBytes()
	if err != nil || !bytes.Equal(again, raw) {
		return nil, [32]byte{}, errors.New("effect object does not round-trip")
	}
	typed, err := typedFromCBOR(raw)
	if err != nil {
		return nil, [32]byte{}, err
	}
	return object{
		"note":       "a financial_request.create effect (AED 1,250.00 = 125000 minor units); the effect digest every capability, receipt and audit entry of the operation commits to",
		"value":      typed,
		"cbor_hex":   hex.EncodeToString(raw),
		"label":      "AgentGate/EffectObject/v1",
		"digest_hex": hex.EncodeToString(digest[:]),
	}, digest, nil
}

// --- COSE_Sign1 (signed delegation grant) ------------------------------------------

func coseSection() (object, error) {
	seed, _ := hex.DecodeString(rfc8032Test2Seed)
	private := ed25519.NewKeyFromSeed(seed)
	public := private.Public().(ed25519.PublicKey)
	kid, err := capability.DeriveKID(public)
	if err != nil {
		return nil, err
	}
	grant := devcomposition.DelegationGrant{
		Version: 1, GrantID: "grant-vectors-0001", Issuer: "Example Organisation", TenantID: "tenant.demo",
		Delegate: "agent.demo", Purpose: "Pay office suppliers and notify the operations lead",
		EffectTypes: []string{"external_message.send", "financial_request.create"},
		Recipients:  []string{"ops.lead"}, Payees: []string{"payee.office-supplies"},
		Budgets:   map[string]uint64{"AED": 10000000, "USD": 300000},
		MaxCounts: map[string]uint64{"external_message.send": 20, "financial_request.create": 20},
		NotBefore: 1790000000, ExpiresAt: 1790086400,
	}
	signer := signed.Signer{KID: kid, Role: devcomposition.DelegationAuthorityRole, Private: private}
	envelope, err := devcomposition.SignDelegationGrant(grant, signer)
	if err != nil {
		return nil, err
	}
	// Take the envelope apart with the generic decoder and rebuild every piece.
	var tag cbor.RawTag
	if err := cbor.Unmarshal(envelope, &tag); err != nil || tag.Number != 18 {
		return nil, fmt.Errorf("envelope is not tag 18: %v", err)
	}
	var fields []cbor.RawMessage
	if err := cbor.Unmarshal(tag.Content, &fields); err != nil || len(fields) != 4 {
		return nil, errors.New("envelope is not a 4-element array")
	}
	var protected, payload, signature []byte
	if cbor.Unmarshal(fields[0], &protected) != nil || cbor.Unmarshal(fields[2], &payload) != nil || cbor.Unmarshal(fields[3], &signature) != nil {
		return nil, errors.New("envelope fields")
	}
	sigStructure := mustEncode([]any{"Signature1", protected, []byte{}, payload})
	if !ed25519.Verify(public, sigStructure, signature) {
		return nil, errors.New("signature does not verify over the Sig_structure")
	}
	grantCBOR := mustEncode(grant)
	if !bytes.Equal(grantCBOR, payload) {
		return nil, errors.New("payload is not the canonical grant")
	}
	bodyHash, err := devcomposition.DelegationGrantHash(grant)
	if err != nil {
		return nil, err
	}
	objectHash, err := canon.Hash("AgentGate/DelegationGrant/v1/cose", envelope)
	if err != nil {
		return nil, err
	}
	// The verifying side of the project accepts it.
	if _, gotHash, err := devcomposition.VerifyDelegationGrant(envelope, kid, public); err != nil || gotHash != bodyHash {
		// VerifyDelegationGrant checks the validity window against the
		// current time only for use; signature and shape are what matter
		// here, so report but do not fail on a window error.
		if err != nil && !strings.Contains(err.Error(), "window") {
			return nil, fmt.Errorf("VerifyDelegationGrant: %w", err)
		}
	}
	protectedTyped, err := typedFromCBOR(protected)
	if err != nil {
		return nil, err
	}
	payloadTyped, err := typedFromCBOR(payload)
	if err != nil {
		return nil, err
	}
	grantJSON, _ := json.Marshal(grant)
	return object{
		"note":                 "a delegation grant signed as COSE_Sign1 by the DELEGATION_AUTHORITY role (devcomposition SignDelegationGrant over internal/signed); the same profile shape (protected header, empty unprotected map, embedded payload, Ed25519) is used by capabilities, effect receipts and provider receipts",
		"signer_seed_hex":      rfc8032Test2Seed,
		"signer_public_hex":    hex.EncodeToString(public),
		"signer_kid_hex":       hex.EncodeToString(kid[:]),
		"content_type":         devcomposition.DelegationContentType,
		"grant_json":           json.RawMessage(grantJSON),
		"payload_value":        payloadTyped,
		"payload_hex":          hex.EncodeToString(payload),
		"protected_value":      protectedTyped,
		"protected_hex":        hex.EncodeToString(protected),
		"sig_structure_hex":    hex.EncodeToString(sigStructure),
		"signature_hex":        hex.EncodeToString(signature),
		"cose_sign1_hex":       hex.EncodeToString(envelope),
		"body_hash_label":      "AgentGate/DelegationGrant/v1/body",
		"body_hash_hex":        hex.EncodeToString(bodyHash[:]),
		"object_hash_label":    "AgentGate/DelegationGrant/v1/cose",
		"object_hash_hex":      hex.EncodeToString(objectHash[:]),
		"structure":            "tag 18 [ protected (bstr: canonical map {1:-8, 2:[-65537], 3:content type, 4:KID, -65537:1}), unprotected {}, payload (bstr: canonical CBOR body), signature (bstr, 64 bytes) ]; signature = Ed25519(Sig_structure), Sig_structure = canonical [\"Signature1\", protected, h'', payload]",
	}, nil
}

// --- audit log -------------------------------------------------------------------

func auditSection(effectCBORHex string, effectDigest [32]byte) (object, error) {
	dir, err := os.MkdirTemp("", "agentgate-vectors-")
	if err != nil {
		return nil, err
	}
	defer os.RemoveAll(dir)
	base := time.Date(2026, 10, 1, 12, 0, 0, 0, time.UTC)
	tick := 0
	clock := func() time.Time {
		tick++
		return base.Add(time.Duration(tick) * 1500 * time.Microsecond)
	}
	const runID = "run-20261001-120000-vector"
	log, err := audit.Create(audit.Options{Dir: dir, RunID: runID, Now: clock})
	if err != nil {
		return nil, err
	}
	effectCBOR, _ := hex.DecodeString(effectCBORHex)
	operation := base64.RawURLEncoding.EncodeToString([]byte{0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f})
	digest := hex.EncodeToString(effectDigest[:])
	events := []audit.Event{
		{Stage: "RUN_STARTED", Actor: "system", Component: "demo/run", Location: "agentgate-demo (pid 1) @ review-host", Outcome: "info",
			Summary: "Run started <vectors> & checks: no HTML escaping, café",
			Details: map[string]any{"escalation": "flag", "keys_sha256": strings.Repeat("ab", 32), "limits": map[string]any{"AED": []any{500000, 5000000}}}},
		{Stage: "REQUEST_VALIDATED", Actor: "gateway", Component: "gateway/normalizer", Location: "agentgate-demo (pid 1) @ review-host", Outcome: "ok",
			Summary: "financial_request.create: AED 1,250.00 to payee.office-supplies", OperationID: operation,
			EffectType: "financial_request.create", EffectDigest: digest,
			Details:   map[string]any{"amount_minor": 125000, "currency": "AED"},
			Artifacts: map[string][]byte{"effect_cbor": effectCBOR}},
		{Stage: "POLICY_DECISION", Actor: "gateway", Component: "gateway/policy", Location: "agentgate-demo (pid 1) @ review-host", Outcome: "allow",
			Summary: "Allowed: amount within the automatic limit", OperationID: operation,
			EffectType: "financial_request.create", EffectDigest: digest,
			Details: map[string]any{"flagged": false, "escalation": "flag", "reasons": []any{map[string]any{"rule": "FIN-AUTO", "outcome": "ALLOW"}}}},
	}
	for _, event := range events {
		if _, err := log.Append(event); err != nil {
			return nil, err
		}
	}
	realKID, realPublic := log.PublicKey()
	if err := log.Close(); err != nil {
		return nil, err
	}
	data, err := os.ReadFile(filepath.Join(dir, audit.LogFile))
	if err != nil {
		return nil, err
	}
	headData, err := os.ReadFile(filepath.Join(dir, audit.HeadFile))
	if err != nil {
		return nil, err
	}

	seed, _ := hex.DecodeString(rfc8032Test1Seed)
	private := ed25519.NewKeyFromSeed(seed)
	public := private.Public().(ed25519.PublicKey)
	if hex.EncodeToString(public) != rfc8032Test1Pub {
		return nil, errors.New("RFC 8032 test key mismatch")
	}
	fixedKID := sha256.Sum256(public)

	lines := bytes.Split(bytes.TrimSuffix(data, []byte("\n")), []byte("\n"))
	entries := make([]object, 0, len(lines))
	fixedLines := make([]string, 0, len(lines))
	prev := audit.ZeroHash
	for i, line := range lines {
		var record audit.Record
		if err := json.Unmarshal(line, &record); err != nil {
			return nil, err
		}
		prefix := []byte(`{"entry_hash":"` + record.EntryHash + `","signature":"` + record.Signature + `","entry":`)
		if !bytes.HasPrefix(line, prefix) || !bytes.HasSuffix(line, []byte("}")) {
			return nil, fmt.Errorf("line %d is not in the documented layout", i+1)
		}
		entryJSON := line[len(prefix) : len(line)-1]
		if !bytes.Equal(entryJSON, record.Entry) {
			return nil, fmt.Errorf("line %d: raw entry differs", i+1)
		}
		sum, _ := canon.Hash(audit.EntryHashLabel, entryJSON)
		if hex.EncodeToString(sum[:]) != record.EntryHash {
			return nil, fmt.Errorf("line %d: entry hash is not SHA-256(label||0||ENTRY_JSON)", i+1)
		}
		var fields struct {
			Seq      uint64 `json:"seq"`
			PrevHash string `json:"prev_hash"`
		}
		if err := json.Unmarshal(entryJSON, &fields); err != nil {
			return nil, err
		}
		if fields.Seq != uint64(i+1) || fields.PrevHash != prev {
			return nil, fmt.Errorf("line %d: seq or prev_hash does not chain", i+1)
		}
		message := append(append([]byte(audit.EntrySigLabel), 0), sum[:]...)
		realSig, _ := base64.StdEncoding.DecodeString(record.Signature)
		if !ed25519.Verify(realPublic, message, realSig) {
			return nil, fmt.Errorf("line %d: the implementation's signature does not verify under the documented message", i+1)
		}
		sig := base64.StdEncoding.EncodeToString(ed25519.Sign(private, message))
		fixed := `{"entry_hash":"` + record.EntryHash + `","signature":"` + sig + `","entry":` + string(entryJSON) + `}`
		fixedLines = append(fixedLines, fixed)
		entries = append(entries, object{
			"seq": fields.Seq, "prev_hash": fields.PrevHash, "entry_json": string(entryJSON),
			"entry_hash": record.EntryHash, "signature_message_hex": hex.EncodeToString(message), "signature_b64": sig,
		})
		prev = record.EntryHash
	}

	var head audit.Head
	if err := json.Unmarshal(headData, &head); err != nil {
		return nil, err
	}
	headMessage := []byte(audit.HeadSigLabel + "\x00" + head.RunID + "\x00" + strconv.FormatUint(head.Seq, 10) + "\x00" + head.EntryHash)
	realHeadSig, _ := base64.StdEncoding.DecodeString(head.Signature)
	if head.KIDHex != hex.EncodeToString(realKID[:]) || !ed25519.Verify(realPublic, headMessage, realHeadSig) {
		return nil, errors.New("the implementation's head signature does not verify under the documented message")
	}
	if head.EntryHash != prev || head.Seq != uint64(len(lines)) {
		return nil, errors.New("head does not name the last entry")
	}
	head.KIDHex = hex.EncodeToString(fixedKID[:])
	head.Signature = base64.StdEncoding.EncodeToString(ed25519.Sign(private, headMessage))
	headJSON, err := indented(head)
	if err != nil {
		return nil, err
	}

	keysDir, err := os.MkdirTemp("", "agentgate-vectors-keys-")
	if err != nil {
		return nil, err
	}
	defer os.RemoveAll(keysDir)
	keysSHA, err := audit.WriteKeys(keysDir, audit.KeysDocument{Format: audit.KeysFormat, RunID: runID,
		Keys: []audit.Key{audit.NewKey(fixedKID, audit.RoleAuditLog, audit.AuditKeyPurpose, public)}})
	if err != nil {
		return nil, err
	}
	keysJSON, err := os.ReadFile(filepath.Join(keysDir, audit.KeysFile))
	if err != nil {
		return nil, err
	}

	return object{
		"note": "three entries written by internal/audit Log.Append with a fixed clock; ENTRY_JSON and entry hashes are the implementation's bytes, signatures use the RFC 8032 TEST 1 key (the implementation's own random-key signatures were checked against the same messages first)",
		"line_layout":       "{\"entry_hash\":\"<64 hex>\",\"signature\":\"<base64>\",\"entry\":ENTRY_JSON}\\n, ENTRY_JSON = compact encoding/json of the entry (fields in struct order, map keys sorted, no HTML escaping)",
		"entry_hash":        "hex( SHA-256(\"AgentGate/AuditEntry/v1\" || 0x00 || ENTRY_JSON) )",
		"entry_signature":   "base64( Ed25519(\"AgentGate/AuditEntrySig/v1\" || 0x00 || raw 32 bytes of entry_hash) )",
		"head_signature":    "base64( Ed25519(\"AgentGate/AuditHead/v1\" || 0x00 || run_id || 0x00 || decimal seq || 0x00 || entry_hash hex) )",
		"chain":             "entry n carries prev_hash = entry_hash of entry n-1; the first entry carries 64 zeros",
		"run_id":            runID,
		"signer_seed_hex":   rfc8032Test1Seed,
		"signer_public_hex": hex.EncodeToString(public),
		"signer_kid_hex":    hex.EncodeToString(fixedKID[:]),
		"lines":             fixedLines,
		"entries":           entries,
		"head_json":         string(headJSON),
		"head_message_hex":  hex.EncodeToString(headMessage),
		"keys_json":         string(keysJSON),
		"keys_sha256_hex":   keysSHA,
	}, nil
}

func indented(v any) ([]byte, error) {
	var b bytes.Buffer
	enc := json.NewEncoder(&b)
	enc.SetEscapeHTML(false)
	enc.SetIndent("", "  ")
	if err := enc.Encode(v); err != nil {
		return nil, err
	}
	return b.Bytes(), nil
}

// --- helpers -----------------------------------------------------------------------

func mustEncode(v any) []byte {
	raw, err := canon.Encode(v)
	if err != nil {
		panic(err)
	}
	return raw
}

// typedFromCBOR decodes CBOR with the generic decoder and returns the typed
// JSON tree described in the file's conventions.
func typedFromCBOR(raw []byte) (any, error) {
	mode, err := cbor.DecOptions{TagsMd: cbor.TagsAllowed, IntDec: cbor.IntDecConvertNone}.DecMode()
	if err != nil {
		return nil, err
	}
	var v any
	if err := mode.Unmarshal(raw, &v); err != nil {
		return nil, err
	}
	return typed(v)
}

func typed(v any) (any, error) {
	switch x := v.(type) {
	case uint64:
		return object{"uint": jsonInt(new(big.Int).SetUint64(x))}, nil
	case int64:
		if x >= 0 {
			return object{"uint": jsonInt(big.NewInt(x))}, nil
		}
		return object{"nint": jsonInt(big.NewInt(x))}, nil
	case []byte:
		return object{"bytes": hex.EncodeToString(x)}, nil
	case string:
		return object{"text": x}, nil
	case bool:
		return object{"bool": x}, nil
	case []any:
		items := make([]any, 0, len(x))
		for _, item := range x {
			t, err := typed(item)
			if err != nil {
				return nil, err
			}
			items = append(items, t)
		}
		return object{"array": items}, nil
	case map[any]any:
		type pair struct {
			key     []byte
			encoded []any
		}
		pairs := make([]pair, 0, len(x))
		for key, value := range x {
			k, err := typed(key)
			if err != nil {
				return nil, err
			}
			val, err := typed(value)
			if err != nil {
				return nil, err
			}
			rawKey, err := cbor.Marshal(key)
			if err != nil {
				return nil, err
			}
			pairs = append(pairs, pair{rawKey, []any{k, val}})
		}
		sort.Slice(pairs, func(i, j int) bool { return bytes.Compare(pairs[i].key, pairs[j].key) < 0 })
		rows := make([]any, 0, len(pairs))
		for _, p := range pairs {
			rows = append(rows, p.encoded)
		}
		return object{"map": rows}, nil
	case cbor.Tag:
		content, err := typed(x.Content)
		if err != nil {
			return nil, err
		}
		return object{"tag": x.Number, "content": content}, nil
	default:
		return nil, fmt.Errorf("unsupported CBOR item %T", v)
	}
}

// jsonInt keeps integers above 2^53 exact by writing them as strings.
func jsonInt(n *big.Int) any {
	limit := big.NewInt(1 << 53)
	if n.CmpAbs(limit) >= 0 {
		return n.String()
	}
	return n.Int64()
}
