# Mechanism ablation of the AgentGate verifier

Local measurements on one computer. Each base run is a fresh demo run (new keys and IDs) with the same scripted scenario suite, so the runs are replications of one workload, not different workloads. The attacks are the tamper lab's fixed, hand-written set. Detected means the verifier's verdict was FAILED.

- Base runs: 10 fresh demo runs (self-test, 14 scenarios + 3 custom requests each, all passed); entries per run: median 119 (min 119, max 119).
- Attacked copies: 8 attacks x 10 runs = 80 copies; plus 10 clean runs.
- Configurations: 24 (8 cumulative, 8 leave-one-out, 7 single-mechanism, 1 reference); verifications: 2160.
- Always evaluated in every configuration: chain.time, verifier.error (never failed in this experiment unless listed under Problems).
- Trust anchors (pinned configurations only): keys.json fingerprint recorded at startup and the final head hash held by the writing process.
- Command: `agentgate-eval ablation -runs 10 -out <path>/ablation -work <work>`; Go go1.26.6 on windows/amd64, 12 CPUs; total 15 s.

## Mechanisms

| Mechanism | Checks |
|---|---|
| files | files.present, files.run_id, files.run_record, keys.valid, keys.hash |
| hash-chain | chain.entry_hash, chain.links |
| entry-signatures | chain.signature |
| signed-head | head.signature, head.matches |
| artifact-signatures | artifact.signature, artifact.effect_digest, artifact.effect_readable |
| bindings | op.requires_validation, op.requires_policy, op.approval_bound, op.capability_bound, op.receipts_bound, op.single_use, op.no_effect_when_refused |
| provider-reconciliation | provider.signature, provider.state_chain, provider.matches_audit |
| anchors | keys.anchor, head.anchor |

## Cumulative configurations

Cells: runs with verdict FAILED / runs. Row "clean" = false alarms.

| Target | C0 | C1 | C2 | C3 | C4 | C5 | C6 | C7 | R-unpinned |
|---|---|---|---|---|---|---|---|---|---|
| clean | 0/10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/10 |
| edit-value | 0/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 |
| delete-entry | 0/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 |
| rehash-chain | 0/10 | 0/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 |
| truncate | 0/10 | 0/10 | 0/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 |
| swap-receipt | 0/10 | 0/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 |
| hide-operation | 0/10 | 0/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 |
| forge-approval | 0/10 | 0/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 |
| rollback | 0/10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/10 | 10/10 | 0/10 |

- C0: files only (no protection)
- C1: + hash-chain
- C2: + entry-signatures
- C3: + signed-head
- C4: + artifact-signatures
- C5: + bindings
- C6: + provider-reconciliation
- C7: + anchors (pinned)
- R-unpinned: default verifier, no trust anchors

## Leave-one-out configurations

Cells: runs with verdict FAILED / runs. Row "clean" = false alarms.

| Target | L-files | L-hash-chain | L-entry-signatures | L-signed-head | L-artifact-signatures | L-bindings | L-provider-reconciliation | L-anchors |
|---|---|---|---|---|---|---|---|---|
| clean | 0/10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/10 |
| edit-value | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 |
| delete-entry | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 |
| rehash-chain | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 |
| truncate | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 |
| swap-receipt | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 |
| hide-operation | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 |
| forge-approval | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 |
| rollback | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 0/10 |

- L-files: full minus files (pinned)
- L-hash-chain: full minus hash-chain (pinned)
- L-entry-signatures: full minus entry-signatures (pinned)
- L-signed-head: full minus signed-head (pinned)
- L-artifact-signatures: full minus artifact-signatures (pinned)
- L-bindings: full minus bindings (pinned)
- L-provider-reconciliation: full minus provider-reconciliation (pinned)
- L-anchors: full minus anchors

## Single-mechanism configurations (files + one mechanism)

Cells: runs with verdict FAILED / runs. Row "clean" = false alarms.

| Target | S-hash-chain | S-entry-signatures | S-signed-head | S-artifact-signatures | S-bindings | S-provider-reconciliation | S-anchors |
|---|---|---|---|---|---|---|---|
| clean | 0/10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/10 |
| edit-value | 10/10 | 0/10 | 0/10 | 10/10 | 0/10 | 0/10 | 0/10 |
| delete-entry | 10/10 | 0/10 | 0/10 | 0/10 | 10/10 | 0/10 | 0/10 |
| rehash-chain | 0/10 | 10/10 | 10/10 | 10/10 | 0/10 | 0/10 | 10/10 |
| truncate | 0/10 | 0/10 | 10/10 | 0/10 | 0/10 | 10/10 | 10/10 |
| swap-receipt | 0/10 | 10/10 | 10/10 | 0/10 | 10/10 | 10/10 | 10/10 |
| hide-operation | 0/10 | 10/10 | 10/10 | 0/10 | 0/10 | 10/10 | 10/10 |
| forge-approval | 0/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 | 10/10 |
| rollback | 0/10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/10 | 10/10 |

- S-hash-chain: files + hash-chain only
- S-entry-signatures: files + entry-signatures only
- S-signed-head: files + signed-head only
- S-artifact-signatures: files + artifact-signatures only
- S-bindings: files + bindings only
- S-provider-reconciliation: files + provider-reconciliation only
- S-anchors: files + anchors only (pinned)

## What each mechanism alone is responsible for

Runs in which the full pinned verifier (C7) detected the attack but the verifier without that one mechanism did not.

| Mechanism removed | Attacks no longer detected |
|---|---|
| files | none (every attack is still detected by another mechanism) |
| hash-chain | none (every attack is still detected by another mechanism) |
| entry-signatures | none (every attack is still detected by another mechanism) |
| signed-head | none (every attack is still detected by another mechanism) |
| artifact-signatures | none (every attack is still detected by another mechanism) |
| bindings | none (every attack is still detected by another mechanism) |
| provider-reconciliation | none (every attack is still detected by another mechanism) |
| anchors | rollback (10/10) |

## Failing checks under the full pinned verifier (C7)

| Attack | First cumulative config detecting all runs | Mechanisms firing in every run | Sufficient alone (S-configs, all runs) | Failing checks (runs) |
|---|---|---|---|---|
| edit-value | C1 | hash-chain, artifact-signatures | hash-chain, artifact-signatures | artifact.effect_readable (10/10), chain.entry_hash (10/10) |
| delete-entry | C1 | hash-chain, bindings | hash-chain, bindings | chain.links (10/10), op.requires_policy (10/10) |
| rehash-chain | C2 | entry-signatures, signed-head, artifact-signatures, anchors | entry-signatures, signed-head, artifact-signatures, anchors | artifact.effect_readable (10/10), chain.signature (10/10), head.anchor (10/10), head.signature (10/10) |
| truncate | C3 | signed-head, provider-reconciliation, anchors | signed-head, provider-reconciliation, anchors | head.anchor (10/10), head.matches (10/10), provider.matches_audit (10/10) |
| swap-receipt | C2 | entry-signatures, signed-head, bindings, provider-reconciliation, anchors | entry-signatures, signed-head, bindings, provider-reconciliation, anchors | chain.signature (10/10), head.anchor (10/10), head.signature (10/10), op.receipts_bound (10/10), provider.matches_audit (10/10) |
| hide-operation | C2 | entry-signatures, signed-head, provider-reconciliation, anchors | entry-signatures, signed-head, provider-reconciliation, anchors | chain.signature (10/10), head.anchor (10/10), head.signature (10/10), provider.matches_audit (10/10) |
| forge-approval | C2 | entry-signatures, signed-head, artifact-signatures, bindings, provider-reconciliation, anchors | entry-signatures, signed-head, artifact-signatures, bindings, provider-reconciliation, anchors | artifact.signature (10/10), chain.signature (10/10), head.anchor (10/10), head.signature (10/10), op.approval_bound (10/10), op.capability_bound (10/10), op.no_effect_when_refused (10/10), op.receipts_bound (10/10), op.requires_policy (10/10), op.single_use (10/10), provider.matches_audit (10/10) |
| rollback | C7 | anchors | anchors | head.anchor (10/10) |

## Verifier runtime per configuration (clean runs)

One timed verification per clean run and configuration (n = 10 each); durations are quantized to the clock granularity (0.505 ms). A switched-off mechanism skips its signature verifications (entries, head, artifacts, provider journal); the other switched-off checks are computed and discarded, so these differences are indicative only.

| Config | Median ms | Min | Max |
|---|---|---|---|
| C0 | 2.00 | 2.00 | 3.00 |
| C1 | 2.00 | 1.00 | 2.57 |
| C2 | 3.00 | 2.00 | 3.28 |
| C3 | 2.31 | 2.00 | 3.10 |
| C4 | 3.00 | 2.00 | 4.00 |
| C5 | 3.00 | 2.00 | 4.00 |
| C6 | 3.00 | 2.98 | 4.00 |
| C7 | 3.23 | 2.00 | 4.00 |
| L-files | 3.00 | 2.92 | 3.74 |
| L-hash-chain | 3.00 | 2.02 | 4.00 |
| L-entry-signatures | 2.38 | 2.00 | 3.00 |
| L-signed-head | 3.00 | 2.00 | 4.00 |
| L-artifact-signatures | 3.00 | 2.00 | 4.00 |
| L-bindings | 3.00 | 2.88 | 4.00 |
| L-provider-reconciliation | 3.00 | 2.00 | 3.51 |
| L-anchors | 3.00 | 2.00 | 4.00 |
| S-hash-chain | 2.00 | 2.00 | 2.68 |
| S-entry-signatures | 2.00 | 2.00 | 3.00 |
| S-signed-head | 2.00 | 1.60 | 2.10 |
| S-artifact-signatures | 2.00 | 2.00 | 3.00 |
| S-bindings | 2.00 | 0.90 | 2.15 |
| S-provider-reconciliation | 2.30 | 1.00 | 3.00 |
| S-anchors | 2.00 | 1.00 | 2.20 |
| R-unpinned | 3.00 | 3.00 | 4.00 |

## Attacks (as applied to run 1)

- **edit-value** (Edit a recorded value). Attacker: An insider who can edit files in the run directory but holds none of the signing keys. Change: audit.jsonl seq 43: entry #43 REQUEST_VALIDATED: "amount_minor":1850000 (AED 18,500.00) -> entry #43 REQUEST_VALIDATED: "amount_minor":185000 (AED 1,850.00)
- **delete-entry** (Delete an entry). Attacker: An insider who can edit files in the run directory but holds none of the signing keys. Change: audit.jsonl seq 44: #44 POLICY_DECISION: "Allowed and flagged for audit: amount AED 18,500.00 exceeds the AED 5,000.00 automatic ..." -> (removed: entry #43 is now followed directly by #45)
- **rehash-chain** (Edit and re-hash the chain). Attacker: A careful insider who understands the hash chain but does not have the audit signing key. Change: audit.jsonl seq 43: entry #43 REQUEST_VALIDATED: "amount_minor":1850000 (AED 18,500.00) -> entry #43 REQUEST_VALIDATED: "amount_minor":185000 (AED 1,850.00) (then 77 entries re-hashed so the chain links again)
- **truncate** (Truncate the log). Attacker: An insider who can edit files in the run directory but holds none of the signing keys. Change: audit.jsonl seq 117: audit.jsonl ends at entry #119 (AGENT_RECEIVED) -> audit.jsonl ends at entry #116 (CAPABILITY_ISSUED); the 3 newest entries were removed
- **swap-receipt** (Swap a provider receipt). Attacker: An insider trying to make one payment's evidence cover another, without any signing key. Change: audit.jsonl seq 117: entry #117 EFFECT_EXECUTED provider_receipt = commit #10, operation MBMAePld7B..., ref sim-11ff71f5-10 -> entry #117 EFFECT_EXECUTED provider_receipt = commit #9, operation 2CumnWKE39..., ref sim-11ff71f5-9 (copied from entry #109; 3 entries re-hashed)
- **hide-operation** (Hide an operation). Attacker: An insider covering up a payment, without the audit signing key. Change: audit.jsonl seq 104: operation 2CumnWKE39... "Release q3-operations-summary.txt (internal) to sara.ahmed@falcon-freight.example with view access": 8 entries (#104 to #111) -> operation 2CumnWKE39...: no entries; log renumbered and re-hashed (119 -> 111 entries)
- **forge-approval** (Forge an approval). Attacker: An insider who wants a refused payment to look legitimate, without any signing key. Change: audit.jsonl seq 65: operation 2kc7b1_31h... "Send email \"Example retail contract\" to dispatch@bluewave-shipping.example": policy decision "deny" at entry #62, never executed -> an action the policy denied now looks approved and executed: inserted APPROVAL_VERIFIED, POLICY_FINAL, CAPABILITY_ISSUED, EFFECT_EXECUTED at entry #65 (an APPROVED decision signed with a key that is not the approval authority's)
- **rollback** (Roll back to an earlier checkpoint). Attacker: An insider who saved copies of earlier evidence files (any reader of the folder can) and holds no signing key. Change: audit.jsonl seq 112: audit.jsonl ends at entry #119 (AGENT_RECEIVED) -> audit.jsonl ends at entry #111 (AGENT_RECEIVED), with the genuine head.json from that moment and the provider journal saved with it; the 8 newest entries were removed, hiding 1 executed action

## Problems

None: no false alarms in any configuration, every attack detected by C7 in every run, and the always-on checks never failed.
