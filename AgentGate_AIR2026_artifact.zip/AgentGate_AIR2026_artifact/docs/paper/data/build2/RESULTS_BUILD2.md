# AgentGate build 2: results for the supervisor's second review (2026-10-10)

> **Correction note (2026-10-10, honesty sweep).** Three sentences were
> corrected in place (marked "corrected 2026-10-10"). Elsewhere, including
> quotations from the experiment files: (1) "Need", "needed", "necessary" and "minimal" for key sets mean the smallest tested key set that passed among the 12 tested key sets, for the canonical targets, in a structural simulation in which the verifier skips the signature checks of the roles the attacker holds (nothing is re-signed). They are not proofs that fewer keys cannot succeed. (2) They hold on the receipt path only: through reconciliation, the audit and issuer keys with access to the provider's status interface sufficed in every verifier setting (fixture runs with real signatures, `docs/paper/data/build2/fixture-studies/RESULTS.md` §2.2). (3) "Adapter" counts the three adapter keys as one role, and every role is held in one process: key counts count roles, not independently held keys. Log:
> `docs/paper/artifact/HONESTY_SWEEP.md`.

This file collects every result of the **build-2 rerun** for the
supervisor's second review (literature assessment date 9 October 2026;
called "review 3" in the experiment files). It is modelled on the build-1
collation `../revision/RESULTS_REVISION.md` (2026-10-08), which stays
unchanged and is cited as "build 1".

- §0 identifies build 2, its self-tests, and what changed since build 1 and
  why.
- §1 is a one-line status table of every experiment.
- §2 has one section per experiment, with its key numbers, the comparison
  with build 1 and its caveats.
- §3 maps the review's major comments 1-8, its priority items and its minor
  comments to the evidence (supported / narrowed / deferred to GP2).
- §4 lists the open issues, starting with the places where two files
  disagree.

**Source of every number.** Each experiment folder next to this file has a
`RESULTS.md` with the full summary, raw data, scripts and its own
`build-manifest.txt`: `compromise/`, `fixture-studies/`, `subset-corpus/`,
`crash/`, `killsuite/`, `concurrency/`, `custody/`, `misuse/`,
`robustness/`, `heldout/`, `baseline/`. Every number below is copied from
one of those files, from the build-2 manifest or from the build-2 self-test
summary; nothing was recomputed here. Where two files disagree, §4.1 says
so.

**One build.** Every result below comes from **frozen build 2**: six
binaries built once from commit `86643d7` (branch `claude/supervisor-demo`),
identified by the build manifest `MANIFEST.txt`, written
2026-10-10T02:24:44Z, SHA-256
`841a7c6fd3c6ea5790692c7bb3be27e783e6ad803ef5adeb39d26b792534b658`. Every
experiment re-hashed all 1,868 manifest entries before and after its runs
and found 0 different. Experiments that need test builds (fixture studies,
robustness, held-out mutation, the subset corpus generator, the stage-cost
and validation tests) compiled them from the same commit and checked their
source files against the manifest (§0.1). The one deliberate exception is
held-out variant 3 (§2.10): it runs build 1's verifier source and suite (an
export of commit `f01d1c9`) as the comparison point, because build 1 has no
held-out run.

## 0. Build 2

### 0.1 Identity

**Source.** Branch `claude/supervisor-demo`, commit `86643d7`
(`86643d751720e33e6fca36c739a4c8135361cd3c`). The manifest records the
uncommitted changes at build time (`research/` omitted): one deleted PDF
under `output/paper/` and two untracked files, none of them compiled. The
binaries' VCS stamp is `v0.0.0-20261010022356-86643d751720+dirty`,
`vcs.revision=86643d7` (`concurrency/RESULTS.md` §1).

**Toolchain.** Go 1.26.6 windows/amd64, offline:
`GOFLAGS=-mod=readonly GOPROXY=off GOTOOLCHAIN=local`, module cache = the
repository's offline cache.

**Build commands** (run in the repository; all six exited 0):
`go build -o <singlebuild2>/bin/agentgate-<name>.exe ./cmd/agentgate-<name>/`
for `demo`, `verify`, `eval`, `provider`, `witness` and `killsuite`.
`<singlebuild2>` is the frozen build folder, outside the repository; the
experiment files use the same placeholder.

| binary | SHA-256 | used by |
|---|---|---|
| agentgate-demo | `f04ccf1b98afff9389f03f623a38bce3b3af72b9d483b57ba9104778278a6b6d` | the eight self-tests |
| agentgate-verify | `83d0786afabbba31870499ab0f3ffc6674780d9545a8eb8122429773f006eed0` | every CLI cross-check (compromise, crash, concurrency, misuse, custody), the kill suite's verifications, the subset corpus's frozen-binary check |
| agentgate-eval | `485e4ce0c8ea5fe8c7006ff0de25391466c403fe930a7492d52195cf5304fdca` | compromise, crash, concurrency (5 of 7 runs), misuse, custody, baseline |
| agentgate-provider | `99fd7ad6cf745d3c59c49939c22b926608ce2e0cef45390abe6e24f4f7961349` | custody, self-tests |
| agentgate-witness | `b20c4d5620a1be307c59fdbf63df4960c150028620822f22172e38a555d445de` | custody, self-tests |
| agentgate-killsuite | `edbc7eec377114df64784666e37c52fbe48d6a7e204107ea8fbcb068b37f9655` | killsuite (new in build 2) |

**The manifest** lists the six binaries and the SHA-256 of every file
compiled into them (union of the six): **256 module files, 385 third-party
module-cache files and 1,221 standard-library files**, 1,868 entries in all.
Build 1's manifest had 5 binaries and 244 / 385 / 1,175 files (1,809
entries; SHA-256 `188f83bd...121e`). A copy with the repository path
replaced is `baseline/source-manifest.txt`; because of that replacement its
hash is not the manifest hash. `check_manifest.py` (in the build folder)
re-hashes every entry.

**Manifest checks** (UTC, 2026-10-10; "checked 1868 files, 0 differ" every
time):

| experiment | before | after |
|---|---|---|
| fixture-studies | 02:26:54Z | 02:44:18Z |
| robustness | 02:26:57 | 04:03:38 |
| compromise | 02:26:58Z | 02:44:10Z |
| killsuite | 02:27:23Z | 02:30:46Z |
| subset-corpus | 02:27:54Z | 02:36:23Z |
| crash | 02:28:21Z | 02:37:05Z |
| concurrency | 02:29:01 | 02:29:41 (after the race build), 02:45:15 (after the last run), 02:51:19 (after the unit tests) |
| custody | 02:29:19Z | 02:43:30Z |
| misuse | 02:30:57 | 02:41:02 |
| baseline | 04:21:56Z | 04:45:45Z |
| held-out mutation | 05:02:54Z | 07:19:42Z |

**Derived and test builds** (not among the six; each tied to build 2 by
source identity):

- **Race build** (concurrency `race-n8`, `race-n32`):
  `agentgate-eval-race.exe`,
  `d3c919d302fc890cec87e3396f134719e35fb531522cf8db5bbdd57f8ce08192`,
  built 02:29:20-02:29:33 UTC with `-race`; its `go version -m` differs from
  the frozen `agentgate-eval` only in `build -race=true`.
- **Robustness test builds** from a 94-file copy of HEAD `86643d7` (build 1
  copied 57 files; build 2's verifier tests import `internal/evalattack`).
  The 33 copied files compiled into a frozen binary match `MANIFEST.txt`
  exactly.
- **Subset corpus generator** `corpusgen.exe` (`2c28ae46…53514a799`): 242 of
  its 243 module source files are in the manifest with the same SHA-256; the
  other is `docs/paper/artifact/corpusgen/main.go` as committed.
- **Fixture-study test binaries:** 239 of the 298 files in the four test
  binaries are hash-equal to the manifest; the other 59 are test-only and
  hashed in `fixture-studies/build-manifest.txt`.
- **Held-out mutation** (`heldout/build-manifest.txt`):
  `refusalmutation.exe` (`d4df0bb7...4ce191`) built with a fresh GOCACHE
  from a new 94-file copy of `86643d7`, whose snapshot manifest is
  byte-identical to the robustness rerun's (its 33 compiled files match
  `MANIFEST.txt`); the mutants are `go test -overlay` builds that are not
  kept. Variant 3 runs in a `git archive` export of `f01d1c9`: its 55
  verifier files are byte-identical to build 1's robustness snapshot apart
  from the tool's own `main.go`, which is not used there. Two analysis
  helpers, `siteflags.exe` and `jobcap.exe`, use the standard library only
  and have their own `go.mod`.
- **Compromise validation tests** (`go test -c` on `86643d7`) and the
  **baseline stage-cost and witness-push tests** (`audit.test.exe`
  `31251d66...47a63bd`, `headwitness.test.exe` `4e4ec853...5209cb9`):
  hashes in the respective `build-manifest.txt`.

### 0.2 Self-tests (2026-10-10 02:24:52-02:25:10 UTC)

Frozen `agentgate-demo`, `-host-label review-host`. **All eight passed**
(exit 0), each with verifier VERIFIED / ANCHORED, 8/8 tamper attacks
detected and 3/3 custom requests:

| mode | plain | with the provider process and the witness (`-external-provider -witness`) |
|---|---|---|
| autonomous flag | 16/16 scenarios (2 skipped as human-approval only), 5/5 revision checks | the same, 9/9 revision checks |
| human approval | 18/18 scenarios, 5/5 revision checks | the same, 9/9 revision checks |
| autonomous deny | 16/16 scenarios (2 skipped), 5/5 revision checks | the same, 9/9 revision checks |
| flag, unbound-flags ablation | 16/16 scenarios (2 skipped), 5/5 revision checks | the same, 9/9 revision checks |

The 20 custody runs (§2.7) are further self-tests with the provider and
witness processes: 20/20 passed, 9/9 revision checks each (180/180).

### 0.3 What changed since build 1, and why

**Build 1** is the five binaries of 2026-10-08 (HEAD `ac5b71a` plus an
uncommitted tree). Its compiled files equal commit `2d32506`: build 1's
244 module files match the build-1 manifest 244/244 when that commit is
extracted (`fixture-studies/RESULTS.md` §1), and all 239 files of the
`agentgate-eval` and `agentgate-verify` list equal it
(`compromise/RESULTS.md` §4).

**Size of the change.** Across the six binaries, 13 compiled module files
changed and 12 were added (the kill-suite command and
`internal/auditverify/freshness.go`) (`misuse/`, `concurrency/`,
`custody/RESULTS.md`). In `agentgate-eval` and `agentgate-verify` alone,
14 compiled files differ: 13 changed and 1 new (`freshness.go`)
(`compromise/RESULTS.md` §4).

| # | change | files | why (second review) | measured by | not exercised by |
|---|---|---|---|---|---|
| 1 | **The gateway keeps the bound flag on recovery records and on every COMMITTED answer**, replayed and stored ones included; the dispatch intent journals the flag; a refusal states no flag | `internal/devcomposition/{auditing,dispatch,durable}.go` | major comment 2 (recovery must not weaken classification). A build-1 gateway restarted after the dispatch intent wrote RECONCILED without the flag ("per the test's comment", `fixture-studies/RESULTS.md` §8; not rerun on build 1) | killsuite §4 (45/45 flagged operations keep the flag), fixture-studies s4 and s5 (12/12), concurrency unit tests | crash, concurrency harness, misuse, custody, compromise, subset corpus: no flagged operation is replayed or reconciled there |
| 2 | **New verifier rules**: `checkReconciledFlag` and `checkReplayedFlag` (part of `op.requires_policy`; the confirming call's CALL_RESULT is compared too); `checkReconciledReceipt` (`op.receipts_bound` for an adapter receipt attached to RECONCILED). Three new `fail` sites, 142 in all | `internal/auditverify/operations.go` (and `reconcile.go`) | major comment 2 | robustness §4 (new sites), fixture-studies §2 (lifecycle), crash (240 RECONCILED entries carry an adapter receipt, 0 failing checks) | compromise, subset corpus (no mutant touches a recovery or replay record) |
| 3 | **Derived dimensions `head_fresh` and `run_complete`**; per-operation **classification evidence** (`issuer_adapter`, `issuer_only_reconciled`, `issuer_only_unresolved`, `issuer_only_no_effect`, `audit_only`); **Missing entries with kinds** (`freshness`, `unresolved`, `issuer_only`, `other`); `flagged` and `flagged_unconfirmed` counts. The dimensions own no check and add no failing check | `internal/auditverify/{freshness,assurance,verify,operations,reconcile}.go`, `cmd/agentgate-verify/main.go`, `cmd/agentgate-eval/harness.go` | major comment 5 ("Expose freshness and run-completeness as explicit verifier outputs"), major comment 2 ("report the weaker classification guarantee explicitly"), minor comment on the legacy VERIFIED value | custody §6, crash §3, concurrency, misuse §6, killsuite §5 | none of them changes a verdict or an assurance level anywhere |
| 4 | The custody runner's in-process live anchor passes the fetch time (`WitnessRunFetchedAt`) | `cmd/agentgate-eval/custody.go` | build-1 open issue (eval-engine row of build 1 §10) | custody §8-§9 (closed) | |
| 5 | `evalattack` states the flag on RECONCILED commits | `internal/evalattack/operators.go` | consistency of the attack engine with change 1 | | compromise: no target and no relabelled operation has a RECONCILED-committed record |
| 6 | **New command `agentgate-killsuite`**: kills and restarts real gateway processes | `cmd/agentgate-killsuite/*` | major comment 4, priority 1 "Run a focused crash suite" | killsuite | |
| 7 | CLI help and human-readable output; a UI asset | `cmd/agentgate-verify/main.go`, `internal/demo/assets/app.js` | reporting of change 3 | | |
| 8 | New tests (no binary change): lifecycle mutation tests (`afe8730`), registration and clock attacks and the A+X / A+P key sets (`abfe013`), verifier reporting, adapter receipt on RECONCILED and flagged recovery end to end (`d084ef9`), replayed-answer flags (`682d37e`) | test files | major comments 2, 3, 5, 7 | fixture-studies, robustness | |

**What did not change** (byte-identical between the builds, per the
experiment files): `internal/audit/audit.go`; `cmd/agentgate-eval/`
`misuse.go`, `concurrency.go`, `baseline.go`, `resources.go`, `cost.go`;
the gateway policy, the verifier's policy replay and the MCP boundary
(`misuse/RESULTS.md` §7); `internal/headwitness` (`custody/RESULTS.md` §9).

**Effect on the build-1 results.** Every build-1 measurement that was
repeated is unchanged:

- compromise: all 51,840 result rows (verdict, assurance, `detected`,
  `simulated`, `applied`, failing checks in order, `not_applicable` text);
- crash: all 560 schedules (280 in deny), with the build-2 fields removed;
- misuse: 0/95 requests changed per mode, 563 / 521 audit entries, 0
  differ after normalisation;
- concurrency: safety, completion and journal results number for number;
- custody: 110/110 matrix cells, 74/74 rollback cells, 160/160 tamper-lab
  rows and 14/14 relay-probe cells with the same outcome counts and failing
  checks.

The differences are the new report members of change 3 (and, in the
timing experiments, machine state; §2.11).

### 0.4 Timeline and machine

**Timeline** (2026-10-10, UTC). The self-tests ran first; the experiments
from fixture-studies to misuse then ran **at the same time**; the baseline
session ran **alone** afterwards; the held-out campaign ran last.

| experiment | run |
|---|---|
| self-tests | 02:24:52-02:25:10 |
| fixture-studies | 02:26:54-02:44:19 |
| robustness | 02:26:57-04:03:39 (fuzzing 02:31-02:42, coverage 02:42-02:45, mutation 02:45-04:00) |
| compromise | 02:27:17-02:43:57 |
| killsuite | 02:27:31-02:30:33 |
| subset-corpus | 02:27:54 to about 02:46 (corpus 02:28:32-02:28:45, comparison 02:29:15-02:29:44) |
| crash | 02:28:36-02:30:37 (flag), 02:30:37-02:33:08 (deny) |
| concurrency | 02:30:15-02:44:55 (seven harness runs) |
| custody | 02:31:00-02:40:55 (relay probe 02:41:06-02:43:22) |
| misuse | 02:31:10-02:31:24, repetitions 02:31:25-02:33:42 |
| baseline | 04:22:32-04:45:22, alone (a first attempt, 04:18:37-04:21:39, was discarded because a stray process used 1.14 cores during R1) |
| held-out mutation | 05:02:54-07:19:49 (mutants 05:07-07:19), after the baseline session; another agent used the machine, but no other AgentGate experiment process was running at the start of any run |

The baseline's process logger saw only the session's own binaries for the
whole session, so no other experiment overlapped it.

**Machine.** One desktop: AMD Ryzen 5 7600X 6c/12t, 31.2 GiB, Windows 10 Pro
10.0.19045 (`baseline/build-manifest.txt`); a 2 TB consumer NVMe SSD, the
system volume NTFS with 4,096-byte clusters, **97.4 % full** at the start
of the baseline session (build 1: 96 %); Go's clock advances in about 1 ms
steps. **No elapsed time outside §2.11 is a performance result.**

### 0.5 Host label and anonymity

Every experiment that writes run evidence used `-host-label review-host`
(compromise; crash: 1,260/1,260 `run.json`; concurrency; misuse: 118 of 295
files per work folder; custody; killsuite; subset corpus; baseline: 460
files). The held-out campaign writes no run evidence; its copied reports
and logs went through `heldout/scripts/sanitize.py` (machine name to
`review-host`, user name to `user`, local paths to placeholders). The
experiment files report the machine name in 0 evidence files and no local
path in any file of this folder. A grep of every file in this folder
(2026-10-10, the three tarballs' names, owners and contents included) found
no machine name, no absolute local path and the user name nowhere as a
word. Two caveats:

- The Windows user name appears by chance inside hexadecimal digests in raw
  scratch folders (concurrency: 11 times in 6 files, all in SHA-256
  digests; misuse: 2 files of one scratch work folder). In this folder it
  occurs once, also by chance inside a 64-character SHA-256 digest (a
  `keys_sha256` value in `killsuite/results.json`), which cannot be edited
  without corrupting the record.
- **In the kill suite's 5 journal-failure cells the signed
  `journal_unavailable` CALL_RESULT embeds the absolute path of
  `operations.jsonl`** (`killsuite/RESULTS.md` §11.1). It cannot be
  redacted without breaking verification. No such folder is in
  `killsuite/samples/` (§4.2, release).

### 0.6 Words used throughout

As in build 1 §0:

- *Detected* means verdict `FAILED`. `VERIFIED` with assurance
  `CONSISTENT`, warnings or Missing entries is acceptance.
- Assurance: `FAILED`; `CONSISTENT` (every check passed, at least one anchor
  missing); `ANCHORED` (keys fingerprint and a trusted head both match). A
  key-compromise simulation prefixes them with `SIMULATED_`.
- *Pinned* anchors were captured by the harness itself. ANCHORED therefore
  means "matches what the harness recorded", never third-party custody,
  except where the custody experiment uses the witness process.
- *Repetitions* re-run deterministic scripts with fresh keys, IDs and
  timestamps. They show stability, not independent workloads.
- All providers are the project's simulator; a provider receipt is the
  simulator's signed assertion that it APPLIED a request.

New in build 2 (all derived, none changes a verdict or assurance):

- **`head_fresh`**: pass only when the witness's signed run status was
  fetched live and is current; `not_checked` for a pinned or saved head;
  fail when the witness's answer is refused.
- **`run_complete`**: the latest-run completeness claim. Pass needs a fresh
  signed status, a run that ended where the log ends and no unresolved
  operation; fail when a continuation is withheld, an operation is
  unresolved or the verdict is FAILED.
- **Classification evidence** of an operation: `issuer_adapter` (capability
  and adapter receipt both sign the decision), `issuer_only_reconciled`
  (executed only according to a RECONCILED entry without an adapter
  receipt), `issuer_only_unresolved`, `issuer_only_no_effect`, `audit_only`
  (no verified capability).
- **Missing kinds**: `freshness` ("Head not shown to be fresh", listed when
  a pin or saved head anchors the log end), `unresolved`, `issuer_only`,
  `other`.

## 1. Status of all experiments

| # | experiment | folder | build 1? | one-line result (denominators) |
|---|---|---|---|---|
| 1 | flag-binding ablation + key compromise (**simulation**) | `compromise/` | rerun | **identical to build 1 in all 51,840 rows**; binding flips full **0/336**, `no-replay` **12/336**, `no-replay-no-snapshot` 12/336, only snapshot binding off **8/336**, all without a head anchor (0/168 with one); strongest attacker defeats every non-anchor check in **46/672** cells per run; oracle 540/560 (strongest) and 560/560 (plain); **0/1,280** false alarms |
| 2 | fixture studies: lifecycle, real-signature roles, key sets A+X / A+P / I+X, registration, clocks, flagged recovery | `fixture-studies/` | **new** | 8/8 runs pass (46 top-level tests, 88 subtests); conflicting histories **9/12 detected, 3/12 VERIFIED** with the flag kept; on the reconciliation path **A+I accepted 6/6** (no replay) and **8/8** (full verifier, every execution converted) vs A 0/6; A+X = A in 56/56 cells, I+X 0/56; registration preemption never ANCHORED (2/2), but **a false continuation registered first is ANCHORED**; 2 expired-grant revival counterexamples; flagged recovery 12/12; simulation vs real audit key 44/44 |
| 3 | subset verifier on a frozen mutant corpus (second implementation, **same authors**) | `subset-corpus/` | **new** | **42/42** binding-relevant folders agree (Go FAILED 26, accepted 16); 296/296 verifications; the same **6** binding flips; expected outcomes frozen before the run (manifest `a9f9d178...`); frozen CLI 148/148 |
| 4 | in-process crash / response loss / restart | `crash/` | rerun | **identical per schedule**; 0/1,120 operations with two effects; 0/480 REJECTED with an effect; 0/1,120 unresolved after one Reconcile; 840/840 folders ANCHORED (280/280 segment-2 chains); 240/240 replays scope `call`; **320/1,360 effects `issuer_only_reconciled`** |
| 5 | OS-level kill suite (real gateway processes) | `killsuite/` | **new** | 195 cell runs: **every acceptance measure 0** (0/235 IDs with two effects, 0/30 REJECTED with an effect, 0/185 COMMITTED without one, 0/225 unresolved outside the deliberate cells); flag kept **45/45**; run walks 145/150 (**5 false alarms on an untampered `head_reverted` crash state**); torn audit tail: restart refused 5/5 |
| 6 | concurrency | `concurrency/` | rerun | every invariant **1,820/1,820** scenario-repetitions (33,040 calls); 260/260 folders ANCHORED; **0/3,640** lease expiries, minimum slack 28,460.1 ms; 15,220/15,220 repeats scope `call`; 0 race reports in 60 repetitions |
| 7 | custody, freshness and run completeness | `custody/` | rerun | 20/20 runs (9/9 checks); every build-1 count unchanged; `head_fresh` pass **180/180** with the live witness, **0/1,300** with any other anchor; `run_complete` pass only for the clean whole run with the live witness (**20/20**), **0/1,300** on tampered evidence, never fails clean evidence (0/120); withheld segment `run_complete` fail **40/40** |
| 8 | policy misuse | `misuse/` | rerun | **identical to build 1**; 95/95 as specified; harmful **24 blocked, 3 flagged, 17 permitted of 44**; regrouped after the run: 24/24 blocked, policy-compliant harm 16/16 executed, no-grant controls 4/4 executed |
| 9 | verifier robustness | `robustness/` | rerun | 0 crashers in **34,178,449** fuzz executions; refusal sites 142/142 killed with the full suite, **honest score 56/142 = 0.394** (seven post-hoc tests left out); **47/313** refusal conditions never executed |
| 10 | held-out mutation operators (frozen before the run) | `heldout/` | **new** (build 1's verifier and suite run as variant 3) | full suite **144/358 = 0.402** (H1 63/164, H2 52/123, H3 29/71), against 142/142 for the refusal-site operator; without the four post-hoc tests **127/358 = 0.355**; build 1's verifier and suite (`f01d1c9`) **111/336 = 0.330**; full-suite survivors 214: 66 not executed, 53 evaluation not shown, 13 equivalent, **82 executed but undetected**; 0 build errors, 0 timeouts |
| 11 | baselines, load, per-stage cost, witness push | `baseline/` | rerun + new | paired medians (R2, block 95 % CI): mediation **3.18 ms [3.13, 3.25]**, signed durable recording **11.29 ms [11.19, 11.43]**, total **14.46 ms [14.39, 14.54]**; full recording levels off at **92.5 calls/s** from 4 clients; one durable append 1.70 ms (70 % `head.json` replacement); a witness push would add about 2.4 ms per call and is **in no reported latency**; 0/62,500 calls failed; 230/230 folders ANCHORED |

## 2. Results per experiment

The order follows the review: the binding question (§2.1-§2.3), recovery
and failures (§2.4-§2.6), custody (§2.7), policy (§2.8), verifier adequacy
(§2.9-§2.10) and performance (§2.11).

### 2.1 Flag-binding ablation and key-compromise simulation (`compromise/`)

Run 02:27:17-02:43:57 UTC, `agentgate-eval -host-label review-host
compromise -runs 10`, results format `agentgate-compromise/v2`. Method,
parameters, repetitions and analysis scripts as in build 1 (build 1 §1);
`analyze_compromise.py` and `base_controls.py` are byte-identical copies.
This is a key-compromise **simulation**: nothing was re-signed, and no
private key was read, exported or generated.

**Volume.** 7 operators x 12 attacker key sets x 4 anchor conditions x 2
designs x 4 verifier configurations = **2,688 cells per run**, 10 runs;
49,920 mutant verifications, 1,920 not-applicable rows, 6,720
strongest-attacker cell-runs per configuration, 1,280 clean controls. A
cell counts as detected only if every applicable variant (`plain`,
`forge-snapshot`, `forge-restate`) is detected.

**Binding flips** (bound detected, unbound accepted; strongest attacker;
every flip in 10/10 runs):

| verifier setting | none | keys | head | both | without head anchor | **all** | reverse |
|---|---|---|---|---|---|---|---|
| full | 0/84 | 0/84 | 0/84 | 0/84 | 0/168 | **0/336** | 0 |
| no-snapshot-bound-only | 4/84 | 4/84 | 0/84 | 0/84 | 8/168 | **8/336** | 0 |
| no-replay | 6/84 | 6/84 | 0/84 | 0/84 | 12/168 | **12/336** | 0 |
| no-replay-no-snapshot | 6/84 | 6/84 | 0/84 | 0/84 | 12/168 | **12/336** | 0 |

- **no-replay** flips: {strip-flag, invent-flag, change-rules} x {audit,
  audit+issuer} x {none, keys}. The bound design catches them with
  `artifact.signature`, `op.capability_bound` and `op.receipts_bound`
  (audit key alone), or `artifact.signature` and `op.receipts_bound`
  (audit+issuer). In the unbound design `plain` evades: the flag lives only
  in the audit-signed details.
- **no-snapshot-bound-only** flips: {strip-flag, invent-flag} x {audit,
  audit+issuer} x {none, keys}; the unbound design's audit-key-only
  `forge-snapshot` evades.
- **A head anchor leaves 0/168 flips in every setting.**

**Acceptance** (strongest attacker, cell-runs; none with a head anchor):
full **460/6,720** (230/3,360 per design); no-snapshot-bound-only 540/6,720
(230 / 310); no-replay and no-replay-no-snapshot 940/6,720 each (410 /
530). All 4,780 accepted rows of 49,920 are `SIMULATED_CONSISTENT`. With the
full verifier the strongest attacker defeats every non-anchor check in
**46/672 cells per run**: strip-flag and invent-flag via `forge-restate`
with audit+issuer+adapter or larger key sets (both designs), and
change-amount with audit+issuer+adapter+provider or larger. The plain
attacker gets only change-amount through (100/6,720). Smallest tested key
sets that passed, unchanged from build 1 (wording corrected 2026-10-10;
smallest among the 12 tested sets, receipt path only, not a proof): flag
edits passed only with audit+issuer+adapter, and every smaller tested set
was detected; change-amount only with audit+issuer+adapter+provider; the
delegation key was never in a smallest set and the approval key never
helped.

**Replacement keys** (14 rows per anchor condition): full, no anchor 6/14
accepted (all-replaced and all-stolen); keys anchor 0/14 all-replaced but
6/14 all-stolen; head or both 0/14. no-replay: 10/14, keys 0/14 [10/14
all-stolen], head and both 0/14.

**Oracle** (frozen, same SHA-256 as build 1; cells of 560, strongest /
plain): full `snapshot_bound+mode_checked` **540/560** (270/280 per
design); full plain `no_snapshot_forgery+mode_checked` **560/560**;
no-snapshot-bound-only `mode_checked` **536/560** (bound 270/280, unbound
266/280); no-replay configurations `mode_checked` **560/560**. The 44
disagreements with the mapped readings are C1 (10 + 14) and C2 (10 + 10);
all 1,888 disagreeing (configuration x reading x attacker) rows have a
named cause, 0 unexplained.

**Clean controls.** Runner **1,280/1,280 VERIFIED, 0 false alarms** (real:
600 CONSISTENT, 40 ANCHORED; simulated: 600 SIMULATED_CONSISTENT, 40
SIMULATED_ANCHORED); self-test pins of the 40 base runs 40/40
VERIFIED/ANCHORED (35/35 checks); frozen `agentgate-verify` 20/20 bound
base runs VERIFIED at every anchor condition (ANCHORED with both). The 20
unbound base runs fail in the CLI **by design** (no ablation option, so
`op.requires_policy` rejects the ablated value shape).

**Validation of the simulation** (test binaries on `86643d7`):
`internal/auditverify` 134/134, `tools/refusalmutation` 14/14,
`internal/evalattack` 17/17, `cmd/agentgate-eval` 27/27 top-level tests
pass; `TestSimulationAgreesWithRealAuditKeyResigning` **44/44 cells
identical** (on its case count see §4.1). As in build 1, only the audit-key
simulation has been compared with real re-signing.

**Comparison with build 1.** Every headline number is the same (flips,
acceptance, 46/672, 4,780 rows, 100/6,720, oracle agreement, replacement
keys, controls, 0/2,688 unstable cells, 44/44). Every derived file is
byte-identical to build 1's; `results.json` differs only in run-specific values, and
with operation IDs normalised all 51,840 rows are equal. Why build 2 does
not move it (`compromise/RESULTS.md` §4): the base runs' replayed and
reconciled operations (AED 900.00, AED 400.00) are unflagged and no mutant
touches them; 80/80 base-run audit segments are structurally identical to
build 1's; the receipt rule returns early (the only RECONCILED record has
no adapter receipt); the dimensions change no verdict. **It therefore does
not test the new recovery and replay rules** ("no mutated operation has a
recovery or replay record").

**Caveats** (from the file): "Only the audit key has been compared with
real re-signing (44/44)"; "The simulator is a structural attack model, not
cryptographic exploitation"; "'Necessary' means necessary among the 12
tested key sets for the canonical target, not proved from the protocol";
"'Adapter' (D). It means all three adapter keys at once; partial adapter
compromise and A+X are not in this matrix" (A+X is in §2.2); engine limits
C1 and C2, swap-decisions a verbatim transplant, provider effect-row and
state hashes, request digest and approval-artifact hash lists not
recomputed; **new engine gap** (code reading, not exercised):
`rewriteDecision` does not rewrite call-scope replayed COMMITTED answers,
so a flag edit aimed at a replayed operation would be caught by
`checkReplayedFlag`, "an unrepaired consequence of the engine, not a
verifier strength"; snapshot deletion with `policy.snapshot_bound` off
reaches the no-replay outcome. **The fixture studies (§2.2) qualify the
"audit+issuer+adapter" requirement on the reconciliation path.**

### 2.2 Fixture studies (`fixture-studies/`, new)

Run 02:26:54-02:44:19 UTC; test code only, compiled from `86643d7` (§0.1).
Eight runs, each run twice (hashed test binary and the literal `go test`);
the two logs are identical after timings are removed. **8/8 runs PASS: 46
top-level tests and 88 subtests, 0 failures, 0 skips.** Evidence labels:
**REAL-FX** (real Ed25519 signatures with the fixture's in-memory audit,
issuer, provider or witness keys; keys anchor taken from the genuine run
before the mutation), **REAL-GW** (the real gateway code in process),
**SIM** (verifier-side simulation). Key notation: A audit, I issuer, X
the simulation's ADAPTER role (all three adapter keys together), P
provider, Ap approval, "status" a genuine provider-signed status
observation (no key needed in the prototype).

**Lifecycle (s1, s1b; REAL-FX; 85 verifications, 63 printed).**

- **Genuine states** (13 operations): executed with an adapter receipt 5/13
  → `issuer_adapter`; executed only by RECONCILED-committed 1/13 →
  `issuer_only_reconciled` plus a Missing `issuer_only` entry; UNCERTAIN
  after a verified capability 1/13 → `issuer_only_unresolved`,
  `run_complete` fail; no verified capability 6/13 → `audit_only`.
- **L1 (A): execution restated as RECONCILIATION_REQUIRED or UNCERTAIN, flag
  dropped from CALL_RESULT** → **VERIFIED 8/8** (CONSISTENT). "The downgrade
  is not refused, but it is reported": still flagged (bound by the
  capability), `issuer_only_unresolved`, `flagged_unconfirmed`=1,
  `op.outcome_resolved` warning, Missing entry, `run_complete` fail. Keys
  and head anchors: FAILED `head.anchor` 2/2.
- **L1b (A vs A+I), no replay:** A FAILED; A+I with the capability re-signed
  VERIFIED, unflagged, `issuer_only_unresolved`; under the full verifier
  `policy.replay` fails.
- **L2 (A + status): execution converted in place to RECONCILED-committed**
  (adapter receipt dropped, flag kept, observation dated 2027-06-01) →
  VERIFIED 4/4, `issuer_only_reconciled`; "The verifier does not date
  observations against the run."
- **Recovery records must state the bound flag:** 5/7 cases fail with only
  `op.requires_policy`; the 2 consistent cases VERIFIED. **Replayed and
  confirming answers:** 3/6 fail with only `op.requires_policy`; 3
  consistent VERIFIED.
- **Adapter receipt on RECONCILED:** genuine receipt VERIFIED,
  `issuer_adapter` (2/2); edited payload fails `artifact.signature` and
  `op.receipts_bound`; another operation's receipt fails
  `op.receipts_bound` (2/2).
- **L3 (A vs A+I + status), no replay**, on the 12 grid flips: execution
  kept 6/6 detected (reproduces the grid); **converted to
  RECONCILED-committed: A 0/6 accepted, A+I 6/6 accepted** (VERIFIED,
  `issuer_only_reconciled`, flag chosen by the attacker). The full verifier
  catches 3/3 A+I conversions (`policy.replay`); a head anchor 3/3.
- **L4 (A+I + status), full verifier, forge-restate:** executions kept 2/2
  fail; **every execution converted → VERIFIED 8/8** (strip-flag and
  invent-flag x 4 settings, full included); head anchor 2/2.
- **Count statement** (exact): "So on this path binding raises the
  requirement from A to A+I, not from A to A+I+X. Only the 6 A-only cells
  remain differences between the designs. Under the full verifier, the same
  path lowers the bound design's flag forgery from A+I+X to A+I (+ status)
  (L4)."
- **Conflicting and mixed histories** (12 cases, full verifier, keys
  anchor): **9/12 detected, 3/12 VERIFIED**; all 3 VERIFIED keep the flag
  and state the evidence strength (confirming RECONCILED after the
  execution → `issuer_adapter`; the same commit reconciled twice →
  `issuer_only_reconciled`, effects counted once; CALL_RESULT restated
  RECONCILIATION_REQUIRED → warning, `run_complete` fail). A real
  provider-key forgery of ABSENT (A+P) is detected (`op.outcome_resolved`,
  `provider.matches_audit`).
- **Keys per state** (`fixture-studies/RESULTS.md` §2.4): EFFECT_EXECUTED
  with adapter receipt: A+I+X (grid, SIM); executed only by RECONCILED:
  **A+I+status** (no replay, L3 6/6; full with forge-restate and all
  executions converted, L4 8/8); RECONCILED with the genuine adapter
  receipt: as EFFECT_EXECUTED; UNCERTAIN / RECONCILIATION_REQUIRED:
  downgrade needs A but the flag survives, stripping it needs A+I without
  replay; not committed: asserting ABSENT needs P and is still detected; no
  capability: A. "Every rewrite above needs the audit key, and every one
  that a head anchor was applied to is detected by it."

**Key sets A+X, A+P, I+X (s2; SIM).** 22 mutants, 56 independent cells (2
designs x 7 operators x 4 settings, no anchor), 616 independent
verifications, 128 clean controls all VERIFIED (1,360 verifications in
all). Accepted cells: A 8/56, A+I 8/56, A+I+X 28/56, A+I+X+Ap 28/56,
**A+X 8/56, A+P 8/56, I+X 0/56**. A+X equals A in 56/56 cells and is
detected in 20/20 cells where A+I+X was the smallest tested set; A+P equals
A in 56/56 (by construction on 20/22 mutants); I+X is 0/56 by construction
(every mutant edits `audit.jsonl`). Against the frozen 336-cell grid:
**216/224 agree**; the 8 disagreements are relabel-approved under A+I+X and
A+I+X+Ap in full and no-snapshot-bound-only, because the human-mode fixture
has no policy snapshot (confirmed by an overlay probe) — "a limitation of
the fixture, not a difference between builds".

**Registration before first enrollment (s3a; REAL-FX, real witness service
in process).** Control: VERIFIED and ANCHORED, 2 segments. **Preemption**
(attacker registers the run ID first): **never ANCHORED, 2/2**.
**Substitution** (false continuation first): denial of anchoring, never a
false ANCHORED for the genuine run. **Counterexample:** a forged
continuation registered first (fresh keys, grant copied from the public
log, no private key of the genuine run) verifies **VERIFIED and ANCHORED, 2
segments**: "ANCHORED never establishes gateway origin. Only authenticated
enrollment, which is not implemented, would close this."

**Clocks.** Gateway (s4; REAL-GW, registry and delegation clocks injected,
not the OS clock): a 30 s backward step → REJECTED (`capability_refused`);
+61 s between issue and consume → REJECTED (`dispatch_refused`), +48 s →
COMMITTED. **Expired-grant revival, two counterexamples:** in process
(rolled back to +0 s after DEL-EXPIRED at +900 s, the next payment
COMMITTED) and across a restart (the restore ignores the journaled
capability expiry; a new payment COMMITTED under the expired grant).
Verifier windows (s3b; REAL-FX): witness status fetched exactly 2 min or 2
min minus 1 s from signing accepted 4/4; 2 min plus 1 ns or plus 1 s
refused 4/4 (`head.witness`); a backward step of 1 s or 1 ns inside a
segment fails `chain.time`; +48 h fails `delegation.window`. Documented
gaps, each VERIFIED: witness clock 1 min behind the head time; a restart
segment starting 1 min before the previous one ends; a recorded
issue-to-execution gap longer than the capability lifetime ("The verifier
never compares entry times with a capability's iat/exp").

**Flagged recovery end to end (s5; REAL-GW).** 4 fault points x 3 retry
paths: **12/12 pass**; all **20** folders VERIFIED and ANCHORED; exactly 1
provider commit each; RECONCILED and the reconciling CALL_RESULT flagged in
12/12. After a restart, `after_receipt_before_audit` and `audit_append`
become `issuer_only_reconciled` (the receipt was only in memory). Gateway
restart-flag tests (s4) all pass (crash after the intent, replays, not
committed, expired-lease intent, old journal format).

**Simulation validation (s6).** `TestSimulationAgreesWithRealAuditKeyResigning`
**44/44 cells identical** between real audit-key re-signing and the
simulation; also 44/44 on the build-1 tree. `TestEachRoleUnderSimulation`
11/11.

**Comparison with build 1.** Simulation agreement and role checks unchanged;
everything else is new: real-signature roles now audit, issuer, provider
(one forged ABSENT) and witness (REAL-FX), "adapter and approval keys are
still never used to re-sign an attack"; A+X / A+P / I+X; lifecycle,
registration, clock and flagged-recovery tests; the no-replay grid is
unchanged, with the new qualification from L3.

**Caveats** (exact): "Fixture evidence only... None of it is gateway-run
data from the frozen binaries."; "Asserted, not sampled... They are not
attack rates."; "'status' needs no key in the prototype... So L2, L3 and L4
need no provider key."; "Partial adapter compromise is not tested. X is the
aggregate of the three adapter keys, and only in the simulation."; "The
clock results are unit-level injections."; an operation journaled before
build 2 restores unflagged, and its RECONCILED entry would then fail
`op.requires_policy` (inferred, not run).

### 2.3 Subset verifier on a frozen mutant corpus (`subset-corpus/`, new)

`docs/paper/artifact/subset_verifier.py` is "a **second implementation of a
protocol subset, written by the same authors**" (Python standard library,
no shared code, ported with the Go sources open). It checks parts of 15 of
the 38 Go checks, never replays the policy and does not check
`keys.valid`. All mutants come from the Go engine (`internal/evalattack`)
and the expected outcomes are the Go verifier's in the no-replay setting.

**Freeze.** `corpusgen -make-base -host-label review-host` (02:28:32Z-
02:28:45Z) made a fresh flag-mode base pair, tamper-lab copies and mutants;
at 02:28:57Z, before any Python run, the manifest SHA-256 was recorded
outside the corpus:
**`a9f9d178fb03a36e2b948e22f4f07b138d8f61c85d08fceba840453fb217765d`**.
The comparison (02:29:15Z-02:29:44Z) checked it and all 372 corpus files.

**Corpus.** 2 clean, 16 tamper-lab (8 attacks x 2 designs) and 56 mutant
folders (3 operators x 4 key sets x 3 snapshot variants x 2 designs = 72
cells, 16 not applicable), each under 4 anchor conditions = 296
verifications.

| quantity | result |
|---|---|
| **binding-relevant mutant folders**, each counted once (A, A+I, A+I+X; anchor none) | **42 of 42 agree**: Go FAILED 26, accepted 16; the subset FAILED the same 26 |
| per key set: A / A+I / A+I+X | 14 folders each: Go FAILED 11 / 11 / 4; designs differ in 3/7, 3/7, 0/7 operator-variant pairs |
| keys-pinned repeats | 42 of 42, not counted again (keys.json byte-identical to its pin in all 74 folders) |
| other rows | 212 of 212 (Go FAILED 200, accepted 12) |
| all verifications | **296 of 296**, 0 disagree (clean 8/8, tamper-lab 64/64, mutants 224/224) |
| strongest-attacker cells | 96 of 96 |
| **distinct binding flips** | **Go 6, subset 6, the same six**: {strip-flag, invent-flag, change-rules} x {audit, audit+issuer}; reverse 0 |

Diagnostics: failing-check sets equal on 244 of 252 Go-FAILED
verifications (the other 8 are `forge-approval-7`, where Go also fails the
approval artifact's signature, which the subset never verifies); Go's
replay-on verdict differs from no-replay in 24/296 (all VERIFIED →
FAILED); the frozen `agentgate-verify` reproduces `go_full` in **148/148**
bound-design verifications (it cannot run the unbound design or disable
replay); post-hoc sensitivity: no signature verification 56/296
disagreements and 0/6 flips found, trusted snapshot hash 16/296, no
detail comparison 0/296 (that piece is covered by a package test). The
package test's second fresh base pair gave identical counts.

**Comparison with the earlier numbers** (smoke test on a development
build): every count is the same; the earlier summary counted the 42
folders twice (84 rows, 52/32) and the flips twice (12); the freeze is
stronger (hash recorded outside, 372 files checked). The manifest hash
differs by construction.

**Why build 2 changes nothing here:** every mutant edits a first-time
execution (entries 37, 13, 29); the base run's replayed and reconciled
operations are unflagged; the RECONCILED entry carries no adapter receipt.
"Agreement on build 2 therefore says nothing about these new Go checks";
they are also outside the subset.

**Caveats** (exact): "Agreement shows the port is faithful on this corpus.
It is not independent confirmation of the Go logic, and the paper must not
call it an 'independent verifier'."; subset only (no replay, `keys.valid`,
delegation, provider, approval, witness or build-2 recovery checks); one
frozen corpus from one base pair; corpusgen is a separate compile (tied by
242 of 242 module files).

### 2.4 In-process crash, response loss and restart (`crash/`)

Run 02:28:36-02:30:37 UTC (flag) and 02:30:37-02:33:08 UTC (deny), same
command, parameters, repetitions and scripts as build 1: 7 fault points x
retry (same / fresh ID) x restart (none / journal) x 20 = **560 schedules,
1,120 operations, 2,240 answers, 1,360 provider effects, 840 evidence
folders**; deny half of each. Answers: COMMITTED 1,120 (320 reconciled),
REJECTED 480, RECONCILIATION_REQUIRED 480, UNCERTAIN 160, PENDING 0; no
`dispatch_lease_expired`.

| measure (flag; deny in brackets) | build 1 | build 2 |
|---|---|---|
| more than one provider effect per operation ID | 0 / 1,120 (0 / 560) | **0 / 1,120 (0 / 560)** |
| REJECTED while the provider holds an effect | 0 / 480 (0 / 240) | **0 / 480 (0 / 240)**; all `dispatched=false` |
| COMMITTED with no provider effect | 0 / 1,120 | **0 / 1,120** |
| provider effect with no EFFECT_EXECUTED / RECONCILED(committed) | 0 / 1,360 | **0 / 1,360** |
| unresolved after the retry, then after one Reconcile | 320 then 0 / 1,120 | **320 then 0 / 1,120** |
| same-ID retry of an unresolved operation: COMMITTED, 0 new effects | 320 / 320 | **320 / 320** |
| same content committed twice under a fresh ID (by design) | 400 / 1,120 | **400 / 1,120** |
| replayed answers with scope `call` | 240 / 240 (120 / 120) | **240 / 240 (120 / 120)** |
| `call_id` on EFFECT_EXECUTED / on same-ID RECONCILED, answered later | 880 / 880, 320 / 320 | **880 / 880, 320 / 320** |
| folders VERIFIED/ANCHORED; segment 2 walked with segment 1 | 840 / 840; 280 / 280 | **840 / 840; 280 / 280** (deny 420 / 420; 140 / 140) |
| CLI cross-check agrees | 1,680 / 1,680 | **1,680 / 1,680** (deny 840 / 840) |
| restart tamper probes detected / clean copy accepted | 2,800 / 2,800, 560 / 560 | **the same**; `continuity_probes.csv` byte-identical |
| folders listing any Missing entry | 160 / 840 | **840 / 840** (new `freshness` entry in every pinned folder) |

**New verifier output.** Missing by kind: `freshness` 840/840, `unresolved`
160/840 (2 entries each, the same folders as build 1), `issuer_only`
160/840, `other` 0. `head_fresh` not_checked 840/840; `run_complete` **fail
160** (restart segment 1 verified alone with unresolved operations),
not_checked 680. Classification evidence of the 1,680 operations in the
final views: `issuer_adapter` 1,040, **`issuer_only_reconciled` 320**,
`issuer_only_no_effect` 320 (deny 520 / 160 / 160 of 840). The 320
`issuer_only_reconciled` effects are `provider_response_lost` (160) and
`after_receipt_before_audit` / `audit_append` after a restart (160: the
adapter receipt is kept in memory only). **240 RECONCILED entries carry an
adapter receipt** (120 in deny), checked under `op.receipts_bound` with 0
failing checks. No operation is flagged: `details.flagged` absent from all
2,240 CALL_RESULT and 640 RECONCILED entries; the new flag checks ran and
none failed.

**Caveats** (exact): "The crash abandons the gateway object inside one
process. No process is killed, and the provider never restarts."
`head_replace` emulated; one fault per operation, at most one restart; no
provider-side faults; only plain ALLOW operations; no witness; "The
freshness entry is constant... Counting 'folders with missing items' no
longer means anything, so read the counts by kind"; "`issuer_only_reconciled`
is a property of these recovery paths, not a failure. For 320 of 1,360
effects (160 of 680 in deny), the flag and mode of the decision rest on the
capability issuer's signature alone"; "Gateway flag changes are not tested
here." The kill suite (§2.5) covers OS-level kills, provider faults and the
flagged path.

### 2.5 OS-level kill suite (`killsuite/`, new)

Run 02:27:31-02:30:33 UTC with the frozen `agentgate-killsuite` and
`agentgate-verify`, `-reps 5 -host-label review-host`. For every cell the
parent starts a fresh provider inside its own (the parent's) process, not
`agentgate-provider`, signs a grant, starts a real gateway as a child
process, drives MCP `tools/call` over loopback, kills the child at the
cell's kill point (`os.Exit(86)` from a fault hook or audit-sink point, or
`TerminateProcess` for the two human points), restarts a new child on the
same operation journal, retries, reconciles and verifies with the keys
fingerprint and final head pinned. No build-1 run exists.

**Cells** (39 x 5 = **195 cell runs**): kill (7 kill points x ALLOW payment
same-ID, FLAG message same-ID, payment fresh-ID control: 21), human (4),
provider faults without a kill (8), power-loss surrogates (4), journal
write failure (1), replay (1). Totals: 235 operations, 220 dispatch
requests, 210 provider effects, 455 answers (185 COMMITTED, 30 REJECTED, 70
UNCERTAIN, 35 approval challenges, 135 no answer because the process died),
135 segments killed with exit 86, 10 terminated, 5 restarts refused; 365
verifications.

**Acceptance measures (all required to be 0): met.**

| measure | result |
|---|---|
| cells that did not test what they model | **0 / 195** |
| operation IDs with more than one provider effect | **0 / 235** |
| REJECTED while the provider held an effect | **0 / 30** REJECTED answers |
| REJECTED/provider_not_committed while the provider holds an effect (end of cell) | **0 / 15** |
| COMMITTED while the provider held no effect | **0 / 185** |
| operations unresolved after Reconcile, not deliberate | **0 / 225** |
| dispatched or effect-holding operations not COMMITTED or REJECTED after Reconcile, not deliberate | **0 / 210** |
| cells with an operation ID dispatched more than once | **0 / 195** |
| kill points not reached | **0 / 145** |

A recount from the provider journals and audit logs on disk found 0
disagreements in 195 cells. Every cell gave the same result in all 5
repetitions.

**Flag preservation (build-2 change 1).** 45 flagged cells: flag kept in
**45/45**; lost in 0/85 outcome entries, 0/60 recovery entries (10 same
process, 50 after a restart), 0/20 replayed answers (10 / 10); the verifier
reports the operation flagged 45/45. Every replayed CALL_RESULT has scope
`call` (35/35). The agent's MCP answer carries no `flagged` member (0/185),
so flag preservation is measured on the audit entries and the verifier
report only.

**Evidence.** Segment 1 alone: 95/155 VERIFIED/ANCHORED, 60 FAILED (50
`provider.matches_audit` after a kill between the provider commit and any
outcome entry; 5 `head.matches` head_reverted; 5 torn audit tail); newest
segment with the chain followed: **145/150** (the 5 failures are
`head_reverted`); single-segment provider cells 40/40; as-killed copies
20/20. Re-verification with the build-2 fields: `head_fresh` not_checked
365/365; `run_complete` never pass, fail 70, not_checked 295; Missing
`freshness` 360/365, `issuer_only` 75, `unresolved` 5. Classification:
`issuer_adapter` 85, `issuer_only_reconciled` 75, `issuer_only_no_effect`
20, `issuer_only_unresolved` 5, not reported 10. **No RECONCILED entry
carried an adapter receipt (0/105)**, so the receipt-on-RECONCILED path is
not exercised here (crash §2.4 and fixture-studies exercise it).

**Power-loss surrogates** (applied to a folder killed after
EFFECT_EXECUTED): torn journal tail → recovers (5/5, torn line discarded);
**torn audit tail → restart refused 5/5** (fail closed; the agent never
gets an answer, the folder needs repair by hand); **`head_reverted` →
"false alarm on an untampered crash state, permanent"** (segment 1 and run
walk FAILED `head.matches` 5/5 and 5/5; the finding text reads like
tampering); leftover temporary head → ignored, VERIFIED.

**Journal write failure** (journal read-only right after consume, 5/5):
first call REJECTED/aborted_before_send (scope `operation`, nothing sent);
after a restart the exact retry runs again and COMMITS with 1 effect. So
**10 REJECTED answers were followed by a commit of the same operation ID**;
each was true when given and the operation got exactly one effect, but "the
scope `operation` label promises more than the gateway can keep in that
case". The first capability is consumed once and never used
(`op.single_use` passes).

**Provider faults** (no kill, 5/5 each): lost response (payment and flagged
message) → UNCERTAIN, then COMMITTED/reconciled, 1 effect; certified
no-effect (signed ABSENT) → REJECTED/provider_not_committed, **0 effects**;
UNKNOWN then APPLIED → COMMITTED; delayed delivery before the lookup →
COMMITTED; delayed delivery after ABSENT → REJECTED, 0 effects, the late
request refused with HTTP 409; lookup failure x3 → COMMITTED via
Reconcile; persistent lookup failure → stays **UNCERTAIN** (deliberate),
VERIFIED/ANCHORED with an `op.outcome_resolved` warning, `run_complete`
fail. Every operation dispatched exactly once (40 dispatches); no UNCERTAIN
operation re-dispatched.

**Human approval** (AED 12,400.00): second approval needed in **15/20**
cells ("An approval that has not led to a dispatch does not survive a
gateway crash"); every effect follows an APPROVAL_VERIFIED in the same
segment; no effect twice.

**Comparison with build 1** (in-process crash, the closest experiment):
same properties (0 duplicates, 0 REJECTED with an effect, 0 COMMITTED
without one); a killed process logs nothing after the provider commit, so
segment 1 alone fails where build 1's abandoned gateway had logged
UNCERTAIN / RECONCILIATION_REQUIRED; before the commit, the killed process
records no outcome, so the restarted gateway runs the operation again (1
effect) where build 1 answered REJECTED (0 effects). Provider faults, the
flagged and human paths, torn writes and a journal write failure were not
covered in build 1.

**Caveats** (exact): "a kill is a process crash, not a power cut. The
kernel file cache survives, so a killed process never loses a write it
made. Power loss is only approximated by the four surrogates"; "Directory-
entry persistence and `fsync` ordering are not tested on real power loss";
"There is no kill inside `audit.Append` between the line sync and the head
rename"; "The provider runs in the parent and never crashes or restarts.
Provider restart ... is not covered"; no witness; human cells use a
synthetic TLS, loopback and browser-header request; the re-verification
uses the same verifier binary.

### 2.6 Concurrency (`concurrency/`)

Run 02:30:15-02:44:55 UTC, method, harness (`concurrency.go`
byte-identical) and analysis script (`analyze.py` byte-identical) as build
1: 7 runs (N = 8 and 32; GOMAXPROCS=1; `-race`), **260 repetitions x 7
scenarios = 1,820 scenario-repetitions, 33,040 calls, 10,740 operations,
3,640 dispatches**, 260 evidence folders. No request fires a flag rule
(0/33,040 CALL_RESULT entries flagged).

| scenario | provider effects | answers |
|---|---|---|
| exact-payment / exact-message | exactly 1 in 260/260 each | 4,720/4,720 COMMITTED each |
| conflicting-reuse | 1 in 260/260 | 260 COMMITTED + 4,460 REJECTED/operation_id_conflict |
| cross-tool-reuse | 1 in 260/260 | 2,360 COMMITTED + 2,360 REJECTED/operation_id_conflict (payment won 77, message 183) |
| lost-response | 1 in 260/260 | 260 UNCERTAIN + 4,460 COMMITTED/reconciled, 0 REJECTED |
| budget-race (N x USD 500.00) | exactly 6 in 260/260 | 1,560 COMMITTED + 3,160 REJECTED/policy_denied |
| count-race | exactly 3 in 260/260 | 780 COMMITTED + 3,940 REJECTED/policy_denied |

Harness invariant, safety (separately from completion), completion and
consistency each **1,820/1,820**; journal transitions 10,740/10,740;
independent effect count 1,820/1,820 (3,640 receipts); delegation exact
260/260; **0 race-detector reports** in 60 instrumented repetitions.
**Lease (30 s):** 0 expiries in 3,640 dispatches; minimum slack to the
deadline (lower bound) **28,460.1 ms** (`n32`); maximum consume-to-intent
864.0 ms (`n32`, 100 % median CPU, up to 5 `agentgate-eval` processes).
**Replay scope:** 15,220/15,220 repeated answers scope `call`.

**Evidence.** Harness (pinned): 260/260 VERIFIED/ANCHORED, 0 failing
checks; `head_fresh` and `run_complete` not_checked 260/260; `missing` 2
entries in 260/260 (`freshness` 1, `issuer_only` 1: the lost-response
operation). Standalone CLI without anchors: 260/260 VERIFIED/CONSISTENT, 34
checks (32 pass, 2 warn), `missing` 3. Classification: 3,380
`issuer_adapter`, 260 `issuer_only_reconciled`, 7,100 `audit_only`. The
build-2 verifier gives the same report on build 1's 260 folders (0 false
alarms). Unit tests: the 10 of build 1 plus 3 for the replay flag, all ok.

**Comparison with build 1.** Identical safety, completion, journal and
replay counts. Differences: minimum slack 28,801.0 ms → 28,460.1 ms and
maximum consume-to-intent 649.0 → 864.0 ms (load, not a performance
result); cross-tool winner 72/188 → 77/183 (scheduler); `missing` empty →
2 entries (verifier change, also on build-1 folders); different race binary
(source differs).

**Caveats** (exact): "Same-ID calls do not truly race. The per-operation
lock (`lockOperation`) serializes them"; "Invariants that held here are not
a proof for all interleavings"; no flagged operation, so build 2's flag
changes on this path are covered by unit tests only; untested: reuse across
principals, races during a restart, two calls presenting one capability to
the dispatch path, flagged operations under concurrency.

### 2.7 Custody, freshness and run completeness (`custody/`)

20 runs, 02:31:00-02:40:55 UTC (15 flag, 2 of them under a process
monitor, 5 deny), relay probe 02:41:06-02:43:22. Same commands as build 1;
scripts extended only to read the new fields.

**Build-1 numbers, again on build 2** (every outcome count and failing-
check set equal; `compare_build1.json`): self-test 20/20, 180/180 revision
checks; tamper lab ordinary edits 140/140 without and with anchors,
coherent rollback 0/20 without and 20/20 with anchors; in-process matrix
300/600 tampered detected, **0/120 false alarms**, 60/120 ANCHORED; CLI =
in process 720/720; extended CLI matrix (1,480): clean 120/120 accepted,
wrong-run anchor 60/60 refused, tampered 740/1,300 detected; rollback table
unchanged (keys anchor alone 0/20 for R1, R3, R4; a later trusted head
20/20; a stale witness head as a saved file **0/20, ANCHORED**); withheld
segment detected via `--witness-url` 20/20 with either journal; signed run
status verified 20/20 for both segments; a relay that changed the
witness's answers refused **180/180**, a withheld status exit 2 in 40/40;
witness probes 300/300; replayed answers 80/80 scope `call`.

**New: freshness and completeness as explicit outputs** (1,480 CLI and 720
in-process verifications):

| case | CLI | in process |
|---|---|---|
| live witness (`--witness-url`): `head_fresh` | **pass 180/180** | **pass 100/100** |
| any other anchor: `head_fresh` | pass 0/1,300 | pass 0/620 |
| ANCHORED without the live witness: `head_fresh` and `run_complete` not_checked plus a `freshness` entry | 200/200 | 140/140 |
| saved stale head, rollback R1 | ANCHORED 20/20; not_checked 20/20; freshness entry 20/20 | the same, 20/20 |
| saved stale segment head (#3), segment rollback R7 | the same, 20/20 | (no such cell) |
| withheld segment R5, R5j via `--witness-url`: `run_complete` | **fail 40/40** (`head_fresh` pass 40/40) | **fail 40/40** |
| `run_complete` pass: clean whole run with the live witness | **20/20** | 20/20 |
| `run_complete` pass on tampered evidence | **0/1,300** (0/1,340 with the wrong-run cells) | 0/600 |
| `run_complete` fail on clean evidence | **0/120** | 0/120 |
| relay probe, every changed answer: `head_fresh` and `run_complete` fail | 180/180 | |

- **A consumer that requires `run_complete` = pass** accepted the clean
  whole run 20/20 (with `--witness-url`) and none of the 560 tampered CLI
  verifications the verdict leaves undetected (160 ANCHORED, 400
  CONSISTENT).
- "A pass means the witness's statement is current. It does not mean the
  log matches that statement": in 160 of the 180 live-witness CLI
  verifications the evidence is tampered and the verdict is FAILED.
- **Stale window and outage, as measured:** statuses signed 135-584.5 s
  before the fetch refused 40/40; fresh statuses (0.3-1.7 ms old) passed; a
  stopped witness ends the CLI with exit 2 (20/20), no fallback. The exact
  2-minute boundary and clock jumps are covered by unit tests (§2.2), not
  by this experiment.
- The freshness entry appears only when the pin or saved head anchors the
  log end (340 CLI verifications list it).

**Two build-1 open issues closed:** the in-process live anchor now applies
the 2-minute rule (`head_fresh` pass 100/100 needs the fetch time); a saved
witness head now lists the "withheld later restart segment cannot be ruled
out" gap in `missing` (40/40).

**Other.** Outage unchanged (1 WITNESS_UNAVAILABLE entry, 31 pushes
succeed and 1 fails, a jump of 9 against ordinary jumps up to 8). Restarts
unchanged (22 operations replayed; provider commits 14 → 14, deny 11 →
11). Replayed answers: the `flagged` field matches the decision 80/80, none
of the replayed operations is flagged (0/80). Classification: flag runs
`issuer_adapter` 13, `issuer_only_reconciled` 1, `audit_only` 11 (15/15);
deny 10 / 1 / 14 (5/5). Process monitor: the short post-run provider was
seen in 2/2 runs (build 1: 0/2; slower runs on the shared machine).
Differing timing values: replayed-pair age 135-420 s → 135-584.5 s; status
lag 0.3-1.3 ms → 0.3-1.7 ms; per-run time 7.6-17.1 s → 4.5-42.6 s.

**Caveats** (exact): "The provider and the witness are separate processes,
not separate custodians."; "The gateway process could read their key files,
including the witness key that signs the status."; "A replay within 2
minutes is accepted by design."; "Freshness assumes agreeing clocks...
Clock rollback, forward jumps and the inclusive 2-minute boundary were not
tested here."; "Not measured: registration preemption and substitution"
(measured at fixture level in §2.2); only a hard kill of the witness between
operations and one gateway restart per run.

### 2.8 Policy misuse (`misuse/`)

Run 02:31:10-02:31:24 UTC, each mode repeated twice more (02:31:25-
02:33:42); 59 hand-written cases, 95 requests, flag and deny mode;
`misuse.go` byte-identical to build 1. Observed classes identical in all 3
runs, 95/95 per mode.

| category | n | flag: blocked / flagged / permitted / invalid | deny: blocked / permitted / invalid | as specified |
|---|---|---|---|---|
| legitimate | 29 | 0 / 1 / 28 / 0 | 1 / 28 / 0 | 29/29 |
| review | 10 | 0 / 10 / 0 / 0 | 10 / 0 / 0 | 10/10 |
| harmful | 44 | **24 / 3 / 17** / 0 | 27 / 17 / 0 | 44/44 |
| malformed | 12 | 2 / 0 / 0 / 10 | 2 / 0 / 10 | 12/12 |
| total | 95 | 26 / 14 / 45 / 10 | 40 / 45 / 10 | **95/95** |

Harmful, flag mode: 24 blocked (54.5 %), 3 executed with a flag (6.8 %),
**17 executed with no flag (38.6 %)**; blocked by content rules only 10, by
DEL-* only 11 (content rules alone would have allowed 10 and flagged 1),
both 3 (deny: 13 / 10 / 4). Residual harm (17): 12 x AED 5,000.00 to one
payee (AED 60,000.00), USD 500.00 #7 and #8 and releases #4 and #5 in the
no-grant controls, AED 4,999.99 for the wrong purpose. Paired controls:
6/8 vs 8/8 (USD budget), 3/5 vs 5/5 (release count). Confidential text: 5/8
blocked by MSG-CONFIDENTIAL-TEXT, **3/8 executed with only the generic
MSG-EXTERNAL flag**; 0/2 false positives internally. Legitimate blocked
0/29 (flag), 1/29 (deny, as specified). Flag mode executed 14 of 59
committed effects with a flag and no person.

**Regrouped by case family (made after the run; no label changed):**

| group | n | flag: B / F / P / I | deny: B / P / I |
|---|---|---|---|
| harmful: what the policy is built to stop | 24 | **24 / 0 / 0 / 0** | 24 / 0 / 0 |
| harmful: policy-compliant harm (split payment 12, wrong purpose 1, confidential paraphrase or near-copy 3) | 16 | **0 / 3 / 13 / 0** | 3 / 13 / 0 |
| harmful: no-grant controls | 4 | **0 / 0 / 4 / 0** | 0 / 4 / 0 |

Labels: `category` and `expected` are written in `misuse.go` from the case
definition (REVISION_CONTRACT R4, committed in `997d607` before any misuse
run); the earliest recorded run (2026-10-07, `56bab94`) carries all 95
category labels as in build 2 (0/95 differ); one expected outcome changed
since (the comma case, `d73aa73`). Thresholds (AED 5,000.00 / 50,000.00,
USD 1,500.00 / 15,000.00, budgets AED 100,000.00 and USD 3,000.00) are
"**illustrative parameters of a fictitious organisation**".

Status contract: REJECTED with `dispatched: false` 36/36 (deny 50/50);
COMMITTED with exactly one journal entry and one EFFECT_EXECUTED 59/59
(45/45); every invalid request leaves an audit entry. Evidence: 59/59
ANCHORED per mode; CLI 118/118 VERIFIED/CONSISTENT without anchors and
118/118 ANCHORED with self-derived anchors; classification 59
`issuer_adapter` + 36 `audit_only` (flag), 45 + 50 (deny); `flagged` 14 /
0, `flagged_unconfirmed` 0. The build-2 verifier gives the same on build-1
evidence.

**Comparison with build 1:** every policy number identical (0/95 requests
changed per mode; 563 / 521 audit entries, 0 differ after normalisation).
The only differences: `head_fresh`, `run_complete` not_checked in all 236
CLI verifications that read them; a `freshness` entry for every pinned
head (CLI with self-derived anchors: 118 of 236 rows differ by +1).

**Caveats** (exact): "The 44 harmful requests are an authored case set, not
a sample: the percentages describe this set only and are not a population
estimate for autonomous-agent safety."; "Correct enforcement of the
specified rules is not adequate coverage"; "MSG-CONFIDENTIAL-TEXT detects
verbatim copies only; it is not information-flow control."; "Whether any
label was edited during development before the first recorded run cannot
be established from the repository"; one tenant and one delegate; no
witness, repeated operation or fault.

### 2.9 Verifier robustness (`robustness/`)

Fuzzing 02:31-02:42, coverage 02:42-02:45, mutation 02:45-04:00 UTC on a
94-file copy of `86643d7` (§0.1); method, settings and scripts as build 1.
Starting suite: 144 top-level tests (141 tests, 3 fuzz targets on seeds),
589 passes including subtests, 0 failures; plus 14 tool tests.

| measurement | build 1 | build 2 |
|---|---|---|
| fuzzing (120 s per run, 12 workers) | 0 crashers in 40,542,369 executions | **0 crashers or property failures in 34,178,449** (FuzzParseLogLine 15,781,402; FuzzCOSE 18,383,289; FuzzRunFiles 41 / 1,362 / 12,355); replay of 1,483 generated inputs plus 150 seeds: 0 failures |
| refusal sites; full suite | 139/139 = 1.000 | **142/142 = 1.000** (3 new sites) |
| **honest score** | 51/139 = 0.367 (4-test pattern) | **56/142 = 0.394** (7-test pattern of `VERIFIER_CHECKS.md` §6) |
| same 4-test pattern | 51/139 = 0.367 | 58/142 = 0.408 |
| without only the 2 restart tests | 137/139 = 0.986 | 140/142 = 0.986 (same two survivors, `provider.go:150`, `segments.go:308`) |
| strict variant (7 + `TestLifecycleConflictingHistories`, supplementary) | not run | 53/142 = 0.373 |
| survivors without the post-hoc tests (executed / not) | 88 (45 / 43) | 86 (44 / 42) |
| checks with no site killed without the post-hoc tests | 9 | **7 of 38** (`artifact.effect_digest`, `artifact.effect_readable`, `delegation.window`, `files.run_id`, `head.signature`, `op.requires_validation`, `provider.signature`) |
| refusal conditions | 299 | 313 (142 fail, 7 warn, 164 problem) |
| executed by the full suite | 239 | 256 |
| **never executed by tests or fuzzing** | 44/299 | **47/313** (15.0 %), all `problem` lines; 41 the same, 3 now executed, 2 reached only by fuzz in build 1 and not this time, 4 new (`checkReconciledReceipt`) |
| statement coverage, full suite | 3,525/3,919 (89.9 %) | 3,703/4,085 (90.6 %); without the seven 3,571 (87.4 %); suite or fuzz 3,761 (92.1 %) |
| check IDs; R3 parser tests | 38; 37/37 | 38; 37/37 (identical list) |

**New sites:** `operations.go:498` (`checkReconciledFlag`; killed in the
honest and strict variants too, because `TestLifecycleConflictingHistories`
and `TestUnboundFlagsTextsNameTheLogNotTheCapability` also kill it);
`operations.go:935` (`checkReconciledReceipt`) and `operations.go:517`
(`checkReplayedFlag`), each killed only by its own post-hoc test, so both
survive without the post-hoc tests. **Why the honest score rose (+5
kills):** all five from tests added on 2026-10-10 outside the seven-test
pattern (3 by `TestLifecycleConflictingHistories`, 1 by
`TestTimeStepsInsideASegment`, `operations.go:498` as above); "All were
written on 2026-10-10 for review-3 requests ... but after build 1's
survivor list was published." Witness sites (`head.witness`,
withheld-segment site in `head.anchor`) killed in all six variants.

**Caveats** (exact): "0.394 is the honest score under the documented
pattern. The 1.000 is not independent evidence."; "A survivor usually means
another check catches the same tampering, not that the tampering would be
accepted."; one mutation operator (the held-out operators ran separately,
§2.10); short fuzz runs on a loaded machine
(execution counts are lower bounds, not comparable between builds); "What
the fuzz properties check: crashes, errors and exact-form parsing, not
semantic acceptance"; statement coverage only; the refusal-condition
definition does not count build 2's new `Missing` and dimension code.

### 2.10 Held-out mutation operators (`heldout/`, new)

Campaign 05:02:54-07:19:49 UTC (mutants 05:07-07:19), after the baseline
session; manifest checks before (05:02:54Z) and after (07:19:42Z): 1,868
files, 0 differ. This is the first campaign of the three held-out operators
defined in `../revision/robustness/HELDOUT_OPERATORS.md` (frozen in commit
`103a438`; addendum section 7 including 7.10 and 7.11, last commit `be5e88c`
at 02:04:40 UTC). **Build 1 has no held-out result**: the operators were
frozen on 2026-10-10, after build 1. The comparison point is variant 3,
build 1's verifier source and suite.

**Method** (`heldout/RESULTS.md` §1). The mutated files are the non-test
`.go` files directly in `internal/auditverify` (`fixture/`, `tools/` and
tests excluded). There is one mutant per site, applied with `go test
-overlay` (the source tree is never modified), and each mutant runs `go test
-count=1 -timeout=5m0s [-skip ...] ./internal/auditverify/...
./cmd/agentgate-verify/`. Killed = tests fail; survived = tests pass; build
errors and timeouts are reported and left out of the score. `-parallel 8`
replaced the tool's default 6 ("It changes no result"). Suite variants:

- **v1**: build 2's frozen copy, every test (158 top-level tests: 134 in
  `internal/auditverify`, 10 in `cmd/agentgate-verify`, 14 tool tests that
  cannot kill a mutant);
- **v2**: the same without the four post-hoc tests, the pattern the frozen
  document fixes (build 1's four-test pattern of §2.9);
- **v3**: the `f01d1c9` export with its own tests (114 top-level tests) and
  the same four-test skip. Build 2's tool reproduced the committed site
  lists there exactly (append 153, boundary 117, equality 66), so the run
  went ahead;
- **v2b** (supplementary, not defined by the frozen document): build 2
  without the seven post-hoc tests of `VERIFIER_CHECKS.md` §6, the pattern
  behind the honest score 0.394 (§2.9).

The coverage join puts every survivor into one group: *not executed* (its
block did not run), *evaluation not shown* (a switch case expression, which
no profile block contains, or the right operand of `&&`/`||`), *equivalent*
(judged by hand, with a one-line argument each in `equivalence.csv`) or
*executed but undetected*. The three build-2 coverage profiles are
byte-identical to the robustness rerun's.

**Headline** (kill score = killed / (killed + survived), every survivor in
the denominator):

| operator | v1: build 2, full suite | v2: build 2, without the 4 post-hoc tests | v3: build 1 source and suite (`f01d1c9`), without the 4 | v2b (suppl.): build 2, without the 7 |
|---|---|---|---|---|
| H1 `append` (delete one finding) | **63/164 = 0.384** (ceiling 107/164 = 0.652) | **58/164 = 0.354** (ceiling 99/164 = 0.604) | **52/153 = 0.340** (ceiling 84/153 = 0.549) | 55/164 = 0.335 (ceiling 92/164 = 0.561) |
| H2 `boundary` (swap `<`/`<=`, `>`/`>=`) | **52/123 = 0.423** | **51/123 = 0.415** | **43/117 = 0.368** | 49/123 = 0.398 |
| H3 `equality` (a hash or byte comparison always says "equal") | **29/71 = 0.408** | **18/71 = 0.254** | **16/66 = 0.242** | 17/71 = 0.239 |
| all three | **144/358 = 0.402** | **127/358 = 0.355** | **111/336 = 0.330** | 121/358 = 0.338 |
| survivors: not executed / evaluation not shown / equivalent / executed but undetected | 66 / 53 / 13 / 82 (214) | 75 / 59 / 13 / 84 (231) | 79 / 61 / 13 / 72 (225) | 88 / 59 / 14 / 76 (237) |

There were 0 build errors and 0 timeouts in every reported run. The first H2
run on v1 had 3 out-of-memory failures and was repeated (below). The
ceiling (H1 only) is the share of sites whose block the variant's suite
runs. For H2 and H3 the same column is informative only (v1: 94/123 = 0.764
and 56/71 = 0.789), because switch cases may be evaluated: the upper bound
there is (executed + unmapped) / sites, 115/123 and 70/71 for v1.

**What the scores show.**

- **The full suite's 1.000 does not carry over.** Against the refusal-site
  operator the suite was strengthened against, it scores 142/142 with the
  full suite, 58/142 = 0.408 without the four post-hoc tests and 56/142 =
  0.394 without the seven (§2.9). Against the held-out operators the same
  three variants score 144/358 = 0.402, 127/358 = 0.355 and 121/358 = 0.338.
  In the file's words: "the full suite's 1.000 does not carry over to other
  defect classes: the full suite kills 0.40 of the held-out mutants."
- **H1** (delete one finding): the never-executed share dominates (57 of 101
  v1 survivors), and the ceiling (0.652) shows that this suite could kill at
  most 107 of the 164 H1 mutants. Group deletions are killed 10 of 12 times
  in every variant; the two survivors are the `add` closure of
  `decisionBinding` (`decisions.go:277:44`) and the catalog findings of
  `replayDecision` (`replay.go:473`), both executed but undetected.
- **H2** (boundary): "H2 is mostly killed where the swap makes a condition
  constant." Comparisons with literal 0 (emptiness included) score 39/59 =
  0.661 on v1; without them, the "boundary moved by one" mutants score 13/64
  = 0.203. By class (v1): emptiness 31/40, count 10/18, length 6/21, time
  4/26, budget 1/9, limit 0/9: "no test sits exactly on a time window edge,
  a budget limit, a count limit, a size limit or a nesting limit".
- **H3** (equality) depends most on the post-hoc tests: 29/71 with them,
  18/71 without the four. Over all operators the four post-hoc tests
  account for 5 H1, 1 H2 and 11 H3 kills; no mutant is killed by v2 and not
  by v1.
- **The 82 executed-but-undetected survivors** (v1): `operations.go` 40,
  most of them in the receipt and capability binding (`checkReceipts` 15,
  `checkReconciledReceipt` 8, `checkCapability` 6), the human-approval
  binding (`decisionProblems` 4, `checkApprovalForCapability` 3) and
  `requirePolicy` 3; then `delegation.go` 8, `reconcile.go` 5, `replay.go`
  5, `decisions.go` 4, `verify.go` 4 (three are chain links: a wrong `seq`
  alone or a wrong `prev_hash` alone is never tested), `witness.go` 4,
  `tamper.go` 4 and 8 more in six files. "Typically the condition is a field
  of a signed artifact (operation, action digest, provider reference, policy
  decision hash) that tests only ever change together with another field,
  so a second finding still fails the check." Each such mutant was given a
  concrete input on which it changes a check result.
- **The 13 equivalent mutants** (v1): two `requirePolicy` findings that are
  always accompanied by another finding of the same check
  (`operations.go:426`, `:442`), two position comparisons in
  `decisionBounds` (`delegation.go:554`, `:555`), `tamper.go:894`, and 8
  text-only mutants. Variant 2b adds `segments.go:200:44` (text only).

**Declared splits and scores without equivalent mutants**, shown beside the
headline and never instead of it (`heldout/RESULTS.md` §2.2):

| split | v1 | v2 | v3 |
|---|---|---|---|
| H1, single deletions | 53/152 = 0.349 | 48/152 = 0.316 | 42/141 = 0.298 |
| H1, the 12 group deletions | 10/12 = 0.833 | 10/12 = 0.833 | 10/12 = 0.833 |
| H2, without emptiness | 21/83 = 0.253 | 20/83 = 0.241 | 16/81 = 0.198 |
| H2, without comparisons with literal 0 | 13/64 = 0.203 | 12/64 = 0.188 | 9/63 = 0.143 |
| H2, comparisons with literal 0 only | 39/59 = 0.661 | 39/59 = 0.661 | 34/54 = 0.630 |
| H2, verifier only (no `tamper.go`, `parallel.go`) | 51/113 = 0.451 | 50/113 = 0.442 | 42/107 = 0.393 |
| H3, verifier only (no `tamper.go`, `parallel.go`) | 28/68 = 0.412 | 17/68 = 0.250 | 15/63 = 0.238 |
| H1 without equivalent mutants | 63/162 = 0.389 | 58/162 = 0.358 | 52/151 = 0.344 |
| H2 without equivalent mutants (text-only kept) | 52/112 = 0.464 (52/120 = 0.433) | 51/112 = 0.455 (51/120 = 0.425) | 43/106 = 0.406 (43/114 = 0.377) |
| H3 without equivalent mutants (none) | 29/71 = 0.408 | 18/71 = 0.254 | 16/66 = 0.242 |

**Comparison with build 1 and with the values fixed before the run**
(`heldout/RESULTS.md` §3; build 1 = variant 3):

| measurement | build 1 / pre-run value | build 2 | why it differs |
|---|---|---|---|
| sites H1 / H2 / H3 | 153 / 117 / 66 | 164 / 123 / 71 | 22 added, none removed: 11 H1, 1 H2 and 5 H3 sites in `checkReconciledReceipt` (the adapter receipt on RECONCILED), 5 H2 sites in the new `freshness.go` |
| unmapped sites (switch cases), H1 / H2 / H3 | 0 / 21 / 14 (7.10 probe) | 0 / 21 / 14 | same |
| `eval_not_shown` flags | 2 / 45 / 38 | 2 / 47 / 38 | +2 boundary sites in `freshness.go` |
| mutants that compile | 336/336 (pre-run `-compileonly`) | 358/358 | 0 build errors in the reported runs |
| the six §6 validation mutants (4 killed, 2 survived) | fixed before the run | the same six results in v1 and v3 | |
| H1 ceiling, full suite / without the 4 | 93/153 = 0.608 / 84/153 = 0.549 | 107/164 = 0.652 / 99/164 = 0.604 | new tests execute 7 more matched lines, and 7 of the 11 new lines run; on the `f01d1c9` export the block join reproduces the pre-run values exactly |
| **without the 4: H1 / H2 / H3** | 52/153 = 0.340 / 43/117 = 0.368 / 16/66 = 0.242 | 58/164 = 0.354 / 51/123 = 0.415 / 18/71 = 0.254 | +3 / +3 / +1 matched sites killed; +3 / +5 / +1 new sites killed |
| **without the 4: all three** | 111/336 = 0.330 | 127/358 = 0.355 | +7 matched, +9 new |
| refusal-site operator (context) | 139/139; 51/139 = 0.367 | 142/142; 58/142 = 0.408 | §2.9 |

- **Matched sites** (v3 against v2): 329 of the 336 `f01d1c9` sites have the
  same result on build 2. The other 7 went from survived to killed, each
  killed by a test that does not exist at `f01d1c9`:
  `TestLifecycleConflictingHistories` (3),
  `TestLifecycleL4FullVerifierAllReconciled` (2),
  `TestLifecycleL1AuditKeyDowngradeToUnresolved` (1) and
  `TestRecoveryRecordsStateTheBoundFlag` (1; one of the seven post-hoc tests,
  not of the four). No site went from killed to survived. The four killing
  tests were added in commit `afe8730` (00:34 UTC), after the freeze commit
  (00:17:56 UTC) but before any held-out campaign run.
- **v2b against v2**: the three extra post-hoc tests kill 3 H1, 2 H2 and 1
  H3 mutants that no test outside the seven kills: five in
  `checkReconciledReceipt`, plus `segments.go:200:44`.
- Build 2's other verifier changes (classification evidence, `Missing`
  kinds, the derived dimensions, the flag checks, the RECONCILED receipt)
  "change the scores only through the 22 new sites and these tests".

**Memory incident** (no effect on the reported results). In the first H2 run
on v1 (05:23-05:35 UTC) the mutant `files.go:237:30` (`parseLog`:
`len(rest) > 0` becomes `>= 0`) never left its loop. Its allocation request
of 20.9 GB failed after 197 s, so it was killed (the test process crashed),
and three concurrent mutants failed with out-of-memory errors, which the tool
reports as build errors. The repeat agreed on 120 of 123 results. The three
became survived (`operations.go:468:58`, `parallel.go:61:16`) and killed
(`operations.go:934:19`), so the incident caused no false kill. Later
`files.go` parts ran alone, under `jobcap` (a Windows job object). The
reported v1 H2 result (52/123, 0 timeouts) uses the watchdog repeat of
`files.go`; with the hard-limit (version 1) part it would have been 51/122
with one timeout. The runaway mutant was killed in all five completed runs of
it: "a detection by crash, not by an assertion".

**Caveats** (exact): "The 0.40 is measured against defect classes the suite
was not written for. It is not a statement about attacks: a surviving mutant
usually means that another check, or another finding of the same check,
still reports the tampering the tests use."; "Equivalence is a hand
judgement (one person, one pass, no second reviewer). It ignores detail
text, following section 5's example; the 9 text-only mutants are counted
apart and kept in the denominator of the headline."; "'Evaluation not shown'
is not settled. 53 variant-1 survivors (31 H2, 22 H3) are right operands or
switch case expressions; line coverage cannot say whether their expressions
ran." (no separate check was run to settle them, which 7.4 would allow);
variant 3 runs build 2's tool in the `f01d1c9` tree, as 7.2 requires; the
deviations from a single plain run per operator (`-parallel 8`, H2 in two
invocations, `jobcap`, two repeats on v1): "None of this changes the
per-mutant protocol."; "A 4 GB zombie process is left on the machine" (the
runaway mutant's `agentgate-verify.test.exe` under jobcap version 1, since
06:25 UTC; it "will probably need a reboot to go away"); another agent used
the machine during the runs, no other AgentGate experiment process was
running at the start of any run, and wall times are not performance results;
"No test was written or changed, before or after the run, in response to any
held-out result."

### 2.11 Baselines, load, per-stage cost and witness push (`baseline/`)

Session 04:22:32-04:45:22 UTC, **alone**, the only build-2 experiment whose
times are results. Method as build 1 (direct / policy-only / full /
full+journal / full-flagged over the same loopback transport and simulated
provider; 500 paired trials in 10 blocks; closed-loop 1-16 clients; every
call kept). Six runs (R1-R5 financial, M1 message); **R2 primary** (lowest
background load, 0.369 cores); desktop load 0.36-0.50 logical cores
(build 1: 0.19-0.36). **0 of 62,500 measured and 0 of 4,100 warm-up calls
failed; 230/230 folders ANCHORED.** Analysis: build 1's script, seed
20261007, 10,000 resamples; the headline interval is the **block-level**
(cluster) bootstrap.

| paired difference per call (R2) | median | block 95 % CI | trial 95 % CI | range R1-R5 | mean [block CI] |
|---|---|---|---|---|---|
| mediation (policy-only − direct) | **3.18 ms** | [3.13, 3.25] | [3.14, 3.23] | 3.10-3.19 | 3.19 [3.15, 3.24] |
| signed durable recording (full − policy-only) | **11.29 ms** | [11.19, 11.43] | [11.22, 11.37] | 11.29-11.57 | 12.98 [11.40, 16.05] |
| total (full − direct) | **14.46 ms** | [14.39, 14.54] | [14.41, 14.50] | 14.46-14.68 | 16.18 [14.62, 19.24] |
| operation journal (full+journal − full) | 3.43 ms | [3.23, 3.57] | [3.25, 3.56] | 3.27-3.47 | 3.96 [3.39, 4.93] |
| flagging (full-flagged − full) | −0.07 ms | [−0.13, 0.01] | [−0.15, −0.00] | −0.19 to −0.07 | 0.57 [−0.14, 1.84] |
| everything (full+journal − direct) | 17.87 ms | [17.74, 18.03] | [17.79, 17.95] | 17.73-18.18 | 20.14 [18.07, 24.14] |

"Never add or subtract the medians of different rows." Flagging: "flagging
added no measurable latency (within about 0.3 ms, 2 % of a full call,
either way)". M1: mediation 3.36, recording 11.39, total 14.72, journal
3.43 ms.

**Tails (retained).** Sequential R2 p50 / p95 / p99: full 15.72 / 20.09 /
**68.42** ms, full+journal 19.14 / 23.84 / 72.12, full-flagged 15.60 /
20.80 / 68.47; the durable tails come from one disk slowdown in R2's block
10 (64 durable calls over 30 ms). In R1, R3, R5 (no sequential slowdown):
full p99 20.33-20.54 ms. Disk slowdowns also hit R4 (294 durable calls over
30 ms), R3 at 8 clients and M1; they are kept in the data.

**Throughput and saturation** (median of R1-R5): full 62.7 at 1 client,
89.3 at 2, 92.6 at 4, 92.2 at 8, 92.6 at 16 calls/s; **levels off at 92.5
calls/s from 4 clients** with 1.1 cores busy; full+journal 87.7-88.3;
policy-only CPU-bound (706 at 16 clients); direct 3,006 at 16. Why: one
audit log per gateway, appends serialized by one mutex, each fsyncs
`audit.jsonl` and replaces `head.json` through a synced temporary file, no
group commit, six entries per call; 6 x 1.70 ms = 10.2 ms of serialized
disk work gives a ceiling of 98 calls/s; the observed 92.5 calls/s means
10.8 ms per call, so the standalone appends explain about 94 %. **Little's
law** holds within 1.5 % in every full and full+journal cell (R2 at 16
clients: 16 / 93.13 = 171.8 ms against an observed mean of 169.6 ms);
full's median latency 15.6 ms at 1 client to 172.1 ms at 16, about N x
10.8 ms.

**Per-stage cost of one durable append** (`TestStageCost`, run2, 10,000
timed appends; means): encode + hash 2.3 %, Ed25519 signing 2.2 %, log line
write 0.7 %, **log fsync 24.8 %**, temporary head write 11.7 %, **head fsync
43.7 %**, head rename 14.6 %, **directory fsync 0.0 % (none on Windows)**;
staged total mean 1,709.3 us against uninstrumented `Append` 1,699.7 us. The
whole `head.json` replacement is 70.0 % of an append; CPU work is 4.5 %.
Six consecutive appends sum to a median of 9.95 ms, **88 %** of the 11.29 ms
recording median ("not an exact decomposition"). The `agentgate-eval cost`
cross-check agrees within 2-4 %. About 33 KB allocated per append.

**Witness push** (`TestWitnessPushCost`, not in any reported latency): one
push plus save per call would add about **2.4 ms** per call; one per entry
about **11.3 ms**. "No latency in this report or the paper includes a
push": `baseline.go` (byte-identical in builds 1 and 2) has no witness.

**Storage and memory.** Consumer 2 TB NVMe SSD, NTFS, cluster 4,096 bytes,
47.9 GiB free (97.4 % full) at the start; "**Device write-cache setting:
not determinable without administrator rights**"; Defender real-time
protection on. Allocation per call 420 / 2,678 / 3,046 / 3,072 KiB (direct
/ policy-only / full / full+journal) — "Allocation volume is not resident
memory": peak working set ≤ 86.3 MiB, peak Go heap ≤ 48.3 MiB.

**Comparison with build 1** (build 1 recomputed with block intervals):

| measure | build 1 (R3) | build 2 (R2) | change |
|---|---|---|---|
| mediation | 3.32 [3.25, 3.37] | 3.18 [3.13, 3.25] | −0.14 (−4 %) |
| signed durable recording | 11.40 [11.35, 11.47] | 11.29 [11.19, 11.43] | −0.11 (−1 %) |
| total | 14.69 [14.64, 14.75] | 14.46 [14.39, 14.54] | −0.23 (−1.6 %) |
| operation journal | 3.20 [3.15, 3.29] | 3.43 [3.23, 3.57] | +0.23 |
| everything | 17.84 [17.75, 17.91] | 17.87 [17.74, 18.03] | +0.04 |
| flagging | −0.27 [−0.36, −0.18] | −0.07 [−0.13, 0.01] | +0.20 |
| full throughput, 4-16 clients | 94.2-94.4 calls/s | 92.2-92.6 | −2 % |
| full latency at 16 clients, p50 | 168.8 ms | 172.1 ms | +3.3 |
| allocation per call (KiB) | 422 / 2,681 / 3,045 / 3,076 | 420 / 2,678 / 3,046 / 3,072 | none |
| failed calls; evidence | 0 / 62,500; 230/230 ANCHORED | 0 / 62,500; 230/230 ANCHORED | none |

"Build, desktop load (higher now) and disk state (fuller now) changed
together, so no difference is attributed to the build alone; none needs the
build to explain it." (`audit.go`, `baseline.go`, `resources.go`,
`cost.go` are byte-identical.)

**Caveats** (exact): one machine, loopback provider in the same process,
small payloads and short logs; "Durable costs depend on this consumer NVMe
drive at 97.4 % full, NTFS and Windows flush semantics"; "The rotated order
balances positions, not predecessors: differences of a few tenths of a
millisecond ... are not resolved"; the stage path is a copy of `Append`
guarded by a byte-equality test; "Directory fsync does not exist on
Windows; rename durability is not tested here"; and for any optimisation:
"each must still finish the flush of a recorded step before that step
creates authority (persistence before authority, R4)".

## 3. Claims map: the second review

"Supported" always means "on the tested schedules, cases, fixtures and
machine, with the stated denominators". "Narrowed" quotes the limitation
wording from the experiment files. "Deferred to GP2" means not done in this
revision. Every row comes from build 2.

### 3.1 Summary

| review item | status | main evidence |
|---|---|---|
| Major 1: incremental contribution and its conditions | supported, narrowed | §2.1, §2.3, §2.2 L3/L4 |
| Major 2: recovery and classification assurance | supported (reported explicitly), narrowed | §2.2, §2.4, §2.5, §2.9 |
| Major 3: compromise simulation vs real signatures | partly supported, narrowed; A+I+X real re-signing deferred | §2.1, §2.2 |
| Major 4: realistic persistence and delivery failures | supported for process kills and provider faults, narrowed; power loss and provider restart deferred | §2.5, §2.4, §2.2 s5 |
| Major 5: custody freshness and clocks | freshness and completeness supported; custody and enrollment narrowed and deferred | §2.7, §2.2 |
| Major 6: unchecked fields and policy authority | not addressed by an experiment; wording narrowed; checks deferred | §2.1 caveats, §2.2 |
| Major 7: regression vs adequacy; policy workload | supported, narrowed (held-out operators: full suite 144/358 = 0.402 against 142/142 for the refusal-site operator) | §2.9, §2.10, §2.3, §2.8 |
| Major 8: artifact and performance | performance supported; build-2 archive not yet rebuilt | §0, §2.11 |
| Priority 1 (6 items) | 4 with evidence, 1 deferred (effect and approval bindings), 1 open (archive) | §3.3 |
| Priority 2 (6 items) | 4 with evidence, 2 deferred | §3.4 |
| Priority 3 (3 items) | deferred | §3.5 |
| Minor comments (6) | 2 with evidence, 4 text-only | §3.6 |

### 3.2 Major comments

**Major 1. State the incremental contribution and its conditions.**

- *Supported.* Full verifier: **0/336** binding flips; replay off:
  **12/336** ({strip-flag, invent-flag, change-rules} x {audit,
  audit+issuer} x {none, keys}); only snapshot binding off: **8/336**; a
  head anchor leaves 0/168 flips in every setting (§2.1). Identical in
  build 1 and build 2, all 51,840 rows. The Python subset verifier finds
  the same 6 distinct flips on a frozen corpus (42/42 binding-relevant
  folders, §2.3). **Why a final trusted head dominates:** every mutant
  rewrites `audit.jsonl` (I+X is 0/56 "by construction (every mutant edits
  `audit.jsonl`)", §2.2), so a head anchor detects every changed bundle
  (0/168 flips with a head anchor).
- *Worked valid-signature forgery.* The fields and signatures that differ
  between the designs are named per key set: with the audit key the bound
  design fails `artifact.signature` on the issuer-signed capability and
  the adapter-signed effect receipt plus `op.capability_bound` and
  `op.receipts_bound`; with audit+issuer the receipt signature and
  `op.receipts_bound` (§2.1). The fixture studies re-sign the capability
  with the real issuer key (L1b, L3, L4; REAL-FX) and show the same
  checks (§2.2).
- *Narrowed* (exact): the results hold for the tested mutation classes
  and canonical targets ("'Necessary' means necessary among the 12 tested
  key sets for the canonical target, not proved from the protocol"); they
  are not a general attack-success rate; on the reconciliation path "binding raises
  the requirement from A to A+I, not from A to A+I+X", and "Under the full
  verifier, the same path lowers the bound design's flag forgery from
  A+I+X to A+I (+ status) (L4)"; the statement "the strongest attacker
  needs audit+issuer+adapter" therefore holds only for operations executed
  with an EFFECT_EXECUTED entry and an adapter receipt. A disabled replay
  check is presented strictly as an ablation.
- *Deferred to GP2:* a bounded genuinely non-replayable case (unavailable
  policy input, protected human judgment or justified redaction).

**Major 2. Test whether recovery can weaken classification assurance.**

- *Supported.* Lifecycle mutations that delete or replace an execution
  receipt, convert an execution into RECONCILED, restate the outcome and
  build conflicting histories (§2.2): conflicting and mixed histories
  **9/12 detected**, the other **3/12 VERIFIED with the flag kept and the
  evidence strength stated**; downgrades are "not refused, but ...
  reported" (L1, 8/8: still flagged, `issuer_only_unresolved`,
  `flagged_unconfirmed`=1, warning, `run_complete` fail); recovery records
  that drop or invent the bound flag fail `op.requires_policy` (5/7 cases
  fail, the 2 consistent pass); replayed and confirming answers likewise
  (3/6 fail, 3 consistent pass); a wrong or edited receipt on RECONCILED
  fails `op.receipts_bound` (3/3). Keys and reported assurance per
  terminal and unresolved state: the table of §2.2 ("Keys per state").
  On gateway evidence, classification evidence is now reported per
  operation: crash **320/1,360** effects `issuer_only_reconciled` (§2.4),
  concurrency 260 (one per folder), custody 1 per run, kill suite 75; the
  kill suite shows the flag kept on every recovery path (45/45, §2.5);
  `TestLifecycleConflictingHistories` kills three previously surviving
  refusal sites (§2.9).
- *Narrowed* (exact): "So on this path binding raises the requirement from
  A to A+I, not from A to A+I+X"; "It rests on the existing rule that a
  `RECONCILED` entry need not carry an adapter receipt. Build 2 checks a
  receipt when one is attached, but still does not require one"; "The
  verifier does not date observations against the run"; "'status' needs no
  key in the prototype"; "Asserted, not sampled... They are not attack
  rates"; "`issuer_only_reconciled` is a property of these recovery paths,
  not a failure. For 320 of 1,360 effects ..., the flag and mode of the
  decision rest on the capability issuer's signature alone." The crash,
  concurrency, misuse and custody experiments contain no flagged recovery
  or flagged replay, so build 2's flag-keeping is shown there only as
  "absent and not required".
- *Deferred to GP2:* requiring an adapter receipt (or another
  adapter-signed record) before a RECONCILED commit is accepted as
  `issuer_adapter`; dating status observations against the run;
  authenticating the provider's status endpoint.

**Major 3. Validate the compromise simulation with real signatures.**

- *Supported.* Simulation vs real audit-key re-signing **44/44** (on build
  2 and on the build-1 tree, §2.2 s6); real-signature attacks on fixture
  runs with the **audit (A), issuer (A+I) and provider (A+P, one forged
  ABSENT, detected) keys** and the witness key, with the keys anchor taken
  from the genuine run before the mutation (REAL-FX, §2.2); the missing key
  sets in simulation: **A+X = A in 56/56 cells** (detected in 20/20 cells
  that needed A+I+X), A+P = A, I+X 0/56 (§2.2); the frozen oracle is
  unchanged (same SHA-256) and its disagreements are kept with named causes
  (C1, C2; 0 unexplained, §2.1); the fixture grid disagrees with the frozen
  grid in 8/224 cells, explained by the fixture (§2.2). The simulator is
  described as "a structural attack model, not cryptographic exploitation",
  and sufficient key sets as observed in simulation.
- *Narrowed* (exact): "Only the audit key has been compared with real
  re-signing (44/44)" for the 2,688-cell grid; "In these studies, adapter
  and approval keys are still never used to re-sign an attack"; "X is the
  aggregate of the three adapter keys, and only in the simulation"; for the
  grid's D: "It means all three adapter keys at once" (three adapter roles
  are not three independently protected keys in this matrix); the real-signature results
  are "Fixture evidence only".
- *Deferred to GP2:* real re-signing of A+I+X and provider-modification
  attacks on gateway runs with adapter keys; partial adapter compromise.

**Major 4. Exercise realistic persistence and delivery failures.**

- *Supported.* OS-level kill suite (§2.5): real gateway processes killed at
  7 durable transitions on three paths (ALLOW same-ID, FLAG same-ID, fresh-
  ID control) and on the human-approval path; **every acceptance measure
  0** (0/235 IDs with two effects, 0/30 REJECTED with an effect, 0/15
  `provider_not_committed` with an effect, 0/185 COMMITTED without one,
  0/225 unresolved outside the deliberate cells); provider faults:
  committed-with-lost-response, certified no-effect, UNKNOWN then APPLIED,
  delayed delivery (before and after ABSENT), lookup failure (transient
  and persistent); no UNCERTAIN operation re-dispatched; flagged path
  45/45 flag kept; power-loss surrogates (torn journal tail recovers, torn
  audit tail fails closed, reverted head, leftover temporary head); one
  journal write failure, which answers the review's question about
  consumption and the journal: the capability is consumed once and never
  used, the refusal is not recorded, and the restarted gateway runs the
  operation again with a second capability (1 effect). The in-process
  schedules are unchanged (§2.4), and flagged recovery verifies end to end
  12/12 (§2.2 s5).
- *Narrowed* (exact): "a kill is a process crash, not a power cut. The
  kernel file cache survives, so a killed process never loses a write it
  made. Power loss is only approximated by the four surrogates";
  "Directory-entry persistence and `fsync` ordering are not tested on real
  power loss"; "There is no kill inside `audit.Append` between the line
  sync and the head rename"; findings to state: a `head_reverted` state is a
  "false alarm on an untampered crash state, permanent"; "An
  operation-scope REJECTED is not durable under a journal write failure";
  "An approval does not survive a crash before it leads to a dispatch"
  (15/20 second approvals).
- *Deferred to GP2:* provider restart ("The provider runs in the parent and
  never crashes or restarts. Provider restart ... is not covered"); real
  power loss; flagged operations left unresolved under a kill (the
  "flagged but unconfirmed" count is never exercised in the kill suite;
  fixture L1 exercises it).

**Major 5. Make custody freshness and clock assumptions operational.**

- *Supported.* Freshness and run completeness are explicit verifier
  outputs (§2.7): `head_fresh` passes **only** with a live, current signed
  status (180/180 CLI, 100/100 in process; 0/1,300 and 0/620 otherwise);
  `run_complete` passes only for the clean whole run with the live witness
  (20/20), never on tampered evidence (0/1,300), never fails clean evidence
  (0/120); a withheld segment gives `run_complete` fail 40/40; every
  ANCHORED reached through a pin or saved head is qualified (200/200 CLI).
  The stale window is specified (2 minutes, inclusive) and tested at its
  boundary (accepted 4/4, refused 4/4, §2.2); statuses 135-584.5 s old are
  refused (40/40); outage behaviour: a stopped witness ends the CLI with
  exit 2, no fallback; the gateway keeps running during a witness outage
  (fail-open, one WITNESS_UNAVAILABLE entry). Registration preemption is
  never ANCHORED (2/2); substitution denies anchoring (§2.2). Gateway clock
  steps fail closed in process (§2.2).
- *Narrowed* (exact): "The provider and the witness are separate processes,
  not separate custodians"; "The gateway process could read their key
  files, including the witness key that signs the status"; "ANCHORED never
  establishes gateway origin. Only authenticated enrollment, which is not
  implemented, would close this" (a forged continuation registered first
  is ANCHORED); "A replay within 2 minutes is accepted by design"; "The
  clock results are unit-level injections. The registry and delegation
  clocks are moved; the OS clock is not. The two revival results are
  counterexamples of a known limitation, not fixes" (an expired grant
  revives after a clock rollback, in process and across a restart).
- *Deferred to GP2:* separate OS principals or hosts, restricted key
  access, authenticated enrollment and a pinned witness identity; a
  trusted-time strategy (or a delimited statement that offline detection
  does not prevent online revival of an expired grant); clock tests on
  the OS clock.

**Major 6. Resolve unchecked evidence fields and policy authority.**

- *Not addressed by a build-2 experiment.* The fields stay unchecked and
  unmutated: the engine "does not recompute the provider receipt's
  effect-row and state hashes, the request digest, or the approval-artifact
  hash lists" (§2.1). Build 2's source adds documentation that classifies
  every unchecked field as redundant, not needed or deferred
  (`docs/demo/FIELD_CHECK_MAP.md`, written against the build-1 verifier;
  updated for build 2 on 2026-10-10, when the "redundant (honest provider)"
  reason was renamed "provider accounting" because the provider is a role an
  attacker may hold); its "redundant (honest provider)" reason said "The paper therefore claims
  nothing about the provider having applied the row it reports (Lim4)".
  Related gaps found in build 2: "The verifier does not date observations
  against the run"; "The verifier never compares entry times with a
  capability's iat/exp" (§2.2).
- *Narrowed* (build 1 wording, unchanged): "The snapshot is bound to the
  policy the issuer signed, not the one the organisation intended." The
  grant is "signed by a demo-generated organisation key in the gateway
  process, so it is not authenticated human consent", and approval mode
  is "an unauthenticated local click" (build 1 §9, rows 4 and 8).
- *Deferred to GP2:* equality or reconstruction checks with valid-signature
  inconsistent-field tests for the provider request digest, effect content
  and approval lineage (or removing every claim that depends on them);
  binding the policy version to an independently enrolled organisational
  authority with tested rotation.

**Major 7. Separate regression success from general adequacy.**

- *Supported.* Regression and adequacy are reported separately (§2.9):
  142/142 with the full suite, **56/142 = 0.394** without the seven post-hoc
  tests (58/142 = 0.408 with build 1's four-test pattern; strict 53/142 =
  0.373); earlier survivors and **47/313** never-executed refusal
  conditions stay visible; 7 of 38 checks have no site killed without the
  post-hoc tests. **Held-out mutation operators**, defined and frozen
  before the run (§2.10): the full suite kills **144/358 = 0.402** of the
  held-out mutants (H1 `append` 63/164 = 0.384, H2 `boundary` 52/123 =
  0.423, H3 `equality` 29/71 = 0.408), against 142/142 for the refusal-site
  operator it was strengthened against; without the four post-hoc tests
  **127/358 = 0.355** (refusal sites 58/142 = 0.408), without the seven
  121/358 = 0.338 (supplementary); build 1's verifier and suite (`f01d1c9`,
  without the four) 111/336 = 0.330. Every survivor is classified, and the
  declared splits stand beside the headline (full suite: 66 not executed, 53
  evaluation not shown, 13 equivalent, 82 executed but undetected; H1
  ceiling 107/164 = 0.652; H2 "boundary moved by one" 13/64 = 0.203; limit
  0/9, budget 1/9, time 4/26). No test was written or changed in response
  to a held-out result. A second implementation of a protocol subset agrees
  on a frozen adversarial corpus, expected outcomes frozen before the run
  (42/42, 296/296, §2.3). Policy effectiveness (§2.8): legitimate,
  review, harmful and malformed kept distinct; the harmful set split after
  the run into what the policy is built to stop (24/24 blocked),
  policy-compliant harm (16/16 executed: split payment 12, wrong purpose
  1, confidential paraphrase or near-copy 3) and no-grant controls (4/4
  executed); label assignment and thresholds documented.
- *Narrowed* (exact): "0.394 is the honest score under the documented
  pattern. The 1.000 is not independent evidence"; five of the honest
  score's kills come from tests written after build 1's survivor list was
  public ("Whether to count more tests as post-hoc is the owner's
  choice"); the subset verifier "is not independent confirmation of the Go
  logic, and the paper must not call it an 'independent verifier'"; "The
  44 harmful requests are an authored case set, not a sample"; "What the
  fuzz properties check: crashes, errors and exact-form parsing, not
  semantic acceptance"; thresholds are "illustrative parameters of a
  fictitious organisation". The review's "unsupported-control" category has
  no separate group: the no-grant controls are the closest. Held-out
  operators (`heldout/RESULTS.md` §4): "The 0.40 is measured against defect
  classes the suite was not written for. It is not a statement about
  attacks"; "Equivalence is a hand judgement (one person, one pass, no
  second reviewer)"; "'Evaluation not shown' is not settled" (53 full-suite
  survivors); build 1 has no held-out run, so the build-1 figure is variant
  3 (build 1's verifier source and suite, run on 2026-10-10 with build 2's
  tool); the 7 matched sites that build 2 kills and build 1's suite does not
  are killed by tests added in `afe8730`, after the operators were frozen
  but before any campaign run.
- *Deferred to GP2:* a verifier written by an outside team; more purpose and
  paraphrase cases (misuse open issue 4); a separate check that settles the
  held-out "evaluation not shown" survivors (allowed by
  `HELDOUT_OPERATORS.md` 7.4, not run).

**Major 8. Supply an auditable artifact and interpretable performance
results.**

- *Supported (performance, §2.11).* Paired block-level intervals; every
  call retained, with the disk slowdowns located in time; storage
  configuration (consumer NVMe, NTFS, 4,096-byte clusters, 97.4 % full,
  write cache not determinable); allocation volume separated from resident
  memory; the 11.29 ms recording stage explained (six serialized durable
  appends, 88 % of it; `head.json` replacement 70 % of an append, log fsync
  24.8 %, CPU 4.5 %, directory fsync none on Windows); saturation at 92.5
  calls/s from 4 clients explained by the serialized appends (ceiling 98
  calls/s) and Little's law; witnessing is in no timing, and its cost is
  measured separately (+2.4 ms per call or +11.3 ms per entry);
  optimisations must keep persistence before authority. *Accounting:* every
  experiment section above names its cells, variants, verifications,
  schedules, calls, operations and repetitions. *Provenance:* commit, build
  commands, toolchain, manifest hash, binary hashes and per-experiment
  manifest checks (§0.1); seeds and resample counts in §2.11.
- *Narrowed* (exact): "The rotated order balances positions, not
  predecessors: differences of a few tenths of a millisecond ... are not
  resolved"; "Device write-cache setting: not determinable without
  administrator rights"; one machine, loopback provider in the same process.
- *Open:* the review archive has not been rebuilt from build 2 in these
  inputs (the build-1 archive exists; build 1 §10 release row); the kill
  suite's journal-failure evidence cannot go into it as is (§0.5). See §4.2.

### 3.3 Priority 1 (essential revisions)

| item | status | evidence and limitation |
|---|---|---|
| Reframe the contribution | evidence ready (text is outside this file) | 0/336 full, 12/336 replay off, 8/336 snapshot binding off; head anchor 0/168 flips (§2.1); qualify with the reconciliation path (§2.2 L3/L4) |
| Cover lifecycle assurance | supported, narrowed | state-by-state keys and reporting table (§2.2); conflicting histories 9/12 detected, 3/12 VERIFIED and reported; execution-to-reconciliation substitution accepted with A+I + status (6/6, 8/8) and reported `issuer_only_reconciled` |
| Validate attack construction | partly supported | real A, A+I, A+P re-signing on fixtures; 44/44; frozen oracle unchanged, disagreements kept (§2.1, §2.2). "adapter and approval keys are still never used to re-sign an attack" |
| Verify effect and approval bindings | **deferred to GP2** | no signed inconsistent-field attacks for request digests, effect content or approval lineage; fields classified in `docs/demo/FIELD_CHECK_MAP.md` |
| Run a focused crash suite | supported, narrowed | kill suite: all acceptance measures 0, ambiguous provider outcomes, FLAG and approval paths; no duplicate effect and no false no-effect classification (0/15 `provider_not_committed` with an effect) (§2.5). Not power loss, not provider restart |
| Release reproducible evidence | **open** | build-2 manifest and per-experiment commands exist; the archive has not been rebuilt and re-checked on build 2 (§4.2) |

### 3.4 Priority 2 (strong supporting revisions)

| item | status | evidence and limitation |
|---|---|---|
| A realistic reason for partial replay | deferred to GP2; the replay-disabled condition is presented strictly as an ablation | §2.1 |
| A small independent-custody deployment | deferred to GP2 | §2.7 caveats: one machine, one user account |
| Witness enrollment, stale and unavailable status, continued-run rollback, clock jumps, expiry boundaries; freshness as a consumer-visible dimension | supported, with counterexamples | `head_fresh` / `run_complete` (§2.7); registration preemption and substitution, the forged-continuation counterexample, clock steps, 2-minute boundary, expired-grant revival (§2.2); continued-run rollback R7 detected by the segment's witness head 20/20 (§2.7) |
| Held-out mutations and an independent verifier for a protocol subset, expected outcomes frozen | supported, narrowed: held-out operators frozen before the run, full suite 144/358 = 0.402, without the four post-hoc tests 127/358 = 0.355, build 1's verifier and suite 111/336 = 0.330, every survivor classified; subset verifier supported (same authors, not independent) | §2.10, §2.3 |
| Workload reporting | supported | §2.8 regrouping; paraphrase cases without an information-flow claim ("MSG-CONFIDENTIAL-TEXT detects verbatim copies only; it is not information-flow control") |
| Block-level performance uncertainty, storage; serialization, signing, fsync, directory fsync and witness update separately; saturation and allocation | supported | §2.11 |

### 3.5 Priority 3 (optional extensions)

| item | status |
|---|---|
| Integrate one real agent framework | deferred to GP2 |
| Cross-run business deduplication with intent identifiers | deferred to GP2. The per-operation guarantee is unchanged and duplicates under fresh IDs remain by design (crash 400/1,120; kill suite 25/35 fresh-ID cells) |
| Privacy-preserving replay, multi-tenant storage, key rotation, higher throughput | deferred to GP2 (the throughput ceiling and what an optimisation may not change are measured in §2.11) |

### 3.6 Minor comments

| minor comment | status | evidence |
|---|---|---|
| Update Table I for CATP; keep "unknown" markers | text only (paper) | none in this file |
| Glossary; keep signing roles distinct from custodians | text only | `docs/demo/GLOSSARY.md` in the build-2 source; custody: "separate processes, not separate custodians" (§2.7) |
| Deprecate or qualify the legacy VERIFIED value | supported in the verifier output | `head_fresh`, `run_complete`, classification evidence and Missing kinds now qualify every non-failing result: 200/200 CLI ANCHORED verdicts without the live witness are marked not fresh (§2.7); the VERIFIED value itself still exists |
| Keep REJECTED scoped to the current call; one example each of an earlier same-ID commit and of fresh-ID repeated intent | supported | the kill suite's journal-failure cell: 10 REJECTED answers followed by a commit of the same operation ID ("A REJECTED answer describes the moment it was given", §2.5); fresh-ID duplicates (crash 400/1,120, kill suite 25/35); REJECTED/operation_id_conflict with scope `call` (concurrency 6,820) |
| A compact state-transition figure and one evidence-lineage example | text only | journal transition sequences in §2.6 can feed the figure |
| Qualify security arguments; verify references | text only | |

## 4. Open issues

### 4.1 Where the files disagree (found while collating)

None of these changes a number in this file.

1. **Description of the simulation-validation test.** `compromise/RESULTS.md`
   §1 says `TestSimulationAgreesWithRealAuditKeyResigning` "covers 11
   audit-log edits x 4 anchor conditions", and `fixture-studies/RESULTS.md`
   §7 says "11 edits x 4 anchor conditions". Build 1 (`RESULTS_REVISION.md`
   §1.1 and §10, first row) describes the same test as **10 audit-key edits
   (9 of the log, one of the run record, re-signed through RUN_STARTED) and
   an unedited control**, and lists "11 audit-log edits" as a wording to
   correct. The fixture-studies file itself notes that "Only 'nothing
   changed' reaches ANCHORED", which is the unedited control. The cell
   count (44/44) agrees in all three files; only the wording differs. Use
   build 1's description.
2. **Review comment numbers in two files.** `crash/RESULTS.md` says it
   "answers review major comments 2 and 3": those are the numbers of the
   **first** review (failure boundary, single-use scope). In the second
   review the crash experiment belongs to major comment 4 (and, for the
   classification evidence, major comment 2). `killsuite/RESULTS.md` cites
   "major comments 46-47 and the request at line 82" and "review comment
   47": these are line numbers of the review text, i.e. major comment 4 and
   the priority-1 item "Run a focused crash suite".
3. **Abbreviated verifier hash.** `crash/RESULTS.md` abbreviates
   `agentgate-verify` as `83d0786a...f006`; the hash ends in `...eed0`
   (`compromise/` writes `...ed0`, `killsuite/` `...eed0`). Same binary
   (full hash in §0.1); a cosmetic inconsistency.
4. **Build-1 intervals.** `baseline/RESULTS.md` §9 prints build 1's paired
   medians with **block-level** intervals (mediation [3.25, 3.37], total
   [14.64, 14.75], journal [3.15, 3.29], flagging [−0.36, −0.18]), while
   build 1's `RESULTS_REVISION.md` §8 printed **trial-level** intervals for
   the same medians ([3.26, 3.36], [14.64, 14.77], [3.12, 3.29], [−0.34,
   −0.21]). Both are correct for their method; cite the method with the
   interval.
5. **Little's law example in the baseline headline.** The headline computes
   "16 / 92.6 s = 173 ms (observed mean 170 ms)" from the five-run median
   throughput; §4 of the same file computes R2's own cell, "16 / 93.13 =
   171.8 ms against an observed mean of 169.6 ms". Consistent in substance;
   quote §4's numbers for R2.
6. **"Audit+issuer+adapter" vs the reconciliation path.** `compromise/` (and
   build 1) state that flag edits of an executed operation passed only with
   audit+issuer+adapter against the full verifier (wording corrected
   2026-10-10: the smallest tested set, not a proof). `fixture-studies/` L4
   shows VERIFIED 8/8 with A+I + a status observation when every execution
   is converted to RECONCILED-committed. Not a data conflict (the grid's
   targets are first-time executions with an adapter receipt), but the
   compromise headline must carry that condition (§3.2, major 1).
7. **Receipt on RECONCILED, exercised or not.** `killsuite/` reports 0/105
   committed RECONCILED entries with an adapter receipt and `custody/` says
   the path is not exercised there; `crash/` has 240 RECONCILED entries with
   an adapter receipt (no restart), all checked under `op.receipts_bound`
   with no failure. Different experiments, not a conflict: the genuine path
   is exercised by crash and by the fixture tests only.
8. **Registration attacks "not measured".** `custody/` lists registration
   preemption and substitution as not measured; `fixture-studies/` §4
   measures them on fixtures with an in-process witness service. Not a
   conflict; cite the fixture study for them.
9. **Documentation behind the data.** `VERIFIER_CHECKS.md` §6 still shows
   build 1's robustness numbers (139 sites, 0.367, 44/299, 9 checks) and
   line numbers, and its attribution of `checkReconciledFlag` omits
   `TestUnboundFlagsTextsNameTheLogNotTheCapability` (`robustness/` §7.1).
   The `custody.md` header ("every cell anchored by a pin or a saved head
   lists the freshness gap") holds only when the pin or head matches the log
   end (`custody/` §9). `SUBSET_VERIFIER.md`'s "Not in the subset" list does
   not mention the build-2 additions (`subset-corpus/`). The tool's own
   `misuse.md` line "delegation grant (DEL-*): 14" counts the 3 shared
   blocks as DEL-* (11 DEL-only + 3 both).
10. **Name of the review in `heldout/`.** `heldout/RESULTS.md` says it
    answers "review 2, major comment 7" (the supervisor's second review),
    where the other experiment files call the same review "review 3". Same
    comment (major comment 7, priority 2); naming only.
11. **Which post-hoc pattern goes with which score.** The held-out headline
    compares its variant 2 (the four-test pattern that
    `HELDOUT_OPERATORS.md` freezes) with the refusal-site score 58/142 =
    0.408, whereas `robustness/` and this file call 56/142 = 0.394 (the
    seven-test pattern) the honest score. The held-out run with the
    seven-test pattern is the supplementary variant 2b (121/358 = 0.338).
    Not a conflict; name the pattern with every quoted score (§2.10).
12. **Provider process in the kill suite.** `killsuite/RESULTS.md` §1 says
    the parent "starts a fresh provider in its own process", while its §12
    and `build-manifest.txt` say the provider runs inside the parent process
    and `agentgate-provider` is not used. "Its own" means the parent's; §2.5
    above follows the build manifest.

### 4.2 By owner

Closed in build 2: the in-process live anchor applies the 2-minute rule; a
saved witness head lists the withheld-segment gap in `missing`; freshness
and run completeness are explicit outputs; recovery records and replayed
answers state the bound flag and the verifier checks it; an OS-level crash
suite exists. The rows below remain.

| owner | issue | source |
|---|---|---|
| verifier / docs | `VERIFIER_CHECKS.md` §6: build-2 numbers (142 sites, 0.394 with the seven-test pattern, 47/313, 7 checks), build-2 line numbers, the missing kill attribution; `refusalmutation/main.go` still shows the four-test pattern; decide which further tests count as post-hoc (`TestUnboundFlagsTextsNameTheLogNotTheCapability`, `TestLifecycleConflictingHistories`, `TestTimeStepsInsideASegment`) and name the pattern behind any quoted score; two sites pass a variable check ID (`provider.go:60`, `verify.go:783`) | `robustness/` §7 |
| verifier | A RECONCILED commit need not carry an adapter receipt, so a reconciliation-only execution is bound by the issuer alone (A+I + status suffices, L3/L4); status observations are not dated against the run; entry times are not compared with a capability's iat/exp; a restart segment may start before the previous one ends; the witness clock may lag the head time (all VERIFIED) | `fixture-studies/` §2.2, §5.2 |
| verifier (reporting) | the `head_fresh` reason for a **mismatching** saved head still says the head is anchored by it; the `head_reverted` finding ("entries ... were added without the recorder") reads like tampering on an untampered crash state; segment 1 alone after a post-commit kill says "The provider performed an effect with no authorization trail" although the capability is there; `custody.md` header wording | `custody/` §9, `killsuite/` §11 |
| gateway | the `journal_unavailable` refusal embeds the absolute journal path in a signed entry (cannot be redacted; such evidence cannot go into the anonymous archive); an operation-scope REJECTED is not durable under a journal write failure; an approval does not survive a crash before it leads to a dispatch (15/20); a power loss can leave `head_reverted` (no directory flush on Windows; `os.Rename` not write-through), a permanent `head.matches` failure; a torn audit tail blocks restart until repaired by hand | `killsuite/` §6, §7, §11 |
| gateway | expired-grant revival after a clock rollback (in process: a denied call never reads the registry clock and the delegation window has no floor; across a restart the restore ignores the journaled capability expiry); an operation journaled before build 2 restores unflagged and its RECONCILED entry would fail `op.requires_policy` (inferred) | `fixture-studies/` §5.1, §9 |
| witness | registration and continuation registration unauthenticated (a forged continuation registered first is ANCHORED); the freshness rule assumes agreeing clocks and accepts a replay within 2 minutes; `Client.Registration` reads the status without checking its signature (`internal/headwitness` unchanged) | `custody/` §9.4, `fixture-studies/` §4 |
| eval-engine | `rewriteDecision` does not rewrite call-scope replayed COMMITTED answers (new engine gap); C1 (multi-recipient change-rules target), C2 (delete the never-executed approval requests), swap-decisions, unchecked fields not recomputed | `compromise/` §5 |
| eval-engine | crash harness: record the number of segments verified, the agent's `call_id` and `classification_evidence` in `crash.json`; coverage still missing there: provider faults, a flagged payment across fault points, a tight-budget fresh-ID case, a stall past the 30 s lease, restart segments registered with a witness (some covered by the kill suite and the fixture tests) | `crash/` §6 |
| eval-engine | concurrency: `assessRace` counts a lease-expired UNCERTAIN as a violation and mixes safety with completion; call start times not recorded; an expiry needs a fault hook | `concurrency/` §6 |
| eval-engine | custody: no live-journal variant of the segment; segment pins read from the folder; `started_at` taken after the self-test | `custody/` §9.5 |
| eval-engine | misuse: `tallyMisuse` "both" category; `misuse.go:325` comment; the "one word in six replaced" case tests deletion; new cases (glued punctuation, zero-width, homoglyphs, hyphenation, internal paraphrase, purpose) | `misuse/` §9 |
| gateway-policy | `normalizedWords` removes punctuation instead of replacing it with a space (needs matching snapshot, replay and oracle changes) | `misuse/` §9.5 |
| docs | `SUBSET_VERIFIER.md` "Not in the subset" list; the build-1 collation, the paper and the response still cite build-1 numbers where build 2 adds fields (crash: "nothing listed as missing" must become "only the freshness gap (and, for 40 + 120 folders, the issuer-only classification gap)"; custody: the derived-dimension results and build-2 hashes) | `subset-corpus/`, `crash/` §6, `custody/` §9.6 |
| release | the review archive has not been rebuilt and re-checked on build 2 in these inputs; the kill suite's journal-failure folders must stay out of it; build 1's robustness tarballs record the Windows user name as file owner (`revision/robustness/raw/`) | `killsuite/` §11, `robustness/` §7.6 |
| release | the code-size count of the trusted base (build 1: 85,722 non-test code lines) has not been recounted on build 2 in these inputs | build 1 §0 |
| robustness | held-out operators (§2.10): 82 executed-but-undetected full-suite survivors, typically a signed field that tests only change together with another field; no test sits exactly on a time-window edge, budget, count, size or nesting limit (H2 limit 0/9, budget 1/9, time 4/26); the 53 "evaluation not shown" survivors are unsettled; equivalence judged by one person in one pass; the jobcap version-1 run left a 4 GB zombie `agentgate-verify.test.exe` that probably needs a reboot; the capped runner's header still describes jobcap version 1 | `heldout/` §2, §4, §5 |

### 4.3 Deferred to GP2

A genuinely non-replayable workload; real re-signing with adapter and
approval keys and partial adapter compromise; checks and valid-signature
inconsistent-field tests for provider request digests, effect content and
approval lineage; organisational policy authority with rotation; a
separate-principal or separate-host custody deployment with authenticated
enrollment and a pinned witness identity; a trusted-time strategy; real
power loss and provider restart; a verifier written by an outside team; a
real agent framework; cross-run business deduplication; group commit and
other throughput work that keeps persistence before authority.

## 5. Files

| path | contents |
|---|---|
| `compromise/` | `RESULTS.md`; the runner's `results.{json,csv}`, `strongest.csv`, `controls.csv`, `compromise.md`; `analyze_compromise.py` outputs; `base_controls.*`; `flips_by_anchor.csv`, `breakdown.json`, `compare_build1.json`, `baserun_structure.txt`, `validation_sim_vs_real.txt`; `build-manifest.txt` |
| `fixture-studies/` | `RESULTS.md`; `run_studies.sh`, `sanitize_logs.py`, `analyze_fixture_studies.py`; `tests.csv`, `lifecycle.csv`, `extra_keysets_*`, `fixture_vs_frozen_grid.csv`, `simulation_agreement.csv`, `summary.json`; `logs/`; `probe/`; `build-manifest.txt` |
| `subset-corpus/` | `RESULTS.md`; `manifest.json` (SHA-256 `a9f9d178...`), `manifest.sha256`, `manifest-sha256-recorded.txt`, `subset-result.json`, `summary.json`, `rows.csv`, `flip_cells.csv`, `mutation_targets.csv`, `crosscheck-frozen-verify.json`, `ablations.json`, `go-test-v.txt`, `run-log.txt`, `samples/`, scripts; `build-manifest.txt` |
| `crash/` | `RESULTS.md`; `crash.{json,csv,md}`, `run.log`, cells, folders, `reanalysis.*`, `call_ids.txt`, `recovery_records.txt`, `cli_crosscheck.*`, `continuity_probes.csv`, `analysis_console.txt`, scripts; `deny/`; `build-manifest.txt` |
| `killsuite/` | `RESULTS.md`; `results.{json,csv}`, `summary.md`, `run.log`, `analysis.*`, `recount.*`, `reverify.*`, scripts, `samples/` (two cells); `build-manifest.txt` |
| `concurrency/` | `RESULTS.md`; the seven runs; `analysis/` (`analyze.py`, `verifier_fields.*`, `replay_scope.*`, `unit-tests.txt`, CPU samples); `build-manifest.txt` |
| `custody/` | `RESULTS.md`; `custody.{json,csv,md}`, `witness_probe.json`, `cli_crosscheck.csv`, `status_probe.*`, `repeats*`, `matrix_stability.csv`, `rollback_by_anchor.csv`, `dimensions_by_cell.csv`, `tamper_lab.csv`, `evidence_facts.*`, `compare_build1.json`, `process_observation/`, `scripts/`; `build-manifest.txt` |
| `misuse/` | `RESULTS.md`; `misuse.{json,csv,md}`, `deny/`, `misuse_table.csv`, `misuse_analysis.json`, `cli_crosscheck.csv`, `repeat_stability.csv`, `misuse_by_category.*`, `misuse_category_map.csv`, `cli_kinds.csv`, `build2_comparison.json`, `audit_diff*`; `build-manifest.txt` |
| `robustness/` | `RESULTS.md`; fuzz, coverage, refusal-condition and kill-score data, `kill_attribution_*.json`, `comparison_with_build1.json`, `run_manifest.json`, `raw/`, `scripts/`; `build-manifest.txt` |
| `heldout/` | `RESULTS.md`; `heldout_summary.{json,csv}`, `heldout_mutants.csv` (1,410 rows), `heldout_survivors.csv`, `equivalence.csv` (106 rows), `ceilings.json`, `site_diff_f01d1c9_to_build2.json`, `build1_vs_build2.json`, `validation_comparison.json`, `memory_incident.json`, `test_names.json`, `run_manifest.json`; `raw/` (every tool report, site lists, logs, coverage profiles, snapshot and gate records); `scripts/`; `build-manifest.txt` |
| `baseline/` | `RESULTS.md`; R2 outputs and `load/`, `repeats/R1`, `R3`, `R4`, `R5`, `message/` (M1), `analysis.json`, `comparison-build1.csv`, `slow-calls.json`, `stagecost/`, `cost/`, `session-logs/`, `tools/`, `charts/`, `source-manifest.txt` (copy of the build-2 manifest, repository path replaced); `build-manifest.txt` |

The evidence folders behind these runs stay outside the repository and are
regenerated by the commands in each `RESULTS.md`. The frozen binaries and
`MANIFEST.txt` stay in the frozen build folder; `MANIFEST.txt` is identified
by its SHA-256 (§0.1).
