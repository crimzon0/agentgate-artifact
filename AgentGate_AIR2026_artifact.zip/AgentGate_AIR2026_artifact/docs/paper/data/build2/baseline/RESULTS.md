# Baselines, load, per-stage cost and witness push on build 2 (R6.8)

Session 2026-10-10 04:22:32-04:45:22 UTC on **frozen build 2** (commit
`86643d7`, `agentgate-eval` SHA-256 `485e4ce0...5304fdca`, see
`build-manifest.txt`), after every other build-2 experiment had finished. This
is the only build-2 experiment whose times are results. It answers review 3,
item 8: paired block-level uncertainty, retained tails, storage configuration,
allocation versus resident memory, the 11.4 ms recording stage, saturation
near 94 calls/s, rising latency under concurrency, whether witnessing is in any
timing, and serialization / signing / fsync / directory fsync / witness update
measured separately. Build 1 (2026-10-08) is
`docs/paper/data/revision/baseline/`; its method is repeated exactly.

**Headline.** Six runs (five financial R1-R5, one message M1), the same sizes
as build 1: **0 of 62,500 measured calls and 0 of 4,100 warm-up calls failed;
230/230 evidence folders ANCHORED with no failing check.** Per call (primary
run R2, paired medians with block-level 95 % intervals): mediation **3.18 ms
[3.13, 3.25]**, signed durable recording **11.29 ms [11.19, 11.43]**, total
**14.46 ms [14.39, 14.54]**. Full recording levels off at **92.5 calls/s**
from 4 clients (1.1 cores busy); by Little's law its latency at 16 clients is
16 / 92.6 s = 173 ms (observed mean 170 ms). One durable append costs 1.70 ms
on average, 70 % of it replacing `head.json` (temporary file, its fsync,
rename), 25 % the fsync of `audit.jsonl`, 4.5 % encoding, hashing and Ed25519
signing; six appends are about 88 % of the 11.29 ms. A witness push would add
about 2.4 ms per call (one push per call) or 11.3 ms (one per entry); **no
reported latency includes one.** Against build 1: recording, total cost of
everything, allocation, memory and evidence unchanged; mediation −0.14 ms,
journal +0.23 ms, full saturation −2 %; none attributable to the build-2 code
(section 9).

## 1. What was run

Everything from the repository root; `<repo>`, `<scratch>`, `<singlebuild2>`
stand for the local paths. Details, hashes and the timeline are in
`build-manifest.txt`.

```bash
# before and after: py <singlebuild2>/check_manifest.py   -> "checked 1868 files, 0 differ" (04:21:56Z and 04:45:45Z)
# test binaries (the stage and witness measurements are test-only), compiled before the idle check:
go test -c -o <scratch>/build2-work/baseline/testbin/audit.test.exe ./internal/audit/          # 31251d66...47a63bd
go test -c -o <scratch>/build2-work/baseline/testbin/headwitness.test.exe ./internal/headwitness/  # 4e4ec853...5209cb9
# the whole session, one step after another:
EVAL=<singlebuild2>/bin/agentgate-eval.exe TESTBIN=<scratch>/build2-work/baseline/testbin REPO=<repo> HOST_LABEL=review-host \
  bash docs/paper/data/build2/baseline/tools/run_session.sh <scratch>/build2-work/baseline/session
#   1. tools/drive_runs.sh (build 1, unchanged) -> tools/run_baseline.sh (unchanged; typeperf + process snapshots):
#        R1..R5: agentgate-eval -host-label review-host baseline -out <session>/runs/Rn -work <session>/work/Rn
#        M1:     agentgate-eval -host-label review-host baseline -out <session>/runs/M1 -work <session>/work/M1 \
#                  -workload message -configs direct,policy-only,full,full+journal
#   2. agentgate-eval -host-label review-host cost -n 2000 -batches 5 -repeat 20 -out <session>/cost -work <session>/cost-work
#   3. tools/run_stagecost.sh: in internal/audit, three times (run1..run3) and once on R3's replayed full evidence (run-corpus):
#        audit.test.exe -test.count=1 -test.v -test.run '^TestStageCost$' -stagecost=10000 -stagecost.warmup=200 \
#          -stagecost.work=<dir> -stagecost.out=<run> [-stagecost.corpus=<session>/work/R3/baseline-c16-full/run]
#      in internal/headwitness, three times (run1..run3):
#        headwitness.test.exe -test.count=1 -test.v -test.run '^TestWitnessPushCost$' -witnesspush=2000 -witnesspush.warmup=50 -witnesspush.out=<run>
#      audit.test.exe -test.run '^$' -test.bench AppendStageCPU -test.benchmem
# analysis:
py docs/paper/data/build2/baseline/analyze_baseline.py   # build 1's script; seed 20261007, 10,000 resamples
py docs/paper/data/build2/baseline/compare_build1.py     # comparison-build1.csv
py docs/paper/data/build2/baseline/slow_calls.py         # slow-calls.json
py docs/paper/data/build2/baseline/stage_summary.py      # stagecost/summary.csv
```

Method (unchanged from build 1): one JSON-RPC transport over loopback and the
same simulated provider (own listener and Ed25519 key, same process, a fresh
TCP connection per provider request) for every configuration: **direct**
(normalizer, `adapters.Prepare`, adapter transport and receipt check; no
policy, grant, capability, receipt, journal or audit; a lower bound, not a
secure alternative), **policy-only** (gateway with policy, grant, capability
and signed receipts; no audit, no journal), **full** (plus the signed
hash-chained audit log, fsync per entry, `head.json` replaced through a synced
temporary file), **full+journal** (plus the fsynced operation journal),
**full-flagged** (full with an AED 6,000.00 payment that FIN-APPROVAL-LIMIT
flags). Sequential: 500 paired trials in 10 blocks of 50, 10 warm-up calls per
configuration, order rotated by one position per trial. Concurrent:
closed-loop clients 1, 2, 4, 8, 16, 400 calls per cell, each configuration
alone. Every call is kept (no outlier removal). Intervals: bootstrap over
trials and, as the headline here, **over the 10 blocks** (cluster bootstrap;
each block has fresh providers, gateways and logs).

Idle machine: before the session `tasklist` showed no agentgate, go, compile,
link, go-build, python, py, typeperf or test process (04:22:26Z), and a
process logger (new, `tools/watch_procs.ps1`, every 5 s) saw only the
session's own binaries for the whole session. Desktop load in the 5 s
snapshots around each run: 0.36-0.50 logical cores without the shells and the
logger, almost all coding-agent processes (build 1: 0.19-0.36). A **first
attempt (04:18:37-04:21:39Z) was discarded**: a stray `py` process from the
operator's own shell used 1.14 cores during R1; the attempt was stopped and
the whole session restarted (kept in the scratchpad, not analysed). **R2 is
primary** by build 1's rule (lowest background load, 0.369 cores; others
0.41-0.46). Every key number also gives the R1-R5 range.

## 2. Paired added latency per call (R2 medians, block-level 95 % CI; ms)

| difference | median | block 95 % CI | trial 95 % CI | range R1-R5 | mean [block CI] |
|---|---|---|---|---|---|
| mediation (policy-only − direct) | **3.18** | [3.13, 3.25] | [3.14, 3.23] | 3.10-3.19 | 3.19 [3.15, 3.24] |
| signed durable recording (full − policy-only) | **11.29** | [11.19, 11.43] | [11.22, 11.37] | 11.29-11.57 | 12.98 [11.40, 16.05] |
| total (full − direct) | **14.46** | [14.39, 14.54] | [14.41, 14.50] | 14.46-14.68 | 16.18 [14.62, 19.24] |
| operation journal (full+journal − full) | 3.43 | [3.23, 3.57] | [3.25, 3.56] | 3.27-3.47 | 3.96 [3.39, 4.93] |
| flagging (full-flagged − full) | −0.07 | [−0.13, 0.01] | [−0.15, −0.00] | −0.19 to −0.07 | 0.57 [−0.14, 1.84] |
| everything (full+journal − direct) | 17.87 | [17.74, 18.03] | [17.79, 17.95] | 17.73-18.18 | 20.14 [18.07, 24.14] |

**Why the paired medians do not add up.** Each row is the median of its own
per-trial differences. For every trial, total = mediation + recording exactly,
so the **means** add (3.19 + 12.98 = 16.18), but the median of a sum is not the
sum of the medians: 3.18 + 11.29 = 14.47 is only close to 14.46 because the
per-trial distributions are narrow and nearly symmetric around their centres.
Means are given for that reason, but the medians are the headline because the
means carry the disk-slowdown tail of R2's block 10 (section 6): the
recording mean is 12.98 ms with a block interval of [11.40, 16.05], while R1,
R3 and R5 have means of 11.58-11.65. Never add or subtract the medians of
different rows.

**Flagging.** Flagged calls were again faster in all five runs (−0.07 to
−0.19 ms; four of five block intervals exclude zero; build 1: −0.15 to
−0.32). Flagging writes about 310 more bytes per call in the same six entries,
so a real saving is implausible. As in build 1 the rotation balances positions
but not predecessors (full-flagged follows full+journal in 400 of 500 trials),
so carry-over effects of a few tenths of a millisecond cannot be separated.
Say "flagging added no measurable latency (within about 0.3 ms, 2 % of a full
call, either way)".

Message workload (M1): mediation 3.36 [3.30, 3.40], recording 11.39
[11.32, 11.46], total 14.72 [14.62, 14.80], journal 3.43 [3.38, 3.47] (block
intervals).

## 3. Sequential latency per configuration (R2, 500 calls each, nothing removed; ms)

| config | p50 | p95 | p99 | max | range R1-R5: p50 / p99 / max |
|---|---|---|---|---|---|
| direct | 1.24 | 1.57 | 1.78 | 1.91 | 1.23-1.25 / 1.78-1.99 / 1.91-2.24 |
| policy-only | 4.44 | 5.06 | 5.35 | 5.86 | 4.32-4.44 / 5.35-5.92 / 5.86-6.28 |
| full | 15.72 | 20.09 | **68.42** | 68.80 | 15.72-15.96 / 20.33-68.42 / 21.02-73.51 |
| full+journal | 19.14 | 23.84 | **72.12** | 211.89 | 19.00-19.45 / 24.00-72.12 / 27.58-211.89 |
| full-flagged | 15.60 | 20.80 | **68.47** | 219.16 | 15.51-15.84 / 20.00-68.47 / 21.16-219.16 |

The primary run's durable tails come from one disk slowdown in its last block
(section 6). In the three runs without a sequential slowdown (R1, R3, R5):
full p99 20.33-20.54 ms, full+journal 24.00-24.73, full-flagged 20.00-20.71
(build 1's clean runs: 20.31-21.60 for full). M1: direct 1.29 / 1.68 / 1.83 /
2.04, policy-only 4.68 / 5.18 / 5.52 / 5.86, full 16.05 / 18.94 / 20.17 /
23.79, full+journal 19.45 / 23.12 / 24.71 / 45.47.

## 4. Throughput, saturation and Little's law (calls/s, median of R1-R5 [min-max])

| clients | direct | policy-only | full | full+journal |
|---|---|---|---|---|
| 1 | 957 | 229 | 62.7 [62.5-62.9] | 51.7 |
| 2 | 1,664 | 374 | 89.3 [88.8-89.8] | 79.0 |
| 4 | 2,310 | 569 | 92.6 [91.4-92.7] | 88.0 |
| 8 | 2,839 | 674 | 92.2 [**41.6**-92.3] | 88.3 [**32.4**-89.0] |
| 16 | 3,006 | 706 | 92.6 [92.1-93.3] | 87.7 [86.3-88.5] |

Other cells vary by at most 3.6 % between runs, direct by up to 6 %. The two
bold minima are R3's disk slowdown (section 6).

- **Saturation point: 4 clients.** Full recording levels off at 92.2-92.6
  calls/s (pooled median of the 15 cells at 4-16 clients: 92.5; at 2 clients
  89.3, 97 % of it) with only 1.1 cores busy (0.98-1.21). full+journal levels
  off at 87.7-88.3. policy-only is CPU-bound (5.0 cores busy at 16 clients,
  4.4-5.7); direct reaches 6.0 cores.
- **Why it saturates.** Every gateway writes one audit log; its appends are
  serialized by one mutex, each append fsyncs `audit.jsonl` and replaces
  `head.json` through a synced temporary file, and there is no group commit.
  A full call writes six entries. The measured mean append (1.70 ms, section
  5) gives 6 x 1.70 = 10.2 ms of serialized disk work per call, a ceiling of
  1e6 / (6 x 1,700 us) = 98 calls/s. The observed 92.5 calls/s means 10.8 ms
  of serialized time per call, so the standalone appends explain about 94 % of
  it; the remaining ~0.6 ms per call (appends slowed by the concurrent CPU and
  garbage-collection work of the other clients, or work done while holding
  the log) is not measured here.
- **Little's law** (L = X x W, means, closed loop with N clients): the mean
  latency must be N / X. Full at 16 clients in R2: 16 / 93.13 = 171.8 ms
  against an observed mean of 169.6 ms (p50 171.1); in every full and
  full+journal cell of every run (M1 included) N / X and the observed mean agree within
  1.5 %, slowed cells included. Past saturation each added client only adds
  one more call to the queue at the log: full's median latency is 15.6 ms at
  1 client, 22.1 at 2, 42.4 at 4, 86.3 at 8 and 172.1 at 16 clients, about
  N x 10.8 ms.
- **Latency under load** (ms, median of the five runs, p50 / p95 / p99 /
  max): 1 client: direct 0.95 / 1.30 / 1.41 / 1.51, policy-only 4.31 / 4.82 /
  5.17 / 5.59, full 15.58 / 18.46 / 20.46 / 22.62, full+journal 18.91 /
  22.16 / 23.51 / 24.96; 16 clients: direct 5.19 / 6.06 / 7.82 / 9.26,
  policy-only 21.96 / 27.84 / 37.14 / 39.49, full 172.14 / 180.71 / 185.86 /
  219.78, full+journal 181.80 / 192.11 / 195.84 / 232.79. Every cell of every
  run is in `analysis.json` and the `baseline-concurrent-summary.csv` files.
- **CPU per call** (1 client, whole process including kernel time, median of
  the five runs [min-max]): direct 1.80 [1.41-2.07], policy-only 6.02
  [5.27-6.25], full 11.25 [9.92-12.81], full+journal 12.77 [11.72-13.52] ms.
  `GetProcessTimes` advances in 15.6 ms ticks, so single cells vary this much.
- Message workload (M1): direct 909 → 3,038 calls/s, policy-only 218 → 690,
  full 61.9 at 1, 88.8 at 2, 91.9 at 8 clients (50.4 at 4 and 38.7 at 16:
  disk slowdowns), full+journal 51.0 → 87.5-88.5 (32.4 at 16: slowdown).

## 5. Per-stage cost of a durable append and its relation to the 11.29 ms

`TestStageCost` (method: build 1's `STAGE_COST.md`) splits every
`audit.Append` into its stages, timed with QueryPerformanceCounter, paired
entry by entry with an uninstrumented `Append` on a second fresh log on the
same volume; 200 warm-up and 10,000 timed appends per path, synthetic
six-entry financial call (mean line 2,133 bytes). Three runs in a row:
uninstrumented appends over 10 ms: run1 2, **run2 1**, run3 3 of 10,000, so
**run2 is quoted** (the rule: fewest appends over 10 ms). `Append` medians of
the three runs: 1,641.0-1,653.9 us (means 1,699.7-1,713.6). The disk was
steady during all stage runs (about 3,050 writes/s, 0.037 ms each).

| group (stages) | median us | p99 us | mean us | share of the mean |
|---|---|---|---|---|
| encode + hash (encode entry, decode copy, SHA-256, line, bookkeeping, head JSON, head digest) | 35.9 | 84.9 | 38.7 | 2.3 % |
| Ed25519 signing (entry, head) | 35.7 | 72.6 | 38.4 | 2.2 % |
| log line write (O_APPEND) | 8.3 | 60.3 | 11.4 | 0.7 % |
| **log fsync** (`audit.jsonl`, FlushFileBuffers) | 396.9 | 738.9 | 424.1 | **24.8 %** |
| temp head write (create, write, close) | 192.0 | 284.9 | 199.9 | 11.7 % |
| **head fsync** (temporary `head.json`) | 706.7 | 1,313.2 | 747.8 | **43.7 %** |
| head rename (MoveFileEx, replace) | 236.1 | 381.1 | 249.0 | 14.6 % |
| directory fsync | 0.1 | 0.2 | 0.1 | 0.0 % (none on Windows) |
| staged total | 1,649.3 | 2,613.1 | 1,709.3 | 100 % |
| `Append`, uninstrumented | 1,645.7 | 2,583.0 | 1,699.7 | |

Shares are group mean / staged-total mean (means add up, medians do not).

- **Where the time goes.** The two fsyncs are 68.6 % of an append; the whole
  `head.json` replacement (temporary file, its fsync, rename) is 70.0 %
  (about 1.20 of 1.71 ms), more than the log fsync (24.8 %). CPU work
  (encoding, hashing, signing) is 4.5 %. **Directory fsync: none on Windows**
  (`syncDir` returns at once; the stage times only that call); whether the
  rename is durable when it returns rests on NTFS metadata logging and is not
  tested here (crash behaviour: `../crash/`). On NTFS a flush can also pay for
  earlier metadata changes (such as the previous rename), so a stage's time is
  where the append waits, not necessarily what it caused.
- **Relation to the recorded-minus-mediated median.** The median of the sums
  of six consecutive appends (one call's worth) is **9.95 ms** (run1-run3:
  9.91-9.99), **88 %** of the build-2 recording median of 11.29 ms (the test
  binary prints "87 % of 11.40", build 1's compiled-in value). About 1.3 ms of
  the recording cost is therefore spent outside `Append`: the gateway building
  the six events and their artifacts, not timed here. The two figures come
  from different measurements (a paired difference of call latencies against
  appends timed on their own), so this is "about 88 % of the 11.29 ms is spent
  inside the six appends", not an exact decomposition.
- **Staged versus uninstrumented.** Medians 1,649.3 versus 1,645.7 us, means
  1,709.3 versus 1,699.7 (0.6 %); the timer reads add about 1 us. The guard
  that the staged copy writes what `Append` writes is the byte-equality test
  (passed) plus the source check: `audit.go` is byte-identical in builds 1 and
  2 and unchanged since `stage_bench_test.go` was written.
- **Replayed baseline entries** (run-corpus: R3's `baseline-c16-full`
  `audit.jsonl`, 2,462 events, mean line 2,083 bytes): `Append` median
  1,646.6 us, mean 1,702.5, the same shares within 0.3 points. Blocks of six
  replayed entries are not calls, so no share of the 11.29 ms is computed.
- **Cross-check with `agentgate-eval cost`** (this session; batches of 2,000
  appends of a fresh 20-suite self-test run, 2,986 entries, mean line 1,625
  bytes): durable 1,735.1 us per entry (median of 5 batch means) versus the
  `Append` mean 1,699.7 (+2 %); no-fsync − sign-only 462.2 us versus log write
  + temp head write + rename 460.2 us; durable − no-fsync 1,219.9 us versus
  log fsync + head fsync 1,171.8 us (−4 %); sign-only 53.0 us versus encode +
  hash + signing 77.1 us, which also contain the decode of the returned copy
  (18.8 us) and the lock and clock. The two tools agree within 2-4 %.
- **CPU-only stages with allocations** (`BenchmarkAppendStageCPU`, largest
  synthetic entry): encode 5.3 us, 11.3 KB, 21 allocations; decode copy
  20.5 us, 19.7 KB, 58; SHA-256 1.9 us; Ed25519 entry 16.0 us and head
  16.1 us; head JSON 2.1 us, 1.5 KB. About 33 KB allocated per append, a small
  part of a full call's 3 MiB (section 8).
- **What an optimization may not change.** Group commit, one `head.json`
  replacement per call instead of per entry, or an in-place head update would
  attack the 70 % head share and the serialized ceiling, but each must still
  finish the flush of a recorded step before that step creates authority
  (persistence before authority, R4). The numbers show what each stage costs,
  not that any stage can be skipped.

## 6. Disk slowdowns (kept in the data)

The per-second typeperf logs (`load/system-load.csv`, `session-logs/
stagecost-load.csv`) show periods of 10-80 s in which the drive completed
about half the usual writes (about 1,000-1,600/s instead of 2,000-4,400/s,
mean write time up to 0.2-0.6 ms instead of 0.04-0.08 ms). Only the durable
configurations are affected (`slow-calls.json` counts the calls):

- **R2 sequential, block 10** (about 04:25:09-04:25:19 UTC; writes fell to
  900/s, then 7-425/s at a mean write time up to 2.3 ms): 64 durable calls
  over 30 ms (full 19, full+journal 22, full-flagged 24; one more in block 9;
  direct and policy-only none). This is the primary run's p99 of 68 ms; its
  paired medians are barely affected (11.29 ms, the lowest of the five).
- **R4 sequential, blocks 1-5** (about 04:28:42-04:29:16 UTC; about 1,050
  writes/s): 294 durable calls over 30 ms (293 over 42 ms), full p95/p99
  58.9/64.2 ms, recording median 11.57 ms (the highest), sequential phase 52 s
  instead of 37 s.
- **R3 concurrent, 8 clients** (about 04:27:51-04:28:14 UTC): full 41.6 and
  full+journal 32.4 calls/s (other runs 91.7-92.3 and 87.7-89.0).
- **M1 concurrent**: full at 4 clients 50.4 calls/s (04:33:44-04:33:49 UTC),
  full at 16 clients 38.7 and full+journal at 16 clients 32.4 (04:34:09-
  04:34:33 UTC).
- Witness runs 1 and 2 overlapped two more such periods (04:38:43-04:40:01 and
  04:41:17-04:42:31 UTC); run 3 did not (section 7). The stage runs did not.
- A few single calls of 41-45 ms: R1 one full-flagged call, R5 and M1 one
  full+journal call each.

Build 1 saw the same pattern less often (R4 blocks 7-10, R5's last cell, two
first durable cells). The drive is fuller now (97.4 % versus 96 %); the cause
is not established (consistent with drive-internal housekeeping on a nearly
full consumer SSD, which cannot be observed without vendor tools). One short
per-second dip with almost no writes at each switch between phases is the
non-durable cells writing nothing, not a slowdown.

## 7. Witness update cost (not in any reported latency)

`TestWitnessPushCost`: a witness in a test temporary folder on the same volume,
served over loopback in the test process; two durable logs; 50 warm-up and
2,000 timed calls per mode, the two modes alternating call by call (mean line
2,107 bytes). A push is timed at the client: HTTP round trip, the witness's
checks of the head and lines (hashes, chain, signatures), its cosignature and
its store fsync. Saving the cosigned head as the demo does
(`WriteJSONAtomic`) is a separate row. Three runs; medians are stable, means
and tails of runs 1-2 include the disk slowdowns:

| row | median ms (run1 / run2 / run3) | mean ms (run1 / run2 / run3) | p99 ms run3 |
|---|---|---|---|
| push per call (head + 6 lines) | 1.29 / 1.30 / 1.28 | 1.64 / 1.57 / 1.33 | 1.76 |
| save per call | 1.01 / 1.02 / 1.00 | 1.23 / 1.28 / 1.03 | 1.38 |
| push per entry (head + 1 line) | 0.83 / 0.83 / 0.82 | 1.15 / 1.09 / 0.86 | 1.23 |
| save per entry | 0.99 / 1.00 / 1.00 | 1.26 / 1.24 / 1.03 | 1.40 |
| six per-entry pushes and saves, summed per call | 11.09 / 11.13 / 11.07 | 14.43 / 13.98 / 11.29 | 13.42 |

A deployment whose calls waited for one witness update per call would add
the mean push plus save, about **2.4 ms per call** (run 3: 1.33 + 1.03; about
15 % of a 15.7 ms full call); waiting for one update per entry would add about
**11.3 ms**, roughly doubling the recording cost. The witness serializes
pushes with one mutex and fsyncs once per push. **No latency in this report
or the paper includes a push:** the baseline runs no witness
(`cmd/agentgate-eval/baseline.go`, byte-identical in builds 1 and 2, has no
witness and no `internal/demo`), and the demo pushes the signed head after
each agent step, outside the timed gateway call.

## 8. Storage configuration and memory

- **Storage** (the volume of every run, of the scratch logs of the stage runs
  and of the test temporary folders): KINGSTON SNV2S2000G, a 2 TB consumer
  NVMe SSD (firmware SBM02103, health OK); C: NTFS, **cluster size 4,096
  bytes**, 1,862.4 GiB, **47.9 GiB free (97.4 % full)** at the start, 47.2 GiB
  at the end (build 1: 87 GB free, 96 %); compression off, indexing on.
  **Device write-cache setting: not determinable without administrator
  rights** (`Get-StorageAdvancedProperty`: IsDeviceCacheEnabled "failed with
  ErrorCode 40001"; `fsutil fsinfo`: access denied). Microsoft Defender
  real-time protection on, unchanged; exclusions not readable. Directory
  fsync: none on Windows (section 5).
- **Allocation volume is not resident memory.** A call allocates about 420
  KiB (direct), 2,678 (policy-only), 3,046 (full) and 3,072 KiB
  (full+journal) (1 client, median of five runs), and a sequential phase
  allocates 7.51 GiB in total, all of it short-lived and collected. The
  resident memory stays small: peak working set of the whole process
  **≤ 86.3 MiB** (process-wide, carried over between cells), peak Go heap
  ≤ 48.3 MiB, sequential phase peak working set 56.2-58.7 MiB with 0.56-0.79
  cores busy. The audit append itself allocates about 33 KB per entry
  (section 5).

## 9. Comparison with build 1

Build 1 = 2026-10-08 session, primary R3 (`../../revision/baseline/`); build
2 = this session, primary R2. Same scripts, seed and resamples; build 1's
values recomputed with block intervals from its `analysis.json`
(`comparison-build1.csv` has every row).

| measure | build 1 | build 2 | change | explanation |
|---|---|---|---|---|
| mediation, ms (block CI) (R1-R5) | 3.32 [3.25, 3.37] (3.22-3.33) | 3.18 [3.13, 3.25] (3.10-3.19) | −0.14 (−4 %) | A small but systematic shift (the run ranges do not overlap; M1 −0.10). Not caused by the build-2 source: the only change on the policy-only path adds work (one uncontended mutex per call in the operation lifecycle; nanoseconds). policy-only p50 −0.09, direct p50 +0.03. Binary layout of a new binary and machine state changed together; not resolvable by this design. |
| signed durable recording | 11.40 [11.35, 11.47] (11.33-11.58) | 11.29 [11.19, 11.43] (11.29-11.57) | −0.11 (−1 %) | Within the run ranges; none. |
| total (full − direct) | 14.69 [14.64, 14.75] (14.61-14.82) | 14.46 [14.39, 14.54] (14.46-14.68) | −0.23 (−1.6 %) | The two shifts above. |
| operation journal | 3.20 [3.15, 3.29] (3.07-3.21) | 3.43 [3.23, 3.57] (3.27-3.47) | +0.23 | The journal code changed only by a `flagged` field in the dispatch intent (omitted when false: the unflagged journal payment writes the same bytes, same fsyncs). full+journal − direct is unchanged (next row) and M1 shows the same split (recording −0.09, journal +0.26, everything −0.03): the full configuration moved by 0.1-0.2 ms against its neighbours, the reverse of build 1's shift against the build before it. A carry-over effect of the rotated order, at the resolution limit. |
| everything (full+journal − direct) | 17.84 [17.75, 17.91] | 17.87 [17.74, 18.03] | +0.04 | none |
| flagging | −0.27 [−0.36, −0.18] (−0.32 to −0.15) | −0.07 [−0.13, 0.01] (−0.19 to −0.07) | +0.20 | Same carry-over; the build-2 change on the flagged path (committed answers state the flag) is one boolean under a lock. Still "no measurable cost". |
| sequential p50, full / full+journal | 15.94 / 19.08 | 15.72 / 19.14 | −0.22 / +0.06 | as mediation and journal above |
| sequential p99, full (primary) | 20.38 | 68.42 | +48 | R2's block-10 disk slowdown (section 6); clean runs 20.33-20.54 vs 20.31-21.60. |
| full throughput, 4-16 clients | 94.2-94.4 calls/s | 92.2-92.6 | −2 % | `audit.go` is byte-identical; the serialized resource is the disk flush. The `cost` tool's durable append median rose from 1,672 us (2026-10-06, normal desktop load) to 1,735 us (+4 %, line size +2.5 %), and the drive is fuller with more slowdowns: consistent with disk state, not code. |
| full+journal throughput, 4-16 clients | 86.7-87.2 | 87.7-88.3 | +1 % | Opposite sign to full: session-to-session variation of 1-2 %. |
| direct / policy-only at 16 clients | 3,029 / 706 | 3,006 / 706 | −1 % / none | none (direct at 8 clients +6 %, within direct's spread) |
| full latency at 16 clients, p50 | 168.8 ms | 172.1 ms | +3.3 | follows the −2 % throughput (Little's law, which relates the mean latency; corrected 2026-10-10). |
| CPU per call, 1 client | 1.48 / 5.43 / 11.45 / 12.62 | 1.80 / 6.02 / 11.25 / 12.77 | +0.3 / +0.6 / −0.2 / +0.2 | 15.6 ms tick resolution; the build-1 and build-2 ranges overlap. |
| allocation per call, 1 client (KiB) | 422 / 2,681 / 3,045 / 3,076 | 420 / 2,678 / 3,046 / 3,072 | none | |
| peak heap / working set (MiB) | ≤ 48.1 / ≤ 87.0 | ≤ 48.3 / ≤ 86.3 | none | |
| failed calls; evidence | 0 / 62,500; 230/230 ANCHORED | 0 / 62,500; 230/230 ANCHORED | none | The build-2 verifier's new dimensions (`head_fresh`, `run_complete`) and Missing kinds change neither the assurance level nor the failing checks the baseline records (a pinned head lists a `freshness` gap, which the baseline does not store). |
| M1 mediation / recording / total / journal | 3.46 / 11.48 / 14.96 / 3.17 | 3.36 / 11.39 / 14.72 / 3.43 | −0.10 / −0.09 / −0.24 / +0.26 | same pattern as the financial runs |
| per-stage breakdown, witness push | not run on an idle machine (smoke only) | sections 5 and 7 | new | The smoke values in `STAGE_COST.md` (push 1.30 ms, save 0.99, six per-entry 10.93) agree with the idle medians. |

What changed on the measured path between the builds
(`git diff 2d32506 86643d7`, and file hashes in the two manifests): in
`internal/devcomposition`, `durable.go` (committed answers state the flag; the
dispatch intent carries it), `dispatch.go` (the flag is read before dispatch),
`auditing.go` (stored answers keep the flag only when COMMITTED);
`cmd/agentgate-eval/harness.go` and `internal/auditverify` (verification of
the evidence after the timed calls; new `freshness.go`). `baseline.go`,
`resources.go`, `cost.go` and `internal/audit/audit.go` are byte-identical.
Build, desktop load (higher now) and disk state (fuller now) changed
together, so no difference is attributed to the build alone; none needs the
build to explain it.

## 10. Charts

`charts/baseline_latency_ecdf.{pdf,png}` (R2's sequential calls, log scale;
the block-10 tail is visible as the top 4 % of the durable curves) and
`charts/baseline_throughput.{pdf,png}` (median of five runs, min-max whiskers;
the long whiskers at 8 clients are R3's slowdown). Same style as build 1
(3.5 x 2.2 in, 8 pt, 300 dpi, colour-blind safe palette with a second
encoding). They are not copied to `../charts/`, which other documents own.

## 11. Caveats

- One machine; loopback provider in the same process; small fixed payloads and
  short logs; closed-loop clients (throughput at saturation, latency includes
  queueing).
- Durable costs depend on this consumer NVMe drive at 97.4 % full, NTFS and
  Windows flush semantics, and on the slowdowns of section 6, which hit the
  primary run's last block; the write-cache setting is unknown.
- Desktop load was 0.36-0.50 cores (coding-agent processes; build 1 0.19-0.36).
  The idle checks and the process logger rule out the Go toolchain, Python and
  other experiment binaries, not the coding agents themselves.
- The rotated order balances positions, not predecessors: differences of a few
  tenths of a millisecond (flagging, the journal and mediation shifts against
  build 1) are not resolved.
- `GetProcessTimes` ticks about 15.6 ms (CPU per call is coarse).
- The stage and witness measurements are test-only code on a separate test
  build of the same commit; the stage path is a copy of `Append` guarded by a
  byte-equality test and a source check, not `Append` itself. Directory fsync
  does not exist on Windows; rename durability is not tested here.
- The share of the 11.29 ms inside the appends crosses two measurement
  settings and is approximate.

## 12. Files

| file | content |
|---|---|
| `RESULTS.md` | this report |
| `build-manifest.txt` | binaries, both manifest checks (before/after with timestamps), test build and hashes, source check, idle checks, discarded first attempt, timeline, storage, machine |
| `source-manifest.txt` | copy of `<singlebuild2>/MANIFEST.txt` with the repository path replaced |
| `baseline.json`, `baseline.md`, `baseline-sequential.csv`, `baseline-concurrent.csv`, `baseline-concurrent-summary.csv`, `load/` | primary run R2 (raw per-call CSVs, every call) |
| `repeats/R1`, `R3`, `R4`, `R5` | the other financial runs, same files |
| `message/` | M1, same files |
| `analysis.json` | every derived number (per run: sequential stats, paired differences with trial and block intervals, concurrent cells, phase resources, load, background) plus build 1's primary run and spread |
| `analyze_baseline.py` | build 1's analysis script; only the chart folder and the build-1 comparison input changed |
| `compare_build1.py`, `comparison-build1.csv` | the headline numbers next to build 1 |
| `slow_calls.py`, `slow-calls.json` | slow calls per run, configuration and block; low-throughput cells; disk write-time intervals |
| `stage_summary.py`, `stagecost/summary.csv` | stage groups, shares, per-call sums, serial rate and witness rows of every run |
| `stagecost/run1..run3/`, `stagecost/run-corpus/` | `stagecost.{json,md}` and (run1-run3) `witnesspush.{json,md}` as written by the tests |
| `stagecost/bench-cpu.txt`, `stagecost/stagecost-drive.log` | CPU-only stage benchmark; stage/witness timeline |
| `cost/cost.{json,md}`, `cost/stdout.txt` | the `agentgate-eval cost` run |
| `session-logs/` | `drive.log`, `session.log`, `watch-procs.csv` (idle guard), `idle-check.txt`, `stagecost-load.csv` (typeperf during cost, stage and witness runs) |
| `tools/` | `drive_runs.sh`, `run_baseline.sh`, `procsnap.ps1`, `sanitize_load.py` (build 1, unchanged); `run_session.sh`, `run_stagecost.sh`, `watch_procs.ps1` (new) |
| `charts/` | the two charts |

The 569 MB of evidence folders, the cost run's self-test folder, the test
binaries and the discarded first attempt stay in the scratchpad
(`<scratch>/build2-work/baseline/`). Evidence was written with
`-host-label review-host` (460 files name it; none names the machine or a user
path). Every file above was checked the same way; the process snapshots were
aggregated into categories and the typeperf headers have the machine name
replaced (`tools/sanitize_load.py`).
