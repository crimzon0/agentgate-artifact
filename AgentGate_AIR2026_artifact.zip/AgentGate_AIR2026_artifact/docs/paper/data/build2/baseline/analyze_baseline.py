"""Analyse the R6.8 baseline runs (agentgate-eval baseline) and draw the two charts.

    py docs/paper/data/build2/baseline/analyze_baseline.py \
        [--primary DIR] [--repeat DIR ...] [--message DIR] [--supplementary DIR ...]
        [--charts DIR] [--out FILE] [--no-charts]

Build-2 copy of docs/paper/data/revision/baseline/analyze_baseline.py (build 1).
The statistics, seed, resamples and charts are unchanged. Two path changes
only: charts go to charts/ next to this script (not ../charts, which other
documents own), and the comparison block reads build 1's analysis.json
(../../revision/baseline/analysis.json) into build1_primary and
build1_between_runs instead of the older previous-build session.

DIR is an output folder of `agentgate-eval baseline` (baseline.json,
baseline-sequential.csv, baseline-concurrent.csv, baseline-concurrent-summary.csv,
and load/ with the system-load log written by the run wrapper). Defaults: the
primary run is this folder; repeats are this folder's repeats/*/ folders; the
message-workload run is message/ when present; supplementary runs are
supplementary/*/ (analysed, but kept out of the charts and the between-run
spread); charts go to charts/. The primary run is the run with the lowest
measured background load: the cores busy in the per-process snapshots taken
5 s before and after the run (load/processes-*.csv), excluding the shells and
the load logger (analysis.json, runs.*.background_cores). The run timeline and
binary are in build-manifest.txt. When ../../revision/baseline/analysis.json
(build 1, 2026-10-08) exists, its primary-run numbers and its between-run
spread are copied into analysis.json (build1_primary, build1_between_runs) for
comparison; they come from the older build.

Writes analysis.json next to this script (every derived number) and
baseline_latency_ecdf.{pdf,png} and baseline_throughput.{pdf,png} (3.5 x 2.2 in,
8 pt, 300 dpi). Python 3 + numpy + matplotlib; no other dependency.

Statistics
- Per-configuration latency: every measured sequential call (warm-up calls are
  excluded; nothing else is). Percentiles use linear interpolation between
  order statistics (numpy default; identical to the Go tool's percentile()).
- Incremental latency: per trial t, d_t = latency(b, t) - latency(a, t); one
  trial sends one call to every configuration back to back, in a rotated order.
  Point estimates are the median and the mean of d_t. 95% intervals are
  percentile bootstrap intervals over trials (B = 10,000 resamples, fixed seed).
  A cluster bootstrap over blocks (each block has fresh providers, gateways and
  logs; 10 blocks of 50 trials) is reported as a sensitivity check, because
  trials of one block share state and are not independent.
- Concurrent load: throughput = measured calls / window wall time; one value
  per (configuration, client count) per run. The chart shows the median over
  all financial-workload runs (primary and repeats; line and markers) and their
  min-max range (whiskers); the latency ECDF shows the primary run only.
"""
import argparse
import csv
import glob
import json
import os
from collections import defaultdict

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import matplotlib.ticker as mticker  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 20261007
B = 10_000

CONFIGS = ["direct", "policy-only", "full", "full+journal", "full-flagged"]
PAIRS = [("direct", "policy-only"), ("policy-only", "full"), ("direct", "full"),
         ("full", "full+journal"), ("full", "full-flagged"), ("direct", "full+journal")]

# House style of docs/paper/figures/src/charts.py; series colours are the
# validated categorical slots 1-5 (dataviz reference palette, light mode),
# always with a second encoding (line style / marker) and a legend.
INK, SECONDARY, MUTED, GRID, BASELINE = "#1A1D21", "#3F464E", "#7D858E", "#E3E5E8", "#B9BFC6"
COLOR = {"direct": "#2a78d6", "policy-only": "#eb6834", "full": "#1baf7a", "full+journal": "#eda100", "full-flagged": "#e87ba4"}
STYLE = {"direct": "-", "policy-only": "-", "full": "-", "full+journal": (0, (4, 1.5)), "full-flagged": (0, (1, 1.2))}
MARKER = {"direct": "o", "policy-only": "s", "full": "^", "full+journal": "D"}
DODGE = {"direct": 0.0, "policy-only": 0.0, "full": -0.06, "full+journal": 0.06}
WIDTH, HEIGHT = 3.5, 2.2

plt.rcParams.update({
    "font.family": "Segoe UI", "font.size": 8, "axes.labelsize": 8, "axes.labelcolor": SECONDARY,
    "axes.edgecolor": BASELINE, "axes.linewidth": 0.8, "figure.facecolor": "white", "savefig.facecolor": "white",
    "xtick.labelsize": 8, "ytick.labelsize": 8, "xtick.color": SECONDARY, "ytick.color": SECONDARY,
    "xtick.major.size": 0, "ytick.major.size": 0, "xtick.minor.size": 0, "ytick.minor.size": 0,
    "legend.fontsize": 7.5, "text.color": INK, "pdf.fonttype": 42, "ps.fonttype": 42,
})


def pct(values, q):
    return float(np.percentile(np.asarray(values, dtype=float), q * 100))


def describe(values):
    v = np.asarray(values, dtype=float)
    if v.size == 0:
        return {"n": 0}
    return {"n": int(v.size), "min_us": round(float(v.min()), 1), "p50_us": round(pct(v, .5), 1), "p90_us": round(pct(v, .9), 1),
            "p95_us": round(pct(v, .95), 1), "p99_us": round(pct(v, .99), 1), "max_us": round(float(v.max()), 1),
            "mean_us": round(float(v.mean()), 1), "sd_us": round(float(v.std(ddof=1)), 1) if v.size > 1 else 0.0}


def read_sequential(run_dir):
    """{config: {trial: (block, latency_us, status)}} for measured calls."""
    out = defaultdict(dict)
    with open(os.path.join(run_dir, "baseline-sequential.csv"), newline="") as handle:
        for row in csv.DictReader(handle):
            if row["warmup"] in ("yes", "true"):
                continue
            out[row["config"]][int(row["trial"])] = (int(row["block"]), float(row["latency_us"]), row["status"])
    return out


def bootstrap(diffs, blocks, rng):
    """Percentile bootstrap (trials) and cluster bootstrap (blocks) of median and mean."""
    diffs = np.asarray(diffs, dtype=float)
    n = diffs.size
    idx = rng.integers(0, n, size=(B, n))
    sample = diffs[idx]
    med = np.median(sample, axis=1)
    mean = sample.mean(axis=1)
    blocks = np.asarray(blocks)
    unique = np.unique(blocks)
    groups = [diffs[blocks == b] for b in unique]
    cmed, cmean = np.empty(B), np.empty(B)
    for i in range(B):
        pick = rng.integers(0, len(groups), size=len(groups))
        cat = np.concatenate([groups[j] for j in pick])
        cmed[i], cmean[i] = np.median(cat), cat.mean()
    ci = lambda a: [round(float(np.percentile(a, 2.5)), 1), round(float(np.percentile(a, 97.5)), 1)]  # noqa: E731
    return {"median_ci95_trials": ci(med), "mean_ci95_trials": ci(mean),
            "median_ci95_blocks": ci(cmed), "mean_ci95_blocks": ci(cmean), "blocks": int(len(groups))}


def analyse_sequential(run_dir, rng):
    seq = read_sequential(run_dir)
    configs = [c for c in CONFIGS if c in seq]
    per_config = {}
    for c in configs:
        lat = [v[1] for v in seq[c].values()]
        stats = describe(lat)
        stats["not_committed"] = sum(1 for v in seq[c].values() if not v[2].startswith("COMMITTED"))
        per_config[c] = stats
    paired = []
    for a, b in PAIRS:
        if a not in seq or b not in seq:
            continue
        trials = sorted(set(seq[a]) & set(seq[b]))
        d = [seq[b][t][1] - seq[a][t][1] for t in trials]
        blocks = [seq[a][t][0] for t in trials]
        row = {"compare": f"{b} - {a}", "n_trials": len(trials), "median_us": round(float(np.median(d)), 1),
               "mean_us": round(float(np.mean(d)), 1), "p95_us": round(pct(d, .95), 1),
               "share_b_slower": round(sum(1 for x in d if x > 0) / len(d), 4),
               "median_ratio_b_over_a": round(per_config[b]["p50_us"] / per_config[a]["p50_us"], 2)}
        row.update(bootstrap(d, blocks, rng))
        paired.append(row)
    return per_config, paired, seq


def read_concurrent(run_dir):
    cells = {}
    with open(os.path.join(run_dir, "baseline-concurrent-summary.csv"), newline="") as handle:
        for row in csv.DictReader(handle):
            cells[(row["config"], int(row["clients"]))] = row
    return cells


def load_summary(run_dir):
    """Mean / max total CPU % and disk writes from the wrapper's typeperf log, if present."""
    path = os.path.join(run_dir, "load", "system-load.csv")
    if not os.path.exists(path):
        return None
    cpu, writes, wlat = [], [], []
    with open(path, newline="") as handle:
        rows = list(csv.reader(handle))[1:]
    for row in rows:
        try:
            cpu.append(float(row[1]))
            writes.append(float(row[3]))
            wlat.append(float(row[4]) * 1000)
        except (ValueError, IndexError):
            continue
    if not cpu:
        return None
    return {"samples_1s": len(cpu), "total_cpu_pct_mean": round(float(np.mean(cpu)), 1), "total_cpu_pct_p95": round(pct(cpu, .95), 1),
            "total_cpu_pct_max": round(float(np.max(cpu)), 1), "disk_writes_per_s_mean": round(float(np.mean(writes)), 0),
            "disk_avg_write_ms_mean": round(float(np.mean(wlat)), 3), "disk_avg_write_ms_max": round(float(np.max(wlat)), 3)}


def background_cores(run_dir):
    """Cores busy in the before/after snapshots, without the shells and the load logger."""
    out = {}
    for when in ("before", "after"):
        path = os.path.join(run_dir, "load", f"processes-{when}.csv")
        if not os.path.exists(path):
            continue
        with open(path, encoding="utf-8-sig") as handle:
            lines = handle.read().splitlines()
        rows = {}
        for row in csv.DictReader(lines[1:]):
            name = row.get("category") or row.get("name")
            rows[name] = rows.get(name, 0.0) + float(row["cores_busy"])
        total = rows.pop("all listed processes", None)
        if total is None:
            total = sum(rows.values())
        own = rows.get("shells and the load logger", 0.0) + sum(v for k, v in rows.items() if k in ("powershell", "typeperf", "bash", "conhost"))
        out[when] = {"all_listed": round(total, 3), "without_shells_and_logger": round(total - own, 3)}
    return out or None


def concurrent_table(cells):
    out = []
    for (config, clients), row in sorted(cells.items(), key=lambda kv: (kv[0][1], CONFIGS.index(kv[0][0]))):
        out.append({"clients": clients, "config": config, "calls": int(row["calls"]), "not_committed": int(row["failed"]),
                    "throughput_calls_per_s": float(row["throughput_calls_per_s"]), "p50_us": float(row["p50_us"]),
                    "p95_us": float(row["p95_us"]), "p99_us": float(row["p99_us"]), "max_us": float(row["max_us"]),
                    "cpu_ms_per_call": float(row["cpu_ms_per_call"]), "cpu_cores_busy": float(row["cpu_utilization_cores"]),
                    "alloc_kib_per_call": float(row["alloc_kib_per_call"]),
                    "peak_heap_mib": round(int(row["peak_heap_objects_bytes"]) / 2**20, 1),
                    "peak_working_set_mib": round(int(row["peak_working_set_bytes"]) / 2**20, 1), "evidence": row["evidence"]})
    return out


def style_axes(ax):
    ax.grid(True, which="major", color=GRID, linewidth=0.6)
    ax.set_axisbelow(True)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)


def chart_ecdf(seq, path_base, title_note):
    fig, ax = plt.subplots(figsize=(WIDTH, HEIGHT), layout="constrained")
    for c in CONFIGS:
        if c not in seq:
            continue
        v = np.sort(np.array([x[1] for x in seq[c].values()]) / 1000.0)
        y = np.arange(1, v.size + 1) / v.size
        ax.step(v, y, where="post", color=COLOR[c], linestyle=STYLE[c], linewidth=1.3 if c in ("direct", "policy-only", "full") else 1.1,
                label=c)
    ax.set_xscale("log")
    low, high = ax.get_xlim()
    ax.xaxis.set_major_locator(mticker.FixedLocator([t for t in (0.5, 1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000) if low <= t <= high]))
    ax.xaxis.set_minor_locator(mticker.NullLocator())
    ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x:g}"))
    ax.set_xlabel("Per-call latency, sequential paired trials (ms, log scale)")
    ax.set_ylabel("Share of calls (ECDF)")
    ax.set_ylim(0, 1.0)
    ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda y, _: f"{y:g}"))
    style_axes(ax)
    leg = ax.legend(loc="lower left", bbox_to_anchor=(0.0, 1.0), ncol=3, frameon=False, handlelength=2.2, handletextpad=0.4,
                    columnspacing=1.0, borderaxespad=0.1, labelspacing=0.2)
    for text in leg.get_texts():
        text.set_color(INK)
    if title_note:
        ax.text(0.01, 0.99, title_note, transform=ax.transAxes, ha="left", va="top", fontsize=7, color=MUTED)
    for ext in ("pdf", "png"):
        fig.savefig(f"{path_base}.{ext}", dpi=300)
    plt.close(fig)


def chart_throughput(primary_cells, runs_cells, path_base, title_note):
    """Line and markers: median over all financial runs; whiskers: min-max over those runs."""
    fig, ax = plt.subplots(figsize=(WIDTH, HEIGHT), layout="constrained")
    clients = sorted({k for (_, k) in primary_cells})
    for c in CONFIGS:
        if c not in MARKER or not any((c, k) in primary_cells for k in clients):
            continue
        xs = [k for k in clients if (c, k) in primary_cells]
        ys = np.array([float(np.median([float(cells[(c, k)]["throughput_calls_per_s"]) for cells in runs_cells if (c, k) in cells])) for k in xs])
        lo = np.array([min(float(cells[(c, k)]["throughput_calls_per_s"]) for cells in runs_cells if (c, k) in cells) for k in xs])
        hi = np.array([max(float(cells[(c, k)]["throughput_calls_per_s"]) for cells in runs_cells if (c, k) in cells) for k in xs])
        # A horizontal dodge (log2 units) keeps the whiskers of the two
        # recording configurations, which sit close together, apart (direct
        # and policy-only are far from them and from each other: no dodge).
        xd = [k * 2 ** DODGE.get(c, 0.0) for k in xs]
        if len(runs_cells) > 1:
            ax.errorbar(xd, ys, yerr=[ys - lo, hi - ys], fmt="none", ecolor=COLOR[c], elinewidth=0.8, capsize=1.8, alpha=0.9)
        ax.plot(xd, ys, color=COLOR[c], linestyle=STYLE[c], marker=MARKER[c], markersize=4, linewidth=1.3,
                markeredgecolor="white", markeredgewidth=0.6, label=c)
    if len(runs_cells) > 1:
        ax.text(0.98, 0.40, f"median of {len(runs_cells)} runs; whiskers: min-max", transform=ax.transAxes, ha="right", va="center",
                fontsize=7, color=MUTED)
    ax.set_xscale("log", base=2)
    ax.set_xticks(clients)
    ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{int(x)}"))
    ax.set_yscale("log")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda y, _: f"{y:g}"))
    ax.set_xlabel("Concurrent clients (closed loop, back to back)")
    ax.set_ylabel("Throughput (calls/s, log scale)")
    style_axes(ax)
    ax.grid(True, which="minor", axis="y", color=GRID, linewidth=0.3)
    leg = ax.legend(loc="lower left", bbox_to_anchor=(0.0, 1.0), ncol=4, frameon=False, handlelength=1.8, handletextpad=0.4,
                    columnspacing=0.9, borderaxespad=0.1)
    for text in leg.get_texts():
        text.set_color(INK)
    if title_note:
        ax.text(0.01, 0.99, title_note, transform=ax.transAxes, ha="left", va="top", fontsize=7, color=MUTED)
    for ext in ("pdf", "png"):
        fig.savefig(f"{path_base}.{ext}", dpi=300)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--primary", default=HERE)
    parser.add_argument("--repeat", action="append", default=None)
    parser.add_argument("--message", default=None)
    parser.add_argument("--supplementary", action="append", default=None,
                        help="runs analysed but kept out of the charts and the between-run spread (default: supplementary/*/)")
    parser.add_argument("--no-charts", action="store_true")
    parser.add_argument("--charts", default=os.path.join(HERE, "charts"))
    parser.add_argument("--out", default=os.path.join(HERE, "analysis.json"))
    args = parser.parse_args()
    repeats = args.repeat if args.repeat is not None else sorted(d for d in glob.glob(os.path.join(HERE, "repeats", "*")) if os.path.isdir(d))
    message = args.message if args.message is not None else (os.path.join(HERE, "message") if os.path.isdir(os.path.join(HERE, "message")) else None)
    supplementary = args.supplementary if args.supplementary is not None else sorted(
        d for d in glob.glob(os.path.join(HERE, "supplementary", "*")) if os.path.isfile(os.path.join(d, "baseline.json")))
    rng = np.random.default_rng(SEED)

    result = {"method": __doc__.split("Statistics", 1)[1].strip(), "bootstrap_resamples": B, "seed": SEED, "runs": {}}
    run_dirs = [("primary", args.primary)] + [(f"repeat-{os.path.basename(d)}", d) for d in repeats]
    if message:
        run_dirs.append(("message", message))
    run_dirs += [(f"supplementary-{os.path.basename(d)}", d) for d in supplementary]
    primary_seq = None
    primary_cells = None
    financial_cells = []
    for name, run_dir in run_dirs:
        with open(os.path.join(run_dir, "baseline.json")) as handle:
            meta = json.load(handle)
        per_config, paired, seq = analyse_sequential(run_dir, rng)
        cells = read_concurrent(run_dir)
        result["runs"][name] = {
            "dir": os.path.relpath(run_dir, HERE).replace("\\", "/"), "workload": meta["workload"],
            "command": meta["environment"]["command"], "started_at": meta["environment"]["started_at"],
            "sequential": per_config, "paired_differences": paired, "concurrent": concurrent_table(cells),
            "sequential_phase_resources": meta.get("sequential", {}).get("phase_resources"),
            "system_load": load_summary(run_dir), "background_cores": background_cores(run_dir), "errors": meta.get("errors", []),
        }
        if name == "primary":
            primary_seq, primary_cells = seq, cells
        if meta["workload"] == "financial" and not name.startswith("supplementary-"):
            financial_cells.append(cells)
    # Between-run spread of the key numbers (financial runs only).
    fin = [r for n, r in result["runs"].items() if r["workload"] == "financial" and not n.startswith("supplementary-")]
    if len(fin) > 1:
        spread = {"runs": len(fin), "paired_median_us": {}, "p99_us": {}, "throughput": {}}
        for row in fin[0]["paired_differences"]:
            vals = [p["median_us"] for r in fin for p in r["paired_differences"] if p["compare"] == row["compare"]]
            spread["paired_median_us"][row["compare"]] = {"min": min(vals), "max": max(vals), "values": vals}
        for c in fin[0]["sequential"]:
            vals = [r["sequential"][c]["p99_us"] for r in fin if c in r["sequential"]]
            spread["p99_us"][c] = {"min": min(vals), "max": max(vals), "values": vals}
        for cell in fin[0]["concurrent"]:
            key = f"{cell['config']}@{cell['clients']}"
            vals = [x["throughput_calls_per_s"] for r in fin for x in r["concurrent"] if x["config"] == cell["config"] and x["clients"] == cell["clients"]]
            spread["throughput"][key] = {"min": min(vals), "max": max(vals), "values": vals}
        result["between_runs"] = spread
    previous = os.path.normpath(os.path.join(HERE, "..", "..", "revision", "baseline", "analysis.json"))
    if os.path.abspath(args.primary) == HERE and os.path.exists(previous):
        with open(previous) as handle:
            old_all = json.load(handle)
        old = old_all["runs"].get("primary", {})
        result["build1_primary"] = {
            "note": "primary run (R3) of the 2026-10-08 03:23 UTC session on build 1 (agentgate-eval 744d480c...), docs/paper/data/revision/baseline/; the older build, for comparison only",
            "started_at": old.get("started_at"), "sequential": old.get("sequential"), "paired_differences": old.get("paired_differences"),
            "concurrent": old.get("concurrent"), "system_load": old.get("system_load")}
        result["build1_between_runs"] = old_all.get("between_runs")
    with open(args.out, "w") as handle:
        json.dump(result, handle, indent=2)
    print("wrote", args.out)
    if not args.no_charts:
        os.makedirs(args.charts, exist_ok=True)
        chart_ecdf(primary_seq, os.path.join(args.charts, "baseline_latency_ecdf"), "")
        chart_throughput(primary_cells, financial_cells, os.path.join(args.charts, "baseline_throughput"), "")
        print("wrote charts in", args.charts)


if __name__ == "__main__":
    main()
