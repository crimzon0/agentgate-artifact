# Baselines and load

Local measurements on one machine with simulated providers over loopback. They compare matched configurations of this prototype under one synthetic workload; they are not a general performance claim, and repeated timing calls are not independent workloads.

Command: `agentgate-eval -host-label review-host baseline -out <path>/R2 -work <work>`. Workload: financial. Go go1.26.6 on windows/amd64, 12 CPUs, GOMAXPROCS 12.  
Timer: QueryPerformanceCounter (kernel32 via golang.org/x/sys/windows), frequency 10000000 Hz, tick 100.0 ns. Wall-clock step observed for time.Now: 0.0113 ms.

## Configurations

- **direct**: no gateway: normalize (gateway normalizer), adapters.Prepare, adapters.HTTPTransport to the provider, verify the provider receipt
- **policy-only**: gateway with policy, grant, capability and signed receipts; audit sink off, no operation journal
- **full**: policy-only plus the signed hash-chained audit log, durable (fsync per entry)
- **full+journal**: full plus the fsynced operation journal
- **full-flagged**: full; the request is above the automatic limit and is flagged for audit

## Method

- Identical transport: every configuration is reached by JSON-RPC tools/call over loopback HTTP (keep-alive client, one per configuration) and reaches the provider with the adapter's HTTP transport (one fresh TCP connection per provider request).
- Identical provider: a provider host (internal/simulator behind its own loopback listener and key); every configuration has its own instance (same code, same transport, its own state) per sequential block and per concurrent cell, so state growth is equal and each evidence folder's provider journal holds only its own effects.
- Sequential: 500 paired trials in blocks of 50; in each trial every configuration gets one call, in an order rotated by one position per trial; each block starts fresh (provider, gateways, audit logs, journal) after 10 warm-up calls per configuration.
- Concurrent: client counts [1 2 4 8 16]; each configuration alone per cell, 10 warm-up calls then 400 measured calls split over the clients, back to back; CPU time is the whole process (client, server, gateway, provider host), memory peaks are sampled every 5ms.
- Every observation is kept: raw CSVs hold warm-up calls (marked) and every measured call, failed or not; summaries use every measured call (no outlier removal).
- Paired differences: per trial b - a; median with a distribution-free 95% interval (sign test order statistics), mean, and the share of trials in which b was slower.

## Sequential, paired trials (500 trials, 10 blocks, 40.2 s)

Latency per call in microseconds (all measured calls).

| config | n | min | p50 | p90 | p95 | p99 | max | mean | not committed | audit entries/call | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| direct | 500 | 1048 | 1238 | 1434 | 1568 | 1785 | 1909 | 1267 | 0 | 0.00 |  |
| policy-only | 500 | 3858 | 4437 | 4890 | 5059 | 5353 | 5855 | 4462 | 0 | 0.00 |  |
| full | 500 | 14708 | 15722 | 17757 | 20090 | 68419 | 68800 | 17446 | 0 | 6.00 | ANCHORED x10 |
| full+journal | 500 | 17915 | 19140 | 22400 | 23841 | 72120 | 211890 | 21406 | 0 | 6.00 | ANCHORED x10 |
| full-flagged | 500 | 14610 | 15599 | 18482 | 20804 | 68472 | 219156 | 18020 | 0 | 6.00 | ANCHORED x10 |

Paired differences (per trial, microseconds; 95% interval of the median from the sign test):

| difference | n | median | 95% CI | mean | p95 | share of trials slower |
|---|---|---|---|---|---|---|
| policy-only - direct | 500 | 3182 | [3138, 3227] | 3194 | 3838 | 100.0% |
| full - policy-only | 500 | 11286 | [11219, 11373] | 12984 | 15505 | 100.0% |
| full - direct | 500 | 14457 | [14406, 14504] | 16179 | 18706 | 100.0% |
| full+journal - full | 500 | 3432 | [3248, 3556] | 3960 | 8239 | 94.4% |
| full-flagged - full | 500 | -68 | [-146, -2] | 574 | 4155 | 45.6% |
| full+journal - direct | 500 | 17875 | [17788, 17953] | 20139 | 22584 | 100.0% |

Whole sequential phase: CPU 28703 ms (user 18234, kernel 10469) over 40210 ms wall; 7691.4 MiB allocated; peak working set 56.2 MiB (sampled).

## Concurrent load

Each cell runs one configuration alone; latency in microseconds; CPU is the whole process.

| clients | config | calls | not committed | calls/s | p50 | p95 | p99 | max | CPU ms/call | CPU cores busy | KiB alloc/call | peak heap MiB | peak working set MiB | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | direct | 400 | 0 | 957.4 | 952 | 1295 | 1418 | 1513 | 1.445 | 1.38 | 419.7 | 4.9 | 50.2 |  |
| 1 | policy-only | 400 | 0 | 229.5 | 4274 | 4742 | 5173 | 5475 | 5.273 | 1.21 | 2678.2 | 20.8 | 45.1 |  |
| 1 | full | 400 | 0 | 62.7 | 15582 | 18359 | 20600 | 24196 | 10.781 | 0.68 | 3040.7 | 39.7 | 65.1 | ANCHORED |
| 1 | full+journal | 400 | 0 | 51.6 | 18972 | 22167 | 23375 | 24394 | 13.438 | 0.69 | 3071.0 | 40.6 | 67.2 | ANCHORED |
| 2 | direct | 400 | 0 | 1688.6 | 1174 | 1430 | 1555 | 1975 | 1.719 | 2.90 | 429.4 | 5.5 | 81.8 |  |
| 2 | policy-only | 400 | 0 | 373.8 | 5301 | 5974 | 6262 | 6640 | 5.508 | 2.06 | 2699.9 | 20.6 | 82.9 |  |
| 2 | full | 400 | 0 | 89.3 | 22027 | 25985 | 27882 | 29035 | 12.891 | 1.15 | 3059.5 | 40.1 | 66.0 | ANCHORED |
| 2 | full+journal | 400 | 0 | 78.6 | 24692 | 28769 | 29445 | 54774 | 13.438 | 1.06 | 3084.6 | 40.7 | 72.4 | ANCHORED |
| 4 | direct | 400 | 0 | 2295.3 | 1646 | 2160 | 2398 | 3539 | 2.070 | 4.75 | 442.8 | 43.7 | 84.7 |  |
| 4 | policy-only | 400 | 0 | 566.6 | 6821 | 9052 | 9677 | 10973 | 7.383 | 4.18 | 2708.9 | 20.2 | 51.0 |  |
| 4 | full | 400 | 0 | 92.7 | 42398 | 47694 | 51356 | 58566 | 13.047 | 1.21 | 3061.9 | 39.7 | 67.2 | ANCHORED |
| 4 | full+journal | 400 | 0 | 88.0 | 44668 | 49999 | 52700 | 58080 | 15.352 | 1.35 | 3082.9 | 40.5 | 75.8 | ANCHORED |
| 8 | direct | 400 | 0 | 2685.8 | 2893 | 3535 | 5326 | 6818 | 1.992 | 5.35 | 439.6 | 47.9 | 83.2 |  |
| 8 | policy-only | 400 | 0 | 678.5 | 11471 | 15272 | 17510 | 19709 | 6.914 | 4.69 | 2705.2 | 21.3 | 52.7 |  |
| 8 | full | 400 | 0 | 92.2 | 85827 | 96958 | 112237 | 123355 | 11.914 | 1.10 | 3051.6 | 40.8 | 69.7 | ANCHORED |
| 8 | full+journal | 400 | 0 | 88.5 | 90514 | 96836 | 100048 | 119019 | 13.438 | 1.19 | 3081.6 | 39.5 | 71.7 | ANCHORED |
| 16 | direct | 400 | 0 | 3006.3 | 5208 | 5992 | 7738 | 9149 | 1.992 | 5.99 | 424.5 | 44.5 | 86.2 |  |
| 16 | policy-only | 400 | 0 | 705.9 | 22002 | 28214 | 37375 | 39485 | 6.211 | 4.38 | 2688.5 | 25.7 | 60.9 |  |
| 16 | full | 400 | 0 | 93.1 | 171114 | 180570 | 184795 | 222954 | 11.914 | 1.11 | 3047.1 | 41.3 | 72.0 | ANCHORED |
| 16 | full+journal | 400 | 0 | 88.4 | 180500 | 187409 | 195841 | 223671 | 12.383 | 1.09 | 3075.4 | 41.4 | 78.9 | ANCHORED |

CPU source: GetProcessTimes (user + kernel) (resolution: scheduler tick (about 15.6 ms on an idle system)). Memory: K32GetProcessMemoryInfo (working set), sampled every 5 ms; heap = runtime/metrics /memory/classes/heap/objects:bytes.

## Files

- concurrent_observations: `baseline-concurrent.csv`
- concurrent_summary: `baseline-concurrent-summary.csv`
- sequential_observations: `baseline-sequential.csv`
