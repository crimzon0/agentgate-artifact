"""Headline numbers of the baseline on build 2 next to build 1 (new in build 2).

    py docs/paper/data/build2/baseline/compare_build1.py

Reads analysis.json next to this script (build 2, written by analyze_baseline.py)
and ../../revision/baseline/analysis.json (build 1, 2026-10-08) and writes
comparison-build1.csv: one row per headline number with the build-1 value, the
build-2 value and the change. Both files come from the same analysis script
(same seed, same resamples), so every number is computed the same way:

- paired medians: primary run, with the block-level 95 % interval (cluster
  bootstrap over the 10 blocks) and the range over the five financial runs;
- sequential percentiles: primary run, every measured call;
- concurrent cells: median over the five financial runs (min-max);
- latency under load, CPU per call, allocation: median over the five runs;
  peaks: maximum over the five runs and all cells;
- sequential-phase resources: range over the five financial runs.
The primary run of each build is the one with the lowest background load
(build 1: R3; build 2: R2).
"""
import csv
import json
import os
import statistics as st

HERE = os.path.dirname(os.path.abspath(__file__))
FIN = ["primary", "repeat-R1", "repeat-R2", "repeat-R3", "repeat-R4", "repeat-R5"]
PAIRS = [("mediation (policy-only - direct)", "policy-only - direct"),
         ("signed durable recording (full - policy-only)", "full - policy-only"),
         ("total (full - direct)", "full - direct"),
         ("operation journal (full+journal - full)", "full+journal - full"),
         ("flagging (full-flagged - full)", "full-flagged - full"),
         ("everything (full+journal - direct)", "full+journal - direct")]


def load(path):
    with open(path) as handle:
        data = json.load(handle)
    runs = {name: run for name, run in data["runs"].items() if name in FIN}
    return data, runs


def ms(us):
    return round(us / 1000.0, 2)


def paired(runs, compare):
    row = next(p for p in runs["primary"]["paired_differences"] if p["compare"] == compare)
    vals = [p["median_us"] for r in runs.values() for p in r["paired_differences"] if p["compare"] == compare]
    return (f"{ms(row['median_us']):.2f} [{ms(row['median_ci95_blocks'][0]):.2f}, {ms(row['median_ci95_blocks'][1]):.2f}] "
            f"({ms(min(vals)):.2f} to {ms(max(vals)):.2f})"), row["median_us"]


def cell(runs, config, clients, key):
    return [x[key] for r in runs.values() for x in r["concurrent"] if x["config"] == config and x["clients"] == clients]


def main():
    _, b2 = load(os.path.join(HERE, "analysis.json"))
    _, b1 = load(os.path.normpath(os.path.join(HERE, "..", "..", "revision", "baseline", "analysis.json")))
    rows = []
    for label, compare in PAIRS:
        t1, v1 = paired(b1, compare)
        t2, v2 = paired(b2, compare)
        rows.append([f"paired median, ms: {label}", t1, t2, f"{ms(v2 - v1):+.2f}"])
    for config in ["direct", "policy-only", "full", "full+journal", "full-flagged"]:
        s1, s2 = b1["primary"]["sequential"][config], b2["primary"]["sequential"][config]
        f = lambda s: " / ".join(f"{ms(s[k]):.2f}" for k in ("p50_us", "p95_us", "p99_us", "max_us"))  # noqa: E731
        rows.append([f"sequential p50 / p95 / p99 / max, ms (primary): {config}", f(s1), f(s2), f"p50 {ms(s2['p50_us'] - s1['p50_us']):+.2f}"])
        p1 = [r["sequential"][config]["p99_us"] for r in b1.values()]
        p2 = [r["sequential"][config]["p99_us"] for r in b2.values()]
        rows.append([f"sequential p99 range over 5 runs, ms: {config}", f"{ms(min(p1)):.2f}-{ms(max(p1)):.2f}", f"{ms(min(p2)):.2f}-{ms(max(p2)):.2f}", ""])
    for config in ["direct", "policy-only", "full", "full+journal"]:
        for clients in [1, 2, 4, 8, 16]:
            t1, t2 = cell(b1, config, clients, "throughput_calls_per_s"), cell(b2, config, clients, "throughput_calls_per_s")
            m1, m2 = st.median(t1), st.median(t2)
            rows.append([f"throughput, calls/s, median [min-max]: {config} @ {clients}", f"{m1:.1f} [{min(t1):.1f}-{max(t1):.1f}]",
                         f"{m2:.1f} [{min(t2):.1f}-{max(t2):.1f}]", f"{100 * (m2 - m1) / m1:+.1f} %"])
    for config in ["direct", "policy-only", "full", "full+journal"]:
        for clients in [1, 16]:
            f = lambda runs: " / ".join(f"{ms(st.median(cell(runs, config, clients, k))):.2f}" for k in ("p50_us", "p95_us", "p99_us", "max_us"))  # noqa: E731
            rows.append([f"latency under load p50 / p95 / p99 / max, ms (median of 5): {config} @ {clients}", f(b1), f(b2), ""])
        c1, c2 = cell(b1, config, 1, "cpu_ms_per_call"), cell(b2, config, 1, "cpu_ms_per_call")
        rows.append([f"CPU per call at 1 client, ms, median [min-max]: {config}", f"{st.median(c1):.2f} [{min(c1):.2f}-{max(c1):.2f}]",
                     f"{st.median(c2):.2f} [{min(c2):.2f}-{max(c2):.2f}]", f"{st.median(c2) - st.median(c1):+.2f}"])
        k1, k2 = cell(b1, config, 16, "cpu_cores_busy"), cell(b2, config, 16, "cpu_cores_busy")
        rows.append([f"cores busy at 16 clients, median [min-max]: {config}", f"{st.median(k1):.2f} [{min(k1):.2f}-{max(k1):.2f}]",
                     f"{st.median(k2):.2f} [{min(k2):.2f}-{max(k2):.2f}]", ""])
        a1, a2 = cell(b1, config, 1, "alloc_kib_per_call"), cell(b2, config, 1, "alloc_kib_per_call")
        rows.append([f"allocation per call at 1 client, KiB, median of 5 runs: {config}", f"{st.median(a1):.0f}", f"{st.median(a2):.0f}", f"{st.median(a2) - st.median(a1):+.0f}"])
        a1 = [v for n in (1, 2, 4, 8, 16) for v in cell(b1, config, n, "alloc_kib_per_call")]
        a2 = [v for n in (1, 2, 4, 8, 16) for v in cell(b2, config, n, "alloc_kib_per_call")]
        rows.append([f"allocation per call, KiB, median of all cells: {config}", f"{st.median(a1):.0f}", f"{st.median(a2):.0f}", f"{st.median(a2) - st.median(a1):+.0f}"])
    for key, label in (("peak_heap_mib", "peak Go heap, MiB (max over cells and runs)"), ("peak_working_set_mib", "peak working set, MiB (max over cells and runs)")):
        v1 = max(x[key] for r in b1.values() for x in r["concurrent"])
        v2 = max(x[key] for r in b2.values() for x in r["concurrent"])
        rows.append([label, f"{v1:.1f}", f"{v2:.1f}", f"{v2 - v1:+.1f}"])
    for key, label, scale in (("cpu_utilization_cores", "sequential phase: cores busy", 1), ("peak_working_set_bytes", "sequential phase: peak working set, MiB", 2 ** 20),
                              ("alloc_bytes", "sequential phase: allocated, GiB", 2 ** 30), ("wall_ms", "sequential phase: wall time, s", 1000)):
        v1 = [r["sequential_phase_resources"][key] / scale for r in b1.values()]
        v2 = [r["sequential_phase_resources"][key] / scale for r in b2.values()]
        rows.append([f"{label} (range over 5 runs)", f"{min(v1):.2f}-{max(v1):.2f}", f"{min(v2):.2f}-{max(v2):.2f}", ""])
    out = os.path.join(HERE, "comparison-build1.csv")
    with open(out, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["measure", "build 1 (2026-10-08, primary R3)", "build 2 (2026-10-10, primary R2)", "change"])
        writer.writerows(rows)
    for row in rows:
        print(" | ".join(row))
    print("wrote", out)


if __name__ == "__main__":
    main()
