# Cost of evidence

Local measurements on one computer under normal desktop load; absolute values depend on the disk, the file system, antivirus scanning and the Windows timer. Gateway latencies are quantized to the clock granularity.

- Command: `agentgate-eval -host-label review-host cost -n 2000 -batches 5 -repeat 20 -out <path>/cost -work <work>`; Go go1.26.6 on windows/amd64, 12 CPUs; clock granularity 0.013 ms; total 53 s.
- Source run: run-20261010-043443-111e14 (self-test, 20 suites, SELF-TEST PASSED in autonomous flag mode (320/320 scenario runs = 16 scenarios x 20, 40 skipped as human-approval only, 60/60 custom requests, verifier VERIFIED / ANCHORED, 8/8 tamper attacks detected, 4/4 revision checks)), 2986 entries, 4852890 bytes of audit.jsonl.

## (a) audit.Append cost per entry

Per-entry cost of audit.Append, from timed batches of consecutive appends of the run's own events (replayed in order) into a fresh log per batch; per-entry = batch time / appends. Corpus: 2986 real entries, mean 1625 bytes per line. 5 batches x 2000 appends per mode.

| Mode | What it does | Median us/entry | Min | Max | Entries/s (from median) |
|---|---|---|---|---|---|
| durable | default: write line, fsync audit.jsonl, replace head.json via a synced temporary file and rename | 1735.1 | 1726.7 | 1771.5 | 576 |
| no-fsync | same writes as durable, both fsync calls skipped (experiment only) | 515.2 | 505.1 | 522.3 | 1941 |
| sign-only | entry and head encoded, hashed and Ed25519-signed; nothing written (experiment only) | 53.0 | 50.9 | 53.6 | 18868 |

Derived: fsync = 1219.9 us/entry, file writes (line + head replace) = 462.2 us/entry. fsync cost = durable median - no-fsync median; write cost = no-fsync median - sign-only median (differences of medians).

## (b) Gateway call latency by outcome

Wall-clock time of each agent MCP tools/call at the gateway's MCP handler (request received to response complete), from the demo self-test's own timer. Includes the gateway's audit appends and, for applied calls, the loopback HTTP round trip to the simulated provider. Outcome is the result kind the agent received; (resumed) marks the call that resumes after a human decision; applied (duplicate) is a repeated identical call (replay scenario) answered with the original result, with no new effect and no EFFECT_EXECUTED entry (identified from the matched audit segment).

| Outcome | n | Median ms | p95 ms | Mean ms | Max ms | Gateway entries/call | Est. append ms (share of median) | Est. fsync ms |
|---|---|---|---|---|---|---|---|---|
| applied | 202 | 16.38 | 57.98 | 21.96 | 62.29 | 6 | 10.41 (64%) | 7.32 |
| applied (duplicate) | 61 | 5.00 | 6.72 | 6.92 | 76.23 | 2 | 3.47 (69%) | 2.44 |
| denied | 179 | 7.26 | 48.60 | 11.42 | 134.09 | 3 | 5.21 (72%) | 3.66 |
| mcp_rejected | 20 | 2.00 | 5.05 | 4.15 | 43.98 | 0 | 0.00 (0%) | 0.00 |
| refused | 40 | 4.00 | 7.00 | 5.99 | 45.56 | 2 | 3.47 (87%) | 2.44 |
| uncertain | 1 | 16.00 | n<20 | 16.00 | 16.00 | 6 | 10.41 (65%) | 7.32 |
| all calls | 503 | 8.00 | 56.67 | 14.40 | 134.09 | - | - | - |

503 timed gateway calls, 503 agent call segments (AGENT_PROPOSED..AGENT_RECEIVED) in the audit log; calls are sequential in the self-test, so the i-th call is matched with the i-th segment when the counts agree.

(c) The append share is an estimate (gateway entries per call x durable per-entry median from (a)), not a measurement with the recorder switched off: the gateway fails closed without its recorder.
