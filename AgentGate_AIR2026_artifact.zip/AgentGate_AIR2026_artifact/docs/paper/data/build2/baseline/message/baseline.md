# Baselines and load

Local measurements on one machine with simulated providers over loopback. They compare matched configurations of this prototype under one synthetic workload; they are not a general performance claim, and repeated timing calls are not independent workloads.

Command: `agentgate-eval -host-label review-host baseline -out <path>/M1 -work <work> -workload message -configs direct,policy-only,full,full+journal`. Workload: message. Go go1.26.6 on windows/amd64, 12 CPUs, GOMAXPROCS 12.  
Timer: QueryPerformanceCounter (kernel32 via golang.org/x/sys/windows), frequency 10000000 Hz, tick 100.0 ns. Wall-clock step observed for time.Now: 1.0000 ms.

## Configurations

- **direct**: no gateway: normalize (gateway normalizer), adapters.Prepare, adapters.HTTPTransport to the provider, verify the provider receipt
- **policy-only**: gateway with policy, grant, capability and signed receipts; audit sink off, no operation journal
- **full**: policy-only plus the signed hash-chained audit log, durable (fsync per entry)
- **full+journal**: full plus the fsynced operation journal
- **full-flagged**: full; the request is above the automatic limit and is flagged for audit

## Method

- Identical transport: every configuration is reached by JSON-RPC tools/call over loopback HTTP (keep-alive client, one per configuration) and reaches the provider with the adapter's HTTP transport (one fresh TCP connection per provider request).
- Identical provider: a provider host (internal/simulator behind its own loopback listener and key); every configuration has its own instance (same code, same transport, its own state) per sequential block and per concurrent cell, so state growth is equal and each evidence folder's provider journal holds only its own effects.
- Sequential: 500 paired trials in blocks of 50; in each trial every configuration gets one call, in an order rotated by one position per trial; each block starts fresh (provider, gateways, audit logs, journal) after 10 warm-up calls per configuration.
- Concurrent: client counts [1 2 4 8 16]; each configuration alone per cell, 10 warm-up calls then 400 measured calls split over the clients, back to back; CPU time is the whole process (client, server, gateway, provider host), memory peaks are sampled every 5ms.
- Every observation is kept: raw CSVs hold warm-up calls (marked) and every measured call, failed or not; summaries use every measured call (no outlier removal).
- Paired differences: per trial b - a; median with a distribution-free 95% interval (sign test order statistics), mean, and the share of trials in which b was slower.

## Sequential, paired trials (500 trials, 10 blocks, 27.1 s)

Latency per call in microseconds (all measured calls).

| config | n | min | p50 | p90 | p95 | p99 | max | mean | not committed | audit entries/call | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| direct | 500 | 1116 | 1290 | 1548 | 1683 | 1832 | 2039 | 1325 | 0 | 0.00 |  |
| policy-only | 500 | 4009 | 4684 | 5051 | 5184 | 5522 | 5858 | 4682 | 0 | 0.00 |  |
| full | 500 | 14783 | 16046 | 17221 | 18944 | 20166 | 23792 | 16274 | 0 | 6.00 | ANCHORED x10 |
| full+journal | 500 | 18193 | 19446 | 21294 | 23116 | 24710 | 45465 | 19840 | 0 | 6.00 | ANCHORED x10 |

Paired differences (per trial, microseconds; 95% interval of the median from the sign test):

| difference | n | median | 95% CI | mean | p95 | share of trials slower |
|---|---|---|---|---|---|---|
| policy-only - direct | 500 | 3359 | [3306, 3399] | 3357 | 3949 | 100.0% |
| full - policy-only | 500 | 11391 | [11294, 11472] | 11592 | 14218 | 100.0% |
| full - direct | 500 | 14720 | [14644, 14801] | 14949 | 17500 | 100.0% |
| full+journal - full | 500 | 3430 | [3356, 3487] | 3566 | 7044 | 97.4% |
| full+journal - direct | 500 | 18134 | [18084, 18197] | 18515 | 21709 | 100.0% |

Whole sequential phase: CPU 20922 ms (user 13266, kernel 7656) over 27050 ms wall; 6090.7 MiB allocated; peak working set 49.4 MiB (sampled).

## Concurrent load

Each cell runs one configuration alone; latency in microseconds; CPU is the whole process.

| clients | config | calls | not committed | calls/s | p50 | p95 | p99 | max | CPU ms/call | CPU cores busy | KiB alloc/call | peak heap MiB | peak working set MiB | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | direct | 400 | 0 | 909.0 | 1002 | 1349 | 1496 | 1639 | 1.797 | 1.63 | 447.4 | 5.2 | 47.0 |  |
| 1 | policy-only | 400 | 0 | 218.3 | 4501 | 5046 | 5278 | 5808 | 5.938 | 1.30 | 2819.9 | 19.3 | 44.9 |  |
| 1 | full | 400 | 0 | 61.9 | 15811 | 18631 | 20151 | 20506 | 12.227 | 0.76 | 3232.9 | 40.4 | 66.3 | ANCHORED |
| 1 | full+journal | 400 | 0 | 51.0 | 19250 | 22279 | 23345 | 24022 | 13.242 | 0.68 | 3261.9 | 39.6 | 74.5 | ANCHORED |
| 2 | direct | 400 | 0 | 1636.6 | 1219 | 1467 | 1616 | 2458 | 1.992 | 3.26 | 457.1 | 45.6 | 81.9 |  |
| 2 | policy-only | 400 | 0 | 359.2 | 5521 | 6234 | 6692 | 7101 | 6.055 | 2.17 | 2840.9 | 18.6 | 81.1 |  |
| 2 | full | 400 | 0 | 88.8 | 22093 | 26135 | 27995 | 39282 | 12.148 | 1.08 | 3247.4 | 40.2 | 67.1 | ANCHORED |
| 2 | full+journal | 400 | 0 | 77.9 | 24845 | 29075 | 30014 | 53836 | 12.305 | 0.96 | 3270.8 | 39.5 | 67.3 | ANCHORED |
| 4 | direct | 400 | 0 | 2261.6 | 1664 | 2147 | 2361 | 3244 | 1.758 | 3.98 | 467.1 | 5.5 | 83.6 |  |
| 4 | policy-only | 400 | 0 | 559.6 | 6919 | 8860 | 10320 | 10858 | 6.445 | 3.61 | 2849.5 | 22.2 | 50.3 |  |
| 4 | full | 400 | 0 | 50.4 | 82512 | 127896 | 130534 | 142287 | 13.281 | 0.67 | 3250.7 | 38.5 | 66.6 | ANCHORED |
| 4 | full+journal | 400 | 0 | 87.5 | 45310 | 49662 | 52739 | 54129 | 13.906 | 1.22 | 3277.4 | 42.1 | 69.2 | ANCHORED |
| 8 | direct | 400 | 0 | 2603.2 | 2994 | 3634 | 4391 | 4839 | 1.445 | 3.76 | 466.7 | 44.5 | 84.1 |  |
| 8 | policy-only | 400 | 0 | 664.8 | 11818 | 15442 | 17359 | 21299 | 7.656 | 5.09 | 2847.5 | 20.7 | 52.5 |  |
| 8 | full | 400 | 0 | 91.9 | 86079 | 97522 | 114757 | 121715 | 10.977 | 1.01 | 3241.1 | 41.5 | 70.1 | ANCHORED |
| 8 | full+journal | 400 | 0 | 88.5 | 89763 | 97191 | 102101 | 124834 | 13.398 | 1.19 | 3268.7 | 40.8 | 69.9 | ANCHORED |
| 16 | direct | 400 | 0 | 3037.8 | 5223 | 5917 | 6332 | 6790 | 2.422 | 7.36 | 447.5 | 44.8 | 84.5 |  |
| 16 | policy-only | 400 | 0 | 690.1 | 22789 | 29813 | 38122 | 39060 | 8.516 | 5.88 | 2829.2 | 27.6 | 59.6 |  |
| 16 | full | 400 | 0 | 38.7 | 412819 | 464639 | 474443 | 500672 | 12.266 | 0.47 | 3235.5 | 42.2 | 73.1 | ANCHORED |
| 16 | full+journal | 400 | 0 | 32.4 | 495767 | 549487 | 562430 | 568721 | 16.484 | 0.53 | 3266.3 | 40.4 | 78.9 | ANCHORED |

CPU source: GetProcessTimes (user + kernel) (resolution: scheduler tick (about 15.6 ms on an idle system)). Memory: K32GetProcessMemoryInfo (working set), sampled every 5 ms; heap = runtime/metrics /memory/classes/heap/objects:bytes.

## Files

- concurrent_observations: `baseline-concurrent.csv`
- concurrent_summary: `baseline-concurrent-summary.csv`
- sequential_observations: `baseline-sequential.csv`
