# Baselines and load

Local measurements on one machine with simulated providers over loopback. They compare matched configurations of this prototype under one synthetic workload; they are not a general performance claim, and repeated timing calls are not independent workloads.

Command: `agentgate-eval -host-label review-host baseline -out <path>/R1 -work <work>`. Workload: financial. Go go1.26.6 on windows/amd64, 12 CPUs, GOMAXPROCS 12.  
Timer: QueryPerformanceCounter (kernel32 via golang.org/x/sys/windows), frequency 10000000 Hz, tick 100.0 ns. Wall-clock step observed for time.Now: 0.0100 ms.

## Configurations

- **direct**: no gateway: normalize (gateway normalizer), adapters.Prepare, adapters.HTTPTransport to the provider, verify the provider receipt
- **policy-only**: gateway with policy, grant, capability and signed receipts; audit sink off, no operation journal
- **full**: policy-only plus the signed hash-chained audit log, durable (fsync per entry)
- **full+journal**: full plus the fsynced operation journal
- **full-flagged**: full; the request is above the automatic limit and is flagged for audit

## Method

- Identical transport: every configuration is reached by JSON-RPC tools/call over loopback HTTP (keep-alive client, one per configuration) and reaches the provider with the adapter's HTTP transport (one fresh TCP connection per provider request).
- Identical provider: a provider host (internal/simulator behind its own loopback listener and key); every configuration has its own instance (same code, same transport, its own state) per sequential block and per concurrent cell, so state growth is equal and each evidence folder's provider journal holds only its own effects.
- Sequential: 500 paired trials in blocks of 50; in each trial every configuration gets one call, in an order rotated by one position per trial; each block starts fresh (provider, gateways, audit logs, journal) after 10 warm-up calls per configuration.
- Concurrent: client counts [1 2 4 8 16]; each configuration alone per cell, 10 warm-up calls then 400 measured calls split over the clients, back to back; CPU time is the whole process (client, server, gateway, provider host), memory peaks are sampled every 5ms.
- Every observation is kept: raw CSVs hold warm-up calls (marked) and every measured call, failed or not; summaries use every measured call (no outlier removal).
- Paired differences: per trial b - a; median with a distribution-free 95% interval (sign test order statistics), mean, and the share of trials in which b was slower.

## Sequential, paired trials (500 trials, 10 blocks, 36.8 s)

Latency per call in microseconds (all measured calls).

| config | n | min | p50 | p90 | p95 | p99 | max | mean | not committed | audit entries/call | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| direct | 500 | 1067 | 1232 | 1499 | 1683 | 1921 | 2078 | 1280 | 0 | 0.00 |  |
| policy-only | 500 | 3824 | 4353 | 4837 | 4984 | 5475 | 5910 | 4419 | 0 | 0.00 |  |
| full | 500 | 14433 | 15754 | 17594 | 19032 | 20451 | 24299 | 16065 | 0 | 6.00 | ANCHORED x10 |
| full+journal | 500 | 17930 | 18995 | 21000 | 22889 | 24735 | 28887 | 19412 | 0 | 6.00 | ANCHORED x10 |
| full-flagged | 500 | 14561 | 15509 | 16791 | 18166 | 20712 | 41407 | 15858 | 0 | 6.00 | ANCHORED x10 |

Paired differences (per trial, microseconds; 95% interval of the median from the sign test):

| difference | n | median | 95% CI | mean | p95 | share of trials slower |
|---|---|---|---|---|---|---|
| policy-only - direct | 500 | 3108 | [3076, 3160] | 3140 | 3780 | 100.0% |
| full - policy-only | 500 | 11376 | [11323, 11449] | 11646 | 14602 | 100.0% |
| full - direct | 500 | 14464 | [14410, 14526] | 14786 | 17703 | 100.0% |
| full+journal - full | 500 | 3273 | [3157, 3331] | 3347 | 6735 | 96.0% |
| full-flagged - full | 500 | -187 | [-270, -115] | -208 | 2388 | 39.4% |
| full+journal - direct | 500 | 17733 | [17679, 17771] | 18132 | 21481 | 100.0% |

Whole sequential phase: CPU 29156 ms (user 18938, kernel 10219) over 36762 ms wall; 7691.5 MiB allocated; peak working set 58.5 MiB (sampled).

## Concurrent load

Each cell runs one configuration alone; latency in microseconds; CPU is the whole process.

| clients | config | calls | not committed | calls/s | p50 | p95 | p99 | max | CPU ms/call | CPU cores busy | KiB alloc/call | peak heap MiB | peak working set MiB | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | direct | 400 | 0 | 956.6 | 955 | 1280 | 1374 | 1550 | 2.070 | 1.98 | 420.0 | 28.2 | 58.0 |  |
| 1 | policy-only | 400 | 0 | 224.2 | 4314 | 4994 | 7446 | 10656 | 6.016 | 1.35 | 2677.1 | 20.2 | 45.1 |  |
| 1 | full | 400 | 0 | 62.7 | 15563 | 18456 | 20566 | 22621 | 12.813 | 0.80 | 3045.0 | 39.2 | 64.7 | ANCHORED |
| 1 | full+journal | 400 | 0 | 51.6 | 18806 | 22530 | 24906 | 44060 | 11.719 | 0.60 | 3072.0 | 39.4 | 65.6 | ANCHORED |
| 2 | direct | 400 | 0 | 1663.8 | 1176 | 1490 | 1603 | 2322 | 2.070 | 3.44 | 429.1 | 47.0 | 80.4 |  |
| 2 | policy-only | 400 | 0 | 369.6 | 5292 | 6235 | 8076 | 9385 | 6.953 | 2.57 | 2696.0 | 19.6 | 73.6 |  |
| 2 | full | 400 | 0 | 89.8 | 21892 | 25759 | 27980 | 28536 | 12.188 | 1.09 | 3054.9 | 40.4 | 66.9 | ANCHORED |
| 2 | full+journal | 400 | 0 | 79.1 | 24619 | 28843 | 30227 | 34390 | 12.734 | 1.01 | 3086.3 | 39.2 | 73.2 | ANCHORED |
| 4 | direct | 400 | 0 | 2288.9 | 1624 | 2151 | 2465 | 3397 | 2.109 | 4.83 | 445.5 | 48.3 | 82.7 |  |
| 4 | policy-only | 400 | 0 | 568.8 | 6757 | 8657 | 9344 | 10853 | 7.305 | 4.16 | 2705.1 | 21.3 | 49.6 |  |
| 4 | full | 400 | 0 | 92.5 | 42203 | 47631 | 49606 | 52468 | 10.586 | 0.98 | 3056.3 | 39.7 | 67.0 | ANCHORED |
| 4 | full+journal | 400 | 0 | 87.3 | 44808 | 49743 | 56610 | 70885 | 15.039 | 1.31 | 3081.8 | 38.8 | 70.6 | ANCHORED |
| 8 | direct | 400 | 0 | 2687.4 | 2894 | 3550 | 4277 | 5487 | 2.266 | 6.09 | 439.1 | 44.7 | 84.6 |  |
| 8 | policy-only | 400 | 0 | 668.4 | 11396 | 15725 | 17917 | 19109 | 7.656 | 5.12 | 2701.9 | 20.7 | 53.6 |  |
| 8 | full | 400 | 0 | 92.2 | 86247 | 95920 | 98403 | 114204 | 11.172 | 1.03 | 3049.6 | 40.4 | 68.8 | ANCHORED |
| 8 | full+journal | 400 | 0 | 89.0 | 89707 | 96563 | 102065 | 131665 | 12.734 | 1.13 | 3084.8 | 41.2 | 70.2 | ANCHORED |
| 16 | direct | 400 | 0 | 3068.8 | 5005 | 5966 | 7609 | 8591 | 1.680 | 5.16 | 422.1 | 7.3 | 82.9 |  |
| 16 | policy-only | 400 | 0 | 705.8 | 22190 | 27943 | 35956 | 41167 | 8.086 | 5.71 | 2686.4 | 26.0 | 63.0 |  |
| 16 | full | 400 | 0 | 92.6 | 172221 | 180708 | 185861 | 217044 | 11.680 | 1.08 | 3041.1 | 41.7 | 72.3 | ANCHORED |
| 16 | full+journal | 400 | 0 | 86.3 | 183774 | 198712 | 211523 | 237319 | 14.414 | 1.24 | 3078.9 | 41.5 | 77.9 | ANCHORED |

CPU source: GetProcessTimes (user + kernel) (resolution: scheduler tick (about 15.6 ms on an idle system)). Memory: K32GetProcessMemoryInfo (working set), sampled every 5 ms; heap = runtime/metrics /memory/classes/heap/objects:bytes.

## Files

- concurrent_observations: `baseline-concurrent.csv`
- concurrent_summary: `baseline-concurrent-summary.csv`
- sequential_observations: `baseline-sequential.csv`
