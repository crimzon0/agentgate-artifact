# Baselines and load

Local measurements on one machine with simulated providers over loopback. They compare matched configurations of this prototype under one synthetic workload; they are not a general performance claim, and repeated timing calls are not independent workloads.

Command: `agentgate-eval -host-label review-host baseline -out <path>/R3 -work <work>`. Workload: financial. Go go1.26.6 on windows/amd64, 12 CPUs, GOMAXPROCS 12.  
Timer: QueryPerformanceCounter (kernel32 via golang.org/x/sys/windows), frequency 10000000 Hz, tick 100.0 ns. Wall-clock step observed for time.Now: 0.0063 ms.

## Configurations

- **direct**: no gateway: normalize (gateway normalizer), adapters.Prepare, adapters.HTTPTransport to the provider, verify the provider receipt
- **policy-only**: gateway with policy, grant, capability and signed receipts; audit sink off, no operation journal
- **full**: policy-only plus the signed hash-chained audit log, durable (fsync per entry)
- **full+journal**: full plus the fsynced operation journal
- **full-flagged**: full; the request is above the automatic limit and is flagged for audit

## Method

- Identical transport: every configuration is reached by JSON-RPC tools/call over loopback HTTP (keep-alive client, one per configuration) and reaches the provider with the adapter's HTTP transport (one fresh TCP connection per provider request).
- Identical provider: a provider host (internal/simulator behind its own loopback listener and key); every configuration has its own instance (same code, same transport, its own state) per sequential block and per concurrent cell, so state growth is equal and each evidence folder's provider journal holds only its own effects.
- Sequential: 500 paired trials in blocks of 50; in each trial every configuration gets one call, in an order rotated by one position per trial; each block starts fresh (provider, gateways, audit logs, journal) after 10 warm-up calls per configuration.
- Concurrent: client counts [1 2 4 8 16]; each configuration alone per cell, 10 warm-up calls then 400 measured calls split over the clients, back to back; CPU time is the whole process (client, server, gateway, provider host), memory peaks are sampled every 5ms.
- Every observation is kept: raw CSVs hold warm-up calls (marked) and every measured call, failed or not; summaries use every measured call (no outlier removal).
- Paired differences: per trial b - a; median with a distribution-free 95% interval (sign test order statistics), mean, and the share of trials in which b was slower.

## Sequential, paired trials (500 trials, 10 blocks, 36.8 s)

Latency per call in microseconds (all measured calls).

| config | n | min | p50 | p90 | p95 | p99 | max | mean | not committed | audit entries/call | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| direct | 500 | 1057 | 1232 | 1478 | 1648 | 1942 | 2068 | 1277 | 0 | 0.00 |  |
| policy-only | 500 | 3879 | 4401 | 4892 | 5062 | 5382 | 5962 | 4458 | 0 | 0.00 |  |
| full | 500 | 14729 | 15783 | 16979 | 18810 | 20335 | 21019 | 16038 | 0 | 6.00 | ANCHORED x10 |
| full+journal | 500 | 17779 | 19083 | 21271 | 22775 | 23997 | 27584 | 19477 | 0 | 6.00 | ANCHORED x10 |
| full-flagged | 500 | 14562 | 15612 | 16599 | 17866 | 20120 | 21156 | 15815 | 0 | 6.00 | ANCHORED x10 |

Paired differences (per trial, microseconds; 95% interval of the median from the sign test):

| difference | n | median | 95% CI | mean | p95 | share of trials slower |
|---|---|---|---|---|---|---|
| policy-only - direct | 500 | 3159 | [3128, 3199] | 3182 | 3870 | 100.0% |
| full - policy-only | 500 | 11334 | [11275, 11445] | 11580 | 14395 | 100.0% |
| full - direct | 500 | 14497 | [14447, 14555] | 14762 | 17535 | 100.0% |
| full+journal - full | 500 | 3280 | [3236, 3354] | 3438 | 7088 | 96.8% |
| full-flagged - full | 500 | -187 | [-266, -118] | -223 | 2096 | 39.8% |
| full+journal - direct | 500 | 17817 | [17750, 17884] | 18200 | 21412 | 100.0% |

Whole sequential phase: CPU 28625 ms (user 18562, kernel 10062) over 36809 ms wall; 7694.2 MiB allocated; peak working set 58.7 MiB (sampled).

## Concurrent load

Each cell runs one configuration alone; latency in microseconds; CPU is the whole process.

| clients | config | calls | not committed | calls/s | p50 | p95 | p99 | max | CPU ms/call | CPU cores busy | KiB alloc/call | peak heap MiB | peak working set MiB | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | direct | 400 | 0 | 945.4 | 972 | 1324 | 1410 | 1516 | 1.406 | 1.33 | 422.9 | 5.1 | 52.5 |  |
| 1 | policy-only | 400 | 0 | 228.8 | 4320 | 4802 | 4971 | 5594 | 6.094 | 1.39 | 2679.1 | 19.7 | 45.7 |  |
| 1 | full | 400 | 0 | 62.8 | 15557 | 18764 | 20338 | 21121 | 11.250 | 0.71 | 3046.2 | 38.5 | 63.8 | ANCHORED |
| 1 | full+journal | 400 | 0 | 51.8 | 18840 | 21987 | 23510 | 45193 | 11.836 | 0.61 | 3068.7 | 39.9 | 65.4 | ANCHORED |
| 2 | direct | 400 | 0 | 1646.0 | 1215 | 1417 | 1543 | 1794 | 1.836 | 3.02 | 434.2 | 5.2 | 80.3 |  |
| 2 | policy-only | 400 | 0 | 376.0 | 5282 | 5908 | 6184 | 6798 | 5.508 | 2.07 | 2699.3 | 19.8 | 75.2 |  |
| 2 | full | 400 | 0 | 89.6 | 22077 | 25734 | 27351 | 27906 | 12.500 | 1.12 | 3056.6 | 38.9 | 65.7 | ANCHORED |
| 2 | full+journal | 400 | 0 | 79.2 | 24701 | 28662 | 29294 | 30737 | 12.617 | 1.00 | 3083.2 | 38.6 | 68.6 | ANCHORED |
| 4 | direct | 400 | 0 | 2309.5 | 1618 | 2132 | 2296 | 2516 | 1.484 | 3.43 | 445.3 | 5.8 | 84.0 |  |
| 4 | policy-only | 400 | 0 | 587.2 | 6710 | 8517 | 9483 | 9943 | 6.719 | 3.94 | 2702.4 | 20.3 | 51.1 |  |
| 4 | full | 400 | 0 | 92.6 | 42230 | 47367 | 49275 | 59274 | 12.383 | 1.15 | 3057.4 | 40.4 | 67.9 | ANCHORED |
| 4 | full+journal | 400 | 0 | 87.9 | 44788 | 49627 | 54934 | 73959 | 12.891 | 1.13 | 3086.1 | 39.7 | 70.9 | ANCHORED |
| 8 | direct | 400 | 0 | 2839.0 | 2823 | 3352 | 3839 | 4055 | 2.227 | 6.32 | 433.1 | 42.1 | 85.9 |  |
| 8 | policy-only | 400 | 0 | 674.1 | 11527 | 14704 | 16641 | 20710 | 7.266 | 4.90 | 2705.5 | 21.3 | 51.5 |  |
| 8 | full | 400 | 0 | 41.6 | 205557 | 253876 | 263593 | 307763 | 13.555 | 0.56 | 3055.1 | 39.1 | 68.6 | ANCHORED |
| 8 | full+journal | 400 | 0 | 32.4 | 234880 | 283861 | 317979 | 350555 | 15.586 | 0.51 | 3084.7 | 39.7 | 70.3 | ANCHORED |
| 16 | direct | 400 | 0 | 2998.8 | 5186 | 6169 | 7819 | 9258 | 1.523 | 4.57 | 423.0 | 10.3 | 83.2 |  |
| 16 | policy-only | 400 | 0 | 723.1 | 21455 | 27158 | 37145 | 38985 | 6.914 | 5.00 | 2682.9 | 25.0 | 59.1 |  |
| 16 | full | 400 | 0 | 93.3 | 171255 | 180154 | 185610 | 218333 | 12.227 | 1.14 | 3044.0 | 41.4 | 71.3 | ANCHORED |
| 16 | full+journal | 400 | 0 | 88.5 | 178980 | 194527 | 210991 | 232791 | 13.516 | 1.20 | 3076.7 | 42.2 | 77.2 | ANCHORED |

CPU source: GetProcessTimes (user + kernel) (resolution: scheduler tick (about 15.6 ms on an idle system)). Memory: K32GetProcessMemoryInfo (working set), sampled every 5 ms; heap = runtime/metrics /memory/classes/heap/objects:bytes.

## Files

- concurrent_observations: `baseline-concurrent.csv`
- concurrent_summary: `baseline-concurrent-summary.csv`
- sequential_observations: `baseline-sequential.csv`
