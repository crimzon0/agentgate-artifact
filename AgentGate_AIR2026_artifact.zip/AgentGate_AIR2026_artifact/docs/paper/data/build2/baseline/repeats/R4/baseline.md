# Baselines and load

Local measurements on one machine with simulated providers over loopback. They compare matched configurations of this prototype under one synthetic workload; they are not a general performance claim, and repeated timing calls are not independent workloads.

Command: `agentgate-eval -host-label review-host baseline -out <path>/R4 -work <work>`. Workload: financial. Go go1.26.6 on windows/amd64, 12 CPUs, GOMAXPROCS 12.  
Timer: QueryPerformanceCounter (kernel32 via golang.org/x/sys/windows), frequency 10000000 Hz, tick 100.0 ns. Wall-clock step observed for time.Now: 0.9999 ms.

## Configurations

- **direct**: no gateway: normalize (gateway normalizer), adapters.Prepare, adapters.HTTPTransport to the provider, verify the provider receipt
- **policy-only**: gateway with policy, grant, capability and signed receipts; audit sink off, no operation journal
- **full**: policy-only plus the signed hash-chained audit log, durable (fsync per entry)
- **full+journal**: full plus the fsynced operation journal
- **full-flagged**: full; the request is above the automatic limit and is flagged for audit

## Method

- Identical transport: every configuration is reached by JSON-RPC tools/call over loopback HTTP (keep-alive client, one per configuration) and reaches the provider with the adapter's HTTP transport (one fresh TCP connection per provider request).
- Identical provider: a provider host (internal/simulator behind its own loopback listener and key); every configuration has its own instance (same code, same transport, its own state) per sequential block and per concurrent cell, so state growth is equal and each evidence folder's provider journal holds only its own effects.
- Sequential: 500 paired trials in blocks of 50; in each trial every configuration gets one call, in an order rotated by one position per trial; each block starts fresh (provider, gateways, audit logs, journal) after 10 warm-up calls per configuration.
- Concurrent: client counts [1 2 4 8 16]; each configuration alone per cell, 10 warm-up calls then 400 measured calls split over the clients, back to back; CPU time is the whole process (client, server, gateway, provider host), memory peaks are sampled every 5ms.
- Every observation is kept: raw CSVs hold warm-up calls (marked) and every measured call, failed or not; summaries use every measured call (no outlier removal).
- Paired differences: per trial b - a; median with a distribution-free 95% interval (sign test order statistics), mean, and the share of trials in which b was slower.

## Sequential, paired trials (500 trials, 10 blocks, 52.2 s)

Latency per call in microseconds (all measured calls).

| config | n | min | p50 | p90 | p95 | p99 | max | mean | not committed | audit entries/call | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| direct | 500 | 1065 | 1245 | 1496 | 1674 | 1927 | 2241 | 1288 | 0 | 0.00 |  |
| policy-only | 500 | 3859 | 4442 | 4928 | 5107 | 5924 | 6280 | 4513 | 0 | 0.00 |  |
| full | 500 | 14719 | 15965 | 57291 | 58927 | 64178 | 73511 | 23595 | 0 | 6.00 | ANCHORED x10 |
| full+journal | 500 | 18066 | 19453 | 61917 | 63110 | 68544 | 146218 | 29781 | 0 | 6.00 | ANCHORED x10 |
| full-flagged | 500 | 14575 | 15840 | 57025 | 59088 | 62521 | 68430 | 23284 | 0 | 6.00 | ANCHORED x10 |

Paired differences (per trial, microseconds; 95% interval of the median from the sign test):

| difference | n | median | 95% CI | mean | p95 | share of trials slower |
|---|---|---|---|---|---|---|
| policy-only - direct | 500 | 3189 | [3147, 3239] | 3225 | 3859 | 100.0% |
| full - policy-only | 500 | 11566 | [11438, 11651] | 19082 | 54646 | 100.0% |
| full - direct | 500 | 14677 | [14614, 14800] | 22307 | 57694 | 100.0% |
| full+journal - full | 500 | 3466 | [3307, 3585] | 6186 | 46481 | 82.4% |
| full-flagged - full | 500 | -169 | [-235, -31] | -311 | 41354 | 44.6% |
| full+journal - direct | 500 | 18178 | [18070, 18338] | 28494 | 61846 | 100.0% |

Whole sequential phase: CPU 29016 ms (user 18438, kernel 10578) over 52180 ms wall; 7691.1 MiB allocated; peak working set 57.9 MiB (sampled).

## Concurrent load

Each cell runs one configuration alone; latency in microseconds; CPU is the whole process.

| clients | config | calls | not committed | calls/s | p50 | p95 | p99 | max | CPU ms/call | CPU cores busy | KiB alloc/call | peak heap MiB | peak working set MiB | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | direct | 400 | 0 | 950.2 | 965 | 1300 | 1416 | 1468 | 2.031 | 1.93 | 420.2 | 4.8 | 51.9 |  |
| 1 | policy-only | 400 | 0 | 228.3 | 4311 | 4824 | 5099 | 5532 | 6.250 | 1.43 | 2680.1 | 20.4 | 45.4 |  |
| 1 | full | 400 | 0 | 62.9 | 15618 | 17964 | 20243 | 20651 | 9.922 | 0.62 | 3046.6 | 39.0 | 64.8 | ANCHORED |
| 1 | full+journal | 400 | 0 | 51.7 | 18908 | 22157 | 23843 | 24958 | 12.773 | 0.66 | 3071.7 | 39.4 | 65.8 | ANCHORED |
| 2 | direct | 400 | 0 | 1650.1 | 1197 | 1474 | 1665 | 2678 | 1.875 | 3.09 | 435.6 | 46.5 | 82.0 |  |
| 2 | policy-only | 400 | 0 | 374.1 | 5276 | 5965 | 6398 | 7045 | 5.273 | 1.97 | 2698.3 | 19.3 | 73.4 |  |
| 2 | full | 400 | 0 | 89.0 | 22275 | 26025 | 27637 | 28818 | 11.758 | 1.05 | 3056.6 | 39.5 | 66.3 | ANCHORED |
| 2 | full+journal | 400 | 0 | 78.8 | 24453 | 28861 | 35482 | 54882 | 11.992 | 0.94 | 3081.8 | 39.3 | 67.4 | ANCHORED |
| 4 | direct | 400 | 0 | 2385.1 | 1600 | 2083 | 2473 | 2882 | 2.383 | 5.68 | 439.0 | 45.8 | 84.8 |  |
| 4 | policy-only | 400 | 0 | 582.2 | 6684 | 8700 | 9890 | 10620 | 5.977 | 3.48 | 2703.4 | 20.8 | 49.8 |  |
| 4 | full | 400 | 0 | 92.7 | 42357 | 47366 | 50014 | 53202 | 12.109 | 1.12 | 3059.4 | 39.3 | 66.9 | ANCHORED |
| 4 | full+journal | 400 | 0 | 88.0 | 44786 | 49445 | 50977 | 55860 | 13.984 | 1.23 | 3089.6 | 40.7 | 80.0 | ANCHORED |
| 8 | direct | 400 | 0 | 2840.1 | 2839 | 3442 | 3763 | 4044 | 1.680 | 4.77 | 425.4 | 47.4 | 86.2 |  |
| 8 | policy-only | 400 | 0 | 676.4 | 11543 | 15326 | 16918 | 19365 | 6.875 | 4.65 | 2705.6 | 21.2 | 53.2 |  |
| 8 | full | 400 | 0 | 92.3 | 86427 | 96109 | 99579 | 114020 | 12.227 | 1.13 | 3055.5 | 40.6 | 69.8 | ANCHORED |
| 8 | full+journal | 400 | 0 | 87.7 | 90959 | 97933 | 116850 | 122949 | 13.242 | 1.16 | 3081.4 | 39.2 | 69.6 | ANCHORED |
| 16 | direct | 400 | 0 | 2977.9 | 5214 | 6241 | 9126 | 11425 | 2.148 | 6.40 | 425.2 | 45.4 | 83.5 |  |
| 16 | policy-only | 400 | 0 | 713.8 | 21586 | 27621 | 37222 | 44860 | 7.813 | 5.58 | 2687.6 | 25.6 | 61.3 |  |
| 16 | full | 400 | 0 | 92.5 | 172662 | 182698 | 185897 | 219782 | 12.305 | 1.14 | 3044.1 | 40.2 | 72.0 | ANCHORED |
| 16 | full+journal | 400 | 0 | 87.7 | 181799 | 189450 | 194630 | 234106 | 13.008 | 1.14 | 3080.8 | 40.1 | 78.9 | ANCHORED |

CPU source: GetProcessTimes (user + kernel) (resolution: scheduler tick (about 15.6 ms on an idle system)). Memory: K32GetProcessMemoryInfo (working set), sampled every 5 ms; heap = runtime/metrics /memory/classes/heap/objects:bytes.

## Files

- concurrent_observations: `baseline-concurrent.csv`
- concurrent_summary: `baseline-concurrent-summary.csv`
- sequential_observations: `baseline-sequential.csv`
