# Baselines and load

Local measurements on one machine with simulated providers over loopback. They compare matched configurations of this prototype under one synthetic workload; they are not a general performance claim, and repeated timing calls are not independent workloads.

Command: `agentgate-eval -host-label review-host baseline -out <path>/R5 -work <work>`. Workload: financial. Go go1.26.6 on windows/amd64, 12 CPUs, GOMAXPROCS 12.  
Timer: QueryPerformanceCounter (kernel32 via golang.org/x/sys/windows), frequency 10000000 Hz, tick 100.0 ns. Wall-clock step observed for time.Now: 0.0135 ms.

## Configurations

- **direct**: no gateway: normalize (gateway normalizer), adapters.Prepare, adapters.HTTPTransport to the provider, verify the provider receipt
- **policy-only**: gateway with policy, grant, capability and signed receipts; audit sink off, no operation journal
- **full**: policy-only plus the signed hash-chained audit log, durable (fsync per entry)
- **full+journal**: full plus the fsynced operation journal
- **full-flagged**: full; the request is above the automatic limit and is flagged for audit

## Method

- Identical transport: every configuration is reached by JSON-RPC tools/call over loopback HTTP (keep-alive client, one per configuration) and reaches the provider with the adapter's HTTP transport (one fresh TCP connection per provider request).
- Identical provider: a provider host (internal/simulator behind its own loopback listener and key); every configuration has its own instance (same code, same transport, its own state) per sequential block and per concurrent cell, so state growth is equal and each evidence folder's provider journal holds only its own effects.
- Sequential: 500 paired trials in blocks of 50; in each trial every configuration gets one call, in an order rotated by one position per trial; each block starts fresh (provider, gateways, audit logs, journal) after 10 warm-up calls per configuration.
- Concurrent: client counts [1 2 4 8 16]; each configuration alone per cell, 10 warm-up calls then 400 measured calls split over the clients, back to back; CPU time is the whole process (client, server, gateway, provider host), memory peaks are sampled every 5ms.
- Every observation is kept: raw CSVs hold warm-up calls (marked) and every measured call, failed or not; summaries use every measured call (no outlier removal).
- Paired differences: per trial b - a; median with a distribution-free 95% interval (sign test order statistics), mean, and the share of trials in which b was slower.

## Sequential, paired trials (500 trials, 10 blocks, 36.8 s)

Latency per call in microseconds (all measured calls).

| config | n | min | p50 | p90 | p95 | p99 | max | mean | not committed | audit entries/call | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| direct | 500 | 1044 | 1230 | 1442 | 1643 | 1991 | 2164 | 1269 | 0 | 0.00 |  |
| policy-only | 500 | 3844 | 4325 | 4839 | 4987 | 5502 | 6145 | 4406 | 0 | 0.00 |  |
| full | 500 | 14670 | 15727 | 17014 | 18822 | 20536 | 21283 | 16025 | 0 | 6.00 | ANCHORED x10 |
| full+journal | 500 | 17887 | 19048 | 20275 | 22657 | 24320 | 45282 | 19414 | 0 | 6.00 | ANCHORED x10 |
| full-flagged | 500 | 14452 | 15576 | 17231 | 18915 | 19999 | 23342 | 15882 | 0 | 6.00 | ANCHORED x10 |

Paired differences (per trial, microseconds; 95% interval of the median from the sign test):

| difference | n | median | 95% CI | mean | p95 | share of trials slower |
|---|---|---|---|---|---|---|
| policy-only - direct | 500 | 3098 | [3057, 3123] | 3136 | 3740 | 100.0% |
| full - policy-only | 500 | 11403 | [11325, 11466] | 11620 | 14572 | 100.0% |
| full - direct | 500 | 14479 | [14412, 14522] | 14756 | 17647 | 100.0% |
| full+journal - full | 500 | 3313 | [3197, 3403] | 3389 | 6609 | 96.2% |
| full-flagged - full | 500 | -134 | [-234, -51] | -143 | 3085 | 43.0% |
| full+journal - direct | 500 | 17787 | [17713, 17841] | 18146 | 21383 | 100.0% |

Whole sequential phase: CPU 28156 ms (user 18344, kernel 9812) over 36747 ms wall; 7688.0 MiB allocated; peak working set 57.0 MiB (sampled).

## Concurrent load

Each cell runs one configuration alone; latency in microseconds; CPU is the whole process.

| clients | config | calls | not committed | calls/s | p50 | p95 | p99 | max | CPU ms/call | CPU cores busy | KiB alloc/call | peak heap MiB | peak working set MiB | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | direct | 400 | 0 | 957.8 | 950 | 1284 | 1410 | 1511 | 1.797 | 1.72 | 421.5 | 28.9 | 53.9 |  |
| 1 | policy-only | 400 | 0 | 229.3 | 4285 | 4818 | 5284 | 5703 | 5.508 | 1.26 | 2672.7 | 19.7 | 45.4 |  |
| 1 | full | 400 | 0 | 62.5 | 15579 | 18484 | 20465 | 42138 | 11.953 | 0.75 | 3045.8 | 39.0 | 64.1 | ANCHORED |
| 1 | full+journal | 400 | 0 | 51.8 | 18914 | 21959 | 23447 | 24362 | 13.516 | 0.70 | 3073.2 | 39.6 | 65.9 | ANCHORED |
| 2 | direct | 400 | 0 | 1704.9 | 1165 | 1427 | 1548 | 1691 | 1.758 | 3.00 | 432.6 | 5.2 | 81.7 |  |
| 2 | policy-only | 400 | 0 | 382.7 | 5177 | 6014 | 6244 | 6396 | 7.305 | 2.80 | 2694.2 | 18.7 | 73.4 |  |
| 2 | full | 400 | 0 | 88.8 | 22272 | 25997 | 28069 | 29088 | 12.617 | 1.12 | 3052.9 | 39.6 | 66.2 | ANCHORED |
| 2 | full+journal | 400 | 0 | 79.0 | 24723 | 28998 | 29825 | 30540 | 14.063 | 1.11 | 3078.6 | 39.2 | 78.1 | ANCHORED |
| 4 | direct | 400 | 0 | 2341.4 | 1620 | 2140 | 2347 | 3621 | 1.680 | 3.93 | 439.2 | 43.1 | 84.3 |  |
| 4 | policy-only | 400 | 0 | 568.9 | 6878 | 8714 | 9246 | 10463 | 5.820 | 3.31 | 2709.4 | 21.0 | 49.5 |  |
| 4 | full | 400 | 0 | 91.4 | 42949 | 48779 | 57366 | 73854 | 11.016 | 1.01 | 3057.5 | 38.4 | 66.4 | ANCHORED |
| 4 | full+journal | 400 | 0 | 88.6 | 44653 | 49171 | 51636 | 54617 | 13.672 | 1.21 | 3084.8 | 39.6 | 67.0 | ANCHORED |
| 8 | direct | 400 | 0 | 2855.0 | 2825 | 3425 | 3808 | 4256 | 2.461 | 7.03 | 427.1 | 47.9 | 86.3 |  |
| 8 | policy-only | 400 | 0 | 671.4 | 11578 | 15400 | 19192 | 24432 | 7.227 | 4.85 | 2701.9 | 20.4 | 54.6 |  |
| 8 | full | 400 | 0 | 91.7 | 85764 | 98518 | 115435 | 125384 | 13.008 | 1.19 | 3051.7 | 40.8 | 69.7 | ANCHORED |
| 8 | full+journal | 400 | 0 | 88.3 | 90482 | 97309 | 100974 | 123204 | 11.758 | 1.04 | 3083.9 | 40.7 | 69.9 | ANCHORED |
| 16 | direct | 400 | 0 | 3007.6 | 5112 | 6061 | 8320 | 9266 | 2.383 | 7.17 | 426.3 | 43.9 | 82.9 |  |
| 16 | policy-only | 400 | 0 | 705.8 | 21958 | 27836 | 35799 | 36003 | 6.641 | 4.69 | 2684.2 | 26.0 | 62.7 |  |
| 16 | full | 400 | 0 | 92.1 | 172138 | 184946 | 200990 | 222339 | 12.227 | 1.13 | 3049.7 | 40.8 | 73.4 | ANCHORED |
| 16 | full+journal | 400 | 0 | 87.2 | 183289 | 192108 | 195554 | 231256 | 14.258 | 1.24 | 3073.5 | 40.6 | 81.0 | ANCHORED |

CPU source: GetProcessTimes (user + kernel) (resolution: scheduler tick (about 15.6 ms on an idle system)). Memory: K32GetProcessMemoryInfo (working set), sampled every 5 ms; heap = runtime/metrics /memory/classes/heap/objects:bytes.

## Files

- concurrent_observations: `baseline-concurrent.csv`
- concurrent_summary: `baseline-concurrent-summary.csv`
- sequential_observations: `baseline-sequential.csv`
