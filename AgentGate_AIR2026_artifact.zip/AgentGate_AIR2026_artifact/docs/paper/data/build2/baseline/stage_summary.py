"""Summarise the per-stage and witness push runs of build 2 (new in build 2).

    py docs/paper/data/build2/baseline/stage_summary.py

Reads stagecost/<run>/stagecost.json and witnesspush.json (run1..run3, run-corpus)
and writes stagecost/summary.csv. Rules of STAGE_COST.md (build 1):
- the quoted stage run is the synthetic run with the fewest uninstrumented
  appends over 10 ms (first on a tie);
- shares are group mean / staged-total mean (means add up, medians do not);
- the per-call comparison is the median of the 6-append sums (median against
  median) with the build-2 recorded-minus-mediated paired median of the primary
  run (11.29 ms, analysis.json), not with the 11.40 ms of build 1 that the test
  binary prints (it is compiled in);
- the serial rate uses the mean append and is compared with the build-2
  saturation throughput of full (median of the five runs at 4-16 clients).
"""
import csv
import json
import os
import statistics as st

HERE = os.path.dirname(os.path.abspath(__file__))
RUNS = ["run1", "run2", "run3", "run-corpus"]
GROUPS = ["encode + hash", "Ed25519 signing", "log line write", "log fsync", "temp head write", "head fsync", "head rename", "directory fsync"]


def main():
    with open(os.path.join(HERE, "analysis.json")) as handle:
        analysis = json.load(handle)
    primary = analysis["runs"]["primary"]
    recorded = next(p["median_us"] for p in primary["paired_differences"] if p["compare"] == "full - policy-only") / 1000.0
    fin = [r for n, r in analysis["runs"].items() if r["workload"] == "financial" and not n.startswith("supplementary-")]
    saturation = st.median([x["throughput_calls_per_s"] for r in fin for x in r["concurrent"] if x["config"] == "full" and x["clients"] in (4, 8, 16)])
    rows, stage = [], {}
    for run in RUNS:
        with open(os.path.join(HERE, "stagecost", run, "stagecost.json")) as handle:
            s = json.load(handle)
        stage[run] = s
        total = s["staged_total"]["mean_us"]
        groups = {g["name"]: g for g in s["groups"]}
        for name in GROUPS:
            g = groups[name]
            rows.append([run, "stage group", name, g["median_us"], g["p99_us"], g["mean_us"], g["max_us"], round(100 * g["mean_us"] / total, 2)])
        rows.append([run, "total", "staged total", s["staged_total"]["median_us"], s["staged_total"]["p99_us"], total, s["staged_total"]["max_us"], 100.0])
        a = s["append_uninstrumented"]
        rows.append([run, "total", "Append (uninstrumented)", a["median_us"], a["p99_us"], a["mean_us"], a["max_us"], ""])
        sums = s["per_call"]["consecutive_append_sums"]
        share = round(100 * sums["median_us"] / 1000.0 / recorded, 1) if s["per_call"]["blocks_are_calls"] else ""
        rows.append([run, "per call", "6 consecutive appends", sums["median_us"], sums["p99_us"], sums["mean_us"], sums["max_us"], share])
        rows.append([run, "per call", "serial rate calls/s from mean append (observed build-2 saturation %.1f)" % saturation,
                     "", "", round(1e6 / (6 * a["mean_us"]), 1), "", ""])
        rows.append([run, "count", "uninstrumented appends over 10 ms", "", "", s["per_call"]["appends_over_10ms"], "", ""])
        path = os.path.join(HERE, "stagecost", run, "witnesspush.json")
        if os.path.exists(path):
            with open(path) as handle:
                w = json.load(handle)
            for r in w["rows"]:
                rows.append([run, "witness", r["name"], r["median_us"], r["p99_us"], r["mean_us"], r["max_us"], ""])
    synthetic = ["run1", "run2", "run3"]
    quoted = min(synthetic, key=lambda r: (stage[r]["per_call"]["appends_over_10ms"], synthetic.index(r)))
    out = os.path.join(HERE, "stagecost", "summary.csv")
    with open(out, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["# quoted stage run (fewest appends over 10 ms): %s; recorded-minus-mediated median of build 2: %.2f ms; "
                         "full saturation of build 2: %.1f calls/s" % (quoted, recorded, saturation)])
        writer.writerow(["run", "kind", "row", "median_us", "p99_us", "mean_us", "max_us", "share_pct"])
        writer.writerows(rows)
    print("quoted", quoted, "recorded", round(recorded, 3), "saturation", saturation)
    medians = [stage[r]["append_uninstrumented"]["median_us"] for r in synthetic]
    print("Append median range over run1-run3: %.2f-%.2f us" % (min(medians), max(medians)))
    for row in rows:
        print(row)
    print("wrote", out)


if __name__ == "__main__":
    main()
