# Per-stage cost of a durable audit append

Per-entry stage times of audit.Append (WriteDurable) on one computer; absolute values depend on the disk, its fill level, the file system, antivirus scanning and background load. Only a run on an idle machine counts.

- Command: `go test -count=1 -v -run '^TestStageCost$' ./internal/audit/ -stagecost=10000 -stagecost.warmup=200 -stagecost.corpus=<run> -stagecost.work=<dir>`; go1.26.6 on windows/amd64, 12 CPUs; 34.8 s.
- Storage: volume C:\, NTFS, 2000 GB, 97 % full.
- Timer: QueryPerformanceCounter, 10000000 Hz (tick 100.0 ns); one read costs about 49.5 ns (a staged append has 18 reads).
- Corpus: replayed audit.jsonl of run (2462 events, cycled); mean line 2083 bytes. 200 warm-up + 10000 timed appends per path. staged and uninstrumented appends alternate entry by entry; the first position alternates from entry to entry and flips once per pass over the corpus, so each event goes first on each path equally often; two fresh logs on the same volume.

## Stages (us per entry)

| Stage | What | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode_entry | lock, checks, clock, Entry built (artifacts to base64), encodeCompact (encode + hash) | 10.80 | 38.40 | 11.98 | 135.00 |
| decode_entry | decodeEntry: the copy Append returns (encode + hash) | 18.00 | 56.90 | 19.65 | 159.90 |
| hash_entry | SHA-256 entry hash, hex (encode + hash) | 1.10 | 2.80 | 1.28 | 86.60 |
| sign_entry | Ed25519 signature of the entry hash, base64 (Ed25519 signing) | 17.10 | 49.50 | 18.74 | 131.60 |
| format_line | audit.jsonl line assembled (encode + hash) | 0.90 | 8.00 | 1.27 | 92.90 |
| write_line | write of the line to audit.jsonl (O_APPEND) (log line write) | 7.60 | 59.40 | 10.38 | 158.60 |
| fsync_log | fsync of audit.jsonl (FlushFileBuffers) (log fsync) | 395.80 | 747.11 | 425.36 | 26709.10 |
| bookkeeping | seq, head hash, time and stored line updated (encode + hash) | 0.30 | 0.60 | 0.34 | 137.40 |
| sign_head | Ed25519 signature of the head message, Head built (Ed25519 signing) | 18.10 | 46.60 | 19.67 | 126.40 |
| encode_head | head.json bytes (indented JSON) (encode + hash) | 4.30 | 12.70 | 4.95 | 94.90 |
| create_temp | os.CreateTemp next to head.json (temp head write) | 128.80 | 209.30 | 135.94 | 4906.50 |
| write_temp | write of the head bytes to the temporary file (temp head write) | 29.50 | 79.20 | 32.17 | 403.10 |
| fsync_temp | fsync of the temporary head file (head fsync) | 707.50 | 1315.41 | 743.32 | 2055.70 |
| close_temp | close of the temporary head file (temp head write) | 30.90 | 61.40 | 33.38 | 1789.00 |
| rename | rename over head.json (MoveFileEx, replace existing) (head rename) | 236.40 | 383.30 | 248.20 | 834.00 |
| fsync_dir | syncDir: returns at once on Windows (no directory fsync) (directory fsync) | 0.10 | 0.30 | 0.13 | 13.70 |
| head_digest | SHA-256 of the head bytes, computed and discarded by WriteJSONAtomic (encode + hash) | 0.90 | 2.50 | 0.99 | 40.80 |

## Groups (us per entry; a group's value is the sum of its stages within each entry)

| Group | Stages | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode + hash | encode_entry, decode_entry, hash_entry, format_line, bookkeeping, encode_head, head_digest | 37.70 | 89.30 | 40.46 | 201.90 |
| Ed25519 signing | sign_entry, sign_head | 35.50 | 73.40 | 38.41 | 154.10 |
| log line write | write_line | 7.60 | 59.40 | 10.38 | 158.60 |
| log fsync | fsync_log | 395.80 | 747.11 | 425.36 | 26709.10 |
| temp head write | create_temp, write_temp, close_temp | 192.00 | 300.90 | 201.49 | 4983.80 |
| head fsync | fsync_temp | 707.50 | 1315.41 | 743.32 | 2055.70 |
| head rename | rename | 236.40 | 383.30 | 248.20 | 834.00 |
| directory fsync | fsync_dir | 0.10 | 0.30 | 0.13 | 13.70 |
| staged total | sum of the stages of one staged append (includes the timer reads between stages) | 1650.00 | 2604.01 | 1707.77 | 29082.80 |
| Append | audit.Append timed as a whole on the second log (no timer reads inside) | 1646.55 | 2601.10 | 1702.46 | 11172.30 |

## Per call (6 gateway entries)

- Sums of 6 consecutive appends (not a call) (1666 blocks): median 9.94 ms, p99 12.80 ms, mean 10.21 ms; share of the recorded-minus-mediated median: n/a, the blocks of a replayed run are not calls.
- Serial rate predicted from the mean append: 1e6 / (6 x 1702.46 us) = 97.9 calls/s (observed in the baseline: 94.3).
- Uninstrumented appends over 10 ms: 1 of 10000.

With a replayed run, six consecutive entries are not one call (the run also holds agent and run entries, and its lines have another mean size), so no share of the recorded-minus-mediated median is given. Appends of one log are serialized by its mutex, so with everything else running in parallel the log predicts about 1e6 / (entries per call x mean append us) calls/s for calls of this corpus's entries; the mean, not the median, sets that rate, so slow flushes lower it.

- Directory fsync: none on Windows: AgentGate's syncDir returns at once there (audit.go), so the fsync_dir stage times only that call. On other systems syncDir opens and fsyncs the run directory once per append, after the rename.
- Witness update: measured separately by internal/headwitness's TestWitnessPushCost (push_bench_test.go): a push is a separate round trip to the witness after the append. No reported latency includes one (the baseline runs no witness; the demo pushes the head after each agent step, outside the gateway call).
