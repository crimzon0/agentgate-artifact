# Per-stage cost of a durable audit append

Per-entry stage times of audit.Append (WriteDurable) on one computer; absolute values depend on the disk, its fill level, the file system, antivirus scanning and background load. Only a run on an idle machine counts.

- Command: `go test -count=1 -v -run '^TestStageCost$' ./internal/audit/ -stagecost=10000 -stagecost.warmup=200 -stagecost.work=<dir>`; go1.26.6 on windows/amd64, 12 CPUs; 35.0 s.
- Storage: volume C:\, NTFS, 2000 GB, 97 % full.
- Timer: QueryPerformanceCounter, 10000000 Hz (tick 100.0 ns); one read costs about 57.8 ns (a staged append has 18 reads).
- Corpus: synthetic six-entry financial call (stageCallShape) (6 events, cycled); mean line 2133 bytes. 200 warm-up + 10000 timed appends per path. staged and uninstrumented appends alternate entry by entry; the first position alternates from entry to entry and flips once per pass over the corpus, so each event goes first on each path equally often; two fresh logs on the same volume.

## Stages (us per entry)

| Stage | What | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode_entry | lock, checks, clock, Entry built (artifacts to base64), encodeCompact (encode + hash) | 10.10 | 34.40 | 11.05 | 207.50 |
| decode_entry | decodeEntry: the copy Append returns (encode + hash) | 16.90 | 52.00 | 18.77 | 288.40 |
| hash_entry | SHA-256 entry hash, hex (encode + hash) | 1.10 | 3.10 | 1.29 | 75.00 |
| sign_entry | Ed25519 signature of the entry hash, base64 (Ed25519 signing) | 17.00 | 50.80 | 18.74 | 142.40 |
| format_line | audit.jsonl line assembled (encode + hash) | 1.00 | 8.20 | 1.37 | 117.40 |
| write_line | write of the line to audit.jsonl (O_APPEND) (log line write) | 7.80 | 57.30 | 10.04 | 170.40 |
| fsync_log | fsync of audit.jsonl (FlushFileBuffers) (log fsync) | 397.60 | 733.32 | 423.68 | 1498.00 |
| bookkeeping | seq, head hash, time and stored line updated (encode + hash) | 0.20 | 0.60 | 0.33 | 172.80 |
| sign_head | Ed25519 signature of the head message, Head built (Ed25519 signing) | 18.10 | 46.30 | 19.70 | 252.10 |
| encode_head | head.json bytes (indented JSON) (encode + hash) | 4.30 | 13.30 | 4.98 | 139.10 |
| create_temp | os.CreateTemp next to head.json (temp head write) | 129.10 | 210.60 | 135.73 | 1753.90 |
| write_temp | write of the head bytes to the temporary file (temp head write) | 29.80 | 74.81 | 32.42 | 175.50 |
| fsync_temp | fsync of the temporary head file (head fsync) | 709.30 | 1312.91 | 745.93 | 1901.60 |
| close_temp | close of the temporary head file (temp head write) | 31.20 | 63.40 | 33.45 | 2768.40 |
| rename | rename over head.json (MoveFileEx, replace existing) (head rename) | 236.40 | 391.60 | 250.79 | 3247.70 |
| fsync_dir | syncDir: returns at once on Windows (no directory fsync) (directory fsync) | 0.10 | 0.20 | 0.13 | 76.90 |
| head_digest | SHA-256 of the head bytes, computed and discarded by WriteJSONAtomic (encode + hash) | 0.90 | 2.50 | 0.97 | 50.60 |

## Groups (us per entry; a group's value is the sum of its stages within each entry)

| Group | Stages | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode + hash | encode_entry, decode_entry, hash_entry, format_line, bookkeeping, encode_head, head_digest | 35.70 | 86.91 | 38.75 | 307.90 |
| Ed25519 signing | sign_entry, sign_head | 35.40 | 73.80 | 38.43 | 276.50 |
| log line write | write_line | 7.80 | 57.30 | 10.04 | 170.40 |
| log fsync | fsync_log | 397.60 | 733.32 | 423.68 | 1498.00 |
| temp head write | create_temp, write_temp, close_temp | 192.90 | 297.90 | 201.61 | 2967.80 |
| head fsync | fsync_temp | 709.30 | 1312.91 | 745.93 | 1901.60 |
| head rename | rename | 236.40 | 391.60 | 250.79 | 3247.70 |
| directory fsync | fsync_dir | 0.10 | 0.20 | 0.13 | 76.90 |
| staged total | sum of the stages of one staged append (includes the timer reads between stages) | 1656.60 | 2604.70 | 1709.37 | 4710.40 |
| Append | audit.Append timed as a whole on the second log (no timer reads inside) | 1653.85 | 2606.63 | 1713.58 | 27693.00 |

## Per call (6 gateway entries)

- Sums of 6 consecutive appends (one call) (1666 blocks): median 9.99 ms, p99 12.84 ms, mean 10.28 ms; the median is 88 % of the 11.40 ms recorded-minus-mediated paired median (not an exact decomposition).
- Serial rate predicted from the mean append: 1e6 / (6 x 1713.58 us) = 97.3 calls/s (observed in the baseline: 94.3).
- Uninstrumented appends over 10 ms: 2 of 10000.

With the synthetic corpus any six consecutive entries hold each event of the call once, so a block sum is one call's worth of appends. It is not an exact decomposition of the recorded-minus-mediated median: that median also contains the gateway's work to build the six events (not timed here), and the two figures come from different measurements (a paired difference of call latencies in the baseline session against a sum of appends timed here on their own). Appends of one log are serialized by its mutex, so with everything else running in parallel the log predicts about 1e6 / (entries per call x mean append us) calls/s for calls of this corpus's entries; the mean, not the median, sets that rate, so slow flushes lower it.

- Directory fsync: none on Windows: AgentGate's syncDir returns at once there (audit.go), so the fsync_dir stage times only that call. On other systems syncDir opens and fsyncs the run directory once per append, after the rename.
- Witness update: measured separately by internal/headwitness's TestWitnessPushCost (push_bench_test.go): a push is a separate round trip to the witness after the append. No reported latency includes one (the baseline runs no witness; the demo pushes the head after each agent step, outside the gateway call).
