# Witness update cost

Witness update cost on one computer, witness and client in one process over loopback; absolute values depend on the disk, its fill level, the file system, antivirus scanning and background load. Only a run on an idle machine counts.

- Command: `go test -count=1 -v -run '^TestWitnessPushCost$' ./internal/headwitness/ -witnesspush=2000 -witnesspush.warmup=50`; go1.26.6 on windows/amd64, 12 CPUs; 152.5 s.
- Storage: volume C:\, NTFS, 2000 GB, 97 % full (the test temporary folder).
- Timer: QueryPerformanceCounter, 10000000 Hz.
- 50 warm-up + 2000 timed calls per mode; mean audit line 2107 bytes. per-call and per-entry modes alternate call by call, first position alternating; one witness, two registered runs, one volume.

| Row | What | n | Median (us) | p99 (us) | Mean (us) | Max (us) |
|---|---|---|---|---|---|---|
| push per call | PushHeadWithEntries with the head and 6 new lines (round trip, witness checks, cosignature, store fsync) | 2000 | 1300.10 | 2004.67 | 1567.76 | 35568.90 |
| save per call | audit.WriteJSONAtomic of the cosigned head (temporary file, fsync, rename), as the demo saves it | 2000 | 1015.00 | 1499.25 | 1278.47 | 36435.00 |
| push per entry | PushHeadWithEntries with the head and 1 new line | 12000 | 826.70 | 1369.52 | 1086.72 | 38861.60 |
| save per entry | audit.WriteJSONAtomic of the cosigned head | 12000 | 998.60 | 1522.03 | 1243.28 | 52076.50 |
| 6 per-entry pushes and saves | sum over the 6 entries of one call when every entry is pushed | 2000 | 11132.85 | 45459.31 | 13980.00 | 61973.00 |

A witness update is not part of any latency in the paper: the baseline runs no witness and the demo pushes after each agent step, outside the gateway call. These rows say what a deployment would add per call if each call waited for one push (push per call plus save per call) or for one push per entry. The witness serializes pushes with one mutex and fsyncs its store once per push.
