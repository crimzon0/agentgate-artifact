# Per-stage cost of a durable audit append

Per-entry stage times of audit.Append (WriteDurable) on one computer; absolute values depend on the disk, its fill level, the file system, antivirus scanning and background load. Only a run on an idle machine counts.

- Command: `go test -count=1 -v -run '^TestStageCost$' ./internal/audit/ -stagecost=10000 -stagecost.warmup=200 -stagecost.work=<dir>`; go1.26.6 on windows/amd64, 12 CPUs; 34.7 s.
- Storage: volume C:\, NTFS, 2000 GB, 97 % full.
- Timer: QueryPerformanceCounter, 10000000 Hz (tick 100.0 ns); one read costs about 47.5 ns (a staged append has 18 reads).
- Corpus: synthetic six-entry financial call (stageCallShape) (6 events, cycled); mean line 2133 bytes. 200 warm-up + 10000 timed appends per path. staged and uninstrumented appends alternate entry by entry; the first position alternates from entry to entry and flips once per pass over the corpus, so each event goes first on each path equally often; two fresh logs on the same volume.

## Stages (us per entry)

| Stage | What | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode_entry | lock, checks, clock, Entry built (artifacts to base64), encodeCompact (encode + hash) | 10.10 | 30.81 | 11.02 | 114.50 |
| decode_entry | decodeEntry: the copy Append returns (encode + hash) | 17.10 | 51.60 | 18.87 | 169.10 |
| hash_entry | SHA-256 entry hash, hex (encode + hash) | 1.10 | 2.80 | 1.26 | 108.10 |
| sign_entry | Ed25519 signature of the entry hash, base64 (Ed25519 signing) | 17.00 | 49.30 | 18.66 | 111.10 |
| format_line | audit.jsonl line assembled (encode + hash) | 0.90 | 6.80 | 1.29 | 50.10 |
| write_line | write of the line to audit.jsonl (O_APPEND) (log line write) | 8.00 | 60.00 | 10.77 | 136.60 |
| fsync_log | fsync of audit.jsonl (FlushFileBuffers) (log fsync) | 396.60 | 739.21 | 423.30 | 7884.30 |
| bookkeeping | seq, head hash, time and stored line updated (encode + hash) | 0.20 | 0.60 | 0.35 | 116.70 |
| sign_head | Ed25519 signature of the head message, Head built (Ed25519 signing) | 18.00 | 44.40 | 19.54 | 119.40 |
| encode_head | head.json bytes (indented JSON) (encode + hash) | 4.20 | 12.20 | 4.86 | 143.80 |
| create_temp | os.CreateTemp next to head.json (temp head write) | 128.00 | 202.40 | 135.06 | 4753.70 |
| write_temp | write of the head bytes to the temporary file (temp head write) | 29.60 | 72.22 | 32.11 | 175.70 |
| fsync_temp | fsync of the temporary head file (head fsync) | 707.40 | 1318.10 | 744.81 | 2203.20 |
| close_temp | close of the temporary head file (temp head write) | 31.00 | 59.90 | 33.23 | 2591.20 |
| rename | rename over head.json (MoveFileEx, replace existing) (head rename) | 230.60 | 372.90 | 244.15 | 2234.90 |
| fsync_dir | syncDir: returns at once on Windows (no directory fsync) (directory fsync) | 0.10 | 0.20 | 0.12 | 10.60 |
| head_digest | SHA-256 of the head bytes, computed and discarded by WriteJSONAtomic (encode + hash) | 0.90 | 2.30 | 0.96 | 37.00 |

## Groups (us per entry; a group's value is the sum of its stages within each entry)

| Group | Stages | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode + hash | encode_entry, decode_entry, hash_entry, format_line, bookkeeping, encode_head, head_digest | 35.80 | 84.80 | 38.61 | 251.30 |
| Ed25519 signing | sign_entry, sign_head | 35.30 | 73.40 | 38.20 | 141.70 |
| log line write | write_line | 8.00 | 60.00 | 10.77 | 136.60 |
| log fsync | fsync_log | 396.60 | 739.21 | 423.30 | 7884.30 |
| temp head write | create_temp, write_temp, close_temp | 191.60 | 286.10 | 200.40 | 4958.80 |
| head fsync | fsync_temp | 707.40 | 1318.10 | 744.81 | 2203.20 |
| head rename | rename | 230.60 | 372.90 | 244.15 | 2234.90 |
| directory fsync | fsync_dir | 0.10 | 0.20 | 0.12 | 10.60 |
| staged total | sum of the stages of one staged append (includes the timer reads between stages) | 1644.20 | 2615.23 | 1700.36 | 9307.40 |
| Append | audit.Append timed as a whole on the second log (no timer reads inside) | 1641.00 | 2600.12 | 1701.67 | 27452.60 |

## Per call (6 gateway entries)

- Sums of 6 consecutive appends (one call) (1666 blocks): median 9.91 ms, p99 12.72 ms, mean 10.21 ms; the median is 87 % of the 11.40 ms recorded-minus-mediated paired median (not an exact decomposition).
- Serial rate predicted from the mean append: 1e6 / (6 x 1701.67 us) = 97.9 calls/s (observed in the baseline: 94.3).
- Uninstrumented appends over 10 ms: 3 of 10000.

With the synthetic corpus any six consecutive entries hold each event of the call once, so a block sum is one call's worth of appends. It is not an exact decomposition of the recorded-minus-mediated median: that median also contains the gateway's work to build the six events (not timed here), and the two figures come from different measurements (a paired difference of call latencies in the baseline session against a sum of appends timed here on their own). Appends of one log are serialized by its mutex, so with everything else running in parallel the log predicts about 1e6 / (entries per call x mean append us) calls/s for calls of this corpus's entries; the mean, not the median, sets that rate, so slow flushes lower it.

- Directory fsync: none on Windows: AgentGate's syncDir returns at once there (audit.go), so the fsync_dir stage times only that call. On other systems syncDir opens and fsyncs the run directory once per append, after the rename.
- Witness update: measured separately by internal/headwitness's TestWitnessPushCost (push_bench_test.go): a push is a separate round trip to the witness after the append. No reported latency includes one (the baseline runs no witness; the demo pushes the head after each agent step, outside the gateway call).
