#!/usr/bin/env bash
# Drive one complete baseline session: five financial runs (R1-R5) and one
# message run (M1), full default sizes, one after another, each through
# run_baseline.sh (typeperf system-load log + per-process CPU snapshots).
#
#   EVAL=path/to/agentgate-eval.exe [HOST_LABEL=NAME] bash drive_runs.sh SESSIONDIR
#
# Writes SESSIONDIR/runs/<run>/ (results) and SESSIONDIR/work/<run>/ (evidence
# folders) and SESSIONDIR/drive.log (UTC start/exit of every run). The
# published folders are then assembled by hand: the run with the lowest
# background load (processes-before/after, excluding the shells and the load
# logger) becomes the primary run in baseline/, the others go to repeats/, M1
# to message/; every load/ folder passes through sanitize_load.py.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
EVAL="${EVAL:?set EVAL to the agentgate-eval binary}"
export EVAL
export HOST_LABEL="${HOST_LABEL:-}"
SP="${1:?session directory}"
WRAP="$HERE/run_baseline.sh"
mkdir -p "$SP/runs" "$SP/work"
echo "drive start $(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$SP/drive.log"
for R in R1 R2 R3 R4 R5; do
  echo "$R start $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$SP/drive.log"
  bash "$WRAP" "$SP/runs/$R" "$SP/work/$R"
  echo "$R exit $? $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$SP/drive.log"
done
echo "M1 start $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$SP/drive.log"
bash "$WRAP" "$SP/runs/M1" "$SP/work/M1" -workload message -configs direct,policy-only,full,full+journal
echo "M1 exit $? $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$SP/drive.log"
echo "drive end $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$SP/drive.log"
