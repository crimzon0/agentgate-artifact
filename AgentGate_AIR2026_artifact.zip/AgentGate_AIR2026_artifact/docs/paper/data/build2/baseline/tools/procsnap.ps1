param([string]$Out, [int]$Seconds = 5)
# Per-process CPU use (cores busy) over a short window, plus system totals.
$a = @{}; Get-Process | ForEach-Object { if ($_.CPU -ne $null) { $a[$_.Id] = $_.CPU } }
$t0 = Get-Date
Start-Sleep -Seconds $Seconds
$el = ((Get-Date) - $t0).TotalSeconds
$rows = foreach ($p in Get-Process) {
  if ($p.CPU -ne $null -and $a.ContainsKey($p.Id)) {
    [pscustomobject]@{ name = $p.Name; pid = $p.Id; cores_busy = [math]::Round(($p.CPU - $a[$p.Id]) / $el, 3); working_set_mb = [math]::Round($p.WorkingSet64 / 1MB) }
  }
}
$os = Get-CimInstance Win32_OperatingSystem
$header = "# taken $((Get-Date).ToString('s')) window ${el}s; free physical MB $([math]::Round($os.FreePhysicalMemory/1024)) of $([math]::Round($os.TotalVisibleMemorySize/1024))"
$body = $rows | Sort-Object cores_busy -Descending | Select-Object -First 25 | ConvertTo-Csv -NoTypeInformation
Set-Content -Path $Out -Value (@($header) + $body) -Encoding utf8
