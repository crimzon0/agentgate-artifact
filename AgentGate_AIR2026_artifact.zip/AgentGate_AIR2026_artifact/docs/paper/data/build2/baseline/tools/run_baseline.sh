#!/usr/bin/env bash
# Run `agentgate-eval baseline` with full default sizes and log system load.
#
#   EVAL=path/to/agentgate-eval.exe [HOST_LABEL=NAME] bash run_baseline.sh OUTDIR WORKDIR [extra baseline flags...]
#
# HOST_LABEL, when set, is passed as the global option -host-label NAME (before
# the subcommand), so the evidence folders record NAME instead of the machine
# name (2026-10-08 session: HOST_LABEL=review-host).
# Windows (Git Bash). Logs total CPU %, available memory and disk writes every
# second with typeperf during the run (OUTDIR/load/system-load.csv) and a
# per-process CPU snapshot (5 s) before and after (OUTDIR/load/processes-*.csv).
# The published load/ folders were passed through sanitize_load.py, which
# aggregates process names into categories and removes the machine name.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
EVAL="${EVAL:?set EVAL to the agentgate-eval binary}"
OUT="$1"; WORK="$2"; shift 2
mkdir -p "$OUT" "$WORK" "$OUT/load"
OUTW=$(cygpath -w "$OUT")
powershell -NoProfile -ExecutionPolicy Bypass -File "$(cygpath -w "$HERE/procsnap.ps1")" -Out "$OUTW\load\processes-before.csv" -Seconds 5
rm -f "$OUT/load/system-load.csv"
typeperf "\Processor(_Total)\% Processor Time" "\Memory\Available MBytes" "\PhysicalDisk(_Total)\Disk Writes/sec" "\PhysicalDisk(_Total)\Avg. Disk sec/Write" -si 1 -sc 7200 -f CSV -o "$OUTW\load\system-load.csv" -y > /dev/null 2>&1 &
sleep 2
date -u +%Y-%m-%dT%H:%M:%SZ > "$OUT/load/run-start-utc.txt"
"$EVAL" ${HOST_LABEL:+-host-label "$HOST_LABEL"} baseline -out "$OUT" -work "$WORK" "$@" > "$OUT/load/stdout.txt" 2>&1
RC=$?
date -u +%Y-%m-%dT%H:%M:%SZ > "$OUT/load/run-end-utc.txt"
echo "exit $RC" >> "$OUT/load/run-end-utc.txt"
sleep 1
taskkill //F //IM typeperf.exe > /dev/null 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -File "$(cygpath -w "$HERE/procsnap.ps1")" -Out "$OUTW\load\processes-after.csv" -Seconds 5
exit $RC
