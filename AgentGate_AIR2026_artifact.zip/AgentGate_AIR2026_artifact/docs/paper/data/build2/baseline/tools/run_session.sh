#!/usr/bin/env bash
# The whole build-2 performance session, one step after another (new wrapper;
# each step is the build-1 method):
#   1. baseline: drive_runs.sh (R1-R5 financial, M1 message; run_baseline.sh
#      logs system load with typeperf and takes per-process snapshots);
#   2. agentgate-eval cost -n 2000 -batches 5 -repeat 20 (append cost per entry
#      in three write modes; the cross-check of STAGE_COST.md);
#   3. run_stagecost.sh (per-stage cost x3, one run on R3's replayed full
#      evidence, witness push x3, CPU-only stage benchmark).
# Steps 2-3 run under their own typeperf log (stagecost-load.csv). The idle
# guard watch_procs.ps1 runs for the whole session (watch-procs.csv).
#
#   EVAL=<singlebuild2>/bin/agentgate-eval.exe TESTBIN=<scratch>/testbin REPO=<repo> \
#     HOST_LABEL=review-host bash run_session.sh SESSIONDIR
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
EVAL="${EVAL:?set EVAL}"; export EVAL
TESTBIN="${TESTBIN:?set TESTBIN}"; export TESTBIN
REPO="${REPO:?set REPO}"; export REPO
export HOST_LABEL="${HOST_LABEL:-}"
SP="${1:?session directory}"
mkdir -p "$SP"
LOG="$SP/session.log"
stamp() { echo "$1 $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$LOG"; }
STOP="$SP/watch.stop"; rm -f "$STOP"
powershell -NoProfile -ExecutionPolicy Bypass -File "$(cygpath -w "$HERE/watch_procs.ps1")" \
  -Out "$(cygpath -w "$SP/watch-procs.csv")" -StopFile "$(cygpath -w "$STOP")" &
WPID=$!
stamp "session start"
stamp "baseline start"
bash "$HERE/drive_runs.sh" "$SP"
stamp "baseline end"
typeperf "\Processor(_Total)\% Processor Time" "\Memory\Available MBytes" "\PhysicalDisk(_Total)\Disk Writes/sec" "\PhysicalDisk(_Total)\Avg. Disk sec/Write" \
  -si 1 -sc 7200 -f CSV -o "$(cygpath -w "$SP/stagecost-load.csv")" -y > /dev/null 2>&1 &
sleep 2
stamp "cost start"
"$EVAL" ${HOST_LABEL:+-host-label "$HOST_LABEL"} cost -n 2000 -batches 5 -repeat 20 -out "$SP/cost" -work "$SP/cost-work" > "$SP/cost-stdout.txt" 2>&1
stamp "cost exit $?"
bash "$HERE/run_stagecost.sh" "$SP/stagecost" "$SP/stagecost-work" "$SP/work/R3/baseline-c16-full/run"
stamp "stagecost end"
sleep 1
taskkill //F //IM typeperf.exe > /dev/null 2>&1
touch "$STOP"
wait "$WPID"
stamp "session end"
