#!/usr/bin/env bash
# Per-stage cost of durable appends and witness push cost (STAGE_COST.md of
# build 1, docs/paper/data/revision/baseline/STAGE_COST.md), with test
# binaries compiled beforehand from the repository at the build-2 commit
# (go test -c), so no Go toolchain runs during the timed session.
#
#   TESTBIN=<dir with audit.test.exe and headwitness.test.exe> REPO=<repo> \
#     bash run_stagecost.sh OUTROOT WORKDIR [CORPUS_RUN_DIR]
#
# Each test binary runs in its package folder, as `go test` would. Order:
# three stage runs in a row (run1..run3, synthetic corpus), one stage run on
# the replayed audit.jsonl of CORPUS_RUN_DIR (run-corpus, if given), three
# witness push runs (run1..run3), then the CPU-only stage benchmark.
# Equivalent go test commands (STAGE_COST.md):
#   go test -count=1 -v -run '^TestStageCost$' ./internal/audit/ -stagecost=10000 -stagecost.warmup=200 -stagecost.work=W -stagecost.out=O
#   go test -count=1 -v -run '^TestWitnessPushCost$' ./internal/headwitness/ -witnesspush=2000 -witnesspush.warmup=50 -witnesspush.out=O
#   go test -run '^$' -bench AppendStageCPU -benchmem ./internal/audit/
set -u
TB="${TESTBIN:?set TESTBIN}"; REPO="${REPO:?set REPO}"
OUT="$1"; WORK="$2"; CORPUS="${3:-}"
mkdir -p "$OUT" "$WORK"
LOG="$OUT/stagecost-drive.log"
stamp() { echo "$1 $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$LOG"; }
stamp "stagecost start"
for n in 1 2 3; do
  stamp "run$n stage start"
  (cd "$REPO/internal/audit" && "$TB/audit.test.exe" -test.count=1 -test.v -test.run '^TestStageCost$' \
    -stagecost=10000 -stagecost.warmup=200 -stagecost.work="$WORK" -stagecost.out="$OUT/run$n") > "$OUT/run$n-stage.log" 2>&1
  stamp "run$n stage exit $?"
done
if [ -n "$CORPUS" ]; then
  stamp "run-corpus stage start"
  (cd "$REPO/internal/audit" && "$TB/audit.test.exe" -test.count=1 -test.v -test.run '^TestStageCost$' \
    -stagecost=10000 -stagecost.warmup=200 -stagecost.corpus="$CORPUS" -stagecost.work="$WORK" -stagecost.out="$OUT/run-corpus") > "$OUT/run-corpus-stage.log" 2>&1
  stamp "run-corpus stage exit $?"
fi
for n in 1 2 3; do
  stamp "run$n witness start"
  (cd "$REPO/internal/headwitness" && "$TB/headwitness.test.exe" -test.count=1 -test.v -test.run '^TestWitnessPushCost$' \
    -witnesspush=2000 -witnesspush.warmup=50 -witnesspush.out="$OUT/run$n") > "$OUT/run$n-witness.log" 2>&1
  stamp "run$n witness exit $?"
done
stamp "bench start"
(cd "$REPO/internal/audit" && "$TB/audit.test.exe" -test.run '^$' -test.bench AppendStageCPU -test.benchmem) > "$OUT/bench-cpu.txt" 2>&1
stamp "bench exit $?"
stamp "stagecost end"
