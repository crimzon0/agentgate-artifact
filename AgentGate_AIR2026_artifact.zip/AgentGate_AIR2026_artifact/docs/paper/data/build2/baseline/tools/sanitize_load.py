"""Copy a run's load/ folder into the repository with personal details removed.

- system-load.csv: the machine name in the typeperf header becomes HOST.
- processes-*.csv: per-process rows are aggregated into generic categories
  (cores busy over a 5 s window), so application names are not published.
"""
import csv
import os
import re
import shutil
import sys

CATEGORIES = [
    (re.compile(r"^VALORANT", re.I), "3D game (foreground)"),
    (re.compile(r"^(Riot Client|vgc|vgtray)", re.I), "game launcher / anti-cheat"),
    (re.compile(r"^javaw?$", re.I), "Java desktop application"),
    (re.compile(r"^(claude|node|codex|ChatGPT)$", re.I), "coding-agent / assistant processes"),
    (re.compile(r"^(go|compile|link|.*\.test|agentgate-.*)$", re.I), "Go toolchain / tests / experiment binaries"),
    (re.compile(r"^(powershell|bash|typeperf|conhost|WindowsTerminal)$", re.I), "shells and the load logger"),
    (re.compile(r"^(firefox|chrome|msedge|msedgewebview2|Discord.*|steamwebhelper|steam|CurseForge.*)$", re.I), "browsers / chat / launchers"),
    (re.compile(r"^vmware", re.I), "virtual machine"),
]


def category(name):
    for pattern, label in CATEGORIES:
        if pattern.match(name):
            return label
    return "other (system services, drivers, desktop)"


def sanitize_processes(src, dst):
    with open(src, encoding="utf-8-sig") as handle:
        lines = handle.read().splitlines()
    header = lines[0]
    rows = list(csv.DictReader(lines[1:]))
    totals = {}
    for row in rows:
        label = category(row["name"])
        totals[label] = totals.get(label, 0.0) + float(row["cores_busy"])
    with open(dst, "w", newline="", encoding="utf-8") as handle:
        handle.write(header.replace("﻿", "") + " (top 25 processes, aggregated into categories)\n")
        writer = csv.writer(handle)
        writer.writerow(["category", "cores_busy"])
        for label, value in sorted(totals.items(), key=lambda kv: -kv[1]):
            writer.writerow([label, f"{value:.3f}"])
        writer.writerow(["all listed processes", f"{sum(totals.values()):.3f}"])


def main(src_load, dst_load):
    os.makedirs(dst_load, exist_ok=True)
    for name in os.listdir(src_load):
        src = os.path.join(src_load, name)
        dst = os.path.join(dst_load, name)
        if name.startswith("processes-"):
            sanitize_processes(src, dst)
        elif name == "system-load.csv":
            with open(src, encoding="utf-8") as handle:
                text = handle.read()
            text = re.sub(r"\\\\\\\\[^\\\\]+\\\\", r"\\\\\\\\HOST\\\\", text)
            text = re.sub(r"\\\\[A-Za-z0-9-]+\\(?=(Processor|Memory|PhysicalDisk))", r"\\\\HOST\\", text)
            with open(dst, "w", encoding="utf-8") as handle:
                handle.write(text)
        else:
            shutil.copyfile(src, dst)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
