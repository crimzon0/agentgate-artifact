param([string]$Out, [string]$StopFile, [int]$IntervalSeconds = 5)
# Idle guard for the build-2 performance session (new in build 2; build 1
# checked only before the session and in the 5 s snapshots around each run).
# Every IntervalSeconds, append one line per running process whose name says
# it could disturb a timing run (Go toolchain, test binaries, experiment
# binaries, Python, the load logger), until StopFile exists. One long-lived
# PowerShell process, one Get-Process call per interval (about 0.01 cores).
# The session's own processes (agentgate-eval, *.test, typeperf) are expected
# in the log; anything else, or two experiment binaries at once, is contention.
$pattern = '^(agentgate-.*|go|compile|link|go-build.*|vet|asm|cgo|gopls|python.*|py|pyw|.*\.test|typeperf)$'
Set-Content -Path $Out -Value 'utc,name,pid' -Encoding utf8
while (-not (Test-Path $StopFile)) {
  $t = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
  $rows = @(Get-Process | Where-Object { $_.Name -match $pattern } | ForEach-Object { "$t,$($_.Name),$($_.Id)" })
  if ($rows.Count -eq 0) { $rows = @("$t,(none),") }
  Add-Content -Path $Out -Value $rows -Encoding utf8
  Start-Sleep -Seconds $IntervalSeconds
}
