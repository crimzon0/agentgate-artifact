# build-manifest.txt

Copy of the build-2 manifest (`MANIFEST.txt` in the frozen build folder, outside the repository) with one change: the repository's local path on line 3 is replaced by `<repo>`. The SHA-256 of the original file, which every experiment re-hashed against and which the papers and RESULTS_BUILD2.md cite, is `841a7c6fd3c6ea5790692c7bb3be27e783e6ad803ef5adeb39d26b792534b658`; restoring line 3 to the repository path reproduces it.
