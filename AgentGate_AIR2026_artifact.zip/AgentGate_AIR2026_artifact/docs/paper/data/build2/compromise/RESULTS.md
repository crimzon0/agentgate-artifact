# Flag-binding ablation and key-compromise simulation: build 2 rerun

> **Correction note (2026-10-10, honesty sweep; the record below is
> unchanged).** (1) "Need", "needed", "necessary" and "minimal" for key sets mean the smallest tested key set that passed among the 12 tested key sets, for the canonical targets, in a structural simulation in which the verifier skips the signature checks of the roles the attacker holds (nothing is re-signed). They are not proofs that fewer keys cannot succeed. (2) They hold on the receipt path only: through reconciliation, the audit and issuer keys with access to the provider's status interface sufficed in every verifier setting (fixture runs with real signatures, `docs/paper/data/build2/fixture-studies/RESULTS.md` §2.2). (3) "Adapter" counts the three adapter keys as one role, and every role is held in one process: key counts count roles, not independently held keys. The paper states flips over the 168 cells without a
> head anchor (head-anchored cells are detected by construction). Log:
> `docs/paper/artifact/HONESTY_SWEEP.md`.

Run on 2026-10-10 from 02:27:17 to 02:43:57 UTC, on **frozen build 2** (commit
`86643d7`, branch `claude/supervisor-demo`), results format
`agentgate-compromise/v2`. This repeats the build-1 experiment
(`../../revision/compromise/RESULTS.md`, run 2026-10-08) for the answer to
the supervisor's second review. The commands, parameters, repetitions and
analysis scripts are the same; only the binaries changed. As before, this is
a key-compromise **simulation**: nothing was re-signed, and no private key
was read, exported or generated.

**Headline.** Build 2 gives the same result as build 1 in every cell. All
51,840 result rows have the same verdict, assurance, `detected`, `simulated`,
`applied` value, failing checks (in the same order) and `not_applicable`
text. Every derived file is byte-identical to build 1's (section 4).

- **Binding flips.** Bound detected, unbound accepted; strongest attacker.
  - Full verifier: **0 of 336** cells (0 of 168 without a head anchor).
  - `policy.replay` off (`no-replay`): **12 of 336** (12 of 168 without a
    head anchor).
  - `no-replay-no-snapshot`: also 12 of 336 (12 of 168).
  - Only `policy.snapshot_bound` off: **8 of 336** (8 of 168).
  - Every flip is in a cell without a head anchor. A head anchor (head or
    both) leaves **0 of 168** flips in every setting. There are no reverse
    flips.
- **Strongest attacker, full verifier.** It defeats every check except the
  anchors in **46 of 672** cells per run (460 of 6,720 cell-runs; 230 of
  3,360 per design). Two cases:
  - strip-flag and invent-flag, using `forge-restate` with
    audit+issuer+adapter or larger key sets, in both designs;
  - change-amount, with audit+issuer+adapter+provider or larger key sets.
- **Oracle agreement** on the frozen oracle (`docs/paper/oracle`, same
  SHA-256 as in build 1):
  - Full verifier: **540/560** cells against the strongest attacker
    (`snapshot_bound+mode_checked`; 270/280 per design) and **560/560**
    against the plain attacker (`no_snapshot_forgery+mode_checked`; 280/280
    per design).
  - no-snapshot-bound-only against the strongest attacker: **536/560**
    (`mode_checked`; bound 270/280, unbound 266/280).
  - Both no-replay configurations: **560/560** against `mode_checked`, for
    both attackers.
  - All 1,888 disagreeing (configuration x reading x attacker) cells have a
    named cause; 0 are unexplained.
- **False alarms: 0.**
  - **0 of 1,280** clean-control verifications by the runner.
  - The self-test pins of all 40 base runs give 40/40 VERIFIED/ANCHORED
    (35/35 checks).
  - The separate `agentgate-verify` CLI accepts all 20 bound base runs at
    every anchor condition, ANCHORED with both anchors.
  - The 20 unbound base runs fail in the CLI **by design**, as in build 1:
    the CLI has no ablation option, so `op.requires_policy` fails.
- **Stability.** 0 of the 2,688 distinct cells changed outcome across the 10
  runs. No failing-check set changed.

## 1. What was run

**Method.** It is unchanged from build 1 (`../../revision/compromise/RESULTS.md`
§1), so only a summary is given here.

- **Cell count.** 7 operators x 12 attacker key sets x 4 anchor conditions
  (none, keys, head, both) x 2 designs (bound, unbound) x 4 verifier
  configurations (`full`, `no-replay`, `no-replay-no-snapshot`,
  `no-snapshot-bound-only`) = **2,688 cells per run**.
- **Snapshot variants.** Each cell is tried with up to 3 variants (`plain`,
  `forge-snapshot`, `forge-restate`). A cell counts as detected only if
  every applicable variant is detected.
- **Base runs.** Each of the 10 runs makes 4 base runs with the real
  gateway: flag mode and human mode, each bound and unbound.
- **Volume.**
  - 49,920 mutant verifications and 1,920 not-applicable rows;
  - 6,720 strongest-attacker cell-runs per configuration;
  - 1,280 clean-control verifications.
- **Detected** means verdict FAILED.
- **Accepted** means VERIFIED with any assurance, warnings or `missing`
  entries.

**Commands**, run from the repository root:

```
py <singlebuild2>/check_manifest.py                                   # before: 1,868 files, 0 differ
<singlebuild2>/bin/agentgate-eval.exe -host-label review-host compromise -runs 10 -work <scratch>/build2-work/compromise/work -out docs/paper/data/build2/compromise
py <singlebuild2>/check_manifest.py                                   # after: 1,868 files, 0 differ
cd docs/paper/data/build2/compromise
python analyze_compromise.py
python base_controls.py <scratch>/build2-work/compromise/work <singlebuild2>/bin/agentgate-verify.exe .
python compare_build1.py        # comparison with build 1 (new; section 4)
python breakdown.py             # flips per anchor condition, oracle agreement per design (new)
```

- **Analysis scripts.** `analyze_compromise.py` and `base_controls.py` are
  byte-identical copies of build 1's scripts (same SHA-256). Their relative
  oracle path resolves from this folder unchanged.
- **New scripts.** `compare_build1.py`, `breakdown.py`,
  `baserun_structure.py` and `compiled_files.py` were added for this rerun.
  They only read data.
- **Binaries and manifest checks.** Only the build-2 binaries were used:
  `agentgate-eval` `485e4ce0...fdca` and `agentgate-verify`
  `83d0786a...ed0`. `check_manifest.py` re-hashed all 1,868 manifest files
  before the run (02:26:58Z) and after the run and analysis (02:44:10Z), and
  found 0 differences both times (`build-manifest.txt`).

**Validation of the simulation.** The same test packages as build 1 were
run on commit `86643d7`. The test binaries were built with `go test -c` from
the working tree, which equals `86643d7` apart from untracked or deleted
non-code files. Their hashes are in `build-manifest.txt`. Everything passed:

| package | top-level tests passed |
|---|---|
| `internal/auditverify` | 134/134 |
| `internal/auditverify/tools/refusalmutation` | 14/14 |
| `internal/evalattack` | 17/17 |
| `cmd/agentgate-eval` | 27/27 |

- `TestSimulationAgreesWithRealAuditKeyResigning` covers 11 audit-log edits
  x 4 anchor conditions. Each edit is re-signed once with the fixture's real
  audit key and verified once unsigned under `AssumeCompromised=[AUDIT_LOG]`.
  All **44/44 cells are identical** (`validation_sim_vs_real.txt`).
- The role-by-role simulation tests passed: `TestEachRoleUnderSimulation`,
  `TestWitnessRoleUnderSimulation`, `TestReplacementKeysNeedAnAnchor`,
  `TestSimulationIsLabelled`, `TestAssumeCompromisedNamesAreChecked` and
  `TestEscalationModeCheckIsSymmetric`.
- As in build 1, only the audit-key simulation has been compared with real
  re-signing.

## 2. Results

### 2.1 Binding flips per verifier setting and anchor condition

Cells are operator x key set. There are 84 per anchor condition, 168
without a head anchor (none + keys), 168 with one (head + both), and 336 in
all. The oracle's 10 key sets give 140 cells without a head anchor and 280 in
all. Every flip occurs in 10/10 runs (`flips.csv`, `flips_by_anchor.csv`).

| verifier setting | none | keys | head | both | **without head anchor** | with head anchor | **all** | oracle key sets (no head / all) | reverse |
|---|---|---|---|---|---|---|---|---|---|
| full | 0/84 | 0/84 | 0/84 | 0/84 | **0/168** | 0/168 | **0/336** | 0/140 / 0/280 | 0 |
| no-snapshot-bound-only | 4/84 | 4/84 | 0/84 | 0/84 | **8/168** | 0/168 | **8/336** | 8/140 / 8/280 | 0 |
| no-replay | 6/84 | 6/84 | 0/84 | 0/84 | **12/168** | 0/168 | **12/336** | 12/140 / 12/280 | 0 |
| no-replay-no-snapshot | 6/84 | 6/84 | 0/84 | 0/84 | **12/168** | 0/168 | **12/336** | 12/140 / 12/280 | 0 |

The flipped cells:

- **no-replay** (12 flips): {strip-flag, invent-flag, change-rules} x
  {audit, audit+issuer} x {none, keys}.
  - The bound design catches them with `artifact.signature`,
    `op.capability_bound` and `op.receipts_bound` (audit key alone), or with
    `artifact.signature` and `op.receipts_bound` (audit+issuer).
  - In the unbound design `plain` evades, because the flag lives only in the
    audit-signed details.
- **no-snapshot-bound-only** (8 flips): {strip-flag, invent-flag} x {audit,
  audit+issuer} x {none, keys}.
  - In the unbound design the audit-key-only `forge-snapshot` evades.
- The plain attacker alone gives the same 12 flips in both no-replay
  configurations and none elsewhere.

### 2.2 Acceptance per configuration (strongest attacker, cell-runs)

| configuration | accepted | bound | unbound | with a head anchor |
|---|---|---|---|---|
| full | **460/6,720** | 230/3,360 | 230/3,360 | 0 |
| no-snapshot-bound-only | 540/6,720 | 230/3,360 | 310/3,360 | 0 |
| no-replay | 940/6,720 | 410/3,360 | 530/3,360 | 0 |
| no-replay-no-snapshot | 940/6,720 | 410/3,360 | 530/3,360 | 0 |

- All 4,780 accepted rows (out of 49,920) are `SIMULATED_CONSISTENT`; none is
  ANCHORED.
- With the full verifier, the plain attacker gets only change-amount through:
  100 of 6,720 rows.

### 2.3 Strongest-attacker matrix

The matrix below is for the full verifier with no anchor. The bound and
unbound designs are identical; "U" means accepted in 10/10 runs and "." means
detected in 10/10 runs. A cell shows the strongest attacker, then the plain
attacker in brackets. Key sets: A audit, I issuer, D adapter (all three
adapter keys), P provider, G delegation, H approval, ALLs all-stolen, ALLr
all-replaced.

| operator | - | A | I | D | P | G | AI | AID | AIDP | AIDH | ALLs | ALLr |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| strip-flag | . | . | . | . | . | . | . | U[.] | U[.] | U[.] | U[.] | U[.] |
| invent-flag | . | . | . | . | . | . | . | U[.] | U[.] | U[.] | U[.] | U[.] |
| change-rules | . | . | . | . | . | . | . | . | . | . | . | . |
| change-escalation | . | . | . | . | . | . | . | . | . | . | . | . |
| swap-decisions | . | . | . | . | . | . | . | . | . | . | . | . |
| change-amount | . | . | . | . | . | . | . | . | U[U] | . | U[U] | U[U] |
| relabel-approved | . | . | . | . | . | . | . | . | . | . | . | . |

How the anchors and the other settings change this matrix:

- **Keys anchor.** It removes only the ALLr column.
- **Head anchor (head or both).** Every cell is detected in every
  configuration.
- **no-replay.** strip-flag, invent-flag and change-rules are accepted with
  AID and larger key sets in the bound design, but with **A** and larger in
  the unbound design. relabel-approved is accepted with AID and larger in
  both designs (a control: the approval overlay is committed in both
  designs).
- **no-snapshot-bound-only.** It differs from the full verifier only for
  unbound strip-flag and invent-flag, which are accepted with A and AI
  (`forge-snapshot`).

All 64 matrices (configuration x anchors x design, each for both attackers)
are in `matrices.json`. The minimal and necessary key sets are in
`keysets.json`. They are the same as build 1's (§5 there):

- strip-flag and invent-flag need audit+issuer+adapter, and every member is
  necessary;
- change-amount needs audit+issuer+adapter+provider;
- the delegation key is never needed and the approval key never helped.

### 2.4 Replacement keys (`replacement_keys.csv`)

Each anchor condition has 14 rows (7 operators x 2 designs).

| anchor | full: all-replaced [all-stolen] accepted | no-replay: all-replaced [all-stolen] |
|---|---|---|
| none | 6/14 [6/14] | 10/14 [10/14] |
| keys | 0/14 [6/14] | 0/14 [10/14] |
| head | 0/14 [0/14] | 0/14 [0/14] |
| both | 0/14 [0/14] | 0/14 [0/14] |

### 2.5 Oracle agreement (`oracle_agreement.csv`, `breakdown.json`)

Agreement is counted in cells out of 560 (7 operators x 10 key sets x 4
anchors x 2 designs). The runner counts each cell once per run, so its
counts are 10 times larger (`results.json` → `oracle`, `oracle_plain`).

| reading | full | no-snapshot-bound-only | no-replay (both configs) |
|---|---|---|---|
| primary | 514 / 494 | 522 / 494 | 546 / 546 |
| no_snapshot_forgery | 526 / 546 | 518 / 546 | 494 / 494 |
| snapshot_bound | 526 / 506 | 518 / 506 | 534 / 534 |
| mode_checked | 528 / 508 | **536** / 508 | **560 / 560** |
| receipt_decision_unchecked | 502 / 482 | 510 / 482 | 534 / 534 |
| snapshot_bound + mode_checked | **540** / 520 | 532 / 520 | 548 / 548 |
| no_snapshot_forgery + mode_checked | 540 / **560** | 532 / **560** | 508 / 508 |

Each entry gives the strongest attacker / the plain attacker. Bold marks the
mapped reading.

- **Per design** (mapped readings):
  - full, strongest attacker: bound 270/280, unbound 270/280;
  - full, plain attacker: 280/280 each;
  - no-snapshot-bound-only, strongest attacker: bound 270/280, unbound
    266/280;
  - no-replay: 280/280 each.
- **Disagreements with the mapped readings.** There are 44: 20 in full and
  24 in no-snapshot-bound-only. All of them are C1 (change-rules has no
  snapshot lever for the single-recipient target; 10 + 14) or C2 (the engine
  does not delete the two never-executed approval requests that a
  relabel-approved forgery would reclassify; 10 + 10). These are limits of
  the canonical runs, not gaps in the verifier.
- **All readings.** The 1,888 disagreeing rows across every configuration,
  reading and attacker (`oracle_mismatches.csv`) all have a cause from build
  1's list (A3, A6, P1, C1, C2, S1, S2, F1, V2). None is unexplained.
- The two combined readings and the mapping of the no-replay configurations
  to `mode_checked` were defined by build 1's analysis, not by the oracle.

### 2.6 Clean controls (false alarms)

| control | result |
|---|---|
| Runner controls: every unmutated base run, verified for real and with all six roles assumed compromised, under every anchor condition and configuration (`controls.csv`) | **1,280/1,280 VERIFIED, 0 false alarms**. Real: 600 CONSISTENT and 40 ANCHORED. Simulated: 600 SIMULATED_CONSISTENT and 40 SIMULATED_ANCHORED |
| Self-test pins of the 40 base runs (`base_controls.csv`) | 40/40 VERIFIED/ANCHORED, 35/35 checks, 0 failed |
| `agentgate-verify` CLI, a separate process, on the 20 bound base runs | 20/20 VERIFIED at every anchor condition (CONSISTENT; ANCHORED with both anchors). The head equals the self-test pin in 40/40 |
| `agentgate-verify` CLI on the 20 unbound base runs | 20/20 FAILED by design: the CLI has no ablation option, so `op.requires_policy` rejects the ablated value shape. This is not a false alarm |

## 3. Comparison with build 1

Build 1 is `../../revision/compromise/`, run 2026-10-08 with
`agentgate-eval` `744d480c...57bb6`.

| headline number | build 1 | build 2 | difference and cause |
|---|---|---|---|
| binding flips, full | 0/336 (0/168 without a head anchor) | 0/336 (0/168) | none |
| binding flips, no-snapshot-bound-only | 8/336 (8/168) | 8/336 (8/168) | none; same 8 cells |
| binding flips, no-replay | 12/336 (12/168) | 12/336 (12/168) | none; same 12 cells |
| binding flips, no-replay-no-snapshot | 12/336 (12/168) | 12/336 (12/168) | none |
| flips with a head anchor, any setting | 0/168 | 0/168 | none |
| reverse flips | 0 | 0 | none |
| accepted cell-runs, full (bound / unbound) | 460/6,720 (230 / 230) | 460/6,720 (230 / 230) | none |
| accepted cell-runs, no-snapshot-bound-only | 540/6,720 (230 / 310) | 540/6,720 (230 / 310) | none |
| accepted cell-runs, no-replay and no-replay-no-snapshot | 940/6,720 each (410 / 530) | 940/6,720 each (410 / 530) | none |
| cells defeating every non-anchor check, full, per run | 46/672 | 46/672 | none |
| accepted rows | 4,780/49,920, all SIMULATED_CONSISTENT | 4,780/49,920, all SIMULATED_CONSISTENT | none |
| plain attacker accepted, full | 100/6,720 | 100/6,720 | none |
| oracle, full, strongest (`snapshot_bound+mode_checked`) | 540/560 | 540/560 | none |
| oracle, full, plain (`no_snapshot_forgery+mode_checked`) | 560/560 | 560/560 | none |
| oracle, no-snapshot-bound-only, strongest (`mode_checked`) | 536/560 | 536/560 | none |
| oracle, no-replay, `mode_checked` | 560/560 | 560/560 | none |
| unexplained oracle disagreements | 0 | 0 | none |
| replacement keys (full / no-replay, no anchor) | 6/14 / 10/14 | 6/14 / 10/14 | none |
| runner clean controls | 1,280/1,280, 0 false alarms | 1,280/1,280, 0 false alarms | none |
| CLI controls, bound / unbound | 20/20 VERIFIED / 20/20 FAILED by design | the same | none |
| unstable cells across runs | 0/2,688 | 0/2,688 | none |
| simulation vs real audit-key re-signing | 44/44 | 44/44 | none |

**No cell changed.** The comparison is in `compare_build1.json`, made by
`compare_build1.py`, which does what build 1 did against its previous build:

- **Byte-identical to build 1:**
  - `results.csv`, `strongest.csv`, `controls.csv` and `compromise.md`;
  - `cells.csv`, `matrices.json`, `flips.csv` and `keysets.json`;
  - `replacement_keys.csv`, `oracle_agreement.csv`,
    `oracle_mismatches.csv` and `unrepaired.csv`;
  - `analysis.json`, `base_controls.csv` and `base_controls.json`.
- **`results.json` differs only in run-specific values:**
  - `environment.started_at`;
  - `environment.clock_granularity_ms` (1.0001 vs 0.9998 ms; not used);
  - the `-out` path in `environment.command`;
  - the operation IDs inside the `unrepaired` notes of the 7,680
    relabel-approved x {forge-snapshot, forge-restate} rows.
- **Row comparison.** With those IDs normalised, all **51,840 rows** are
  equal, in the same order and with the same field set. The top-level
  summary fields (`binding_flips`, `oracle`, `oracle_plain`, `controls`) are
  equal too.

## 4. Why the build-2 changes do not move this experiment

**What changed in the compiled code.** 14 compiled files of `agentgate-eval`
and `agentgate-verify` differ from build 1: 13 changed and 1 new
(`internal/auditverify/freshness.go`). All 239 files of build 1's list equal
commit `2d32506`. The list is in `build-manifest.txt`. Each change is listed
below with why it leaves this experiment's verdicts unchanged.

1. **The gateway keeps the flag on recovery records and on replayed
   COMMITTED answers** (`internal/devcomposition/auditing.go`, `durable.go`,
   `dispatch.go`).
   - Each base run has exactly one RECONCILED-committed record (the AED
     400.00 payment, after its provider answer was lost). It has 4 replayed
     COMMITTED answers: 3 in-process retries of the AED 900.00 payment, and 1
     retry of the AED 400.00 payment after the restart.
   - Both payments are unflagged automatic payments. Their records state no
     flag in either build.
   - The three flagged executed operations (the partner email, AED 12,400.00
     and AED 18,500.00) are never replayed or reconciled.
   - `baserun_structure.py` compared the 80 build-2 audit segments with
     build 1's, entry by entry, on (stage, outcome, effect type, stated
     flag, scope, replayed, status): **80/80 segments are structurally
     identical** (`baserun_structure.txt`).
2. **New verifier rules** (`internal/auditverify/operations.go`):
   - `checkReplayedFlag` and `checkReconciledFlag` (part of
     `op.requires_policy`);
   - `checkReconciledReceipt` (`op.receipts_bound` for an adapter receipt on
     RECONCILED).

   The flag rules run in every verification and pass on the AED 900.00 and
   AED 400.00 operations. No mutant changes those two operations:

   - The canonical targets are AED 12,400.00, AED 1,250.00, the partner
     email and the human-mode AED 12,400.00.
   - No forged snapshot reclassifies AED 900.00 or AED 400.00. strip-flag
     and relabel-approved raise the AED automatic limit to 12,400.00, and
     invent-flag lowers it to just below 1,250.00. Both payments stay
     automatic either way.

   The receipt rule returns early: the only RECONCILED record carries a
   provider receipt and a provider status, but no adapter effect receipt.
3. **The verifier's freshness and completeness dimensions** (`head_fresh`,
   `run_complete`; `freshness.go`, `assurance.go`, `verify.go`), plus:
   - per-operation classification evidence;
   - Missing entries with kinds;
   - flagged-but-unconfirmed counting.

   The dimensions are derived: they own no check and add no failing check.
   The other additions are reported only. None of them changes a verdict,
   and the compromise rows record verdict, assurance and failing checks, not
   dimensions or Missing kinds. The base runs have no operation left
   unresolved, so the unconfirmed counting is not exercised. The assurance
   labels are unchanged in all 49,920 rows and 1,280 controls.
4. **evalattack states the flag on RECONCILED commits**
   (`internal/evalattack/operators.go`). No target and no relabelled
   operation has a RECONCILED-committed record, so the added loop has
   nothing to rewrite.
5. **Other changes.**
   - `cmd/agentgate-eval/custody.go` (witness fetch time) and `crash.go`:
     the compromise runs use no witness and no crash injection.
   - `harness.go` gains `missing_by_kind` and the derived dimensions, but
     the compromise runner does not write them.
   - `cmd/agentgate-verify/main.go` changes only the help text and the
     human-readable output (new dimensions, classification evidence,
     unconfirmed flags). The JSON verdicts and assurance that
     `base_controls.py` reads are unchanged.
   - `internal/demo/assets/app.js` is a UI asset.
   - The killsuite binary is not used.

**Consequence.** As in build 1, the identical result is a regression check:
the build-2 changes did not alter any verdict this experiment measures. It
**does not test the new recovery and replay rules**, because no mutated
operation has a recovery or replay record. The crash, custody and killsuite
experiments are where those rules are measured.

## 5. Caveats

- **Simulation.** Signatures of the assumed-compromised roles are accepted
  without checking. Only the audit key has been compared with real
  re-signing (44/44). The issuer, adapter, provider, approval and delegation
  roles are validated one role at a time, never against real re-signed COSE
  artifacts. The simulator is a structural attack model, not cryptographic
  exploitation.
- **Sufficient vs necessary key sets.** Sufficient key sets are observed in
  simulation. "Necessary" means necessary among the 12 tested key sets for
  the canonical target, not proved from the protocol.
- **"Adapter" (D).** It means all three adapter keys at once; partial adapter
  compromise and A+X are not in this matrix.
- **Engine limits** (unchanged from build 1):
  - one canonical target per operator, and no multi-recipient change-rules
    target (C1);
  - the engine does not delete the never-executed approval requests (C2);
  - swap-decisions is a verbatim transplant;
  - the engine does not recompute the provider receipt's effect-row and
    state hashes, the request digest, or the approval-artifact hash lists.
- **New engine gap (found by code reading in this rerun; not exercised
  here).** `rewriteDecision` rewrites the executing call's CALL_RESULT and,
  since build 2, RECONCILED-committed records. It does not rewrite the
  call-scope replayed COMMITTED answers (`executingCallResults` skips scope
  `call`). Build 2's verifier checks the flag those answers state.
  - Consequence: a strip-flag or invent-flag aimed at an operation with
    replayed answers would currently be caught by `checkReplayedFlag`.
  - That would be an unrepaired consequence of the engine, not a verifier
    strength: an audit-key holder could rewrite those answers.
  - It does not affect any number here, because no target has a replayed
    answer.
- **Snapshot deletion.** With `policy.snapshot_bound` off, an audit-key
  holder who deletes the snapshot reaches the no-replay outcome, as in build
  1 §8.
- **Scope and timing.**
  - The 10 repetitions re-run the same deterministic scripts with fresh keys
    and IDs: they show stability, not independent workloads.
  - The anchors are the harness's own pins, and everything ran on one
    machine.
  - Other experiment runners used the machine at the same time. The
    16 min 40 s wall-clock time is not a performance result.

## 6. Files

| file | contents |
|---|---|
| `results.json`, `results.csv` | the runner's output: 51,840 rows, one per mutant verification, with the variant (21 MB / 8.8 MB) |
| `strongest.csv` | one row per cell and run: strongest attacker, evading variants, plain outcome |
| `controls.csv` | 1,280 clean-control verifications |
| `compromise.md` | the runner's de-duplicated summary |
| `cells.csv`, `matrices.json`, `flips.csv`, `keysets.json`, `replacement_keys.csv`, `oracle_agreement.csv`, `oracle_mismatches.csv` (with causes), `unrepaired.csv`, `analysis.json` | `analyze_compromise.py` (build 1's script, unchanged) |
| `base_controls.csv`, `base_controls.json` | self-test and CLI verification of the 40 base runs (`base_controls.py`, build 1's script, unchanged) |
| `flips_by_anchor.csv`, `breakdown.json` | flips per setting and anchor condition (of 84 / 168 / 336), oracle agreement per design (`breakdown.py`) |
| `compare_build1.json` | file-by-file and row-by-row comparison with build 1 (`compare_build1.py`) |
| `baserun_structure.txt` | replayed and reconciled records of the 80 build-2 audit segments, and their structural comparison with build 1's base runs (`baserun_structure.py <build-1 work> <build-2 work>`) |
| `validation_sim_vs_real.txt` | the 44 cells of `TestSimulationAgreesWithRealAuditKeyResigning` on `86643d7` |
| `build-manifest.txt` | both `check_manifest.py` outputs with times, the six binary hashes, script, oracle and test-binary hashes, and the 240 compiled files of `agentgate-eval` and `agentgate-verify` with the 14 that differ from build 1 (`compiled_files.py`) |

The base runs and logs stay outside the repository, under
`<scratch>/build2-work/compromise/work` (about 3 MB per base run). Mutants
are generated, verified in memory and deleted.
