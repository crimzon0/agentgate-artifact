#!/usr/bin/env python3
"""Analyse the R6.1 key-compromise simulation (agentgate-eval compromise, format v2).

Reads results.json (one row per mutant verification, with the snapshot
variant), controls.csv (clean controls) written by `agentgate-eval compromise`
and the oracle (docs/paper/oracle/expected.json), and writes next to
results.json:

  cells.csv              one row per (verifier config, anchors, design, operator, keyset):
                         runs, the strongest attacker's outcome (detected only if every
                         applicable snapshot variant was detected), each variant's outcome,
                         the evading variants, modal failing checks per variant, the
                         oracle label under every reading
  matrices.json          operator x keyset outcome matrices per config/anchors/design
                         (strongest attacker and plain attacker)
  flips.csv              cells whose outcome differs between bound and unbound
                         (strongest attacker; the plain attacker's flip alongside)
  keysets.json           sufficient / minimal sufficient key sets and necessary roles
                         (anchors none and keys; strongest and plain attacker)
  replacement_keys.csv   all-replaced and all-stolen under the four anchor conditions
  oracle_agreement.csv   agreement per config x reading x attacker (cell level)
  oracle_mismatches.csv  every disagreeing cell, with the cause (see CAUSES below)
  unrepaired.csv         what the engine reported it could not make consistent
  analysis.json          everything above plus controls and stability in one document

Standard library only; deterministic. Usage:
  python analyze_compromise.py [RESULTS_DIR] [ORACLE_JSON]
"""
import collections
import csv
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
RESULTS_DIR = sys.argv[1] if len(sys.argv) > 1 else HERE
ORACLE = sys.argv[2] if len(sys.argv) > 2 else os.path.join(
    HERE, "..", "..", "..", "oracle", "expected.json")

OPERATORS = ["strip-flag", "invent-flag", "change-rules", "change-escalation",
             "swap-decisions", "change-amount", "relabel-approved"]
KEYSETS = ["none", "audit", "issuer", "adapter", "provider", "delegation",
           "audit+issuer", "audit+issuer+adapter", "audit+issuer+adapter+provider",
           "audit+issuer+adapter+approval", "all-stolen", "all-replaced"]
ANCHORS = ["none", "keys", "head", "both"]
CONFIGS = ["full", "no-replay", "no-replay-no-snapshot", "no-snapshot-bound-only"]
DESIGNS = ["bound", "unbound"]
VARIANTS = ["plain", "forge-snapshot", "forge-restate"]
ROLES = {
    "none": set(), "audit": {"A"}, "issuer": {"I"}, "adapter": {"D"}, "provider": {"P"},
    "delegation": {"G"}, "audit+issuer": {"A", "I"}, "audit+issuer+adapter": {"A", "I", "D"},
    "audit+issuer+adapter+provider": {"A", "I", "D", "P"},
    "audit+issuer+adapter+approval": {"A", "I", "D", "H"},
    "all-stolen": {"A", "I", "D", "P", "G", "H"}, "all-replaced": {"A", "I", "D", "P", "G", "H", "R"},
}
ROLE_NAMES = {"A": "audit", "I": "issuer", "D": "adapter", "P": "provider", "G": "delegation",
              "H": "approval", "R": "keys.json replaced"}
READINGS = ["primary", "no_snapshot_forgery", "snapshot_bound", "mode_checked",
            "receipt_decision_unchecked"]
# Combined readings: detected if any component says detected (each alternative
# column changes one assumption of the primary reading).
COMBINED = {
    "snapshot_bound+mode_checked": ["snapshot_bound", "mode_checked"],
    "no_snapshot_forgery+mode_checked": ["no_snapshot_forgery", "mode_checked"],
}
ALL_READINGS = READINGS + list(COMBINED)
# The reading that describes each configuration (oracle README "Which column
# to compare against"; the verifier checks the escalation mode, A3 closed).
# The no-replay configurations have no oracle reading: the oracle predicts a
# verifier with replay.
MAPPED = {
    ("full", "strongest"): "snapshot_bound+mode_checked",
    ("full", "plain"): "no_snapshot_forgery+mode_checked",
    ("no-snapshot-bound-only", "strongest"): "mode_checked",
    ("no-snapshot-bound-only", "plain"): "no_snapshot_forgery+mode_checked",
}


def oracle_keyset(ks):
    return {"all-replaced": "all", "all-stolen": None, "audit+issuer+adapter+approval": None}.get(ks, ks)


def load():
    with open(os.path.join(RESULTS_DIR, "results.json"), encoding="utf-8") as f:
        results = json.load(f)
    with open(ORACLE, encoding="utf-8") as f:
        oracle = json.load(f)
    cells = {(c["operator"], c["keyset"], c["anchors"], c["design"]): c for c in oracle["cells"]}
    controls = []
    path = os.path.join(RESULTS_DIR, "controls.csv")
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            controls = list(csv.DictReader(f))
    return results, cells, controls


def oracle_label(cell, reading):
    if cell is None:
        return None
    if reading == "primary":
        return cell["expected"]
    if reading in COMBINED:
        labels = [oracle_label(cell, r) for r in COMBINED[reading]]
        return "detected" if "detected" in labels else "undetected"
    return cell["alternatives"].get(reading)


def outcome_of(flags):
    """flags: list of detected booleans over runs."""
    if not flags:
        return "n/a"
    if all(flags):
        return "detected"
    if not any(flags):
        return "undetected"
    return "mixed"


CAUSES = {
    "A3": "the escalation mode is checked against run.json in both designs (op.requires_policy, policy.replay); the reading assumes no such check (A3)",
    "A6": "the effect receipt's policy_decision_hash is checked (op.receipts_bound), so a decision edit needs the adapter key; the reading assumes it is not (A6)",
    "P1": "the plain attacker leaves policy_snapshot alone, so policy.replay re-derives the genuine classification; the reading's attacker forges the snapshot",
    "C1": "change-rules: the canonical target is a single-recipient message, so no valid snapshot makes MSG-BULK fire (forging variants not applicable) and policy.replay re-derives the genuine rules",
    "C2": "relabel-approved (human-mode run): a snapshot that makes the target automatic would also make the never-executed approval requests (AED 12,400 abandoned, AED 9,800) automatic; the engine does not delete them (Mutant.Unrepaired), so policy.replay still fires",
    "S1": "policy.snapshot_bound ties the snapshot to the issuer-signed policy hash, so a forged snapshot needs the restated hash (issuer and adapter keys) in both designs; the reading assumes the audit key alone protects the snapshot (A1)",
    "S2": "policy.snapshot_bound is switched off in this configuration, so the audit-key-only forge-snapshot passes; the reading binds the snapshot to the policy hash",
    "F1": "the forging attacker (forge-restate / forge-snapshot) evades where the reading assumes the snapshot is left alone",
    "V2": "policy.replay is switched off; the reading predicts a verifier with replay, which would catch the edit",
}


def mismatch_cause(cfg, attacker, reading, design, op, ks, verifier, oc):
    """Name why one cell disagrees with an oracle reading (CAUSES).

    The rules were written after reading the failing checks of every
    disagreeing cell (oracle_mismatches.csv lists them); they never change a
    label, they only name the assumption or engine limit behind the difference.
    """
    assumes_forgery = not reading.startswith("no_snapshot_forgery")
    assumes_a1 = reading in ("primary", "mode_checked", "receipt_decision_unchecked")
    if verifier == "detected":
        if op == "change-escalation" and "mode_checked" not in reading:
            return "A3"
        if reading == "receipt_decision_unchecked" and oc["expected"] == "detected":
            return "A6"
        if attacker == "plain" and assumes_forgery:
            return "P1"
        if op == "change-rules":
            return "C1"
        if op == "relabel-approved":
            return "C2"
        if cfg == "full" and assumes_a1 and op in ("strip-flag", "invent-flag"):
            return "S1"
        return "unexplained"
    if cfg.startswith("no-replay"):
        return "V2"
    if reading.startswith("no_snapshot_forgery"):
        return "F1"
    if reading.startswith("snapshot_bound") and cfg == "no-snapshot-bound-only":
        return "S2"
    return "unexplained"


def main():
    results, ocells, controls = load()
    rows = results["rows"]
    runs = results["runs"]
    not_applied = [r for r in rows if not r["applied"]]
    applied = [r for r in rows if r["applied"]]

    # rows per (cell, variant), runs kept separate
    by_cell_variant = collections.defaultdict(list)
    for r in applied:
        by_cell_variant[(r["verifier_config"], r["anchors"], r["design"], r["operator"], r["keyset"], r["variant"])].append(r)

    # strongest attacker per (cell, run)
    per_run = collections.defaultdict(lambda: collections.defaultdict(list))
    for r in applied:
        per_run[(r["verifier_config"], r["anchors"], r["design"], r["operator"], r["keyset"])][r["run"]].append(r["detected"])

    cell_rows, cell_index, unstable = [], {}, []
    for cfg in CONFIGS:
        for anchors in ANCHORS:
            for design in DESIGNS:
                for op in OPERATORS:
                    for ks in KEYSETS:
                        key = (cfg, anchors, design, op, ks)
                        run_map = per_run.get(key, {})
                        strongest_flags = [all(v) for _, v in sorted(run_map.items())]
                        rec = {"verifier_config": cfg, "anchors": anchors, "design": design,
                               "operator": op, "keyset": ks, "runs": len(strongest_flags),
                               "detected_runs": sum(strongest_flags), "outcome": outcome_of(strongest_flags)}
                        evading, checks_stable = set(), True
                        for v in VARIANTS:
                            rs = by_cell_variant.get(key + (v,), [])
                            o = outcome_of([r["detected"] for r in rs])
                            rec[v] = o
                            modal = collections.Counter(" ".join(r.get("failing_checks") or []) for r in rs)
                            rec[v + "_checks"] = modal.most_common(1)[0][0] if modal else ""
                            if len(modal) > 1:
                                checks_stable = False
                            if o in ("undetected", "mixed"):
                                evading.add(v)
                            if o == "mixed":
                                unstable.append(key + (v,))
                            assur = collections.Counter(r["assurance"] for r in rs)
                            rec[v + "_assurance"] = " ".join(f"{k}:{n}" for k, n in sorted(assur.items()))
                            rec[v + "_unrepaired"] = max((len(r.get("unrepaired") or []) for r in rs), default=0)
                        rec["evading_variants"] = " ".join(v for v in VARIANTS if v in evading)
                        rec["checks_stable"] = checks_stable
                        if rec["outcome"] == "mixed":
                            unstable.append(key)
                        ok = oracle_keyset(ks)
                        oc = ocells.get((op, ok, anchors, design)) if ok else None
                        for reading in ALL_READINGS:
                            rec["oracle_" + reading] = oracle_label(oc, reading) if oc else ""
                        rec["oracle_anchor_only"] = oc["anchor_only"] if oc else ""
                        cell_rows.append(rec)
                        cell_index[key] = rec

    # --- matrices -----------------------------------------------------------
    matrices = {}
    for cfg in CONFIGS:
        for anchors in ANCHORS:
            for design in DESIGNS:
                m = {"strongest": {}, "plain": {}}
                for op in OPERATORS:
                    m["strongest"][op] = {ks: cell_index[(cfg, anchors, design, op, ks)]["outcome"] for ks in KEYSETS}
                    m["plain"][op] = {ks: cell_index[(cfg, anchors, design, op, ks)]["plain"] for ks in KEYSETS}
                matrices[f"{cfg}|{anchors}|{design}"] = m

    # --- flips ---------------------------------------------------------------
    def kind_of(b, u):
        if b == u:
            return ""
        if b == "detected" and u == "undetected":
            return "binding"
        if b == "undetected" and u == "detected":
            return "reverse"
        return "mixed"

    flips = []
    for cfg in CONFIGS:
        for anchors in ANCHORS:
            for op in OPERATORS:
                for ks in KEYSETS:
                    b = cell_index[(cfg, anchors, "bound", op, ks)]
                    u = cell_index[(cfg, anchors, "unbound", op, ks)]
                    k_strong, k_plain = kind_of(b["outcome"], u["outcome"]), kind_of(b["plain"], u["plain"])
                    if not k_strong and not k_plain:
                        continue
                    flips.append({
                        "verifier_config": cfg, "anchors": anchors, "operator": op, "keyset": ks,
                        "in_oracle_keysets": oracle_keyset(ks) is not None,
                        "bound": b["outcome"], "unbound": u["outcome"], "kind": k_strong or "none",
                        "bound_evading": b["evading_variants"], "unbound_evading": u["evading_variants"],
                        "plain_bound": b["plain"], "plain_unbound": u["plain"], "plain_kind": k_plain or "none",
                        "bound_checks": b["plain_checks"] if b["outcome"] == "detected" else b["forge-restate_checks"] or b["plain_checks"],
                        "unbound_checks": u["plain_checks"],
                        "oracle_primary_flip": _oracle_flip(ocells, op, ks, anchors, "primary"),
                        "oracle_mapped_flip": _oracle_flip(ocells, op, ks, anchors, MAPPED.get((cfg, "strongest"), "")),
                    })
    flip_counts = collections.Counter()
    for f in flips:
        if f["kind"] != "none":
            flip_counts[(f["verifier_config"], "strongest", f["kind"], "all")] += 1
            if f["in_oracle_keysets"]:
                flip_counts[(f["verifier_config"], "strongest", f["kind"], "oracle_keysets")] += 1
        if f["plain_kind"] != "none":
            flip_counts[(f["verifier_config"], "plain", f["plain_kind"], "all")] += 1
            if f["in_oracle_keysets"]:
                flip_counts[(f["verifier_config"], "plain", f["plain_kind"], "oracle_keysets")] += 1

    # --- key sets (per config, design, operator; anchors none and keys) ------
    keysets = {}
    for cfg in CONFIGS:
        for anchors in ["none", "keys"]:
            for design in DESIGNS:
                for op in OPERATORS:
                    for attacker, field in (("strongest", "outcome"), ("plain", "plain")):
                        suff = [ks for ks in KEYSETS if cell_index[(cfg, anchors, design, op, ks)][field] == "undetected"]
                        minimal = [ks for ks in suff if not any(ROLES[o] < ROLES[ks] for o in suff if o != ks)]
                        necessary = sorted(set.intersection(*[ROLES[ks] for ks in suff])) if suff else None
                        keysets[f"{cfg}|{anchors}|{design}|{op}|{attacker}"] = {
                            "sufficient": suff, "minimal_sufficient": minimal,
                            "necessary_roles": [ROLE_NAMES[x] for x in necessary] if necessary is not None else None,
                            "evading_variants": {ks: cell_index[(cfg, anchors, design, op, ks)]["evading_variants"] for ks in suff},
                        }

    # --- replacement keys ---------------------------------------------------
    replacement = []
    for cfg in CONFIGS:
        for design in DESIGNS:
            for op in OPERATORS:
                for ks in ["all-stolen", "all-replaced"]:
                    # the variant that evades with no anchor (the strongest attacker), else plain
                    evading = cell_index[(cfg, "none", design, op, ks)]["evading_variants"].split()
                    variant = evading[-1] if evading else "plain"
                    row = {"verifier_config": cfg, "design": design, "operator": op, "keyset": ks, "variant": variant}
                    for anchors in ANCHORS:
                        c = cell_index[(cfg, anchors, design, op, ks)]
                        row[anchors] = c["outcome"]
                        row[anchors + "_evading"] = c["evading_variants"]
                        row[anchors + "_checks"] = c[variant + "_checks"]
                    replacement.append(row)

    # --- oracle agreement (cell level) -----------------------------------------
    agreement, mismatches = [], []
    for cfg in CONFIGS:
        for attacker, field in (("strongest", "outcome"), ("plain", "plain")):
            for reading in ALL_READINGS:
                agree = disagree = total = mixed = 0
                v_det_o_undet = v_undet_o_det = 0
                for (c2, anchors, design, op, ks), rec in cell_index.items():
                    if c2 != cfg or not rec["oracle_" + reading]:
                        continue
                    total += 1
                    got = rec[field]
                    if got == "mixed":
                        mixed += 1
                        continue
                    if got == rec["oracle_" + reading]:
                        agree += 1
                        continue
                    disagree += 1
                    if got == "detected":
                        v_det_o_undet += 1
                    else:
                        v_undet_o_det += 1
                    mismatches.append({
                        "verifier_config": cfg, "attacker": attacker, "reading": reading,
                        "mapped_reading": MAPPED.get((cfg, attacker)) == reading,
                        "anchors": anchors, "design": design, "operator": op, "keyset": ks,
                        "verifier": got, "oracle": rec["oracle_" + reading],
                        "evading_variants": rec["evading_variants"],
                        "failing_checks": rec[(field if field != "outcome" else "plain") + "_checks"] if got == "detected" else "",
                        "forge_restate_checks": rec["forge-restate_checks"] if got == "detected" else "",
                        "cause": mismatch_cause(cfg, attacker, reading, design, op, ks, got,
                                                ocells.get((op, oracle_keyset(ks), anchors, design))),
                    })
                agreement.append({"verifier_config": cfg, "attacker": attacker, "reading": reading,
                                  "mapped": MAPPED.get((cfg, attacker)) == reading,
                                  "agree": agree, "disagree": disagree, "mixed": mixed, "total_cells": total,
                                  "verifier_detected_oracle_undetected": v_det_o_undet,
                                  "verifier_accepted_oracle_detected": v_undet_o_det})

    # --- unrepaired ---------------------------------------------------------
    def strip_ids(text):
        text = re.sub(r"operation [A-Za-z0-9_-]{6,}:", "operation X:", text)
        return re.sub(r"\b[0-9a-f]{32,}\b", "<hash>", text)
    unrep = collections.Counter()
    for r in applied:
        if r["verifier_config"] != "full" or r["anchors"] != "none":
            continue  # one row per mutant
        for u in sorted(set(strip_ids(x) for x in (r.get("unrepaired") or []))):
            n_items = sum(1 for x in (r.get("unrepaired") or []) if strip_ids(x) == u)
            unrep[(r["design"], r["operator"], r["variant"], u, n_items)] += 1
    unrepaired_rows = [{"design": d, "operator": o, "variant": v, "unrepaired": u, "items_per_mutant": k, "mutants": n}
                       for (d, o, v, u, k), n in sorted(unrep.items())]

    # --- not applicable -------------------------------------------------------
    na = collections.Counter((r["design"], r["operator"], r["variant"], r["not_applicable"]) for r in not_applied)

    # --- controls -----------------------------------------------------------
    ctrl = collections.Counter((c["verifier_config"], c["simulation"], c["verdict"]) for c in controls)
    ctrl_assurance = collections.Counter((c["verifier_config"], c["anchors"], c["simulation"], c["assurance"]) for c in controls)

    # --- per-config acceptance (strongest attacker, cell x run) -------------------
    acceptance = []
    for cfg in CONFIGS:
        for design in DESIGNS + ["both"]:
            total = acc = 0
            for (c2, anchors, d, op, ks), rec in cell_index.items():
                if c2 != cfg or (design != "both" and d != design):
                    continue
                total += rec["runs"]
                acc += rec["runs"] - rec["detected_runs"]
            acceptance.append({"verifier_config": cfg, "design": design, "cell_runs": total, "accepted": acc})

    run_level = collections.Counter((r["verifier_config"], r["design"], r["variant"], r["detected"]) for r in applied)
    analysis = {
        "source": "results.json from agentgate-eval compromise (format %s; key-compromise SIMULATION)" % results.get("format"),
        "runs": runs,
        "rows_total": len(rows), "rows_applied": len(applied), "rows_not_applied": len(not_applied),
        "not_applicable": [{"design": d, "operator": o, "variant": v, "reason": re.sub(r"run-[0-9-]+[0-9a-f]{6}", "run-X", why), "rows": n}
                           for (d, o, v, why), n in sorted(na.items())],
        "unstable_cells": [list(k) for k in unstable],
        "cells_with_unstable_failing_checks": sum(1 for r in cell_rows if not r["checks_stable"]),
        "acceptance_strongest": acceptance,
        "run_level_counts": {f"{c}|{d}|{v}|{'detected' if det else 'accepted'}": n for (c, d, v, det), n in sorted(run_level.items())},
        "flip_counts": {"|".join(k): n for k, n in sorted(flip_counts.items())},
        "flips": flips,
        "keysets": keysets,
        "replacement_keys": replacement,
        "oracle_agreement": agreement,
        "oracle_mismatches": mismatches,
        "mismatch_causes": CAUSES,
        "mismatch_cause_counts": {"|".join(k): n for k, n in sorted(collections.Counter(
            (m["verifier_config"], m["attacker"], m["reading"], m["cause"]) for m in mismatches).items())},
        "unrepaired": unrepaired_rows,
        "controls": {"verifications": len(controls),
                     "by_config_simulation_verdict": {"|".join(k): n for k, n in sorted(ctrl.items())},
                     "assurance": {"|".join(k): n for k, n in sorted(ctrl_assurance.items())}},
        "matrices": matrices,
    }
    write_csv("cells.csv", cell_rows)
    write_csv("flips.csv", flips, list(flips[0].keys()) if flips else ["empty"])
    write_csv("replacement_keys.csv", replacement)
    write_csv("oracle_agreement.csv", agreement)
    write_csv("oracle_mismatches.csv", mismatches, ["verifier_config", "attacker", "reading", "mapped_reading", "anchors", "design",
                                                     "operator", "keyset", "verifier", "oracle", "evading_variants",
                                                     "failing_checks", "forge_restate_checks", "cause"])
    write_csv("unrepaired.csv", unrepaired_rows, ["design", "operator", "variant", "unrepaired", "items_per_mutant", "mutants"])
    for name, doc in (("matrices.json", matrices), ("keysets.json", keysets), ("analysis.json", analysis)):
        with open(os.path.join(RESULTS_DIR, name), "w", encoding="utf-8", newline="\n") as f:
            json.dump(doc, f, indent=1)
            f.write("\n")
    print_summary(analysis, cell_index)


def _oracle_flip(ocells, op, ks, anchors, reading):
    ok = oracle_keyset(ks)
    if not ok or not reading:
        return ""
    b = oracle_label(ocells.get((op, ok, anchors, "bound")), reading)
    u = oracle_label(ocells.get((op, ok, anchors, "unbound")), reading)
    return "yes" if (b == "detected" and u == "undetected") else "no"


def write_csv(name, rows, fields=None):
    if not rows and not fields:
        fields = ["empty"]
    fields = fields or list(rows[0].keys())
    with open(os.path.join(RESULTS_DIR, name), "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, lineterminator="\n")
        w.writeheader()
        for r in rows:
            w.writerow(r)


def print_summary(a, cell_index):
    print(f"runs={a['runs']} rows={a['rows_total']} applied={a['rows_applied']} not_applied={a['rows_not_applied']}")
    print("unstable cells:", len(a["unstable_cells"]), "cells with unstable failing checks:", a["cells_with_unstable_failing_checks"])
    print("controls:", a["controls"]["by_config_simulation_verdict"])
    for r in a["acceptance_strongest"]:
        print("  accepted (strongest, cell x run)", r)
    print("flip counts:", json.dumps(a["flip_counts"], indent=1))
    short = {"none": "-", "audit": "A", "issuer": "I", "adapter": "D", "provider": "P", "delegation": "G",
             "audit+issuer": "AI", "audit+issuer+adapter": "AID", "audit+issuer+adapter+provider": "AIDP",
             "audit+issuer+adapter+approval": "AIDH", "all-stolen": "ALLs", "all-replaced": "ALLr"}
    sym = {"detected": ".", "undetected": "U", "mixed": "?", "n/a": "x"}
    for cfg in CONFIGS:
        for anchors in ANCHORS:
            print(f"\n== {cfg} / anchors {anchors}   strongest[plain]  (U = accepted in every run, . = detected, ? = mixed)")
            print(f"{'operator':18s} {'design':8s} " + " ".join(f"{short[k]:>7s}" for k in KEYSETS))
            for op in OPERATORS:
                for d in DESIGNS:
                    cells = []
                    for ks in KEYSETS:
                        c = cell_index[(cfg, anchors, d, op, ks)]
                        cells.append(sym[c["outcome"]] + "[" + sym[c["plain"]] + "]")
                    print(f"{op:18s} {d:8s} " + " ".join(f"{c:>7s}" for c in cells))
    print("\noracle agreement (cells):")
    for r in a["oracle_agreement"]:
        print(f"  {r['verifier_config']:22s} {r['attacker']:9s} {r['reading']:34s} {r['agree']:4d}/{r['total_cells']}"
              f" vdet/oundet {r['verifier_detected_oracle_undetected']} vacc/odet {r['verifier_accepted_oracle_detected']}"
              f"{'  <- mapped' if r['mapped'] else ''}")


if __name__ == "__main__":
    main()
