#!/usr/bin/env python3
"""Clean controls for the compromise experiment's base runs.

For every base run (work/run-NN/{flag,human}-{bound,unbound}/run-*/ with a
selftest-report.json):
  * the self-test's own in-process verification (VerifyRun with the demo's
    pinned keys and head, UnboundFlags for the ablation) from
    selftest-report.json;
  * a separate agentgate-verify CLI process (a REAL verification, no
    simulation) under the four anchor conditions, anchors taken from the
    unmodified folder (SHA-256 of keys.json, head.json entry_hash). The CLI has
    no UnboundFlags option, so unbound runs are expected to FAIL there
    (op.requires_policy): this is the effect the runner fix removes.
Writes base_controls.csv / base_controls.json into OUT_DIR.
Usage: python base_controls.py WORK_DIR VERIFY_EXE OUT_DIR
"""
import csv
import glob
import hashlib
import json
import os
import subprocess
import sys

work, verify_exe, out_dir = sys.argv[1], sys.argv[2], sys.argv[3]
rows = []
for report_path in sorted(glob.glob(os.path.join(work, "run-*", "*", "run-*", "selftest-report.json"))):
    run_dir = os.path.dirname(report_path)
    base = os.path.basename(os.path.dirname(run_dir))  # flag-bound etc.
    run_no = os.path.basename(os.path.dirname(os.path.dirname(run_dir)))
    with open(report_path, encoding="utf-8") as f:
        st = json.load(f)
    v = st.get("verifier", {})
    keys_sha = hashlib.sha256(open(os.path.join(run_dir, "keys.json"), "rb").read()).hexdigest()
    head = json.load(open(os.path.join(run_dir, "head.json"), encoding="utf-8"))["entry_hash"]
    row = {"run": run_no, "base": base, "selftest_passed": st.get("passed"),
           "selftest_verdict": v.get("verdict"), "selftest_assurance": v.get("assurance"),
           "selftest_checks_passed": v.get("checks_passed"), "selftest_checks_failed": v.get("checks_failed"),
           "selftest_keys_pinned": v.get("live_keys_pinned"), "selftest_head_pinned": v.get("live_head_pinned"),
           "head_matches_selftest_pin": head == v.get("after_shutdown_head_hash"),
           "entries": v.get("entries"), "operations": v.get("operations")}
    for anchors in ["none", "keys", "head", "both"]:
        args = [verify_exe, "--json"]
        if anchors in ("keys", "both"):
            args += ["--expect-keys", keys_sha]
        if anchors in ("head", "both"):
            args += ["--expect-head", head]
        args.append(run_dir)
        proc = subprocess.run(args, capture_output=True)
        try:
            rep = json.loads(proc.stdout.decode("utf-8"))
            fails = sorted({x.get("id") for x in (rep.get("failures") or [])})
            row[f"cli_{anchors}"] = f"{rep['verdict']}/{rep['assurance']}"
            row[f"cli_{anchors}_failing"] = " ".join(fails)
        except Exception as exc:  # noqa: BLE001
            row[f"cli_{anchors}"] = f"error exit {proc.returncode}: {exc}"
            row[f"cli_{anchors}_failing"] = ""
    rows.append(row)

with open(os.path.join(out_dir, "base_controls.csv"), "w", encoding="utf-8", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()), lineterminator="\n")
    w.writeheader()
    w.writerows(rows)
with open(os.path.join(out_dir, "base_controls.json"), "w", encoding="utf-8", newline="\n") as f:
    json.dump(rows, f, indent=1)
    f.write("\n")
from collections import Counter
print(len(rows), "base runs")
print(Counter((r["base"], r["selftest_verdict"], r["selftest_assurance"], r["selftest_checks_failed"]) for r in rows))
for a in ["none", "keys", "head", "both"]:
    print(a, Counter((r["base"], r[f"cli_{a}"], r[f"cli_{a}_failing"]) for r in rows))
print("head == self-test pin:", Counter(r["head_matches_selftest_pin"] for r in rows))
