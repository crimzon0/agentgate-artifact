"""Structural comparison of the build-1 and build-2 base runs of the compromise experiment.
For every audit log: entries, replayed COMMITTED call-scope answers and RECONCILED-committed records
(operation amount, flag stated, adapter receipt attached), flagged operations, and an order-aligned
comparison of (stage, outcome, effect_type, flag, scope, replayed, status) with build 1."""
import collections, glob, json, os, re, sys
b1, b2 = sys.argv[1], sys.argv[2]
def logs(work):
    out = {}
    for run in sorted(glob.glob(os.path.join(work, 'run-*'))):
        for base in sorted(glob.glob(os.path.join(run, '*-*bound'))):
            segs = sorted(glob.glob(os.path.join(base, 'run-*', 'audit.jsonl')))
            out[(os.path.basename(run), os.path.basename(base))] = segs
    return out
amount_re = re.compile(r'(AED|USD|EUR) ([0-9,]+\.[0-9]{2})')
def entries(p):
    return [json.loads(l)['entry'] for l in open(p, encoding='utf-8')]
def sig(e):
    d = e.get('details') or {}
    return (e.get('stage'), e.get('outcome'), e.get('effect_type'), bool(d.get('flagged')), d.get('scope'), d.get('replayed'), d.get('status'))
L1, L2 = logs(b1), logs(b2)
summary = collections.Counter(); notes = collections.Counter(); diffs = []
for key, segs in L2.items():
    summary['base runs'] += 1
    for i, seg in enumerate(segs):
        summary['audit logs'] += 1
        es = entries(seg)
        opdesc = {}
        for e in es:
            if e.get('stage') == 'AGENT_PROPOSED':
                m = amount_re.search(e.get('summary', ''))
                opdesc.setdefault(e.get('operation_id'), (m.group(0) if m else e.get('effect_type')))
        for e in es:
            d = e.get('details') or {}
            if e.get('stage') == 'CALL_RESULT' and d.get('scope') == 'call' and d.get('status') == 'COMMITTED':
                notes[('replayed COMMITTED answer', key[1], 'segment %d' % i, opdesc.get(e.get('operation_id'), '(earlier segment)'), 'flagged=%s' % bool(d.get('flagged')))] += 1
            if e.get('stage') == 'RECONCILED' and e.get('outcome') == 'committed':
                notes[('RECONCILED committed', key[1], 'segment %d' % i, opdesc.get(e.get('operation_id'), '?'), 'flagged=%s' % bool(d.get('flagged')), 'adapter receipt=%s' % ('effect_receipt' in (e.get('artifacts') or {})), 'artifacts=%s' % ','.join(sorted((e.get('artifacts') or {}).keys())))] += 1
            if e.get('stage') in ('EFFECT_EXECUTED',) and d.get('flagged'):
                notes[('flagged EFFECT_EXECUTED', key[1], opdesc.get(e.get('operation_id')))] += 1
        old = L1.get(key, [])
        if i < len(old):
            s1 = [sig(e) for e in entries(old[i])]; s2 = [sig(e) for e in es]
            if s1 != s2:
                n = sum(1 for a, b in zip(s1, s2) if a != b) + abs(len(s1) - len(s2))
                diffs.append((key, i, len(s1), len(s2), n, [(j, a, b) for j, (a, b) in enumerate(zip(s1, s2)) if a != b][:3]))
            else:
                summary['segments structurally equal to build 1'] += 1
for k, v in summary.items(): print('%s: %d' % (k, v))
for k, v in sorted(notes.items()): print(v, ' | '.join(k))
print('segments differing from build 1:', len(diffs))
for d in diffs[:10]: print(d)
