#!/usr/bin/env python3
"""Breakdowns asked for in the build-2 brief, computed from the files analyze_compromise.py writes.

  * binding flips per verifier configuration and anchor condition, out of 84 cells per
    anchor condition (7 operators x 12 key sets), 168 without a head anchor (none, keys),
    168 with one (head, both) and 336 in all; the same within the oracle's 10 key sets
    (70 / 140 / 140 / 280);
  * oracle agreement per configuration, attacker (strongest, plain) and design (bound,
    unbound; 280 cells each), for the mapped readings.
Writes breakdown.json and flips_by_anchor.csv next to this script. Standard library only.
Usage: python breakdown.py [RESULTS_DIR]
"""
import collections
import csv
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
D = sys.argv[1] if len(sys.argv) > 1 else HERE
CONFIGS = ["full", "no-snapshot-bound-only", "no-replay", "no-replay-no-snapshot"]
ANCHORS = ["none", "keys", "head", "both"]
ORACLE_KS = 10
ALL_KS = 12
OPS = 7
MAPPED = {"full": {"strongest": "snapshot_bound+mode_checked", "plain": "no_snapshot_forgery+mode_checked"},
          "no-snapshot-bound-only": {"strongest": "mode_checked", "plain": "no_snapshot_forgery+mode_checked"},
          "no-replay": {"strongest": "mode_checked", "plain": "mode_checked"},
          "no-replay-no-snapshot": {"strongest": "mode_checked", "plain": "mode_checked"}}


def rows(name):
    with open(os.path.join(D, name), encoding="utf-8") as f:
        return list(csv.DictReader(f))


flips = [r for r in rows("flips.csv") if r.get("kind") == "binding"]
reverse = [r for r in rows("flips.csv") if r.get("kind") == "reverse"]
by = collections.Counter((r["verifier_config"], r["anchors"]) for r in flips)
by_o = collections.Counter((r["verifier_config"], r["anchors"]) for r in flips if r["in_oracle_keysets"] == "True")
table = []
for cfg in CONFIGS:
    row = {"verifier_config": cfg}
    for a in ANCHORS:
        row[a] = "%d/%d" % (by[(cfg, a)], OPS * ALL_KS)
    nh = by[(cfg, "none")] + by[(cfg, "keys")]
    wh = by[(cfg, "head")] + by[(cfg, "both")]
    row["without_head_anchor"] = "%d/%d" % (nh, 2 * OPS * ALL_KS)
    row["with_head_anchor"] = "%d/%d" % (wh, 2 * OPS * ALL_KS)
    row["all"] = "%d/%d" % (nh + wh, 4 * OPS * ALL_KS)
    onh = by_o[(cfg, "none")] + by_o[(cfg, "keys")]
    ow = by_o[(cfg, "head")] + by_o[(cfg, "both")]
    row["oracle_keysets_without_head_anchor"] = "%d/%d" % (onh, 2 * OPS * ORACLE_KS)
    row["oracle_keysets_all"] = "%d/%d" % (onh + ow, 4 * OPS * ORACLE_KS)
    row["reverse"] = sum(1 for r in reverse if r["verifier_config"] == cfg)
    table.append(row)
with open(os.path.join(HERE, "flips_by_anchor.csv"), "w", encoding="utf-8", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(table[0].keys()), lineterminator="\n")
    w.writeheader()
    w.writerows(table)

cells = rows("cells.csv")
agree = []
for cfg in CONFIGS:
    for attacker, field in (("strongest", "outcome"), ("plain", "plain")):
        reading = MAPPED[cfg][attacker]
        for design in ["bound", "unbound", "both"]:
            sel = [c for c in cells if c["verifier_config"] == cfg and c["oracle_" + reading]
                   and (design == "both" or c["design"] == design)]
            ok = sum(1 for c in sel if c[field] == c["oracle_" + reading])
            agree.append({"verifier_config": cfg, "attacker": attacker, "reading": reading, "design": design,
                          "agree": ok, "cells": len(sel)})
out = {"flips_by_anchor": table, "oracle_agreement_by_design": agree}
with open(os.path.join(HERE, "breakdown.json"), "w", encoding="utf-8", newline="\n") as f:
    json.dump(out, f, indent=1)
    f.write("\n")
for r in table:
    print(r)
for r in agree:
    print("%-24s %-9s %-34s %-7s %d/%d" % (r["verifier_config"], r["attacker"], r["reading"], r["design"], r["agree"], r["cells"]))
