"""List the main-module files compiled into agentgate-eval and agentgate-verify (go list -deps),
hash them, and compare with build 1's build-manifest.txt list and build 2's MANIFEST.txt."""
import hashlib, json, os, re, subprocess, sys
repo, b1manifest, b2manifest, out = sys.argv[1:5]
go = os.path.join(repo, '.tools', 'go-1.26.6', 'bin', 'go.exe')
env = dict(os.environ, GOMODCACHE=os.path.join(repo, '.tools', 'go-host-cache-20260916', 'mod'), GOPROXY='off', GOFLAGS='-mod=readonly', GOTOOLCHAIN='local')
files = set()
for b in ('agentgate-eval', 'agentgate-verify'):
    r = subprocess.run([go, 'list', '-deps', '-json', './cmd/' + b + '/'], cwd=repo, env=env, capture_output=True, text=True, encoding='utf-8')
    dec = json.JSONDecoder(); s = r.stdout; i = 0
    while i < len(s):
        while i < len(s) and s[i].isspace(): i += 1
        if i >= len(s): break
        obj, i = dec.raw_decode(s, i)
        if not (obj.get('Module') or {}).get('Main'): continue
        d = obj['Dir']
        for key in ('GoFiles', 'CgoFiles', 'SFiles', 'CFiles', 'HFiles', 'EmbedFiles'):
            for f in obj.get(key) or []:
                files.add(os.path.relpath(os.path.join(d, f), repo).replace(os.sep, '/'))
def sha(p): return hashlib.sha256(open(os.path.join(repo, p), 'rb').read()).hexdigest()
cur = {p: sha(p) for p in sorted(files)}
b1 = {}
sect = False
for line in open(b1manifest, encoding='utf-8'):
    if line.startswith('compiled AgentGate source'): sect = True
    m = re.match(r'^\s+([0-9a-f]{64}) \*(\S+)$', line)
    if sect and m: b1[m.group(2)] = m.group(1)
b2 = {}
for line in open(b2manifest, encoding='utf-8'):
    m = re.match(r'^([0-9a-f]{64}) \*(.+)$', line)
    if m: b2[m.group(2)] = m.group(1)
lines = []
mism = [p for p in cur if b2.get(p) != cur[p]]
lines.append('compiled AgentGate source and embedded files of agentgate-eval and agentgate-verify (SHA-256; go list -deps, main module), %d files' % len(cur))
lines.append('(%d of %d equal to the build-2 MANIFEST.txt entries)' % (len(cur) - len(mism), len(cur)))
changed = [p for p in cur if p in b1 and b1[p] != cur[p]]
added = [p for p in cur if p not in b1]
removed = [p for p in b1 if p not in cur]
lines.append('compared with build 1 (docs/paper/data/revision/compromise/build-manifest.txt, %d files): %d changed, %d new, %d no longer compiled' % (len(b1), len(changed), len(added), len(removed)))
for title, lst in (('changed', changed), ('new', added), ('no longer compiled', removed)):
    for p in lst: lines.append('  %s: %s' % (title, p))
lines.append('')
for p, h in cur.items(): lines.append('  %s *%s' % (h, p))
open(out, 'w', encoding='utf-8', newline='\n').write('\n'.join(lines) + '\n')
print('\n'.join(lines[:3 + len(changed) + len(added) + len(removed) + 1]))
