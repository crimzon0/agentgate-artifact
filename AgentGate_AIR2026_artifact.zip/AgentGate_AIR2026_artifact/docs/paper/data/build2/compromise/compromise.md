# Key-compromise simulation results (R6.1)

**Simulation, not a real verification.** For each attacker key set the verifier accepted that
set's roles' signatures without verification (`auditverify.AssumeCompromised`). The mutation
engine edited content and recomputed hashes only; nothing was signed. A cell's strongest
attacker is the snapshot variant that evades (plain, forge-snapshot, forge-restate): the cell is
detected only when every applicable variant is detected.

Clean controls (unmutated base runs, real and all roles simulated, every anchor condition and configuration): 1280 verifications, **0 false alarms**.

## Not applicable

- change-amount / forge-restate: evalattack: change-amount: the decision is re-derived for the new amount under the recorded policy
- change-amount / forge-snapshot: evalattack: change-amount: the decision is re-derived for the new amount under the recorded policy
- change-escalation / forge-restate: evalattack: change-escalation: a flagged execution requires escalation mode flag, so no snapshot mode reproduces a flagged decision made in mode deny
- change-escalation / forge-snapshot: evalattack: change-escalation: a flagged execution requires escalation mode flag, so no snapshot mode reproduces a flagged decision made in mode deny
- change-rules / forge-restate: evalattack: change-rules: the target message has 1 recipient(s); MSG-BULK fires only above MaxRecipients, which must be at least 1, so no valid snapshot reproduces the forged rules
- change-rules / forge-snapshot: evalattack: change-rules: the target message has 1 recipient(s); MSG-BULK fires only above MaxRecipients, which must be at least 1, so no valid snapshot reproduces the forged rules
- swap-decisions / forge-restate: evalattack: swap-decisions: the transplanted values name the donor operation whatever the policy says
- swap-decisions / forge-snapshot: evalattack: swap-decisions: the transplanted values name the donor operation whatever the policy says

## Consequences the engine could not repair

(Operation IDs differ per run and are omitted.)

- bound/relabel-approved (forge-restate): forged snapshot: an operation: the action waited for a human, which the rules would not have asked for (rules FIN-AUTO give ALLOW_BASE)
- bound/relabel-approved (forge-snapshot): forged snapshot: an operation: the action waited for a human, which the rules would not have asked for (rules FIN-AUTO give ALLOW_BASE)
- unbound/relabel-approved (forge-restate): forged snapshot: an operation: the action waited for a human, which the rules would not have asked for (rules FIN-AUTO give ALLOW_BASE)
- unbound/relabel-approved (forge-snapshot): forged snapshot: an operation: the action waited for a human, which the rules would not have asked for (rules FIN-AUTO give ALLOW_BASE)

## Accepted cells per configuration (strongest attacker; all runs)

| configuration | cells | accepted | binding flips | reverse flips |
|---|---|---|---|---|
| full | 6720 | 460 | 0 | 0 |
| no-replay | 6720 | 940 | 120 | 0 |
| no-replay-no-snapshot | 6720 | 940 | 120 | 0 |
| no-snapshot-bound-only | 6720 | 540 | 80 | 0 |

Flip counts are cell x run. A binding flip is a cell detected in the bound design and accepted in the unbound one.

## Accepted (operator, key set, anchors) per configuration and design

| configuration | design | operator | anchors | accepted key sets [evading variants] |
|---|---|---|---|---|
| full | bound | change-amount | keys | all-stolen [plain]; audit+issuer+adapter+provider [plain] |
| full | bound | change-amount | none | all-replaced [plain]; all-stolen [plain]; audit+issuer+adapter+provider [plain] |
| full | bound | invent-flag | keys | all-stolen [forge-restate]; audit+issuer+adapter [forge-restate]; audit+issuer+adapter+approval [forge-restate]; audit+issuer+adapter+provider [forge-restate] |
| full | bound | invent-flag | none | all-replaced [forge-restate]; all-stolen [forge-restate]; audit+issuer+adapter [forge-restate]; audit+issuer+adapter+approval [forge-restate]; audit+issuer+adapter+provider [forge-restate] |
| full | bound | strip-flag | keys | all-stolen [forge-restate]; audit+issuer+adapter [forge-restate]; audit+issuer+adapter+approval [forge-restate]; audit+issuer+adapter+provider [forge-restate] |
| full | bound | strip-flag | none | all-replaced [forge-restate]; all-stolen [forge-restate]; audit+issuer+adapter [forge-restate]; audit+issuer+adapter+approval [forge-restate]; audit+issuer+adapter+provider [forge-restate] |
| full | unbound | change-amount | keys | all-stolen [plain]; audit+issuer+adapter+provider [plain] |
| full | unbound | change-amount | none | all-replaced [plain]; all-stolen [plain]; audit+issuer+adapter+provider [plain] |
| full | unbound | invent-flag | keys | all-stolen [forge-restate]; audit+issuer+adapter [forge-restate]; audit+issuer+adapter+approval [forge-restate]; audit+issuer+adapter+provider [forge-restate] |
| full | unbound | invent-flag | none | all-replaced [forge-restate]; all-stolen [forge-restate]; audit+issuer+adapter [forge-restate]; audit+issuer+adapter+approval [forge-restate]; audit+issuer+adapter+provider [forge-restate] |
| full | unbound | strip-flag | keys | all-stolen [forge-restate]; audit+issuer+adapter [forge-restate]; audit+issuer+adapter+approval [forge-restate]; audit+issuer+adapter+provider [forge-restate] |
| full | unbound | strip-flag | none | all-replaced [forge-restate]; all-stolen [forge-restate]; audit+issuer+adapter [forge-restate]; audit+issuer+adapter+approval [forge-restate]; audit+issuer+adapter+provider [forge-restate] |
| no-replay | bound | change-amount | keys | all-stolen [plain]; audit+issuer+adapter+provider [plain] |
| no-replay | bound | change-amount | none | all-replaced [plain]; all-stolen [plain]; audit+issuer+adapter+provider [plain] |
| no-replay | bound | change-rules | keys | all-stolen [plain]; audit+issuer+adapter [plain]; audit+issuer+adapter+approval [plain]; audit+issuer+adapter+provider [plain] |
| no-replay | bound | change-rules | none | all-replaced [plain]; all-stolen [plain]; audit+issuer+adapter [plain]; audit+issuer+adapter+approval [plain]; audit+issuer+adapter+provider [plain] |
| no-replay | bound | invent-flag | keys | all-stolen [plain,forge-restate]; audit+issuer+adapter [plain,forge-restate]; audit+issuer+adapter+approval [plain,forge-restate]; audit+issuer+adapter+provider [plain,forge-restate] |
| no-replay | bound | invent-flag | none | all-replaced [plain,forge-restate]; all-stolen [plain,forge-restate]; audit+issuer+adapter [plain,forge-restate]; audit+issuer+adapter+approval [plain,forge-restate]; audit+issuer+adapter+provider [plain,forge-restate] |
| no-replay | bound | relabel-approved | keys | all-stolen [plain,forge-restate]; audit+issuer+adapter [plain]; audit+issuer+adapter+approval [plain,forge-restate]; audit+issuer+adapter+provider [plain] |
| no-replay | bound | relabel-approved | none | all-replaced [plain,forge-restate]; all-stolen [plain,forge-restate]; audit+issuer+adapter [plain]; audit+issuer+adapter+approval [plain,forge-restate]; audit+issuer+adapter+provider [plain] |
| no-replay | bound | strip-flag | keys | all-stolen [plain,forge-restate]; audit+issuer+adapter [plain,forge-restate]; audit+issuer+adapter+approval [plain,forge-restate]; audit+issuer+adapter+provider [plain,forge-restate] |
| no-replay | bound | strip-flag | none | all-replaced [plain,forge-restate]; all-stolen [plain,forge-restate]; audit+issuer+adapter [plain,forge-restate]; audit+issuer+adapter+approval [plain,forge-restate]; audit+issuer+adapter+provider [plain,forge-restate] |
| no-replay | unbound | change-amount | keys | all-stolen [plain]; audit+issuer+adapter+provider [plain] |
| no-replay | unbound | change-amount | none | all-replaced [plain]; all-stolen [plain]; audit+issuer+adapter+provider [plain] |
| no-replay | unbound | change-rules | keys | all-stolen [plain]; audit [plain]; audit+issuer [plain]; audit+issuer+adapter [plain]; audit+issuer+adapter+approval [plain]; audit+issuer+adapter+provider [plain] |
| no-replay | unbound | change-rules | none | all-replaced [plain]; all-stolen [plain]; audit [plain]; audit+issuer [plain]; audit+issuer+adapter [plain]; audit+issuer+adapter+approval [plain]; audit+issuer+adapter+provider [plain] |
| no-replay | unbound | invent-flag | keys | all-stolen [plain,forge-restate]; audit [plain]; audit+issuer [plain]; audit+issuer+adapter [plain,forge-restate]; audit+issuer+adapter+approval [plain,forge-restate]; audit+issuer+adapter+provider [plain,forge-restate] |
| no-replay | unbound | invent-flag | none | all-replaced [plain,forge-restate]; all-stolen [plain,forge-restate]; audit [plain]; audit+issuer [plain]; audit+issuer+adapter [plain,forge-restate]; audit+issuer+adapter+approval [plain,forge-restate]; audit+issuer+adapter+provider [plain,forge-restate] |
| no-replay | unbound | relabel-approved | keys | all-stolen [plain,forge-restate]; audit+issuer+adapter [plain]; audit+issuer+adapter+approval [plain,forge-restate]; audit+issuer+adapter+provider [plain] |
| no-replay | unbound | relabel-approved | none | all-replaced [plain,forge-restate]; all-stolen [plain,forge-restate]; audit+issuer+adapter [plain]; audit+issuer+adapter+approval [plain,forge-restate]; audit+issuer+adapter+provider [plain] |
| no-replay | unbound | strip-flag | keys | all-stolen [plain,forge-restate]; audit [plain]; audit+issuer [plain]; audit+issuer+adapter [plain,forge-restate]; audit+issuer+adapter+approval [plain,forge-restate]; audit+issuer+adapter+provider [plain,forge-restate] |
| no-replay | unbound | strip-flag | none | all-replaced [plain,forge-restate]; all-stolen [plain,forge-restate]; audit [plain]; audit+issuer [plain]; audit+issuer+adapter [plain,forge-restate]; audit+issuer+adapter+approval [plain,forge-restate]; audit+issuer+adapter+provider [plain,forge-restate] |
| no-replay-no-snapshot | bound | change-amount | keys | all-stolen [plain]; audit+issuer+adapter+provider [plain] |
| no-replay-no-snapshot | bound | change-amount | none | all-replaced [plain]; all-stolen [plain]; audit+issuer+adapter+provider [plain] |
| no-replay-no-snapshot | bound | change-rules | keys | all-stolen [plain]; audit+issuer+adapter [plain]; audit+issuer+adapter+approval [plain]; audit+issuer+adapter+provider [plain] |
| no-replay-no-snapshot | bound | change-rules | none | all-replaced [plain]; all-stolen [plain]; audit+issuer+adapter [plain]; audit+issuer+adapter+approval [plain]; audit+issuer+adapter+provider [plain] |
| no-replay-no-snapshot | bound | invent-flag | keys | all-stolen [plain,forge-snapshot,forge-restate]; audit+issuer+adapter [plain,forge-snapshot,forge-restate]; audit+issuer+adapter+approval [plain,forge-snapshot,forge-restate]; audit+issuer+adapter+provider [plain,forge-snapshot,forge-restate] |
| no-replay-no-snapshot | bound | invent-flag | none | all-replaced [plain,forge-snapshot,forge-restate]; all-stolen [plain,forge-snapshot,forge-restate]; audit+issuer+adapter [plain,forge-snapshot,forge-restate]; audit+issuer+adapter+approval [plain,forge-snapshot,forge-restate]; audit+issuer+adapter+provider [plain,forge-snapshot,forge-restate] |
| no-replay-no-snapshot | bound | relabel-approved | keys | all-stolen [plain,forge-snapshot,forge-restate]; audit+issuer+adapter [plain,forge-snapshot]; audit+issuer+adapter+approval [plain,forge-snapshot,forge-restate]; audit+issuer+adapter+provider [plain,forge-snapshot] |
| no-replay-no-snapshot | bound | relabel-approved | none | all-replaced [plain,forge-snapshot,forge-restate]; all-stolen [plain,forge-snapshot,forge-restate]; audit+issuer+adapter [plain,forge-snapshot]; audit+issuer+adapter+approval [plain,forge-snapshot,forge-restate]; audit+issuer+adapter+provider [plain,forge-snapshot] |
| no-replay-no-snapshot | bound | strip-flag | keys | all-stolen [plain,forge-snapshot,forge-restate]; audit+issuer+adapter [plain,forge-snapshot,forge-restate]; audit+issuer+adapter+approval [plain,forge-snapshot,forge-restate]; audit+issuer+adapter+provider [plain,forge-snapshot,forge-restate] |
| no-replay-no-snapshot | bound | strip-flag | none | all-replaced [plain,forge-snapshot,forge-restate]; all-stolen [plain,forge-snapshot,forge-restate]; audit+issuer+adapter [plain,forge-snapshot,forge-restate]; audit+issuer+adapter+approval [plain,forge-snapshot,forge-restate]; audit+issuer+adapter+provider [plain,forge-snapshot,forge-restate] |
| no-replay-no-snapshot | unbound | change-amount | keys | all-stolen [plain]; audit+issuer+adapter+provider [plain] |
| no-replay-no-snapshot | unbound | change-amount | none | all-replaced [plain]; all-stolen [plain]; audit+issuer+adapter+provider [plain] |
| no-replay-no-snapshot | unbound | change-rules | keys | all-stolen [plain]; audit [plain]; audit+issuer [plain]; audit+issuer+adapter [plain]; audit+issuer+adapter+approval [plain]; audit+issuer+adapter+provider [plain] |
| no-replay-no-snapshot | unbound | change-rules | none | all-replaced [plain]; all-stolen [plain]; audit [plain]; audit+issuer [plain]; audit+issuer+adapter [plain]; audit+issuer+adapter+approval [plain]; audit+issuer+adapter+provider [plain] |
| no-replay-no-snapshot | unbound | invent-flag | keys | all-stolen [plain,forge-snapshot,forge-restate]; audit [plain,forge-snapshot]; audit+issuer [plain,forge-snapshot]; audit+issuer+adapter [plain,forge-snapshot,forge-restate]; audit+issuer+adapter+approval [plain,forge-snapshot,forge-restate]; audit+issuer+adapter+provider [plain,forge-snapshot,forge-restate] |
| no-replay-no-snapshot | unbound | invent-flag | none | all-replaced [plain,forge-snapshot,forge-restate]; all-stolen [plain,forge-snapshot,forge-restate]; audit [plain,forge-snapshot]; audit+issuer [plain,forge-snapshot]; audit+issuer+adapter [plain,forge-snapshot,forge-restate]; audit+issuer+adapter+approval [plain,forge-snapshot,forge-restate]; audit+issuer+adapter+provider [plain,forge-snapshot,forge-restate] |
| no-replay-no-snapshot | unbound | relabel-approved | keys | all-stolen [plain,forge-snapshot,forge-restate]; audit+issuer+adapter [plain,forge-snapshot]; audit+issuer+adapter+approval [plain,forge-snapshot,forge-restate]; audit+issuer+adapter+provider [plain,forge-snapshot] |
| no-replay-no-snapshot | unbound | relabel-approved | none | all-replaced [plain,forge-snapshot,forge-restate]; all-stolen [plain,forge-snapshot,forge-restate]; audit+issuer+adapter [plain,forge-snapshot]; audit+issuer+adapter+approval [plain,forge-snapshot,forge-restate]; audit+issuer+adapter+provider [plain,forge-snapshot] |
| no-replay-no-snapshot | unbound | strip-flag | keys | all-stolen [plain,forge-snapshot,forge-restate]; audit [plain,forge-snapshot]; audit+issuer [plain,forge-snapshot]; audit+issuer+adapter [plain,forge-snapshot,forge-restate]; audit+issuer+adapter+approval [plain,forge-snapshot,forge-restate]; audit+issuer+adapter+provider [plain,forge-snapshot,forge-restate] |
| no-replay-no-snapshot | unbound | strip-flag | none | all-replaced [plain,forge-snapshot,forge-restate]; all-stolen [plain,forge-snapshot,forge-restate]; audit [plain,forge-snapshot]; audit+issuer [plain,forge-snapshot]; audit+issuer+adapter [plain,forge-snapshot,forge-restate]; audit+issuer+adapter+approval [plain,forge-snapshot,forge-restate]; audit+issuer+adapter+provider [plain,forge-snapshot,forge-restate] |
| no-snapshot-bound-only | bound | change-amount | keys | all-stolen [plain]; audit+issuer+adapter+provider [plain] |
| no-snapshot-bound-only | bound | change-amount | none | all-replaced [plain]; all-stolen [plain]; audit+issuer+adapter+provider [plain] |
| no-snapshot-bound-only | bound | invent-flag | keys | all-stolen [forge-snapshot,forge-restate]; audit+issuer+adapter [forge-snapshot,forge-restate]; audit+issuer+adapter+approval [forge-snapshot,forge-restate]; audit+issuer+adapter+provider [forge-snapshot,forge-restate] |
| no-snapshot-bound-only | bound | invent-flag | none | all-replaced [forge-snapshot,forge-restate]; all-stolen [forge-snapshot,forge-restate]; audit+issuer+adapter [forge-snapshot,forge-restate]; audit+issuer+adapter+approval [forge-snapshot,forge-restate]; audit+issuer+adapter+provider [forge-snapshot,forge-restate] |
| no-snapshot-bound-only | bound | strip-flag | keys | all-stolen [forge-snapshot,forge-restate]; audit+issuer+adapter [forge-snapshot,forge-restate]; audit+issuer+adapter+approval [forge-snapshot,forge-restate]; audit+issuer+adapter+provider [forge-snapshot,forge-restate] |
| no-snapshot-bound-only | bound | strip-flag | none | all-replaced [forge-snapshot,forge-restate]; all-stolen [forge-snapshot,forge-restate]; audit+issuer+adapter [forge-snapshot,forge-restate]; audit+issuer+adapter+approval [forge-snapshot,forge-restate]; audit+issuer+adapter+provider [forge-snapshot,forge-restate] |
| no-snapshot-bound-only | unbound | change-amount | keys | all-stolen [plain]; audit+issuer+adapter+provider [plain] |
| no-snapshot-bound-only | unbound | change-amount | none | all-replaced [plain]; all-stolen [plain]; audit+issuer+adapter+provider [plain] |
| no-snapshot-bound-only | unbound | invent-flag | keys | all-stolen [forge-snapshot,forge-restate]; audit [forge-snapshot]; audit+issuer [forge-snapshot]; audit+issuer+adapter [forge-snapshot,forge-restate]; audit+issuer+adapter+approval [forge-snapshot,forge-restate]; audit+issuer+adapter+provider [forge-snapshot,forge-restate] |
| no-snapshot-bound-only | unbound | invent-flag | none | all-replaced [forge-snapshot,forge-restate]; all-stolen [forge-snapshot,forge-restate]; audit [forge-snapshot]; audit+issuer [forge-snapshot]; audit+issuer+adapter [forge-snapshot,forge-restate]; audit+issuer+adapter+approval [forge-snapshot,forge-restate]; audit+issuer+adapter+provider [forge-snapshot,forge-restate] |
| no-snapshot-bound-only | unbound | strip-flag | keys | all-stolen [forge-snapshot,forge-restate]; audit [forge-snapshot]; audit+issuer [forge-snapshot]; audit+issuer+adapter [forge-snapshot,forge-restate]; audit+issuer+adapter+approval [forge-snapshot,forge-restate]; audit+issuer+adapter+provider [forge-snapshot,forge-restate] |
| no-snapshot-bound-only | unbound | strip-flag | none | all-replaced [forge-snapshot,forge-restate]; all-stolen [forge-snapshot,forge-restate]; audit [forge-snapshot]; audit+issuer [forge-snapshot]; audit+issuer+adapter [forge-snapshot,forge-restate]; audit+issuer+adapter+approval [forge-snapshot,forge-restate]; audit+issuer+adapter+provider [forge-snapshot,forge-restate] |

## Binding flips (strongest attacker)

| configuration | operator | key set | anchors | runs | reverse |
|---|---|---|---|---|---|
| no-replay | change-rules | audit | keys | 10 | false |
| no-replay | change-rules | audit | none | 10 | false |
| no-replay | change-rules | audit+issuer | keys | 10 | false |
| no-replay | change-rules | audit+issuer | none | 10 | false |
| no-replay | invent-flag | audit | keys | 10 | false |
| no-replay | invent-flag | audit | none | 10 | false |
| no-replay | invent-flag | audit+issuer | keys | 10 | false |
| no-replay | invent-flag | audit+issuer | none | 10 | false |
| no-replay | strip-flag | audit | keys | 10 | false |
| no-replay | strip-flag | audit | none | 10 | false |
| no-replay | strip-flag | audit+issuer | keys | 10 | false |
| no-replay | strip-flag | audit+issuer | none | 10 | false |
| no-replay-no-snapshot | change-rules | audit | keys | 10 | false |
| no-replay-no-snapshot | change-rules | audit | none | 10 | false |
| no-replay-no-snapshot | change-rules | audit+issuer | keys | 10 | false |
| no-replay-no-snapshot | change-rules | audit+issuer | none | 10 | false |
| no-replay-no-snapshot | invent-flag | audit | keys | 10 | false |
| no-replay-no-snapshot | invent-flag | audit | none | 10 | false |
| no-replay-no-snapshot | invent-flag | audit+issuer | keys | 10 | false |
| no-replay-no-snapshot | invent-flag | audit+issuer | none | 10 | false |
| no-replay-no-snapshot | strip-flag | audit | keys | 10 | false |
| no-replay-no-snapshot | strip-flag | audit | none | 10 | false |
| no-replay-no-snapshot | strip-flag | audit+issuer | keys | 10 | false |
| no-replay-no-snapshot | strip-flag | audit+issuer | none | 10 | false |
| no-snapshot-bound-only | invent-flag | audit | keys | 10 | false |
| no-snapshot-bound-only | invent-flag | audit | none | 10 | false |
| no-snapshot-bound-only | invent-flag | audit+issuer | keys | 10 | false |
| no-snapshot-bound-only | invent-flag | audit+issuer | none | 10 | false |
| no-snapshot-bound-only | strip-flag | audit | keys | 10 | false |
| no-snapshot-bound-only | strip-flag | audit | none | 10 | false |
| no-snapshot-bound-only | strip-flag | audit+issuer | keys | 10 | false |
| no-snapshot-bound-only | strip-flag | audit+issuer | none | 10 | false |

## Oracle agreement (cells x runs; strongest attacker / plain variant)

| configuration | reading | strongest agree/total | plain agree/total |
|---|---|---|---|
| full | primary | 5140/5600 | 4940/5600 |
| full | no_snapshot_forgery | 5260/5600 | 5460/5600 |
| full | snapshot_bound | 5260/5600 | 5060/5600 |
| full | mode_checked | 5280/5600 | 5080/5600 |
| full | receipt_decision_unchecked | 5020/5600 | 4820/5600 |
| full | snapshot_bound+mode_checked | 5400/5600 | 5200/5600 |
| full | no_snapshot_forgery+mode_checked | 5400/5600 | 5600/5600 |
| no-replay | primary | 5460/5600 | 5460/5600 |
| no-replay | no_snapshot_forgery | 4940/5600 | 4940/5600 |
| no-replay | snapshot_bound | 5340/5600 | 5340/5600 |
| no-replay | mode_checked | 5600/5600 | 5600/5600 |
| no-replay | receipt_decision_unchecked | 5340/5600 | 5340/5600 |
| no-replay | snapshot_bound+mode_checked | 5480/5600 | 5480/5600 |
| no-replay | no_snapshot_forgery+mode_checked | 5080/5600 | 5080/5600 |
| no-replay-no-snapshot | primary | 5460/5600 | 5460/5600 |
| no-replay-no-snapshot | no_snapshot_forgery | 4940/5600 | 4940/5600 |
| no-replay-no-snapshot | snapshot_bound | 5340/5600 | 5340/5600 |
| no-replay-no-snapshot | mode_checked | 5600/5600 | 5600/5600 |
| no-replay-no-snapshot | receipt_decision_unchecked | 5340/5600 | 5340/5600 |
| no-replay-no-snapshot | snapshot_bound+mode_checked | 5480/5600 | 5480/5600 |
| no-replay-no-snapshot | no_snapshot_forgery+mode_checked | 5080/5600 | 5080/5600 |
| no-snapshot-bound-only | primary | 5220/5600 | 4940/5600 |
| no-snapshot-bound-only | no_snapshot_forgery | 5180/5600 | 5460/5600 |
| no-snapshot-bound-only | snapshot_bound | 5180/5600 | 5060/5600 |
| no-snapshot-bound-only | mode_checked | 5360/5600 | 5080/5600 |
| no-snapshot-bound-only | receipt_decision_unchecked | 5100/5600 | 4820/5600 |
| no-snapshot-bound-only | snapshot_bound+mode_checked | 5320/5600 | 5200/5600 |
| no-snapshot-bound-only | no_snapshot_forgery+mode_checked | 5320/5600 | 5600/5600 |

The readings that describe a configuration: full verifier + strongest attacker = `snapshot_bound+mode_checked`;
full verifier + plain attacker = `no_snapshot_forgery+mode_checked`; no-snapshot-bound-only + strongest
attacker = `mode_checked` (the primary reading with the escalation mode checked). The no-replay
configurations have no oracle reading. Readings joined with `+` are computed here (detected when
either single-assumption reading says detected), not by the oracle.

## Disagreements with the mapped reading (strongest attacker; one line per cell)

| configuration | reading | operator | key set | anchors | design | verifier | oracle | runs |
|---|---|---|---|---|---|---|---|---|
| full | snapshot_bound+mode_checked | change-rules | all-replaced | none | bound | detected | undetected | 10 |
| full | snapshot_bound+mode_checked | change-rules | all-replaced | none | unbound | detected | undetected | 10 |
| full | snapshot_bound+mode_checked | change-rules | audit+issuer+adapter+provider | keys | bound | detected | undetected | 10 |
| full | snapshot_bound+mode_checked | change-rules | audit+issuer+adapter+provider | keys | unbound | detected | undetected | 10 |
| full | snapshot_bound+mode_checked | change-rules | audit+issuer+adapter+provider | none | bound | detected | undetected | 10 |
| full | snapshot_bound+mode_checked | change-rules | audit+issuer+adapter+provider | none | unbound | detected | undetected | 10 |
| full | snapshot_bound+mode_checked | change-rules | audit+issuer+adapter | keys | bound | detected | undetected | 10 |
| full | snapshot_bound+mode_checked | change-rules | audit+issuer+adapter | keys | unbound | detected | undetected | 10 |
| full | snapshot_bound+mode_checked | change-rules | audit+issuer+adapter | none | bound | detected | undetected | 10 |
| full | snapshot_bound+mode_checked | change-rules | audit+issuer+adapter | none | unbound | detected | undetected | 10 |
| full | snapshot_bound+mode_checked | relabel-approved | all-replaced | none | bound | detected | undetected | 10 |
| full | snapshot_bound+mode_checked | relabel-approved | all-replaced | none | unbound | detected | undetected | 10 |
| full | snapshot_bound+mode_checked | relabel-approved | audit+issuer+adapter+provider | keys | bound | detected | undetected | 10 |
| full | snapshot_bound+mode_checked | relabel-approved | audit+issuer+adapter+provider | keys | unbound | detected | undetected | 10 |
| full | snapshot_bound+mode_checked | relabel-approved | audit+issuer+adapter+provider | none | bound | detected | undetected | 10 |
| full | snapshot_bound+mode_checked | relabel-approved | audit+issuer+adapter+provider | none | unbound | detected | undetected | 10 |
| full | snapshot_bound+mode_checked | relabel-approved | audit+issuer+adapter | keys | bound | detected | undetected | 10 |
| full | snapshot_bound+mode_checked | relabel-approved | audit+issuer+adapter | keys | unbound | detected | undetected | 10 |
| full | snapshot_bound+mode_checked | relabel-approved | audit+issuer+adapter | none | bound | detected | undetected | 10 |
| full | snapshot_bound+mode_checked | relabel-approved | audit+issuer+adapter | none | unbound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | change-rules | all-replaced | none | bound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | change-rules | all-replaced | none | unbound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | change-rules | audit+issuer+adapter+provider | keys | bound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | change-rules | audit+issuer+adapter+provider | keys | unbound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | change-rules | audit+issuer+adapter+provider | none | bound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | change-rules | audit+issuer+adapter+provider | none | unbound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | change-rules | audit+issuer+adapter | keys | bound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | change-rules | audit+issuer+adapter | keys | unbound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | change-rules | audit+issuer+adapter | none | bound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | change-rules | audit+issuer+adapter | none | unbound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | change-rules | audit+issuer | keys | unbound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | change-rules | audit+issuer | none | unbound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | change-rules | audit | keys | unbound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | change-rules | audit | none | unbound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | relabel-approved | all-replaced | none | bound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | relabel-approved | all-replaced | none | unbound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | relabel-approved | audit+issuer+adapter+provider | keys | bound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | relabel-approved | audit+issuer+adapter+provider | keys | unbound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | relabel-approved | audit+issuer+adapter+provider | none | bound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | relabel-approved | audit+issuer+adapter+provider | none | unbound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | relabel-approved | audit+issuer+adapter | keys | bound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | relabel-approved | audit+issuer+adapter | keys | unbound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | relabel-approved | audit+issuer+adapter | none | bound | detected | undetected | 10 |
| no-snapshot-bound-only | mode_checked | relabel-approved | audit+issuer+adapter | none | unbound | detected | undetected | 10 |
