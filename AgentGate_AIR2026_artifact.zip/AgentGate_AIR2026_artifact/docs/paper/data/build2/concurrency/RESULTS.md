# Concurrency on build 2 (R6.4, rerun for review round 3)

This folder holds the concurrency experiment rerun on **frozen build 2**
(commit `86643d7`, 2026-10-10 02:30:15-02:44:55 UTC). The method is build 1's
(`docs/paper/data/revision/concurrency/RESULTS.md`, 2026-10-08), unchanged:
- the same seven runs and sizes;
- the same harness (`cmd/agentgate-eval/concurrency.go` is byte-identical);
- the same analysis script (`analysis/analyze.py` is byte-identical);
- the same unit tests, plus three for build 2's change on this path.

Only the binaries changed. One script is new: `analysis/verifier_fields.py`.
It reads the fields the build-2 verifier added.

**Headline.** Every invariant held in all **1,820 scenario-repetitions**
(260 repetitions x 7 scenarios, 33,040 calls, 10,740 operations):
- at most one provider effect per operation ID;
- no COMMITTED answer without an effect;
- no budget or count overshoot.

**Evidence.** All 260 evidence folders verify with 0 failing checks (0 false
alarms):
- with keys and head pinned: 260/260 VERIFIED/ANCHORED;
- with the standalone verifier and no anchors: 260/260 VERIFIED/CONSISTENT.

**Lease.** With the 30 s development dispatch lease there were 0 lease expiries
in 3,640 dispatches. The closest any dispatch came to its deadline was
28.46 s away.

**Replay scope.** All 15,220 repeated answers are logged with scope `call`.

**Race detector.** 0 reports in 60 instrumented repetitions.

**What differs from build 1.** The safety, completion and journal results are
identical to build 1's, number for number. The audit and journal records have
the same shape. Three things differ:
- **The verifier reports more gaps.** Each folder now lists:
  - a `freshness` gap when the head is pinned;
  - an `issuer_only` gap for the one operation per folder that the
    lost-response scenario completes by reconciliation.

  These gaps come from the verifier, not from the gateway (§4):
  - the standalone build-2 verifier reports the same `issuer_only` gap, with
    an otherwise identical report, on build 1's 260 folders;
  - the `freshness` gap is listed by design for every pinned head, whichever
    gateway wrote the folder.
- **Which tool won cross-tool-reuse.** The scheduler picks it.
- **Timing.** The machine was loaded.

This is one local run on one machine, not a proof.

## 1. Method

The method is unchanged from build 1. In each repetition N goroutines wait on
one barrier, and each sends one JSON-RPC `tools/call` to the in-process MCP
handler. Each repetition gets:
- a fresh provider host (in process, own key, loopback HTTP);
- a fresh gateway with its own operation journal;
- a signed grant (budget USD 3,000.00, `document.release` MaxCount 3);
- an evidence folder.

Escalation mode is `flag`, the harness default. None of the requests fires a
flag rule: 0 of 33,040 CALL_RESULT entries carry `flagged=true`. Effects are
counted from the provider's signed journal. Every run used
`-host-label review-host`.

**Commands** (`analysis/run_all.sh`, sequential; `<work>` is
`<scratch>/build2-work/concurrency/work/<run>`):

```
<singlebuild2>/bin/agentgate-eval.exe -host-label review-host concurrency \
    -out docs/paper/data/build2/concurrency/<run> -work <work> -repeat <R> -n <N>
GOMAXPROCS=1 <singlebuild2>/bin/agentgate-eval.exe ...          (gomaxprocs1-*)
<scratch>/build2-work/concurrency/agentgate-eval-race.exe ...    (race-*)
```

| run (folder) | N | repetitions | note | UTC | median machine CPU |
|---|---|---|---|---|---|
| `n8` | 8 | 50 | | 02:30:15-02:30:56 | 92.5 % |
| `n32` | 32 | 50 | | 02:30:56-02:37:16 | 100 % |
| `replicate-n8` | 8 | 50 | | 02:37:17-02:38:46 | 100 % |
| `gomaxprocs1-n8` | 8 | 20 | GOMAXPROCS=1 | 02:38:46-02:39:30 | 100 % |
| `race-n8` | 8 | 30 | `-race` build | 02:39:30-02:41:31 | 100 % |
| `race-n32` | 32 | 30 | `-race` build | 02:41:31-02:44:05 | 81.5 % |
| `gomaxprocs1-n32` | 32 | 30 | GOMAXPROCS=1 | 02:44:06-02:44:55 | 47.5 % |

**Totals (the units counted)**

| unit | count |
|---|---|
| repetitions | 260 (150 at N=8, 110 at N=32) |
| scenario-repetitions | 1,820 |
| calls | 33,040 |
| logical operations (operation IDs) | 10,740 |
| capability consumptions, dispatch intents and provider effects | 3,640 each |
| evidence folders | 260 |
| verifications | 780: 260 in the harness (pinned) + 260 by `analyze.py` + 260 by `verifier_fields.py` (both standalone, no anchors) |
| extra verifications of build 1's folders by the build-2 verifier | 260 |

Seven runs exited 0. None logged `VIOLATED`. No repetition had an error.

### Build (`build-manifest.txt`)

**Binaries.**
- The five runs without `-race` used the frozen `agentgate-eval.exe`
  (`485e4ce0...fdca`).
- The analysis used the frozen `agentgate-verify.exe` (`83d0786a...ed0`).

Both come from `<singlebuild2>/bin`. Its manifest (`MANIFEST.txt`, SHA-256
`841a7c6f...b658`) has 1,868 entries:
- the 6 binaries;
- 256 module files;
- 385 third-party files;
- 1,221 standard-library files.

`check_manifest.py` re-hashed all of them four times, with 0 differences each
time (UTC):
- before any build or run (02:29:01);
- after the race build (02:29:41);
- after the last harness run (02:45:15);
- after the unit tests (02:51:19).

The working tree was at `86643d7`. Its only differences from the commit were
a deleted PDF and untracked files, none of them compiled.

**Race build.** `race-n8` and `race-n32` used `agentgate-eval-race.exe`,
SHA-256 `d3c919d302fc890cec87e3396f134719e35fb531522cf8db5bbdd57f8ce08192`.
- It was built at 02:29:20-02:29:33 UTC from the frozen source:
  `go build -race -o <scratch>/build2-work/concurrency/agentgate-eval-race.exe ./cmd/agentgate-eval/`.
- Toolchain: Go 1.26.6, offline flags, CGO through msys64 ucrt64 gcc 15.2.0.
- Its `go version -m` differs from the frozen `agentgate-eval.exe` only in
  the extra line `build -race=true`. Both binaries have:
  - the same module version (`v0.0.0-20261010022356-86643d751720+dirty`);
  - `vcs.revision=86643d7`;
  - the same dependencies and settings.

**What changed since build 1 on this code path.** The manifest diff lists 13
changed and 12 added module files.
- `internal/devcomposition/{auditing,dispatch,durable}.go`:
  - every COMMITTED answer, replayed and stored ones included, states the
    flag of the decision its effect rests on;
  - the dispatch intent journals the flag.
- `cmd/agentgate-eval/harness.go`: the harness stores the derived dimensions
  and `missing_by_kind`.
- The verifier: `internal/auditverify/{assurance,operations,reconcile,verify}.go`,
  the new `freshness.go`, and `cmd/agentgate-verify/main.go`.

### Analysis

**Same scripts as build 1.**
- `analyze.py`:
  - decodes the provider receipts with its own CBOR decoder;
  - checks every operation's journal transitions;
  - counts safety apart from completion;
  - measures the lease;
  - runs the standalone verifier without anchors on every folder;
  - scans every evidence file for the machine name.
- `aggregate.py` collects its totals.
- `replay_scope.py` counts the CALL_RESULT entries by scope. It ran on this
  run and on build 1's folders.
- `join_cpu.py` joins the CPU samples (`sampler.ps1`) to the runs.

**New script: `verifier_fields.py`.** It records what build 1's script does
not read:
- `head_fresh` and `run_complete`;
- the Missing entries by kind;
- the check-status counts;
- `counts.classification_evidence`;
- `counts.flagged` and `counts.flagged_unconfirmed`;
- CALL_RESULT entries with `flagged=true`.

It reads them for this run's 260 folders and for build 1's 260 folders.

## 2. Results (260 repetitions per scenario)

| scenario | the N calls | provider effects | answers |
|---|---|---|---|
| exact-payment | N identical payments, one ID | exactly 1 in 260/260 | 4,720/4,720 COMMITTED, one provider reference |
| exact-message | N identical internal messages, one ID | exactly 1 in 260/260 | 4,720/4,720 COMMITTED |
| conflicting-reuse | one ID, N different amounts | exactly 1 in 260/260 | 260 COMMITTED + 4,460 REJECTED/operation_id_conflict |
| cross-tool-reuse | one ID, N/2 payments + N/2 messages | exactly 1 in 260/260 | 2,360 COMMITTED + 2,360 REJECTED/operation_id_conflict; payment won 77, message won 183 |
| lost-response | N identical payments, response loss armed once | exactly 1 in 260/260 | 260 UNCERTAIN/provider_response_lost + 4,460 COMMITTED/reconciled; 0 REJECTED |
| budget-race | N fresh-ID USD 500.00 payments, budget USD 3,000.00 | exactly 6 (USD 3,000.00) in 260/260 | 1,560 COMMITTED + 3,160 REJECTED/policy_denied |
| count-race | N fresh-ID public releases, MaxCount 3 | exactly 3 in 260/260 | 780 COMMITTED + 3,940 REJECTED/policy_denied |

Within each run every repetition had the same answer pattern (one pattern
per scenario per N).

**Invariants (out of 1,820 scenario-repetitions unless stated)**

| invariant | result |
|---|---|
| harness invariant (`assessRace`) | 1,820 / 1,820 |
| safety, counted separately from completion (the five conditions are listed below the table) | 1,820 / 1,820 |
| completion: the expected number of effects, and every caller of the winning request COMMITTED | 1,820 / 1,820 |
| consistency: identical requests got identical answers, and the CALL_RESULT answers in the audit log equal what the callers received | 1,820 / 1,820 |
| journal transitions in an allowed order | 10,740 / 10,740 operations; journal sequence numbers have no gaps in 260/260 repetitions |
| independent effect count equals the harness's | 1,820 / 1,820. 3,640 receipts, all APPLIED, 14 per repetition; dispatch intents equal effects everywhere |
| each operation with a receipt has exactly one EFFECT_EXECUTED (3,380) or one RECONCILED (260) | 3,640 / 3,640; the 7,100 operations without a receipt have neither |
| delegation after each repetition: reservations back to 0, USD committed exactly 300,000 minor units, releases exactly 3 | 260 / 260 |
| race detector reports | 0 in 60 instrumented repetitions (420 scenario-repetitions) |
| answers `UNCERTAIN/dispatch_lease_expired` | 0 |

The safety row requires all of these:
- at most 1 effect per operation ID;
- 0 of 33,040 answers COMMITTED without an effect;
- 0 REJECTED answers to a request identical to the one that produced the
  effect;
- 0 REJECTED answers in lost-response;
- no budget or count overshoot.

How the 10,740 operations ended:
- **7,100 REJECTED:** `received > recorded REJECTED`.
- **3,380 COMMITTED:** `received > capability_issued > capability_consumed >
  dispatch_intent > provider_outcome > recorded COMMITTED`.
- **260 UNCERTAIN, then COMMITTED:** `... recorded UNCERTAIN > reconcile_query
  > reconciled > recorded COMMITTED`.

No operation had a dispatch intent and ended REJECTED.

**Dispatch lease** (3,640 dispatches, 30 s development lease)

| run | consume to dispatch intent, median | p99 | max | minimum slack to the deadline |
|---|---|---|---|---|
| n8 / replicate-n8 / n32 | 3.0 / 5.0 / 5.4 ms | 11.9 / 18.2 / 158.4 ms | 22.7 / 28.7 / 864.0 ms | 28,981.4 / 28,985.7 / 28,460.1 ms |
| race-n8 / race-n32 | 14.0 / 10.0 ms | 91.6 / 136.0 ms | 211.0 / 286.9 ms | 28,866.9 / 28,939.1 ms |
| gomaxprocs1-n8 / gomaxprocs1-n32 | 8.0 / 22.6 ms | 31.0 / 317.8 ms | 39.9 / 355.9 ms | 28,981.7 / 28,659.1 ms |

- The deadline is taken as min(floor(capability issued) + 30 s, capability
  expiry). This is a lower bound.
- The minimum slack was 28,460.1 ms, in `n32`. No dispatch came within 28 s
  of its deadline: `below_28s` is 0 in every run.
- There were 0 lease expiries.
- No capability was consumed without a dispatch intent.
- The 864.0 ms maximum came from `n32`. During that run:
  - the machine ran at 100 % median CPU;
  - up to 5 `agentgate-eval` processes ran at once, this run's included;
  - up to 10 other agentgate processes ran at once.

**Evidence, with keys and head pinned** (the harness, in process; the
build-2 verifier code linked into `agentgate-eval`)
- 260/260 VERIFIED/ANCHORED with 0 failing checks.
- The seven check-based dimensions pass in 260/260.
- The two new derived dimensions, `head_fresh` and `run_complete`, are
  `not_checked` in 260/260. This is the specified result for a pinned head:
  only a fetched signed witness run status can make them pass
  (`VERIFIER_CHECKS.md` §1). The harness starts no witness.
- `missing` has exactly 2 entries in 260/260 (`missing_by_kind`: freshness
  1, issuer_only 1, unresolved 0, other 0):
  - **freshness:** "Head not shown to be fresh". A pinned head shows where
    the log ended when it was saved, not that it is the run's latest head.
  - **issuer_only:** one operation "was executed only according to a
    RECONCILED entry without an adapter receipt". This is the lost-response
    operation:
    - the provider applied the payment, but its response was lost before
      the adapter could sign a receipt;
    - the gateway completed the operation from the provider's signed status;
    - so the decision behind the operation is bound by the capability
      issuer's signature alone (`issuer_only_reconciled`).

**Evidence, standalone verifier without anchors** (frozen
`agentgate-verify --json --workers 1`)
- 260/260 VERIFIED/CONSISTENT with exit 0.
- 34 checks per folder: 32 pass, and 2 warn (`head.anchor` and `keys.anchor`).
- Of the nine dimensions, 5 pass in 260/260. The other 4 are `not_checked`:
  - `anchored_keys` and `anchored_head`, because no anchors were given;
  - `head_fresh` and `run_complete`, which need a fetched witness status.
- `missing` has 3 entries in 260/260, with `missing_kinds` other, other,
  issuer_only:
  - the two missing anchors;
  - the same lost-response operation.

  There is no freshness entry, because no head anchor was given.
- Classification evidence of the 10,740 operations:
  - 3,380 `issuer_adapter`, the operations executed with EFFECT_EXECUTED;
  - 260 `issuer_only_reconciled`, one per folder, all of them the
    lost-response operations (`counts.reconciled` = 1 per folder);
  - 7,100 `audit_only`, the denied and refused operations.
- `counts.flagged` is 0 in 260/260. `counts.flagged_unconfirmed` is absent
  in 260/260, which means 0: the JSON field is omitted when it is 0.

**Other evidence results**
- **False alarms:** 0. The build-2 verifier was also run on build 1's 260
  folders. Its report was the same in every field `verifier_fields.py`
  reads: 260/260 VERIFIED/CONSISTENT, exit 0, 32 pass and 2 warn, the same
  3 Missing entries and the same classification counts.
- **Machine name:** it appears 0 times in all files of all 260 folders,
  journals included. "review-host" appears in every folder.
- **Windows user name:** a separate check, not in build 1's script, found
  the string 11 times in the raw folders (6 files). Every time it was by
  chance, inside a 64-character hex SHA-256 digest. Build 1's folders have
  14 such chance hits: 12 in digests and 2 in 32-character hex call IDs.
  No file in this repository folder contains the machine name, the user
  name or a local path.
- **Folder shape:** the same as build 1. At N=8 there are 160 audit entries
  and 21 operations; at N=32, 484 and 69.
- **Record shape:** the audit entries (77,240) and the journal records
  (36,820) have the same set of (stage, detail keys) and (kind, data keys)
  as build 1's. The flag fields added in build 2 are omitted when false, and
  no operation here is flagged.

**Unit tests** (`analysis/unit-tests.txt`) were rerun on the frozen source
after the last run (02:47:42-02:50:46 UTC). All were ok.
- Same commands as build 1, under `-race -count=20`:
  - `TestConcurrentConsumeBarrierCommitsExactlyOnce`
  - `TestIssueExactConcurrentBarrierAndOperationConflict`
  - `TestMemoryOperationStoreConcurrentBeginAndEffectConflict`
  - `TestDelegationReservationsAreConsistentUnderConcurrency`
  - `TestConcurrentRetriesYieldOneEffect`
  - `TestConcurrentDuplicatesCommitExactlyOnce`
  - `TestConcurrentAppendsAreNumberedWithoutGaps`
  - `TestConcurrentAppendsKeepValidChain`
  - `TestReplayedAnswersAreCallScoped`
- `TestDelegationAccountingDoesNotDependOnLogOrder` ran with count=5 and no
  race build, as in build 1.
- Added for build 2's change on this path:
  - `TestReplayedCommittedAnswersKeepTheFlag` and
    `TestNotCommittedAnswersStateNoFlag`, under `-race -count=20`;
  - `TestCallScopeReplayedAnswers` (verifier), with count=5.
- A `-v` pass confirmed that all 13 tests exist and ran.

## 3. Replay scope

`analysis/replay_scope.tsv` counts the 33,040 CALL_RESULT entries of each
build. The counts are identical:

| answer (audit summary) | status / reason | build 1: scope | build 2: scope |
|---|---|---|---|
| Call completed (the winning call) | COMMITTED | 3,380 `operation` | 3,380 `operation` |
| Reconciled with the provider | COMMITTED/reconciled | 260 `operation` | 260 `operation` |
| The provider's answer was lost | UNCERTAIN/provider_response_lost | 260 `operation` | 260 `operation` |
| Call denied by policy | REJECTED/policy_denied | 7,100 `operation` | 7,100 `operation` |
| Call refused during the operation check | REJECTED/operation_id_conflict | 6,820 `call` | 6,820 `call` |
| Repeated call (`replayed=true`) | COMMITTED | 11,020 `call` | 11,020 `call` |
| Repeated call (`replayed=true`) | COMMITTED/reconciled | 4,200 `call` | 4,200 `call` |

There are 0 repeats of a completed operation outside scope `call`
(`replay_scope.py` exits 0). Build 2's replay change makes a replayed
COMMITTED answer state the flag of its decision. Nothing is flagged here, so
it adds no field to any of these entries.

## 4. Comparison with build 1

| headline number | build 1 (2026-10-08) | build 2 (this run) | why it differs |
|---|---|---|---|
| repetitions / scenario-repetitions / calls / operations | 260 / 1,820 / 33,040 / 10,740 | 260 / 1,820 / 33,040 / 10,740 | same method |
| harness invariant, safety, completion, consistency | 1,820 / 1,820 each | 1,820 / 1,820 each | - |
| journal transitions; gapless sequences | 10,740 / 10,740; 260 / 260 | 10,740 / 10,740; 260 / 260 | - |
| effects (independent = harness = dispatch intents) | 3,640 | 3,640 | - |
| EFFECT_EXECUTED / RECONCILED per receipt | 3,380 / 260 | 3,380 / 260 | - |
| delegation exact after each repetition | 260 / 260 | 260 / 260 | - |
| race detector reports | 0 in 60 repetitions | 0 in 60 repetitions | different race binary (`14e36017...` vs `d3c919d3...`), because the source differs |
| lease expiries | 0 / 3,640 | 0 / 3,640 | - |
| minimum slack to the lease deadline | 28,801.0 ms (gomaxprocs1-n32) | 28,460.1 ms (n32) | load and scheduling: one `n32` dispatch took 864 ms from consumption to intent while the machine ran at 100 % with up to 5 eval processes. Still more than 28 s from the deadline. |
| maximum consume-to-intent | 649.0 ms (n32) | 864.0 ms (n32) | the same load effect; not a performance result |
| cross-tool winner (payment / message) | 72 / 188 | 77 / 183 | the scheduler picks it. With GOMAXPROCS=1 the message won 19/20 and 30/30, the same as build 1 |
| harness (pinned) verdict | 260 / 260 VERIFIED/ANCHORED, 7 dimensions pass | 260 / 260 VERIFIED/ANCHORED, 7 check-based dimensions pass | - |
| harness `head_fresh` / `run_complete` | (did not exist) | `not_checked` 260 / 260 | new derived dimensions. A pinned head cannot show freshness. They never change the verdict. |
| harness `missing` | empty in 260 / 260 | 2 entries in 260 / 260 (freshness 1, issuer_only 1) | the new verifier lists the freshness gap of every pinned head, and the issuer-only classification of the lost-response operation (§2). The gateway's records are unchanged; no check fails. |
| CLI (no anchors) verdict and checks | 260 / 260 CONSISTENT, exit 0; 34 checks: 32 pass, 2 warn | 260 / 260 CONSISTENT, exit 0; 34 checks: 32 pass, 2 warn | - |
| CLI `missing` | 2 (the two anchors) | 3 (two anchors, kind `other`; one `issuer_only`) | the same verifier change. The build-2 verifier gives 3 on build 1's folders too. |
| classification evidence (10,740 operations) | (not reported) | 3,380 `issuer_adapter`, 260 `issuer_only_reconciled`, 7,100 `audit_only` | new per-operation field. Identical on build 1's folders. |
| flagged operations; flagged but unconfirmed | 0 | 0; 0 | the concurrency requests fire no flag rule, so the flag changes of build 2 are not exercised here (unit tests only, §2) |
| repeated answers with scope `call` | 15,220 / 15,220 | 15,220 / 15,220 | - |
| folder shape; audit and journal record shape | 160/21 and 484/69 | the same; identical key shapes | - |
| machine name in the evidence | 0 | 0 | - |
| unit tests | 10, all ok | the same 10 ok, plus 3 replay-flag tests ok | build 2 added tests for its change on this path |
| median machine CPU per run | 69.5-100 % | 47.5-100 % | other runners; not a result |
| slowest call | 4.3 s (n32, budget-race) | 7.1 s (n32 repetition 19, count-race) | load. That call was REJECTED/policy_denied (DEL-COUNT) and never reached a capability. All 32 calls of that repetition took 3.5-7.1 s, so the whole repetition was slowed. Consume-to-intent stayed at most 864 ms. |
| wall time of the seven runs | 14 min 10 s | 14 min 40 s | load; not a result |

## 5. Caveats

- **Loaded, shared machine.** Other experiment runners were working at the
  same time, so no elapsed time here is a performance result.
  - Median CPU per run was 47.5-100 %. It was 100 % during `n32`,
    `replicate-n8`, `gomaxprocs1-n8` and `race-n8`.
  - Up to 5 `agentgate-eval` processes (this run's included), 10 other
    agentgate processes and 6 Go toolchain processes ran at once.
  - The details are in `analysis/runs.tsv` and `analysis/cpu-samples.tsv`.
- **Scope.** One process, one tenant and one principal, a loopback provider on
  one machine. Invariants that held here are not a proof for all
  interleavings.
- **Same-ID calls do not truly race.** The per-operation lock
  (`lockOperation`) serializes them, and PRE reservations run under the global
  `ledgerOrder` lock. "At most one effect" under simultaneous retries comes
  from that mutual exclusion.
- **No flagged operation.** The harness runs in flag mode, but no request
  fires a flag rule. Build 2's flag changes on this path are therefore covered
  only by the unit tests here:
  - the flag on replayed and stored COMMITTED answers;
  - the flag in the dispatch intent and recovery records;
  - the verifier's flag check on replays.

  The concurrency evidence shows that these changes left the unflagged
  records unchanged.
- **`issuer_only` is a reported gap, not a failure.** The lost-response
  operation is classified `issuer_only_reconciled` in every folder. Nothing
  was sent or recorded differently than in build 1: the build-2 verifier
  reports the same on build 1's folders. It now says explicitly that, for
  this one operation, no adapter receipt binds the decision.
- **Freshness.** ANCHORED with a pinned head is not "complete latest run".
  `run_complete` stays `not_checked` without a fetched witness status.
- **Race build.** It is not one of the six frozen binaries. It was built from
  the verified frozen source (§1) and has its own hash.
- **Untested:** reuse of an ID across principals; races during a restart; two
  calls presenting one capability to the dispatch path (unit tests only);
  flagged operations under concurrency.

## 6. Open issues (eval-engine, unchanged since build 1)

The file `cmd/agentgate-eval/concurrency.go` has not changed.
- **`assessRace` counts an expired lease as a violation.** The answer
  `UNCERTAIN/dispatch_lease_expired` is fail-closed, but `assessRace` would
  still count it as a violation.
  - None happened here: 0 answers and 0 operations recorded with that reason.
  - `analyze.py` reports such a case in its own fields:
    `lease_expired_answers` (0),
    `harness_violation_explained_by_lease_expiry_only` (0) and
    `harness_violation_with_safety_breach` (0).
  - Forcing an expiry needs a fault hook. Even 100 % CPU load left more than
    28.4 s of the lease.
- **`assessRace` mixes safety and completion.** The analysis script separates
  them.
- **Call start times are not recorded.** `assessRace` does not record when each
  call started relative to the barrier.

## 7. Files

- `<run>/concurrency.{json,csv,md}`: the harness output of the seven runs.
- `build-manifest.txt`:
  - the frozen binary hashes and the manifest hash;
  - git HEAD and status;
  - the race build's hash and its `go version -m` difference;
  - the four manifest checks with timestamps;
  - the files changed since build 1;
  - the module source hashes.
- `analysis/`:
  - `analyze.py` (byte-identical to build 1's), `summary.json`,
    `scenario_repetitions.csv` (1,820 rows), `journal_operations.csv`
    (10,740 rows), `evidence.csv` (260 rows);
  - `aggregate.py`, which prints the totals quoted above;
  - `replay_scope.py` (byte-identical to build 1's) and `replay_scope.tsv`
    (build 2 and build 1);
  - `verifier_fields.py` (new), `verifier_fields.csv` (520 rows: this run's
    260 folders and build 1's 260) and `verifier_fields.json` (totals per
    build);
  - `run_all.sh`, `sampler.ps1`, `join_cpu.py`, `runs.tsv` (times, exit
    codes, race reports, CPU) and `cpu-samples.tsv`;
  - `unit_tests.sh` and `unit-tests.txt`;
  - `write_manifest.py`;
  - `logs/`: the harness console output of each run.

The evidence folders (about 172 MB) stay outside the repository, in
`<scratch>/build2-work/concurrency/work/`, together with:
- the race binary;
- the raw manifest-check outputs and the raw unit-test output;
- the raw outputs of `aggregate.py`, `replay_scope.py` and
  `verifier_fields.py`.

Build 1's folders are in `<scratch>/final4-concurrency/work/`.

Total time for this experiment, from the first manifest check to the end of
the analysis, unit tests and write-up: 02:29:00-02:57 UTC (about 28 min).
The seven harness runs took 14 min 40 s.
