import collections
import csv
import json
import sys

summary = json.load(open(sys.argv[1], encoding='utf-8'))
tot = collections.Counter()
answers = collections.defaultdict(collections.Counter)
winners = collections.Counter()
evid = collections.Counter()
dims = collections.Counter()
host = collections.Counter()
deleg = collections.Counter()
indep = collections.Counter()
patterns = collections.defaultdict(lambda: collections.defaultdict(set))
journal = collections.Counter()
lease = []
problems = []
per_variant = []
for v in summary['variants']:
    name = v['variant']
    j = v['journal']
    per_variant.append((name, v['simultaneous_calls'], v['repetitions'], j['consume_to_intent_ms'], j['slack_to_lease_deadline_ms'],
                        len(j['lease_expired_dispatches']), len(j['consumed_without_dispatch_intent']), j['dispatches'],
                        v['cross_tool_winner'], v['repetitions_with_error']))
    journal['dispatches'] += j['dispatches']
    journal['seq_gapless'] += j['repetitions_seq_gapless']
    journal['all_ops_ok'] += j['repetitions_all_operations_ok']
    journal['lease_expired'] += len(j['lease_expired_dispatches'])
    journal['lease_recorded'] += len(j['operations_recorded_uncertain_dispatch_lease_expired'])
    journal['lease_only_harness'] += len(j['harness_violations_explained_by_lease_expiry_only'])
    journal['consumed_without_intent'] += len(j['consumed_without_dispatch_intent'])
    problems += j['problem_examples']
    for sname, a in v['scenarios'].items():
        for k, x in a.items():
            if k.startswith('answer '):
                answers[sname][k[7:]] += x
            else:
                tot[k] += x
                tot[(sname, k)] += x
        for p, c in v['answer_patterns'][sname].items():
            patterns[sname][v['simultaneous_calls']].add(p)
    for k, x in v['cross_tool_winner'].items():
        winners[k] += x
    for k, x in v['evidence'].items():
        evid[k] += x
    for k, x in v['harness_dimensions'].items():
        dims[k] += x
    for k, x in v['host_label_scan'].items():
        host[k] += x
    for k, x in v['delegation_status_after_repetition'].items():
        deleg[k] += x
    for k, x in v['independent_provider_counts'].items():
        indep[k] += x
keys = ['repetitions', 'harness_invariant_held', 'safety_held', 'completed', 'consistent', 'identical_requests_identical_answers',
        'audit_call_results_match_answers', 'journal_transitions_ok', 'calls', 'operations', 'effects_independent', 'effects_harness',
        'effects_expected', 'dispatch_intents', 'committed_without_effect', 'rejected_identical_to_effect_request', 'max_effects_per_id_gt1',
        'harness_independent_effect_mismatch', 'lease_expired_answers', 'harness_violation_explained_by_lease_expiry_only',
        'harness_violation_with_safety_breach']
print('TOTALS')
for k in keys:
    print('  %-50s %s' % (k, tot[k]))
print('PER SCENARIO')
for s in ['exact-payment', 'exact-message', 'conflicting-reuse', 'cross-tool-reuse', 'lost-response', 'budget-race', 'count-race']:
    print(' ', s, 'reps', tot[(s, 'repetitions')], 'held', tot[(s, 'harness_invariant_held')], 'safety', tot[(s, 'safety_held')],
          'completed', tot[(s, 'completed')], 'effects', tot[(s, 'effects_independent')], 'calls', tot[(s, 'calls')], 'ops', tot[(s, 'operations')],
          dict(answers[s]), {n: sorted(p) for n, p in patterns[s].items()})
print('WINNERS', dict(winners))
print('JOURNAL', dict(journal), problems[:5])
print('EVIDENCE', dict(evid))
print('DIMS', dict(dims))
print('HOST', dict(host))
print('DELEG', dict(deleg))
print('INDEP', dict(indep))
for row in per_variant:
    print('VARIANT', row)
# journal paths
paths = collections.Counter()
for r in csv.DictReader(open(sys.argv[2], encoding='utf-8')):
    final = r['recorded_statuses'].split(' > ')[-1]
    paths[(r['journal_kinds'], r['recorded_statuses'])] += 1
for k, c in paths.most_common():
    print('PATH', c, k)
# EFFECT_EXECUTED / RECONCILED per op with receipt
cnt = collections.Counter()
for r in csv.DictReader(open(sys.argv[2], encoding='utf-8')):
    if int(r['provider_receipts']) > 0:
        cnt['with_receipt'] += 1
        ee, rc = int(r['audit_effect_executed']), int(r['audit_reconciled'])
        cnt['ee=%d rc=%d' % (ee, rc)] += 1
    else:
        cnt['no_receipt ee=%s rc=%s' % (r['audit_effect_executed'], r['audit_reconciled'])] += 1
print('AUDIT', dict(cnt))
