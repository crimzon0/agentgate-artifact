"""Secondary analysis of the concurrency run on the final build (R6.4).

Adapted from the 2026-10-08 re-run script (previous-build/rerun-2026-10-08/
analysis/analyze_rerun.py). Changes: the development dispatch lease is now
30 s (capability.DevelopmentDispatchLeaseSeconds), so the lease deadline is
taken as min(floor(t_capability_issued) + 30 s, capability expires_at), a
lower bound of the real deadline (the adapter PoP, created between issue
and consumption, and the lease are both counted from a whole-second clock
read at or after issue). A lease that expired is answered
UNCERTAIN/dispatch_lease_expired (fail-closed: no request byte left); it is
classified separately from safety violations, although the harness's
assessRace counts it as a violation.

Independent of the harness's own counting (cmd/agentgate-eval concurrency.go
assessRace), it reads each variant's concurrency.json and the evidence folders
the harness left in its work directory and reports, per scenario and
repetition:

  safety      at most one provider receipt per operation ID; no COMMITTED
              answer for an operation without a receipt; no REJECTED answer to
              a caller whose request is identical to the request that produced
              the operation's effect; no REJECTED answer in lost-response;
              budget-race committed USD <= USD 3,000.00; count-race releases
              <= 3.
  completed   the expected number of effects (1,1,1,1,1,6,3) and every caller
              of the winning request COMMITTED (lost-response: COMMITTED or
              the one UNCERTAIN of the call that lost its response).
  consistent  identical requests got identical answers (lost-response: up to
              its one UNCERTAIN), and the audit log's CALL_RESULT answers equal
              the answers the callers received.
  journal_ok  every operation's journal transitions are in an allowed order
              (received first and once; capability issued < consumed <
              dispatch intent < provider outcome, each at most once;
              reconcile_query < reconciled; a COMMITTED or REJECTED record is
              never followed by a different status; UNCERTAIN only moves to
              COMMITTED after a reconciled record; the final record is
              COMMITTED iff the provider journal holds a receipt; no
              dispatch intent for a REJECTED operation), journal seq has no
              gaps.

Provider receipts are decoded with a minimal CBOR decoder (signatures NOT
checked here; the verifier checks them). It also runs the standalone verifier
CLI without anchors on every folder (expected VERIFIED / CONSISTENT), measures
consume-to-dispatch-intent intervals against the development dispatch lease
(whole-second clock, 30 s lease; deadline lower bound as above), and counts
occurrences of the machine name and of the host label in every evidence file.

Usage:
  python analyze_rerun.py ANALYSIS_DIR VERIFY_EXE MACHINE_NAME HOST_LABEL NAME=OUT_DIR::WORK_DIR [...]
Writes ANALYSIS_DIR/{summary.json, scenario_repetitions.csv, evidence.csv,
journal_operations.csv}.
"""
import base64
import collections
import csv
import datetime
import json
import os
import statistics
import struct
import subprocess
import sys

SCENARIOS = ['exact-payment', 'exact-message', 'conflicting-reuse', 'cross-tool-reuse', 'lost-response', 'budget-race', 'count-race']
EXPECTED_EFFECTS = {'exact-payment': 1, 'exact-message': 1, 'conflicting-reuse': 1, 'cross-tool-reuse': 1, 'lost-response': 1, 'budget-race': 6, 'count-race': 3}
BUDGET_USD_MINOR, AMOUNT_USD_MINOR, RELEASE_LIMIT = 300_000, 50_000, 3
LEASE_SECONDS = 30
LEASE_EXPIRED = 'UNCERTAIN/dispatch_lease_expired'


# --- minimal CBOR decoder (RFC 8949 subset) ---
def cbor_decode(data, i=0):
    ib = data[i]
    major, info = ib >> 5, ib & 0x1F
    i += 1
    if info < 24:
        arg = info
    elif info == 24:
        arg = data[i]; i += 1
    elif info == 25:
        arg = struct.unpack('>H', data[i:i + 2])[0]; i += 2
    elif info == 26:
        arg = struct.unpack('>I', data[i:i + 4])[0]; i += 4
    elif info == 27:
        arg = struct.unpack('>Q', data[i:i + 8])[0]; i += 8
    else:
        raise ValueError('indefinite length not supported')
    if major == 0:
        return arg, i
    if major == 1:
        return -1 - arg, i
    if major == 2:
        return bytes(data[i:i + arg]), i + arg
    if major == 3:
        return data[i:i + arg].decode('utf-8'), i + arg
    if major == 4:
        out = []
        for _ in range(arg):
            v, i = cbor_decode(data, i)
            out.append(v)
        return out, i
    if major == 5:
        out = {}
        for _ in range(arg):
            k, i = cbor_decode(data, i)
            v, i = cbor_decode(data, i)
            out[k] = v
        return out, i
    if major == 6:
        v, i = cbor_decode(data, i)
        return ('tag', arg, v), i
    if major == 7:
        return {20: False, 21: True, 22: None}.get(arg, ('simple', arg)), i
    raise ValueError(major)


def receipt_payload(b64):
    obj, _ = cbor_decode(base64.b64decode(b64))
    if isinstance(obj, tuple) and obj[0] == 'tag':
        obj = obj[2]
    payload, _ = cbor_decode(obj[2])
    return payload


def b64url(b):
    return base64.urlsafe_b64encode(b).decode().rstrip('=')


def ts(s):
    s = s.rstrip('Z')
    main, _, frac = s.partition('.')
    t = datetime.datetime.strptime(main, '%Y-%m-%dT%H:%M:%S').replace(tzinfo=datetime.timezone.utc).timestamp()
    return t + (float('0.' + frac) if frac else 0.0)


def pct(values, p):
    s = sorted(values)
    if not s:
        return None
    k = (len(s) - 1) * p / 100
    f = int(k)
    c = min(f + 1, len(s) - 1)
    return s[f] + (s[c] - s[f]) * (k - f)


def answer(call):
    r = call['result']
    return '%s/%s' % (r.get('status') or 'ERROR', r.get('reason', ''))


def content_key(call):
    return '%s|%s' % (call['tool'], call.get('amount_minor', 0))


def journal_check(records, has_receipt):
    """Returns (ok, problems, kinds, statuses, consume_to_intent_s, slack_s)."""
    problems = []
    kinds = [r['kind'] for r in records]
    if not kinds or kinds[0] != 'received' or kinds.count('received') != 1:
        problems.append('received not first/once')
    first = {}
    for index, kind in enumerate(kinds):
        first.setdefault(kind, index)
    for kind in ('capability_issued', 'capability_consumed', 'dispatch_intent', 'provider_outcome', 'reconciled'):
        if kinds.count(kind) > 1:
            problems.append('%s x%d' % (kind, kinds.count(kind)))
    chain = ['capability_issued', 'capability_consumed', 'dispatch_intent', 'provider_outcome']
    present = [k for k in chain if k in first]
    if present != chain[:len(present)]:
        problems.append('lifecycle step missing before %s' % present)
    for a, b in zip(present, present[1:]):
        if first[a] > first[b]:
            problems.append('%s after %s' % (a, b))
    if 'reconciled' in first and ('reconcile_query' not in first or first['reconcile_query'] > first['reconciled']):
        problems.append('reconciled without earlier reconcile_query')
    if 'reconcile_query' in first and ('dispatch_intent' not in first or first['dispatch_intent'] > first['reconcile_query']):
        problems.append('reconcile_query without earlier dispatch_intent')
    statuses = []
    reconciled_seen = False
    reconciled_absent = False
    lease_expired_recorded = False
    for r in records:
        if r['kind'] == 'reconciled':
            reconciled_seen = True
            reconciled_absent |= str((r.get('data') or {}).get('provider_status', '')).upper() == 'ABSENT'
        if r['kind'] != 'recorded':
            continue
        status = (r.get('data') or {}).get('status')
        if status == 'UNCERTAIN' and (r.get('data') or {}).get('reason') == 'dispatch_lease_expired':
            lease_expired_recorded = True
        if statuses and statuses[-1] in ('COMMITTED', 'REJECTED') and status != statuses[-1]:
            problems.append('%s after terminal %s' % (status, statuses[-1]))
        if statuses and statuses[-1] == 'UNCERTAIN' and status == 'COMMITTED' and not reconciled_seen:
            problems.append('UNCERTAIN->COMMITTED without reconciled')
        if statuses and statuses[-1] == 'UNCERTAIN' and status == 'REJECTED' and not reconciled_absent:
            problems.append('UNCERTAIN->REJECTED without a reconciled ABSENT')
        statuses.append(status)
    final = statuses[-1] if statuses else None
    if final is None:
        problems.append('no recorded status')
    if final == 'COMMITTED' and not has_receipt:
        problems.append('COMMITTED without provider receipt')
    if has_receipt and final != 'COMMITTED':
        problems.append('receipt but final %s' % final)
    if final == 'REJECTED' and 'dispatch_intent' in first and not reconciled_absent:
        problems.append('REJECTED after dispatch_intent')
    if lease_expired_recorded and 'provider_outcome' in first:
        problems.append('provider_outcome after an expired lease')
    interval = slack = None
    issued = [r for r in records if r['kind'] == 'capability_issued']
    consumed = [ts(r['time']) for r in records if r['kind'] == 'capability_consumed']
    intent = [ts(r['time']) for r in records if r['kind'] == 'dispatch_intent']
    if consumed and intent:
        interval = intent[0] - consumed[0]
        deadline = int(ts(issued[0]['time']) if issued else consumed[0]) + LEASE_SECONDS
        expires = (issued[0].get('data') or {}).get('expires_at') if issued else None
        if expires:
            deadline = min(deadline, expires)
        slack = deadline - intent[0]
    return (not problems), problems, kinds, statuses, interval, slack, lease_expired_recorded


def scan_host(folder, machine, label):
    machine_hits = label_hits = 0
    for root, _, files in os.walk(folder):
        for name in files:
            data = open(os.path.join(root, name), 'rb').read().decode('utf-8', 'replace').lower()
            machine_hits += data.count(machine.lower())
            label_hits += data.count(label.lower())
    return machine_hits, label_hits


def analyze_variant(name, out_dir, work_dir, verify_exe, machine, label, rows, evidence_rows, journal_rows):
    d = json.load(open(os.path.join(out_dir, 'concurrency.json'), encoding='utf-8'))
    n = d['simultaneous_calls']
    reps = d['repetitions']
    agg = collections.defaultdict(lambda: collections.Counter())
    patterns = collections.defaultdict(collections.Counter)
    elapsed = collections.defaultdict(list)
    winners = collections.Counter()
    deleg = collections.Counter()
    independent = collections.Counter()
    intervals, slacks, consumed_without_intent, lease_expired = [], [], [], []
    lease_expired_recorded_ops, lease_only_harness_failures = [], []
    journal_problem_examples = []
    totals = collections.Counter()
    evidence = collections.Counter()
    dims = collections.Counter()
    host = collections.Counter()
    for r in reps:
        rep = r['repeat']
        folder = os.path.join(work_dir, 'concurrency-r%02d' % rep)
        run_dir = os.path.join(folder, 'run')
        receipts = collections.Counter()
        outcomes = collections.Counter()
        pj = json.load(open(os.path.join(run_dir, 'provider-journal.json'), encoding='utf-8'))
        for e in pj['entries']:
            p = receipt_payload(e['signed_receipt'])
            receipts[b64url(p['operation_id'])] += 1
            outcomes[p.get('outcome')] += 1
        independent['provider_receipt_outcomes=%s' % dict(outcomes)] += 1
        independent['receipts_total=%d' % sum(receipts.values())] += 1
        journal = collections.defaultdict(list)
        seqs = []
        for line in open(os.path.join(folder, 'operations.jsonl'), encoding='utf-8'):
            j = json.loads(line)
            seqs.append(j['seq'])
            journal[j['operation'].rsplit('/', 1)[-1]].append(j)
        seq_ok = seqs == list(range(1, len(seqs) + 1))
        totals['journal_seq_gapless'] += seq_ok
        entries = [json.loads(line)['entry'] for line in open(os.path.join(run_dir, 'audit.jsonl'), encoding='utf-8')]
        call_results = collections.defaultdict(collections.Counter)
        stages = collections.defaultdict(collections.Counter)
        for e in entries:
            op = e.get('operation_id')
            stages[op][e['stage']] += 1
            if e['stage'] == 'CALL_RESULT':
                det = e.get('details') or {}
                call_results[op]['%s/%s' % (det.get('status'), det.get('reason', ''))] += 1
        ds = r.get('delegation_status') or {}
        committed = ds.get('committed', {})
        reserved = ds.get('reserved', {})
        deleg['usd_committed_minor=%s' % committed.get('amounts', {}).get('USD')] += 1
        deleg['document_release_count=%s' % committed.get('counts', {}).get('document.release')] += 1
        deleg['reserved_all_zero=%s' % (all(v == 0 for v in reserved.get('amounts', {}).values()) and all(v == 0 for v in reserved.get('counts', {}).values()))] += 1
        rep_journal_ok = True
        for s in r['scenarios']:
            sname = s['scenario']
            calls = s['calls']
            ids = sorted({c['operation_id'] for c in calls})
            eff = {i: receipts.get(i, 0) for i in ids}
            effects = sum(eff.values())
            intents = sum(1 for i in ids for rec in journal.get(i, []) if rec['kind'] == 'dispatch_intent')
            # winning content: the content of COMMITTED callers per operation
            win_content = collections.defaultdict(set)
            for c in calls:
                if c['result'].get('status') == 'COMMITTED':
                    win_content[c['operation_id']].add(content_key(c))
            s_max_per_id = max(eff.values()) <= 1
            s_committed_without = sum(1 for c in calls if c['result'].get('status') == 'COMMITTED' and eff[c['operation_id']] == 0)
            s_rejected_own = sum(1 for c in calls if c['result'].get('status') == 'REJECTED' and eff[c['operation_id']] > 0
                                 and content_key(c) in win_content[c['operation_id']])
            s_effect_unanswered = sum(1 for i in ids if eff[i] > 0 and not win_content[i]
                                      and not any(c['operation_id'] == i and c['result'].get('status') == 'UNCERTAIN' for c in calls))
            s_lost_rejected = sum(1 for c in calls if c['result'].get('status') == 'REJECTED') if sname == 'lost-response' else 0
            s_budget = effects * AMOUNT_USD_MINOR <= BUDGET_USD_MINOR if sname == 'budget-race' else True
            s_count = effects <= RELEASE_LIMIT if sname == 'count-race' else True
            safety = s_max_per_id and s_committed_without == 0 and s_rejected_own == 0 and s_effect_unanswered == 0 and s_lost_rejected == 0 and s_budget and s_count
            # completion
            groups = collections.defaultdict(list)
            for c in calls:
                groups[(c['operation_id'], content_key(c))].append(answer(c))
            winning = [g for key, g in groups.items() if key[1] in win_content[key[0]]]
            if sname == 'lost-response':
                all_win = all(a in ('COMMITTED/', 'COMMITTED/reconciled', 'UNCERTAIN/provider_response_lost') for g in winning for a in g) and \
                    sum(a.startswith('UNCERTAIN') for g in winning for a in g) <= 1 and bool(winning)
            elif sname in ('budget-race', 'count-race'):
                all_win = True
            else:
                all_win = bool(winning) and all(a == 'COMMITTED/' for g in winning for a in g)
            completed = effects == EXPECTED_EFFECTS[sname] and all_win
            lease_answers = sum(1 for c in calls if answer(c) == LEASE_EXPIRED)
            # consistency
            identical_same = True
            for key, g in groups.items():
                distinct = set(g)
                if sname == 'lost-response':
                    distinct = {a for a in distinct if not a.startswith('UNCERTAIN')}
                    if sum(a.startswith('UNCERTAIN') for a in g) > 1:
                        identical_same = False
                if len(distinct) > 1:
                    identical_same = False
            audit_answers = collections.Counter()
            for i in ids:
                audit_answers.update(call_results.get(i, {}))
            caller_answers = collections.Counter(answer(c) for c in calls)
            audit_match = audit_answers == caller_answers
            consistent = identical_same and audit_match
            # journal transitions
            j_ok = True
            for i in ids:
                ok, problems, kinds, statuses, interval, slack, lease_rec = journal_check(journal.get(i, []), eff[i] > 0)
                if lease_rec:
                    lease_expired_recorded_ops.append({'repeat': rep, 'scenario': sname, 'operation_id': i})
                j_ok &= ok
                if not ok and len(journal_problem_examples) < 20:
                    journal_problem_examples.append({'variant': name, 'repeat': rep, 'scenario': sname, 'operation_id': i, 'problems': problems})
                if interval is not None:
                    intervals.append(interval)
                    slacks.append(slack)
                    if slack < 0:
                        lease_expired.append({'repeat': rep, 'scenario': sname, 'operation_id': i, 'slack_ms': round(1000 * slack, 1)})
                elif 'capability_consumed' in kinds:
                    consumed_without_intent.append({'repeat': rep, 'scenario': sname, 'operation_id': i})
                journal_rows.append([name, n, rep, sname, i, ' > '.join(kinds), ' > '.join(str(x) for x in statuses), eff[i],
                                     'true' if ok else 'false', '; '.join(problems),
                                     '' if interval is None else round(1000 * interval, 3), '' if slack is None else round(1000 * slack, 3),
                                     stages[i].get('EFFECT_EXECUTED', 0), stages[i].get('RECONCILED', 0), stages[i].get('EFFECT_FAILED', 0), stages[i].get('CALL_RESULT', 0)])
            rep_journal_ok &= j_ok
            winner = ''
            if sname == 'cross-tool-reuse':
                winner = ','.join(sorted({c['tool'] for c in calls if c['result'].get('status') == 'COMMITTED'})) or 'none'
                winners[winner] += 1
            for c in calls:
                elapsed[sname].append(c['elapsed_ms'])
            a = agg[sname]
            a['repetitions'] += 1
            a['harness_invariant_held'] += s['invariant_holds']
            a['safety_held'] += safety
            a['completed'] += completed
            a['consistent'] += consistent
            a['identical_requests_identical_answers'] += identical_same
            a['audit_call_results_match_answers'] += audit_match
            a['journal_transitions_ok'] += j_ok
            a['calls'] += len(calls)
            a['operations'] += len(ids)
            a['effects_independent'] += effects
            a['effects_harness'] += s['provider_effects']
            a['effects_expected'] += EXPECTED_EFFECTS[sname]
            a['dispatch_intents'] += intents
            a['committed_without_effect'] += s_committed_without
            a['rejected_identical_to_effect_request'] += s_rejected_own
            a['max_effects_per_id_gt1'] += (not s_max_per_id)
            a['harness_independent_effect_mismatch'] += (effects != s['provider_effects'])
            a['lease_expired_answers'] += lease_answers
            lease_only = (not s['invariant_holds']) and safety and lease_answers > 0
            a['harness_violation_explained_by_lease_expiry_only'] += lease_only
            a['harness_violation_with_safety_breach'] += (not s['invariant_holds']) and not safety
            if lease_only:
                lease_only_harness_failures.append({'repeat': rep, 'scenario': sname, 'pattern': s['pattern']})
            for ans, count in caller_answers.items():
                a['answer ' + ans] += count
            patterns[sname][s['pattern']] += 1
            rows.append([name, n, rep, sname, len(calls), len(ids), s['pattern'], s['provider_effects'], effects, intents, EXPECTED_EFFECTS[sname],
                         'true' if safety else 'false', 'true' if completed else 'false', 'true' if identical_same else 'false',
                         'true' if audit_match else 'false', 'true' if j_ok else 'false', 'true' if s['invariant_holds'] else 'false',
                         s_committed_without, s_rejected_own, s_lost_rejected, lease_answers, winner, s.get('detail', ''),
                         round(min(c['elapsed_ms'] for c in calls), 3), round(max(c['elapsed_ms'] for c in calls), 3)])
        totals['repetitions_all_journal_ok'] += rep_journal_ok
        # evidence: harness pinned verification + CLI without anchors + host label scan
        e = r['evidence']
        evidence['harness %s/%s failing=%s' % (e.get('verdict'), e.get('assurance'), ','.join(e.get('failing_checks') or []) or '-')] += 1
        for k, v in (e.get('dimensions') or {}).items():
            dims['%s=%s' % (k, v)] += 1
        proc = subprocess.run([verify_exe, '--json', '--workers', '1', run_dir], capture_output=True)
        cli = json.loads(proc.stdout.decode('utf-8')) if proc.stdout else {}
        cli_fail = [c['id'] for c in cli.get('checks', []) if c.get('status') == 'fail']
        cli_dims = cli.get('dimensions') or {}
        cli_dim_text = ' '.join('%s=%s' % (k, (v or {}).get('status')) for k, v in sorted(cli_dims.items()))
        evidence['cli(no anchors) %s/%s exit=%d failing=%s' % (cli.get('verdict'), cli.get('assurance'), proc.returncode, ','.join(cli_fail) or '-')] += 1
        mh, lh = scan_host(folder, machine, label)
        host['machine_name_occurrences=%d' % mh] += 1
        host['host_label_present=%s' % (lh > 0)] += 1
        evidence_rows.append([name, n, rep, e.get('verdict'), e.get('assurance'), ' '.join(e.get('failing_checks') or []),
                              ' '.join('%s=%s' % (k, v) for k, v in sorted((e.get('dimensions') or {}).items())), len(e.get('missing') or []),
                              e.get('entries'), e.get('operations'), cli.get('verdict'), cli.get('assurance'), proc.returncode, ' '.join(cli_fail),
                              cli_dim_text, len(cli.get('missing') or []), mh, lh, r.get('error', '')])
    out = {
        'variant': name, 'simultaneous_calls': n, 'repetitions': len(reps), 'environment': d['environment'],
        'repetitions_with_error': [r['repeat'] for r in reps if r.get('error')],
        'scenarios': {k: dict(agg[k]) for k in SCENARIOS},
        'answer_patterns': {k: dict(patterns[k]) for k in SCENARIOS},
        'cross_tool_winner': dict(winners),
        'delegation_status_after_repetition': dict(deleg),
        'independent_provider_counts': dict(independent),
        'journal': {
            'repetitions_seq_gapless': totals['journal_seq_gapless'],
            'repetitions_all_operations_ok': totals['repetitions_all_journal_ok'],
            'problem_examples': journal_problem_examples,
            'dispatches': len(intervals),
            'consumed_without_dispatch_intent': consumed_without_intent,
            'lease_expired_dispatches': lease_expired,
            'lease_seconds': LEASE_SECONDS,
            'operations_recorded_uncertain_dispatch_lease_expired': lease_expired_recorded_ops,
            'harness_violations_explained_by_lease_expiry_only': lease_only_harness_failures,
            'consume_to_intent_ms': None if not intervals else {
                'median': round(1000 * statistics.median(intervals), 1), 'p95': round(1000 * pct(intervals, 95), 1),
                'p99': round(1000 * pct(intervals, 99), 1), 'max': round(1000 * max(intervals), 1)},
            'slack_to_lease_deadline_ms': None if not slacks else {
                'min': round(1000 * min(slacks), 1), 'p1': round(1000 * pct(slacks, 1), 1), 'median': round(1000 * statistics.median(slacks), 1),
                'below_250ms': sum(s < .25 for s in slacks), 'below_500ms': sum(s < .5 for s in slacks),
                'below_2s': sum(s < 2 for s in slacks), 'below_28s': sum(s < 28 for s in slacks)},
        },
        'elapsed_ms': {k: {'median': round(statistics.median(v), 2), 'p95': round(pct(v, 95), 2), 'max': round(max(v), 2)} for k, v in elapsed.items()},
        'evidence': dict(evidence), 'harness_dimensions': dict(dims), 'host_label_scan': dict(host),
    }
    return out


def main():
    analysis_dir, verify_exe, machine, label = sys.argv[1:5]
    os.makedirs(analysis_dir, exist_ok=True)
    rows, evidence_rows, journal_rows, variants = [], [], [], []
    for spec in sys.argv[5:]:
        name, _, dirs = spec.partition('=')
        out_dir, _, work_dir = dirs.partition('::')
        variants.append(analyze_variant(name, out_dir, work_dir, verify_exe, machine, label, rows, evidence_rows, journal_rows))
        print('analyzed', name, file=sys.stderr)
    with open(os.path.join(analysis_dir, 'scenario_repetitions.csv'), 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['variant', 'n', 'repeat', 'scenario', 'calls', 'operation_ids', 'pattern', 'effects_harness', 'effects_independent', 'dispatch_intents',
                    'effects_expected', 'safety_holds', 'completed', 'identical_requests_identical_answers', 'audit_call_results_match_answers',
                    'journal_transitions_ok', 'harness_invariant_holds', 'committed_without_effect', 'rejected_identical_to_effect_request',
                    'lost_response_rejected', 'lease_expired_answers', 'cross_tool_winner', 'harness_detail', 'first_finisher_ms', 'last_finisher_ms'])
        w.writerows(rows)
    with open(os.path.join(analysis_dir, 'evidence.csv'), 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['variant', 'n', 'repeat', 'harness_verdict', 'harness_assurance', 'harness_failing_checks', 'harness_dimensions', 'harness_missing_count',
                    'entries', 'operations', 'cli_verdict_no_anchors', 'cli_assurance_no_anchors', 'cli_exit', 'cli_failing_checks', 'cli_dimensions',
                    'cli_missing_count', 'machine_name_occurrences', 'host_label_occurrences', 'harness_error'])
        w.writerows(evidence_rows)
    with open(os.path.join(analysis_dir, 'journal_operations.csv'), 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['variant', 'n', 'repeat', 'scenario', 'operation_id', 'journal_kinds', 'recorded_statuses', 'provider_receipts', 'transitions_ok',
                    'problems', 'consume_to_intent_ms', 'slack_to_lease_deadline_ms', 'audit_effect_executed', 'audit_reconciled', 'audit_effect_failed',
                    'audit_call_results'])
        w.writerows(journal_rows)
    json.dump({'method': __doc__, 'variants': variants}, open(os.path.join(analysis_dir, 'summary.json'), 'w', encoding='utf-8'), indent=1, default=str)


if __name__ == '__main__':
    main()
