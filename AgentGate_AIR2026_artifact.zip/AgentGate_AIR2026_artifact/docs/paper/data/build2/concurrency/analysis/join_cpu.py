import csv, statistics, sys
runs = list(csv.DictReader(open(sys.argv[1], encoding='utf-8'), delimiter='\t'))
samples = list(csv.DictReader(open(sys.argv[2], encoding='utf-8-sig'), delimiter='\t'))
cols = ['variant', 'binary', 'n', 'repeat', 'gomaxprocs', 'start_utc', 'end_utc', 'exit', 'data_race_reports', 'cpu_samples',
        'machine_cpu_median_pct', 'machine_cpu_min_pct', 'machine_cpu_max_pct', 'max_agentgate_eval_processes_on_machine',
        'max_go_toolchain_processes_on_machine', 'max_other_agentgate_processes_on_machine', 'command']
out = open(sys.argv[3], 'w', encoding='utf-8', newline='')
out.write('\t'.join(cols) + '\n')
for r in runs:
    s = [x for x in samples if r['start_utc'] <= x['utc'] <= r['end_utc']]
    cpu = [float(x['cpu_total_pct']) for x in s]
    r['cpu_samples'] = len(s)
    r['machine_cpu_median_pct'] = '%.1f' % statistics.median(cpu) if cpu else ''
    r['machine_cpu_min_pct'] = '%.1f' % min(cpu) if cpu else ''
    r['machine_cpu_max_pct'] = '%.1f' % max(cpu) if cpu else ''
    r['max_agentgate_eval_processes_on_machine'] = max((int(x['agentgate_eval_processes']) for x in s), default='')
    r['max_go_toolchain_processes_on_machine'] = max((int(x['go_toolchain_processes']) for x in s), default='')
    r['max_other_agentgate_processes_on_machine'] = max((int(x['other_agentgate_processes']) for x in s), default='')
    out.write('\t'.join(str(r[c]) for c in cols) + '\n')
out.close()
print(open(sys.argv[3], encoding='utf-8').read())
