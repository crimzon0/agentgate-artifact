"""Census of the CALL_RESULT audit entries by scope (concurrency, frozen build).

The one change on the concurrency code path in this build is that a replayed
answer of a completed operation (COMMITTED or REJECTED) is logged with scope
"call" (internal/devcomposition/auditing.go). This script counts CALL_RESULT
entries per variant by (kind of answer, replayed, status, reason, scope),
where "kind" is the first words of the entry summary ("Call completed",
"Repeated call", ...), and flags any answer whose summary says it is a
repeat, or whose details say replayed=true, with status COMMITTED/REJECTED
and a scope other than "call".

Usage: python replay_scope.py OUT_TSV LABEL=WORK_ROOT [LABEL=WORK_ROOT ...]
  WORK_ROOT holds one folder per variant, each with concurrency-rNN/run/audit.jsonl.
Exit status 1 if any flagged entry exists in a LABEL whose name starts with "frozen".
"""
import collections
import glob
import json
import os
import sys

VARIANTS = ['n8', 'n32', 'replicate-n8', 'gomaxprocs1-n8', 'race-n8', 'race-n32', 'gomaxprocs1-n32']


def kind(summary):
    s = summary.split(':')[0].split(';')[0]
    return s if len(s) <= 40 else s[:40]


def main():
    out, specs = sys.argv[1], sys.argv[2:]
    rows, flagged_frozen = [], 0
    for spec in specs:
        label, _, root = spec.partition('=')
        for variant in VARIANTS:
            counts = collections.Counter()
            folders = 0
            for path in sorted(glob.glob(os.path.join(root, variant, 'concurrency-r*', 'run', 'audit.jsonl'))):
                folders += 1
                for raw in open(path, encoding='utf-8'):
                    e = json.loads(raw)['entry']
                    if e.get('stage') != 'CALL_RESULT':
                        continue
                    d = e.get('details') or {}
                    counts[(kind(e.get('summary', '')), bool(d.get('replayed')), d.get('status'), d.get('reason', ''), d.get('scope'))] += 1
            for (k, replayed, status, reason, scope), n in sorted(counts.items(), key=str):
                repeat = replayed or k.startswith('Repeated call')
                flag = repeat and status in ('COMMITTED', 'REJECTED') and scope != 'call'
                if flag and label.startswith('frozen'):
                    flagged_frozen += n
                rows.append([label, variant, folders, k, replayed, status, reason, scope, n, 'yes' if flag else ''])
    with open(out, 'w', encoding='utf-8', newline='') as f:
        f.write('build\tvariant\tfolders\tanswer_kind\treplayed\tstatus\treason\tscope\tcall_results\trepeat_not_call_scope\n')
        for r in rows:
            f.write('\t'.join(str(x) for x in r) + '\n')
    totals = collections.Counter()
    for label, variant, folders, k, replayed, status, reason, scope, n, flag in rows:
        totals[(label, k, status, reason, scope, flag)] += n
    for key, n in sorted(totals.items(), key=str):
        print(n, key)
    print('frozen-build repeats of completed operations not scoped to the call:', flagged_frozen)
    sys.exit(1 if flagged_frozen else 0)


if __name__ == '__main__':
    main()
