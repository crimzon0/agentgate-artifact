#!/usr/bin/env bash
# Runs the seven concurrency variants (same set and sizes as build 1, 2026-10-08)
# sequentially with the FROZEN build-2 binaries of singlebuild2/bin; the -race
# variants use agentgate-eval-race.exe, built with -race from the same
# (manifest-verified) source at commit 86643d7.
set -u
REPO="<repo>"
S="<scratch>"
F="$S/build2-work/concurrency"
FROZEN="$S/singlebuild2/bin"
RACEBIN="$F"
OUTREL="docs/paper/data/build2/concurrency"
cd "$REPO" || exit 1
mkdir -p "$F/logs" "$F/work"
RUNS="$F/runs.tsv"
printf 'variant\tbinary\tn\trepeat\tgomaxprocs\tstart_utc\tend_utc\texit\tdata_race_reports\tcommand\n' > "$RUNS"
VARIANTS="n8 agentgate-eval.exe 8 50 0
n32 agentgate-eval.exe 32 50 0
replicate-n8 agentgate-eval.exe 8 50 0
gomaxprocs1-n8 agentgate-eval.exe 8 20 1
race-n8 agentgate-eval-race.exe 8 30 0
race-n32 agentgate-eval-race.exe 32 30 0
gomaxprocs1-n32 agentgate-eval.exe 32 30 1"
echo "$VARIANTS" | while read -r name bin n repeat gmp; do
  rm -rf "$F/work/$name"
  case "$bin" in *race*) exe="$RACEBIN/$bin";; *) exe="$FROZEN/$bin";; esac
  start=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  cmd="$bin -host-label review-host concurrency -out $OUTREL/$name -work <work> -repeat $repeat -n $n"
  if [ "$gmp" = "1" ]; then
    GOMAXPROCS=1 "$exe" -host-label review-host concurrency -out "$OUTREL/$name" -work "$F/work/$name" -repeat "$repeat" -n "$n" > "$F/logs/$name.log" 2>&1
    rc=$?
    cmd="GOMAXPROCS=1 $cmd"
    gmpv=1
  else
    "$exe" -host-label review-host concurrency -out "$OUTREL/$name" -work "$F/work/$name" -repeat "$repeat" -n "$n" > "$F/logs/$name.log" 2>&1
    rc=$?
    gmpv=12
  fi
  end=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  races=""
  case "$bin" in *race*) races=$(grep -c "WARNING: DATA RACE" "$F/logs/$name.log");; esac
  printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$name" "$bin" "$n" "$repeat" "$gmpv" "$start" "$end" "$rc" "$races" "$cmd" >> "$RUNS"
  echo "RUN-DONE $name exit=$rc races=$races violated=$(grep -c VIOLATED "$F/logs/$name.log") $start $end"
done
echo "ALL-DONE"
