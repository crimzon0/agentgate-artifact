param([string]$Out, [string]$StopFile)
# Samples machine CPU and process counts every ~2 s until $StopFile exists.
"utc`tcpu_total_pct`tagentgate_eval_processes`tgo_toolchain_processes`tother_agentgate_processes" | Out-File -FilePath $Out -Encoding ascii
while (-not (Test-Path $StopFile)) {
    try {
        $cpu = (Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'").PercentProcessorTime
        $procs = Get-Process
        $eval = @($procs | Where-Object { $_.ProcessName -like 'agentgate-eval*' }).Count
        $go = @($procs | Where-Object { $_.ProcessName -in @('go', 'compile', 'link', 'vet', 'asm', 'cgo', 'gopls') }).Count
        $other = @($procs | Where-Object { $_.ProcessName -like 'agentgate-*' -and $_.ProcessName -notlike 'agentgate-eval*' }).Count
        $t = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
        "$t`t$cpu`t$eval`t$go`t$other" | Out-File -FilePath $Out -Encoding ascii -Append
    } catch { }
    Start-Sleep -Seconds 2
}
