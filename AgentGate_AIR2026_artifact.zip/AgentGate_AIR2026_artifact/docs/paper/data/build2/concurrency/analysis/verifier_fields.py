"""Build-2 verifier fields of the concurrency evidence (new in the build-2 rerun).

analyze.py is byte-identical to build 1's. It records the verdict,
assurance, dimensions, failing checks and the number of Missing entries, but
not the fields the build-2 verifier added (docs/demo/VERIFIER_CHECKS.md):
the derived dimensions head_fresh and run_complete, the kind of each Missing
entry (unresolved, freshness, issuer_only, other), the per-operation
classification evidence (issuer_adapter, issuer_only_reconciled,
issuer_only_unresolved, issuer_only_no_effect, audit_only) and the flagged /
flagged-but-unconfirmed counts. This script reads them, per evidence folder:

  harness   the in-process verification with keys and head pinned, as the
            harness stored it in concurrency.json (evidence.dimensions,
            evidence.missing, evidence.missing_by_kind);
  cli       the standalone verifier without anchors
            (VERIFY_EXE --json --workers 1 RUN_DIR): verdict, assurance,
            exit code, check-status counts, the nine dimensions, Missing
            kinds, counts.classification_evidence, counts.flagged,
            counts.flagged_unconfirmed, and the classification evidence of
            each RECONCILED-committed operation.

It also counts CALL_RESULT entries with flagged=true in audit.jsonl (expected
0: the concurrency harness's grant and requests fire no flag rule).

Usage: python verifier_fields.py OUT_PREFIX VERIFY_EXE LABEL=OUT_DIR::WORK_DIR::VARIANT [...]
  Writes OUT_PREFIX.csv (one row per folder) and OUT_PREFIX.json (totals per label).
  OUT_DIR holds the variant's concurrency.json; WORK_DIR holds concurrency-rNN/.
"""
import collections
import csv
import json
import os
import subprocess
import sys

DIMS = ['structural', 'decisions_authenticated', 'policy_replayed', 'provider_reconciled', 'delegation_respected',
        'anchored_keys', 'anchored_head', 'head_fresh', 'run_complete']
KINDS = ['unresolved', 'freshness', 'issuer_only', 'other']


def kv(counter):
    return ' '.join('%s=%s' % (k, counter[k]) for k in sorted(counter))


def main():
    prefix, verify_exe = sys.argv[1:3]
    rows = []
    totals = collections.defaultdict(collections.Counter)
    for spec in sys.argv[3:]:
        label, _, rest = spec.partition('=')
        out_dir, work_dir, variant = rest.split('::')
        d = json.load(open(os.path.join(out_dir, 'concurrency.json'), encoding='utf-8'))
        for r in d['repetitions']:
            rep = r['repeat']
            folder = os.path.join(work_dir, 'concurrency-r%02d' % rep)
            run_dir = os.path.join(folder, 'run')
            t = totals[label]
            t['folders'] += 1
            # harness (pinned) evidence as stored by the harness
            e = r.get('evidence') or {}
            hdims = e.get('dimensions') or {}
            hmk = e.get('missing_by_kind')
            t['harness %s/%s' % (e.get('verdict'), e.get('assurance'))] += 1
            for name in DIMS:
                t['harness dim %s=%s' % (name, hdims.get(name, 'absent'))] += 1
            t['harness missing=%d' % len(e.get('missing') or [])] += 1
            t['harness missing_by_kind %s' % (kv(hmk) if hmk is not None else 'absent')] += 1
            t['harness failing=%d' % len(e.get('failing_checks') or [])] += 1
            # standalone verifier, no anchors
            proc = subprocess.run([verify_exe, '--json', '--workers', '1', run_dir], capture_output=True)
            cli = json.loads(proc.stdout.decode('utf-8')) if proc.stdout else {}
            status = collections.Counter(c.get('status') for c in cli.get('checks', []))
            failing = sorted({c['id'] for c in cli.get('checks', []) if c.get('status') == 'fail'})
            warn_ids = sorted({c['id'] for c in cli.get('checks', []) if c.get('status') == 'warn'})
            cdims = {k: (v or {}).get('status') for k, v in (cli.get('dimensions') or {}).items()}
            kinds = collections.Counter(cli.get('missing_kinds') or [])
            counts = cli.get('counts') or {}
            ce = collections.Counter(counts.get('classification_evidence') or {})
            reconciled_ce = collections.Counter()
            for op in cli.get('operations') or []:
                if (op.get('status') or '').lower() in ('executed',) and op.get('reconciled'):
                    reconciled_ce[op.get('classification_evidence')] += 1
            flagged_results = 0
            for raw in open(os.path.join(run_dir, 'audit.jsonl'), encoding='utf-8'):
                entry = json.loads(raw)['entry']
                if entry.get('stage') == 'CALL_RESULT' and (entry.get('details') or {}).get('flagged') is True:
                    flagged_results += 1
            t['cli %s/%s exit=%d' % (cli.get('verdict'), cli.get('assurance'), proc.returncode)] += 1
            t['cli checks %s' % kv(status)] += 1
            t['cli checks_total=%d' % sum(status.values())] += 1
            t['cli failing=%s' % (','.join(failing) or '-')] += 1
            t['cli warn=%s' % (','.join(warn_ids) or '-')] += 1
            for name in DIMS:
                t['cli dim %s=%s' % (name, cdims.get(name, 'absent'))] += 1
            t['cli missing=%d' % len(cli.get('missing') or [])] += 1
            t['cli missing_kinds %s' % kv(kinds)] += 1
            t['cli classification_evidence %s' % kv(ce)] += 1
            t['cli flagged=%s flagged_unconfirmed=%s' % (counts.get('flagged'), counts.get('flagged_unconfirmed', 'absent'))] += 1
            t['cli reconciled=%s' % counts.get('reconciled')] += 1
            t['cli executed+reconciled ops: classification_evidence %s' % kv(reconciled_ce)] += 1
            t['audit call_results_flagged=%d' % flagged_results] += 1
            for k, v in ce.items():
                t['ops classification_evidence ' + k] += v
            t['ops total'] += counts.get('operations', 0) or 0
            t['entries total'] += counts.get('entries', 0) or 0
            rows.append([label, variant, d['simultaneous_calls'], rep,
                         e.get('verdict'), e.get('assurance'), len(e.get('failing_checks') or []),
                         hdims.get('head_fresh', 'absent'), hdims.get('run_complete', 'absent'),
                         len(e.get('missing') or []), kv(hmk) if hmk is not None else 'absent',
                         cli.get('verdict'), cli.get('assurance'), proc.returncode, sum(status.values()),
                         status.get('pass', 0), status.get('warn', 0), status.get('fail', 0), ' '.join(failing), ' '.join(warn_ids),
                         ' '.join('%s=%s' % (k, cdims.get(k, 'absent')) for k in DIMS),
                         len(cli.get('missing') or []), ' '.join(cli.get('missing_kinds') or []),
                         kv(ce), counts.get('flagged'), counts.get('flagged_unconfirmed', 'absent'), counts.get('reconciled'),
                         counts.get('entries'), counts.get('operations'), flagged_results])
        print('verified', label, variant, file=sys.stderr)
    with open(prefix + '.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['label', 'variant', 'n', 'repeat', 'harness_verdict', 'harness_assurance', 'harness_failing',
                    'harness_head_fresh', 'harness_run_complete', 'harness_missing', 'harness_missing_by_kind',
                    'cli_verdict', 'cli_assurance', 'cli_exit', 'cli_checks', 'cli_pass', 'cli_warn', 'cli_fail', 'cli_failing_ids', 'cli_warn_ids',
                    'cli_dimensions', 'cli_missing', 'cli_missing_kinds', 'cli_classification_evidence', 'cli_flagged',
                    'cli_flagged_unconfirmed', 'cli_reconciled', 'entries', 'operations', 'audit_call_results_flagged'])
        w.writerows(rows)
    json.dump({'method': __doc__, 'totals': {k: dict(sorted(v.items())) for k, v in totals.items()}},
              open(prefix + '.json', 'w', encoding='utf-8'), indent=1)
    for label, t in totals.items():
        print('==', label)
        for k, v in sorted(t.items()):
            print('  %6d  %s' % (v, k))


if __name__ == '__main__':
    main()
