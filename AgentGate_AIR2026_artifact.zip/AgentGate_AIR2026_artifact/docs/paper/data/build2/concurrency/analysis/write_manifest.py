"""Writes build-manifest.txt for the build-2 concurrency rerun (adapted from build 1's write_manifest.py).

usage: python write_manifest.py MANIFEST2 MANIFEST1 OUT RACE_SHA256 RACE_T0 RACE_T1 GO_VERSION_M_DIFF_FILE GIT_STATUS_FILE CHECK_LINE...
  MANIFEST2  <singlebuild2>/MANIFEST.txt (build 2)
  MANIFEST1  <scratch>/singlebuild/MANIFEST.txt (build 1, for the list of changed files)
  CHECK_LINE "label|utc-start|utc-end|output" lines of check_manifest.py, in order
No absolute local path is written: paths are given as <repo>, <scratch>, <singlebuild2>.
"""
import hashlib
import re
import sys

manifest, prev, out, racehash, t_race0, t_race1, vdiff, gitstatus = sys.argv[1:9]
checks = sys.argv[9:]
text = open(manifest, encoding='utf-8').read()


def load(p):
    d = {}
    for line in open(p, encoding='utf-8'):
        m = re.match(r'^([0-9a-f]{64}) \*(.+)$', line.strip())
        if m:
            d[m.group(2)] = m.group(1)
    return d


new, old = load(manifest), load(prev)
mod = lambda d: {k: v for k, v in d.items() if not k.startswith('$') and not k.startswith('bin/')}
nm, om = mod(new), mod(old)
changed = sorted(k for k in set(nm) & set(om) if nm[k] != om[k])
added = sorted(set(nm) - set(om))
removed = sorted(set(om) - set(nm))
third = lambda d: {k: v for k, v in d.items() if k.startswith('$')}
nt, ot = third(new), third(old)
third_changed = sum(1 for k in set(nt) & set(ot) if nt[k] != ot[k])
third_added = len(set(nt) - set(ot))
bins = [l for l in text.splitlines() if re.match(r'^[0-9a-f]{64} \*bin/', l)]
module = sorted(('%s *%s' % (v, k) for k, v in nm.items()), key=lambda s: s.split('*', 1)[1])
written = re.search(r'^written: (\S+)', text, re.M).group(1)
L = []
L.append('# Build manifest for the concurrency rerun on FROZEN BUILD 2 (2026-10-10 UTC)')
L.append('# The harness runs used ONLY the frozen binaries of <singlebuild2>/bin (manifest written %s by the build step,' % written)
L.append('# commit 86643d7 of branch claude/supervisor-demo; the working tree differs from it only by files that are not compiled:')
L.append('# a deleted PDF under output/paper/ and untracked files, see git status below); full manifest:')
L.append('#   <singlebuild2>/MANIFEST.txt, SHA-256 %s' % hashlib.sha256(open(manifest, 'rb').read()).hexdigest())
L.append('#   (%d entries: 6 binaries + %d compiled source/embedded files: %d module, %d third-party, %d stdlib)'
         % (len(new), len(new) - len(bins), len(nm), sum(1 for k in nt if k.startswith('$GOMODCACHE/')), sum(1 for k in nt if k.startswith('$GOROOT/'))))
L.append('# git rev-parse HEAD and git status --porcelain (research/ omitted) before the runs (the build2/ folder is this output):')
for line in open(gitstatus, encoding='utf-8'):
    L.append('#   ' + line.rstrip())
L.append('# frozen binaries (sha256), checked against MANIFEST.txt before the first run:')
for l in bins:
    L.append('#   ' + l)
L.append('# used here: bin/agentgate-eval.exe (n8, n32, replicate-n8, gomaxprocs1-n8, gomaxprocs1-n32) and bin/agentgate-verify.exe')
L.append('#   (analysis CLI cross-check: analyze.py and verifier_fields.py, on this run\'s folders and on build 1\'s).')
L.append('# race build (race-n8, race-n32): the frozen set has no -race binary, so it was built from the frozen source after check_manifest.py')
L.append('#   reported 0 differences, %s-%s, with the same toolchain and flags plus -race (CGO via msys64 ucrt64 gcc 15.2.0):' % (t_race0, t_race1))
L.append('#   go build -race -o <scratch>/build2-work/concurrency/agentgate-eval-race.exe ./cmd/agentgate-eval/')
L.append('#   %s *agentgate-eval-race.exe' % racehash)
L.append('#   go version -m of the race build against the frozen bin/agentgate-eval.exe (diff, paths replaced):')
for line in open(vdiff, encoding='utf-8'):
    L.append('#     ' + line.rstrip('\n'))
L.append('#   i.e. identical module version (agentgate v0.0.0-20261010022356-86643d751720+dirty, vcs.revision 86643d7, vcs.modified=true),')
L.append('#   dependencies and build settings, except "build -race=true". It also links runtime/race and runtime/cgo files that')
L.append('#   MANIFEST.txt does not list (not part of the six frozen binaries).')
L.append('# check_manifest.py (re-hash of all %d MANIFEST entries: binaries, module, third-party, stdlib), py <singlebuild2>/check_manifest.py:' % len(new))
for c in checks:
    label, t0, t1, output = c.split('|', 3)
    L.append('#   %-34s %s .. %s: %s' % (label + ':', t0, t1, output))
L.append('# Changed against build 1 (<scratch>/singlebuild/MANIFEST.txt, %d module files):' % len(om))
L.append('#   changed (%d): %s' % (len(changed), ', '.join(changed)))
L.append('#   added (%d): %s' % (len(added), ', '.join(added)))
L.append('#   removed (%d): %s' % (len(removed), ', '.join(removed) or '-'))
L.append('#   third-party/stdlib: %d changed, %d added (files of packages only the new killsuite binary links), 0 removed' % (third_changed, third_added))
L.append('#   On the concurrency code path: internal/devcomposition/{auditing,dispatch,durable}.go (a COMMITTED answer, also a replayed')
L.append('#   or stored one, states the flag of the decision its effect rests on; the dispatch intent journals the flag; comments),')
L.append('#   cmd/agentgate-eval/harness.go (the harness stores the derived dimensions and missing_by_kind) and the verifier')
L.append('#   (internal/auditverify/{assurance,operations,reconcile,verify,freshness}.go, cmd/agentgate-verify/main.go).')
L.append('#   cmd/agentgate-eval/concurrency.go is byte-identical to build 1 (53667d0b...).')
L.append('# agentgate module files compiled into the six frozen binaries (sha256, from MANIFEST.txt):')
L.extend(module)
open(out, 'w', encoding='utf-8', newline='\n').write('\n'.join(L) + '\n')
print(len(module), 'module entries;', len(changed), 'changed;', len(added), 'added:', changed, added)
