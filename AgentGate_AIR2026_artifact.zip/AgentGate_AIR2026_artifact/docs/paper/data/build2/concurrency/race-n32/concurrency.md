# Concurrency: simultaneous retries, conflicting reuse, racing reservations

Local races inside one gateway process on one machine: the start barrier releases the goroutines together, but the interleaving is whatever the Go scheduler produced in each repetition. Holding invariants here do not prove them for all interleavings.

Command: `agentgate-eval -host-label review-host concurrency -out docs/paper/data/build2/concurrency/race-n32 -work <work> -repeat 30 -n 32`. Go go1.26.6 on windows/amd64, 12 CPUs, GOMAXPROCS 12.

## Method

- 32 goroutines per scenario wait on one start barrier and then each send one JSON-RPC tools/call through the gateway's MCP handler (in process).
- Provider: provider host with its own key, reached over loopback HTTP; every count of effects is read from its own signed journal.
- Grant: AED budget AED 10,000,000,000.00, USD budget USD 3,000.00, 3 document releases; everything else unbounded.
- Pattern: the sorted multiset of STATUS/reason answers of one scenario; identical patterns in every repetition mean the answers were deterministic up to which caller won.

## Results

| scenario | invariant | held | max effects | max effects per ID | REJECTED with effect | COMMITTED without effect | answer patterns (repetitions) |
|---|---|---|---|---|---|---|---|
| exact-payment | exactly 1 effect; every answer COMMITTED with the same provider reference | 30 / 30 | 1 | 1 | 0 | 0 | 32x COMMITTED/ (30) |
| exact-message | exactly 1 effect; every answer COMMITTED with the same provider reference | 30 / 30 | 1 | 1 | 0 | 0 | 32x COMMITTED/ (30) |
| conflicting-reuse | at most 1 effect; every other caller REJECTED operation_id_conflict | 30 / 30 | 1 | 1 | 0 | 0 | 1x COMMITTED/ + 31x REJECTED/operation_id_conflict (30) |
| cross-tool-reuse | exactly 1 effect; all callers of the winning tool COMMITTED (same reference), all callers of the other tool REJECTED operation_id_conflict | 30 / 30 | 1 | 1 | 0 | 0 | 16x COMMITTED/ + 16x REJECTED/operation_id_conflict (30) |
| lost-response | exactly 1 effect; no REJECTED; the answers that are not UNCERTAIN are COMMITTED (reconciled) | 30 / 30 | 1 | 1 | 0 | 0 | 31x COMMITTED/reconciled + 1x UNCERTAIN/provider_response_lost (30) |
| budget-race | committed USD total <= budget (at most 6 of 32 payments); COMMITTED answers == effects | 30 / 30 | 6 | 1 | 0 | 0 | 6x COMMITTED/ + 26x REJECTED/policy_denied (30) |
| count-race | at most 3 releases committed; COMMITTED answers == effects | 30 / 30 | 3 | 1 | 0 | 0 | 3x COMMITTED/ + 29x REJECTED/policy_denied (30) |

## Evidence

One evidence folder per repetition, verified with the keys fingerprint and final head pinned:

- ANCHORED: 30
