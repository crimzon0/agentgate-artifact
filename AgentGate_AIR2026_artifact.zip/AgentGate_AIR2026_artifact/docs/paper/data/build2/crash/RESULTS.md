# Crash, response loss and restart (R6.3), rerun on frozen build 2

Run 2026-10-10 02:28:36-02:30:37 UTC (flag mode) and 02:30:37-02:33:08 UTC
(deny mode) with **frozen build 2** (`agentgate-eval` `485e4ce0...fdca`,
`agentgate-verify` `83d0786a...f006`, built from commit `86643d7` of
`claude/supervisor-demo`; `build-manifest.txt`). It repeats the build-1 run of
2026-10-08 (`../../revision/crash/RESULTS.md`) with the same command,
parameters, repetitions and analysis scripts. It answers review major
comments 2 and 3 for the second review round.

**Headline.** All build-1 results hold on build 2:

- 0 of 1,120 operations produced two provider effects.
- 0 of 480 REJECTED answers came while the provider held an effect.
- 0 of 1,120 COMMITTED answers had no provider effect.
- After one `Reconcile`, 0 of 1,120 operations were unresolved.
- **All 840 evidence folders are VERIFIED/ANCHORED (flag), and 420 of 420 in
  deny.** That includes the 280 second segments after a restart, which are
  walked together with segment 1 as one run (140 of 140 in deny).
- Every replayed answer is logged with scope `call` (240 of 240; 120 of 120
  in deny).
- Every `call_id` ties to a later answer.

The results for each schedule are **the same as in build 1**. I removed the
fields that build 2 adds and compared all 560 schedules (280 in deny): none
differs.

The differences come only from new verifier output:

- **Every folder now lists a `freshness` Missing entry.** A pinned head is
  never shown to be fresh. This covers 840 of 840 folders (420 of 420 in
  deny), so "folders with missing items" rose from 160 to 840 (80 to 420 in
  deny).
- **320 of the 1,360 provider effects are classified `issuer_only_reconciled`**
  (a RECONCILED entry with no adapter receipt). Each folder that holds one
  adds one `issuer_only` Missing entry, 160 folders in all (80 in deny).
- The derived dimension `run_complete` **fails** in the 160 restart segment-1
  folders (80 in deny) that leave operations unresolved.

None of these changes a verdict, an assurance level or a failing check.

## 0. Comparison with build 1

| headline number (flag run; deny in brackets) | build 1 (2026-10-08) | build 2 (2026-10-10) | why it differs |
|---|---|---|---|
| more than one provider effect for one operation ID | 0 / 1,120 (0 / 560) | **0 / 1,120 (0 / 560)** | same |
| REJECTED answered while the provider holds an effect | 0 / 480 (0 / 240) | **0 / 480 (0 / 240)** | same; all `dispatched=false`: 240 `dispatch_refused`, 240 `aborted_before_send` |
| COMMITTED answered with no provider effect | 0 / 1,120 (0 / 560) | **0 / 1,120 (0 / 560)** | same |
| provider effect with no EFFECT_EXECUTED / RECONCILED(committed) | 0 / 1,360 (0 / 680) | **0 / 1,360 (0 / 680)** | same |
| unresolved after the retry, then after one `Reconcile` | 320 then 0 / 1,120 (160 then 0 / 560) | **320 then 0 / 1,120 (160 then 0 / 560)** | same |
| same-ID retry of an unresolved operation: COMMITTED/reconciled, 0 new effects | 320 / 320 (160 / 160) | **320 / 320 (160 / 160)** | same |
| same content committed twice under a fresh ID (by design) | 400 / 1,120 (200 / 560) | **400 / 1,120 (200 / 560)** | same |
| replayed answers logged with scope `call` | 240 / 240 (120 / 120) | **240 / 240 (120 / 120)** | same; `call_ids.txt` byte-identical (flag and deny) |
| EFFECT_EXECUTED with `call_id` that a later CALL_RESULT answers | 880 / 880 (440 / 440) | **880 / 880 (440 / 440)** | same |
| RECONCILED (same-ID retry) with `call_id` that a later CALL_RESULT answers | 320 / 320 (160 / 160) | **320 / 320 (160 / 160)** | same; the 320 (160) RECONCILED written by `Reconcile` have no `call_id`, as specified |
| evidence folders VERIFIED/ANCHORED | 840 / 840 (420 / 420) | **840 / 840 (420 / 420)** | same |
| restart segment 2, verified as a chain of 2 | 280 / 280 (140 / 140) | **280 / 280 (140 / 140)** | same; the CLI walked 2 segments in 560 / 560 rows (280 / 280) |
| folders whose seven check-based dimensions all pass | 840 / 840 | **840 / 840 (420 / 420)** | same |
| folders listing any Missing entry | 160 / 840 (80 / 420) | **840 / 840 (420 / 420)** | new freshness entry in every pinned folder (VERIFIER_CHECKS §1, `freshnessGap`) |
| ... of kind `unresolved` | (160, the only kind then) | **160 / 840 (80 / 420)**, 2 entries each | same folders and entries as build 1 (restart segment 1 of the four post-dispatch fault points) |
| ... of kind `freshness` | did not exist | **840 / 840 (420 / 420)** | new: the head is pinned, never fresh (`head_fresh` not_checked) |
| ... of kind `issuer_only` | did not exist | **160 / 840 (80 / 420)** | new: a folder with an executed operation known only from a RECONCILED entry without an adapter receipt (below) |
| ... of kind `other` | | **0 / 840 (0 / 420)** | |
| no-restart folders with nothing missing | 280 / 280 | **0 / 280**: 240 list only `freshness`, 40 list `freshness` + `issuer_only` | the new kinds; `provider_response_lost` (40) has no adapter receipt |
| restart segment 2 with nothing missing | 280 / 280 | **0 / 280**: 160 list only `freshness`, 120 list `freshness` + `issuer_only` | the new kinds; the 120 recoveries after a restart lack an adapter receipt |
| `head_fresh` / `run_complete` | did not exist | `head_fresh` not_checked 840 / 840; `run_complete` **fail 160**, not_checked 680 / 840 (deny 80 / 340) | new derived dimensions: a pinned head is never fresh. `run_complete` fails when an operation is left unresolved (restart segment 1 verified alone) |
| classification evidence (operations in the final view of each schedule) | did not exist | `issuer_adapter` 1,040; `issuer_only_reconciled` 320; `issuer_only_no_effect` 320; 0 other; of 1,680 operations (deny 520 / 160 / 160 of 840) | new per-operation report member (table in §3) |
| CLI cross-check agrees with the harness | 1,680 / 1,680 (840 / 840) | **1,680 / 1,680 (840 / 840)** | same, after `cli_crosscheck.py` was changed to the new Missing semantics (§4) |
| restart tamper probes detected (5 edits x 560) / clean copy accepted | 2,800 / 2,800, 560 / 560 | **2,800 / 2,800, 560 / 560** | same; `continuity_probes.csv` byte-identical |
| recount from disk: disagreements with the harness / answers = logged CALL_RESULT | 0, 1,120 / 1,120 (0, 560 / 560) | **0, 1,120 / 1,120 (0, 560 / 560)** | same; totals in `reanalysis.json` identical |
| armed faults that fired / schedules failed / unstable cells | 960 / 960, 0 / 560, 0 / 56 | **960 / 960, 0 / 560, 0 / 56** (deny 480 / 480, 0 / 280, 0 / 56) | same |
| flag and deny cell results | 0 of 336 compared fields differ | **0 of 336** (also 0 of 504 safety shares, 0 of 112 folder fields) | same; `flag_vs_deny.py` rebuilds the build-1 comparison |
| run.json with `"host": "review-host"` | 1,260 / 1,260 | **1,260 / 1,260** | same; no evidence file contains the machine name or a local path |

**What the build-2 changes do here.**

- **Verifier, freshness.** The harness pins keys and head, so every folder
  gets the freshness gap. The text names the case that build 1 left as a
  caveat: "a withheld later restart segment cannot be ruled out". Segment 1
  verified alone is still ANCHORED (280/280). Its report now says that it
  is not shown to be the complete latest run: `run_complete` is fail (160)
  or not_checked (120), never pass.
- **Verifier, classification evidence.** Of the 1,360 effects, 320 rest on
  the issuer's signature alone (`issuer_only_reconciled`):
  - `provider_response_lost`, all four cells (160 operations). The adapter
    never saw the provider's answer, so no adapter receipt exists.
  - `after_receipt_before_audit` and `audit_append` after a restart (160).
    The gateway keeps the adapter's receipt in memory only, so a gateway
    rebuilt on the journal reconciles without it (as VERIFIER_CHECKS §1
    documents).

  The same two fault points without a restart (160) keep the receipt on
  RECONCILED and count as `issuer_adapter`. In all, 240 RECONCILED entries
  carry an adapter receipt (flag; 120 in deny). That is those 160 plus 80
  from `head_replace` without a restart. The verifier checks an attached
  receipt under `op.receipts_bound`, and no check failed in any folder.
  The disk recount in `recovery_records.py` gives the same split as the
  classification: 880 EFFECT_EXECUTED + 160 RECONCILED with adapter receipt
  = 1,040; 320 RECONCILED with the provider receipt only; 320 refused. The
  evidence files carry these receipts in the same places as in build 1
  (`recovery_records.txt` is byte-identical to its build-1 count). What is
  new is the verifier's reading of them, not the gateway's records.
- **Gateway, flag on recovery records and replays.** No operation in this
  experiment is flagged (plain ALLOW: FIN-AUTO payment, MSG-INTERNAL
  message). `details.flagged` is absent from all 2,240 CALL_RESULT and 640
  RECONCILED entries (1,120 and 320 in deny), and `counts.flagged` /
  `counts.flagged_unconfirmed` are 0 in 840 of 840 reports. The new
  recovery-flag and replay checks of `op.requires_policy` ran, and none
  failed. This experiment does not exercise a flagged recovery (open issues).
- **Not exercised here:** evalattack's flag on RECONCILED commits, the
  custody runner's witness fetch time, the killsuite binary, and the witness
  run status. The crash harness registers no witness.

## 1. Method (unchanged from build 1)

Commands, run from the repository root; nothing was compiled:

```
<singlebuild2>/bin/agentgate-eval -host-label review-host crash -repeat 20 -out docs/paper/data/build2/crash -work <scratch>/build2-work/crash/wf
<singlebuild2>/bin/agentgate-eval -host-label review-host crash -escalation deny -repeat 10 -out docs/paper/data/build2/crash/deny -work <scratch>/build2-work/crash/wd
```

Both exited 0 with empty stderr. `run.log` and `deny/run.log` are their
stdout, byte-identical to build 1 apart from the line that names the output
folder.

**Schedules.** Each schedule builds a fresh gateway with:

- an fsynced JSONL operation journal;
- per-run keys;
- an effectively unlimited signed grant.

It then sends two operations, an AED 400.00 payment and an internal message.

**Factors:**

- 7 fault points: `none`, `before_capability_consume`,
  `after_capability_consume`, `provider_response_lost`,
  `after_receipt_before_audit`, `audit_append` and `head_replace` (emulated);
- retry with the same operation ID or a fresh ID;
- restart: none, or journal (abandon the gateway object and build a new one
  with new keys on the same journal and provider);
- 20 repetitions.

That gives **560 schedules, 1,120 operations, 2,240 answers, 1,360 provider
effects and 840 evidence folders**. The deny run has half of each.

**Order:** first calls, the optional restart, retries, one
`Composition.Reconcile`, close. Then each folder is verified with its keys
fingerprint and final head pinned.

**Build check.** `check_manifest.py` re-hashed the 1,868 files listed in
`MANIFEST.txt` at two points:

- before the runs, at 02:28:21Z;
- after every run, cross-check and probe, at 02:37:05Z.

Both times, 0 files differed (`build-manifest.txt`).

**Analysis**, with the same scripts as build 1, copied here:

- `cells.py`
- `reanalyze_from_disk.py`
- `call_ids.py`
- `cli_crosscheck.py`, changed for the new Missing semantics, §4
- `continuity_probes.py`

Changes and additions:

- `cells.py` now also prints each folder's Missing kinds.
- `compare_crash_json.py` is the build-1 comparison script. It now also
  repeats the comparison with the build-2 additions removed.
- Two scripts are new:
  - `recovery_records.py`: receipts on recovery records and the flag field,
    read from disk;
  - `flag_vs_deny.py`: rebuilds build 1's "0 of 336" comparison, whose
    script was not kept.

## 2. Results (flag run; deny shows the same pattern at half the counts)

Answers:

- COMMITTED 1,120, of which 320 reconciled;
- REJECTED 480;
- RECONCILIATION_REQUIRED 480;
- UNCERTAIN 160;
- PENDING 0.

No answer had reason `dispatch_lease_expired`, and no EFFECT_FAILED has
`lease_expired=true` (lease 30 s).

| fault point | first answer | exact retry | provider effects | classification of the original operation (final view) |
|---|---|---|---|---|
| none | COMMITTED | COMMITTED (stored, scope `call`) | 1 | `issuer_adapter` |
| before_capability_consume | REJECTED / dispatch_refused | the stored REJECTED (scope `call`) | 0 | `issuer_only_no_effect` |
| after_capability_consume | REJECTED / aborted_before_send | the stored REJECTED (scope `call`) | 0 | `issuer_only_no_effect` |
| provider_response_lost | UNCERTAIN | COMMITTED / reconciled | 1 | `issuer_only_reconciled` (with or without restart) |
| after_receipt_before_audit, audit_append | RECONCILIATION_REQUIRED | COMMITTED / reconciled | 1 | `issuer_adapter` without restart (receipt on RECONCILED); `issuer_only_reconciled` after a restart |
| head_replace (emulated) | RECONCILIATION_REQUIRED | COMMITTED / reconciled | 1 | `issuer_adapter` (EFFECT_EXECUTED present) |

A fresh-ID retry commits the same content once more under the new ID, and
that operation is `issuer_adapter`. A restart changes where the evidence
lands and, for the two post-receipt fault points, whether RECONCILED carries
the adapter receipt. Answers, effects and operation states are the same as
without a restart.

## 3. Evidence verification (keys fingerprint and final head pinned)

| folders | verdict / assurance | Missing by kind (folders) | derived dimensions |
|---|---|---|---|
| all | **840 / 840 VERIFIED/ANCHORED**, 0 FAILED, 7 check-based dimensions pass in all | freshness 840, unresolved 160 (320 entries), issuer_only 160, other 0 | head_fresh not_checked 840; run_complete fail 160, not_checked 680 |
| no restart (280) | 280 / 280 ANCHORED | freshness 280; issuer_only 40 (provider_response_lost) | run_complete not_checked 280 |
| restart, segment 1 verified alone (280) | 280 / 280 ANCHORED | freshness 280; unresolved 160 (2 operations each, settled in segment 2) | run_complete **fail** 160 (the unresolved ones), not_checked 120 |
| restart, segment 2 walked with segment 1 (280) | **280 / 280 VERIFIED/ANCHORED**, 0 failing checks | freshness 280; issuer_only 120 (provider_response_lost, after_receipt_before_audit, audit_append) | run_complete not_checked 280 |
| deny run | 420 / 420 ANCHORED; segment 2: 140 / 140 | freshness 420, unresolved 80, issuer_only 80, other 0 | run_complete fail 80, not_checked 340 |

**Classification evidence** comes from the CLI's
`operations[].classification_evidence`; the harness does not record it.
Pinned pass:

| scope | operations | issuer_adapter | issuer_only_reconciled | issuer_only_unresolved | issuer_only_no_effect | audit_only |
|---|---|---|---|---|---|---|
| final view of each schedule (no restart: segment 1; restart: segment-2 chain), flag | 1,680 (1,120 original + 560 fresh-ID) | 1,040 | 320 | 0 | 320 | 0 |
| same, deny | 840 | 520 | 160 | 0 | 160 | 0 |
| every pinned verification, flag (a segment-2 chain counts both segments' operations) | 2,240 | 1,200 | 320 | 240 (160 reconciliation_required + 80 uncertain, all in restart segment 1) | 480 | 0 |

The executed operations in the final views, 1,040 + 320 = 1,360, equal the
1,360 provider effects. The per-cell breakdown is in
`cli_crosscheck.summary.json` and in the `cli_operation_classes` column of
`cli_crosscheck.csv`.

Two notes on the classes:

- **Restart segment 1 alone, `head_replace`.** These operations are
  `executed` / `issuer_adapter`, because the EFFECT_EXECUTED entry is in
  segment 1. The folder still lists them as unresolved, because the gateway
  answered RECONCILIATION_REQUIRED and reconciled them only in segment 2.
  The same 2 unresolved items appeared in build 1.
- **`before_capability_consume` refusals.** These are
  `issuer_only_no_effect`, not `audit_only`: the capability was issued and
  verified, then refused before it was consumed.

## 4. Cross-checks

**Command-line verifier in a separate process** (`cli_crosscheck.py` with
the frozen `agentgate-verify`). Each folder is checked twice:

- with no anchors: VERIFIED/CONSISTENT;
- with the pins read from the folder: VERIFIED/ANCHORED.

It agreed with the in-process result in 840 of 840 checks of each kind
(1,680 of 1,680 flag; 840 of 840 deny). The columns it shares with build 1's
CSV are identical row by row: verdicts, assurance, failing checks, exit
code, segments walked and entry counts. For every segment 2 it walked 2
segments, and its entry count equals the sum of both. Same verifier code,
so this is not an independent check.

*Script change and why.* Build 1 expected the unanchored run to list
"harness count + 2" Missing entries: the harness count plus "No keys anchor"
and "No head anchor". Build 2 compares by kind:

- The harness (pinned head) now always lists one `freshness` entry.
- An unanchored run has no head anchor, so it lists no freshness entry
  (`freshnessGap` requires `anchored_head` to pass) and lists the two anchor
  items, of kind `other`, instead.

So the expected unanchored kinds are the harness kinds, with `freshness`
removed and `other` increased by 2. In total that is harness count - 1 + 2:

| harness kinds | unanchored total, build 1 | unanchored total, build 2 |
|---|---|---|
| freshness only | 2 | 2 |
| freshness + issuer_only | 2 | 3 |
| freshness + 2 unresolved | 4 | 4 |

The pinned run must list exactly the harness kinds. The script now also
checks:

- that all nine dimensions, including `head_fresh` and `run_complete`,
  equal the harness's;
- that `missing_kinds` has one kind per Missing entry.

**Recount from the files on disk** (`reanalyze_from_disk.py`, which decodes
the provider receipts with its own CBOR reader):

- 0 disagreements with the harness;
- the agent's answer matches the logged CALL_RESULT in 1,120 of 1,120
  (560 of 560 in deny);
- the totals are identical to build 1.

**Tamper tests on the restart evidence** (`continuity_probes.py`; 280
restart schedules x 2 anchor conditions = 560 per edit):

- the clean copy was accepted 560 of 560;
- each of the five edits was detected 560 of 560 (segment 1 deleted, cut
  short, rolled back by a simulated audit-key holder, link removed, swapped
  for another run's);
- the failing checks in every row are the same as in build 1.
  `continuity_probes.csv` is byte-identical.

## 5. Caveats

All build-1 caveats still apply:

- The crash abandons the gateway object inside one process. No process is
  killed, and the provider never restarts. The new `agentgate-killsuite`
  covers OS-level kills.
- `head_replace` is emulated.
- There is one fault per operation and at most one restart.
- No provider-side faults are injected, so a reconciliation to "not
  committed" is never exercised.
- Only plain ALLOW operations are used, with no budget pressure, so the deny
  run exercises the same paths.
- No witness is used.
- Repetitions are stability checks, not independent samples.

New or sharpened in build 2:

- **The freshness entry is constant.** Here it says only that the head was
  pinned, not fetched fresh from a witness. Counting "folders with missing
  items" no longer means anything, so read the counts by kind.
- **`issuer_only_reconciled` is a property of these recovery paths, not a
  failure.** For 320 of 1,360 effects (160 of 680 in deny), the flag and
  mode of the decision rest on the capability issuer's signature alone. An
  audit-key plus issuer-key holder could restate that classification
  without new provider status (VERIFIER_CHECKS §1, "Two kinds of
  `issuer_adapter`"). After a restart, the in-memory adapter receipt is
  always lost.
- **Gateway flag changes are not tested here.** No operation is flagged, so
  the build-2 flag-keeping on recovery records and replays is shown only as
  "absent and not required".
- **Timings are not performance results.** Other experiment runners used the
  machine at the same time, and the clock granularity was 1.0 ms.
  - flag: 121 s (build 1: 286 s), median schedule 194 ms (build 1: 220 ms);
  - deny: 150 s (build 1: 140 s), median schedule 223 ms.

## 6. Open issues

- **eval-engine:**
  - The harness's verification record still does not say how many segments
    were verified.
  - `crash.json` still does not record the `call_id` the agent received.
  - **New:** `crash.json` does not record `classification_evidence`. This
    run took it from the CLI cross-check.
- **eval-engine, coverage still missing:**
  - provider faults (DROP_BEFORE_COMMIT, REJECT_BEFORE_COMMIT,
    DROP_AFTER_COMMIT + STATUS_UNKNOWN);
  - a flagged AED 10,000 payment across fault points, which would exercise
    the build-2 flag on recovery records, on reconciling answers and on
    replays, plus `flagged_unconfirmed`;
  - a tight-budget fresh-ID case;
  - a stall past the 30 s lease;
  - restart segments registered with a witness, which would let
    `head_fresh` and `run_complete` pass and test the withheld-segment rule.
- **For `RESULTS_REVISION.md`:**
  - The crash rows can cite build 2 with unchanged numbers.
  - The sentence "nothing listed as missing" for no-restart folders and for
    segment 2 must become "only the freshness gap (and, for 40 + 120
    folders, the issuer-only classification gap)".
  - "160 folders list missing items" must become "160 list unresolved
    operations; every folder lists the freshness gap".

## 7. Files

Flag run (deny run in `deny/`):

| file | what it is | also in `deny/` |
|---|---|---|
| `crash.json`, `crash.csv`, `crash.md` | harness output; `crash.csv` has the new `segment1_missing_kinds` and `segment2_missing_kinds` columns | yes |
| `run.log` | harness stdout | yes |
| `crash.cells.csv`, `crash.cells.json`, `crash.folders.csv` | `cells.py` output | yes |
| `reanalysis.json`, `reanalysis.md` | `reanalyze_from_disk.py` output; the `[n missing]` folder text now counts the freshness entry | yes |
| `call_ids.txt` | `call_ids.py` output | yes |
| `recovery_records.txt` | `recovery_records.py` output | yes |
| `cli_crosscheck.csv`, `cli_crosscheck.summary.json` | `cli_crosscheck.py` output | yes |
| `continuity_probes.csv` | `continuity_probes.py` output | no (flag only) |
| `analysis_console.txt` | console output of the comparison, cross-check and probe scripts | no |
| `build-manifest.txt` | binary hashes, manifest checks before and after, run times and commands, compiled module sources | no |

Scripts:

- `cells.py`
- `reanalyze_from_disk.py`
- `call_ids.py`
- `continuity_probes.py`
- `cli_crosscheck.py`
- `compare_crash_json.py`
- `recovery_records.py`
- `flag_vs_deny.py`

The evidence folders (72 MB flag, 36 MB deny) stay outside the repository,
under `<scratch>/build2-work/crash/`.
