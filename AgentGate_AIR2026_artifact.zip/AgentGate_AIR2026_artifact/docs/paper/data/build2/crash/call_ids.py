#!/usr/bin/env python3
"""Call IDs, call scope and dispatch-lease expiry in a crash run's evidence.

Reads every audit.jsonl under WORK_DIR (<schedule>/segment-N/audit.jsonl, as
written by `agentgate-eval crash -work WORK_DIR`) and counts:

  * EFFECT_EXECUTED / RECONCILED entries with and without details.call_id, and
    whether each call_id is answered by a later CALL_RESULT of the same
    operation with the same call_id in the same folder;
  * CALL_RESULT entries by details.scope, and the call-scope and replayed ones
    by cell (fault point, retry, restart, segment, status/reason, scope);
  * EFFECT_FAILED entries by outcome and details.lease_expired;
  * operations whose one provider effect is recorded by more than one entry
    (EFFECT_EXECUTED or RECONCILED committed), with where each entry lies.

Usage: python call_ids.py WORK_DIR
Python 3 standard library only. Reads the files only; the signatures are
checked by the verifier, not here.
"""
import collections
import json
import os
import re
import sys

LABEL = re.compile(r"crash-(.*)-(same-id|fresh-id)-(none|journal)-r\d+$")


def main():
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    root = sys.argv[1]
    totals = collections.Counter()
    tie = collections.Counter()
    replays = collections.Counter()
    double = collections.Counter()
    for schedule in sorted(os.listdir(root)):
        match = LABEL.match(schedule)
        if not match:
            continue
        point, retry, restart = match.groups()
        evidence = collections.defaultdict(list)
        for segment in sorted(os.listdir(os.path.join(root, schedule))):
            path = os.path.join(root, schedule, segment, "audit.jsonl")
            if not os.path.isfile(path):
                continue
            with open(path, encoding="utf-8") as handle:
                entries = [json.loads(line)["entry"] for line in handle if line.strip()]
            answers = collections.defaultdict(list)
            for entry in entries:
                details = entry.get("details") or {}
                if entry["stage"] == "CALL_RESULT":
                    answers[details.get("call_id")].append(entry)
                    totals["CALL_RESULT scope=%s call_id=%s" % (details.get("scope"), "yes" if details.get("call_id") else "no")] += 1
                    if details.get("scope") == "call" or details.get("replayed"):
                        replays[(point, retry, restart, segment, "%s/%s" % (details.get("status"), details.get("reason") or ""),
                                 "scope=%s" % details.get("scope"), "replayed=%s" % details.get("replayed"))] += 1
            for entry in entries:
                details = entry.get("details") or {}
                stage = entry["stage"]
                if stage in ("EFFECT_EXECUTED", "RECONCILED"):
                    call_id = details.get("call_id")
                    totals["%s outcome=%s call_id=%s" % (stage, entry.get("outcome"), "yes" if call_id else "no")] += 1
                    if call_id:
                        tied = any(answer.get("operation_id") == entry.get("operation_id") and answer["seq"] > entry["seq"]
                                   for answer in answers.get(call_id, []))
                        tie["%s with call_id answered by a later CALL_RESULT of the same operation and call: %s" % (stage, tied)] += 1
                    if stage == "EFFECT_EXECUTED" or entry.get("outcome") == "committed":
                        evidence[entry.get("operation_id")].append(
                            "%s %s (%s)" % (segment, stage, "call_id" if call_id else "no call_id"))
                if stage == "EFFECT_FAILED":
                    totals["EFFECT_FAILED outcome=%s lease_expired=%s" % (entry.get("outcome"), bool(details.get("lease_expired")))] += 1
        for records in evidence.values():
            if len(records) > 1:
                double[(point, retry, restart, " + ".join(records))] += 1
    print("# totals")
    for key, value in sorted(totals.items()):
        print("%6d  %s" % (value, key))
    for key, value in sorted(tie.items()):
        print("%6d  %s" % (value, key))
    print("# CALL_RESULT with scope=call or replayed=true, by cell")
    for key, value in sorted(replays.items()):
        print("%6d  %s" % (value, " ".join(key)))
    print("# operations whose provider effect is recorded by more than one entry")
    for key, value in sorted(double.items()):
        print("%6d  %s" % (value, " ".join(key)))


if __name__ == "__main__":
    main()
