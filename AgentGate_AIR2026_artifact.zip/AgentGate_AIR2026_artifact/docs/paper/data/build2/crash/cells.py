#!/usr/bin/env python3
"""Per-cell aggregation of an `agentgate-eval crash` result (crash.json).

One row per fault point x retry x restart x effect (the operations of a
cell are its repetitions), and one row per fault point x retry x restart for
the evidence folders. Every count carries its denominator (n). A cell is
"stable" when every repetition produced the same outcome signature
(answers, effects, states, folder verdicts with their failing checks and
missing counts).

Build-2 copy: the only change from the build-1 script is that a folder's
Missing entries are shown with their kinds ("[3 missing: unresolved=2
freshness=1]"), because the build-2 verifier tags each entry with a kind and
lists a freshness entry for every folder verified with a pinned head.

Usage: python cells.py CRASH_JSON [OUT_PREFIX]
Writes OUT_PREFIX.cells.csv, OUT_PREFIX.folders.csv and OUT_PREFIX.cells.json
(default prefix: crash next to CRASH_JSON). Python 3 standard library only.
"""
import collections
import csv
import json
import os
import sys


def status(call):
    text = call.get("status", "") or "ERROR"
    if call.get("reason"):
        text += "/" + call["reason"]
    return text


def counter_text(counter):
    return "; ".join("%s x%d" % (key, value) for key, value in sorted(counter.items()))


def folder_text(segment):
    text = "%s/%s" % (segment.get("verdict", ""), segment.get("assurance", ""))
    if segment.get("failing_checks"):
        text += "(" + ",".join(segment["failing_checks"]) + ")"
    if segment.get("missing"):
        # build 2: the verifier tags each Missing entry with a kind; show them
        kinds = segment.get("missing_by_kind") or {}
        named = " ".join("%s=%d" % (k, kinds[k]) for k in ("unresolved", "freshness", "issuer_only", "other") if kinds.get(k))
        text += "[%d missing%s]" % (len(segment["missing"]), ": " + named if named else "")
    if segment.get("error"):
        text += "{error}"
    return text


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    path = sys.argv[1]
    prefix = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(os.path.abspath(path)), "crash")
    with open(path, encoding="utf-8") as handle:
        result = json.load(handle)

    cells = collections.OrderedDict()
    folders = collections.OrderedDict()
    for schedule in result["schedules"]:
        skey = (schedule["fault_point"], schedule["retry"], schedule["restart"])
        fagg = folders.setdefault(skey, {"schedules": 0, "errors": 0, "segments": collections.Counter(),
                                         "per_segment": collections.defaultdict(collections.Counter),
                                         "dimension_fail": collections.Counter(), "signatures": collections.Counter()})
        fagg["schedules"] += 1
        fagg["errors"] += bool(schedule.get("error"))
        fagg["segments"][len(schedule["evidence_segments"])] += 1
        for index, segment in enumerate(schedule["evidence_segments"]):
            fagg["per_segment"][index + 1][folder_text(segment)] += 1
            for name, value in (segment.get("dimensions") or {}).items():
                if value != "pass":
                    fagg["dimension_fail"]["seg%d:%s=%s" % (index + 1, name, value)] += 1
        fagg["signatures"][" | ".join(folder_text(s) for s in schedule["evidence_segments"])] += 1
        for cell in schedule["operations"]:
            key = skey + (cell["effect"],)
            agg = cells.setdefault(key, {
                "n": 0, "fault_fired": 0, "first": collections.Counter(), "retry_answer": collections.Counter(),
                "first_dispatched": 0, "effects": collections.Counter(), "dup_per_id": 0, "business_dup": 0,
                "rejected_with_effect": 0, "rejected_answers": 0, "committed_without_effect": 0, "committed_answers": 0,
                "unresolved_after_retry": 0, "unresolved_after_reconcile": 0,
                "state_after_retry": collections.Counter(), "state_after_reconcile": collections.Counter(),
                "evidence_gap": 0, "evidenced_in": collections.Counter(), "signatures": collections.Counter()})
            agg["n"] += 1
            agg["fault_fired"] += cell["fault_fired"]
            first, retry = cell["first_call"], cell["retry_call"]
            agg["first"][status(first)] += 1
            agg["retry_answer"][status(retry)] += 1
            agg["first_dispatched"] += bool(first.get("dispatched"))
            effects = "%d+%d" % (cell["provider_effects_original_id"], cell["provider_effects_fresh_id"])
            agg["effects"][effects] += 1
            agg["dup_per_id"] += cell["duplicate_effect_per_operation_id"]
            agg["business_dup"] += cell["business_duplicate"]
            agg["rejected_with_effect"] += cell["rejected_while_effect_exists"]
            agg["rejected_answers"] += sum(c.get("status") == "REJECTED" for c in (first, retry))
            agg["committed_without_effect"] += cell["committed_without_effect"]
            agg["committed_answers"] += sum(c.get("status") == "COMMITTED" for c in (first, retry))
            agg["unresolved_after_retry"] += cell["unresolved_after_retry"]
            agg["unresolved_after_reconcile"] += cell["unresolved_after_reconcile"]
            agg["state_after_retry"][cell["original_state_after_retry"]] += 1
            agg["state_after_reconcile"][cell["original_state_after_reconcile"]] += 1
            agg["evidence_gap"] += cell["evidence_gap"]
            agg["evidenced_in"][" ".join(cell["effect_evidenced_in"]) or "-"] += 1
            agg["signatures"][json.dumps([status(first), status(retry), effects, cell["original_state_after_retry"],
                                          cell["original_state_after_reconcile"], cell["effect_evidenced_in"],
                                          [folder_text(s) for s in schedule["evidence_segments"]]])] += 1

    cell_rows = []
    for (point, retry, restart, effect), agg in cells.items():
        cell_rows.append({
            "fault_point": point, "retry": retry, "restart": restart, "effect": effect, "n": agg["n"],
            "fault_fired": agg["fault_fired"], "first_answer": counter_text(agg["first"]),
            "first_dispatched": agg["first_dispatched"], "retry_answer": counter_text(agg["retry_answer"]),
            "effects_original+fresh": counter_text(agg["effects"]), "duplicate_per_operation_id": agg["dup_per_id"],
            "business_duplicate": agg["business_dup"], "rejected_answers": agg["rejected_answers"],
            "rejected_while_effect_exists": agg["rejected_with_effect"], "committed_answers": agg["committed_answers"],
            "committed_without_effect": agg["committed_without_effect"],
            "unresolved_after_retry": agg["unresolved_after_retry"], "unresolved_after_reconcile": agg["unresolved_after_reconcile"],
            "state_after_retry": counter_text(agg["state_after_retry"]), "state_after_reconcile": counter_text(agg["state_after_reconcile"]),
            "evidence_gap": agg["evidence_gap"], "effect_evidenced_in": counter_text(agg["evidenced_in"]),
            "distinct_outcome_signatures": len(agg["signatures"]), "stable": len(agg["signatures"]) == 1,
        })
    folder_rows = []
    for (point, retry, restart), agg in folders.items():
        folder_rows.append({
            "fault_point": point, "retry": retry, "restart": restart, "schedules": agg["schedules"], "errors": agg["errors"],
            "segments": counter_text(agg["segments"]),
            "segment1": counter_text(agg["per_segment"].get(1, collections.Counter())),
            "segment2_chain": counter_text(agg["per_segment"].get(2, collections.Counter())),
            "dimensions_not_pass": counter_text(agg["dimension_fail"]) or "-",
            "distinct_folder_signatures": len(agg["signatures"]),
        })
    for name, rows in (("cells", cell_rows), ("folders", folder_rows)):
        with open(prefix + "." + name + ".csv", "w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
    with open(prefix + ".cells.json", "w", encoding="utf-8") as handle:
        json.dump({"source": os.path.basename(path), "escalation": result.get("escalation"),
                   "environment": result.get("environment"), "cells": cell_rows, "folders": folder_rows}, handle, indent=1)
    unstable = [row for row in cell_rows if not row["stable"]]
    print("cells: %d, unstable: %d; folder groups: %d" % (len(cell_rows), len(unstable), len(folder_rows)))
    for row in unstable:
        print("UNSTABLE", row["fault_point"], row["retry"], row["restart"], row["effect"], row["distinct_outcome_signatures"])


if __name__ == "__main__":
    main()
