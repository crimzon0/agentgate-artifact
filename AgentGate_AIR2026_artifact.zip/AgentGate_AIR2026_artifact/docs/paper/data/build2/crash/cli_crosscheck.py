#!/usr/bin/env python3
"""Re-verify every evidence folder of a crash run with the standalone CLI.

Build-2 copy of the build-1 (2026-10-08) script. Changes, all caused by the
build-2 verifier (VERIFIER_CHECKS.md section 1, "missing_kinds"):

  * The verifier now tags every Missing entry with a kind (unresolved,
    freshness, issuer_only, other) and adds a "freshness" entry for every
    folder whose head anchor holds but is not shown to be fresh (a pinned
    head is never fresh). The harness verifies with keys and head pinned, so
    every harness folder lists one freshness entry. The "none" pass has no
    head anchor, so it gets no freshness entry; it gets the two anchor items
    ("No keys anchor", "No head anchor", kind other) instead. Build 1 expected
    "harness count + 2"; build 2 expects, kind by kind,
        none:   harness kinds with freshness removed and other + 2
        pinned: exactly the harness kinds
    (so the total for "none" is harness count - 1 + 2 when the harness lists
    the freshness gap).
  * Also compared: all nine dimensions of the pinned pass (seven check-based
    plus the derived head_fresh and run_complete) against the harness's.
  * Also recorded per run: the CLI's head_fresh / run_complete,
    counts.classification_evidence, counts.flagged, counts.flagged_unconfirmed
    and each operation's status:classification_evidence.

For every folder the harness verified in process (crash.json ->
schedules[].evidence_segments[]), run `agentgate-verify --json` in a separate
process twice:

  * "none": no anchors (expected VERIFIED/CONSISTENT);
  * "pinned": --expect-keys = SHA-256 of the folder's keys.json and
    --expect-head = entry_hash of the folder's head.json. These pins are read
    from the folder after the run, so they are only as good as the folder:
    on untouched evidence they equal what the harness pinned in memory, and
    this pass reproduces the in-process verification in another process.

Compared with the harness: verdict, assurance, failing check IDs, Missing
entries by kind (rule above), dimensions (pinned pass), and for a
continuation segment the number of segments the CLI walked and that its entry
count equals the sum of the segments' own entries.

Usage: python cli_crosscheck.py VERIFY_EXE CRASH_JSON WORK_DIR OUT_CSV [WORKERS]
Writes OUT_CSV and OUT_CSV with .csv replaced by .summary.json.
Python 3 standard library only.
"""
import collections
import concurrent.futures
import csv
import hashlib
import json
import os
import subprocess
import sys

KINDS = ["unresolved", "freshness", "issuer_only", "other"]


def kinds_text(counts):
    return " ".join("%s=%d" % (k, counts.get(k, 0)) for k in KINDS if counts.get(k, 0))


def run_cli(exe, folder, pins):
    args = [exe, "--json", "--workers", "1"]
    if pins:
        with open(os.path.join(folder, "keys.json"), "rb") as handle:
            keys = hashlib.sha256(handle.read()).hexdigest()
        with open(os.path.join(folder, "head.json"), encoding="utf-8") as handle:
            head = json.load(handle)["entry_hash"]
        args += ["--expect-keys", keys, "--expect-head", head]
    args.append(folder)
    proc = subprocess.run(args, capture_output=True, text=True, encoding="utf-8")
    try:
        report = json.loads(proc.stdout)
    except ValueError:
        return {"exit": proc.returncode, "error": (proc.stderr or proc.stdout)[:300]}
    failing = sorted({item.get("id", "") for item in report.get("failures") or []})
    segments = report.get("segments") or []
    counts = report.get("counts") or {}
    kinds = collections.Counter(report.get("missing_kinds") or [])
    return {
        "exit": proc.returncode, "verdict": report.get("verdict"), "assurance": report.get("assurance"),
        "failing": failing, "missing": len(report.get("missing") or []), "missing_kinds": dict(kinds),
        "kinds_len_ok": len(report.get("missing_kinds") or []) == len(report.get("missing") or []),
        "segments": len(segments), "segment_entries": [s.get("entries") for s in segments],
        "entries": counts.get("entries"),
        "dimensions": {name: value.get("status") for name, value in (report.get("dimensions") or {}).items()},
        "classification": dict(counts.get("classification_evidence") or {}),
        "flagged": counts.get("flagged", 0), "flagged_unconfirmed": counts.get("flagged_unconfirmed", 0),
        "op_classes": sorted("%s:%s" % (op.get("status"), op.get("classification_evidence"))
                             for op in report.get("operations") or []),
        "reconciled_ops": sum(bool(op.get("reconciled")) for op in report.get("operations") or []),
    }


def expected_kinds(harness_kinds, anchors):
    out = {k: harness_kinds.get(k, 0) for k in KINDS}
    if anchors == "none":
        out["freshness"] = 0
        out["other"] += 2
    return out


def main():
    if len(sys.argv) < 5:
        sys.exit(__doc__)
    exe, crash_json, work, out_csv = sys.argv[1:5]
    workers = int(sys.argv[5]) if len(sys.argv) > 5 else 6
    with open(crash_json, encoding="utf-8") as handle:
        result = json.load(handle)
    jobs = []
    for schedule in result["schedules"]:
        for index, segment in enumerate(schedule["evidence_segments"]):
            folder = segment["folder"].replace("<work>", work)
            for anchors in ("none", "pinned"):
                jobs.append((schedule, index, segment, folder, anchors))
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        outcomes = list(pool.map(lambda job: run_cli(exe, job[3], job[4] == "pinned"), jobs))
    rows = []
    agree = {"none": [0, 0], "pinned": [0, 0]}
    for (schedule, index, segment, folder, anchors), cli in zip(jobs, outcomes):
        harness_failing = sorted(segment.get("failing_checks") or [])
        harness_missing = len(segment.get("missing") or [])
        harness_kinds = {k: v for k, v in (segment.get("missing_by_kind") or {}).items()}
        want_kinds = expected_kinds(harness_kinds, anchors)
        got_kinds = {k: (cli.get("missing_kinds") or {}).get(k, 0) for k in KINDS}
        is_continuation = index > 0
        harness_dims = segment.get("dimensions") or {}
        checks = {
            "verdict": cli.get("verdict") == segment.get("verdict"),
            "assurance": (cli.get("assurance") == segment.get("assurance")) if anchors == "pinned"
            else (cli.get("assurance") == ("CONSISTENT" if segment.get("verdict") == "VERIFIED" else "FAILED")),
            "failing": cli.get("failing") == harness_failing,
            "harness_kinds_sum": sum(harness_kinds.values()) == harness_missing,
            "missing_kinds": got_kinds == want_kinds and bool(cli.get("kinds_len_ok")),
            "missing": cli.get("missing") == sum(want_kinds.values()),
            "dimensions": (anchors != "pinned") or (cli.get("dimensions") == harness_dims),
            "segments": cli.get("segments") == (index + 1 if is_continuation else 0) or (not is_continuation and cli.get("segments") in (0, 1)),
            "entries_sum": (not is_continuation) or (cli.get("entries") == sum(cli.get("segment_entries") or [-1])),
            "harness_entries": (not is_continuation) or cli.get("entries") == segment.get("entries"),
        }
        ok = all(checks.values()) and "error" not in cli
        agree[anchors][0] += ok
        agree[anchors][1] += 1
        dims = cli.get("dimensions") or {}
        rows.append({
            "escalation": result.get("escalation"), "label": schedule["label"], "fault_point": schedule["fault_point"],
            "retry": schedule["retry"], "restart": schedule["restart"], "repeat": schedule["repeat"],
            "segment": index + 1, "verified_as": "chain of %d segments" % (index + 1) if is_continuation else "single folder",
            "anchors": anchors, "harness_verdict": segment.get("verdict"), "harness_assurance": segment.get("assurance"),
            "harness_failing": " ".join(harness_failing), "harness_missing": harness_missing,
            "harness_missing_kinds": kinds_text(harness_kinds),
            "cli_exit": cli.get("exit"), "cli_verdict": cli.get("verdict"), "cli_assurance": cli.get("assurance"),
            "cli_failing": " ".join(cli.get("failing") or []), "cli_missing": cli.get("missing"),
            "cli_missing_kinds": kinds_text(got_kinds), "expected_missing_kinds": kinds_text(want_kinds),
            "cli_segments": cli.get("segments"), "cli_segment_entries": " ".join(str(e) for e in cli.get("segment_entries") or []),
            "cli_entries": cli.get("entries"),
            "cli_dimensions_not_pass": " ".join("%s=%s" % (k, v) for k, v in sorted(dims.items()) if v != "pass"),
            "cli_head_fresh": dims.get("head_fresh"), "cli_run_complete": dims.get("run_complete"),
            "cli_classification": " ".join("%s=%d" % (k, v) for k, v in sorted((cli.get("classification") or {}).items())),
            "cli_operation_classes": " ".join(cli.get("op_classes") or []),
            "cli_flagged": cli.get("flagged"), "cli_flagged_unconfirmed": cli.get("flagged_unconfirmed"),
            "agrees": ok, "disagreement": " ".join(name for name, value in checks.items() if not value) + (" error:" + cli["error"] if "error" in cli else ""),
        })
    with open(out_csv, "w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    summary = collections.OrderedDict()
    for anchors, (ok, total) in agree.items():
        print("%s: %d / %d CLI runs agree with the harness" % (anchors, ok, total))
        summary["agree_" + anchors] = [ok, total]
    by = collections.Counter()
    for row in rows:
        by[(row["restart"], row["segment"], row["anchors"], row["cli_verdict"], row["cli_assurance"], row["cli_missing_kinds"],
            row["cli_segments"])] += 1
    for key in sorted(by, key=str):
        print("restart=%s segment=%s anchors=%s -> %s/%s missing[%s] segments=%s: %d" % (key + (by[key],)))
    # derived dimensions, classification evidence and Missing kinds (pinned pass), by cell
    derived = collections.Counter()
    classes = collections.defaultdict(collections.Counter)
    kinds_by_cell = collections.defaultdict(collections.Counter)
    flagged = collections.Counter()
    for row in rows:
        derived["%s head_fresh=%s run_complete=%s" % (row["anchors"], row["cli_head_fresh"], row["cli_run_complete"])] += 1
        if row["anchors"] != "pinned":
            continue
        cell = "%s %s restart=%s segment=%s" % (row["fault_point"], row["retry"], row["restart"], row["segment"])
        for item in (row["cli_operation_classes"] or "").split():
            classes[cell][item] += 1
        kinds_by_cell[cell][row["cli_missing_kinds"] or "-"] += 1
        flagged["flagged=%s flagged_unconfirmed=%s" % (row["cli_flagged"], row["cli_flagged_unconfirmed"])] += 1
    print("# derived dimensions (all runs)")
    for key, value in sorted(derived.items()):
        print("%6d  %s" % (value, key))
    print("# pinned pass: operations by status:classification_evidence, per cell (a segment-2 chain counts the operations of both segments)")
    for cell in sorted(classes):
        print("  %s: %s | missing kinds: %s" % (cell, ", ".join("%s x%d" % kv for kv in sorted(classes[cell].items())),
                                               ", ".join("%s x%d" % kv for kv in sorted(kinds_by_cell[cell].items()))))
    print("# pinned pass flag counts:", dict(flagged))
    summary["derived_dimensions"] = dict(derived)
    summary["pinned_operation_classes_by_cell"] = {cell: dict(counter) for cell, counter in sorted(classes.items())}
    summary["pinned_missing_kinds_by_cell"] = {cell: dict(counter) for cell, counter in sorted(kinds_by_cell.items())}
    summary["pinned_flag_counts"] = dict(flagged)
    with open(os.path.splitext(out_csv)[0] + ".summary.json", "w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=1)


if __name__ == "__main__":
    main()
