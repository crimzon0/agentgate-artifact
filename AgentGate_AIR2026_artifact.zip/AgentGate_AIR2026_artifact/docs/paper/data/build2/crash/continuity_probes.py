#!/usr/bin/env python3
"""Negative probes on the multi-segment (restart) evidence of a crash run.

The 2026-10-08 verifier follows a continuation segment back to the segment it
continues (run.json and the signed RUN_STARTED "continues" record; check
files.continuity). These probes check that accepting the chain did not open
a hole: for every restart schedule of a crash run, a copy of its two
segments is edited in one way and the newest segment is verified with the
standalone CLI, with no anchors and with segment 2's original keys
fingerprint and final head pinned (taken from the untouched folder).

  control          no edit (must verify)
  seg1_deleted     segment 1's folder removed
  seg1_truncated   segment 1's last audit line removed, head.json left (no key)
  seg1_rolled_back segment 1's last audit line removed and head.json moved to
                   the new last entry; verified with --assume-compromised
                   AUDIT_LOG (SIMULATION of an audit-key holder: head and
                   entry signatures are not checked, everything else is)
  continues_removed "continues" deleted from segment 2's run.json (byte-exact
                   otherwise; the signed RUN_STARTED still names segment 1)
  seg1_spliced     segment 1 replaced by segment 1 of another schedule of the
                   same cell (the next repetition): a genuine, intact folder
                   of a different run

Not probed: an attacker holding the audit keys of BOTH segments who rewrites
segment 2's continuation record, RUN_STARTED and chain coherently (only a
head anchor on segment 2 could catch that, as for a single folder).

Usage: python continuity_probes.py VERIFY_EXE CRASH_JSON WORK_DIR SCRATCH_DIR OUT_CSV [WORKERS]
Python 3 standard library only.
"""
import collections
import concurrent.futures
import csv
import hashlib
import json
import os
import shutil
import subprocess
import sys

PROBES = ["control", "seg1_deleted", "seg1_truncated", "seg1_rolled_back", "continues_removed", "seg1_spliced"]


def pins(folder):
    with open(os.path.join(folder, "keys.json"), "rb") as handle:
        keys = hashlib.sha256(handle.read()).hexdigest()
    with open(os.path.join(folder, "head.json"), encoding="utf-8") as handle:
        head = json.load(handle)["entry_hash"]
    return keys, head


def drop_last_line(folder):
    path = os.path.join(folder, "audit.jsonl")
    with open(path, encoding="utf-8") as handle:
        lines = [line for line in handle.read().split("\n") if line.strip()]
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write("\n".join(lines[:-1]) + "\n")
    return json.loads(lines[-2])


def move_head(folder, last):
    path = os.path.join(folder, "head.json")
    with open(path, encoding="utf-8") as handle:
        head = json.load(handle, object_pairs_hook=collections.OrderedDict)
    head["seq"] = last["entry"]["seq"]
    head["entry_hash"] = last["entry_hash"]
    head["time"] = last["entry"]["time"]
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(head, indent=2) + "\n")


def remove_continues(folder):
    path = os.path.join(folder, "run.json")
    with open(path, "rb") as handle:
        raw = handle.read()
    document = json.loads(raw, object_pairs_hook=collections.OrderedDict)
    exact = (json.dumps(document, indent=2) + "\n").encode() == raw
    document.pop("continues", None)
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(document, indent=2) + "\n")
    return exact


def verify(exe, folder, pin, simulate):
    args = [exe, "--json", "--workers", "1"]
    if pin:
        args += ["--expect-keys", pin[0], "--expect-head", pin[1]]
    if simulate:
        args += ["--assume-compromised", "AUDIT_LOG"]
    args.append(folder)
    proc = subprocess.run(args, capture_output=True, text=True, encoding="utf-8")
    try:
        report = json.loads(proc.stdout)
    except ValueError:
        return {"exit": proc.returncode, "verdict": "", "assurance": "", "failing": [], "error": (proc.stderr or proc.stdout).strip()[:300]}
    return {"exit": proc.returncode, "verdict": report.get("verdict", ""), "assurance": report.get("assurance", ""),
            "failing": sorted({item.get("id", "") for item in report.get("failures") or []}), "error": ""}


def run_probe(exe, scratch, schedule_dir, partner_dir, label, probe):
    target = os.path.join(scratch, label + "--" + probe)
    shutil.rmtree(target, ignore_errors=True)
    os.makedirs(target)
    for name in ("segment-1", "segment-2"):
        shutil.copytree(os.path.join(schedule_dir, name), os.path.join(target, name))
    seg1, seg2 = os.path.join(target, "segment-1"), os.path.join(target, "segment-2")
    pin = pins(os.path.join(schedule_dir, "segment-2"))
    note, simulate = "", False
    if probe == "seg1_deleted":
        shutil.rmtree(seg1)
    elif probe == "seg1_truncated":
        drop_last_line(seg1)
    elif probe == "seg1_rolled_back":
        move_head(seg1, drop_last_line(seg1))
        simulate = True
    elif probe == "continues_removed":
        note = "byte-exact rewrite" if remove_continues(seg2) else "run.json re-serialised (not byte-exact)"
    elif probe == "seg1_spliced":
        shutil.rmtree(seg1)
        shutil.copytree(os.path.join(partner_dir, "segment-1"), seg1)
    results = {anchors: verify(exe, seg2, pin if anchors == "pinned" else None, simulate) for anchors in ("none", "pinned")}
    shutil.rmtree(target, ignore_errors=True)
    return results, note


def main():
    if len(sys.argv) < 6:
        sys.exit(__doc__)
    exe, crash_json, work, scratch, out_csv = sys.argv[1:6]
    workers = int(sys.argv[6]) if len(sys.argv) > 6 else 6
    with open(crash_json, encoding="utf-8") as handle:
        result = json.load(handle)
    restart = [s for s in result["schedules"] if s["restart"] == "journal" and not s.get("error")]
    by_cell = collections.defaultdict(dict)
    for schedule in restart:
        by_cell[(schedule["fault_point"], schedule["retry"])][schedule["repeat"]] = schedule["label"]
    jobs = []
    for schedule in restart:
        cell = by_cell[(schedule["fault_point"], schedule["retry"])]
        repeats = sorted(cell)
        partner = cell[repeats[(repeats.index(schedule["repeat"]) + 1) % len(repeats)]]
        for probe in PROBES:
            if probe == "seg1_spliced" and partner == schedule["label"]:
                continue  # one repetition only: no other run of the same cell to splice in
            jobs.append((schedule, partner, probe))
    os.makedirs(scratch, exist_ok=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        outcomes = list(pool.map(lambda job: run_probe(exe, scratch, os.path.join(work, job[0]["label"]),
                                                      os.path.join(work, job[1]), job[0]["label"], job[2]), jobs))
    rows = []
    summary = collections.OrderedDict((probe, collections.Counter()) for probe in PROBES)
    failing_by_probe = collections.defaultdict(collections.Counter)
    for (schedule, partner, probe), (results, note) in zip(jobs, outcomes):
        for anchors, outcome in results.items():
            if outcome["verdict"] == "FAILED":
                decision = "detected"
            elif outcome["verdict"] == "VERIFIED":
                decision = "accepted"
            else:
                decision = "error"
            rows.append({
                "label": schedule["label"], "fault_point": schedule["fault_point"], "retry": schedule["retry"],
                "repeat": schedule["repeat"], "probe": probe, "anchors": anchors,
                "simulation": "AUDIT_LOG" if probe == "seg1_rolled_back" else "",
                "partner": partner if probe == "seg1_spliced" else "",
                "exit": outcome["exit"], "verdict": outcome["verdict"], "assurance": outcome["assurance"],
                "failing_checks": " ".join(outcome["failing"]), "files_continuity_failed": "files.continuity" in outcome["failing"],
                "decision": decision, "error": outcome["error"], "note": note,
            })
            summary[probe]["%s:%s" % (anchors, decision)] += 1
            summary[probe]["%s:continuity" % anchors] += "files.continuity" in outcome["failing"]
            failing_by_probe[(probe, anchors)][" ".join(outcome["failing"]) or "(none)"] += 1
    with open(out_csv, "w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print("restart schedules probed: %d" % len(restart))
    for probe, counter in summary.items():
        print(probe, dict(counter))
    for (probe, anchors), counter in failing_by_probe.items():
        for failing, count in counter.most_common():
            print("  %s/%s: %d x [%s]" % (probe, anchors, count, failing))
    notes = collections.Counter(row["note"] for row in rows if row["probe"] == "continues_removed")
    print("continues_removed rewrite:", dict(notes))


if __name__ == "__main__":
    main()
