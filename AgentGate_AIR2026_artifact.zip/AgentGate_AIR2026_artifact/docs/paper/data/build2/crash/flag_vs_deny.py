#!/usr/bin/env python3
"""Compare the flag run's per-cell results with the deny run's (new script in build 2).

Build 1 reported "flag and deny results are identical (0 of 336 compared cell
fields differ)" without keeping the script; this re-creates that comparison:
56 cells (fault point x retry x restart x effect) x 6 outcome fields
(first_answer, retry_answer, effects_original+fresh, state_after_retry,
state_after_reconcile, effect_evidenced_in) of crash.cells.csv, with the
repetition counts ("x20" / "x10") reduced to the share of the cell's n. It also
compares the per-cell 0/1 safety counts as shares, and crash.folders.csv
(segment1, segment2_chain, dimensions_not_pass) the same way.

Usage: python flag_vs_deny.py FLAG_DIR DENY_DIR
Python 3 standard library only.
"""
import csv
import re
import sys

FIELDS = ["first_answer", "retry_answer", "effects_original+fresh", "state_after_retry", "state_after_reconcile", "effect_evidenced_in"]
SHARES = ["duplicate_per_operation_id", "business_duplicate", "rejected_while_effect_exists", "committed_without_effect",
          "unresolved_after_retry", "unresolved_after_reconcile", "evidence_gap", "fault_fired", "first_dispatched"]
FOLDER_FIELDS = ["segment1", "segment2_chain", "dimensions_not_pass", "segments"]


def shares(text, n):
    out = {}
    for part in (text or "").split("; "):
        match = re.match(r"^(.*) x(\d+)$", part)
        if match:
            out[match.group(1)] = int(match.group(2)) / n
        elif part:
            out[part] = None
    return out


def rows(path, key):
    with open(path, encoding="utf-8", newline="") as handle:
        return {tuple(r[k] for k in key): r for r in csv.DictReader(handle)}


def main():
    flag, deny = sys.argv[1], sys.argv[2]
    key = ["fault_point", "retry", "restart", "effect"]
    a, b = rows(flag + "/crash.cells.csv", key), rows(deny + "/crash.cells.csv", key)
    compared = differ = 0
    for cell in a:
        x, y = a[cell], b.get(cell)
        for field in FIELDS:
            compared += 1
            if y is None or shares(x[field], int(x["n"])) != shares(y[field], int(y["n"])):
                differ += 1
                print("DIFF", cell, field, x[field], "|", y and y[field])
    print("cells: flag %d, deny %d; outcome fields compared: %d, differ: %d" % (len(a), len(b), compared, differ))
    sdiff = 0
    for cell in a:
        x, y = a[cell], b[cell]
        for field in SHARES:
            if int(x[field]) / int(x["n"]) != int(y[field]) / int(y["n"]):
                sdiff += 1
                print("DIFF share", cell, field, x[field], y[field])
    print("safety/fault counts compared as shares: %d, differ: %d" % (len(a) * len(SHARES), sdiff))
    fkey = ["fault_point", "retry", "restart"]
    fa, fb = rows(flag + "/crash.folders.csv", fkey), rows(deny + "/crash.folders.csv", fkey)
    fdiff = 0
    for group in fa:
        x, y = fa[group], fb[group]
        for field in FOLDER_FIELDS:
            if shares(x[field], int(x["schedules"])) != shares(y[field], int(y["schedules"])):
                fdiff += 1
                print("DIFF folders", group, field, x[field], "|", y[field])
    print("folder groups: %d; folder fields compared: %d, differ: %d" % (len(fa), len(fa) * len(FOLDER_FIELDS), fdiff))


if __name__ == "__main__":
    main()
