#!/usr/bin/env python3
"""Independent re-analysis of the crash experiment from the files on disk.

agentgate-eval crash computes its counts from in-memory state (the agent's
answers, the provider runtime's snapshot, the events its audit sink received).
This script recomputes the safety counts from what was written to disk only:

  * provider effects: the signed receipts in the provider-journal.json of the
    schedule's last evidence folder (decoded with a minimal CBOR reader; the
    signatures themselves are checked by the verifier, not here);
  * evidence: EFFECT_EXECUTED / RECONCILED(committed) / CALL_RESULT entries in
    every evidence folder's audit.jsonl;
  * agent answers: crash.json (first_call / retry_call), compared with the
    CALL_RESULT status the gateway logged for the same call.

It then aggregates per cell (fault point x retry x restart x effect) and
writes reanalysis.json and reanalysis.md next to crash.json.

Usage: python reanalyze_from_disk.py CRASH_JSON WORK_DIR [OUT_DIR]
Python 3 standard library only.
"""
import base64
import collections
import json
import os
import sys


# --- minimal CBOR (RFC 8949) reader: enough for COSE_Sign1 receipts ---------

def _cbor(data, i):
    head = data[i]
    major, info = head >> 5, head & 0x1F
    i += 1
    if info < 24:
        arg = info
    elif info in (24, 25, 26, 27):
        size = 1 << (info - 24)
        arg = int.from_bytes(data[i:i + size], "big")
        i += size
    else:
        raise ValueError("indefinite or reserved CBOR length")
    if major == 0:
        return arg, i
    if major == 1:
        return -1 - arg, i
    if major == 2:
        return bytes(data[i:i + arg]), i + arg
    if major == 3:
        return data[i:i + arg].decode("utf-8"), i + arg
    if major == 4:
        out = []
        for _ in range(arg):
            value, i = _cbor(data, i)
            out.append(value)
        return out, i
    if major == 5:
        out = {}
        for _ in range(arg):
            key, i = _cbor(data, i)
            value, i = _cbor(data, i)
            out[key] = value
        return out, i
    if major == 6:
        value, i = _cbor(data, i)
        return ("tag", arg, value), i
    if major == 7:
        return {20: False, 21: True, 22: None}.get(info, ("simple", info)), i
    raise ValueError("bad CBOR major type")


def cbor_decode(data):
    value, end = _cbor(data, 0)
    if end != len(data):
        raise ValueError("trailing bytes after CBOR item")
    return value


def receipt_payload(signed_b64):
    item = cbor_decode(base64.b64decode(signed_b64))
    if isinstance(item, tuple) and item[0] == "tag":
        item = item[2]
    if not (isinstance(item, list) and len(item) == 4):
        raise ValueError("not a COSE_Sign1 array")
    return cbor_decode(item[2])


def op_text(raw):
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


# --- per schedule -------------------------------------------------------------

def read_audit(path):
    entries = []
    with open(path, encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                entries.append(json.loads(line)["entry"])
    return entries


def provider_commits(path):
    with open(path, encoding="utf-8") as handle:
        journal = json.load(handle)
    per_op = collections.Counter()
    outcomes = collections.Counter()
    for entry in journal.get("entries", []):
        payload = receipt_payload(entry["signed_receipt"])
        per_op[op_text(payload["operation_id"])] += 1
        outcomes[payload.get("outcome")] += 1
    return per_op, outcomes, len(journal.get("entries", []))


def analyse(crash_json, work_dir):
    with open(crash_json, encoding="utf-8") as handle:
        result = json.load(handle)
    rows = []
    for schedule in result["schedules"]:
        if schedule.get("error"):
            rows.append({"label": schedule["label"], "error": schedule["error"]})
            continue
        folders = [seg["folder"].replace("<work>", work_dir) for seg in schedule["evidence_segments"]]
        audits = [read_audit(os.path.join(folder, "audit.jsonl")) for folder in folders]
        per_op, outcomes, total = provider_commits(os.path.join(folders[-1], "provider-journal.json"))
        for cell in schedule["operations"]:
            original, fresh = cell["operation_id"], cell.get("fresh_operation_id", "")
            ids = [original] + ([fresh] if fresh else [])
            retried = fresh or original
            # what the gateway logged for this operation, in folder order
            logged_statuses = []
            evidenced = {op: [] for op in ids}
            per_folder_orphan = []  # provider effect present when the folder closed, no trail in that folder
            for index, entries in enumerate(audits):
                for entry in entries:
                    op = entry["operation_id"]
                    if op not in ids:
                        continue
                    if entry["stage"] == "CALL_RESULT":
                        logged_statuses.append((op, entry["details"].get("status")))
                    if entry["stage"] == "EFFECT_EXECUTED" or (entry["stage"] == "RECONCILED" and entry["outcome"] == "committed"):
                        evidenced[op].append(index + 1)
            for index, folder in enumerate(folders):
                folder_ops, _, _ = provider_commits(os.path.join(folder, "provider-journal.json"))
                for op in ids:
                    if folder_ops.get(op, 0) > 0 and (index + 1) not in evidenced[op]:
                        per_folder_orphan.append("segment-%d%s" % (index + 1, "(fresh)" if op == fresh else ""))
            first, retry = cell["first_call"], cell["retry_call"]
            answers = [(original, first.get("status", "")), (retried, retry.get("status", ""))]
            rejected_with_effect = any(status == "REJECTED" and per_op.get(op, 0) > 0 for op, status in answers)
            committed_without = any(status == "COMMITTED" and per_op.get(op, 0) == 0 for op, status in answers)
            # does every agent answer appear as a logged CALL_RESULT with the same status (in order)?
            agent_seq = [(op, status) for op, status in answers]
            log_matches = logged_statuses[:2] == agent_seq if len(logged_statuses) >= 2 else False
            gap = any(per_op.get(op, 0) > 0 and not evidenced[op] for op in ids)
            rows.append({
                "label": schedule["label"], "point": cell["fault_point"], "retry": cell["retry"],
                "restart": cell["restart"], "effect": cell["effect"], "repeat": cell["repeat"],
                "fault_fired": cell["fault_fired"],
                "first": first.get("status", "") + ("/" + first["reason"] if first.get("reason") else ""),
                "retry_answer": retry.get("status", "") + ("/" + retry["reason"] if retry.get("reason") else ""),
                "first_dispatched": first.get("dispatched"), "retry_dispatched": retry.get("dispatched"),
                "effects_original": per_op.get(original, 0), "effects_fresh": per_op.get(fresh, 0) if fresh else 0,
                "duplicate_per_id": any(per_op.get(op, 0) > 1 for op in ids),
                "business_duplicate": sum(per_op.get(op, 0) for op in ids) > 1,
                "rejected_with_effect": rejected_with_effect,
                "committed_without_effect": committed_without,
                "evidence_gap_all_folders": gap,
                "orphan_in_folder": per_folder_orphan,
                "logged_call_results": ["%s:%s" % ("fresh" if op == fresh else "orig", s) for op, s in logged_statuses],
                "agent_answers_match_log": log_matches,
                "state_after_retry": cell["original_state_after_retry"],
                "state_after_reconcile": cell["original_state_after_reconcile"],
                "folders": [{"verdict": seg["verdict"], "assurance": seg["assurance"], "failing": seg["failing_checks"],
                             "missing": len(seg["missing"])} for seg in schedule["evidence_segments"]],
                "harness": {  # the eval's own per-cell flags, for the cross-check
                    "duplicate_per_id": cell["duplicate_effect_per_operation_id"],
                    "rejected_with_effect": cell["rejected_while_effect_exists"],
                    "committed_without_effect": cell["committed_without_effect"],
                    "evidence_gap": cell["evidence_gap"],
                    "effects_original": cell["provider_effects_original_id"],
                    "effects_fresh": cell["provider_effects_fresh_id"],
                },
                "provider_receipt_outcomes": dict(outcomes),
            })
    return result, rows


def aggregate(rows):
    cells = collections.OrderedDict()
    for row in rows:
        if "error" in row:
            continue
        key = (row["point"], row["retry"], row["restart"], row["effect"])
        agg = cells.setdefault(key, {
            "n": 0, "fault_fired": 0, "first_answer": collections.Counter(), "retry_answer": collections.Counter(),
            "effects": collections.Counter(), "duplicate_per_id": 0, "business_duplicate": 0,
            "rejected_with_effect": 0, "committed_without_effect": 0, "evidence_gap": 0,
            "orphan_folders": collections.Counter(), "answers_match_log": 0,
            "unresolved_after_retry": 0, "unresolved_after_reconcile": 0,
            "after_retry": collections.Counter(), "after_reconcile": collections.Counter(),
            "folders": collections.Counter(), "harness_disagrees": 0})
        agg["n"] += 1
        agg["fault_fired"] += row["fault_fired"]
        agg["first_answer"][row["first"]] += 1
        agg["retry_answer"][row["retry_answer"]] += 1
        agg["effects"]["%d+%d" % (row["effects_original"], row["effects_fresh"])] += 1
        for name in ("duplicate_per_id", "business_duplicate", "rejected_with_effect", "committed_without_effect"):
            agg[name] += row[name]
        agg["evidence_gap"] += row["evidence_gap_all_folders"]
        for folder in row["orphan_in_folder"]:
            agg["orphan_folders"][folder] += 1
        agg["answers_match_log"] += row["agent_answers_match_log"]
        unresolved = ("UNCERTAIN", "RECONCILIATION_REQUIRED")
        agg["unresolved_after_retry"] += row["state_after_retry"].split("/")[0] in unresolved
        agg["unresolved_after_reconcile"] += row["state_after_reconcile"].split("/")[0] in unresolved
        agg["after_retry"][row["state_after_retry"]] += 1
        agg["after_reconcile"][row["state_after_reconcile"]] += 1
        agg["folders"][" ; ".join("%s%s%s" % (f["assurance"], "(" + ",".join(f["failing"]) + ")" if f["failing"] else "",
                                               "[%d missing]" % f["missing"] if f["missing"] else "") for f in row["folders"])] += 1
        h = row["harness"]
        agg["harness_disagrees"] += (h["duplicate_per_id"] != row["duplicate_per_id"] or h["rejected_with_effect"] != row["rejected_with_effect"]
                                     or h["committed_without_effect"] != row["committed_without_effect"]
                                     or h["evidence_gap"] != row["evidence_gap_all_folders"]
                                     or h["effects_original"] != row["effects_original"] or h["effects_fresh"] != row["effects_fresh"])
    return cells


def counter_text(counter):
    return ", ".join("%s x%d" % (key, value) for key, value in sorted(counter.items()))


def markdown(cells, totals):
    lines = ["# Crash experiment: re-analysis from the files on disk", "",
             "Generated by `reanalyze_from_disk.py` from crash.json and the evidence folders. Every count is out of the n operations of its row.", "",
             "## Totals", "", "| measure | count |", "|---|---|"]
    for key, value in totals.items():
        lines.append("| %s | %s |" % (key, value))
    lines += ["", "## Per cell", "",
              "| fault point | retry | restart | effect | n | fault fired | first answer | retry answer | effects orig+fresh | dup per ID | REJECTED w/ effect | COMMITTED w/o effect | gap (all folders) | effect without trail in a folder | answers = log | unresolved after retry / after Reconcile | folders (verifier, keys+head pinned) | harness disagrees |",
              "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for (point, retry, restart, effect), agg in cells.items():
        lines.append("| %s | %s | %s | %s | %d | %d | %s | %s | %s | %d | %d | %d | %d | %s | %d | %d / %d | %s | %d |" % (
            point, retry, restart, effect, agg["n"], agg["fault_fired"], counter_text(agg["first_answer"]), counter_text(agg["retry_answer"]),
            counter_text(agg["effects"]), agg["duplicate_per_id"], agg["rejected_with_effect"], agg["committed_without_effect"],
            agg["evidence_gap"], counter_text(agg["orphan_folders"]) or "-", agg["answers_match_log"],
            agg["unresolved_after_retry"], agg["unresolved_after_reconcile"], counter_text(agg["folders"]), agg["harness_disagrees"]))
    return "\n".join(lines) + "\n"


def main():
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    crash_json, work_dir = sys.argv[1], sys.argv[2]
    out_dir = sys.argv[3] if len(sys.argv) > 3 else os.path.dirname(os.path.abspath(crash_json))
    result, rows = analyse(crash_json, work_dir)
    cells = aggregate(rows)
    ok_rows = [row for row in rows if "error" not in row]
    totals = collections.OrderedDict([
        ("schedules", len(result["schedules"])),
        ("schedule errors", len(rows) - len(ok_rows)),
        ("operations", len(ok_rows)),
        ("armed faults that fired (operations with a fault point other than none)",
         "%d / %d" % (sum(r["fault_fired"] for r in ok_rows if r["point"] != "none"), sum(1 for r in ok_rows if r["point"] != "none"))),
        ("more than one provider effect for one operation ID", sum(r["duplicate_per_id"] for r in ok_rows)),
        ("identical content committed twice (fresh-ID retry)", sum(r["business_duplicate"] for r in ok_rows)),
        ("REJECTED answered while the provider journal holds an effect for that ID", sum(r["rejected_with_effect"] for r in ok_rows)),
        ("COMMITTED answered while the provider journal holds no effect for that ID", sum(r["committed_without_effect"] for r in ok_rows)),
        ("provider effect with no EFFECT_EXECUTED / RECONCILED(committed) in any folder", sum(r["evidence_gap_all_folders"] for r in ok_rows)),
        ("operations with a provider effect that some single folder's journal shows but whose trail is in another folder",
         sum(1 for r in ok_rows if r["orphan_in_folder"])),
        ("agent answers equal to the logged CALL_RESULT statuses", "%d / %d" % (sum(r["agent_answers_match_log"] for r in ok_rows), len(ok_rows))),
        ("rows where the harness's own flags disagree with this re-analysis", sum(a["harness_disagrees"] for a in cells.values())),
    ])
    serial_cells = []
    for (point, retry, restart, effect), agg in cells.items():
        item = {"fault_point": point, "retry": retry, "restart": restart, "effect": effect}
        for key, value in agg.items():
            item[key] = dict(value) if isinstance(value, collections.Counter) else value
        serial_cells.append(item)
    with open(os.path.join(out_dir, "reanalysis.json"), "w", encoding="utf-8") as handle:
        json.dump({"source": os.path.basename(crash_json), "totals": totals, "cells": serial_cells}, handle, indent=1)
    with open(os.path.join(out_dir, "reanalysis.md"), "w", encoding="utf-8") as handle:
        handle.write(markdown(cells, totals))
    for key, value in totals.items():
        print("%s: %s" % (key, value))


if __name__ == "__main__":
    main()
