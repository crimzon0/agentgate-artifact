#!/usr/bin/env python3
"""Recovery records of a crash run, read from the files on disk (new in build 2).

Build 2 changed what the verifier reads from recovery records: the per-
operation classification evidence (issuer_adapter when an EFFECT_EXECUTED or a
RECONCILED-committed entry carries the adapter's effect receipt,
issuer_only_reconciled when only a RECONCILED-committed entry without one
records the effect), the check of a receipt attached to RECONCILED
(op.receipts_bound) and the flag stated on recovery records and replayed
answers (op.requires_policy). This script counts, from every audit.jsonl under
WORK_DIR (<schedule>/segment-N/audit.jsonl), independently of the verifier:

  * RECONCILED entries by outcome and by the artifacts they carry
    (effect_receipt = the adapter's receipt, provider_receipt = only the
    provider's), by cell (fault point, retry, restart, segment);
  * per operation, the strongest receipt path over all segments of its
    schedule: "EFFECT_EXECUTED" (an EFFECT_EXECUTED entry exists),
    "RECONCILED+effect_receipt", "RECONCILED provider_receipt only",
    or "no committed record" -- the disk-side counterpart of
    issuer_adapter / issuer_adapter / issuer_only_reconciled / other;
  * details.flagged on RECONCILED and CALL_RESULT entries (no operation in this
    experiment is flagged, so every value should be false or absent).

Usage: python recovery_records.py WORK_DIR
Python 3 standard library only. Reads the files only; signatures and the
binding of a receipt are checked by the verifier, not here.
"""
import collections
import json
import os
import re
import sys

LABEL = re.compile(r"crash-(.*)-(same-id|fresh-id)-(none|journal)-r\d+$")


def main():
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    root = sys.argv[1]
    reconciled = collections.Counter()
    paths = collections.Counter()
    flags = collections.Counter()
    for schedule in sorted(os.listdir(root)):
        match = LABEL.match(schedule)
        if not match:
            continue
        point, retry, restart = match.groups()
        best = {}
        rank = {"EFFECT_EXECUTED": 3, "RECONCILED+effect_receipt": 2, "RECONCILED provider_receipt only": 1}
        ops = set()
        for segment in sorted(os.listdir(os.path.join(root, schedule))):
            path = os.path.join(root, schedule, segment, "audit.jsonl")
            if not os.path.isfile(path):
                continue
            with open(path, encoding="utf-8") as handle:
                entries = [json.loads(line)["entry"] for line in handle if line.strip()]
            for entry in entries:
                stage, op = entry["stage"], entry.get("operation_id")
                details = entry.get("details") or {}
                artifacts = sorted((entry.get("artifacts") or {}).keys())
                if stage == "CAPABILITY_ISSUED":
                    ops.add(op)
                if stage in ("RECONCILED", "CALL_RESULT"):
                    flags["%s flagged=%s" % (stage, details.get("flagged", "absent"))] += 1
                if stage == "RECONCILED":
                    reconciled[(point, retry, restart, segment, entry.get("outcome"), "+".join(artifacts) or "-")] += 1
                path_name = None
                if stage == "EFFECT_EXECUTED":
                    path_name = "EFFECT_EXECUTED"
                elif stage == "RECONCILED" and entry.get("outcome") == "committed":
                    path_name = "RECONCILED+effect_receipt" if "effect_receipt" in artifacts else "RECONCILED provider_receipt only"
                if path_name and rank[path_name] > rank.get(best.get(op), 0):
                    best[op] = path_name
        for op in ops:
            paths[(point, retry, restart, best.get(op, "no committed record"))] += 1
    print("# RECONCILED entries by cell, segment, outcome and artifacts")
    for key, value in sorted(reconciled.items()):
        print("%6d  %s" % (value, " ".join(key)))
    print("# operations with a capability, by strongest committed record over all segments of the schedule")
    for key, value in sorted(paths.items()):
        print("%6d  %s" % (value, " ".join(key)))
    total = collections.Counter()
    for key, value in paths.items():
        total[key[3]] += value
    print("# totals by strongest committed record")
    for key, value in sorted(total.items()):
        print("%6d  %s" % (value, key))
    print("# details.flagged on recovery records and answers")
    for key, value in sorted(flags.items()):
        print("%6d  %s" % (value, key))


if __name__ == "__main__":
    main()
