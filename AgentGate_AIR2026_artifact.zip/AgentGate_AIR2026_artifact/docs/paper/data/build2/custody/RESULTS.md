# Custody on build 2: rollback anchors, restart segments, signed witness status, freshness and run completeness

20 runs on 2026-10-10, 02:31:00-02:40:55 UTC: 15 in flag mode (the canonical
run plus 14 repeats, 2 of them under a process monitor) and 5 in deny mode.
After them came the relay probe of the signed run status (02:41:06-02:43:22).

This is the build-1 custody experiment
(`../../revision/custody/RESULTS.md`, 2026-10-08) repeated on **frozen
build 2**: commit `86643d7` of `claude/supervisor-demo`, binaries in
`<singlebuild2>/bin`, SHA-256 in `build-manifest.txt`. Nothing was rebuilt.

It answers review 3, major comment 5: "Expose freshness and run-completeness
as explicit verifier outputs, and require a fresh signed run-status response
when the claim is latest-run completeness." Section 6 reports the verifier's
two new derived dimensions, `head_fresh` and `run_complete`, for every cell.

## Headline

- **All 20 runs passed.** Each passed 9/9 revision checks (180/180).
- **No build-1 result changed.** Every outcome count is the same as in
  build 1, and so is every failing-check set (`compare_build1.json`):
  - 110/110 matrix cells (36 in process, 74 CLI);
  - 74/74 rollback cells;
  - 160/160 tamper-lab rows;
  - 14/14 relay-probe cells.

  Only two timing values differ (section 8).
- **The build-1 numbers, again on build 2.**
  - Tamper lab: ordinary edits detected 140/140, both without anchors and with
    them. The coherent rollback was detected 0/20 without anchors and 20/20
    with them.
  - In-process matrix: 300/600 tampered verifications detected, 0/120 false
    alarms, 60/120 clean verifications ANCHORED. The CLI agrees with the
    in-process verifier on 720/720.
  - CLI matrix (1,480 verifications): clean evidence 120/120 accepted,
    wrong-run anchor 60/60 refused, tampered evidence 740/1,300 detected.
  - The withheld segment is detected via `--witness-url` 20/20 with either
    journal.
  - The witness signs its run status; the signature verified 20/20 for both
    segments.
  - A relay that changed the witness's answers was refused 180/180, and a
    withheld status ended with exit 2 in 40/40.
  - The witness probes answered as expected 300/300.
  - All 80/80 replayed answers have scope `call`.
- **New: freshness and run completeness are explicit outputs** (section 6).
  The three cases the brief named:

  | case | expected | CLI | in process |
  |---|---|---|---|
  | live witness fetch (`--witness-url`, every variant) | `head_fresh` pass | **pass 180/180** | **pass 100/100** |
  | saved stale witness head, tamper-lab rollback R1 (#168 / #159) | ANCHORED, `head_fresh` not_checked, freshness Missing entry | **ANCHORED 20/20; not_checked 20/20; freshness entry 20/20** (`run_complete` not_checked 20/20) | the same, 20/20 |
  | saved stale segment head (#3), segment rollback R7 | as above | **20/20** on each point | – (no such cell) |
  | withheld segment (R5, R5j) via `--witness-url` | `run_complete` fail | **fail 40/40** (`head_fresh` pass 40/40) | **fail 40/40** |

  Further results:
  - `head_fresh` passes **only** with the live witness: 0/1,300 CLI and 0/620
    in-process verifications with any other anchor.
  - Every ANCHORED verdict without the live witness reports `head_fresh`
    not_checked, `run_complete` not_checked and a `freshness` Missing entry:
    200/200 CLI, 140/140 in process.
  - `run_complete` passed on **0/1,300** tampered CLI verifications and
    **0/600** in process. It passed only for the clean whole run verified
    with the live witness: 20/20 CLI, 20/20 in process.
  - `run_complete` never **failed** clean evidence: 0/120 CLI, 0/120 in
    process. The new dimensions raise no false alarm.
  - Relay probe: every changed answer gave `head_fresh` fail and
    `run_complete` fail (180/180).
- **Two build-1 open issues are closed** (section 9):
  - The in-process live anchor now applies the 2-minute freshness rule.
  - A saved witness head now lists the "withheld later restart segment cannot
    be ruled out" gap in `missing` (40/40).

## 1. What was run

The commands are the build-1 commands. Only the binaries and the folders
differ. Times are in `build-manifest.txt`.

```
# before and after the runs (recorded verbatim in build-manifest.txt)
py <singlebuild2>/check_manifest.py                      # 1868 files, 0 differ (02:29:19Z and 02:43:30Z)

# canonical run (from <repo>)
<singlebuild2>/bin/agentgate-eval.exe -host-label review-host custody \
    -work <scratch>/build2-work/custody/canonical/work -out docs/paper/data/build2/custody
# from this folder
python scripts/probe.py <singlebuild2>/bin <scratch>/build2-work/custody/canonical/work \
    <scratch>/build2-work/custody/canonical/probe custody.json
sh scripts/repeat.sh <scratch>/build2-work/custody <repo>      # 2 monitored + 12 flag + 5 deny
python scripts/status_probe.py <singlebuild2>/bin <scratch>/build2-work/custody custody.json \
    <canonical work> <canonical probe> .
python scripts/aggregate.py <scratch>/build2-work/custody custody.json <canonical probe> <agg>
python scripts/tamper_lab.py <scratch>/build2-work/custody custody.json <canonical work> tamper_lab.csv
# new for build 2
python scripts/evidence_facts.py <singlebuild2>/bin <scratch>/build2-work/custody custody.json \
    <canonical work> evidence_facts.csv evidence_facts_summary.json
python scripts/copy_process_observation.py <scratch>/build2-work/custody process_observation
python scripts/compare_build1.py ../../revision/custody . compare_build1.json
```

- `<scratch>/build2-work/custody/bin` is a directory junction to
  `<singlebuild2>/bin`, as in build 1.
- `agentgate-eval` starts `agentgate-provider` and `agentgate-witness` from
  that same folder.
- Every eval, probe and analysis step exited 0.
- Per-run evidence (about 6.5 MB per run) stays in
  `<scratch>/build2-work/custody/`.

**The method is unchanged** (build-1 RESULTS.md §1). Each run executes the
demo self-test with the operation journal, using the provider and the witness
as separate processes. The self-test runs every scenario, the tamper lab, a
witness outage and a gateway restart with a 4-entry restart segment registered
at the witness, plus 9 revision checks. Then:

- `agentgate-eval custody` verifies 36 evidence × anchor cells in process;
- `probe.py` runs 15 witness probes, builds the extra rollback and segment
  variants, runs 74 CLI cells per run and checks the signed run status;
- `status_probe.py` puts a loopback relay in front of a witness on a copy of
  each run's store (14 cells per run).

**Script changes for build 2.** Only additions; build 1's versions are in
`../../revision/custody/scripts/`.

- `probe.py`: every CLI row gains `head_fresh`, `run_complete`,
  `missing_kinds` and the two dimensions' reasons. The verify-time
  `--witness-url` checks on the segment and on the first folder record the
  same.
- `status_probe.py`: every row gains the same three columns, and the summary
  counts them per cell.
- `aggregate.py`: collects them into `dimensions_by_cell.csv` and adds
  `derived_dimensions` to `repeats_summary.json`.
- New scripts:
  - `evidence_facts.py`: the replay-scope count, which build 1 did by hand,
    plus the replay flags and the per-operation classification evidence;
  - `copy_process_observation.py`: a step build 1 did by hand;
  - `compare_build1.py`: a cell-by-cell comparison with build 1.
- Unchanged: `repeat.sh` (saved with LF line ends so that `sh` runs it),
  `tamper_lab.py`, `status_sig.py` and `monitor-run.ps1`.
- Every variant, anchor and outcome rule is the same.

## 2. Self-test, tamper lab and matrices

Every number here equals build 1.

- **Self-test:** PASSED 20/20, with 9/9 revision checks in each run.
- **Tamper lab** (`tamper_lab.csv`, 160 rows):
  - 7 ordinary edits per run: detected 140/140 without anchors and 140/140
    with keys and head pinned;
  - the coherent rollback: detected 0/20 without anchors, 20/20 with them.
- **In-process matrix** (36 cells × 20 runs = 720 verifications):
  - tampered: 300/600 detected;
  - **false alarms on clean evidence: 0/120**;
  - clean evidence reaching ANCHORED: 60/120.
  - The 300 undetected verifications are the same cells as in build 1:
    - the withheld segment under 6 anchor conditions (none, keys, the first
      run's head, keys + head, the saved witness file, the stale head), with
      either journal;
    - the folder-journal rollback under none, keys only and the stale head.
- **CLI cross-check:** agrees with the in-process verifier on 720/720 shared
  verifications.
- **Extended CLI matrix** (74 cells × 20 runs = 1,480 verifications):
  - **clean: 120/120 accepted, 0 false alarms**;
  - wrong-run anchor: 60/60 refused (`head.witness`);
  - tampered: 740/1,300 detected;
  - every cell gave the same result in all 20 runs (`matrix_stability.csv`).

## 3. Rollback detection, run folder (CLI; detected out of 20 runs)

This is the same table as build 1, with the same variants:

- **R1:** the tamper-lab rollback to #168 of 183 (deny #159 of 174);
- **R2:** R1 with the provider-process journal;
- **R3:** a rollback to #177 (deny #168), with no provider commit removed;
- **R4:** R3 with the provider-process journal.

The new column shows the derived dimensions of the cells that are **not**
detected.

| anchor | R1 | R2 | R3 | R4 | undetected cells: assurance / `head_fresh` / `run_complete` |
|---|---|---|---|---|---|
| none | 0 | 20 | 0 | 0 | CONSISTENT / not_checked / not_checked |
| keys only | **0** | 20 | **0** | **0** | CONSISTENT / not_checked / not_checked |
| stale witness head (#168 / #159), saved file | **0 (ANCHORED)** | 20 | 0 | 0 | R1: **ANCHORED / not_checked / not_checked + freshness entry**; R3, R4: CONSISTENT (the head covers only a prefix) |
| witness head at the R3 cut (#177 / #168) | 20 | 20 | 0 (ANCHORED) | 0 (ANCHORED) | ANCHORED / not_checked / not_checked + freshness entry |
| latest witness head, saved file | 20 | 20 | 20 | 20 | – |
| **latest witness head via `--witness-url`** | **20** | **20** | **20** | **20** | – (every cell: `head_fresh` pass, `run_complete` fail) |
| head pinned at shutdown | 20 | 20 | 20 | 20 | – |
| keys + head pinned | 20 | 20 | 20 | 20 | – |

Every detection count is unchanged from build 1 (`rollback_by_anchor.csv`,
74/74 cells equal). What changes is the report of the cells a saved head
leaves undetected. The verdict is still ANCHORED, but the report now says that
this ANCHORED rests on a saved head, so a rollback to it cannot be ruled out:

- `head_fresh` is not_checked, with the reason "anchored by a saved witness
  head, which carries no run status";
- `run_complete` is not_checked;
- `missing` adds the freshness entry "Head not shown to be fresh: ... a
  coherent rollback to the anchored head ... or a withheld later restart
  segment cannot be ruled out".

## 4. Restart segments and the withheld segment (CLI; out of 20 runs)

**Registration: unchanged, 20/20.**

- The witness registered the segment as the continuation.
- It cosigned the segment's heads #3 and #4.
- The signed `GET /runs/{run}` names the segment in `continued_by`.
- The segment's `continues` equals its `run.json`.

The variants:

- **S0:** the segment, followed to the first folder: the whole run.
- **R6:** the segment, with the first folder replaced by the R1 rollback.
- **R7:** the segment rolled back to its own head #3.
- **R5:** the segment withheld.
- **R5j:** R5 with the provider-process journal.

Each cell gives the detection count first, then `head_fresh` /
`run_complete` (from `dimensions_by_cell.csv`).

| anchor | S0 (clean) | R6 | R7 | R5 | R5j |
|---|---|---|---|---|---|
| none | accepted (CONSISTENT); nc / nc | 20; nc / fail | **0**; nc / nc | **0**; nc / nc | **0**; nc / nc |
| keys pinned | accepted; nc / nc | 20 | 0; nc / nc | 0; nc / nc | 0; nc / nc |
| head pinned | accepted; nc / nc + freshness | 20 | 20 | 0; nc / nc + freshness | 0; nc / nc + freshness |
| keys + head pinned | ANCHORED; nc / nc + freshness | 20 | 20 | **0 (ANCHORED); nc / nc + freshness** | **0 (ANCHORED); nc / nc + freshness** |
| segment's latest witness head, saved file | ANCHORED; nc / nc + freshness | 20 | 20 | 20 (`head.witness`, wrong run) | 20 |
| first run's latest witness head, saved file | refused, wrong run (20) | refused (20) | refused (20) | **0 (ANCHORED); nc / nc + freshness** | **0 (ANCHORED); nc / nc + freshness** |
| **latest head + signed status via `--witness-url`** | **ANCHORED; pass / pass (20/20)** | 20; pass / fail | **20; pass / fail** | **20 (`head.anchor`); pass / fail** | **20 (`head.anchor`); pass / fail** |
| stale witness head, saved file (segment #3; R5: #168 / #159) | – | – | **0 (ANCHORED); nc / nc + freshness** | 0 (CONSISTENT; prefix only) | 0 (CONSISTENT) |
| witness head at the R3 cut (probe) | – | – | – | 0 (CONSISTENT) | 0 (CONSISTENT) |
| head pinned = the run's real final head | – | – | – | 20 (`head.anchor`); nc / fail | 20; nc / fail |

nc = not_checked. "+ freshness" = the report lists a `freshness` Missing
entry. Every detected cell has `run_complete` fail.

- **Detection counts and failing checks are all unchanged** from build 1.
- **R5 (withheld segment) with the live witness: `run_complete` fail
  (40/40).**
  - `head_fresh` passes, because the witness's signed statement is current.
  - `run_complete` fails, with the reason: "The witness's signed run status
    says run <segment> continued this run after a gateway restart, and that
    segment is not part of the verified chain: the run did not end where this
    log ends."
  - The in-process verifier gave the same, 40/40.
  - So did the verify-time check (`witness_probe.json`,
    `verify_time_outage`): exit 1, `head.anchor`, `head_fresh` pass,
    `run_complete` fail, 20/20.
- **R5 without the live witness** is still ANCHORED under the first run's pins
  or saved witness file, which is build 1's open gap. The report now
  qualifies it in 80/80 such ANCHORED verifications: `head_fresh` and
  `run_complete` are not_checked, and the freshness entry names the withheld
  later restart segment.
- **S0 (the clean whole run).** It reaches `run_complete` pass only with the
  live witness (20/20). Pins and saved heads give ANCHORED with `head_fresh`
  and `run_complete` not_checked. `run_complete` failed on clean evidence
  0/120.
- **Verification against the witness:**
  - `--witness-url` on the segment exited 0, ANCHORED, `head_fresh` pass and
    `run_complete` pass, 20/20;
  - on the first folder alone it exited 1 (`head.anchor`), 20/20;
  - against the stopped witness it exited 2 (connection refused, 0.03-0.13
    s), 20/20. There is no fallback.

## 5. The signed witness run status

### 5.1 What the witness answered (20 runs, both segments)

Unchanged from build 1.

| fact (checked by `probe.py` and `status_sig.py`, not by AgentGate code) | first run | segment |
|---|---|---|
| format `agentgate-witness-run-status/v1` | 20/20 | 20/20 |
| signature verifies with the saved witness key | 20/20 | 20/20 |
| names the head that `GET /runs/{id}/latest` returned | 20/20 | 20/20 |
| `status_at` is after that head's `witnessed_at` | 20/20 | 20/20 |
| `continued_by` | the segment, 20/20 | absent, 20/20 |

- `status_at` was 0.3-1.7 ms before `probe.py` received the answer (build 1:
  0.3-1.3 ms).
- The witness-copy probe saw the same, and the store copy did not change
  (20/20).
- **CLI:** all 180 `--witness-url` verifications read the status as
  "checked"; 0 were "given; INVALID". 120 say "continued_by=the segment" and
  60 say "not continued".

### 5.2 An intermediary that answers in the witness's place (`status_probe.csv`, 280 cells)

The outcomes are unchanged from build 1. The two new columns are the derived
dimensions.

| relay answer | S0 (clean) | R5 (withheld) | R1 (rollback) | `head_fresh` / `run_complete` |
|---|---|---|---|---|
| unchanged (control) | **ANCHORED 20/20** | detected 20/20 (`head.anchor`) | detected 20/20 (`head.anchor`) | S0: **pass / pass**; R5, R1: pass / fail |
| `continued_by` removed | – | **detected 20/20** (`head.witness`) | – | fail / fail |
| status replaced by the old unsigned format | refused 20/20 | **detected 20/20** | – | fail / fail |
| the segment's genuine status served for the first run | – | **detected 20/20** | – | fail / fail |
| an earlier genuine head served as the latest, with the current status | refused 20/20 | detected 20/20 | **detected 20/20** | fail / fail |
| a genuine (head, status) pair served again 135-584.5 s after signing | refused 20/20 | detected 20/20 | – | fail / fail |
| status withheld (404) | – | exit 2, 20/20 | exit 2, 20/20 (with the stale head) | no report |

- Every changed or swapped answer was refused (`head.witness`): 180/180. A
  withheld status stopped the CLI with exit 2: 40/40.
- The new dimensions say the same thing consumer-side: each of the 180
  refused answers gives `head_fresh` fail ("the witness's answer is not an
  authentic, consistent and current statement") and `run_complete` fail.
- Relay requests: 2 per cell in 220 cells, and 6 in the 60 cells where the
  head and the status disagree (3 fetches). This is as in build 1.
- The witness store copies were unchanged: 20/20.
- **Not tested, as in build 1:**
  - a replay within the 2-minute window, which is accepted by design;
  - a genuine status from before the continuation was registered.

## 6. Freshness and run completeness (new; review 3, major comment 5)

The verifier derives `head_fresh` and `run_complete` from the state its checks
leave (`docs/demo/VERIFIER_CHECKS.md` §1). They change no verdict and no
assurance, which is why every build-1 count is unchanged.

**All 1,480 CLI verifications** (from `dimensions_by_cell.csv`), grouped by
anchor type:

| anchor type | verifications | assurance / `head_fresh` / `run_complete` (count) | lists a `freshness` entry |
|---|---|---|---|
| live witness (`--witness-url`) | 180 | ANCHORED / pass / pass 20 (S0); FAILED / pass / fail 160 | 0 |
| latest witness head, saved file | 220 | ANCHORED / nc / nc 60; FAILED / nc / fail 160 | 80 |
| stale witness head, saved file | 140 | ANCHORED / nc / nc 40 (R1, R7); CONSISTENT / nc / nc 80; FAILED / nc / fail 20 | 60 |
| witness head at the R3 cut, saved file | 120 | ANCHORED / nc / nc 40; CONSISTENT / nc / nc 40; FAILED / nc / fail 40 | 40 |
| keys + head pinned | 180 | ANCHORED / nc / nc 60; FAILED / nc / fail 120 | 80 |
| head pinned | 180 | CONSISTENT / nc / nc 60; FAILED / nc / fail 120 | 80 |
| head pinned = the run's real final head | 40 | FAILED / nc / fail 40 | 0 |
| keys pinned | 180 | CONSISTENT / nc / nc 140; FAILED / nc / fail 40 | 0 |
| none | 180 | CONSISTENT / nc / nc 140; FAILED / nc / fail 40 | 0 |
| wrong-run witness head | 60 | FAILED / nc / fail 60 | 0 |

The in-process verifier gives the same per anchor type (720 verifications,
`dimensions_by_cell.csv`, source "in-process"):

- live witness: pass / pass 20, pass / fail 80;
- every other anchor: `head_fresh` not_checked 620/620.

**What this shows, with denominators.**

- **`head_fresh` passes exactly when the witness's signed status was fetched
  live:**
  - pass 180/180 CLI and 100/100 in process;
  - 0/1,300 CLI and 0/620 in process with any other anchor.

  A pass means the witness's statement is current. It does not mean the log
  matches that statement: in 160 of the 180 CLI verifications the evidence is
  tampered and the verdict is FAILED. In 140 of those 160, `head.anchor`
  fails; R6 fails `files.continuity` and `provider.matches_audit` instead.
  `run_complete` carries that judgment.
- **`run_complete` is the latest-run completeness claim:**
  - It passes only for the clean whole run with the live witness: 20/20 CLI,
    20/20 in process, 0 other verifications.
  - It never passes on tampered evidence: 0/1,300 CLI (0/1,340 including the
    40 wrong-run cells on tampered variants), 0/600 in process.
  - It never fails clean evidence: 0/120 CLI, 0/120 in process.
  - **A consumer that requires `run_complete` = pass** therefore accepted
    the clean whole run 20/20 (with `--witness-url`) and accepted none of
    the 560 tampered CLI verifications that the verdict leaves undetected:
    - 160 of them are ANCHORED;
    - 400 are CONSISTENT.
- **ANCHORED without the live witness is now qualified:**
  - All 200/200 CLI and 140/140 in-process ANCHORED verdicts reached with
    pins or saved heads report `head_fresh` and `run_complete` not_checked
    and list the freshness entry.
  - This covers the two build-1 counterexamples:
    - the saved stale head with the R1 rollback, 20/20;
    - the saved first-run head with the withheld segment, 40/40.
- **The freshness entry appears only when the pin or saved head actually
  anchors the log end.**
  - In total 340 CLI verifications list it: 200 ANCHORED, 60 CONSISTENT (a
    head pin without a keys pin), and 80 FAILED for other reasons.
  - A mismatching anchor lists "Head anchor MISMATCH" instead.
  - A witness head that covers only a prefix lists "Head anchored only up to
    entry #k". Examples are the stale #168 head on the 183-entry first
    folder, and the #177 head on R5.
- **Stale window and outage behaviour, as measured here:**
  - Statuses signed 135-584.5 s before the fetch were refused, with
    `head_fresh` fail, 40/40.
  - Fresh statuses (0.3-1.7 ms old) passed.
  - A stopped witness ends the CLI with exit 2 (20/20); there is no fallback
    to a saved head.
  - The exact boundary (2 min inclusive) and clock jumps were not exercised
    here. They are covered by unit tests in `internal/auditverify`, not by
    this experiment.

## 7. Outage, probes, restarts, replayed answers and processes

- **Outage (20/20, unchanged).**
  - There is 1 WITNESS_UNAVAILABLE entry.
  - Pushes: 31 succeeded, 1 failed.
  - The restarted witness caught up to #177 (deny #168).
  - In the witness history the outage is a jump of 9 entries, against
    ordinary jumps of up to 8.
- **Witness probes:** 300/300 as expected, with the same status sequence as
  build 1. The store copy was unchanged in 20/20.
- **Restarts (20/20, unchanged).**
  - The witness kept its key, and its latest head equals the saved anchor.
  - The provider kept its key. Its journal matches the folder: 14 commits in
    flag mode, 11 in deny mode.
  - The gateway was rebuilt on its journal and replayed 22 operations.
    Provider commits stayed the same: 14 → 14 (deny 11 → 11).
- **Replayed answers** (`evidence_facts.csv`, 40 run folders):
  - 80 replayed CALL_RESULT entries, all COMMITTED with scope `call`. That is
    4 per run: 3 in the first folder, 1 in the segment. Unchanged.
  - The `flagged` field matches the operation's decision in 80/80.
  - None of the replayed operations is flagged (0/80). Both are ALLOW_BASE
    decisions:
    - the three retries of a message send;
    - the reconciled payment answered from the journal after the restart.
  - So the build-2 gateway change (keep the flag on every replayed COMMITTED
    answer) and the verifier's new replay-flag rule (refusal site 142) are
    exercised here only on unflagged answers. The rule raised no failure.
- **Classification evidence** (new verifier output; the whole run, no
  anchors):
  - flag runs: `issuer_adapter` 13, `issuer_only_reconciled` 1,
    `audit_only` 11 (15/15 runs);
  - deny runs: 10 / 1 / 14 (5/5);
  - `flagged` 3 (flag mode) and 0 (deny mode); `flagged_unconfirmed` 0
    everywhere.
  - The one `issuer_only_reconciled` operation is the fault-injection payment
    whose provider response was lost and which an exact retry reconciled in
    the same process. No adapter receipt was ever signed, because the
    response was lost, so its classification rests on the issuer's signature
    alone.
  - Every verification therefore lists one `issuer_only` Missing entry. Build
    1 had no such output.
- **Process monitor** (2 runs, all listeners on 127.0.0.1;
  `process_observation/`).
  - The children appeared in the same order as in build 1:
    1. the provider;
    2. the first witness (killed for the outage);
    3. the restarted witness;
    4. the provider for the gateway restart;
    5. the witness for the segment registration;
    6. the runner's post-run witness, up 2.4-2.8 s here (build 1: 0.9-1.0 s).
  - The short post-run provider restart was seen in **2 of 2** runs (build 1:
    0 of 2). In monitored-01 it lived 169 ms, with its listener seen; in
    monitored-02 it was seen in one sample. The runs were 3-5 times slower on
    the shared machine, so this process lived longer than the sampling
    interval (about 35 ms).

## 8. Comparison with build 1

| measure (20 runs) | build 1 (2026-10-08, eval `744d480c...`) | build 2 (2026-10-10, eval `485e4ce0...`) | why |
|---|---|---|---|
| self-test passed; revision checks | 20/20; 180/180 | 20/20; 180/180 | – |
| tamper lab: ordinary edits; rollback without / with anchors | 140/140; 0/20 / 20/20 | the same; 160/160 rows identical, failing checks included | – |
| in-process matrix | 300/600 detected, 0/120 false alarms, 60/120 ANCHORED | the same | – |
| CLI matrix | 1,480; clean 120/120; wrong-run 60/60; tampered 740/1,300 | the same | – |
| cells with the same outcome counts and failing checks | – | 110/110 matrix, 74/74 rollback | The new checks (recovery and replay flags, adapter receipt on RECONCILED) find nothing to refuse in this genuine evidence, and the derived dimensions change no verdict |
| CLI = in-process | 720/720 | 720/720 | – |
| withheld segment via `--witness-url` (R5, R5j) | 20/20, 20/20 | 20/20, 20/20 | – |
| clean whole run (S0), 6 anchor conditions | 120/120 accepted, 60 ANCHORED | the same | – |
| stale head (R1) as a saved file | ANCHORED 20/20 | ANCHORED 20/20, **now with `head_fresh` not_checked, `run_complete` not_checked and a freshness entry 20/20** | new derived dimensions and Missing kinds |
| saved first-run head with the segment withheld | ANCHORED 20/20, gap not in `missing` | ANCHORED 40/40 (R5 + R5j), **freshness entry naming the withheld segment 40/40** | build-1 open issue 3 closed |
| `head_fresh` with the live witness / any other anchor | not reported | pass 180/180 / pass 0/1,300 (CLI); 100/100 / 0/620 (in process) | new dimension |
| `run_complete` pass: clean whole run with `--witness-url` / tampered | not reported | 20/20 / 0/1,300 (CLI); 20/20 / 0/600 (in process) | new dimension |
| `run_complete`, withheld segment via `--witness-url` | not reported | fail 40/40 CLI, 40/40 in process | new dimension |
| in-process live anchor applies the 2-minute rule | no (open issue 1) | yes: `head_fresh` pass 100/100 needs the fetch time | `custody.go` passes `WitnessRunFetchedAt` |
| signed status verified (both segments); CLI statuses checked | 20/20; 180/180, 0 invalid | the same | – |
| relay probe | 180/180 refused, 40/40 exit 2, control 20/20 | the same, plus `head_fresh` and `run_complete` fail 180/180 | – |
| replayed (head, status) pair age | 135-420 s | 135-584.5 s | The canonical pair was older when replayed, because the repetitions ran slower on the shared machine. The outcome is the same (refused 40/40). |
| status lag (`status_at` to the probe's receipt) | 0.3-1.3 ms | 0.3-1.7 ms | timing; the only differing key of `repeats_summary.json` (59/60 equal) |
| replayed answers: scope `call`; flag | 80/80; not counted | 80/80; flag matches the decision 80/80 (no flagged operation is replayed) | gateway keeps the flag on replayed COMMITTED answers; not visible here |
| Missing entries per verification | text only | adds the kinds; adds 1 `issuer_only` entry to every verification and a `freshness` entry where a pin or saved head anchors the log | new verifier outputs (`missing_kinds`, classification evidence) |
| `custody.csv` / `custody.md` columns | 10 / 6 | 13 / 8 (`missing_kinds`, `head_fresh`, `run_complete`) | new runner output |
| post-run provider seen by the process monitor | 0/2 | 2/2 | slower runs (shared machine); not a behaviour change |
| per-run time | 7.6-17.1 s | 4.5-42.6 s | shared machine (up to 5 `agentgate-eval` processes at once); not a performance result |

The build-2 changes that this experiment does **not** exercise:

- the killsuite binary;
- the `evalattack` change;
- the RECONCILED adapter-receipt path: the only RECONCILED operation has no
  adapter receipt;
- flagged replays: no replayed operation is flagged.

## 9. Open issues from build 1 (§9 there)

1. **Closed.** The eval engine's in-process live anchor had no fetch time.
   `liveWitnessOptions` now passes `WitnessRunFetchedAt`. `head_fresh` passes
   in process 100/100; without the fetch time its reason would be "no fetch
   time was given".
2. **Exposed, still by design.** A stale witness head given as a file yields
   ANCHORED. It is now marked as unfresh (section 6). The deployment rule
   "always verify with `--witness-url`" becomes checkable: require
   `run_complete` = pass.
3. **Closed.** The withheld-segment gap of a saved witness head now appears in
   `missing` (the freshness entry), 40/40.
4. **Unchanged.** `internal/headwitness` was not changed between the builds:
   - registration is unauthenticated;
   - the freshness rule assumes agreeing clocks;
   - `Client.Registration` reads the status without checking its signature.
5. **Unchanged.**
   - No live-journal variant of the segment.
   - The segment pins are read from the folder.
   - `started_at` (02:31:04Z) is still taken after the self-test; the run ID
     is 02:31:00Z.
6. **Outside this folder.** `RESULTS_REVISION.md`, the paper and
   `RESPONSE_TO_REVIEW.md` still cite build 1's custody numbers. They should
   take the derived-dimension results (sections 6 and 8) and the build-2
   hashes from here.

**New minor observations.** No outcome is affected; these are reporting
texts only.

- For a saved witness head that **mismatches** the log (FAILED), the
  `head_fresh` reason still says "The head is anchored by a saved witness
  head". The status (not_checked) is right, but the wording claims an anchor
  that `head.anchor` refused.
- The `custody.md` header says "every cell anchored by a pin or a saved head
  lists the freshness gap". In the data this holds only when the pin or head
  matches the log end (section 6).
- In the CLI reasons, `status_at` and the fetch time are often printed
  identical to the 100 ns. Go's clock on this machine ticks about once per
  millisecond (`clock_granularity_ms` 0.9998), and the witness and the
  verifier share it. Python's finer clock measured 0.3-1.7 ms.

## 10. Caveats

- **One machine, one user account.**
  - The provider and the witness are separate processes, not separate
    custodians.
  - The gateway process could read their key files, including the witness
    key that signs the status.
- **Elapsed times are not performance results.** Other build-2 experiments ran
  at the same time.
- **Same code.** The derived dimensions are computed by the same
  `internal/auditverify` code in the CLI and in process. Only the status
  signature was checked independently (`status_sig.py`).
- **Freshness assumes agreeing clocks.** Here the witness and the verifier
  share one clock. Clock rollback, forward jumps and the inclusive 2-minute
  boundary were not tested here.
- **A replay within 2 minutes is accepted by design.** A continuation
  registered less than 2 minutes before a verification could be hidden that
  way.
- **Narrow failure cases.** Only a hard kill of the witness between
  operations and one gateway restart per run were exercised.
- **Not measured:** registration preemption and substitution (review 3
  comment 5, first paragraph).
- **The scripts were extended.** The additions only read new report fields.
  Build 1's versions are kept unchanged in `../../revision/custody/scripts/`.

## 11. Files

| file | contents |
|---|---|
| `custody.json`, `custody.csv`, `custody.md` | the canonical flag run (the tool's output, 36 cells, with `missing_kinds`, `head_fresh` and `run_complete`) |
| `witness_probe.json` | the canonical run's `probe.json`: witness probes, signed statuses, registrations, live witness, verify-time checks (with the derived dimensions), rollback probe |
| `cli_crosscheck.csv` | the canonical run's 74 CLI cells, with `head_fresh`, `run_complete`, `missing_kinds` and the reasons |
| `status_probe.csv`, `status_probe_summary.json` | the relay probe: 14 cells per run plus the store-copy check, 20 runs, with the derived dimensions |
| `repeats.csv`, `repeats_summary.json` | one row per run (20) and the summary with denominators, including `derived_dimensions` |
| `matrix_stability.csv`, `rollback_by_anchor.csv` | every cell over the 20 runs (in process and CLI), the same format as build 1 |
| `dimensions_by_cell.csv` | new: assurance / `head_fresh` / `run_complete` and the Missing kinds per cell over the 20 runs (in process and CLI) |
| `tamper_lab.csv` | the self-test tamper lab of the 20 runs |
| `evidence_facts.csv`, `evidence_facts_summary.json` | new: the 80 replayed answers (scope, status, flag against the decision) and the verifier's classification-evidence counts per run |
| `compare_build1.json` | new: the cell-by-cell comparison with `../../revision/custody/` |
| `process_observation/` | the 2 monitored runs (process tree, listeners), paths replaced by `<exp>` |
| `scripts/` | build 1's scripts: `probe.py`, `aggregate.py` and `status_probe.py` extended; `repeat.sh`, `tamper_lab.py`, `status_sig.py` and `monitor-run.ps1` unchanged. New: `evidence_facts.py`, `copy_process_observation.py`, `compare_build1.py` |
| `build-manifest.txt` | the six binaries' SHA-256, `check_manifest.py` before and after (with timestamps), commands, times, the script changes, the 13 changed and 12 added module files against build 1, and the 256 compiled module files |

Per-run evidence (work folders, probe folders, raw stdout) stays outside the
repository, in `<scratch>/build2-work/custody/`.
