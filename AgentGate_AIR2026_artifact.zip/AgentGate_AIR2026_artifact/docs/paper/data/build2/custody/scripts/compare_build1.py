"""Compare the build-2 custody aggregates with build 1, cell by cell (new for build 2).

Usage: python compare_build1.py BUILD1_DIR BUILD2_DIR OUT_JSON
  BUILD1_DIR  docs/paper/data/revision/custody (build 1, 2026-10-08)
  BUILD2_DIR  docs/paper/data/build2/custody   (build 2, 2026-10-10)

Compares, for the files both builds wrote with the same scripts:
  matrix_stability.csv    per (source, variant, anchors): outcome counts and failing checks
  rollback_by_anchor.csv  per (variant, anchors): every count column, assurance and failing checks
  tamper_lab.csv          per (run, attack): naive and anchored verdicts, detected, failing checks
  status_probe_summary.json  per (variant, answer): outcomes and failing checks
  repeats_summary.json    every key build 1 has (keys new in build 2 are listed, not compared)
and writes OUT_JSON with the number of equal and differing items and every difference.
"""
import csv, json, os, sys

b1, b2, out = sys.argv[1:4]


def rows(folder, name):
    return list(csv.DictReader(open(os.path.join(folder, name), encoding="utf-8")))


def compare_csv(name, key_cols, skip=()):
    r1 = {tuple(r[k] for k in key_cols): r for r in rows(b1, name)}
    r2 = {tuple(r[k] for k in key_cols): r for r in rows(b2, name)}
    diffs, equal = [], 0
    for key in sorted(set(r1) | set(r2)):
        a, b = r1.get(key), r2.get(key)
        if a is None or b is None:
            diffs.append({"key": list(key), "only_in": "build 1" if b is None else "build 2"})
            continue
        changed = {c: [a.get(c), b.get(c)] for c in a if c not in key_cols and c not in skip and a.get(c) != b.get(c)}
        if changed:
            diffs.append({"key": list(key), "changed": changed})
        else:
            equal += 1
    return {"build1_items": len(r1), "build2_items": len(r2), "equal": equal, "different": len(diffs), "differences": diffs}


result = {
    "matrix_stability.csv": compare_csv("matrix_stability.csv", ["source", "variant", "anchors"]),
    "rollback_by_anchor.csv": compare_csv("rollback_by_anchor.csv", ["variant", "anchors"]),
    "tamper_lab.csv": compare_csv("tamper_lab.csv", ["run", "attack"]),
}

s1 = json.load(open(os.path.join(b1, "status_probe_summary.json"), encoding="utf-8"))
s2 = json.load(open(os.path.join(b2, "status_probe_summary.json"), encoding="utf-8"))
c1 = {(c["variant"], c["answer"]): c for c in s1["by_cell"]}
c2 = {(c["variant"], c["answer"]): c for c in s2["by_cell"]}
sp = {"build1_items": len(c1), "build2_items": len(c2), "equal": 0, "differences": []}
for key in sorted(set(c1) | set(c2)):
    a, b = c1.get(key), c2.get(key)
    if a is None or b is None:
        sp["differences"].append({"key": list(key), "only_in": "build 1" if b is None else "build 2"})
    elif (a["outcomes"], a["failing"], a["runs"]) != (b["outcomes"], b["failing"], b["runs"]):
        sp["differences"].append({"key": list(key), "build1": [a["runs"], a["outcomes"], a["failing"]], "build2": [b["runs"], b["outcomes"], b["failing"]]})
    else:
        sp["equal"] += 1
for k in ("runs", "cells", "witness_copy_unchanged", "relay_requests_per_cell", "replayed_status_age_s"):
    if s1.get(k) != s2.get(k):
        sp["differences"].append({"key": k, "build1": s1.get(k), "build2": s2.get(k)})
sp["different"] = len(sp["differences"])
result["status_probe_summary.json"] = sp

r1 = json.load(open(os.path.join(b1, "repeats_summary.json"), encoding="utf-8"))
r2 = json.load(open(os.path.join(b2, "repeats_summary.json"), encoding="utf-8"))
rs = {"build1_keys": len(r1), "equal": 0, "differences": [], "new_in_build2": sorted(set(r2) - set(r1))}
for k in r1:
    if r1[k] != r2.get(k):
        rs["differences"].append({"key": k, "build1": r1[k], "build2": r2.get(k)})
    else:
        rs["equal"] += 1
rs["different"] = len(rs["differences"])
result["repeats_summary.json"] = rs

json.dump(result, open(out, "w", encoding="utf-8"), indent=1)
for name, r in result.items():
    print("%-28s equal %s, different %s" % (name, r.get("equal"), r.get("different")))
    for d in r["differences"][:40]:
        print("   ", json.dumps(d)[:600])
