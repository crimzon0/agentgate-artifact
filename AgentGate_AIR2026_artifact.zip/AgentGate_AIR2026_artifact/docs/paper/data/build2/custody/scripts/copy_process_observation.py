"""Copy the process-monitor output of the monitored runs into the repository, paths replaced by <exp>.

Usage: python copy_process_observation.py EXP OUTDIR
  EXP/runs/monitored-NN/{processes.csv, listeners.csv, monitor.txt} (monitor-run.ps1)
  OUTDIR/monitored-NN-{processes.csv, listeners.csv, monitor.txt}
Build 1 did the same step by hand (its process_observation/ folder); written down for build 2.
"""
import glob, os, sys

exp, outdir = sys.argv[1:3]
os.makedirs(outdir, exist_ok=True)
forms = set()
for form in (exp, os.path.abspath(exp), os.path.realpath(exp)):
    forms.update({form, form.replace("/", "\\"), form.replace("\\", "/")})
for d in sorted(glob.glob(os.path.join(exp, "runs", "monitored-*"))):
    name = os.path.basename(d)
    for f in ("processes.csv", "listeners.csv", "monitor.txt"):
        src = os.path.join(d, f)
        if not os.path.exists(src):
            continue
        raw = open(src, "rb").read()
        text = raw.decode("utf-8-sig")
        for form in sorted(forms, key=len, reverse=True):
            text = text.replace(form, "<exp>")
        open(os.path.join(outdir, "%s-%s" % (name, f)), "w", encoding="utf-8", newline="").write(text)
        print(name, f, "copied")
