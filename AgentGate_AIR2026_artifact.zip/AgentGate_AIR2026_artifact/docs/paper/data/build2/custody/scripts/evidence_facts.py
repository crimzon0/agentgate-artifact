"""Replayed answers and per-operation classification evidence of every custody run (new for build 2).

Usage: python evidence_facts.py BIN EXP CANONICAL_CUSTODY_JSON CANONICAL_WORK OUT_CSV OUT_JSON
  BIN  folder holding agentgate-verify.exe
  EXP  EXP/runs/<name>/{out/custody.json, work/} are the repetitions (repeat.sh)

Build 1 counted the replayed CALL_RESULT entries and their scope by hand
(RESULTS.md section 6, "Replay scope"); this script does the same for every
run folder (first folder and restart segment) and adds what build 2 changed:

  - each replayed COMMITTED answer's `flagged` field against the flag of the
    decision its operation rests on (POLICY_DECISION / POLICY_FINAL details),
    since build 2 keeps the flag on every replayed COMMITTED answer;
  - the verifier's per-operation classification evidence, flagged and
    flagged-but-unconfirmed counts: agentgate-verify --json on the restart
    segment (the whole run, no anchors; the counts do not depend on anchors).

Reads genuine files only and writes nothing into the run folders.
"""
import csv, glob, json, os, subprocess, sys
from collections import Counter

bindir, exp, canonical_json, canonical_work, out_csv, out_json = sys.argv[1:7]
binv = os.path.join(bindir, "agentgate-verify.exe")
runs = [("canonical", canonical_json, canonical_work)]
for d in sorted(glob.glob(os.path.join(exp, "runs", "*", ""))):
    name = os.path.basename(os.path.dirname(d))
    runs.append((name, os.path.join(d, "out", "custody.json"), os.path.join(d, "work")))


def entries(folder):
    return [json.loads(l)["entry"] for l in open(os.path.join(folder, "audit.jsonl"), encoding="utf-8") if l.strip()]


def decision_flagged(es):
    """operation id -> True when a policy entry of the operation states flagged=true."""
    out = {}
    for e in es:
        if e["stage"] in ("POLICY_DECISION", "POLICY_FINAL"):
            if (e.get("details") or {}).get("flagged") is True:
                out[e["operation_id"]] = True
    return out


rows = []
folder_count = 0
for name, cj, work in runs:
    f = json.load(open(cj, encoding="utf-8"))["facts"]
    mode = "deny" if "deny" in name else "flag"
    folders = [("first folder", os.path.join(work, "runs", f["run_id"]))]
    if f.get("segment_run_id"):
        folders.append(("segment", os.path.join(work, "runs", f["segment_run_id"])))
    flags = {}
    folder_count += len(folders)
    for label, folder in folders:
        es = entries(folder)
        flags.update(decision_flagged(es))
        for e in es:
            det = e.get("details") or {}
            if e["stage"] == "CALL_RESULT" and det.get("replayed"):
                op_flag = flags.get(e["operation_id"], False)
                stated = det.get("flagged", False)
                rows.append({"run": name, "mode": mode, "folder": label, "seq": e["seq"], "status": det.get("status", ""),
                             "reason": det.get("reason", ""), "scope": det.get("scope", ""), "flagged_stated": stated,
                             "operation_decision_flagged": op_flag, "flag_matches_decision": stated == op_flag})
    # classification evidence: the verifier on the whole run (newest segment)
    p = subprocess.run([binv, "--json", folders[-1][1]], capture_output=True, text=True)
    rep = json.loads(p.stdout) if p.stdout.strip() else {}
    counts = rep.get("counts") or {}
    ce = counts.get("classification_evidence") or {}
    rows.append({"run": name, "mode": mode, "folder": "whole run (verifier, no anchors)", "seq": "", "status": rep.get("assurance", ""),
                 "reason": "exit %d; flagged %s; flagged_unconfirmed %s; classification_evidence %s; failing %s" % (
                     p.returncode, counts.get("flagged", 0), counts.get("flagged_unconfirmed", 0),
                     " ".join("%s=%d" % kv for kv in sorted(ce.items())),
                     " ".join(sorted({x.get("id") for x in (rep.get("failures") or [])})) or "-"),
                 "scope": "", "flagged_stated": "", "operation_decision_flagged": "", "flag_matches_decision": ""})

with open(out_csv, "w", newline="", encoding="utf-8") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
rep_rows = [r for r in rows if r["seq"] != ""]
ver_rows = [r for r in rows if r["seq"] == ""]
summary = {
    "runs": len(runs), "run_folders": folder_count,
    "replayed_call_results": len(rep_rows),
    "replayed_by_folder": dict(Counter(r["folder"] for r in rep_rows)),
    "replayed_by_status_scope": dict(Counter("%s/%s" % (r["status"], r["scope"]) for r in rep_rows)),
    "replayed_committed_flag_matches_decision": "%d/%d" % (sum(1 for r in rep_rows if r["status"] == "COMMITTED" and r["flag_matches_decision"] is True),
                                                         sum(1 for r in rep_rows if r["status"] == "COMMITTED")),
    "replayed_of_flagged_operations": sum(1 for r in rep_rows if r["operation_decision_flagged"] is True),
    "replayed_per_run": dict(Counter(str(sum(1 for r in rep_rows if r["run"] == name)) for name, _, _ in runs)),
    "verifier_whole_run": dict(Counter("%s|%s|%s" % (r["mode"], r["status"], r["reason"]) for r in ver_rows)),
}
json.dump(summary, open(out_json, "w", encoding="utf-8"), indent=1)
print(json.dumps(summary, indent=1))
