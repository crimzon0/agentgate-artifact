# Runs one "agentgate-eval custody" invocation and observes, from outside, the
# process tree it creates: every agentgate-* process (pid, parent pid, image,
# first/last time seen) via a Toolhelp32 snapshot, and every IPv4 TCP listening
# socket owned by one of them via GetExtendedTcpTable, polled every few ms
# until the eval process exits. Command lines are read once per new pid via
# Win32_Process (may be missing for very short-lived processes).
param(
    [Parameter(Mandatory = $true)][string]$Exp,
    [Parameter(Mandatory = $true)][string]$Name,
    [string]$Escalation = "flag",
    # global -host-label option of agentgate-eval (empty: the real host name)
    [string]$HostLabel = "review-host",
    [switch]$NoCommandLine,
    # repository root (default: six levels above this script, docs/paper/data/revision/custody/scripts)
    [string]$Repo = (Resolve-Path (Join-Path $PSScriptRoot "..\..\..\..\..\..")).Path
)
$ErrorActionPreference = "Stop"
Add-Type -TypeDefinition @"
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public static class ProcProbe {
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    struct PROCESSENTRY32W {
        public uint dwSize; public uint cntUsage; public uint th32ProcessID; public IntPtr th32DefaultHeapID;
        public uint th32ModuleID; public uint cntThreads; public uint th32ParentProcessID; public int pcPriClassBase;
        public uint dwFlags; [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)] public string szExeFile;
    }
    [DllImport("kernel32.dll", SetLastError = true)] static extern IntPtr CreateToolhelp32Snapshot(uint flags, uint pid);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] static extern bool Process32FirstW(IntPtr snap, ref PROCESSENTRY32W e);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] static extern bool Process32NextW(IntPtr snap, ref PROCESSENTRY32W e);
    [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
    [DllImport("iphlpapi.dll")] static extern uint GetExtendedTcpTable(IntPtr table, ref int size, bool order, int af, int tableClass, uint reserved);
    public static List<string> Processes(string prefix) {
        var result = new List<string>();
        IntPtr snap = CreateToolhelp32Snapshot(2, 0);
        if (snap == (IntPtr)(-1)) return result;
        var e = new PROCESSENTRY32W(); e.dwSize = (uint)Marshal.SizeOf(typeof(PROCESSENTRY32W));
        if (Process32FirstW(snap, ref e)) {
            do { if (e.szExeFile.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) result.Add(e.th32ProcessID + "|" + e.th32ParentProcessID + "|" + e.szExeFile); }
            while (Process32NextW(snap, ref e));
        }
        CloseHandle(snap);
        return result;
    }
    // IPv4 listeners: "pid|a.b.c.d:port"
    public static List<string> Listeners() {
        var result = new List<string>();
        int size = 0;
        GetExtendedTcpTable(IntPtr.Zero, ref size, false, 2, 3, 0); // TCP_TABLE_OWNER_PID_LISTENER
        IntPtr buf = Marshal.AllocHGlobal(size);
        try {
            if (GetExtendedTcpTable(buf, ref size, false, 2, 3, 0) != 0) return result;
            int n = Marshal.ReadInt32(buf);
            for (int i = 0; i < n; i++) {
                IntPtr row = buf + 4 + i * 24;
                uint addr = (uint)Marshal.ReadInt32(row + 4);
                int portRaw = Marshal.ReadInt32(row + 8);
                int port = ((portRaw & 0xff) << 8) | ((portRaw >> 8) & 0xff);
                uint pid = (uint)Marshal.ReadInt32(row + 20);
                string ip = (addr & 0xff) + "." + ((addr >> 8) & 0xff) + "." + ((addr >> 16) & 0xff) + "." + ((addr >> 24) & 0xff);
                result.Add(pid + "|" + ip + ":" + port);
            }
        } finally { Marshal.FreeHGlobal(buf); }
        return result;
    }
}
"@
$repo = $Repo
$bin = Join-Path $Exp "bin"
$probe = Join-Path $Exp ("runs\" + $Name)
New-Item -ItemType Directory -Force $probe | Out-Null
$out = Join-Path $probe "out"
$work = Join-Path $probe "work"
$argList = @()
if ($HostLabel -ne "") { $argList += @("-host-label", $HostLabel) }
$argList += @("custody", "-out", $out, "-work", $work, "-escalation", $Escalation)
$sw = [System.Diagnostics.Stopwatch]::StartNew()
$proc = Start-Process -FilePath (Join-Path $bin "agentgate-eval.exe") -ArgumentList $argList -WorkingDirectory $repo `
    -RedirectStandardOutput (Join-Path $probe "stdout.txt") -RedirectStandardError (Join-Path $probe "stderr.txt") -PassThru -NoNewWindow
$null = $proc.Handle # keep the handle so ExitCode is available
$root = [uint32]$proc.Id
$seen = [ordered]@{}
$listen = [ordered]@{}
$samples = 0
$tree = @{ ([string]$root) = $true }
while (-not $proc.HasExited) {
    $samples++
    $t = [int]$sw.ElapsedMilliseconds
    foreach ($line in [ProcProbe]::Processes("agentgate-")) {
        $f = $line.Split("|")
        $procId = $f[0]; $parent = $f[1]
        if ($procId -ne [string]$root -and -not $tree.ContainsKey($parent)) { continue } # not ours (other experiments run concurrently)
        $tree[$procId] = $true
        if (-not $seen.Contains($procId)) {
            $cmd = ""
            if (-not $NoCommandLine) { try { $cmd = (Get-CimInstance Win32_Process -Filter "ProcessId=$procId" -ErrorAction Stop).CommandLine } catch {} }
            $seen[$procId] = [pscustomobject]@{ pid = [int]$procId; ppid = [int]$parent; image = $f[2]; first_ms = $t; last_ms = $t; command = $cmd }
        } else { $seen[$procId].last_ms = $t }
    }
    foreach ($line in [ProcProbe]::Listeners()) {
        $f = $line.Split("|")
        if ($seen.Contains($f[0]) -and -not $listen.Contains($line)) {
            $listen[$line] = [pscustomobject]@{ pid = [int]$f[0]; image = $seen[$f[0]].image; address = $f[1]; first_ms = [int]$sw.ElapsedMilliseconds }
        }
    }
    Start-Sleep -Milliseconds 5
}
$proc.WaitForExit()
$seen.Values | Export-Csv -NoTypeInformation -Path (Join-Path $probe "processes.csv")
$listen.Values | Export-Csv -NoTypeInformation -Path (Join-Path $probe "listeners.csv")
"exit=$($proc.ExitCode) samples=$samples elapsed_ms=$($sw.ElapsedMilliseconds) eval_pid=$root" | Set-Content -Encoding utf8 (Join-Path $probe "monitor.txt")
Get-Content (Join-Path $probe "monitor.txt")
