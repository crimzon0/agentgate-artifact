#!/bin/sh
# Repetitions of the custody experiment (each: agentgate-eval custody + probe.py).
# usage: repeat.sh EXP REPO   (EXP/bin holds the built agentgate-*.exe; runs go to EXP/runs/<name>)
# then: python aggregate.py EXP <canonical custody.json> <canonical probe dir> <out dir>
EXP="$1"; REPO="$2"; SCRIPTS="$(cd "$(dirname "$0")" && pwd)"
cd "$REPO" || exit 2
run_one() { # name escalation
  name="$1"; esc="$2"; d="$EXP/runs/$name"; rm -rf "$d"; mkdir -p "$d"
  echo "== $name ($esc) $(date -u +%FT%TZ)"
  "$EXP/bin/agentgate-eval.exe" -host-label review-host custody -out "$d/out" -work "$d/work" -escalation "$esc" > "$d/stdout.txt" 2> "$d/stderr.txt"; echo "eval exit $?"
  python "$SCRIPTS/probe.py" "$EXP/bin" "$d/work" "$d/probe" "$d/out/custody.json" > "$d/probe-stdout.txt" 2>&1; echo "probe exit $?"
}
monitored() { # name escalation
  name="$1"; esc="$2"; d="$EXP/runs/$name"; rm -rf "$d"
  echo "== $name ($esc, monitored) $(date -u +%FT%TZ)"
  powershell -NoProfile -ExecutionPolicy Bypass -File "$SCRIPTS/monitor-run.ps1" -Exp "$EXP" -Name "$name" -Escalation "$esc" -Repo "$REPO"; echo "monitor exit $?"
  python "$SCRIPTS/probe.py" "$EXP/bin" "$d/work" "$d/probe" "$d/out/custody.json" > "$d/probe-stdout.txt" 2>&1; echo "probe exit $?"
}
monitored monitored-01 flag
monitored monitored-02 flag
for i in 01 02 03 04 05 06 07 08 09 10 11 12; do run_one repeat-flag-$i flag; done
for i in 01 02 03 04 05; do run_one repeat-deny-$i deny; done
echo "done $(date -u +%FT%TZ)"
