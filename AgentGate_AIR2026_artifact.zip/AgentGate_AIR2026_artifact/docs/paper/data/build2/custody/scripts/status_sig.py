"""Independent check of the witness's signed run status (GET /runs/{id}).

Verification only: an RFC 8032 Ed25519 verifier in pure Python (the reference
code of RFC 8032 section 6, verify half) and the run status message as
documented in internal/headwitness RunStatus / docs/demo/CONTRACTS.md. It
shares no code with the Go verifier (internal/auditverify) or the witness.
It holds no private key and signs nothing.
"""
import base64, hashlib

_p = 2 ** 255 - 19
_q = 2 ** 252 + 27742317777372353535851937790883648493


def _inv(x):
    return pow(x, _p - 2, _p)


_d = -121665 * _inv(121666) % _p
_sqrt_m1 = pow(2, (_p - 1) // 4, _p)


def _add(P, Q):
    A, B = (P[1] - P[0]) * (Q[1] - Q[0]) % _p, (P[1] + P[0]) * (Q[1] + Q[0]) % _p
    C, D = 2 * P[3] * Q[3] * _d % _p, 2 * P[2] * Q[2] % _p
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F, G * H, F * G, E * H)


def _mul(s, P):
    Q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            Q = _add(Q, P)
        P = _add(P, P)
        s >>= 1
    return Q


def _equal(P, Q):
    return (P[0] * Q[2] - Q[0] * P[2]) % _p == 0 and (P[1] * Q[2] - Q[1] * P[2]) % _p == 0


def _recover_x(y, sign):
    if y >= _p:
        return None
    x2 = (y * y - 1) * _inv(_d * y * y + 1) % _p
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (_p + 3) // 8, _p)
    if (x * x - x2) % _p != 0:
        x = x * _sqrt_m1 % _p
    if (x * x - x2) % _p != 0:
        return None
    if (x & 1) != sign:
        x = _p - x
    return x


_gy = 4 * _inv(5) % _p
_gx = _recover_x(_gy, 0)
_G = (_gx, _gy, 1, _gx * _gy % _p)


def _decompress(s):
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _recover_x(y, sign)
    return None if x is None else (x, y, 1, x * y % _p)


def ed25519_verify(public, message, signature):
    """True when signature is a valid Ed25519 signature of message under public (32 bytes)."""
    if len(public) != 32 or len(signature) != 64:
        return False
    A = _decompress(public)
    R = _decompress(signature[:32])
    if A is None or R is None:
        return False
    s = int.from_bytes(signature[32:], "little")
    if s >= _q:
        return False
    h = int.from_bytes(hashlib.sha512(signature[:32] + public + message).digest(), "little") % _q
    return _equal(_mul(s, _G), _add(R, _mul(h, A)))


def _self_test():
    # RFC 8032 section 7.1, TEST 1 (empty message)
    pub = bytes.fromhex("d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a")
    sig = bytes.fromhex("e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b")
    assert ed25519_verify(pub, b"", sig), "RFC 8032 test 1 does not verify"
    assert not ed25519_verify(pub, b"x", sig), "RFC 8032 test 1 verifies a different message"


_self_test()

RUN_STATUS_FORMAT = "agentgate-witness-run-status/v1"
RUN_STATUS_LABEL = "AgentGate/WitnessRunStatus/v1"


def run_status_message(s):
    """The bytes the witness signs for run status s (a parsed GET /runs/{id} body)."""
    c = s.get("continues") or {}
    fields = [RUN_STATUS_LABEL, s.get("run_id", ""), s.get("keys_sha256", ""), s.get("audit_kid", ""),
              s.get("audit_public_key", ""), "1" if s.get("keys_file_verified") else "0", s.get("registered_at", ""),
              c.get("run_id", ""), c.get("final_head", ""), c.get("keys_sha256", ""), s.get("continued_by", ""),
              str(s.get("latest_index", 0)), str(s.get("latest_seq", 0)), s.get("latest_entry_hash", ""), s.get("status_at", "")]
    return "\x00".join(fields).encode()


def check_run_status(s, witness_key_hex):
    """(signature_ok, problem) for run status s against the witness public key (64 hex)."""
    if not isinstance(s, dict):
        return False, "not a JSON object"
    if s.get("format") != RUN_STATUS_FORMAT:
        return False, "format %r" % s.get("format")
    key = bytes.fromhex(witness_key_hex)
    if s.get("witness_kid", "").lower() != hashlib.sha256(key).hexdigest() or s.get("witness_public_key") != base64.b64encode(key).decode():
        return False, "names another witness key"
    try:
        signature = base64.b64decode(s.get("witness_signature", ""), validate=True)
    except Exception:
        return False, "witness_signature is not base64"
    if not ed25519_verify(key, run_status_message(s), signature):
        return False, "witness_signature does not verify"
    return True, ""
