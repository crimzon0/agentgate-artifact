"""Collect the self-test tamper lab of the canonical custody run and its repetitions.

Usage: python tamper_lab.py EXP CANONICAL_CUSTODY_JSON CANONICAL_WORK OUT_CSV
  EXP/runs/<name>/{out/custody.json, work/} are the repetitions (repeat.sh).
Reads <work>/runs/<run id>/selftest-report.json ("tampers") of every run and
writes one row per run and attack: the verdict without anchors (naive), the
verdict with the run's keys and final head pinned (anchored), and the checks
that failed in the anchored verification.
"""
import csv, glob, json, os, sys

exp, canonical_json, canonical_work, out_csv = sys.argv[1:5]
runs = [("canonical", canonical_json, canonical_work)]
for d in sorted(glob.glob(os.path.join(exp, "runs", "*", ""))):
    name = os.path.basename(os.path.dirname(d))
    runs.append((name, os.path.join(d, "out", "custody.json"), os.path.join(d, "work")))

rows = []
for name, cj, work in runs:
    custody = json.load(open(cj, encoding="utf-8"))
    run_id = custody["facts"]["run_id"]
    report = json.load(open(os.path.join(work, "runs", run_id, "selftest-report.json"), encoding="utf-8"))
    mode = report.get("escalation") or ("deny" if "deny" in name else "flag")
    for t in report["tampers"]:
        rows.append({"run": name, "mode": mode, "attack": t["kind"], "naive_verdict": t.get("naive_verdict", ""),
                     "anchored_verdict": t["verdict"], "detected": t["detected"],
                     "failed_checks_anchored": " ".join(t.get("failed_checks") or [])})
with open(out_csv, "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(rows)
naive = sum(1 for r in rows if r["attack"] != "rollback" and r["naive_verdict"] == "FAILED")
anch = sum(1 for r in rows if r["attack"] != "rollback" and r["anchored_verdict"] == "FAILED")
ordinary = sum(1 for r in rows if r["attack"] != "rollback")
rb = [r for r in rows if r["attack"] == "rollback"]
print("runs %d; ordinary edits detected without anchors %d/%d, with keys+head pinned %d/%d; rollback without anchors %d/%d, with %d/%d"
      % (len(runs), naive, ordinary, anch, ordinary, sum(r["naive_verdict"] == "FAILED" for r in rb), len(rb),
         sum(r["anchored_verdict"] == "FAILED" for r in rb), len(rb)))
