# Added after the build-2 freeze

`ROUND4_SIGNED_ATTACKS.md`, this note, the fixture helper
`internal/auditverify/fixture/held.go` (`ResignHeld`, `RestoreUnheld`) and the
tests `internal/auditverify/round4_signed_attacks_test.go`,
`round4_signed_fields_test.go` and `round4_lifecycle_test.go` were written on
2026-10-19, after build 2 was frozen at commit `86643d7` (2026-10-10). They
are not listed in `build-manifest.txt` and are not compiled into any frozen
binary: they are test-only (the fixture package is imported only by
`_test.go` files) and they compile against the unchanged frozen sources. How
this was checked: `git diff --stat 86643d7 -- internal cmd go.mod go.sum`
lists only the four files above plus `cmd/agentgate-killsuite/README.md`, a
documentation file changed before these tests (commits `ac5c2a9` and `816b1df`)
and not compiled; `sha256sum -c` over the module section of
`../build-manifest.txt` (the 256 repository files compiled into the six
frozen binaries) gives 256/256 OK, and over the 59 test-only files listed in
`build-manifest.txt` here gives 59/59 OK. The numbers of these tests come from
`go test`, not from the frozen binaries, and are reported in
`ROUND4_SIGNED_ATTACKS.md`.
