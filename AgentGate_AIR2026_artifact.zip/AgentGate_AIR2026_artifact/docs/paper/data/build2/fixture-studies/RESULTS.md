# Fixture studies on build 2 (lifecycle, key sets, registration, clocks, flagged recovery)

> **Correction note (2026-10-10, honesty sweep; the record below is
> unchanged).** "Keys needed" and "needs" (§2.2, §2.4, §3) mean the smallest
> key set that passed among those the fixture tests tried; they are not proofs
> that fewer keys cannot succeed. X is the three adapter keys together, and
> only in the simulation; key counts count roles, all held in one process. Log:
> `docs/paper/artifact/HONESTY_SWEEP.md`.

**Experiment:** fixture-studies. This experiment is new in build 2. It answers
the supervisor's second review: major comments 2 (lifecycle), 3 (real
signatures and missing key sets) and 5 (registration, freshness and clocks),
plus the flagged-recovery path the build-2 gateway fixes.

**Run:** 2026-10-10, 02:26:54Z to 02:44:19Z.

**Source:** commit `86643d7` on branch `claude/supervisor-demo`. This is the
same commit the six frozen build-2 binaries come from. The working tree
equals the commit; `build-manifest.txt` has the record.

**Test code only.** None of the six frozen binaries runs here. The tests are
compiled from the same source:

- Every repository file that is also compiled into the frozen binaries (239
  of the 298 files in the four test binaries) is hash-equal to the build-2
  `MANIFEST.txt`.
- The other 59 files are test-only, and their hashes are listed in
  `build-manifest.txt`.

`check_manifest.py` ran before (02:26:54Z) and after (02:44:18Z) the runs. Both
times it reported **1,868 files checked, 0 differ**.

## 1. What was run

There were eight runs. Each ran twice, with the same outcome both times:

- **Primary:** the hashed test binary, run from its package directory.
- **Cross-check:** the literal `go test -v -count=1 -run '<regex>' ./<pkg>/`.

After timings and the final `ok` line are removed, the two logs are identical
for all eight runs. `run_studies.sh` holds the exact regexes.

| run | package | `-run` |
|---|---|---|
| s1 lifecycle (brief item 1) | `./internal/auditverify/` | `TestLifecycle\|TestRecoveryRecords\|TestReconciledAdapterReceipt\|TestReplayedAndConfirming` |
| s1b lifecycle states (supplement) | `./internal/auditverify/` | `^(TestClassificationEvidenceByLifecycleState\|TestUnboundFlagsTextsNameTheLogNotTheCapability)$` |
| s2 extra key sets (item 2) | `./internal/auditverify/` | `TestExtraKeySets` |
| s3a registration attacks (item 3) | `./internal/headwitness/` | the 4 tests of `registration_attack_test.go` |
| s3b verifier clock and freshness (item 3) | `./internal/auditverify/` | the 7 tests of `clock_test.go` and the 9 of `freshness_test.go` |
| s4 gateway clock and restart flag (item 4) | `./internal/devcomposition/` | the 5 tests of `clock_attack_test.go` and the 5 of `restart_flag_test.go` |
| s5 flagged recovery end to end (item 5) | `./cmd/agentgate-eval/` | `^TestFlaggedOperationRecoveryVerifies$` |
| s6 simulation validation (item 6) | `./internal/auditverify/` | `^(TestSimulationAgreesWithRealAuditKeyResigning\|TestEachRoleUnderSimulation)$` |

Environment:

```
GOMODCACHE=<repo>/.tools/go-host-cache-20260916/mod GOPROXY=off GOFLAGS=-mod=readonly GOTOOLCHAIN=local
REPO=<repo> W=<scratch>/build2-work/fixture-studies bash run_studies.sh
python sanitize_logs.py <scratch>/build2-work/fixture-studies/raw
python analyze_fixture_studies.py            # reads logs/ and ../../revision/compromise/cells.csv
```

Two further runs supported the analysis:

- **s6 on the build-1 tree.** The tree is extracted with
  `git archive 2d32506 go.mod go.sum internal cmd`. Its 244 module files
  compiled into the build-1 binaries match the build-1 manifest 244/244.
- **Overlay probe.** `probe/zz_fixture_study_probe_test.go`, compiled in
  through `go test -overlay`. Nothing is written into `<repo>`. Its purpose is
  to explain the one disagreement with the frozen grid (§3.3).

**Outcome:** 8/8 runs PASS. That is 46 top-level tests and 88 subtests, with
0 failures and 0 skips (`tests.csv`). The probe passes too.

**Kind of evidence.** Every result below is marked with one of these labels:

- **REAL-FX:** real Ed25519 signatures made with the fixture's in-memory keys
  on synthetic fixture runs. The roles used are:
  - the audit key (`fixture.RewriteLogWithAuditKey` re-chains and re-signs
    the log and `head.json`);
  - the issuer key (`fixture.ResignCapability`);
  - the provider key, for a provider-signed status observation or a forged
    ABSENT;
  - the witness key, for cosigned heads and signed run status.

  The keys anchor is the genuine run's `keys.json` fingerprint. It is taken
  before the mutation, so it is pinned independently of the mutated folder.
- **REAL-GW:** the real gateway code running in process, with its own
  generated per-run keys. The simulated provider runs in process or on
  loopback.
- **SIM:** the verifier-side key-compromise simulation
  (`Options.AssumeCompromised`). Signatures of the assumed roles are accepted
  without checking. This is a structural attack model, not cryptographic
  exploitation.

**Key-set notation:**

| symbol | meaning |
|---|---|
| A | audit key |
| I | capability issuer key |
| X | the simulation's `ADAPTER` role, which covers all three adapter keys (message, document, financial) together |
| P | provider key |
| Ap | approval key |
| status | a genuine provider-signed status observation for a receipt |

**Notes on the notation:**

- Partial adapter compromise is not tested here.
- No real-signature test here uses an adapter key.
- "status" needs no attacker key. In the prototype, the provider's status
  endpoint answers any local caller. The fixture's provider key signs the
  observation in its place.

## 2. Lifecycle results (s1, s1b; all REAL-FX)

The lifecycle tests make 85 verifications in total, and 63 of them are printed
(`lifecycle.csv`). The target is the fixture's flagged payment unless stated
otherwise. The verifier setting is `full` and the anchor is the genuine keys
fingerprint, unless stated otherwise.

### 2.1 Genuine lifecycle states (no key held; s1b, asserted)

| lifecycle state | operations in the genuine run | classification evidence reported | flag |
|---|---|---|---|
| executed, `EFFECT_EXECUTED` with an adapter receipt | 5/13 | `issuer_adapter`: capability and adapter receipt both sign the decision | reported (3 operations flagged in the run) |
| executed only by `RECONCILED`-committed, no adapter receipt | 1/13 | `issuer_only_reconciled`, plus a Missing entry (kind `issuer_only`): "1 operation was executed only according to a RECONCILED entry" | from the capability |
| `UNCERTAIN` after a verified capability | 1/13 | `issuer_only_unresolved`; `run_complete` fails | from the capability. This one is unflagged (FIN-AUTO), so `flagged_unconfirmed` is 0 |
| no verified capability (denied, blocked, refused, over budget, revoked, zero) | 6/13 | `audit_only` | rests on audit entries |
| the `UNCERTAIN` payment settled by the provider's genuine ABSENT (key A for the rewrite) | 1 | `not_committed`, `issuer_only_no_effect`, VERIFIED | none |
| unbound-flags ablation (whole run) | 13/13 | `audit_only` | — |

### 2.2 Attacks per lifecycle state: keys needed and what the verifier reports

- **L1, keys A.** The flagged execution is restated as `RECONCILIATION_REQUIRED`
  or `UNCERTAIN`: `EFFECT_EXECUTED` is deleted and the flag is dropped from
  `CALL_RESULT`.
  - Verdict: **VERIFIED in 8/8 cases** (2 statuses x 4 settings; CONSISTENT).
  - The downgrade is not refused, but it is reported. The operation is still
    **flagged** (bound by the capability) and is reported
    `issuer_only_unresolved`, with `flagged_unconfirmed`=1. There is a
    warning from `op.outcome_resolved` ("the provider journal shows it
    committed"), a Missing entry, and `run_complete`=fail.
  - The keys and head anchors detect it: **FAILED `head.anchor` in 2/2**.
- **L1b, A vs A+I.** The grid's strip-flag edit, then the execution deleted and
  the call restated `UNCERTAIN`. The verifier runs without replay.
  - A: **FAILED** (`artifact.signature`, `op.capability_bound`,
    `provider.matches_audit`).
  - A+I, with the capability re-signed: **VERIFIED, unflagged,
    `issuer_only_unresolved`**.
  - A+I under the full verifier: **`policy.replay` fails**.
- **Capability deletion on an uncommitted UNCERTAIN operation, A.**
  **VERIFIED**. The operation stays `uncertain` and its classification falls
  to `audit_only`. The fixture operation is unflagged. With a provider commit,
  the same deletion fails `provider.matches_audit` (§2.3).
- **L2, A + status.** The execution is converted in place to
  `RECONCILED`-committed: the adapter receipt is dropped, the flag is kept,
  and the observation is dated 2027-06-01, months after the run.
  - Verdict: **VERIFIED in 4/4 settings**: executed, flagged, reconciled,
    **`issuer_only_reconciled`**.
  - Missing reads "2 operations were executed only according to a RECONCILED
    entry".
  - So the weaker guarantee is **reported explicitly**. The verifier does not
    date observations against the run.
- **Recovery records state the bound flag, A (+ status).**
  - 5 of the 7 cases fail with only `op.requires_policy` failing: `RECONCILED`
    drops the flag; `CALL_RESULT` drops it (twice: by entry and by
    `call_id`); a genuine reconciliation invents a flag; a confirming
    reconciliation drops it.
  - The 2 consistent cases are VERIFIED.
- **Replayed and confirming answers, A (+ status).**
  - 3 of the 6 cases fail with only `op.requires_policy` failing: a replay
    drops the flag; a replay invents a flag on an unflagged commit; the
    confirming call's `CALL_RESULT` drops it.
  - The 3 consistent cases are VERIFIED.
- **Adapter receipt carried by `RECONCILED`, A + status.**
  - The genuine receipt gives **VERIFIED, `issuer_adapter`** in 2/2 cases
    (recording and confirming).
  - An edited receipt payload fails `artifact.signature` and
    `op.receipts_bound`.
  - Another operation's genuine receipt fails `op.receipts_bound` in 2/2
    cases.
  - A+I strip-flag, converted, with the original receipt kept and no replay:
    fails `op.receipts_bound`. Dropping the receipt instead is accepted (L3).
- **L3, A vs A+I (+ status), verifier without `policy.replay`.** The twelve
  no-replay grid flips are 3 operators (strip-flag, invent-flag, change-rules)
  x {A, A+I} x anchors {none, keys}.
  - With the **execution kept**, 6/6 are detected (A: `artifact.signature`,
    `op.capability_bound`, `op.receipts_bound`; A+I: `artifact.signature`,
    `op.receipts_bound`). This reproduces the grid.
  - **Converted** to `RECONCILED`-committed:
    - **A: 0/6 accepted** (`artifact.signature`, `op.capability_bound`,
      `op.outcome_resolved`);
    - **A+I: 6/6 accepted**: VERIFIED, `issuer_only_reconciled`, with the flag
      the attacker chose.
  - The full verifier catches 3/3 A+I conversions (`policy.replay`). A head
    anchor catches 3/3 (`head.anchor`).
- **L4, A+I + status, full verifier (forge-restate).**
  - With the executions kept, the attack fails in 2/2 cases (`artifact.signature`,
    `op.receipts_bound`).
  - With **every execution converted**, so that no adapter receipt has to
    match the restated policy hash: **VERIFIED in 8/8** (strip-flag and
    invent-flag x 4 settings, full included). All 6 executed operations are
    `issuer_only_reconciled`.
  - change-rules: forge-restate does not apply to this fixture.
  - A head anchor catches 2/2.

**Count statement.** On the reconciliation path the no-replay gain is
A -> A+I (6 of the 12 grid flips are A+I cells).

- In the frozen grid (`flips.csv`, identical in build 1 and build 2), each
  no-replay configuration has 12 binding flips: 6 with key set `audit` and 6
  with `audit+issuer`.
- Once the execution is settled by reconciliation, the bound design accepts
  the A+I mutant in 6/6 cells (needing only a status observation, no key).
  The A-only cells stay detected (0/6).
- So on this path binding raises the requirement from A to A+I, not from A to
  A+I+X. Only the 6 A-only cells remain differences between the designs.
- Under the full verifier, the same path lowers the bound design's flag
  forgery from A+I+X to A+I (+ status) (L4).

### 2.3 Conflicting and mixed histories (12 cases, full verifier, keys anchor)

| history (flagged payment) | keys | result |
|---|---|---|
| execution, then `RECONCILED` not_committed with a provider-signed ABSENT | A+P (real provider-key forgery) | FAILED: `op.outcome_resolved`, `provider.matches_audit` |
| execution, then a confirming `RECONCILED` committed | A+status | VERIFIED, `issuer_adapter` (receipt still binds) |
| `RECONCILED` committed inserted before the genuine execution | A+status | FAILED: `op.single_use` |
| the same commit reconciled twice | A+status | VERIFIED, `issuer_only_reconciled`, effects counted once (6) |
| reconciled twice with contradicting flags | A+status | FAILED: `op.requires_policy` |
| `RECONCILED` committed carrying another operation's observation | A | FAILED: `op.outcome_resolved`, `provider.matches_audit` |
| execution, then `CALL_RESULT` restated `UNCERTAIN` | A | FAILED: `op.outcome_resolved` |
| execution, then `CALL_RESULT` restated `RECONCILIATION_REQUIRED` | A | VERIFIED, still executed and flagged, `issuer_adapter`; warning; `run_complete` fail |
| adapter receipt removed from the execution | A | FAILED: `op.receipts_bound` |
| adapter receipt replaced by another operation's genuine one | A | FAILED: `op.receipts_bound`, `op.single_use` |
| capability deleted, execution restated `UNCERTAIN`, provider commit kept | A | FAILED: `provider.matches_audit` |
| capability deleted, execution converted to `RECONCILED` committed | A+status | FAILED: `op.outcome_resolved` |

Totals: **9/12 detected and 3/12 VERIFIED**. All 3 VERIFIED cases keep the
flag and say how strong the evidence is.

### 2.4 Keys needed per state (summary)

| state of the flagged operation | changing its classification undetected needs | the verifier reports |
|---|---|---|
| executed with `EFFECT_EXECUTED` and an adapter receipt | no replay: A+I+X (grid, SIM). Full: A+I+X with forge-restate (grid, SIM) | `issuer_adapter` |
| executed only by `RECONCILED`, no adapter receipt | no replay: **A+I+status** (L3, 6/6). Full: **A+I+status** with forge-restate and all executions converted (L4, 8/8). A alone: detected (L3 0/6; recovery-record rule 5/5) | `issuer_only_reconciled`, plus a Missing `issuer_only` entry |
| executed by `RECONCILED` with the genuine adapter receipt | same as `EFFECT_EXECUTED`; a wrong or edited receipt fails `op.receipts_bound` (3/3) | `issuer_adapter` |
| `UNCERTAIN` / `RECONCILIATION_REQUIRED` | downgrading an execution needs A, but the flag survives (L1). Stripping the flag needs A+I without replay; the full verifier catches it (L1b) | `issuer_only_unresolved`, flagged-unconfirmed count, warning, Missing, `run_complete` fail |
| not committed (`RECONCILED` ABSENT) | asserting ABSENT for a committed receipt needs P, and is still detected | `issuer_only_no_effect` |
| no verified capability | A (audit entries only) | `audit_only` |

Every rewrite above needs the audit key, and every one that a head anchor was
applied to is detected by it.

## 3. Key sets A+X, A+P, I+X (s2; SIM on fixture runs)

### 3.1 Scope

- 22 mutants: 7 operators x applicable variants x 2 designs. Another 20
  combinations do not apply.
- **56 independent cells**: 2 designs x 7 operators x 4 settings, no anchors.
- 88 (cell, variant) pairs, and **616 independent verifications** (88 x 7 key
  sets).
- The 56 keys-anchored cells (616 verifications) repeat their unanchored
  outcome exactly, so they are not counted.
- A further 128 clean controls (4 base runs x 8 role lists x 4 settings) are
  all VERIFIED. That makes 1,360 verifications in all.

### 3.2 Results

**Accepted cells per key set (strongest variant):**

| setting | A | A+I | A+I+X | A+I+X+Ap | **A+X** | **A+P** | **I+X** |
|---|---|---|---|---|---|---|---|
| full | 0/14 | 0/14 | 6/14 | 6/14 | 0/14 | 0/14 | 0/14 |
| no-replay | 3/14 | 3/14 | 8/14 | 8/14 | 3/14 | 3/14 | 0/14 |
| no-replay-no-snapshot | 3/14 | 3/14 | 8/14 | 8/14 | 3/14 | 3/14 | 0/14 |
| no-snapshot-bound-only | 2/14 | 2/14 | 6/14 | 6/14 | 2/14 | 2/14 | 0/14 |
| **all** | 8/56 | 8/56 | 28/56 | 28/56 | **8/56** | **8/56** | **0/56** |

**The new key sets:**

- **A+X:** where A+I+X was the smallest tested set, A+X was detected in
  **20/20 cells** (34/34 pairs). A+X equals A in **56/56 cells** (88/88
  pairs).
- **A+P:** equals A in **56/56 cells** (88/88 pairs).
  - On 20/22 mutants this holds by construction: they edit no
    provider-signed artifact.
  - The other 2 mutants (change-amount plain, bound and unbound) do edit one.
    They are detected under every tested set in 8/8 of their pairs, because
    no set holds P together with I and X.
- **I+X:** **0/56 accepted**, and detected in 20/20 of the cells that needed
  A+I+X. This holds by construction: all 22 mutants edit `audit.jsonl`.

**Other observations:**

- The A+I+X+Ap branch is never needed: it was the smallest set in 0 cells.
- no-replay-no-snapshot equals no-replay in 14/14 cells.

### 3.3 Agreement with the frozen 336-cell grid

The four shared key sets are A, A+I, A+I+X and A+I+X+Ap, compared at anchors
none (`fixture_vs_frozen_grid.csv`). The build-1 and build-2 grid `cells.csv`
files are byte-identical (SHA-256 `c77317cd...`).

- **216/224 agree.**
- **All 8 disagreements are relabel-approved under A+I+X and A+I+X+Ap, in the
  full and no-snapshot-bound-only settings, for both designs.** The fixture
  accepts these cells; the gateway grid detects them by `policy.replay`.

**Cause, confirmed by the probe** (`logs/probe-relabel-approved.log`):

- The human-mode fixture's `run.json` has no policy snapshot. So
  `policy_replayed` is `not_checked` in every setting, and the fixture's
  "full" setting is effectively no-replay for that operator.
- The gateway's human-mode runs carry a snapshot.
- In the no-replay settings, the fixture and the grid agree (accepted under
  A+I+X).

This is a limitation of the fixture, not a difference between builds. Without
relabel-approved, the fixture's full row for A+I+X is 4/12, the same cells the
grid accepts (strip-flag and invent-flag, both designs).

## 4. Registration attacks before first enrollment (s3a; REAL-FX, real witness service in process)

- **Control:** a genuine restart against a real witness gives **VERIFIED and
  ANCHORED, 2 segments**.
- **Preemption.** The attacker registers the run ID first, with its own audit
  key. Result in **2/2 cases: never ANCHORED.**
  - The genuine registration is refused (`ErrRunConflict`). The genuine head
    push is refused (`ErrInvalidHead`, "not the registered audit key").
  - Before the attacker pushes, there is no head to fetch, and the genuine
    folder is CONSISTENT.
  - After the attacker pushes, with the attacker's own fingerprint: FAILED,
    `keys.anchor` ("these are not the keys this run started with").
  - After the attacker pushes, with the genuine fingerprint copied: FAILED,
    with only `head.witness` failing ("the head it cosigned is not signed by
    this run's audit key"). The keys match, and the anchor is still invalid.
- **Substitution.** A false continuation is registered first. The result is
  **denial of anchoring, never a false ANCHORED**:
  - The genuine continuation is refused (`ErrContinuity`), and its pushes
    and latest-head requests return `ErrUnknownRun`.
  - Segment 1 is FAILED with only `head.anchor` failing ("was continued by
    run ..."), while its keys stay anchored.
  - Genuine segment 2 with no witness answer is VERIFIED and CONSISTENT.
    Given segment 1's answers, it fails `head.witness`.
- **Counterexample: a false continuation registered first is ANCHORED.** The
  forged segment uses keys generated for it and the grant copied from segment
  1's public log, and no private key of the genuine run. Results:
  - The genuine continuation is refused.
  - The forged chain verifies **VERIFIED and ANCHORED, 2 segments**.
  - A first registration made by the test (not by a gateway) is also
    ANCHORED.

  So **ANCHORED never establishes gateway origin**. Only authenticated
  enrollment, which is not implemented, would close this.

## 5. Clocks

### 5.1 Gateway (s4; REAL-GW, unit-level injection of the registry and delegation clocks, not the OS clock)

These are the in-process fail-closed results:

- **Backward step.** A step 30 s below the capability registry's last reading
  gives **REJECTED** (`capability_refused`). Nothing is issued or
  dispatched, and the commit count stays at 1. Once the clock is back, the
  next payment is COMMITTED (2 commits).
- **Forward jump between issue and consume:**
  - +61 s, past the 60 s capability lifetime: **REJECTED**
    (`dispatch_refused`). The capability is never consumed, there is no
    dispatch intent, and there are 0 commits.
  - +48 s: COMMITTED once.

Expired-grant revival (counterexamples, asserted):

- **In process.** The grant ends at +600 s. A payment at +900 s is denied
  with DEL-EXPIRED. Rolled back to +0 s, which is still at or above the
  registry's floor, the next payment is **COMMITTED**: the expired grant
  revives (2 committed payments in the ledger). A denied call never reads the
  registry clock, and the delegation window has no floor.
- **Across a restart.** In the first process:
  - +48 s: commit;
  - +900 s: DEL-EXPIRED;
  - rolled back to +0 s: refused, so the floor holds in process;
  - +500 s: `RECONCILIATION_REQUIRED` (evidence_incomplete), with the
    provider applying the payment.

  Restarted on the same journal at +0 s, the journal is restored: 4 outcomes,
  1 committed payment and 1 reserved. The journaled capability expiry is 500
  s or more after the restart clock, and the restore ignores it. **A new
  payment is COMMITTED under the expired grant**, without DEL-EXPIRED.
- **Audit writer.** The writer clamps a backward step: the entry times are
  t, t+1 s, t+1 s, t+2 s. An honest clock step leaves equal timestamps.

### 5.2 Verifier time windows (s3b; REAL-FX, fixture witness key)

**Witness status window** (MaxWitnessStatusSkew = 2 min, inclusive):

- Fetched exactly 2 min, or 2 min minus 1 s, from signing, on either side:
  accepted (ANCHORED) in 4/4 cases.
- Fetched 2 min plus 1 ns, or 2 min plus 1 s, from signing, on either side:
  refused (`head.witness`, so the witness anchors nothing) in 4/4 cases.
- A status signed 1 ns before its head was cosigned is refused. One signed at
  the same instant is accepted.

**Gateway entry times:**

- A backward step of 1 s or 1 ns inside a segment fails `chain.time`. Equal
  times pass.
- A forward jump of +1 h inside a segment verifies (ANCHORED).
- A forward jump of +48 h fails `delegation.window` ("outside the grant's
  validity window"). `chain.time` passes in both cases.

**Documented gaps, each VERIFIED:**

- the witness clock 1 min behind the head time (ANCHORED);
- a restart segment that starts 1 min before the previous segment ends
  (ANCHORED with anchors supplied by the folder itself);
- a recorded gap between issue and execution that is longer than the
  capability lifetime. The verifier never compares entry times with a
  capability's iat/exp.

**Freshness:**

- A saved or pinned head is still **ANCHORED**, but now with
  **`head_fresh`=not_checked and `run_complete`=not_checked**, plus a Missing
  entry "Head not shown to be fresh". This includes the coherent rollback to a
  saved head that the custody study measured.
- A live signed status fetched 30 s after signing passes `head_fresh` and
  `run_complete`. Without a fetch time, both are not_checked.
- Received 2 min plus 1 s from signing: `head.witness` fails, and both
  `head_fresh` and `run_complete` fail.
- A fresh status that names a continuation: `head_fresh` passes,
  `run_complete` fails.
- One UNCERTAIN operation makes `run_complete` fail even though the run is
  ANCHORED.
- `MissingKinds` per run: 1 freshness, 1 unresolved and 1 issuer_only entry.

## 6. Flagged recovery end to end (s5; REAL-GW, eval harness, loopback provider, `auditverify`)

The case matrix is 4 fault points x 3 ways to reach the retry (no restart, a
restart on the journal, a restart on a journal cut after the dispatch intent).
All **12/12 pass.**

- **Evidence folders:** every one of the **20** folders (4 x (1 + 2 + 2)
  segments) is **VERIFIED and ANCHORED** with the pinned keys and head.
- **The operation:** executed, **flagged**, reconciled. The provider holds
  **exactly 1 commit** for it in 12/12 cases.
- **Recovery records:** `RECONCILED` is committed and flagged, and the
  reconciling `CALL_RESULT` is flagged, in 12/12 cases.

Classification evidence by fault point:

| fault point | no restart | either restart |
|---|---|---|
| provider_response_lost | `issuer_only_reconciled` | `issuer_only_reconciled` |
| head_replace (`EFFECT_EXECUTED` in the log) | `issuer_adapter` | `issuer_adapter` |
| after_receipt_before_audit | `issuer_adapter` (`RECONCILED` carries the receipt) | `issuer_only_reconciled` (the receipt was only in memory) |
| audit_append | `issuer_adapter` (`RECONCILED` carries the receipt) | `issuer_only_reconciled` (the receipt was only in memory) |

**Gateway restart-flag tests (s4, REAL-GW, all pass):**

- **Crash after the dispatch intent** (4 cases: flagged or plain, x retry or
  `Reconcile`):
  - The operation is restored as UNCERTAIN, with the ledger flag equal to
    the decision's.
  - `RECONCILED` states the flag if and only if the decision was flagged.
  - Stored answers keep the flag, also after a second restart.
  - There is 1 commit in each case.
- **Replayed COMMITTED answers keep the flag** (3 cases): in the same process
  (twice) and after a restart.
- **Not committed:** `RECONCILED` not_committed and every stored answer state
  no flag, with 0 commits, while the ledger keeps the flag.
- **Expired-lease intent:** carries flagged=true.
- **Old journal format:** an intent without the flag field restores the
  operation unflagged.

## 7. Simulation validation (s6)

- **`TestSimulationAgreesWithRealAuditKeyResigning`** (REAL-FX vs SIM): 11
  edits x 4 anchor conditions = **44/44 cells identical** between real
  audit-key re-signing and the simulation (verdict, assurance, failing checks
  with counts).
  - The audit key alone can delete a denial or hide a reconciliation, and
    these stay VERIFIED/CONSISTENT unless a head anchor is given (2 edits x 2
    unanchored conditions).
  - Only "nothing changed" reaches ANCHORED, and only with both anchors.
- **`TestEachRoleUnderSimulation`** (SIM): 11/11 role cases pass. The roles
  are audit, issuer, adapter, provider, organisation and approval.
  - 5 cases make an edit that no other check covers (audit, issuer, adapter,
    provider, approval). Each is accepted with its role assumed, and the
    same edit fails the signature check without that role.
  - 6 cases make an edit that another check still catches with the role
    assumed: `op.requires_policy`/`policy.replay`, `op.receipts_bound`/
    `policy.snapshot_bound`, `op.receipts_bound`, `op.outcome_resolved`,
    `delegation.grant` and `op.approval_bound`.

## 8. Comparison with build 1

| headline | build 1 (2026-10-08) | build 2 | difference and cause |
|---|---|---|---|
| simulation vs real audit-key re-signing | 44/44 identical | 44/44 identical. Rerun on the build-1 tree: 44/44 cells identical to build 2 (`simulation_agreement.csv`) | **none**. The build-2 verifier changes (`head_fresh`, `run_complete`, classification evidence, Missing kinds, recovery-flag checks) change no verdict, assurance or failing check for these edits |
| per-role simulation checks | PASS | 11/11 PASS, the same case list on the build-1 tree | none |
| roles validated with real signatures | audit key only | audit (A), issuer (I, `fixture.ResignCapability` in L1b/L3/L4), provider (one forged ABSENT, A+P, detected) and witness, all REAL-FX | **new tests in build 2** (`afe8730`, `abfe013`, `d084ef9`, `682d37e`). In these studies, adapter and approval keys are still never used to re-sign an attack |
| key sets A+X, A+P, I+X | not tested | A+X 8/56 (= A), A+P 8/56 (= A), I+X 0/56 (SIM, 56 independent cells) | new (`keysets_extra_test.go`). A+P = A and I+X = 0 hold by construction |
| no-replay binding flips | 12 per no-replay configuration (6 A, 6 A+I) | grid unchanged; on the reconciliation path the 6 A+I cells are accepted in the bound design (6/6) and the 6 A cells stay detected (0/6) | **new qualification** from L3, not a change of the grid. It rests on the existing rule that a `RECONCILED` entry need not carry an adapter receipt. Build 2 checks a receipt when one is attached, but still does not require one |
| recovery paths under attack | not mutation-tested | 10 lifecycle tests (30 subtests, 85 verifications): weaker evidence is reported (`issuer_only_*`, Missing kinds, `run_complete`), and recovery records must state the bound flag | **build-2 verifier changes** (classification evidence, recovery and replay flag checks, receipt on `RECONCILED`) |
| stale saved head | accepted as ANCHORED, with no freshness output | still ANCHORED, now with `head_fresh`/`run_complete` = not_checked and a Missing freshness entry | **build-2 verifier change** (`head_fresh`, `run_complete`) |
| registration preemption / substitution | not tested | preemption 2/2 never ANCHORED; substitution denies anchoring; forged continuation registered first is ANCHORED (counterexample) | new tests |
| clock attacks | not tested | in-process fail-closed; 2 expired-grant revival counterexamples; verifier windows as in §5.2 | new tests; no gateway clock change in build 2 |
| flagged recovery end to end | not tested; a build-1 gateway restarted after the intent wrote `RECONCILED` without the flag (per the test's comment) | 12/12 VERIFIED/ANCHORED, flag kept, 1 commit each | **build-2 gateway change**: the dispatch intent and replayed answers carry the flag (`51fa426`, `682d37e`) |

## 9. Caveats

- **Fixture evidence only.** These are synthetic fixture runs, or the gateway
  in process, with no OS processes and no OS clock. None of it is gateway-run
  data from the frozen binaries.
- **Asserted, not sampled.** The lifecycle and registration results are
  asserted by tests that their own authors wrote together with the verifier
  rules. They show the current behaviour on chosen cases. They are not attack
  rates.
- **"status" needs no key in the prototype.** A provider status observation
  answers any local caller. The verifier does not date it against the run (it
  was dated 2027-06-01 here). So L2, L3 and L4 need no provider key.
- **Partial adapter compromise is not tested.** X is the aggregate of the
  three adapter keys, and only in the simulation. No real-signature attack
  here uses an adapter or approval key.
- **The fixture extra-key-set study uses runs without a snapshot in human
  mode** (§3.3). Its full and no-snapshot-bound-only results for
  relabel-approved do not represent gateway runs.
- **The clock results are unit-level injections.** The registry and
  delegation clocks are moved; the OS clock is not. The two revival results
  are counterexamples of a known limitation, not fixes.
- **Old journals.** An operation journaled before build 2 (an intent without
  the flag field) restores unflagged. By the recovery-flag rule, its
  `RECONCILED` entry would then fail `op.requires_policy` under the build-2
  verifier. That is inferred, not run here.
- **Timings are not results.** Other experiments ran on the machine at the
  same time, so no time here is a performance result.

## 10. Files

All paths below are inside `docs/paper/data/build2/fixture-studies/`.

**Write-up and provenance:**

- `RESULTS.md`: this file.
- `build-manifest.txt`: the manifest checks before and after, the commit, the
  toolchain, the test-binary hashes, the build-1 tree and probe builds, and
  the hashes of the test-only sources.

**Scripts:**

- `run_studies.sh`: the runner, with placeholders.
- `sanitize_logs.py`: raw logs to `logs/`, with machine-specific strings
  replaced.
- `analyze_fixture_studies.py`: `logs/` to the tables below.

**Tables:**

- `tests.csv`: every test and subtest, with whether the two logs agree.
- `lifecycle.csv`: the 63 printed lifecycle verifications.
- `extra_keysets_grid.csv` and `extra_keysets_summary.json`: the s2 grid and
  its counts.
- `fixture_vs_frozen_grid.csv`: the 224 compared cells, with causes.
- `simulation_agreement.csv`: the 44 cells, build 2 vs the build-1 tree.
- `summary.json`: the headline counts.

**Logs (`logs/`):**

- `<run>.testbin.log` (primary) and `<run>.gotest.log` (the literal command)
  for the eight runs.
- `s6-simulation-validation.build1-tree.log`.
- `probe-relabel-approved.log`.
- `exit-codes.txt`.

**Probe:**

- `probe/zz_fixture_study_probe_test.go` and `probe/overlay.template.json`:
  the investigation probe, used through `-overlay` and never placed in
  `<repo>`.

The raw logs, test binaries and the extracted build-1 tree are kept outside
the repository, in `<scratch>/build2-work/fixture-studies/`.
