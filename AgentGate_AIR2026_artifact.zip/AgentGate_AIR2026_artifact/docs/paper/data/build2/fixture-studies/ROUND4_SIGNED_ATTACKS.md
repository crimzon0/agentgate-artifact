# Real-signature attacks, signed field consistency, lifecycle evidence

**What this is.** Test-only evidence written after the build-2 freeze:
real-signature attacks, validly signed inconsistent fields and the
lifecycle evidence basis (2026-10-19). It adds fixture tests next to the
build-2 fixture studies (`RESULTS.md` in this folder). Nothing here is
gateway-run data and nothing here is a rate: every result is a test
assertion on chosen synthetic cases. The paper calls a "cell" of the tables
below a *fixture result* (one fixture case under one verifier setting and
one anchor condition), and the "rational attacker" the *careful attacker*.

**Added after the freeze.** This file, `ADDED_AFTER_FREEZE.md`, the four Go
files below and the fixture helper were written after build 2 was frozen.
They are not in `build-manifest.txt` and not in the frozen binaries; see
`ADDED_AFTER_FREEZE.md`.

**Source state.** Branch `worktree-wf_3e836efa-6f8-1`, based on `9579324`
(the project branch with the first commit of these tests, `33719d9`, merged).
Against `86643d7`, the commit the six frozen build-2 binaries come from,
`git diff --stat 86643d7 -- internal cmd go.mod go.sum` lists the four files
below and `cmd/agentgate-killsuite/README.md`. The README is documentation;
it is not compiled, and it was changed before these tests were written
(`ac5c2a9`, `816b1df`). All
256 module files compiled into the frozen binaries (the module section of
`../build-manifest.txt`) and all 59 test-only files listed in
`build-manifest.txt` here are hash-equal in this tree (`sha256sum -c`,
256/256 and 59/59). The change set is six files: the four Go files, this
results file and `ADDED_AFTER_FREEZE.md`.

| file | kind | SHA-256 |
|---|---|---|
| `internal/auditverify/fixture/held.go` | test helper (package imported only by tests) | `8b2e89cc21a3c199920513a9ba7b447896ebae29bf0ebc3cbf0d7bd49d09e8c7` |
| `internal/auditverify/round4_signed_attacks_test.go` | test | `687cf9576347527a9e1f3c16d065fbc70781b315f964c831bee82def6237ee97` |
| `internal/auditverify/round4_signed_fields_test.go` | test | `b8df21e15be0b0b49d71de746614da9ed3499c40632df0466c611f6be5d92967` |
| `internal/auditverify/round4_lifecycle_test.go` | test | `947c2bf66aea16721ba47536e9581b76548353a2164553995c01c1b83f6f4200` |

**Run.** 2026-10-19, go1.26.6 windows/amd64, offline:

```
GOMODCACHE=<repo>/.tools/go-host-cache-20260916/mod GOPROXY=off GOFLAGS=-mod=readonly GOTOOLCHAIN=local
gofmt -l internal/auditverify/                                       # empty
go vet ./internal/auditverify/...                                   # clean
go test -count=1 ./internal/auditverify/...                         # ok (whole package, old and new tests)
go test -count=1 -v -run 'TestRound4|TestResignHeld' ./internal/auditverify/   # the numbers below
```

10 new top-level tests and 74 subtests, all PASS (from the `-v` log).
2,642 verifications in all, the sum of the per-test counts below:
888 (RS) + 494 (RB) + 840 (LR) + 325 (LRR) + 30 (LH) + 4 (NC) + 59 (SF) + 2
(genuine-run guard).

**Asserted or logged.** Every count and every outcome reported in §1-§3 is
a test assertion, except where a number is marked *(logged)*: those are
read from the `-v` log and not checked by the test.

**Signing safety.** Real signatures are made only by `fixture.ResignHeld`,
inside the test helper package, with the fixture's own deterministic keys
derived in memory from a fixed label. Before it computes or writes anything,
`ResignHeld` reads the folder and refuses it if `keys.json` lists any key
that is not the fixture's key of that role, if any signed artifact of the
log names a key ID that is not a fixture key, or if any provider-journal
receipt does. Every new byte is computed in memory and written only when
nothing failed, so a refused call leaves the folder byte for byte as it was.
`TestResignHeldRefusesNonFixtureKeys` asserts each refusal and that the five
evidence files are unchanged afterwards, including a folder whose capability
was edited before the foreign artifact (so there was something to re-sign
first). `fixture.RestoreUnheld` (the rational form, §1.1) signs nothing and
holds no key: it copies genuine artifacts back and re-hashes the log with
its old signatures. No key is read from or written to disk, nothing exports
a key, and there is no command or program that re-signs a run folder.

**Refused commands.** Nothing was denied by the permission system or a
classifier, and no signing step was refused. The worktree-isolation guard
refused two shell commands because it could not verify them: a `go test`
whose output was redirected to a file with an exit-code echo appended, once
with a leading `cd`. As its message said, they were rerun as single plain
commands with the literal go path. An earlier session recorded two similar
guard refusals (a `go test` through a shell variable, a Python heredoc).

**Notation.** A audit key, I capability issuer key, Xf financial adapter key,
Xm message adapter key, X every adapter key, P provider key, Ap approval key,
"status" a provider-signed status observation (no attacker key: the prototype's
status endpoint answers any local caller; the fixture's provider key stands in
for that answer). Settings: `full`, `no-replay`, `no-replay-no-snapshot`
(`nrns`), `no-snapshot-bound` (`nsb`). Anchors: `none`, `keys` (the unedited
run's keys.json fingerprint), `head` (keys plus the unedited run's last entry
hash); both pinned before any edit. In the per-case strings, each setting
gets three letters for anchors none/keys/head: V = VERIFIED, F = FAILED.

**Shapes.** The mutation engine edits every artifact an edit reaches. When
the key set lacks the role of an edited artifact, that artifact keeps its old
signature:

- **stale (S):** some edited artifact of an unheld role keeps a stale
  signature, so `artifact.signature` fails next to any binding check. This is
  the simulation's own mutant. Such a cell shows that the key set is not
  enough; it does not show which binding check would catch a careful
  attacker.
- **complete (C):** every edited artifact was re-signed with a held key;
  nothing stale is left.
- **rational (R):** the artifacts of roles not held are left exactly as they
  genuinely are, and the rest is re-signed (§1.1). This is the binding
  evidence for key sets that cannot sign everything the edit reaches.

---

## 1. Real signatures next to the simulation

**Test:** RS = `TestRound4RealSignaturesAgreeWithSimulation`
(`round4_signed_attacks_test.go`).

**Method.** Each mutant comes from the simulation grid's mutation engine
(`internal/evalattack`: payloads edited, hashes recomputed, old signatures
kept). It is verified twice:

- REAL: a copy re-signed by `fixture.ResignHeld` with exactly the keys.json
  roles held (for example the financial adapter key alone). The verification
  uses no simulation.
- SIM: the unsigned mutant under `Options.AssumeCompromised` with the
  simulation's role groups (A, I, ADAPTER = all three adapter keys, P).

`ResignHeld` re-signs only artifacts whose signature no longer verifies, carries
re-signed envelope hashes into the artifacts that cite them (capability ->
adapter receipt; provider receipt -> adapter receipt, status observation,
journal; request state -> human decision), and re-chains and re-signs the log
with the audit key. On an unedited fixture it changes no byte
(`TestResignHeldLeavesAGenuineRunUnchanged`, both fixture modes).

**Comparison rule.** When every broken signature belongs to a held role, or to
a role whose simulation group is not assumed, REAL and SIM must agree exactly:
verdict, assurance level, failing checks and the number of findings per check.
A partial adapter set (Xf or Xm) whose mutant also broke a receipt of the other
adapter cannot be expressed by the simulation (ADAPTER is one group). REAL is
then compared with the simulation **without** ADAPTER on verdict, assurance
and the set of failing check IDs; finding counts differ by construction. The
simulation **with** ADAPTER is reported as the over-approximation it is.

**Matrix.** 34 cases (0 not applicable) x 4 settings x 3 anchors = **408
cells, 888 verifications** (408 REAL, 408 SIM, 72 over-approximating SIM).

- M1 binding chain: strip-flag, invent-flag (plain) x bound/unbound x {A, A+I, A+Xf, A+I+Xf}
- M2 full-verifier forger: strip-flag, invent-flag (forge-restate) x bound/unbound x {A+I+X, A+I+Xf}
- M3 partial adapter: change-rules (a message) x {A+I+Xf, A+I+Xm}; strip-flag (a payment) x A+I+Xm; both designs
- M4 provider key: change-amount (plain) x bound/unbound x {A+I+Xf, A+I+Xf+P}

14 of the 34 cases (168 cells) have the stale shape; 20 (240 cells) are
complete.

**Counts (all asserted).**

| comparison | cells | agree |
|---|---|---|
| exact (verdict, assurance, failing checks with counts) | 336 | **336** |
| partial adapter, bracket (vs SIM without ADAPTER: verdict, assurance, check IDs) | 72 | **72** |
| partial adapter, SIM with ADAPTER differs from REAL | 72 | 72 differ; SIM accepts 40 of them, REAL accepts 0 |
| head-anchored cells detected (REAL, `head.anchor` failing) | 136 | 136 |

REAL accepted 96 of the 408 cells, all of them exact cells without a head
anchor.

**Per case (REAL; setting order full, no-replay, nrns, nsb).** The V/F
string of every cell and the failing checks of every `full`/`none` cell are
asserted (`wantRealVerified`, `wantRealFullNone`), as is
`provider.signature` plus `provider.state_chain` failing in every M4 cell
without P.

| group | design | operator/variant | held | shape | REAL | failing checks (full, none) |
|---|---|---|---|---|---|---|
| M1 | bound | strip-flag/plain | A | S | FFF FFF FFF FFF | artifact.signature x2, op.capability_bound, op.receipts_bound, policy.replay |
| M1 | bound | strip-flag/plain | A+I | S | FFF FFF FFF FFF | artifact.signature, op.receipts_bound, policy.replay |
| M1 | bound | strip-flag/plain | A+Xf | S | FFF FFF FFF FFF | artifact.signature, op.capability_bound, op.receipts_bound, policy.replay |
| M1 | bound | strip-flag/plain | A+I+Xf | C | FFF VVF VVF FFF | policy.replay |
| M1 | bound | invent-flag/plain | A | S | FFF FFF FFF FFF | as strip-flag A |
| M1 | bound | invent-flag/plain | A+I | S | FFF FFF FFF FFF | as strip-flag A+I |
| M1 | bound | invent-flag/plain | A+Xf | S | FFF FFF FFF FFF | as strip-flag A+Xf |
| M1 | bound | invent-flag/plain | A+I+Xf | C | FFF VVF VVF FFF | policy.replay |
| M1 | unbound | strip-flag/plain | A, A+I, A+Xf, A+I+Xf | C | FFF VVF VVF FFF (each) | policy.replay |
| M1 | unbound | invent-flag/plain | A, A+I, A+Xf, A+I+Xf | C | FFF VVF VVF FFF (each) | policy.replay |
| M2 | bound | strip-flag/forge-restate | A+I+X | C | VVF VVF VVF VVF | none |
| M2 | bound | strip-flag/forge-restate | A+I+Xf | S | FFF FFF FFF FFF | artifact.signature x2, op.receipts_bound x2 (the two message receipts) |
| M2 | bound | invent-flag/forge-restate | A+I+X | C | VVF VVF VVF VVF | none |
| M2 | bound | invent-flag/forge-restate | A+I+Xf | S | FFF FFF FFF FFF | artifact.signature x2, op.receipts_bound x2 |
| M2 | unbound | strip-flag, invent-flag/forge-restate | A+I+X | C | VVF VVF VVF VVF | none |
| M2 | unbound | strip-flag, invent-flag/forge-restate | A+I+Xf | S | FFF FFF FFF FFF | artifact.signature x2, op.receipts_bound x2 |
| M3 | bound | change-rules/plain | A+I+Xf | S | FFF FFF FFF FFF | artifact.signature, op.receipts_bound, policy.replay |
| M3 | bound | change-rules/plain | A+I+Xm | C | FFF VVF VVF FFF | policy.replay |
| M3 | bound | strip-flag/plain | A+I+Xm | S | FFF FFF FFF FFF | artifact.signature, op.receipts_bound, policy.replay |
| M3 | unbound | change-rules/plain | A+I+Xf, A+I+Xm | C | FFF VVF VVF FFF | policy.replay |
| M3 | unbound | strip-flag/plain | A+I+Xm | C | FFF VVF VVF FFF | policy.replay |
| M4 | bound, unbound | change-amount/plain | A+I+Xf | S | FFF FFF FFF FFF | artifact.signature, op.receipts_bound, policy.replay, provider.signature, provider.state_chain |
| M4 | bound, unbound | change-amount/plain | A+I+Xf+P | C | FFF VVF VVF FFF | policy.replay |

The S rows show only that the key set is insufficient: the evidence the
key set allows still carries a broken signature. Which check catches an
attacker who does not present that broken artifact is shown in §1.1.

### 1.1 Rational (careful) attacker: unheld artifacts left genuine

**Test:** RB = `TestRound4RationalAttackerBinding`
(`round4_signed_attacks_test.go`).

**Method.** The mutant of each case is turned into the rational form by
`fixture.RestoreUnheld(mutant, genuine run, held)`: every artifact of a role
not held whose signature no longer verifies is replaced by the genuine run's
artifact at the same place (same entry and artifact name, or the same
journal entry), and every artifact citing its envelope hash cites the
genuine one again. Artifacts of held roles keep their edits. That unsigned
folder is SIM's input; a copy re-signed by `ResignHeld` is REAL, and the
test asserts that nothing stale is left in it (`LeftInvalid` empty) and that
`RestoreUnheld` restored exactly the roles named per case.

**Cases.** The receipt-path binding ablation (M1 strip-flag and invent-flag,
both designs, A, A+I, A+Xf: 12 cases) plus every other RS case of the stale
shape (M2 forge-restate A+I+Xf, both designs, both operators; M3 bound
change-rules A+I+Xf and strip-flag A+I+Xm; M4 A+I+Xf, both designs: 8
cases). 20 cases x 4 settings x 3 anchors = **240 cells, 494
verifications** (240 REAL, 240 SIM, 14 binding ablations).

**Asserted in every cell:** REAL and SIM agree exactly (**240/240**); no
signature check fails in REAL or SIM (`chain.signature`, `head.signature`,
`artifact.signature`, `provider.signature`); a head anchor detects every cell
(**80/80**, `head.anchor`). With anchors none and keys, the failing checks
are exactly those below (plus `policy.replay` in `full` and `nsb` for the
plain variants). REAL accepts **24** cells, all unbound M1 without replay.
**Binding ablation:** each of the 14 detected cases is VERIFIED once
`op.requires_policy`, `op.capability_bound` and `op.receipts_bound` are
switched off as well (no-replay, keys anchor), so those binding checks are
the only detection.

| group | design | operator/variant | held | restored genuine | REAL | failing checks without replay (none, keys) | binding checks off |
|---|---|---|---|---|---|---|---|
| M1 | bound | strip-flag, invent-flag/plain | A | I, Xf | FFF FFF FFF FFF | op.capability_bound, op.requires_policy | VERIFIED |
| M1 | bound | strip-flag, invent-flag/plain | A+I | Xf | FFF FFF FFF FFF | op.receipts_bound | VERIFIED |
| M1 | bound | strip-flag, invent-flag/plain | A+Xf | I | FFF FFF FFF FFF | op.capability_bound, op.receipts_bound, op.requires_policy | VERIFIED |
| M1 | unbound | strip-flag, invent-flag/plain | A, A+I, A+Xf | none | FFF VVF VVF FFF (each) | none (accepted); full, nsb: policy.replay | not run |
| M2 | bound, unbound | strip-flag, invent-flag/forge-restate | A+I+Xf | Xm (the message receipts) | FFF FFF FFF FFF | op.receipts_bound x2, in all 4 settings | VERIFIED |
| M3 | bound | change-rules/plain (a message) | A+I+Xf | Xm | FFF FFF FFF FFF | op.receipts_bound | VERIFIED |
| M3 | bound | strip-flag/plain (a payment) | A+I+Xm | Xf | FFF FFF FFF FFF | op.receipts_bound | VERIFIED |
| M4 | bound, unbound | change-amount/plain | A+I+Xf | P (provider receipt, log and journal) | FFF FFF FFF FFF | op.receipts_bound | VERIFIED |

What each row means: under A the genuine capability and adapter receipt
agree with each other but bind the original decision, which no FINAL records
any more. Under A+I the re-signed capability binds the new decision while
the genuine receipt cites the old capability and decision. Under A+Xf the
re-signed receipt binds the new decision while the genuine capability binds
the old one. Under M2/M3 the genuine receipt of the other adapter cites the
old capability (and decision). Under M4 the genuine provider receipt states
the original effect digest while the re-signed adapter receipt states the
new one.

**What the real signatures show.**

1. The simulation agrees with real re-signing wherever it can express the key
   set: 336/336 RS cells and 240/240 RB cells, with A, I, adapter and
   provider keys used for real. (Build 2 had validated the simulation with
   the audit key alone: 44/44 in
   `TestSimulationAgreesWithRealAuditKeyResigning`.)
2. The binding ablation on the receipt path holds with real signatures and a
   careful attacker. With replay disabled, the bound design needs A+I+X_op,
   where X_op is the adapter key of the edited operation: A, A+I and A+Xf
   are each detected by the binding checks alone (RB; VERIFIED once those
   checks are off), and A+I+Xf passes for a payment (RS). The unbound design
   needs only A (RS, RB). The RS cells for A, A+I and A+Xf (bound) are the
   stale shape and are not binding evidence by themselves.
3. **Partial adapter compromise.** The key needed is the adapter key of the
   edited operation's receipt. A message edit with only Xf, and a payment
   edit with only Xm, are detected by `op.receipts_bound` alone (RB M3); with
   the matching key they pass without replay (RS). Under the full verifier
   the forge-restate forger restates the policy hash, which every adapter
   receipt still in the log reaches through its capability and decision.
   With only Xf the two message receipts stay genuine and
   `op.receipts_bound` x2 detects it in all 4 settings (RB M2); with every
   adapter key it passes in all 4 (RS M2). The simulation's single ADAPTER
   group over-approximates the partial attacker: it accepts 40 cells that the
   real partial attacker cannot reach. So the simulated A+I+X results remain
   an upper bound for partial adapter custody.
4. **Provider key.** change-amount edits the provider receipt and journal.
   Without P, a careful attacker keeps the genuine provider receipt, and
   `op.receipts_bound` detects it in all 4 settings and both designs (RB M4);
   the stale shape fails `provider.signature` and `provider.state_chain` too
   (RS). With A+I+Xf+P it passes without replay, and `policy.replay` still
   detects it (RS).
5. A head anchor detected every rewrite (136/136 RS and 80/80 RB REAL cells).

**Disagreements.** None at the level each comparison can make. The only
structural difference is item 3 above. The simulation cannot hold one adapter
key without the others, and that is reported, not hidden: 72 cells, bracketed
72/72 by the simulation without ADAPTER.

---

## 2. Validly signed inconsistent fields

**Test:** SF = `TestRound4ValidlySignedInconsistentFields`
(`round4_signed_fields_test.go`), 59 subtests. Guard:
`TestRound4LogOnlyProviderEditLeavesJournal`.

**Method.** One field of one artifact in a genuine fixture run (revision run,
or human-approval run for approval lineage) is edited. The cited envelope
hashes are carried into the artifacts that cite them, as the mutation engine
does. `ResignHeld` then signs every changed artifact with the fixture key of
the role that signs it, with all roles held. The test asserts:

- no artifact is left with a broken signature, and something was re-signed;
- for every UNCHECKED case, exactly the declared roles were re-signed (and
  the declared number of journal receipts replaced), so an accepted case
  shows that its edit happened;
- no signature check fails (`chain.signature`, `head.signature`,
  `artifact.signature`, `provider.signature`); the one exception is the
  journal-listing case, whose check lives in `provider.signature`;
- the set of failing checks equals the listed set exactly.

Each case runs under the full verifier with the keys anchor.

**Result: 41 detected, 18 accepted (UNCHECKED)** (per-claim counts
asserted).

| claim | detected | UNCHECKED accepted |
|---|---|---|
| effect binding (P3) | 13 | 5 |
| classification binding (P2) | 7 | 0 |
| provider evidence (P4, P7) | 9 | 8 |
| approval lineage (human mode) | 12 | 5 |

### 2.1 Claim -> field -> check (validly signed, detected)

| claim | artifact (signer) | field made inconsistent | failing checks (exactly) |
|---|---|---|---|
| effect binding | capability (I) | -70004 effect digest; -70002 operation ID (another operation's); -70003 effect type; 3 audience | op.capability_bound |
| effect binding | adapter receipt (Xf) | effect_digest; operation_id; effect_type; provider_receipt_hash (another operation's genuine receipt); provider_reference | op.receipts_bound |
| effect binding | provider receipt (P; log and journal copies identical) | effect_digest; operation_id; effect_type; provider_reference | op.receipts_bound |
| classification | capability (I) | -70007 policy decision hash | op.capability_bound, op.receipts_bound, op.requires_policy |
| classification | capability (I) | 7 cti | op.capability_bound, op.receipts_bound |
| classification | capability (I) | -70009 policy hash | op.capability_bound, policy.snapshot_bound |
| classification | adapter receipt (Xf) | policy_decision_hash; capability_hash; cti | op.receipts_bound |
| classification | FINAL value (A), hash carried into capability (I) and receipt (Xf) | field 9 flagging rules | op.requires_policy |
| provider evidence | provider receipt (P), log copy only | unchecked committed_at changed, so the log receipt is no longer the journal's | provider.matches_audit |
| provider evidence | journal receipt (P) | commit_seq differs from the journal listing | provider.signature ("listed as commit"), provider.matches_audit, provider.state_chain |
| provider evidence | provider receipt (P), both copies | state_before_hash of the second commit; outcome REJECTED | provider.state_chain |
| provider evidence | status observation (P) | stored receipt hash names another operation's genuine receipt | op.outcome_resolved, provider.matches_audit |
| provider evidence | status observation (P) | operation_id; effect_digest; effect_type; status ABSENT on a committed RECONCILED | op.outcome_resolved |
| approval lineage | human decision (Ap) | 6 operation; 7 effect digest; 8 PRE hash; 9 approval ID; 10 request-state hash; 2 REJECTED; 11 decided_at after expiry | op.approval_bound |
| approval lineage | request state (Ap, both copies; decision field 10 follows) | 4 operation; 5 effect digest; 6 PRE hash | op.approval_bound |
| approval lineage | FINAL value (A), hash carried into capability (I) and receipt (Xf) | field 3 PRE hash; field 7 overlay root with details unchanged | op.requires_policy |

### 2.2 UNCHECKED fields: validly signed, inconsistent, accepted (VERIFIED)

The paper's claims must not rest on these fields. The roles each edit
re-signed are asserted (capability edits: I and Xf; adapter receipt: Xf;
provider receipt: P and Xf, plus one journal receipt; status: P; decision:
Ap; FINAL edits: I and Xf).

- **Approval lineage (deferred list):**
  - FINAL field 8 (approval artifact hashes);
  - capability -70013 added;
  - adapter receipt `authorization_artifact_hashes` added;
  - FINAL overlay root changed together with `details.overlay_root` (the
    root is not recomputed from the approval artifacts);
  - decision field 5 (approver): the run's one decision, re-signed with Ap
    naming a different approver, is accepted, because the approver is not
    checked.
- **Provider accounting:**
  - status `idempotency_key_hash` and `status_request_digest`;
  - provider receipt `provider_request_digest`, `idempotency_key_hash` and
    `effect_row_hash` added;
  - adapter receipt `provider_request_digest` and `idempotency_key_hash`
    added.

  No check reads a request digest or an idempotency key.
- **Deferred:** status `canonical_state_hash`/`current_commit_seq`; status
  `observed_at` (dated 2030).
- **Redundant:**
  - status `provider_reference`;
  - provider receipt `adapter_id` and `committed_at`, both copies;
  - adapter receipt `adapter_id` and `outcome`;
  - capability -70001 tenant and 2 subject. These are inside the effect
    digest or bound by the key role.
- **New observation:** the provider receipt `state_before_hash` of the
  **first** commit (both copies) is accepted. Nothing in the evidence states
  the provider's initial state, so `provider.state_chain` compares only later
  commits. `docs/demo/FIELD_CHECK_MAP.md` §3 ("before = the previous commit's
  after") should say that commit 1 is not covered.

Every row of `FIELD_CHECK_MAP.md` that these cases touch was confirmed: each
named check fires, and each field listed as unchecked is accepted. The one
exception is the first-commit observation above, which the map does not
state.

---

## 3. Lifecycle evidence basis

**New tests (`round4_lifecycle_test.go`):**

- LR = `TestRound4LifecycleRealVsSimulation`, REAL vs SIM, every setting,
  anchors none/keys/head: 35 cases, **420 cells, 840 verifications, exact
  agreement 420/420**. REAL accepted 120 cells, none with a head anchor (the
  verdict of every cell is asserted). The shapes:
  - convert: the target's execution becomes RECONCILED-committed with the
    genuine receipt and genuine APPLIED status;
  - downgrade: the execution is deleted and the call is restated UNCERTAIN;
  - confirm: the execution is kept and a confirming RECONCILED is added;
  - each of these with every other execution converted (forge-restate);
  - all of them after a strip-flag, invent-flag or change-rules edit.

  13 of the 35 cases are the stale shape: A with the target converted
  (plain, 3 cases) or every execution converted (forge-restate, 4), A
  downgraded (2), A+I confirmed (plain 2, forge-restate with the others
  converted 2). Their detections include `artifact.signature`.
- LRR = `TestRound4LifecycleRationalAttacker`: those 13 cases in the
  rational form (`RestoreUnheld` before the shape), REAL vs SIM, every
  setting, anchors none/keys/head: **156 cells, 325 verifications** (156
  REAL, 156 SIM, 13 ablations), exact agreement **156/156**, no signature
  check failing, head anchor **52/52**, every cell without a head anchor
  still FAILED with the exact failing checks below.
- LH = `TestRound4LifecycleHistories`: 15 histories with real signatures,
  under the full verifier and keys anchor, each also run with no replay (same
  result in 15/15). **12 detected, 3 accepted**, and each accepted case
  reports what it is.
- NC = `TestRound4NoCapabilityReclassifiedInPlace`: a denial restated with A in
  4 settings. Detected by `policy.replay` in full and nsb; accepted as
  `audit_only` in no-replay and nrns.

**LRR results (the rational form of the 13 stale lifecycle cases).** Plain
variants add `policy.replay` in `full` and `nsb`. "Binding checks off" is
no-replay, keys anchor, with `op.requires_policy`, `op.capability_bound`,
`op.receipts_bound` and `policy.snapshot_bound` off as well.

| shape | design | operator/variant | held | restored genuine | REAL | failing checks without replay (none, keys) | binding checks off |
|---|---|---|---|---|---|---|---|
| converted (target) | bound | strip-flag, invent-flag, change-rules/plain | A | I and the target's adapter key | FFF FFF FFF FFF | op.capability_bound, op.outcome_resolved x2 | op.outcome_resolved |
| converted (every execution) | bound, unbound | strip-flag, invent-flag/forge-restate | A | I, Xf, Xm | FFF FFF FFF FFF | op.capability_bound x6, op.outcome_resolved x11, policy.snapshot_bound x6 (the last not in nrns, nsb) | op.outcome_resolved |
| downgraded | bound | strip-flag, invent-flag/plain | A | I, Xf | FFF FFF FFF FFF | op.capability_bound, provider.matches_audit | provider.matches_audit |
| confirmed | bound | strip-flag, invent-flag/plain | A+I | Xf | FFF FFF FFF FFF | op.receipts_bound | VERIFIED |
| confirmed, others converted | bound | strip-flag, invent-flag/forge-restate | A+I | Xf, Xm | FFF FFF FFF FFF | op.receipts_bound | VERIFIED |

Under A the genuine capability binds the original decision (forge-restate:
and the original policy hash), so it is not accepted; the committed
RECONCILED (converted) or the provider's commit (downgraded) is then left
without an accepted capability, which `op.outcome_resolved` or
`provider.matches_audit` also reports. That provider-side consequence stays
when the binding checks are off. Under A+I (confirmed) the target's genuine
adapter receipt still binds the original capability and decision, and only
`op.receipts_bound` detects it.

**Labels:**

- **FIXTURE-TESTED (test):** asserted with real fixture signatures.
- **SIMULATED (grid):** the frozen 336-cell compromise grid
  (`../compromise/cells.csv`, `flips.csv`), simulation only.
- **ARGUED (function):** from the verifier code, not run.

**Test codes.** New: RS = `TestRound4RealSignaturesAgreeWithSimulation`,
RB = `TestRound4RationalAttackerBinding`, LR =
`TestRound4LifecycleRealVsSimulation`, LRR =
`TestRound4LifecycleRationalAttacker`, LH = `TestRound4LifecycleHistories`,
NC = `TestRound4NoCapabilityReclassifiedInPlace`, SF =
`TestRound4ValidlySignedInconsistentFields`. Existing (build 2,
`lifecycle_test.go` unless noted):

| code | test |
|---|---|
| L1 | `TestLifecycleL1AuditKeyDowngradeToUnresolved` |
| L1b | `TestLifecycleL1bAuditIssuerUnresolvedStripFlag` |
| L2 | `TestLifecycleL2ReconciledCommitClassification` |
| L3 | `TestLifecycleL3AuditIssuerConversionWithoutReplay` |
| L4 | `TestLifecycleL4FullVerifierAllReconciled` |
| CH | `TestLifecycleConflictingHistories` |
| RA | `TestReconciledAdapterReceipt` |
| RR | `TestRecoveryRecordsStateTheBoundFlag` |
| UD | `TestLifecycleUnresolvedCapabilityDeletion` |
| CE | `TestClassificationEvidenceByLifecycleState` |
| SA | `TestSimulationAgreesWithRealAuditKeyResigning` (`compromise_test.go`) |

In every cell, a head anchor detects the rewrite (all head-anchored cells of
RS, RB, LR and LRR FAILED).

### 3.1 Evidence-basis table

**Reading the cells.** "Keys" means the smallest key set among those tested
that was accepted. It is not a proof that fewer keys cannot succeed. "Plain"
is the edit without snapshot forgery. "Forge-restate" is the snapshot forger,
who restates the policy hash everywhere. "Detected" for a key set that
cannot sign everything the edit reaches is cited from the rational form (RB,
LRR): no signature check fails there. A stale-shape cell (RS, LR, and the
frozen grid's A and A+I cells) is cited only as "the key set is not enough".

The table has six columns:

- **state, reported as**: the lifecycle state and what the verifier reports
  for it.
- **in place, bound, no replay**; **in place, bound, full**; **in place,
  unbound, no replay**; **in place, unbound, full**: the keys needed to change
  the classification without changing the state, by design and verifier
  setting.
- **switch to a weaker state**: the keys needed for each switch, and what the
  verifier then reports.

| state, reported as | in place, bound, no replay | in place, bound, full | in place, unbound, no replay | in place, unbound, full | switch to a weaker state |
|---|---|---|---|---|---|
| **COMMITTED via receipt** (EFFECT_EXECUTED with an adapter receipt). Reported `issuer_adapter`. | **A+I+X_op**: FIXTURE-TESTED. A, A+I and A+Xf are detected by the binding checks alone (RB M1: A `op.capability_bound` + `op.requires_policy`; A+I `op.receipts_bound`; A+Xf all three; each VERIFIED once those checks are off); A+I+Xf passes for a payment (RS M1); a message edit needs Xm and a payment edit Xf (RS M3; the wrong adapter key detected by `op.receipts_bound`, RB M3). SIMULATED: grid `flips.csv`, the 12 no-replay binding flips per configuration are A and A+I cells of the stale shape (artifact.signature fails in the bound cell too); RB is the binding evidence for these key sets. | Plain: detected by `policy.replay` under every key set (RS M1). Forge-restate: **A+I+X over every adapter receipt left in the log**: FIXTURE-TESTED (RS M2: X passes in all 4 settings; RB M2: Xf alone, message receipts genuine, `op.receipts_bound` x2 in all 4 settings; LR confirm-rest: only the target's receipt left, Xf suffices). SIMULATED (grid `cells.csv`: full, bound, strip-flag and invent-flag are undetected under A+I+X by forge-restate). | **A**: FIXTURE-TESTED (RS and RB M1 unbound: A, A+I, A+Xf accepted without replay). SIMULATED (grid). | Plain: `policy.replay` (RS, RB). Forge-restate: **A+I+X**: FIXTURE-TESTED (RS M2 unbound; Xf alone detected by `op.receipts_bound` x2, RB M2 unbound). | To reconciled with the flag kept: **A + status**; VERIFIED, `issuer_only_reconciled`, Missing (L2, 4 settings). To reconciled and reclassified: **A+I + status**, no replay (LR convert, L3); **A+I + status**, full, forge-restate with every execution converted (LR, L4); A alone detected without a signature failure (LRR converted). To UNCERTAIN/RR with the flag kept: **A**; VERIFIED, still flagged, warning, `run_complete` fail (L1). To UNCERTAIN and reclassified: **A+I**, no replay (LR downgrade, L1b); **A+I**, full, forge-restate with the others converted (LR downgrade-rest); A alone detected (LRR downgraded). To no capability: detected, `provider.matches_audit` (CH). To not committed: A+P forged ABSENT detected (CH); another operation's genuine ABSENT detected (LH). Receipt removed or substituted: detected (CH: adapter receipt; LH: provider receipt, also with A+I+Xf re-signing the adapter receipt). All FIXTURE-TESTED. |
| **COMMITTED via reconciliation** (RECONCILED-committed, no adapter receipt). Reported `issuer_only_reconciled` plus a Missing `issuer_only` entry. | **A+I + status**: FIXTURE-TESTED (LR convert: A+I passes no-replay and nrns; L3 6/6). A detected in 4/4 settings without a signature failure (LRR converted: the genuine capability binds the original decision; `op.capability_bound`, `op.outcome_resolved`). | Plain: `policy.replay` (LR). Forge-restate, every execution converted: **A+I + status**, passes all 4 settings: FIXTURE-TESTED (LR, L4 8/8); A detected (LRR: `op.capability_bound`, `op.outcome_resolved`, and `policy.snapshot_bound` where it runs). | **A + status**: FIXTURE-TESTED (LR convert unbound). | Plain: `policy.replay` (LR). Forge-restate, every execution converted: **A+I + status**: FIXTURE-TESTED (LR unbound: A+I passes all settings; A detected, LRR unbound: the genuine capabilities keep the original policy hash). | RECONCILED deleted, so UNCERTAIN: **A**; VERIFIED, `issuer_only_unresolved`, `run_complete` fail (LH). RECONCILED and capability deleted: detected, `provider.matches_audit` (LH). Restated not_committed with another operation's genuine ABSENT: detected (LH). RECONCILED moved before the capability: detected (LH). Attached provider receipt replaced: detected (LH). Attached provider receipt removed: VERIFIED, class unchanged; the receipt is optional (LH). The observation's date is not checked (L2: dated 2027; SF: dated 2030). All FIXTURE-TESTED. |
| **COMMITTED via reconciliation with an attached adapter receipt.** Reported `issuer_adapter`. | With the receipt kept: A+I+X_op. ARGUED (`checkReconciledReceipt` applies the `checkReceipts` bindings). An edited or foreign receipt is detected; A+I strip-flag keeping the original receipt is detected: FIXTURE-TESTED (RA, 3/3 + 1). Dropping the receipt turns it into the row above (A+I). | As the row above, because the receipt can be dropped: FIXTURE-TESTED (LR, L4). | A: ARGUED (as the unreceipted row). | As the unreceipted row: ARGUED. | As the unreceipted row. |
| **Executed + confirming RECONCILED.** Reported `issuer_adapter`, `reconciled`. | **A+I+X_op**: FIXTURE-TESTED (LR confirm: A+I+Xf passes no-replay and nrns; A+I with the genuine adapter receipt detected by `op.receipts_bound` alone, VERIFIED once it is off: LRR confirmed). | Plain: `policy.replay` (LR). Forge-restate with every other execution converted: **A+I+X_op**, passes all 4 settings: FIXTURE-TESTED (LR confirm-rest); A+I detected by `op.receipts_bound` alone (LRR confirm-rest). | **A**: FIXTURE-TESTED (LR confirm unbound). | Plain: `policy.replay` (LR). Forge-restate: A+I+X_op, ARGUED (as COMMITTED via receipt, unbound). | Execution deleted, RECONCILED kept: the COMMITTED-via-reconciliation row (**A + status**, same shape as L2/LR convert). Contradicting flags on two reconciliations: `op.requires_policy` (CH). RECONCILED inserted before the execution: `op.single_use` (CH). Confirming RECONCILED with a wrong flag: `op.requires_policy` (RR). All FIXTURE-TESTED. |
| **UNCERTAIN / RECONCILIATION_REQUIRED with a capability.** Reported `issuer_only_unresolved`, `flagged_unconfirmed`, a warning when the journal shows a commit, Missing, `run_complete` fail. | **A+I**: FIXTURE-TESTED (LR downgrade: A+I passes no-replay and nrns; L1b). A detected without a signature failure (LRR downgraded: `op.capability_bound`, `provider.matches_audit`). | Plain: `policy.replay` (LR). Forge-restate with every other execution converted: **A+I**, passes all 4 settings: FIXTURE-TESTED (LR downgrade-rest). | **A**: FIXTURE-TESTED (LR downgrade unbound). | Plain: `policy.replay` (LR). Forge-restate: A+I, ARGUED (as COMMITTED via reconciliation, unbound). | To no capability: **A**; VERIFIED `audit_only` only when the provider never committed (UD). With a provider commit: detected, `provider.matches_audit` (CH). To not committed: needs the provider's ABSENT, which is genuine only for an uncommitted operation (honest settlement, CE); for a committed operation it needs P and is still detected (CH). Reconciled committed with another operation's genuine APPLIED evidence: detected (LH). Genuine ABSENT twice: VERIFIED, idempotent (LH). RR restated on a kept execution: VERIFIED, `issuer_adapter`, warning, `run_complete` fail (CH). All FIXTURE-TESTED. |
| **Not committed** (RECONCILED not_committed, genuine ABSENT). Reported `issuer_only_no_effect`. | A+I: ARGUED. The decision is capability-bound as for UNCERTAIN (`requirePolicy`, `classificationEvidence`), and there is no effect to classify. Not run. | ARGUED (as UNCERTAIN). | A: ARGUED. | ARGUED. | RECONCILED deleted, so UNCERTAIN: **A** (this is the genuine fixture state, CE). Capability deleted after the settlement: detected, `op.outcome_resolved` (LH). A committed reconciliation added with another operation's genuine evidence: detected (LH). FIXTURE-TESTED. |
| **No capability** (denied, refused, blocked, over budget, revoked, zero). Reported `audit_only`. | **A**: FIXTURE-TESTED (NC: accepted in no-replay and nrns). | Plain: `policy.replay` detects (NC, full and nsb). With snapshot forgery: ARGUED. `policy.snapshot_bound` recomputes the snapshot hash that the issuer signed into every capability (-70009), so the forger needs I, plus X for any kept receipts (`checkSnapshotBinding`). | A: ARGUED (same code path; there is no capability in either design). | `policy.replay`: ARGUED (same code path). | There is no weaker state. Deleting the whole operation needs **A** and is VERIFIED unless a head anchor is given: FIXTURE-TESTED (SA "deleted denial", real = simulation). |

### 3.2 What the table says

- In every state, a change that the verifier accepts needs the audit key, and
  a head anchor detects it.
- **Receipt path vs reconciliation path.** On the receipt path, binding
  raises the bound design's no-replay threshold from A to A+I+X_op, and the
  smaller key sets are caught by the binding checks themselves, not by a
  broken signature (RB). On the reconciliation path the threshold is A+I
  plus a status observation, which needs no key. The same holds for the
  confirmed path once the execution is dropped. Under the full verifier, the
  forge-restate forger needs A+I plus the adapter keys of exactly the
  receipts left in the log. This is none if every execution is converted.
- **Weaker states.** Every switch to a weaker state that the verifier accepts
  is reported as weaker: `issuer_only_reconciled`, `issuer_only_unresolved`,
  `audit_only`, a Missing entry, a warning, and `run_complete` fail. Every
  attempt to substitute receipts or observations was detected, including one
  built from genuine receipts and genuine observations of another operation
  (12 of 15 histories). The accepted ones are the optional attached receipt,
  the deletion of a RECONCILED (reported as UNCERTAIN), and an idempotent
  repeated ABSENT.
- **ARGUED cells (not run):**
  - every in-place cell of the not-committed row;
  - the unbound full-verifier forge-restate cells of the confirmed and
    UNCERTAIN rows;
  - the receipt-kept cells of the attached-receipt row;
  - the snapshot-forging cell and the unbound cells of the no-capability
    row.

---

## 4. Caveats

- Fixture runs only. They are synthetic and in process, with no gateway
  binary, no OS processes and no clock. These are not frozen-build gateway
  data.
- These are assertions on chosen cases, written alongside the verifier rules.
  They show current behaviour and are not attack rates. Every count above is
  a count of test cells.
- All keys are held in one process. "Held" says nothing about custody.
- "Status" needs no attacker key in the prototype. The fixture's provider key
  stands in for the endpoint's answer.
- The rational form is one careful attacker per case: the unheld artifacts
  are left genuine and the held ones carry the mutation engine's edits. It
  is not a search over every evidence an attacker could present.
- The fixture has no document operation, so ADAPTER_DOCUMENT is never
  exercised. X here means the message and financial keys.
- The partial-adapter result rests on the fixture's two adapter types. With a
  document adapter in a run, its key would join X_op wherever its receipt
  stays in the log.

## 5. Which test produces each number

All numbers are asserted by the named test unless marked *(logged)*.

| number | test (file) |
|---|---|
| 34 cases / 408 cells / 888 verifications; exact 336/336; bracket 72/72; SIM with ADAPTER differs in 72/72 and accepts 40, REAL 0; 96 REAL accepted; 136/136 head detected; every per-case V/F string; every full/none failing-check list; provider evidence failing in every M4 cell without P | `TestRound4RealSignaturesAgreeWithSimulation` (`round4_signed_attacks_test.go`) |
| 20 cases / 240 cells / 494 verifications; exact 240/240; no signature check failing; failing checks per cell; 24 REAL accepted; 80/80 head detected; 14/14 VERIFIED with the binding checks off | `TestRound4RationalAttackerBinding` |
| ResignHeld changes no byte of a genuine run (2 fixture modes) | `TestResignHeldLeavesAGenuineRunUnchanged` |
| refusal of a foreign keys.json key, a foreign artifact kid (after a capability edit), a foreign journal-receipt kid, and a key set without A, each leaving the folder unchanged; RestoreUnheld refusals | `TestResignHeldRefusesNonFixtureKeys` |
| 59 fields: 41 detected (13/7/9/12), 18 UNCHECKED accepted (5/0/8/5), each UNCHECKED edit's re-signed roles; first-commit `state_before_hash` accepted | `TestRound4ValidlySignedInconsistentFields` (`round4_signed_fields_test.go`) |
| a log-only provider edit leaves the journal untouched | `TestRound4LogOnlyProviderEditLeavesJournal` |
| 35 cases / 420 cells / 840 verifications; exact 420/420; 120 REAL accepted; the verdict of every cell | `TestRound4LifecycleRealVsSimulation` (`round4_lifecycle_test.go`) |
| 13 stale lifecycle cases in the rational form: 156 cells / 325 verifications; exact 156/156; no signature check failing; failing checks per cell; 52/52 head detected; ablation results (4 VERIFIED, 9 with one provider-side check) | `TestRound4LifecycleRationalAttacker` |
| 15 histories: 12 detected, 3 accepted; no-replay equals full 15/15 | `TestRound4LifecycleHistories` |
| denial restated with A: detected in full/nsb, accepted in no-replay/nrns | `TestRound4NoCapabilityReclassifiedInPlace` |
| 10 top-level tests, 74 subtests *(logged)*; 2,642 verifications (sum of the counts above) | `go test -v` log |

The per-cell lines of every matrix are printed by `go test -v` (`t.Logf`).
