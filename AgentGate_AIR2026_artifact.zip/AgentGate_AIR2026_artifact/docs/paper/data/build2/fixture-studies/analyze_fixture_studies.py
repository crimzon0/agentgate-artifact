#!/usr/bin/env python3
"""Turn the sanitized `go test -v` logs of the fixture studies (logs/) into
summary tables.

usage: python analyze_fixture_studies.py [FROZEN_CELLS_CSV]
  FROZEN_CELLS_CSV  the build-1 frozen grid's cells.csv
                    (default: ../../revision/compromise/cells.csv)

Writes next to this script:
  tests.csv                  every test and subtest of every study: study, test, result,
                             and whether the go-test log and the hashed test binary's log agree
  lifecycle.csv              every lifecycle line the auditverify lifecycle tests print
                             (label, verifier setting and anchors, key set, verdict,
                             assurance, failing checks, counts, the target operation's
                             status, flag and classification evidence)
  extra_keysets_grid.csv     the extra-key-set grid (design x operator x setting; accepted
                             or detected per key set; strongest variant; no anchors)
  extra_keysets_summary.json the counts the test prints, parsed
  fixture_vs_frozen_grid.csv the extra-key-set grid against the build-1 frozen 336-cell grid
                             (anchors none) for the four key sets both contain, with the
                             cause of every disagreement
  simulation_agreement.csv   TestSimulationAgreesWithRealAuditKeyResigning cells on build 2
                             and on the build-1 tree
  summary.json               the headline counts
Standard library only; deterministic.
"""
import csv
import json
import os
import re
import sys
from collections import Counter, OrderedDict

HERE = os.path.dirname(os.path.abspath(__file__))
LOGS = os.path.join(HERE, "logs")
FROZEN = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "..", "..", "revision", "compromise", "cells.csv")

STUDIES = [
    "s1-lifecycle", "s1b-lifecycle-states", "s2-extra-keysets", "s3a-registration",
    "s3b-verifier-clock-freshness", "s4-gateway-clock-restart-flag", "s5-flagged-recovery-e2e",
    "s6-simulation-validation",
]
KEYSETS = ["A", "A+I", "A+I+X", "A+I+X+Ap", "A+X", "A+P", "I+X"]
FROZEN_NAMES = {"A": "audit", "A+I": "audit+issuer", "A+I+X": "audit+issuer+adapter",
                "A+I+X+Ap": "audit+issuer+adapter+approval"}


def read(name):
    with open(os.path.join(LOGS, name), encoding="utf-8") as handle:
        return handle.read()


def results(text):
    """test name -> PASS/FAIL/SKIP from the --- lines."""
    out = OrderedDict()
    for match in re.finditer(r"^\s*--- (PASS|FAIL|SKIP): (\S+)", text, re.M):
        out[match.group(2)] = match.group(1)
    return out


def normalized(text):
    lines = []
    for line in text.splitlines():
        if line.startswith("ok ") or line == "PASS":
            continue
        lines.append(re.sub(r" \([0-9.]+s\)", "", line))
    return lines


def write_csv(name, header, rows):
    with open(os.path.join(HERE, name), "w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(header)
        writer.writerows(rows)


def main():
    summary = OrderedDict()

    # --- tests.csv ---------------------------------------------------------
    rows, totals = [], OrderedDict()
    for study in STUDIES:
        binary, gotest = read(study + ".testbin.log"), read(study + ".gotest.log")
        same = normalized(binary) == normalized(gotest)
        res = results(binary)
        if res != results(gotest):
            sys.exit("%s: the go-test and test-binary results differ" % study)
        top = [name for name in res if "/" not in name]
        sub = [name for name in res if "/" in name]
        totals[study] = OrderedDict(tests=len(top), subtests=len(sub),
                                    passed=sum(1 for v in res.values() if v == "PASS"),
                                    failed=sum(1 for v in res.values() if v == "FAIL"),
                                    skipped=sum(1 for v in res.values() if v == "SKIP"),
                                    logs_identical=same)
        for name, result in res.items():
            rows.append([study, name, result, "yes" if same else "no"])
    write_csv("tests.csv", ["study", "test", "result", "gotest_and_testbin_logs_identical"], rows)
    summary["tests"] = totals

    # --- lifecycle.csv -----------------------------------------------------
    pattern = re.compile(r"lifecycle_test\.go:\d+: (?P<label>.*?) \[(?P<bracket>[^\]]*)\]: verdict=(?P<verdict>\S+) "
                         r"assurance=(?P<assurance>\S+) failing=\[(?P<failing>[^\]]*)\] flagged=(?P<flagged>\d+) "
                         r"unconfirmed=(?P<unconfirmed>\d+)(?: \| op status=(?P<status>\S+) flagged=(?P<opflag>\S+) "
                         r"evidence=(?P<evidence>\S+))?")
    rows = []
    current = ""
    for line in read("s1-lifecycle.testbin.log").splitlines():
        run = re.match(r"=== (?:RUN|NAME)\s+(\S+)", line)
        if run:
            current = run.group(1)
            continue
        match = pattern.search(line)
        if not match:
            continue
        bracket = [part.strip() for part in match.group("bracket").split(",")]
        label = match.group("label")
        keyset = ""
        for candidate in ("A+status", "A+P", "A+I", "A"):
            if candidate in bracket:
                keyset = candidate
        if not keyset:
            found = re.search(r"\b(A\+I|A)\b(?=,| converted| execution| strip| all)", label)
            if label.startswith("L1b"):
                keyset = "A+I" if "audit+issuer" in label else "A"
            elif found:
                keyset = found.group(1)
            elif label.startswith(("L1 ", "unresolved")):
                keyset = "A"
            elif label.startswith("L2"):
                keyset = "A+status"
        # A conversion of an execution into RECONCILED-committed carries a
        # provider status observation (fixture.ProviderStatus), "status".
        if "converted" in label and "status" not in keyset:
            keyset += "+status"
        setting = next((b for b in bracket if b in ("full", "no-replay", "no-replay-no-snapshot", "no-snapshot-bound")), "")
        anchors = next((b for b in bracket if "anchor" in b or b in ("keys", "none", "keys+head")), "")
        rows.append([current.split("/")[0], label, keyset, setting or "full", anchors, match.group("verdict"),
                     match.group("assurance"), match.group("failing"), match.group("flagged"), match.group("unconfirmed"),
                     match.group("status") or "", match.group("opflag") or "", match.group("evidence") or ""])
    write_csv("lifecycle.csv", ["test", "label", "key_set", "verifier_setting", "anchors", "verdict", "assurance",
                                "failing_checks", "run_flagged", "run_flagged_unconfirmed", "op_status", "op_flagged",
                                "op_classification_evidence"], rows)
    summary["lifecycle_lines"] = len(rows)
    l3 = re.search(r"L3 cells accepted under no-replay \(anchors none and keys\): A (\d+) of (\d+), A\+I (\d+) of (\d+)",
                   read("s1-lifecycle.testbin.log"))
    summary["l3_no_replay_cells_accepted"] = OrderedDict(A=[int(l3.group(1)), int(l3.group(2))],
                                                         A_plus_I=[int(l3.group(3)), int(l3.group(4))])

    # --- extra key sets --------------------------------------------------------
    text = read("s2-extra-keysets.testbin.log")
    grid = []
    for match in re.finditer(r"^\s+(bound|unbound)\s+(\S+)\s+(full|no-replay|no-replay-no-snapshot|no-snapshot-bound-only)\s+([a.]{7})$", text, re.M):
        grid.append((match.group(1), match.group(2), match.group(3), match.group(4)))
    write_csv("extra_keysets_grid.csv", ["design", "operator", "setting"] + KEYSETS,
              [[d, o, s] + ["accepted" if c == "a" else "detected" for c in marks] for d, o, s, marks in grid])
    head = re.search(r"(\d+) mutants \((\d+) operator/variant/design combinations not applicable\), (\d+) cells, (\d+) \(cell, variant\) pairs, (\d+) verifications", text)
    anchored = re.search(r"all (\d+) keys-anchored cells \((\d+) verifications\) repeat", text)
    provider = re.search(r"provider-signed artifact edited by (\d+) mutants \[([^\]]*)\]: detected under every tested set in all (\d+)", text)
    same_row = re.search(r"in (\d+)/(\d+) cells \(observed on this fixture\)", text)
    tallies = {}
    for kind in ("cells \\(strongest variant\\)", "\\(cell, variant\\) pairs"):
        match = re.search(kind + r":\s+(\d+); A\+I\+X smallest tested set in (\d+) \(A\+X detected in (\d+), I\+X detected in (\d+) of them\); "
                          r"A\+I\+X\+Ap smallest in (\d+).*?accepted A (\d+), A\+X (\d+), A\+P (\d+), I\+X (\d+); A\+X == A in (\d+)/(\d+), A\+P == A in (\d+)/(\d+)", text)
        names = ["total", "aix_smallest", "ax_detected_there", "ix_detected_there", "aixap_smallest", "accepted_A", "accepted_AX",
                 "accepted_AP", "accepted_IX", "ax_equals_a", "ax_equals_a_of", "ap_equals_a", "ap_equals_a_of"]
        tallies["cells" if kind.startswith("cells") else "cell_variant_pairs"] = OrderedDict(zip(names, map(int, match.groups())))
    per_setting = OrderedDict()
    for setting in ("full", "no-replay", "no-replay-no-snapshot", "no-snapshot-bound-only"):
        per_setting[setting] = OrderedDict()
        for index, keyset in enumerate(KEYSETS):
            cells = [g for g in grid if g[2] == setting]
            per_setting[setting][keyset] = "%d/%d" % (sum(1 for g in cells if g[3][index] == "a"), len(cells))
    extra = OrderedDict(
        evidence="verifier-side SIMULATION (Options.AssumeCompromised) on synthetic fixture runs",
        mutants=int(head.group(1)), not_applicable=int(head.group(2)), independent_cells=int(head.group(3)),
        independent_cell_variant_pairs=int(head.group(4)), independent_verifications=int(head.group(5)),
        keys_anchored_repeats_cells=int(anchored.group(1)), keys_anchored_repeats_verifications=int(anchored.group(2)),
        provider_signed_edit_mutants=int(provider.group(1)), provider_signed_edit_mutant_names=provider.group(2).split(),
        provider_signed_edit_pairs=int(provider.group(3)),
        no_replay_no_snapshot_equals_no_replay="%s/%s" % same_row.groups(),
        accepted_cells_per_setting=per_setting, tallies=tallies)
    with open(os.path.join(HERE, "extra_keysets_summary.json"), "w", encoding="utf-8", newline="\n") as handle:
        json.dump(extra, handle, indent=2)
        handle.write("\n")
    summary["extra_keysets"] = OrderedDict((k, extra[k]) for k in ("independent_cells", "independent_cell_variant_pairs",
                                                                  "independent_verifications", "tallies"))

    # --- the fixture grid against the frozen gateway-run grid ------------------
    frozen = {}
    with open(FROZEN, encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            if row["anchors"] == "none":
                frozen[(row["design"], row["operator"], row["verifier_config"], row["keyset"])] = row["outcome"]
    rows, agree, disagree, causes = [], 0, 0, Counter()
    for design, operator, setting, marks in grid:
        for index, keyset in enumerate(KEYSETS):
            if keyset not in FROZEN_NAMES:
                continue
            frozen_outcome = frozen.get((design, operator, setting, FROZEN_NAMES[keyset]))
            if frozen_outcome is None:
                continue
            fixture_accepted = marks[index] == "a"
            frozen_accepted = frozen_outcome == "undetected"
            cause = ""
            if fixture_accepted == frozen_accepted:
                agree += 1
            else:
                disagree += 1
                if operator == "relabel-approved" and setting in ("full", "no-snapshot-bound-only") and fixture_accepted:
                    cause = ("fixture: the human-mode fixture run.json has no policy snapshot, so policy.replay is "
                             "not_checked (logs/probe-relabel-approved.log); the gateway's human-mode runs carry one and "
                             "policy.replay detects the relabel")
                else:
                    cause = "UNEXPLAINED"
                causes[cause.split(":")[0]] += 1
            rows.append([design, operator, setting, keyset, "accepted" if fixture_accepted else "detected",
                         "accepted" if frozen_accepted else "detected", "yes" if fixture_accepted == frozen_accepted else "no", cause])
    write_csv("fixture_vs_frozen_grid.csv", ["design", "operator", "setting", "key_set", "fixture_simulation",
                                             "frozen_build1_grid_anchors_none", "agree", "cause"], rows)
    summary["fixture_vs_frozen_grid"] = OrderedDict(compared=agree + disagree, agree=agree, disagree=disagree, causes=dict(causes))

    # --- simulation agreement (build 2 and the build-1 tree) -------------------
    def cells(text):
        out, current = OrderedDict(), ""
        for line in text.splitlines():
            run = re.match(r"=== RUN\s+TestSimulationAgreesWithRealAuditKeyResigning/(\S+)", line)
            if run:
                current = run.group(1)
                continue
            match = re.search(r"compromise_test\.go:\d+: anchors (\S+)\s+(\S+)/(\S+) \[(.*)\]", line)
            if match and current:
                out[(current, match.group(1))] = (match.group(2), match.group(3), match.group(4))
        return out
    build2 = cells(read("s6-simulation-validation.testbin.log"))
    build1 = cells(read("s6-simulation-validation.build1-tree.log"))
    rows = []
    for key, value in build2.items():
        other = build1.get(key)
        rows.append([key[0], key[1], value[0], value[1], value[2], " / ".join(other) if other else "", "yes" if other == value else "no"])
    write_csv("simulation_agreement.csv", ["edit", "anchors", "verdict", "assurance", "failing_checks_with_counts",
                                           "build1_tree_same_cell", "same_as_build1_tree"], rows)
    role_cases = [name for name in results(read("s6-simulation-validation.testbin.log")) if name.startswith("TestEachRoleUnderSimulation/")]
    summary["simulation_validation"] = OrderedDict(
        real_vs_simulated_cells=len(build2), edits=len({k[0] for k in build2}),
        identical_to_build1_tree=sum(1 for r in rows if r[-1] == "yes"), each_role_cases=len(role_cases))

    with open(os.path.join(HERE, "summary.json"), "w", encoding="utf-8", newline="\n") as handle:
        json.dump(summary, handle, indent=2)
        handle.write("\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
