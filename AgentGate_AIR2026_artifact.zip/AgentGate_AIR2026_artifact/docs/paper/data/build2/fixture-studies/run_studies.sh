#!/usr/bin/env bash
# Runs the six fixture studies twice: (a) with the hashed test binaries built by
# `go test -c` (primary; run from the package directory, as `go test` does) and
# (b) with the literal `go test -v -count=1 -run ...` command (cross-check).
# Raw logs go to raw/<study>.{bin,gotest}.log in this folder.
set -u
REPO="${REPO:?set REPO=<repo>}"
W="${W:?set W=<scratch>/build2-work/fixture-studies}"
export GOMODCACHE="$REPO/.tools/go-host-cache-20260916/mod" GOPROXY=off GOFLAGS=-mod=readonly GOTOOLCHAIN=local
export GOCACHE="${GOCACHE:-$W/gocache}"
GO=$REPO/.tools/go-1.26.6/bin/go.exe
mkdir -p "$W/raw"

# study | package dir (relative) | test binary | -run regex
STUDIES=(
"s1-lifecycle|internal/auditverify|auditverify|TestLifecycle|TestRecoveryRecords|TestReconciledAdapterReceipt|TestReplayedAndConfirming"
"s1b-lifecycle-states|internal/auditverify|auditverify|^(TestClassificationEvidenceByLifecycleState|TestUnboundFlagsTextsNameTheLogNotTheCapability)$"
"s2-extra-keysets|internal/auditverify|auditverify|TestExtraKeySets"
"s3a-registration|internal/headwitness|headwitness|^(TestRealWitnessAnchorsAGenuineRestart|TestPreemptedRegistrationDeniesWitnessingButNeverAnchors|TestFalseContinuationDeniesTheGenuineSegmentItsAnchor|TestFalseContinuationRegisteredFirstIsAnchored)$"
"s3b-verifier-clock-freshness|internal/auditverify|auditverify|^(TestWitnessStatusClockWindowBoundaries|TestWitnessStatusSignedBeforeItsHeadIsRefused|TestWitnessClockBehindTheHeadTimeIsNotCompared|TestRestartSegmentStartingBeforeThePreviousEndVerifies|TestTimeStepsInsideASegment|TestForwardTimeJumpsInsideASegment|TestRecordedGapLongerThanTheCapabilityLifetimeIsNotCompared|TestSavedHeadIsAnchoredButNotFresh|TestLiveWitnessStatusMakesTheHeadFreshAndTheRunComplete|TestWitnessStatusWindowBoundaries|TestFreshStatusOfAContinuedRunIsNotComplete|TestRunCompleteNeedsSettledOutcomesAndAnAnchoredEnd|TestHeadFreshForARefusedWitness|TestHeadFreshPassReasonClaimsOnlyWhatTheStatusShows|TestMissingKinds|TestDerivedDimensionsOwnNoCheck)$"
"s4-gateway-clock-restart-flag|internal/devcomposition|devcomposition|^(TestBackwardClockStepFailsCapabilityIssuanceClosed|TestForwardJumpBetweenIssueAndConsume|TestRollbackAboveTheRegistryFloorRevivesAnExpiredGrantInProcess|TestRestartWithARolledBackClockRevivesAnExpiredGrant|TestAuditLogKeepsTimeNonDecreasingAcrossABackwardStep|TestRestartAfterCrashBetweenDispatchIntentAndOutcomeKeepsTheFlag|TestRestartReplaysDispatchIntentsWithoutTheFlagField|TestReplayedCommittedAnswersKeepTheFlag|TestNotCommittedAnswersStateNoFlag|TestExpiredLeaseDispatchIntentCarriesTheFlag)$"
"s5-flagged-recovery-e2e|cmd/agentgate-eval|agentgate-eval|^TestFlaggedOperationRecoveryVerifies$"
"s6-simulation-validation|internal/auditverify|auditverify|^(TestSimulationAgreesWithRealAuditKeyResigning|TestEachRoleUnderSimulation)$"
)

for spec in "${STUDIES[@]}"; do
  name=${spec%%|*}; rest=${spec#*|}
  pkg=${rest%%|*}; rest=${rest#*|}
  bin=${rest%%|*}; regex=${rest#*|}
  echo "== $name ($pkg) $(date -u +%FT%TZ)"
  start=$(date +%s.%N)
  ( cd "$REPO/$pkg" && "$W/testbin/$bin.test.exe" -test.v -test.count=1 -test.run "$regex" ) > "$W/raw/$name.bin.log" 2>&1
  rc1=$?
  mid=$(date +%s.%N)
  ( cd "$REPO" && "$GO" test -v -count=1 -run "$regex" "./$pkg/" ) > "$W/raw/$name.gotest.log" 2>&1
  rc2=$?
  end=$(date +%s.%N)
  printf '%s bin_exit=%d bin_wall_s=%.1f gotest_exit=%d gotest_wall_s=%.1f\n' "$name" $rc1 "$(awk "BEGIN{print $mid - $start}")" $rc2 "$(awk "BEGIN{print $end - $mid}")" | tee -a "$W/raw/exit-codes.txt"
done
