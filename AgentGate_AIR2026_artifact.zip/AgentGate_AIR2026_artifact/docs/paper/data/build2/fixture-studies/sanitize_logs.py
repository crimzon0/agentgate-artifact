#!/usr/bin/env python3
"""Copy the raw `go test -v` logs of the fixture studies into logs/, with every
machine-specific string replaced by a placeholder.

usage: python sanitize_logs.py RAW_DIR
  RAW_DIR  the scratch folder raw/ written by run_studies.sh
           (<scratch>/build2-work/fixture-studies/raw)

Replacements: the repository path -> <repo>, the scratch path -> <scratch>,
the frozen build folder -> <singlebuild2>, any other temp path -> <tmp>, the
Windows user name -> <user>, the machine name -> <host>. The logs written by
the run contain none of these (the tests print no paths); the script also
fails if anything that looks like a drive path survives.
Standard library only.
"""
import os
import re
import socket
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = sys.argv[1]
OUT = os.path.join(HERE, "logs")
USER = os.environ.get("USERNAME") or os.environ.get("USER") or ""
HOST = socket.gethostname()

# The logs kept in the repository: study name -> (raw file, kept file).
KEEP = {}
for name in sorted(os.listdir(RAW)):
    if name.endswith(".bin.log"):
        KEEP[name] = name.replace(".bin.log", ".testbin.log")
    elif name.endswith(".gotest.log"):
        KEEP[name] = name
    elif name.endswith(".build1tree.log"):
        KEEP[name] = name.replace(".build1tree.log", ".build1-tree.log")
    elif name in ("probe-relabel-approved.log", "exit-codes.txt"):
        KEEP[name] = name


def variants(path):
    """The spellings of a local path: with backslashes, with forward slashes
    and in the MSYS form (/<drive letter>/...)."""
    path = os.path.abspath(path)
    forward = path.replace("\\", "/")
    out = {path, forward}
    if re.match(r"^[A-Za-z]:/", forward):
        out.add("/" + forward[0].lower() + forward[2:])
    return sorted(out, key=len, reverse=True)


REPO = os.path.abspath(os.path.join(HERE, "..", "..", "..", "..", ".."))
SCRATCH = os.path.abspath(os.path.join(RAW, "..", "..", ".."))
REPLACEMENTS = ([(v, "<singlebuild2>") for v in variants(os.path.join(SCRATCH, "singlebuild2"))] +
                [(v, "<scratch>") for v in variants(SCRATCH)] +
                [(v, "<repo>") for v in variants(REPO)] +
                [(v, "<tmp>") for v in variants(os.environ.get("TEMP") or os.environ.get("TMPDIR") or "/tmp")])


def sanitize(text):
    for value, placeholder in REPLACEMENTS:
        text = re.sub(re.escape(value), placeholder, text, flags=re.I)
    if USER:
        text = re.sub(re.escape(USER), "<user>", text, flags=re.I)
    if HOST:
        text = re.sub(re.escape(HOST), "<host>", text, flags=re.I)
    return text


def main():
    os.makedirs(OUT, exist_ok=True)
    for raw, kept in KEEP.items():
        with open(os.path.join(RAW, raw), encoding="utf-8", errors="replace") as handle:
            text = sanitize(handle.read().replace("\r\n", "\n"))
        if re.search(r"\b[A-Za-z]:[\\/]|(^|\s)/[a-z]/[A-Za-z]", text, re.M):
            sys.exit("a local path survived in %s" % raw)
        with open(os.path.join(OUT, kept), "w", encoding="utf-8", newline="\n") as handle:
            handle.write(text)
        print("%-45s -> logs/%s" % (raw, kept))


if __name__ == "__main__":
    main()
