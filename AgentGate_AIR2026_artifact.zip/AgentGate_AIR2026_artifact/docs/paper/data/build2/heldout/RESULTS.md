# Held-out mutation operators on build 2

This is the first campaign of the three held-out mutation operators defined
in `docs/paper/data/revision/robustness/HELDOUT_OPERATORS.md` (frozen in
commit `103a438`, addendum section 7 including 7.10 and 7.11, last commit
`be5e88c` at 02:04:40 UTC). It answers review 2, major comment 7, for the
paper revision that replies to the supervisor's second review. It uses
**build 2**: commit `86643d7` of branch `claude/supervisor-demo`, frozen
binaries of 2026-10-10 02:24:44 UTC. The mutants ran 05:07-07:19 UTC on
2026-10-10.

**Build 1 has no held-out result.** The operators were frozen on 2026-10-10,
after build 1 (2026-10-08). The comparison point is variant 3: the frozen
document defines it as a full export of commit `f01d1c9`, whose verifier
source and tests are byte-identical to build 1's (`build-manifest.txt`). So
variant 3 is "the held-out operators against build 1's verifier and suite".
Section 3 compares it, and the frozen pre-run values (site counts, ceilings,
compile check, validation mutants), with build 2.

**Headline** (the kill score is killed / (killed + survived), with every
survivor in the denominator):

| operator | variant 1: build 2, full suite | variant 2: build 2, without the 4 post-hoc tests | variant 3: build 1 source and suite (`f01d1c9`), without the 4 |
|---|---|---|---|
| H1 `append` (delete one finding) | **63/164 = 0.384** (ceiling 107/164 = 0.652) | **58/164 = 0.354** (ceiling 99/164 = 0.604) | **52/153 = 0.340** (ceiling 84/153 = 0.549) |
| H2 `boundary` (swap `<`/`<=`, `>`/`>=`) | **52/123 = 0.423** | **51/123 = 0.415** | **43/117 = 0.368** |
| H3 `equality` (a hash or byte comparison always says "equal") | **29/71 = 0.408** | **18/71 = 0.254** | **16/66 = 0.242** |
| all three | **144/358 = 0.402** | **127/358 = 0.355** | **111/336 = 0.330** |

- No build errors and no timeouts in the reported runs (0 of 358, 358, 336).
  The first run of H2 on variant 1 had 3 out-of-memory failures; it was
  repeated (section 2.4).
- For comparison, the refusal-site operator that the suite was strengthened
  against scores 142/142 with the full suite and 58/142 = 0.408 without the
  same four tests (`../robustness/RESULTS.md`). The held-out operators show
  that the full suite's 1.000 does not carry over to other defect classes:
  the full suite kills 0.40 of the held-out mutants.
- **Why mutants survive** (variant 1, 214 survivors): 66 sit on code the
  suite never executes, 53 sit where line coverage cannot show that the
  mutated expression was evaluated, 13 are equivalent (no check result can
  change; 8 of them change only message text), and **82 are executed but
  undetected**. For H1 the never-executed share dominates (57 of 101
  survivors), and the ceiling (0.652) shows that this suite could kill at most
  107 of the 164 H1 mutants.
- **Supplementary variant 2b** (not defined by the frozen document): without
  the seven post-hoc tests that `VERIFIER_CHECKS.md` §6 names for a build
  from 2026-10-10 on: append 55/164 = 0.335 (ceiling 92/164 = 0.561),
  boundary 49/123 = 0.398, equality 17/71 = 0.239, all 121/358 = 0.338.
- No test was written or changed in response to any survivor.

## 1. What was run

Commands, with REPO = `<repo>`, E = `<scratch>/build2-work/heldout`,
SB = `<singlebuild2>` and OUT = this folder (scripts in `scripts/`):

```
py <singlebuild2>/check_manifest.py                                   # before (05:02:54Z)
bash scripts/snapshot.sh            # frozen copy of 86643d7 in $E/src (the robustness rerun's script)
bash scripts/build_tool.sh          # refusalmutation.exe from the copy, fresh GOCACHE
bash scripts/export_f01d1c9.sh      # git archive f01d1c9 -> $E/f01d1c9 (variant 3)
# site lists, both trees (in the tree's root):
refusalmutation.exe -go $GO -operator <op> -list -out $E/lists/<b2|v3>_<op>.json      # op = append, boundary, equality
python scripts/compare_sites.py <repo>/internal/auditverify/tools/refusalmutation/results/heldout_sites_<op>.json $E/lists/v3_<op>.json
siteflags.exe <tree>/internal/auditverify < ids > $E/lists/<tree>_<op>_flags.tsv    # why line coverage may not show evaluation
bash scripts/run_cover.sh           # coverage profiles of each suite variant, both trees
python scripts/test_names.py $E $OUT/test_names.json      # tests absent from variant 3 (written before its runs)
# the campaign: one tool run per operator and variant, in the tree's root
#   refusalmutation.exe -go $GO -operator <op> -parallel 8 -skip "<pattern>" -out $E/mut/heldout_<op>_<variant>.json
bash scripts/run_heldout.sh 8 v1_full v2_without_posthoc4       # ran v1 append, boundary (memory incident), equality; stopped then
bash scripts/run_heldout_split.sh 8 append,boundary,equality v2_without_posthoc4   # boundary split in two (2.4)
bash scripts/run_heldout_split_capped.sh 8 boundary v1_full     # repeat of v1 boundary
bash scripts/run_heldout_split_capped.sh 8 append,boundary,equality v3_f01d1c9
bash scripts/rerun_v1_files_part.sh                             # v1 files.go part again, watchdog version of jobcap
bash scripts/run_heldout_split_capped.sh 8 append,boundary,equality v2b_without_posthoc7
#   (scripts/drivers/ chained these; merge_parts.py joins the two boundary parts)
bash scripts/post_check.sh;  py <singlebuild2>/check_manifest.py        # after (07:19:42Z)
SANITIZE_USER=... SANITIZE_HOST=... E=$E OUT=$OUT bash scripts/assemble.sh   # raw copies + summarize_heldout.py
python scripts/compare_runs.py $E <repo> $OUT;  python scripts/write_run_manifest.py $E $OUT
python scripts/make_tables.py $OUT                                       # the tables below
```

### 1.1 Protocol (HELDOUT_OPERATORS.md sections 1-3 and 7, unchanged)

- **Files**: the non-test `.go` files directly in `internal/auditverify`
  (`fixture/`, `tools/`, tests excluded). One mutant per site, applied with
  `go test -overlay`; the source tree is never modified.
- **Test run per mutant**: `go test -count=1 -timeout=5m0s [-skip ...]
  ./internal/auditverify/... ./cmd/agentgate-verify/` (the tool's defaults),
  one more minute as a backstop. killed = tests fail; survived = tests pass;
  build errors and timeouts are reported and left out of the score.
- **Suite variants** (skip patterns in `scripts/skip_patterns.sh`,
  `run_manifest.json`):
  1. `v1_full`: build 2's frozen copy, every test (158 top-level tests in the
     three test packages: 134 in `internal/auditverify`, 10 in
     `cmd/agentgate-verify`, 14 tool tests that cannot kill a mutant, 7.8);
  2. `v2_without_posthoc4`: the same, `-skip
     '^(TestRefusalSites|TestDelegationRefusalSites|TestRestartProviderJournalCutBack|TestRestartContinuationRemovedFromRunRecord)$'`
     (the pattern section 1 freezes);
  3. `v3_f01d1c9`: the `f01d1c9` export with its own tests (114 top-level
     tests; no tool tests), the same four-test `-skip`. The build-2 tool's
     `-list` in the export reproduced the committed site lists exactly
     (append 153, boundary 117, equality 66; `raw/v3_list_gate.txt`), so the
     run went ahead (7.2). The 44 tests that exist in build 2 but not at
     `f01d1c9` are in `test_names.json`, written at 05:10:52 UTC, before the
     variant-3 runs (06:31 UTC).
  - 2b (supplementary): build 2 with the seven-test pattern of
    `VERIFIER_CHECKS.md` §6 (the four plus `TestRecoveryRecordsStateTheBoundFlag`,
    `TestReconciledAdapterReceipt`, `TestReplayedAndConfirmingAnswersStateTheBoundFlag`,
    written together with the 2026-10-10 refusal sites). It matches the
    pattern behind the robustness rerun's honest score (0.394).
- **Workers**: `-parallel 8` instead of the tool default 6, to finish in about
  two hours. It changes no result; the machine's CPU was at about 100 %
  throughout (`raw/logs/cpu_*.csv`). Every run's baseline (the unmutated
  suite) passed first: 13.2-17.3 s on build 2, 9.3-9.4 s on `f01d1c9`.

### 1.2 Coverage join and survivor classification (sections 5, 7.4, 7.10)

- **Profiles**: set-mode coverage of `internal/auditverify` by the same test
  packages and skip pattern as each variant (`scripts/run_cover.sh`). The
  three build-2 profiles are byte-identical to the robustness rerun's.
- **Join**: the site's line and column (its `id`); among the profile blocks
  of the file that contain it, the innermost; executed when any count of that
  block is above zero. A site in no block is unmapped. On build 2, no append
  site, 21 boundary sites and 14 equality sites are unmapped, all switch case
  expressions, as the 7.10 probe predicted.
- **Groups**, each survivor in exactly one:
  - *not executed*: its block did not run;
  - *evaluation not shown*: unmapped (switch case expression), or its block
    ran but it is the right operand of `&&`/`||` ("line executed, evaluation
    not shown"). `siteflags` (`scripts/siteflags/`) re-derives from the AST
    why the tool flagged a site `eval_not_shown`; its flags agree with the
    tool's on every site of both trees. The two H1 sites inside one-line
    function literals (`decisions.go:277:44`, `:305:44`) map to the literal's
    own block and get plain labels (7.10);
  - *equivalent*: the block ran and the mutant cannot change any check
    status, dimension or verdict for any input (by hand, one-line argument
    each in `equivalence.csv`);
  - *executed but undetected*: the block ran, otherwise.
- **Equivalence, as applied here.** Section 5's own example ("the deleted
  finding is always reported by another line") counts a mutant as equivalent
  although the report's detail text changes. The classification therefore
  ignores detail text. Mutants that change *only* message text (`short()`,
  `shortOp()`, a reason string, a segment prefix) are marked "text only" and
  counted apart, because a text-checking test can kill them: one of them,
  `segments.go:200:44`, is killed in variants 1 and 2 by
  `TestRecoveryRecordsStateTheBoundFlag`. All 187 survivors (counted by tree
  and site, over all variants) whose block ran and that are not right
  operands were classified: the 102 build-2 sites and 4 `f01d1c9` sites have
  a row of their own (106 rows), and the other 81 `f01d1c9` survivors take
  the verdict of the same build-2 site because their enclosing function is
  byte-identical in both trees. None is left unassessed. A mutant is
  called not equivalent as soon as one distinguishing input is named; inputs
  may be anything the verifier can be given, including evidence re-signed
  with compromised keys or the `-unbound-flags` option. The score without
  equivalent mutants is shown next to the headline, never instead of it, in
  two forms (all equivalents removed; text-only ones kept).

### 1.3 Sites

| operator | build 2 (variants 1, 2, 2b) | `f01d1c9` (variant 3; = section 4) | added in build 2 (none removed) |
|---|---|---|---|
| H1 `append` | 164 | 153 | 11, all in `checkReconciledReceipt` (the RECONCILED adapter receipt, 2026-10-10) |
| H2 `boundary` | 123 | 117 | 6: five in `freshness.go` (new), `len(problems) > 0` in `checkReconciledReceipt` |
| H3 `equality` | 71 | 66 | 5, all in `checkReconciledReceipt` |
| all | 358 | 336 | 22 |

- Sites are matched across trees on file, function, label, class and source
  text (`site_diff_f01d1c9_to_build2.json`); every `f01d1c9` site has a
  build-2 counterpart, 119 of them on moved lines.
- Splits on build 2: H1 has the same 12 group deletions as 7.5 lists
  (`operations.go:391` is now `:445`), so 152 single deletions; H2 has 59
  comparisons with literal 0 (emptiness 40, count 13, time 4, budget 2) and
  40 emptiness sites; H2 and H3 verifier-only sites: 113 and 68 (10 H2 and 3
  H3 sites are in `tamper.go` and `parallel.go`). `eval_not_shown` flags:
  append 2, boundary 47, equality 38 (`f01d1c9`: 2, 45, 38, as 7.4 says).

## 2. Results

### 2.1 Every site, per operator and variant

| variant | operator | sites | killed | survived | build errors | timeouts | kill score | survivors: not executed / evaluation not shown / equivalent / executed but undetected | ceiling (sites whose block ran) |
|---|---|---|---|---|---|---|---|---|---|
| 1: build 2, full suite | append | 164 | 63 | 101 | 0 | 0 | 63/164 = 0.384 | 57 / 0 / 2 / 42 | 107/164 = 0.652 |
| 1: build 2, full suite | boundary | 123 | 52 | 71 | 0 | 0 | 52/123 = 0.423 | 8 / 31 / 11 / 21 | 94/123 = 0.764 |
| 1: build 2, full suite | equality | 71 | 29 | 42 | 0 | 0 | 29/71 = 0.408 | 1 / 22 / 0 / 19 | 56/71 = 0.789 |
| 1: build 2, full suite | **all three** | 358 | 144 | 214 | 0 | 0 | **144/358 = 0.402** | 66 / 53 / 13 / 82 | |
| 2: build 2, without the 4 post-hoc tests | append | 164 | 58 | 106 | 0 | 0 | 58/164 = 0.354 | 65 / 0 / 2 / 39 | 99/164 = 0.604 |
| 2: build 2, without the 4 post-hoc tests | boundary | 123 | 51 | 72 | 0 | 0 | 51/123 = 0.415 | 8 / 31 / 11 / 22 | 94/123 = 0.764 |
| 2: build 2, without the 4 post-hoc tests | equality | 71 | 18 | 53 | 0 | 0 | 18/71 = 0.254 | 2 / 28 / 0 / 23 | 55/71 = 0.775 |
| 2: build 2, without the 4 post-hoc tests | **all three** | 358 | 127 | 231 | 0 | 0 | **127/358 = 0.355** | 75 / 59 / 13 / 84 | |
| 3: f01d1c9 (build 1 verifier and tests), without the 4 | append | 153 | 52 | 101 | 0 | 0 | 52/153 = 0.340 | 69 / 0 / 2 / 30 | 84/153 = 0.549 |
| 3: f01d1c9 (build 1 verifier and tests), without the 4 | boundary | 117 | 43 | 74 | 0 | 0 | 43/117 = 0.368 | 8 / 32 / 11 / 23 | 90/117 = 0.769 |
| 3: f01d1c9 (build 1 verifier and tests), without the 4 | equality | 66 | 16 | 50 | 0 | 0 | 16/66 = 0.242 | 2 / 29 / 0 / 19 | 50/66 = 0.758 |
| 3: f01d1c9 (build 1 verifier and tests), without the 4 | **all three** | 336 | 111 | 225 | 0 | 0 | **111/336 = 0.330** | 79 / 61 / 13 / 72 | |
| 2b (suppl.): build 2, without the 7 post-hoc tests | append | 164 | 55 | 109 | 0 | 0 | 55/164 = 0.335 | 72 / 0 / 2 / 35 | 92/164 = 0.561 |
| 2b (suppl.): build 2, without the 7 post-hoc tests | boundary | 123 | 49 | 74 | 0 | 0 | 49/123 = 0.398 | 9 / 31 / 12 / 22 | 93/123 = 0.756 |
| 2b (suppl.): build 2, without the 7 post-hoc tests | equality | 71 | 17 | 54 | 0 | 0 | 17/71 = 0.239 | 7 / 28 / 0 / 19 | 50/71 = 0.704 |
| 2b (suppl.): build 2, without the 7 post-hoc tests | **all three** | 358 | 121 | 237 | 0 | 0 | **121/358 = 0.338** | 88 / 59 / 14 / 76 | |

- **Ceiling.** The H1 ceiling (7.3) is the share of sites whose block the
  variant's suite runs: a deleted line that never runs cannot change a
  result. The H1 ceilings for variants 1 and 2 are recomputed from build 2's
  profiles (107/164 = 0.652, 99/164 = 0.604); 0.608 and 0.549 are not their
  ceilings. Variant 3 gets 84/153 = 0.549, the value section 4 gave in
  advance. For H2 and H3 the same column is informative only: unmapped sites
  (switch cases) may be evaluated, so the upper bound there is (executed +
  unmapped) / sites, for variant 1 115/123 and 70/71 (`ceilings.json`).
- **Survivors executed vs not executed by that suite** (the join; "block ran"
  includes right operands of `&&`/`||`):

  | variant | append: block ran / not run | boundary: block ran / not run / unmapped | equality: block ran / not run / unmapped |
  |---|---|---|---|
  | 1 | 44 / 57 | 52 / 8 / 11 | 35 / 1 / 6 |
  | 2 | 41 / 65 | 53 / 8 / 11 | 42 / 2 / 9 |
  | 3 | 32 / 69 | 54 / 8 / 12 | 39 / 2 / 9 |
  | 2b | 37 / 72 | 54 / 9 / 11 | 38 / 7 / 9 |

  Sanity check: no killed mutant sits on a block its variant's suite does not
  run.
- **By class** (variant 1): H2 emptiness 31/40, count 10/18, length 6/21,
  time 4/26, budget 1/9, limit 0/9; H3 `if` 21/57, switch case 8/14
  (`by_class` in the reports; per file and per function in `by_file`,
  `by_func`).

### 2.2 Declared splits (7.1, 7.5, 7.6) and the score without equivalent mutants

| variant | operator | split | sites | killed / (killed + survived) | survivors: not executed / evaluation not shown / equivalent (of which text only) / executed but undetected | without equivalent | without equivalent, text-only kept |
|---|---|---|---|---|---|---|---|
| v1 | append | all sites | 164 | 63/164 = 0.384 | 57 / 0 / 2 (0) / 42 | 63/162 = 0.389 | 63/162 = 0.389 |
| v1 | append | the 152 single deletions | 152 | 53/152 = 0.349 | 57 / 0 / 2 (0) / 40 | 53/150 = 0.353 | 53/150 = 0.353 |
| v1 | append | the 12 group deletions | 12 | 10/12 = 0.833 | 0 / 0 / 0 (0) / 2 | 10/12 = 0.833 | 10/12 = 0.833 |
| v1 | boundary | all sites | 123 | 52/123 = 0.423 | 8 / 31 / 11 (8) / 21 | 52/112 = 0.464 | 52/120 = 0.433 |
| v1 | boundary | without emptiness | 83 | 21/83 = 0.253 | 4 / 27 / 10 (7) / 21 | 21/73 = 0.288 | 21/80 = 0.263 |
| v1 | boundary | without comparisons with literal 0 | 64 | 13/64 = 0.203 | 3 / 21 / 8 (5) / 19 | 13/56 = 0.232 | 13/61 = 0.213 |
| v1 | boundary | comparisons with literal 0 only | 59 | 39/59 = 0.661 | 5 / 10 / 3 (3) / 2 | 39/56 = 0.696 | 39/59 = 0.661 |
| v1 | boundary | verifier only (no tamper.go, parallel.go) | 113 | 51/113 = 0.451 | 8 / 30 / 9 (7) / 15 | 51/104 = 0.490 | 51/111 = 0.459 |
| v1 | equality | all sites | 71 | 29/71 = 0.408 | 1 / 22 / 0 (0) / 19 | 29/71 = 0.408 | 29/71 = 0.408 |
| v1 | equality | verifier only (no tamper.go, parallel.go) | 68 | 28/68 = 0.412 | 1 / 20 / 0 (0) / 19 | 28/68 = 0.412 | 28/68 = 0.412 |
| v2 | append | all sites | 164 | 58/164 = 0.354 | 65 / 0 / 2 (0) / 39 | 58/162 = 0.358 | 58/162 = 0.358 |
| v2 | append | the 152 single deletions | 152 | 48/152 = 0.316 | 65 / 0 / 2 (0) / 37 | 48/150 = 0.320 | 48/150 = 0.320 |
| v2 | append | the 12 group deletions | 12 | 10/12 = 0.833 | 0 / 0 / 0 (0) / 2 | 10/12 = 0.833 | 10/12 = 0.833 |
| v2 | boundary | all sites | 123 | 51/123 = 0.415 | 8 / 31 / 11 (8) / 22 | 51/112 = 0.455 | 51/120 = 0.425 |
| v2 | boundary | without emptiness | 83 | 20/83 = 0.241 | 4 / 27 / 10 (7) / 22 | 20/73 = 0.274 | 20/80 = 0.250 |
| v2 | boundary | without comparisons with literal 0 | 64 | 12/64 = 0.188 | 3 / 21 / 8 (5) / 20 | 12/56 = 0.214 | 12/61 = 0.197 |
| v2 | boundary | comparisons with literal 0 only | 59 | 39/59 = 0.661 | 5 / 10 / 3 (3) / 2 | 39/56 = 0.696 | 39/59 = 0.661 |
| v2 | boundary | verifier only (no tamper.go, parallel.go) | 113 | 50/113 = 0.442 | 8 / 30 / 9 (7) / 16 | 50/104 = 0.481 | 50/111 = 0.450 |
| v2 | equality | all sites | 71 | 18/71 = 0.254 | 2 / 28 / 0 (0) / 23 | 18/71 = 0.254 | 18/71 = 0.254 |
| v2 | equality | verifier only (no tamper.go, parallel.go) | 68 | 17/68 = 0.250 | 2 / 26 / 0 (0) / 23 | 17/68 = 0.250 | 17/68 = 0.250 |
| v3 | append | all sites | 153 | 52/153 = 0.340 | 69 / 0 / 2 (0) / 30 | 52/151 = 0.344 | 52/151 = 0.344 |
| v3 | append | the 141 single deletions | 141 | 42/141 = 0.298 | 69 / 0 / 2 (0) / 28 | 42/139 = 0.302 | 42/139 = 0.302 |
| v3 | append | the 12 group deletions | 12 | 10/12 = 0.833 | 0 / 0 / 0 (0) / 2 | 10/12 = 0.833 | 10/12 = 0.833 |
| v3 | boundary | all sites | 117 | 43/117 = 0.368 | 8 / 32 / 11 (8) / 23 | 43/106 = 0.406 | 43/114 = 0.377 |
| v3 | boundary | without emptiness | 81 | 16/81 = 0.198 | 4 / 28 / 10 (7) / 23 | 16/71 = 0.225 | 16/78 = 0.205 |
| v3 | boundary | without comparisons with literal 0 | 63 | 9/63 = 0.143 | 3 / 22 / 8 (5) / 21 | 9/55 = 0.164 | 9/60 = 0.150 |
| v3 | boundary | comparisons with literal 0 only | 54 | 34/54 = 0.630 | 5 / 10 / 3 (3) / 2 | 34/51 = 0.667 | 34/54 = 0.630 |
| v3 | boundary | verifier only (no tamper.go, parallel.go) | 107 | 42/107 = 0.393 | 8 / 31 / 9 (7) / 17 | 42/98 = 0.429 | 42/105 = 0.400 |
| v3 | equality | all sites | 66 | 16/66 = 0.242 | 2 / 29 / 0 (0) / 19 | 16/66 = 0.242 | 16/66 = 0.242 |
| v3 | equality | verifier only (no tamper.go, parallel.go) | 63 | 15/63 = 0.238 | 2 / 27 / 0 (0) / 19 | 15/63 = 0.238 | 15/63 = 0.238 |
| v2b | append | all sites | 164 | 55/164 = 0.335 | 72 / 0 / 2 (0) / 35 | 55/162 = 0.340 | 55/162 = 0.340 |
| v2b | append | the 152 single deletions | 152 | 45/152 = 0.296 | 72 / 0 / 2 (0) / 33 | 45/150 = 0.300 | 45/150 = 0.300 |
| v2b | append | the 12 group deletions | 12 | 10/12 = 0.833 | 0 / 0 / 0 (0) / 2 | 10/12 = 0.833 | 10/12 = 0.833 |
| v2b | boundary | all sites | 123 | 49/123 = 0.398 | 9 / 31 / 12 (9) / 22 | 49/111 = 0.441 | 49/120 = 0.408 |
| v2b | boundary | without emptiness | 83 | 19/83 = 0.229 | 4 / 27 / 11 (8) / 22 | 19/72 = 0.264 | 19/80 = 0.237 |
| v2b | boundary | without comparisons with literal 0 | 64 | 11/64 = 0.172 | 3 / 21 / 9 (6) / 20 | 11/55 = 0.200 | 11/61 = 0.180 |
| v2b | boundary | comparisons with literal 0 only | 59 | 38/59 = 0.644 | 6 / 10 / 3 (3) / 2 | 38/56 = 0.679 | 38/59 = 0.644 |
| v2b | boundary | verifier only (no tamper.go, parallel.go) | 113 | 48/113 = 0.425 | 9 / 30 / 10 (8) / 16 | 48/103 = 0.466 | 48/111 = 0.432 |
| v2b | equality | all sites | 71 | 17/71 = 0.239 | 7 / 28 / 0 (0) / 19 | 17/71 = 0.239 | 17/71 = 0.239 |
| v2b | equality | verifier only (no tamper.go, parallel.go) | 68 | 16/68 = 0.235 | 7 / 26 / 0 (0) / 19 | 16/68 = 0.235 | 16/68 = 0.235 |

- **H2 is mostly killed where the swap makes a condition constant.** The
  comparisons with literal 0 (which include emptiness) score 39/59 = 0.661
  on variant 1; without them, the "boundary moved by one" mutants score
  13/64 = 0.203. `limit` (0/9), `budget` (1/9) and `time` (4/26) are almost
  never killed: no test sits exactly on a time window edge, a budget limit, a
  count limit, a size limit or a nesting limit.
- **H1 group deletions** are killed 10 of 12 times in every variant. The two
  survivors are the `add` closure of `decisionBinding` (`decisions.go:277:44`)
  and the catalog findings of `replayDecision` (`replay.go:473`), both
  executed but undetected.

### 2.3 Survivor labels (7.4)

| variant | operator | not executed | line executed, evaluation not shown | evaluation not shown (switch case, unmapped) | equivalent | executed but undetected |
|---|---|---|---|---|---|---|
| v1 | append | 57 | 0 | 0 | 2 | 42 |
| v1 | boundary | 8 | 20 | 11 | 11 | 21 |
| v1 | equality | 1 | 16 | 6 | 0 | 19 |
| v2 | append | 65 | 0 | 0 | 2 | 39 |
| v2 | boundary | 8 | 20 | 11 | 11 | 22 |
| v2 | equality | 2 | 19 | 9 | 0 | 23 |
| v3 | append | 69 | 0 | 0 | 2 | 30 |
| v3 | boundary | 8 | 20 | 12 | 11 | 23 |
| v3 | equality | 2 | 20 | 9 | 0 | 19 |
| v2b | append | 72 | 0 | 0 | 2 | 35 |
| v2b | boundary | 9 | 20 | 11 | 12 | 22 |
| v2b | equality | 7 | 19 | 9 | 0 | 19 |

No separate check was run to settle the "evaluation not shown" sites (7.4
allows one); they stay in their own group.

**Where the executed-but-undetected survivors are** (variant 1, 82 in all;
`heldout_survivors.csv`): `operations.go` 40, most of them in the receipt and
capability binding (`checkReceipts` 15, `checkReconciledReceipt` 8,
`checkCapability` 6), the human-approval binding (`decisionProblems` 4,
`checkApprovalForCapability` 3) and `requirePolicy` 3; then `delegation.go`
8, `reconcile.go` 5, `replay.go` 5, `decisions.go` 4, `verify.go` 4 (three
are chain links: a wrong `seq` alone or a wrong `prev_hash` alone is never
tested, because the tamper tests change both), `witness.go` 4, `tamper.go` 4 and 8 more in six
files. Typically the condition is a field of a signed artifact (operation,
action digest, provider reference, policy decision hash) that tests only ever
change together with another field, so a second finding still fails the
check. Each such mutant was given a concrete input on which it changes a
check result (`equivalence.csv`).

**The 13 equivalent mutants on build 2** (variant 1): `requirePolicy`'s
findings "no POLICY_DECISION precedes it" (`operations.go:426`) and "confirms
policy decision ..., which is not a policy decision recorded"
(`operations.go:442`), each always accompanied by another finding of the
same check; two position comparisons in `decisionBounds`
(`delegation.go:554`, `:555`) whose operands are lines of different
operations and so never equal; `tamper.go:894`, which then assigns an equal
value; and 8 text-only mutants. Variant 2b adds `segments.go:200:44` (text
only).

### 2.4 The memory incident (no effect on the reported results)

- In the first H2 run on variant 1 (05:23-05:35 UTC), the mutant
  `files.go:237:30` (`parseLog`: `len(rest) > 0` becomes `>= 0`) never left
  its loop and grew its heap until an allocation request of 20.9 GB failed
  after 197 s. It was killed (the test process crashed). While it ran, the machine's
  commit limit was exhausted, and three concurrent mutants failed with
  "paging file is too small" or "cannot allocate memory", which the tool
  reports as build errors.
- That run is kept (`raw/reports/heldout_boundary_v1_full.run1_memory_incident.json`)
  and was repeated. Mutant by mutant (`memory_incident.json`): 120 of 123
  results are identical; the three "build errors" became survived
  (`operations.go:468:58`, `parallel.go:61:16`) and killed
  (`operations.go:934:19`). No other result changed, so the incident caused
  no false kill.
- From then on H2 ran in two invocations (`merge_parts.py`): every file but
  `files.go` with `-parallel 8`, the three `files.go` sites with `-parallel 1`.
  Isolated (variant 2), the runaway mutant still used all free memory for
  about 2.5 minutes before an allocation request of 10.7 GB failed (killed). The
  later `files.go` parts therefore ran under `jobcap`
  (`scripts/jobcap/`), which puts the tool's process tree into a Windows job
  object:
  - version 1 (a hard 8 GiB job memory limit), used once for the variant-1
    repeat: the test process whose allocation failed at the limit hung in its
    exit; the tool's backstop classed the mutant **timeout**, and the process
    could not be terminated (it remains as a 4 GB zombie, caveats);
  - version 2 (a watchdog that terminates any job process above 8 GiB private
    commit, polled every 250 ms): variant 3, variant 2b and a second repeat of
    the variant-1 `files.go` part. The runaway test processes were terminated
    at 8,306-11,302 MiB private commit and the mutant was **killed** each
    time, as in the uncapped runs. The version-1 part is kept with the suffix `.hardcap`.
- So the reported variant-1 H2 result (52/123, 0 timeouts) uses the first
  part of the repeat and the watchdog repeat of `files.go`. With the
  version-1 part it would have been 51/122 with one timeout. The runaway
  mutant is killed in all five completed runs of it (two uncapped, three
  under the watchdog); it is a detection by crash, not by an assertion.

## 3. Comparison with build 1 and with the values fixed before the run

There is no build-1 held-out run. The table compares build 2 with variant 3
(build 1's verifier source and suite) and with every value the frozen
document stated before any held-out run.

| measurement | build 1 / pre-run value | build 2 (this run) | why it differs |
|---|---|---|---|
| H1 sites | 153 (§4, `f01d1c9`) | 164 | +11 `problem` lines of `checkReconciledReceipt`, added on 2026-10-10 (the adapter receipt on RECONCILED). The 7.10 probe on `72f07ac` already counted 164. |
| H2 sites | 117 (§4) | 123 | +5 in the new `freshness.go` (`head_fresh`, `run_complete`), +1 in `checkReconciledReceipt`. 7.2 counted 120 on an earlier tree; the 7.10 probe counted 123. |
| H3 sites | 66 (§4) | 71 | +5 comparisons in `checkReconciledReceipt`. Probe: 71. |
| unmapped sites (append / boundary / equality) | 0 / 21 / 14 (7.10 probe) | 0 / 21 / 14 | Same. All are switch case expressions. |
| `eval_not_shown` flags | 2 / 45 / 38 (7.4, `f01d1c9`) | 2 / 47 / 38 | +2 boundary sites in the new `freshness.go` (lines 127 and 135). |
| mutants that compile | 336/336 (§4 `-compileonly`) | 358/358 (0 build errors in the reported runs) | The 3 build errors of the first run were out-of-memory failures (2.4). |
| §6 validation mutants | `binding.go:78`, `:82`, `assurance.go:204`, `:209` killed; `cose.go:141:5`, `:33` survived | the same six results in variants 1 and 3 (`validation_comparison.json`) | `assurance.go` lines moved to 258 and 263 in build 2. |
| H1 ceiling, full suite | 93/153 = 0.608 (§4) | 107/164 = 0.652 | New tests (lifecycle, flag rules) execute 7 more of the matched `problem` lines, and 7 of the 11 new lines run (the other 4 are among the robustness rerun's never-executed conditions). Recomputed with the block join on the `f01d1c9` export, §4's values come out exactly (93/153, 84/153). |
| H1 ceiling, without the 4 post-hoc tests | 84/153 = 0.549 (§4, = variant 3) | 99/164 = 0.604 | As above. |
| **H1 score, without the 4** | 52/153 = 0.340 (variant 3) | 58/164 = 0.354 | +3 matched sites killed (below), +3 of the 11 new sites killed. |
| **H2 score, without the 4** | 43/117 = 0.368 (variant 3) | 51/123 = 0.415 | +3 matched sites killed, +5 of the 6 new sites killed. |
| **H3 score, without the 4** | 16/66 = 0.242 (variant 3) | 18/71 = 0.254 | +1 matched site killed, +1 of the 5 new sites killed. |
| all three, without the 4 | 111/336 = 0.330 | 127/358 = 0.355 | +7 matched, +9 new. |
| refusal-site operator (context) | 139/139; 51/139 = 0.367 (build 1) | 142/142; 58/142 = 0.408 | `../robustness/RESULTS.md`. |

**Matched sites, variant 3 against variant 2** (`build1_vs_build2.json`):
329 of the 336 `f01d1c9` sites have the same result on build 2. The other 7
went from survived to killed, and each is killed by a test that does not
exist at `f01d1c9`:

| site (build 2) | operator | killed in build 2 by |
|---|---|---|
| `operations.go:831` (`checkReceipts`: no effect_receipt) | append | `TestLifecycleConflictingHistories` |
| `operations.go:833` (`checkReceipts`: adapter receipt does not verify) | append | `TestLifecycleL4FullVerifierAllReconciled` |
| `reconcile.go:115` (`checkReconciled`) | append | `TestLifecycleConflictingHistories` |
| `operations.go:214` (`checkOperations`: `len(lines) < 2`, double spend) | boundary | `TestLifecycleConflictingHistories` |
| `replay.go:219:30` (`FIN-APPROVAL-LIMIT` at exactly the auto-approve limit) | boundary | `TestLifecycleL4FullVerifierAllReconciled` |
| `segments.go:200:44` (segment prefixes, text only) | boundary | `TestRecoveryRecordsStateTheBoundFlag` (one of the seven post-hoc tests of §6, not of the four) |
| `verify.go:997:21` (`head.anchor`: which entry the anchored hash is) | equality | `TestLifecycleL1AuditKeyDowngradeToUnresolved` |

No site went from killed to survived. The four killing tests were added in
commit `afe8730` (2026-10-10 00:34 UTC) for review-3 requests: after the
freeze commit (00:17:56 UTC) but before any held-out campaign run, when only
the six validation mutants of §6 had been tested. The verifier code changes of build 2 (classification
evidence, `Missing` kinds, `head_fresh`/`run_complete`, recovery and replay
flag checks, the RECONCILED adapter receipt) change the scores only through
the 22 new sites and these tests; `evalattack`, the custody runner and the
killsuite are outside the mutated package.

**Variant 2b against variant 2**: the three extra post-hoc tests kill 3 H1, 2
H2 and 1 H3 mutants that no test outside the seven kills; five of the six
are in `checkReconciledReceipt` (`operations.go:900`, `:905`, `:927`, `:934:19`,
`:926:7`), the sixth is `segments.go:200:44`. **Variant 1 against variant 2**:
the four post-hoc tests account for 5 H1, 1 H2 and 11 H3 kills; no mutant is
killed by variant 2 and not by variant 1 (`heldout_mutants.csv`).

## 4. Caveats

- **The 0.40 is measured against defect classes the suite was not written
  for.** It is not a statement about attacks: a surviving mutant usually means
  that another check, or another finding of the same check, still reports the
  tampering the tests use. The executed-but-undetected survivors are
  conditions that no test exercises alone.
- **Equivalence is a hand judgement** (one person, one pass, no second
  reviewer). It ignores detail text, following section 5's example; the 9
  text-only mutants are counted apart and kept in the denominator of the
  headline. "Not equivalent" rests on a named input; for two `parallel.go`
  sites that input is a panicking work item, which only a verifier defect can
  produce.
- **"Evaluation not shown" is not settled.** 53 variant-1 survivors (31 H2,
  22 H3) are right operands or switch case expressions; line coverage cannot
  say whether their expressions ran.
- **Variant 3 runs build 2's tool** in the `f01d1c9` tree, as 7.2 requires;
  its `-list` reproduced the committed site lists exactly. The `f01d1c9`
  tree has no tool tests, so its runs are slightly shorter.
- **Deviations from a single plain run per operator**: `-parallel 8`; H2 in
  two invocations after the memory incident, with `files.go` alone and
  (except in variant 2) under `jobcap`; two repeats on variant 1 (the whole
  H2 operator, then its `files.go` part). Every superseded report is kept in
  `raw/reports/`. None of this changes the per-mutant protocol.
- **A 4 GB zombie process is left on the machine**: `agentgate-verify.test.exe`
  of the runaway mutant under jobcap version 1 (since 06:25 UTC). It has
  exited but Windows has not freed it; `Stop-Process` had no effect. It holds
  about 4 GB of committed memory and will probably need a reboot to go away.
- **Shared machine**: another agent used the machine during the runs. No
  other AgentGate experiment process was running at the start of any run
  (`raw/logs/concurrent_*.txt`; from 06:31 UTC they list only this run's own
  zombie test process). Wall times are not performance results.
- **No test was written or changed**, before or after the run, in response to
  any held-out result.

## 5. Files

- `heldout_summary.json`, `heldout_summary.csv`: per variant and operator:
  counts, kill score, survivor groups and labels, every declared split, the
  ceiling, `by_file`, `by_func`, `by_class`.
- `heldout_mutants.csv`: one row per mutant and variant (1,410 rows): id,
  function, label, class, flags, coverage block and result, first failing
  test, survivor group. `heldout_survivors.csv`: the survivors with their
  equivalence verdict and argument.
- `equivalence.csv`: the hand classification (106 rows).
- `ceilings.json`: executed / unmapped / not executed sites per variant and
  operator, and the recomputed section-4 references.
- `site_diff_f01d1c9_to_build2.json`, `build1_vs_build2.json`: sites and
  results matched between the two trees.
- `validation_comparison.json`: the six §6 validation mutants against
  variants 1 and 3. `memory_incident.json`: the first variant-1 H2 run
  against its repeat.
- `test_names.json`: top-level tests of both trees; tests absent from
  variant 3; the tool's own tests.
- `run_manifest.json`: settings, skip patterns, every tool invocation with
  start, end, wall time and result, the incidents.
- `build-manifest.txt`: frozen binaries, `check_manifest.py` before and
  after, the frozen copy, the `f01d1c9` export and the gate, tool hashes.
- `raw/reports/`: every tool report (the 12 reported ones, the boundary
  parts, the superseded `run1_memory_incident` and `.hardcap` reports);
  `raw/lists/`: `-list` outputs and `siteflags` flags for both trees (and
  the `fail` list of build 2); `raw/logs/`: tool and driver logs, CPU samples,
  concurrent-process snapshots, `manual_interventions.txt`;
  `raw/coverage/`: cover profiles (`cover_profiles.tar.gz`), `go test` outputs
  and `go test -list` outputs; `raw/`: snapshot manifest, time, HEAD, git
  status and its check against `MANIFEST.txt`, the `f01d1c9` manifest, the
  list gate, `check_manifest` before and after, the post-check, tool hashes.
- `scripts/`: every script used. From `../robustness/scripts`: `env.sh`,
  `snapshot.sh`, `skip_patterns.sh`, `concurrent.ps1`, `sanitize.py` (paths
  adjusted). New: `build_tool.sh`, `export_f01d1c9.sh`, `compare_sites.py`,
  `run_cover.sh`, `test_names.py`, `run_heldout.sh`, `run_heldout_split.sh`,
  `run_heldout_split_capped.sh`, `rerun_v1_files_part.sh`, `merge_parts.py`,
  `summarize_heldout.py` (reads the held-out report shape, joins on id and
  operator, block join of 7.10), `compare_runs.py`, `write_run_manifest.py`,
  `make_tables.py`, `post_check.sh`, `assemble.sh`, `siteflags/` and
  `jobcap/` (Go, standard library, own `go.mod`), `drivers/`. The capped
  runner's header still describes jobcap version 1; from 06:32:35 UTC the
  `jobcap.exe` it calls was version 2 (`raw/logs/manual_interventions.txt`).

Total wall time: 05:02:54-07:19:49 UTC (2 h 17 min), of which the tool runs
took 7,452 s (2 h 4 min) including 1,153 s of superseded runs. Not a
performance result: the machine was shared and fully loaded.
