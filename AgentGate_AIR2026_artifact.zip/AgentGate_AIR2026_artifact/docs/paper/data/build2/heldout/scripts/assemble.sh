#!/usr/bin/env bash
# Copies this experiment's small raw data into the repository folder (OUT), with
# paths, the machine name and the user name replaced (sanitize.py; it needs
# SANITIZE_USER and SANITIZE_HOST in the environment), and runs the summary.
# Needs E (scratch folder) and OUT (this folder).
: "${E:?}" "${OUT:?}" "${SANITIZE_USER:?}" "${SANITIZE_HOST:?}"
set -e
S="$(dirname "$0")/sanitize.py"
mkdir -p "$OUT/raw/reports" "$OUT/raw/lists" "$OUT/raw/logs" "$OUT/raw/coverage"
for f in "$E"/mut/*.json; do python "$S" "$f" "$OUT/raw/reports/$(basename "$f")"; done
for f in "$E"/lists/*; do python "$S" "$f" "$OUT/raw/lists/$(basename "$f")"; done
for f in "$E"/logs/*.log "$E"/logs/*.txt; do python "$S" "$f" "$OUT/raw/logs/$(basename "$f")"; done
for f in "$E"/logs/cpu_*.csv; do python "$S" "$f" "$OUT/raw/logs/$(basename "$f")"; done
for f in "$E"/raw/*; do python "$S" "$f" "$OUT/raw/$(basename "$f")"; done
for f in "$E"/cov/*.txt; do python "$S" "$f" "$OUT/raw/coverage/$(basename "$f")"; done
( cd "$E/cov" && tar --force-local --owner=0 --group=0 -czf "$OUT/raw/coverage/cover_profiles.tar.gz" *.out )
python "$(dirname "$0")/summarize_heldout.py" "$E" "$OUT" > "$OUT/raw/summarize_output.txt"
