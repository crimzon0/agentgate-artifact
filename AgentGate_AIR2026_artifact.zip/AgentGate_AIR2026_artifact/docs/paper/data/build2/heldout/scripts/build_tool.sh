#!/usr/bin/env bash
# Builds the mutation tool from the frozen copy ($E/src, commit 86643d7) with a
# fresh GOCACHE, as ../robustness/scripts/build_tools.sh does, and records its
# SHA-256. The frozen build-2 binaries contain no test build and no mutation
# tool, so the tool is built here (never the six frozen binaries).
# Needs REPO and E.
source "$(dirname "$0")/env.sh"
rm -rf "$E/gocache"; mkdir -p "$E/bin"
cd "$E/src" || exit 1
"$GO" version
"$GO" build -o "$E/bin/refusalmutation.exe" ./internal/auditverify/tools/refusalmutation/ && echo "built refusalmutation.exe"
( cd "$E/bin" && sha256sum -b *.exe )
sha256sum -b "$E/src/internal/auditverify/tools/refusalmutation/main.go" | sed "s#$E/##"
