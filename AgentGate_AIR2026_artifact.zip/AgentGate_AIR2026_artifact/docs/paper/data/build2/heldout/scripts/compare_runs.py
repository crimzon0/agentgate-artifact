"""Two comparisons that are not part of any score.

usage: python compare_runs.py EXPDIR REPO OUTDIR

1. validation_comparison.json: the six tool-validation mutants of
   HELDOUT_OPERATORS.md section 6 (committed reports
   internal/auditverify/tools/refusalmutation/results/heldout_validation_<op>.json,
   full suite on f01d1c9) against the same sites in this campaign: variant 1
   (build 2, full suite; matched on file, function, label and source text, since
   lines moved) and variant 3 (f01d1c9, without the four post-hoc tests).
2. memory_incident.json: the first, memory-disturbed run of the boundary
   operator on variant 1 (heldout_boundary_v1_full.run1_memory_incident.json)
   against the rerun (heldout_boundary_v1_full.json), mutant by mutant."""
import json, os, sys

EXP, REPO, OUT = sys.argv[1:4]
key = lambda m: (m["file"], m.get("func", ""), m["call"], m.get("class", ""), m["original"])
rows = []
for op in ["append", "boundary", "equality"]:
    val = json.load(open(os.path.join(REPO, "internal/auditverify/tools/refusalmutation/results", f"heldout_validation_{op}.json"), encoding="utf-8"))
    runs = {}
    for variant in ["v1_full", "v3_f01d1c9"]:
        p = os.path.join(EXP, "mut", f"heldout_{op}_{variant}.json")
        if os.path.exists(p):
            runs[variant] = {}
            for m in json.load(open(p, encoding="utf-8"))["mutants"]:
                runs[variant].setdefault(key(m), []).append(m)
    for m in val["mutants"]:
        row = {"operator": op, "validation_site": f'{m["file"]}:{m["line"]}:{m["column"]}', "func": m.get("func", ""),
               "original": m["original"], "validation_result": m["result"], "validation_first_failure": m.get("detail", "")}
        for variant, by in runs.items():
            hits = by.get(key(m), [])
            # two sites can share a key (same label and text in one function): take the one in the same column order
            same = [h for h in hits if h["column"] == m["column"]] or hits
            h = same[0] if same else None
            row[variant] = {"id": h["id"], "result": h["result"], "first_failure": h.get("detail", "")} if h else None
        rows.append(row)
json.dump(rows, open(os.path.join(OUT, "validation_comparison.json"), "w"), indent=2)
for r in rows:
    print(r["operator"], r["validation_site"], r["validation_result"], {k: (v["id"], v["result"]) for k, v in r.items() if k in ("v1_full", "v3_f01d1c9") and v})

a = os.path.join(EXP, "mut", "heldout_boundary_v1_full.run1_memory_incident.json")
b = os.path.join(EXP, "mut", "heldout_boundary_v1_full.json")
if os.path.exists(a) and os.path.exists(b):
    A = {m["id"]: m for m in json.load(open(a, encoding="utf-8"))["mutants"]}
    B = {m["id"]: m for m in json.load(open(b, encoding="utf-8"))["mutants"]}
    diff = [{"id": i, "run1": A[i]["result"], "run1_detail": A[i].get("detail", "")[:300], "rerun": B[i]["result"],
             "rerun_detail": B[i].get("detail", "")[:300]} for i in A if A[i]["result"] != B[i]["result"]]
    res = {"sites": len(A), "same_result": len(A) - len(diff), "different": diff,
           "run1_totals": {k: sum(1 for m in A.values() if m["result"] == k) for k in ["killed", "survived", "build_error", "timeout"]},
           "rerun_totals": {k: sum(1 for m in B.values() if m["result"] == k) for k in ["killed", "survived", "build_error", "timeout"]},
           "memory_hog": [{"id": i, "run1": A[i]["result"], "run1_seconds": A[i]["seconds"], "run1_detail": A[i].get("detail", "")[:200],
                           "rerun": B[i]["result"], "rerun_seconds": B[i]["seconds"], "rerun_detail": B[i].get("detail", "")[:200]}
                          for i in A if "VirtualAlloc" in A[i].get("detail", "") or "VirtualAlloc" in B[i].get("detail", "")]}
    json.dump(res, open(os.path.join(OUT, "memory_incident.json"), "w"), indent=2)
    print("memory incident:", res["same_result"], "of", res["sites"], "same;", res["run1_totals"], "->", res["rerun_totals"])
    for d in diff:
        print("  ", d["id"], d["run1"], "->", d["rerun"])

# 3. build1_vs_build2.json: variant 3 (f01d1c9 = build 1's verifier source and tests, without the
#    four post-hoc tests) against variant 2 (build 2, without the same four tests), site by site,
#    matched on file, function, label, class and source text. A site whose result differs is listed
#    with the first failing test in the run that killed it.
names = {}
tl = os.path.join(OUT, "test_names.json")
if os.path.exists(tl):
    names = set(json.load(open(tl))["absent_from_f01d1c9_verifier_tests"])
out = {}
for op in ["append", "boundary", "equality"]:
    p3 = os.path.join(EXP, "mut", f"heldout_{op}_v3_f01d1c9.json")
    p2 = os.path.join(EXP, "mut", f"heldout_{op}_v2_without_posthoc4.json")
    if not (os.path.exists(p3) and os.path.exists(p2)):
        continue
    A = json.load(open(p3, encoding="utf-8"))["mutants"]
    B = json.load(open(p2, encoding="utf-8"))["mutants"]
    by = {}
    for m in B:
        by.setdefault(key(m), []).append(m)
    used = set()
    changed, same = [], 0
    for m in A:
        cands = [x for x in by.get(key(m), []) if x["id"] not in used]
        if not cands:
            changed.append({"f01d1c9": m["id"], "build2": None, "f01d1c9_result": m["result"], "build2_result": "site removed"})
            continue
        x = cands[0]
        used.add(x["id"])
        if x["result"] == m["result"]:
            same += 1
            continue
        killer = (x if x["result"] == "killed" else m).get("detail", "")
        test = killer.split("--- FAIL: ")[-1].split(" ")[0].split("/")[0] if "--- FAIL" in killer else ""
        changed.append({"f01d1c9": m["id"], "build2": x["id"], "func": m.get("func", ""), "original": m["original"],
                        "f01d1c9_result": m["result"], "build2_result": x["result"], "first_failing_test": killer,
                        "test_absent_from_f01d1c9": test in names if test else None})
    new = [{"build2": x["id"], "func": x.get("func", ""), "original": x["original"], "result": x["result"]} for x in B if x["id"] not in used]
    out[op] = {"matched": same + sum(1 for c in changed if c["build2"]), "same_result": same, "different_result": changed,
               "build2_only_sites": new,
               "build2_only_killed": sum(1 for n in new if n["result"] == "killed"),
               "build2_only_survived": sum(1 for n in new if n["result"] == "survived")}
json.dump(out, open(os.path.join(OUT, "build1_vs_build2.json"), "w"), indent=2)
for op, r in out.items():
    print(op, "matched", r["matched"], "same", r["same_result"], "different", len(r["different_result"]),
          "build2-only sites", len(r["build2_only_sites"]), "(killed", r["build2_only_killed"], ")")
    for c in r["different_result"]:
        print("   ", c["f01d1c9"], "->", c["build2"], c["f01d1c9_result"], "->", c["build2_result"], c.get("first_failing_test", "")[:80], c.get("test_absent_from_f01d1c9"))
