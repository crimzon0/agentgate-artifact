"""Variant 3 gate (HELDOUT_OPERATORS.md 7.2): the final build's tool, run with -list
in the f01d1c9 export root, must reproduce the committed site list
internal/auditverify/tools/refusalmutation/results/heldout_sites_<op>.json on file,
line, column, function, label, class, original and replacement, in order. Those
files predate c33b297 (no id or flags), so they are compared on content.

usage: python compare_sites.py COMMITTED.json LISTED.json  -> prints the result, exit 1 on any difference"""
import json, sys

FIELDS = ["file", "line", "column", "func", "call", "class", "original", "mutation"]
a = json.load(open(sys.argv[1], encoding="utf-8"))["mutants"]
b = json.load(open(sys.argv[2], encoding="utf-8"))["mutants"]
bad = []
if len(a) != len(b):
    bad.append(f"count differs: committed {len(a)}, listed {len(b)}")
for i, (x, y) in enumerate(zip(a, b)):
    for f in FIELDS:
        if x.get(f) != y.get(f):
            bad.append(f"#{i} {f}: committed {x.get(f)!r} listed {y.get(f)!r}")
print(f"{sys.argv[2].rsplit('/', 1)[-1]}: committed {len(a)} sites, listed {len(b)}; "
      f"{'IDENTICAL on ' + ','.join(FIELDS) + ' in order' if not bad else str(len(bad)) + ' differences'}")
for line in bad[:20]:
    print("  ", line)
sys.exit(1 if bad else 0)
