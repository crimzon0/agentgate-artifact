# Lists other AgentGate experiment processes (name + arguments without paths).
Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'agentgate|refusal|\.test\.exe' } | ForEach-Object {
  $_.Name + ' ' + ((($_.CommandLine -split ' ') | Select-Object -Skip 1 | Where-Object { $_ -notmatch '[\/:]' }) -join ' ')
} | Group-Object | ForEach-Object { "$($_.Count) x $($_.Name)" }
