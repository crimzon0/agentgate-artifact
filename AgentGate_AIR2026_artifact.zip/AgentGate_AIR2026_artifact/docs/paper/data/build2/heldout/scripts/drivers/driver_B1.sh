# scratch driver (the commands it runs are scripts/run_heldout_split.sh)
E=$1; REPO=$2
until [ -f $E/mut/heldout_equality_v1_full.json ]; do sleep 5; done
echo "== v1_full equality report written; end (driver B1 saw it) $(date -u +%FT%TZ)" | tee -a $E/logs/heldout_equality_v1_full.log
kill 112160 2>/dev/null
export REPO E
bash "$REPO/docs/paper/data/build2/heldout/scripts/run_heldout_split.sh" 8 append,boundary,equality v2_without_posthoc4
bash "$REPO/docs/paper/data/build2/heldout/scripts/run_heldout_split.sh" 8 boundary v1_full
echo "B1 done $(date -u +%FT%TZ)"
