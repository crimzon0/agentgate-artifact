# scratch driver (the commands it runs are scripts/run_heldout_split_capped.sh)
E=$1; REPO=$2
until [ -f $E/mut/heldout_equality_v2_without_posthoc4.json ]; do sleep 5; done
sleep 3
export REPO E
bash "$REPO/docs/paper/data/build2/heldout/scripts/run_heldout_split_capped.sh" 8 boundary v1_full
bash "$REPO/docs/paper/data/build2/heldout/scripts/run_heldout_split_capped.sh" 8 append,boundary,equality v3_f01d1c9
echo "C done $(date -u +%FT%TZ)"
