# scratch driver
E=$1; REPO=$2
until grep -q "^C done" $E/logs/driver_C.txt; do sleep 5; done
export REPO E
bash "$REPO/docs/paper/data/build2/heldout/scripts/rerun_v1_files_part.sh"
bash "$REPO/docs/paper/data/build2/heldout/scripts/run_heldout_split_capped.sh" 8 append,boundary,equality v2b_without_posthoc7
echo "D done $(date -u +%FT%TZ)"
