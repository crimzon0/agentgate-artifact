#!/usr/bin/env bash
# Suite variant 3 (HELDOUT_OPERATORS.md 7.2): a full export of commit f01d1c9
# (git archive), into $E/f01d1c9. Nothing written for the revision is copied in.
# Records the export's file count and the SHA-256 of its verifier source,
# tests and fixture (internal/auditverify/**, cmd/agentgate-verify/**, go.mod, go.sum).
# Needs REPO and E.
: "${REPO:?}" "${E:?}"
set -e
rm -rf "$E/f01d1c9"; mkdir -p "$E/f01d1c9" "$E/raw"
cd "$REPO"
git rev-parse f01d1c9 > "$E/raw/f01d1c9_commit.txt"
git archive --format=tar f01d1c9 | tar -x -C "$E/f01d1c9"
echo "exported files: $(cd "$E/f01d1c9" && find . -type f | wc -l)"
( cd "$E/f01d1c9" && find internal/auditverify cmd/agentgate-verify go.mod go.sum -type f | LC_ALL=C sort | xargs sha256sum -b ) > "$E/raw/f01d1c9_verifier_manifest.sha256"
echo "verifier files hashed: $(wc -l < "$E/raw/f01d1c9_verifier_manifest.sha256")"
# the export's verifier tree must equal the commit's (git's own view)
git ls-tree -r f01d1c9 -- internal/auditverify cmd/agentgate-verify go.mod go.sum | wc -l | sed 's/^/files in git ls-tree for the same paths: /'
