module jobcap

go 1.26
