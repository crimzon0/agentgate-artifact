// Command jobcap runs a command inside a Windows job object and terminates
// any process of the job whose private committed memory exceeds a threshold,
// so that a runaway process (here: the boundary mutant files.go:237:30, whose
// parse loop never ends) is stopped before it exhausts the machine. It is an
// experiment helper, not part of AgentGate, and uses only the standard
// library.
//
// usage: jobcap -mb N command [args...]
//
// jobcap puts itself into the job before it starts the command, so the
// command and everything it starts (go, compile, link, the test binaries)
// are in the job too. Every 250 ms it lists the job's processes and
// terminates (exit code 3) each one whose private commit is above N MiB,
// with a line on stderr. The job itself sets no memory limit: a first
// version (kept as main_v1_hardcap.go.txt in the scratch folder) capped the
// job's total commit, and the test process whose allocation failed at the
// cap hung in its exit instead of ending. The exit code is the command's.
package main

import (
	"flag"
	"fmt"
	"os"
	"os/exec"
	"syscall"
	"time"
	"unsafe"
)

type memoryCounters struct {
	Cb                         uint32
	PageFaultCount             uint32
	PeakWorkingSetSize         uintptr
	WorkingSetSize             uintptr
	QuotaPeakPagedPoolUsage    uintptr
	QuotaPagedPoolUsage        uintptr
	QuotaPeakNonPagedPoolUsage uintptr
	QuotaNonPagedPoolUsage     uintptr
	PagefileUsage              uintptr
	PeakPagefileUsage          uintptr
	PrivateUsage               uintptr
}

const (
	jobObjectBasicProcessIDList = 3
	processQueryLimited         = 0x1000
	processVMRead               = 0x0010
	processTerminate            = 0x0001
)

func main() {
	mb := flag.Int("mb", 8192, "terminate a process of the job whose private commit exceeds this many MiB")
	flag.Parse()
	if flag.NArg() == 0 {
		fmt.Fprintln(os.Stderr, "usage: jobcap -mb N command [args...]")
		os.Exit(2)
	}
	k := syscall.NewLazyDLL("kernel32.dll")
	create, assign, query := k.NewProc("CreateJobObjectW"), k.NewProc("AssignProcessToJobObject"), k.NewProc("QueryInformationJobObject")
	open, memInfo, terminate := k.NewProc("OpenProcess"), k.NewProc("K32GetProcessMemoryInfo"), k.NewProc("TerminateProcess")
	job, _, err := create.Call(0, 0)
	if job == 0 {
		fmt.Fprintln(os.Stderr, "jobcap: CreateJobObject:", err)
		os.Exit(2)
	}
	self, _ := syscall.GetCurrentProcess()
	if r, _, err := assign.Call(job, uintptr(self)); r == 0 {
		fmt.Fprintln(os.Stderr, "jobcap: AssignProcessToJobObject:", err)
		os.Exit(2)
	}
	limit := uintptr(*mb) << 20
	me := uint32(os.Getpid())
	go func() {
		buf := make([]uintptr, 1+1024) // two DWORD counts (one uintptr on amd64), then the IDs
		for range time.Tick(250 * time.Millisecond) {
			if r, _, _ := query.Call(job, jobObjectBasicProcessIDList, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf))*unsafe.Sizeof(buf[0]), 0); r == 0 {
				continue
			}
			n := int(uint32(buf[0] >> 32))
			for _, pid := range buf[1 : 1+min(n, len(buf)-1)] {
				if uint32(pid) == me {
					continue
				}
				h, _, _ := open.Call(processQueryLimited|processVMRead|processTerminate, 0, pid)
				if h == 0 {
					continue
				}
				var c memoryCounters
				c.Cb = uint32(unsafe.Sizeof(c))
				if r, _, _ := memInfo.Call(h, uintptr(unsafe.Pointer(&c)), uintptr(c.Cb)); r != 0 && c.PrivateUsage > limit {
					terminate.Call(h, 3)
					fmt.Fprintf(os.Stderr, "jobcap: %s terminated process %d: private commit %d MiB is above %d MiB\n",
						time.Now().UTC().Format(time.RFC3339), pid, c.PrivateUsage>>20, *mb)
				}
				syscall.CloseHandle(syscall.Handle(h))
			}
		}
	}()
	cmd := exec.Command(flag.Arg(0), flag.Args()[1:]...)
	cmd.Stdin, cmd.Stdout, cmd.Stderr = os.Stdin, os.Stdout, os.Stderr
	if err := cmd.Run(); err != nil {
		if exit, ok := err.(*exec.ExitError); ok {
			os.Exit(exit.ExitCode())
		}
		fmt.Fprintln(os.Stderr, "jobcap:", err)
		os.Exit(2)
	}
}
