"""Prints the Markdown tables of RESULTS.md from heldout_summary.json.

usage: python make_tables.py OUTDIR > tables.md"""
import json, os, sys

OUT = sys.argv[1]
S = json.load(open(os.path.join(OUT, "heldout_summary.json")))
V = [("v1_full", "1: build 2, full suite"), ("v2_without_posthoc4", "2: build 2, without the 4 post-hoc tests"),
     ("v3_f01d1c9", "3: f01d1c9 (build 1 verifier and tests), without the 4"),
     ("v2b_without_posthoc7", "2b (suppl.): build 2, without the 7 post-hoc tests")]
OPS = ["append", "boundary", "equality"]


def sc(c):
    k, s = c["killed"], c["survived"]
    return f"{k}/{k + s} = {k / (k + s):.3f}" if k + s else "-"


print("### Headline: every site, per operator and variant\n")
print("| variant | operator | sites | killed | survived | build errors | timeouts | kill score | survivors: not executed / evaluation not shown / equivalent / executed but undetected | ceiling (sites whose block ran) |")
print("|---|---|---|---|---|---|---|---|---|---|")
for v, name in V:
    for op in OPS:
        s = S.get(f"{v}/{op}")
        if not s:
            continue
        g = s["survivors_by_group"]
        c = s["ceiling"]
        print(f"| {name} | {op} | {s['sites']} | {s['killed']} | {s['survived']} | {s['build_errors']} | {s['timeouts']} | {sc(s)} | "
              f"{g['not_executed']} / {g['eval_not_shown']} / {g['equivalent']} / {g['executed_undetected']} | {c['executed']}/{c['sites']} = {c['ceiling_executed_only']:.3f} |")
    t = [S.get(f"{v}/{op}") for op in OPS]
    if all(t):
        k = sum(x["killed"] for x in t); s_ = sum(x["survived"] for x in t)
        print(f"| {name} | **all three** | {sum(x['sites'] for x in t)} | {k} | {s_} | {sum(x['build_errors'] for x in t)} | {sum(x['timeouts'] for x in t)} | **{k}/{k + s_} = {k / (k + s_):.3f}** | "
              f"{sum(x['survivors_by_group']['not_executed'] for x in t)} / {sum(x['survivors_by_group']['eval_not_shown'] for x in t)} / {sum(x['survivors_by_group']['equivalent'] for x in t)} / {sum(x['survivors_by_group']['executed_undetected'] for x in t)} | |")
print()
print("### Declared splits (addendum 7.1, 7.5, 7.6) and the score without equivalent mutants\n")
print("| variant | operator | split | sites | killed / (killed + survived) | survivors: not executed / evaluation not shown / equivalent (of which text only) / executed but undetected | without equivalent | without equivalent, text-only kept |")
print("|---|---|---|---|---|---|---|---|")
names = {"all": "all sites", "single_deletions": "the 141+ single deletions", "group_deletions": "the 12 group deletions",
         "without_emptiness": "without emptiness", "without_literal_0": "without comparisons with literal 0",
         "literal_0_only": "comparisons with literal 0 only", "verifier_only": "verifier only (no tamper.go, parallel.go)"}
for v, name in V:
    for op in OPS:
        s = S.get(f"{v}/{op}")
        if not s:
            continue
        for key in ["all", "single_deletions", "group_deletions", "without_emptiness", "without_literal_0", "literal_0_only", "verifier_only"]:
            c = s["splits"].get(key)
            if not c:
                continue
            g = c["survivors_by_group"]
            label = names[key].replace("141+", str(c["sites"])) if key == "single_deletions" else names[key]
            we = c["kill_score_without_equivalent"]
            k2 = c["killed"]; s2 = c["survived"] - g["equivalent"]
            t = c["equivalent_text_only"]; s3 = s2 + t
            print(f"| {v.split('_')[0]} | {op} | {label} | {c['sites']} | {sc(c)} | {g['not_executed']} / {g['eval_not_shown']} / {g['equivalent']} ({t}) / {g['executed_undetected']} | {k2}/{k2 + s2} = {we:.3f} | {k2}/{k2 + s3} = {k2 / (k2 + s3):.3f} |")
print()
print("### Survivor labels (7.4)\n")
print("| variant | operator | not executed | line executed, evaluation not shown | evaluation not shown (switch case, unmapped) | equivalent | executed but undetected |")
print("|---|---|---|---|---|---|---|")
for v, name in V:
    for op in OPS:
        s = S.get(f"{v}/{op}")
        if not s:
            continue
        l = s["survivors_by_label"]
        print(f"| {v.split('_')[0]} | {op} | {l.get('not executed', 0)} | {l.get('line executed, evaluation not shown', 0)} | {l.get('evaluation not shown', 0)} | {l.get('equivalent', 0)} | {l.get('executed but undetected', 0)} |")
