"""Merges the two parts of a split held-out run into one report of the tool's
shape (agentgate-refusal-mutation/v1), in the order of the operator's -list.

usage: python merge_parts.py LIST.json PART1.json PART2.json OUT.json

Why split: the boundary mutant files.go:237:30 (parseLog, "len(rest) > 0" ->
">= 0") never ends its loop and grows its heap until the allocation fails
(about 20 GB). Run next to seven other mutants it exhausted the machine's
commit limit, and three concurrent mutants then failed to build or run
("paging file is too small", "cannot allocate memory"). From then on the
boundary operator runs in two invocations: every site outside files.go with
-parallel N, and the three files.go sites with -parallel 1. The per-mutant
protocol (overlay, test packages, -skip, limits) is unchanged."""
import json, sys

lst, p1, p2, out = sys.argv[1:5]
L = json.load(open(lst, encoding="utf-8"))
parts = [json.load(open(p, encoding="utf-8")) for p in (p1, p2)]
by_id = {}
for p in parts:
    for m in p["mutants"]:
        assert m["id"] not in by_id, m["id"]
        by_id[m["id"]] = m
ids = [m["id"] for m in L["mutants"]]
assert sorted(ids) == sorted(by_id), "parts do not cover the -list sites exactly"
mutants = [by_id[i] for i in ids]
for a, b in zip(L["mutants"], mutants):
    for f in ("file", "line", "column", "func", "call", "class", "original", "mutation"):
        assert a.get(f) == b.get(f), (a["id"], f)
rep = dict(parts[0])
rep["mutants"] = mutants
rep["sites"] = len(mutants)
rep["selection"] = ""
rep["merged_from"] = [{"selection": p.get("selection", ""), "generated_at": p["generated_at"],
                       "baseline_seconds": p.get("baseline_seconds", {}), "sites": p["sites"]} for p in parts]
rep["generated_at"] = max(p["generated_at"] for p in parts)
for k in ("killed", "survived", "build_errors", "timeouts"):
    rep[k] = 0
key = {"killed": "killed", "survived": "survived", "build_error": "build_errors", "timeout": "timeouts"}
for m in mutants:
    rep[key[m["result"]]] += 1
rep["kill_score"] = rep["killed"] / (rep["killed"] + rep["survived"]) if rep["killed"] + rep["survived"] else 0
for field, fn in (("by_file", lambda m: m["file"]), ("by_func", lambda m: m.get("func", "")),
                  ("by_class", lambda m: m.get("class", "").split(":")[0])):
    t = {}
    for m in mutants:
        e = t.setdefault(fn(m), {"sites": 0, "killed": 0})
        e["sites"] += 1
        e["killed"] += m["result"] == "killed"
    rep[field] = dict(sorted(t.items()))
rep["survivors"] = [f'{m["file"]}:{m["line"]}:{m["column"]} {m["call"]}: {m["original"]} ({m.get("func", "")})'
                    for m in mutants if m["result"] == "survived"]
rep["baseline_seconds"] = {"suite_part1": parts[0].get("baseline_seconds", {}).get("suite"),
                           "suite_part2": parts[1].get("baseline_seconds", {}).get("suite")}
json.dump(rep, open(out, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
print(f"{out}: {rep['sites']} sites, killed {rep['killed']}, survived {rep['survived']}, build errors {rep['build_errors']}, timeouts {rep['timeouts']}, score {rep['kill_score']:.3f}")
