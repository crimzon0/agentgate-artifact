#!/usr/bin/env bash
# After the runs: the frozen copy ($E/src) still matches its manifest, the live
# repository's copied paths are still identical to it and clean in git, and the
# f01d1c9 export's verifier tree still matches its manifest. Needs REPO and E.
: "${REPO:?}" "${E:?}"
echo "post-check $(date -u +%FT%TZ)"
( cd "$E/src" && sha256sum -c --quiet "$E/raw/snapshot_manifest.sha256" ) && echo "frozen copy: all $(wc -l < "$E/raw/snapshot_manifest.sha256") files match the snapshot manifest"
( cd "$REPO" && sed 's# \*\./# *#' "$E/raw/snapshot_manifest.sha256" | sha256sum -c --quiet - ) && echo "live repository: the same $(wc -l < "$E/raw/snapshot_manifest.sha256") paths are identical to the snapshot"
( cd "$REPO" && git status --porcelain -- go.mod go.sum internal/auditverify cmd/agentgate-verify internal/audit internal/canon internal/evalattack docs/demo | wc -l | sed 's/^/git status lines for the copied paths: /' )
( cd "$REPO" && git rev-parse HEAD | sed 's/^/HEAD: /' )
( cd "$E/f01d1c9" && sha256sum -c --quiet "$E/raw/f01d1c9_verifier_manifest.sha256" ) && echo "f01d1c9 export: all $(wc -l < "$E/raw/f01d1c9_verifier_manifest.sha256") verifier files match its manifest"
