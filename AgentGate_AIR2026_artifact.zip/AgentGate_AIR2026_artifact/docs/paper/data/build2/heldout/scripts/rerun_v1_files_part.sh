#!/usr/bin/env bash
# Repeats the files.go part (part2) of the boundary operator on variant 1 under the
# watchdog version of jobcap. The first part2 ran under the first jobcap version
# (a hard job memory limit), and the runaway mutant files.go:237:30 then hung in
# its exit and was classed timeout by the tool's backstop. The earlier part2 and
# its merged report are kept with the suffix .hardcap. Needs REPO and E.
source "$(dirname "$0")/env.sh"
cd "$E/mut" || exit 1
mv heldout_boundary_v1_full.part2.json heldout_boundary_v1_full.part2.hardcap.json
mv heldout_boundary_v1_full.json heldout_boundary_v1_full.hardcap.json
mv "$E/logs/heldout_boundary_v1_full.part2.log" "$E/logs/heldout_boundary_v1_full.part2.hardcap.log"
L="$E/logs/heldout_boundary_v1_full.part2.log"
echo "== v1_full boundary.part2 start $(date -u +%FT%TZ) parallel=1 file=[files.go] cap=[$E/bin/jobcap.exe -mb 8192 (watchdog)] skip=[]" | tee "$L"
S=$(date +%s)
( cd "$E/src" && "$E/bin/jobcap.exe" -mb 8192 "$E/bin/refusalmutation.exe" -go "$GO" -operator boundary -parallel 1 -file files.go -skip "" -out "$E/mut/heldout_boundary_v1_full.part2.json" ) >> "$L" 2>&1
echo "== v1_full boundary.part2 exit=$? wall_seconds=$(( $(date +%s)-S )) end $(date -u +%FT%TZ)" | tee -a "$L"
python "$(dirname "$0")/merge_parts.py" "$E/lists/b2_boundary.json" "$E/mut/heldout_boundary_v1_full.part1.json" "$E/mut/heldout_boundary_v1_full.part2.json" "$E/mut/heldout_boundary_v1_full.json" | tee -a "$L"
