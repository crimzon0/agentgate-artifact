#!/usr/bin/env bash
# Coverage profiles for the held-out coverage join (HELDOUT_OPERATORS.md 7.10):
# statement coverage (set mode) of internal/auditverify by the mutation runs'
# test packages (./internal/auditverify/... and ./cmd/agentgate-verify/), the
# same command as ../robustness/scripts/run_cover.sh, one profile per suite
# variant:
#   b2_full           build 2 frozen copy, full suite                       (variant 1)
#   b2_without_posthoc4  build 2, -skip the four post-hoc tests              (variant 2, as frozen)
#   b2_without_posthoc7  build 2, -skip the seven post-hoc tests             (variant 2b, supplementary)
#   v3_without_posthoc4  f01d1c9 export, -skip the four post-hoc tests       (variant 3)
#   v3_full           f01d1c9 export, full suite (reference only: section 4's 93/153)
# Also lists the top-level test names of both trees (go test -list) for the run manifest.
source "$(dirname "$0")/env.sh"
source "$(dirname "$0")/skip_patterns.sh"
mkdir -p "$E/cov"
cover() { # $1 label, $2 tree, $3 skip pattern or empty
  echo "$1 start $(date -u +%FT%TZ)"
  ( cd "$2" && if [ -n "$3" ]; then
      "$GO" test -count=1 -skip="$3" -covermode=set -coverpkg=agentgate/internal/auditverify -coverprofile="$E/cov/$1.out" ./internal/auditverify/... ./cmd/agentgate-verify/ > "$E/cov/$1.txt" 2>&1
    else
      "$GO" test -count=1 -covermode=set -coverpkg=agentgate/internal/auditverify -coverprofile="$E/cov/$1.out" ./internal/auditverify/... ./cmd/agentgate-verify/ > "$E/cov/$1.txt" 2>&1
    fi )
  echo "$1 exit=$? end $(date -u +%FT%TZ)"
}
cover b2_full "$E/src" ""
cover b2_without_posthoc4 "$E/src" "$POSTHOC4"
cover b2_without_posthoc7 "$E/src" "$POSTHOC7"
cover v3_without_posthoc4 "$E/f01d1c9" "$POSTHOC4"
cover v3_full "$E/f01d1c9" ""
for T in src f01d1c9; do
  ( cd "$E/$T" && "$GO" test -list '.*' ./internal/auditverify/... ./cmd/agentgate-verify/ ) > "$E/cov/testlist_$T.txt" 2>&1
  echo "testlist_$T exit=$?"
done
