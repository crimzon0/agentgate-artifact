#!/usr/bin/env bash
# Held-out mutation campaign (HELDOUT_OPERATORS.md sections 1 and 7) on build 2.
# usage: run_heldout.sh PARALLEL VARIANT... ; each VARIANT runs the three operators
# (append, boundary, equality) in that order:
#   v1_full            frozen copy of 86643d7 ($E/src), full suite                       (variant 1)
#   v2_without_posthoc4  $E/src, -skip the four post-hoc tests (section 1, as frozen)     (variant 2)
#   v3_f01d1c9         full export of f01d1c9 ($E/f01d1c9), its own tests, -skip the four (variant 3, 7.2)
#   v2b_without_posthoc7 $E/src, -skip the seven post-hoc tests of VERIFIER_CHECKS.md 6   (supplementary)
# Every run: the tool built from the frozen copy ($E/bin/refusalmutation.exe), the
# tool's default test packages (./internal/auditverify/...,./cmd/agentgate-verify/)
# and 5-minute limit, -parallel PARALLEL (the only setting that differs from the
# tool's default; it changes no result). The working directory is the tree's root.
source "$(dirname "$0")/env.sh"
source "$(dirname "$0")/skip_patterns.sh"
PAR="$1"; shift
mkdir -p "$E/mut" "$E/logs"
for V in "$@"; do
  case "$V" in
    v1_full) TREE="$E/src"; SKIP="";;
    v2_without_posthoc4) TREE="$E/src"; SKIP="$POSTHOC4";;
    v3_f01d1c9) TREE="$E/f01d1c9"; SKIP="$POSTHOC4";;
    v2b_without_posthoc7) TREE="$E/src"; SKIP="$POSTHOC7";;
    *) echo "unknown variant $V"; exit 2;;
  esac
  for OP in append boundary equality; do
    L="$E/logs/heldout_${OP}_$V.log"
    typeperf.exe "\Processor(_Total)\% Processor Time" -si 10 -sc 720 -y -f CSV -o "$E/logs/cpu_${OP}_$V.csv" >/dev/null 2>&1 &
    TP=$!
    powershell -NoProfile -ExecutionPolicy Bypass -File "$(cygpath -w "$(dirname "$0")/concurrent.ps1")" > "$E/logs/concurrent_${OP}_$V.txt" 2>&1
    S=$(date +%s)
    echo "== $V $OP start $(date -u +%FT%TZ) parallel=$PAR skip=[$SKIP]" | tee "$L"
    ( cd "$TREE" && "$E/bin/refusalmutation.exe" -go "$GO" -operator "$OP" -parallel "$PAR" -skip "$SKIP" -out "$E/mut/heldout_${OP}_$V.json" ) >> "$L" 2>&1
    echo "== $V $OP exit=$? wall_seconds=$(( $(date +%s)-S )) end $(date -u +%FT%TZ)" | tee -a "$L"
    kill $TP 2>/dev/null
  done
done
