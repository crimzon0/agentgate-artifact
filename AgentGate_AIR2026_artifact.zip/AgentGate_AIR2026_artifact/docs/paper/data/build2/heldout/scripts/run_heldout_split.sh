#!/usr/bin/env bash
# Held-out campaign, continued after the memory incident (merge_parts.py says why).
# Same as run_heldout.sh, except that the boundary operator runs as two
# invocations: every site outside files.go with -parallel PARALLEL, and the
# three files.go sites with -parallel 1; merge_parts.py joins them into
# heldout_boundary_<variant>.json. append and equality run as before.
# usage: run_heldout_split.sh PARALLEL OPS VARIANT...   (OPS: comma list, e.g. append,boundary,equality)
source "$(dirname "$0")/env.sh"
source "$(dirname "$0")/skip_patterns.sh"
PAR="$1"; OPS="$2"; shift 2
mkdir -p "$E/mut" "$E/logs"
one() { # $1 variant $2 op $3 tree $4 skip $5 tag $6 parallel $7 file selection or empty
  local L="$E/logs/heldout_$2_$1$5.log"
  typeperf.exe "\Processor(_Total)\% Processor Time" -si 10 -sc 720 -y -f CSV -o "$E/logs/cpu_$2_$1$5.csv" >/dev/null 2>&1 &
  local TP=$!
  powershell -NoProfile -ExecutionPolicy Bypass -File "$(cygpath -w "$(dirname "$0")/concurrent.ps1")" > "$E/logs/concurrent_$2_$1$5.txt" 2>&1
  local S=$(date +%s)
  echo "== $1 $2$5 start $(date -u +%FT%TZ) parallel=$6 file=[$7] skip=[$4]" | tee "$L"
  if [ -n "$7" ]; then
    ( cd "$3" && "$E/bin/refusalmutation.exe" -go "$GO" -operator "$2" -parallel "$6" -file "$7" -skip "$4" -out "$E/mut/heldout_$2_$1$5.json" ) >> "$L" 2>&1
  else
    ( cd "$3" && "$E/bin/refusalmutation.exe" -go "$GO" -operator "$2" -parallel "$6" -skip "$4" -out "$E/mut/heldout_$2_$1$5.json" ) >> "$L" 2>&1
  fi
  echo "== $1 $2$5 exit=$? wall_seconds=$(( $(date +%s)-S )) end $(date -u +%FT%TZ)" | tee -a "$L"
  kill $TP 2>/dev/null
}
for V in "$@"; do
  case "$V" in
    v1_full) TREE="$E/src"; SKIP=""; T=b2;;
    v2_without_posthoc4) TREE="$E/src"; SKIP="$POSTHOC4"; T=b2;;
    v3_f01d1c9) TREE="$E/f01d1c9"; SKIP="$POSTHOC4"; T=v3;;
    v2b_without_posthoc7) TREE="$E/src"; SKIP="$POSTHOC7"; T=b2;;
    *) echo "unknown variant $V"; exit 2;;
  esac
  for OP in ${OPS//,/ }; do
    if [ "$OP" = boundary ]; then
      OTHERS=$(python -c "import json,sys; print(','.join(sorted({m['file'] for m in json.load(open(sys.argv[1]))['mutants']} - {'files.go'})))" "$E/lists/${T}_boundary.json")
      one "$V" boundary "$TREE" "$SKIP" .part1 "$PAR" "$OTHERS"
      one "$V" boundary "$TREE" "$SKIP" .part2 1 files.go
      python "$(dirname "$0")/merge_parts.py" "$E/lists/${T}_boundary.json" "$E/mut/heldout_boundary_$V.part1.json" "$E/mut/heldout_boundary_$V.part2.json" "$E/mut/heldout_boundary_$V.json" | tee -a "$E/logs/heldout_boundary_$V.part2.log"
    else
      one "$V" "$OP" "$TREE" "$SKIP" "" "$PAR" ""
    fi
  done
done
