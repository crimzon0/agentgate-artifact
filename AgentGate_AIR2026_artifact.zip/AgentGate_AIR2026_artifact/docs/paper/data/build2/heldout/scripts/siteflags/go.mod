module siteflags

go 1.26
