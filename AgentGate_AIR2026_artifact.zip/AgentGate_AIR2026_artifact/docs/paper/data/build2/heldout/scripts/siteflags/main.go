// Command siteflags says, for each mutation site, why line coverage may not
// show that it was evaluated (HELDOUT_OPERATORS.md 7.4 and 7.10). It is an
// analysis helper for summarize_heldout.py, not part of AgentGate, and uses
// only the standard library.
//
// usage: siteflags PKGDIR < ids.txt > flags.tsv
//
// Each input line is a site id "file:line:column" (byte column, as in the
// mutation tool's report). Each output line is
//
//	id <TAB> right_operand <TAB> case_expr <TAB> literal_same_line
//
// right_operand: the site lies in the right operand of && or || and not in a
// function literal body nested inside that operand (such a body is a cover
// block of its own); case_expr: it lies in a case expression of a switch
// (likewise not inside a nested literal body); literal_same_line: it lies in
// the body of a function literal that starts on the site's line (the tool's
// third eval_not_shown reason).
package main

import (
	"bufio"
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

type span struct{ start, end, line int }

type fileInfo struct {
	fset            *token.FileSet
	tf              *token.File
	rights, cases   []span
	literals        []span
}

func (s span) has(off int) bool { return s.start <= off && off < s.end }

func main() {
	dir := os.Args[1]
	files := map[string]*fileInfo{}
	load := func(name string) *fileInfo {
		if fi, ok := files[name]; ok {
			return fi
		}
		fset := token.NewFileSet()
		f, err := parser.ParseFile(fset, filepath.Join(dir, name), nil, parser.ParseComments)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		fi := &fileInfo{fset: fset, tf: fset.File(f.Pos())}
		sp := func(n ast.Node) span {
			return span{fset.Position(n.Pos()).Offset, fset.Position(n.End()).Offset, fset.Position(n.Pos()).Line}
		}
		ast.Inspect(f, func(node ast.Node) bool {
			switch n := node.(type) {
			case *ast.BinaryExpr:
				if n.Op == token.LAND || n.Op == token.LOR {
					fi.rights = append(fi.rights, sp(n.Y))
				}
			case *ast.CaseClause:
				for _, e := range n.List {
					fi.cases = append(fi.cases, sp(e))
				}
			case *ast.FuncLit:
				fi.literals = append(fi.literals, sp(n.Body))
			}
			return true
		})
		files[name] = fi
		return fi
	}
	// in reports whether off lies in a region of regs with no literal body
	// that starts inside the region and also contains off.
	in := func(fi *fileInfo, regs []span, off int) bool {
		for _, r := range regs {
			if !r.has(off) {
				continue
			}
			nested := false
			for _, b := range fi.literals {
				if b.has(off) && r.start <= b.start && b.end <= r.end {
					nested = true
				}
			}
			if !nested {
				return true
			}
		}
		return false
	}
	scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
		id := strings.TrimSpace(scanner.Text())
		if id == "" {
			continue
		}
		parts := strings.Split(id, ":")
		line, _ := strconv.Atoi(parts[1])
		col, _ := strconv.Atoi(parts[2])
		fi := load(parts[0])
		off := int(fi.tf.LineStart(line)) - fi.tf.Base() + col - 1
		sameLine := false
		for _, b := range fi.literals {
			if b.has(off) && b.line == line {
				sameLine = true
			}
		}
		fmt.Printf("%s\t%v\t%v\t%v\n", id, in(fi, fi.rights, off), in(fi, fi.cases, off), sameLine)
	}
}
