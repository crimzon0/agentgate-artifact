# The go test -skip patterns of the suite variants (sourced by run_cover.sh and run_mutation.sh).
# POSTHOC7: the honest pattern for a build from 2026-10-10 on (docs/demo/VERIFIER_CHECKS.md section 6):
#   the four tests of build 1 plus the three written together with the 2026-10-10 sites.
POSTHOC7='^(TestRefusalSites|TestDelegationRefusalSites|TestRestartProviderJournalCutBack|TestRestartContinuationRemovedFromRunRecord|TestRecoveryRecordsStateTheBoundFlag|TestReconciledAdapterReceipt|TestReplayedAndConfirmingAnswersStateTheBoundFlag)$'
# POSTHOC4: build 1's pattern (the four tests written after the 2026-10-07 and 2026-10-08 survivors).
POSTHOC4='^(TestRefusalSites|TestDelegationRefusalSites|TestRestartProviderJournalCutBack|TestRestartContinuationRemovedFromRunRecord)$'
# REFUSAL2: only the two tests the earliest version of VERIFIER_CHECKS.md section 6 named (build 1's third variant).
REFUSAL2='TestRefusalSites|TestDelegationRefusalSites'
# RESTART2: only the two restart post-hoc tests (build 1's fourth variant).
RESTART2='^(TestRestartProviderJournalCutBack|TestRestartContinuationRemovedFromRunRecord)$'
# STRICT8: the stricter variant section 6 mentions: POSTHOC7 plus TestLifecycleConflictingHistories
#   (written in the same change as the recovery-record rule; it also kills older sites).
STRICT8='^(TestRefusalSites|TestDelegationRefusalSites|TestRestartProviderJournalCutBack|TestRestartContinuationRemovedFromRunRecord|TestRecoveryRecordsStateTheBoundFlag|TestReconciledAdapterReceipt|TestReplayedAndConfirmingAnswersStateTheBoundFlag|TestLifecycleConflictingHistories)$'
