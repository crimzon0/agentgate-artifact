#!/usr/bin/env bash
# Takes the frozen source copy ($E/src) the test builds compile from, writes its
# SHA-256 list ($E/raw/snapshot_manifest.sha256) and checks every copied file
# that the build-2 MANIFEST.txt also lists (the files compiled into the frozen
# binaries) against it. Build 1 copied go.mod, go.sum, internal/auditverify/**,
# cmd/agentgate-verify/**, docs/demo/VERIFIER_CHECKS.md and
# docs/demo/REVISION_CONTRACT.md. Build 2's verifier tests also import
# internal/evalattack (keysets_extra_test.go, lifecycle_test.go), which pulls in
# internal/audit and internal/canon, so those three folders are copied too.
# Needs REPO, E and SB (the singlebuild2 folder).
: "${REPO:?}" "${E:?}" "${SB:?}"
set -e
rm -rf "$E/src"; mkdir -p "$E/src/docs/demo" "$E/raw"
cd "$REPO"
git rev-parse HEAD > "$E/raw/snapshot_head.txt"
git status --porcelain -- go.mod go.sum internal/auditverify cmd/agentgate-verify internal/audit internal/canon internal/evalattack docs/demo > "$E/raw/snapshot_git_status.txt"
cp go.mod go.sum "$E/src/"
for d in internal/auditverify cmd/agentgate-verify internal/audit internal/canon internal/evalattack; do
  mkdir -p "$E/src/$d"; cp -r "$d/." "$E/src/$d/"
done
cp docs/demo/VERIFIER_CHECKS.md docs/demo/REVISION_CONTRACT.md "$E/src/docs/demo/"
date -u +%FT%TZ > "$E/raw/snapshot_time.txt"
( cd "$E/src" && find . -type f | LC_ALL=C sort | xargs sha256sum -b ) > "$E/raw/snapshot_manifest.sha256"
echo "files copied: $(wc -l < "$E/raw/snapshot_manifest.sha256")"
# compiled files: those of the copy that MANIFEST.txt lists
python - "$E/raw/snapshot_manifest.sha256" "$SB/MANIFEST.txt" <<'EOF' | tee "$E/raw/snapshot_vs_manifest.txt"
import re, sys
snap = {}
for l in open(sys.argv[1]):
    h, p = l.split(" *", 1) if " *" in l else l.split("  ", 1)
    snap[p.strip()[2:]] = h
man = {}
for l in open(sys.argv[2], encoding="utf-8"):
    m = re.match(r"^([0-9a-f]{64}) \*(.+)$", l.strip())
    if m and not m.group(2).startswith(("bin/", "$")):
        man[m.group(2)] = m.group(1)
pref = ("internal/auditverify/", "cmd/agentgate-verify/", "internal/audit/", "internal/canon/", "internal/evalattack/", "go.mod", "go.sum")
inman = {p: h for p, h in man.items() if p.startswith(pref)}
same = sorted(p for p in inman if snap.get(p) == inman[p])
diff = sorted(p for p in inman if p in snap and snap[p] != inman[p])
missing = sorted(p for p in inman if p not in snap)
print(f"MANIFEST.txt lists {len(inman)} files under the copied paths; identical in the copy: {len(same)}; differ: {len(diff)}; absent from the copy: {len(missing)}")
for p in diff + missing:
    print("  ", p)
by = {}
for p in same:
    k = p.rsplit("/", 1)[0] if "/" in p else p
    by[k] = by.get(k, 0) + 1
print("  identical by folder:", by)
print(f"copied files not compiled into any frozen binary (tests, fixture data, tools, docs): {len(snap) - len(same)}")
EOF
