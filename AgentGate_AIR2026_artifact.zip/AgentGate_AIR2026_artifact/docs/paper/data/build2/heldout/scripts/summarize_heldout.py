"""Summarizes the held-out mutation campaign on build 2 (HELDOUT_OPERATORS.md
sections 5 and 7). It reads the held-out report shape (by_file, by_func,
by_class; no by_check), joins results on the mutant id together with the
operator (7.7), and joins coverage by cover-profile block (7.10).

usage: python summarize_heldout.py EXPDIR OUTDIR

EXPDIR (the scratch folder of this experiment) holds:
  mut/heldout_<op>_<variant>.json   the tool reports
  lists/<tree>_<op>.json            the tool's -list output per tree (b2 = 86643d7 copy, v3 = f01d1c9 export)
  lists/<tree>_<op>_flags.tsv       siteflags output (right operand of && or ||, case expression,
                                    body of a one-line function literal) per site
  cov/<profile>.out                 cover profiles (set mode, -coverpkg=agentgate/internal/auditverify)
OUTDIR gets heldout_summary.json, heldout_summary.csv, heldout_mutants.csv,
heldout_survivors.csv, site_diff_f01d1c9_to_build2.json, ceilings.json and
validation_comparison.json. OUTDIR/equivalence.csv (hand classification of
executed survivors: tree, operator, id, verdict, argument) is read when it exists.

Coverage join (7.10): the site's position is its id's line and column; among the
blocks of that file that contain the position, the innermost one (smallest line
span, then smallest column span); executed when any of that block's counts is
above zero. A site in no block is unmapped and labelled "evaluation not shown".

Survivor groups (section 5 and 7.4), in this order:
  not_executed          the site's block did not run in the variant's profile
  eval_not_shown        unmapped (switch case expression; label "evaluation not shown"),
                        or the block ran and the site is in the right operand of && or ||
                        (label "line executed, evaluation not shown")
  equivalent            the block ran and equivalence.csv says equivalent (one-line argument there)
  executed_undetected   the block ran, otherwise
A site in the body of a one-line function literal gets the plain labels: the
literal's body is a block of its own (7.10)."""
import collections, csv, json, os, re, sys

EXP, OUT = sys.argv[1], sys.argv[2]
OPS = ["append", "boundary", "equality"]
# variant -> (tree of its site list, cover profile, description)
VARIANTS = {
    "v1_full": ("b2", "b2_full", "variant 1: build 2 (86643d7), full suite"),
    "v2_without_posthoc4": ("b2", "b2_without_posthoc4", "variant 2: build 2, without the four post-hoc tests (section 1 pattern)"),
    "v3_f01d1c9": ("v3", "v3_without_posthoc4", "variant 3: f01d1c9 export with its own tests, without the four post-hoc tests (7.2)"),
    "v2b_without_posthoc7": ("b2", "b2_without_posthoc7", "supplementary: build 2, without the seven post-hoc tests of VERIFIER_CHECKS.md section 6"),
}
NOT_VERIFIER = {"tamper.go", "parallel.go"}  # 7.6


def load_profile(name):
    blocks = collections.defaultdict(dict)  # file -> {(sl,sc,el,ec): executed}
    for line in open(os.path.join(EXP, "cov", name + ".out")):
        if line.startswith("mode:"):
            continue
        loc, _, cnt = line.rsplit(" ", 2)
        if not loc.startswith("agentgate/internal/auditverify/"):
            continue
        path, rng = loc.rsplit(":", 1)
        rel = path[len("agentgate/internal/auditverify/"):]
        if "/" in rel:  # fixture/, tools/
            continue
        a, b = rng.split(",")
        sl, sc = map(int, a.split("."))
        el, ec = map(int, b.split("."))
        key = (sl, sc, el, ec)
        blocks[rel][key] = blocks[rel].get(key, False) or int(cnt) > 0
    return blocks


def join(blocks, site):
    pos = (site["line"], site["column"])
    cands = [k for k in blocks.get(site["file"], {}) if (k[0], k[1]) <= pos <= (k[2], k[3])]
    if not cands:
        return None, None  # unmapped
    k = min(cands, key=lambda x: (x[2] - x[0], x[3] - x[1]))
    return blocks[site["file"]][k], "%d.%d,%d.%d" % k


def load_flags(tree, op):
    out = {}
    for line in open(os.path.join(EXP, "lists", f"{tree}_{op}_flags.tsv")):
        p = line.rstrip("\n").split("\t")
        out[p[0]] = {"right_operand": p[1] == "true", "case_expr": p[2] == "true", "literal_same_line": p[3] == "true"}
    return out


def group_deletion(m, fl):
    return m["operator"] == "append" and (m["original"].rstrip().endswith("...)") or fl["literal_same_line"])


equiv = {}
eqpath = os.path.join(OUT, "equivalence.csv")
if os.path.exists(eqpath):
    for r in csv.DictReader(open(eqpath, encoding="utf-8")):
        equiv[(r["tree"], r["operator"], r["id"])] = (r["verdict"], r["argument"])

# Variant 3 survivors take the verdict of the same site on build 2 (matched on file, function,
# label, class and source text) when the enclosing function's source is identical in both trees;
# otherwise they need a row of their own (tree v3) in equivalence.csv.
TREEDIR = {"b2": os.path.join(EXP, "src", "internal", "auditverify"), "v3": os.path.join(EXP, "f01d1c9", "internal", "auditverify")}


def func_source(tree, file, func):
    """The source of the named function: from its 'func' line to the first line that is '}'."""
    name = func.split(".")[-1].split(")")[-1] if func else ""
    text = open(os.path.join(TREEDIR[tree], file), encoding="utf-8").read().split("\n")
    for i, line in enumerate(text):
        if line.startswith("func ") and re.match(r"func (\([^)]*\) )?" + re.escape(name) + r"\b", line):
            for j in range(i, len(text)):
                if text[j] == "}":
                    return "\n".join(text[i:j + 1])
    return None


SITEKEY = lambda m: (m["file"], m.get("func", ""), m["call"], m.get("class", ""), m["original"])
b2_by_key = collections.defaultdict(list)
for _op in OPS:
    for _m in json.load(open(os.path.join(EXP, "lists", f"b2_{_op}.json"), encoding="utf-8"))["mutants"]:
        b2_by_key[(_op,) + SITEKEY(_m)].append(_m["id"])


def verdict_for(tree, op, m):
    v = equiv.get((tree, op, m["id"]))
    if v or tree == "b2":
        return v
    ids = b2_by_key.get((op,) + SITEKEY(m), [])
    same = func_source("v3", m["file"], m.get("func", "")) == func_source("b2", m["file"], m.get("func", "")) is not None
    if len(ids) == 1 and same:
        b = equiv.get(("b2", op, ids[0]))
        if b:
            return (b[0], f"carried over from build 2 site {ids[0]} (function unchanged): {b[1]}")
    return None


profiles = {}
summary, mutant_rows, survivor_rows, ceilings = {}, [], [], {}
for variant, (tree, prof, desc) in VARIANTS.items():
    if prof not in profiles:
        profiles[prof] = load_profile(prof)
    blocks = profiles[prof]
    for op in OPS:
        rep_path = os.path.join(EXP, "mut", f"heldout_{op}_{variant}.json")
        listing = json.load(open(os.path.join(EXP, "lists", f"{tree}_{op}.json"), encoding="utf-8"))
        flags = load_flags(tree, op)
        # ceiling: sites whose block ran in this variant's profile (H1: 7.3); computed for every operator
        ex = un = 0
        for s in listing["mutants"]:
            e, _ = join(blocks, s)
            ex += e is True
            un += e is None
        ceilings[f"{variant}/{op}"] = {"sites": len(listing["mutants"]), "executed": ex, "unmapped": un,
                                       "not_executed": len(listing["mutants"]) - ex - un,
                                       "ceiling_executed_only": round(ex / len(listing["mutants"]), 3),
                                       "ceiling_executed_or_unmapped": round((ex + un) / len(listing["mutants"]), 3)}
        if not os.path.exists(rep_path):
            continue
        rep = json.load(open(rep_path, encoding="utf-8"))
        ids = [m["id"] for m in rep["mutants"]]
        assert ids == [m["id"] for m in listing["mutants"]], f"{variant}/{op}: report sites differ from the -list sites"
        assert len(set(ids)) == len(ids)
        groups = collections.Counter()
        sub = collections.Counter()
        splits = collections.defaultdict(lambda: collections.Counter())
        unmapped_noncase = []
        for m in rep["mutants"]:
            fl = flags[m["id"]]
            executed, block = join(blocks, m)
            cov = "unmapped" if executed is None else ("executed" if executed else "not_executed")
            gd = group_deletion(m, fl)
            vo = m["file"] not in NOT_VERIFIER
            label = group = ""
            verdict = argument = ""
            if executed is None and not fl["case_expr"]:
                unmapped_noncase.append(m["id"])
            if m["result"] == "survived":
                if cov == "not_executed":
                    group, label = "not_executed", "not executed"
                elif cov == "unmapped" or fl["case_expr"]:
                    group, label = "eval_not_shown", "evaluation not shown"
                elif fl["right_operand"]:
                    group, label = "eval_not_shown", "line executed, evaluation not shown"
                else:
                    v = verdict_for(tree, op, m)
                    if v and v[0] == "equivalent":
                        group, label = "equivalent", "equivalent"
                    else:
                        group, label = "executed_undetected", "executed but undetected"
                    if v:
                        verdict, argument = v
                    else:
                        verdict, argument = "not_assessed", ""
                groups[group] += 1
                sub[label] += 1
            # splits (7.1, 7.5, 7.6)
            keys = ["all"]
            if op == "append":
                keys.append("group_deletions" if gd else "single_deletions")
            if op == "boundary":
                if not m.get("class", "").startswith("emptiness"):
                    keys.append("without_emptiness")
                if not m.get("zero_operand"):
                    keys.append("without_literal_0")
                else:
                    keys.append("literal_0_only")
            if op in ("boundary", "equality") and vo:
                keys.append("verifier_only")
            for k in keys:
                splits[k]["sites"] += 1
                splits[k][m["result"]] += 1
                if m["result"] == "survived":
                    splits[k]["surv_" + group] += 1
                    if group == "equivalent" and "text only" in argument:
                        splits[k]["surv_equivalent_text_only"] += 1
            row = {"variant": variant, "tree": tree, "operator": op, "id": m["id"], "file": m["file"], "line": m["line"],
                   "column": m["column"], "func": m.get("func", ""), "label": m["call"], "class": m.get("class", ""),
                   "zero_operand": bool(m.get("zero_operand")), "eval_not_shown": bool(m.get("eval_not_shown")),
                   "right_operand": fl["right_operand"], "case_expr": fl["case_expr"],
                   "literal_same_line": fl["literal_same_line"], "group_deletion": gd, "verifier_only": vo,
                   "coverage": cov, "block": block or "", "result": m["result"], "seconds": m["seconds"],
                   "first_failure": m.get("detail", ""), "survivor_group": group, "survivor_label": label,
                   "original": m["original"], "mutation": m["mutation"]}
            mutant_rows.append(row)
            if m["result"] == "survived":
                survivor_rows.append(dict(row, verdict=verdict, argument=argument))

        def score(c):
            k, s = c.get("killed", 0), c.get("survived", 0)
            return round(k / (k + s), 3) if k + s else None

        sp = {}
        for k, c in splits.items():
            sp[k] = {"sites": c["sites"], "killed": c.get("killed", 0), "survived": c.get("survived", 0),
                     "build_errors": c.get("build_error", 0), "timeouts": c.get("timeout", 0), "kill_score": score(c),
                     "survivors_by_group": {g: c.get("surv_" + g, 0) for g in
                                            ["not_executed", "eval_not_shown", "equivalent", "executed_undetected"]}}
            k2, s2 = c.get("killed", 0), c.get("survived", 0) - c.get("surv_equivalent", 0)
            sp[k]["kill_score_without_equivalent"] = round(k2 / (k2 + s2), 3) if k2 + s2 else None
            # the same, but text-only equivalents stay in the denominator (they change only messages)
            s3 = s2 + c.get("surv_equivalent_text_only", 0)
            sp[k]["equivalent_text_only"] = c.get("surv_equivalent_text_only", 0)
            sp[k]["kill_score_without_equivalent_except_text_only"] = round(k2 / (k2 + s3), 3) if k2 + s3 else None
        summary[f"{variant}/{op}"] = {
            "variant": variant, "description": desc, "operator": op, "tree": tree, "profile": prof,
            "skipped_tests": rep.get("skipped_tests", ""), "generated_at": rep["generated_at"],
            "baseline_seconds": rep.get("baseline_seconds", {}).get("suite"),
            "sites": rep["sites"], "killed": rep["killed"], "survived": rep["survived"],
            "build_errors": rep["build_errors"], "timeouts": rep["timeouts"], "kill_score": round(rep["kill_score"], 3),
            "survivors_by_group": {g: groups.get(g, 0) for g in ["not_executed", "eval_not_shown", "equivalent", "executed_undetected"]},
            "survivors_by_label": dict(sub),
            "equivalent_text_only": sum(1 for r in survivor_rows if r["variant"] == variant and r["operator"] == op
                                        and r["survivor_group"] == "equivalent" and "text only" in r["argument"]),
            "survivors_executed_vs_not": {"block_ran": sum(1 for r in survivor_rows if r["variant"] == variant and r["operator"] == op and r["coverage"] == "executed"),
                                          "block_not_run": groups.get("not_executed", 0),
                                          "unmapped": sum(1 for r in survivor_rows if r["variant"] == variant and r["operator"] == op and r["coverage"] == "unmapped")},
            "splits": sp, "ceiling": ceilings[f"{variant}/{op}"],
            "unmapped_sites_not_case_expressions": unmapped_noncase,
            "by_file": rep.get("by_file"), "by_func": rep.get("by_func"), "by_class": rep.get("by_class"),
        }

# site differences between the f01d1c9 list (variant 3) and build 2's (variants 1, 2): matched on
# file, function, label, class and source text (line numbers move), with multiplicity
diff = {}
for op in OPS:
    a = json.load(open(os.path.join(EXP, "lists", f"v3_{op}.json"), encoding="utf-8"))["mutants"]
    b = json.load(open(os.path.join(EXP, "lists", f"b2_{op}.json"), encoding="utf-8"))["mutants"]
    key = lambda m: (m["file"], m.get("func", ""), m["call"], m.get("class", ""), m["original"])
    ca, cb = collections.Counter(map(key, a)), collections.Counter(map(key, b))
    removed, added = ca - cb, cb - ca
    diff[op] = {"f01d1c9_sites": len(a), "build2_sites": len(b), "matched": sum((ca & cb).values()),
                "added": [dict(zip(["file", "func", "label", "class", "original"], k), count=n,
                               ids=[m["id"] for m in b if key(m) == k]) for k, n in sorted(added.items())],
                "removed": [dict(zip(["file", "func", "label", "class", "original"], k), count=n,
                                 ids=[m["id"] for m in a if key(m) == k]) for k, n in sorted(removed.items())],
                "line_moved": sum(1 for m in b if key(m) in ca and m["id"] not in {x["id"] for x in a if key(x) == key(m)})}
json.dump(diff, open(os.path.join(OUT, "site_diff_f01d1c9_to_build2.json"), "w"), indent=2)

# same site, results across variants (matched by key between trees)
# reference: section 4's H1 ceilings (93/153 full suite, 84/153 without the post-hoc tests) were taken
# from the previous build's refusal_conditions.csv; recomputed here with the same block join on the
# f01d1c9 export's own profiles (full suite and without the four post-hoc tests)
for prof in ["v3_full", "v3_without_posthoc4"]:
    blocks = profiles.get(prof) or load_profile(prof)
    for op in OPS:
        listing = json.load(open(os.path.join(EXP, "lists", f"v3_{op}.json"), encoding="utf-8"))["mutants"]
        res = [join(blocks, s)[0] for s in listing]
        ex, un = sum(1 for r in res if r is True), sum(1 for r in res if r is None)
        ceilings[f"reference_{prof}/{op}"] = {"sites": len(listing), "executed": ex, "unmapped": un,
                                              "not_executed": len(listing) - ex - un,
                                              "ceiling_executed_only": round(ex / len(listing), 3),
                                              "ceiling_executed_or_unmapped": round((ex + un) / len(listing), 3)}
json.dump(ceilings, open(os.path.join(OUT, "ceilings.json"), "w"), indent=2)
json.dump(summary, open(os.path.join(OUT, "heldout_summary.json"), "w"), indent=2)
with open(os.path.join(OUT, "heldout_summary.csv"), "w", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["variant", "operator", "split", "sites", "killed", "survived", "build_errors", "timeouts", "kill_score",
                "surv_not_executed", "surv_eval_not_shown", "surv_equivalent", "surv_executed_undetected",
                "kill_score_without_equivalent", "ceiling_executed_only"])
    for k, s in summary.items():
        for name, c in s["splits"].items():
            g = c["survivors_by_group"]
            w.writerow([s["variant"], s["operator"], name, c["sites"], c["killed"], c["survived"], c["build_errors"],
                        c["timeouts"], c["kill_score"], g["not_executed"], g["eval_not_shown"], g["equivalent"],
                        g["executed_undetected"], c["kill_score_without_equivalent"],
                        s["ceiling"]["ceiling_executed_only"] if name == "all" else ""])
for name, rows in [("heldout_mutants.csv", mutant_rows), ("heldout_survivors.csv", survivor_rows)]:
    if rows:
        with open(os.path.join(OUT, name), "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
print(json.dumps({k: {x: v[x] for x in ["sites", "killed", "survived", "build_errors", "timeouts", "kill_score", "survivors_by_group"]}
                  for k, v in summary.items()}, indent=1))
