"""Writes the top-level test names of both trees (go test -list output) and the
tests of build 2 that are absent from f01d1c9, i.e. absent from suite variant 3
by construction (HELDOUT_OPERATORS.md section 1 and 7.2), plus the mutation
tool's own tests (7.8).

usage: python test_names.py EXPDIR OUT.json"""
import json, re, sys, datetime

EXP, OUT = sys.argv[1], sys.argv[2]


def names(path):
    pkg, out = None, {}
    lines = open(path, encoding="utf-8").read().splitlines()
    cur = []
    for l in lines:
        m = re.match(r"^(ok|\?)\s+(\S+)", l)
        if m:
            out[m.group(2)] = cur
            cur = []
        elif re.match(r"^(Test|Fuzz|Example|Benchmark)\w*$", l.strip()):
            cur.append(l.strip())
    return out


b2, v3 = names(f"{EXP}/cov/testlist_src.txt"), names(f"{EXP}/cov/testlist_f01d1c9.txt")
all_b2 = {n for v in b2.values() for n in v}
all_v3 = {n for v in v3.values() for n in v}
tool = sorted(b2.get("agentgate/internal/auditverify/tools/refusalmutation", []))
later = sorted(all_b2 - all_v3)
res = {"written_at": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
       "build2_top_level_by_package": {k: len(v) for k, v in b2.items()},
       "f01d1c9_top_level_by_package": {k: len(v) for k, v in v3.items()},
       "absent_from_f01d1c9_count": len(later),
       "absent_from_f01d1c9_verifier_tests": [n for n in later if n not in tool],
       "mutation_tool_own_tests_7_8": tool,
       "in_f01d1c9_not_in_build2": sorted(all_v3 - all_b2),
       "note": "Variant 3 runs the f01d1c9 export's own tests, so every test listed under absent_from_f01d1c9 is absent from it; tests that existed at f01d1c9 run in their f01d1c9 versions. The mutation tool's own tests run in variants 1, 2 and 2b (they read the sources from disk, not through the overlay, so they cannot kill a mutant)."}
json.dump(res, open(OUT, "w"), indent=2)
print(len(later), "absent from f01d1c9 (", len(tool), "tool tests )", res["build2_top_level_by_package"], res["f01d1c9_top_level_by_package"])
