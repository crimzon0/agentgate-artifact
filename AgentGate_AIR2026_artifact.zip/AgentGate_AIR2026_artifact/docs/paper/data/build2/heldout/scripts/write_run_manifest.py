"""Writes run_manifest.json: settings, skip patterns, the timeline of every tool
invocation (from the '== ... start/exit' lines of the logs) and the headline.

usage: python write_run_manifest.py EXPDIR OUTDIR"""
import glob, json, os, re, sys

EXP, OUT = sys.argv[1:3]
sp = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "skip_patterns.sh")).read()
pat = dict(re.findall(r"^(\w+)='([^']*)'", sp, re.M))
runs = []
for log in sorted(glob.glob(os.path.join(EXP, "logs", "heldout_*.log"))):
    text = open(log, encoding="utf-8", errors="replace").read()
    start = re.search(r"^== (\S+) (\S+) start (\S+) parallel=(\d+)(?: file=\[([^\]]*)\])?(?: cap=\[([^\]]*)\])?", text, re.M)
    end = re.search(r"^== \S+ \S+ exit=(\d+) wall_seconds=(\d+) end (\S+)", text, re.M)
    end2 = re.search(r"report written; end \(driver B1 saw it\) (\S+)", text)
    base = re.search(r"baseline passes in ([\d.]+)s; testing (\d+) (\w+) mutants on (\d+) workers", text)
    final = re.search(r"kill score ([\d.]+) \((\d+) killed, (\d+) survived, (\d+) build errors, (\d+) timeouts\)", text)
    runs.append({"log": os.path.basename(log), "variant": start.group(1) if start else None, "operator": start.group(2) if start else None,
                 "start": start.group(3) if start else None, "parallel": int(start.group(4)) if start else None,
                 "file_selection": (start.group(5) or "") if start else None, "memory_cap": ("" if not (start and start.group(6)) else
                                "jobcap v1: hard 8 GiB job memory limit" if "hardcap" in log else
                                "jobcap v2: watchdog terminates a job process above 8 GiB private commit"),
                 "end": end.group(3) if end else (end2.group(1) if end2 else None),
                 "wall_seconds": int(end.group(2)) if end else None,
                 "wall_note": "" if end else "the driver that wrote the end line had been stopped; end = when the next driver saw the report",
                 "baseline_seconds": float(base.group(1)) if base else None, "mutants": int(base.group(2)) if base else None,
                 "result": final.group(0) if final else None})
summary = json.load(open(os.path.join(OUT, "heldout_summary.json"))) if os.path.exists(os.path.join(OUT, "heldout_summary.json")) else {}
res = {
    "experiment": "held-out mutation operators (HELDOUT_OPERATORS.md) on build 2",
    "build": "frozen build 2, commit 86643d7 (branch claude/supervisor-demo); the six frozen binaries are not run by this experiment",
    "tool": "internal/auditverify/tools/refusalmutation built from the frozen source copy (build-manifest.txt)",
    "test_packages": ["./internal/auditverify/...", "./cmd/agentgate-verify/"],
    "per_mutant_limit": "go test -timeout=5m0s, plus one minute backstop (tool defaults)",
    "variants": {
        "v1_full": {"tree": "<scratch>/build2-work/heldout/src (copy of 86643d7)", "skip": ""},
        "v2_without_posthoc4": {"tree": "<scratch>/build2-work/heldout/src", "skip": pat.get("POSTHOC4")},
        "v3_f01d1c9": {"tree": "<scratch>/build2-work/heldout/f01d1c9 (git archive f01d1c9)", "skip": pat.get("POSTHOC4")},
        "v2b_without_posthoc7": {"tree": "<scratch>/build2-work/heldout/src", "skip": pat.get("POSTHOC7"), "note": "supplementary, not defined by HELDOUT_OPERATORS.md: the seven-test pattern of VERIFIER_CHECKS.md section 6"},
    },
    "tests_absent_from_variant_3": "test_names.json (written before the variant 3 runs)",
    "coverage_profiles": {"v1_full": "b2_full", "v2_without_posthoc4": "b2_without_posthoc4", "v3_f01d1c9": "v3_without_posthoc4", "v2b_without_posthoc7": "b2_without_posthoc7"},
    "total_wall": "check_manifest BEFORE 2026-10-10T05:02:54Z .. AFTER 2026-10-10T07:19:49Z; first tool run 05:07:03Z, last 07:18:40Z",
    "incidents": [
        "boundary, variant 1, first run: the mutant files.go:237:30 grew its heap to about 20 GB; three concurrent mutants failed with out-of-memory errors (reported as build errors). The run is kept as heldout_boundary_v1_full.run1_memory_incident.json and was repeated (memory_incident.json).",
        "From then on the boundary operator ran as two invocations (merge_parts.py): every file but files.go with -parallel 8, files.go with -parallel 1. In variant 2 the isolated mutant still used all free memory for about 2.5 minutes, so the later files.go parts ran under jobcap. Its first version (a hard 8 GiB job memory limit, variant 1 rerun) left the test process hung in its exit; the tool's backstop classed the mutant timeout and the process stayed as an unkillable 4 GB zombie. The second version (a watchdog that terminates a job process above 8 GiB private commit) ran variant 3, variant 2b and a repeat of the variant 1 files.go part; the earlier variant 1 part is kept with the suffix .hardcap."
    ],
    "runs": runs,
    "headline": {k: {x: v[x] for x in ("sites", "killed", "survived", "build_errors", "timeouts", "kill_score")} for k, v in summary.items()},
}
json.dump(res, open(os.path.join(OUT, "run_manifest.json"), "w"), indent=2)
print(len(runs), "runs")
