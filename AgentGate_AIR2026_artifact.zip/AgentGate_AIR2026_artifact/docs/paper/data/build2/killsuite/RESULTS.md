# OS-level crash suite: killed and restarted gateway processes (build 2)

Run 2026-10-10 02:27:31-02:30:33 UTC with **frozen build 2** (`agentgate-killsuite`
`edbc7eec...9655`, `agentgate-verify` `83d0786a...eed0`, built from commit
`86643d7`; `build-manifest.txt`). Review 3, "run a focused crash suite"
(major comments 46-47 and the request at line 82). **New in build 2: there is
no build-1 run of this suite.** Section 10 compares it with the build-1
in-process crash experiment (`docs/paper/data/revision/crash/`) where the two
model the same thing.

**Headline.** 195 cell runs (39 cells x 5 repetitions), 235 operations, 455
agent answers, 210 provider effects. **Every acceptance measure is 0**: no
operation ID got a second provider effect (0/235), no REJECTED answer was
given while the provider held an effect (0/30), no
`REJECTED/provider_not_committed` was given or left while the provider held one
(0/15), no COMMITTED answer lacked an effect (0/185), nothing was dispatched
twice (0/195 cells), and no operation outside the two deliberate cells was
left unresolved or unsettled after Reconcile (0/225 operations). Every kill
point fired (145/145) and every cell gave the same result in all 5
repetitions. **The flag survived every recovery path: 45/45 committed flagged
operations**, including 60/60 recovery entries and 20/20 replayed answers
(10 in the process that recorded the effect, 10 after a restart). The verifier
accepted the newest segment, chain followed, in 145/150 restarted cells and
every single-segment cell (40/40). It failed **segment 1 verified alone** in
60/155 restarted cells: in 50 the process died after the provider committed
but before any outcome entry (`provider.matches_audit`), and 10 are
power-loss surrogates. **The 5 failing run walks are a false alarm on a crash
state with nothing tampered** (`head_reverted`, `head.matches`). A torn audit
tail makes the restart fail closed (5/5 refused).

## 1. What was run

```
py <singlebuild2>/check_manifest.py                      # before: 02:27:23Z, 1868 files, 0 differ
<singlebuild2>/bin/agentgate-killsuite.exe run \
    -verify <singlebuild2>/bin/agentgate-verify.exe -reps 5 -host-label review-host \
    -commit 86643d7 -out <scratch>/build2-work/killsuite/out -work <scratch>/build2-work/killsuite/work
py <singlebuild2>/check_manifest.py                      # after: 02:30:46Z, 1868 files, 0 differ
py recount_from_disk.py <scratch>/build2-work/killsuite/out/results.json <scratch>/build2-work/killsuite/work <out>
py reverify_dimensions.py <...>/results.json <...>/work <singlebuild2>/bin/agentgate-verify.exe <out>
py analyze.py <...>/results.json <out>
```

The suite's own method (`cmd/agentgate-killsuite/README.md`): for every cell
the parent starts a fresh provider in its own process, signs a grant, starts a
real gateway as a child process, drives MCP `tools/call` over loopback,
kills the child at the cell's kill point (`os.Exit(86)` from a fault hook or
an audit-sink point, or `TerminateProcess` from the parent for the two human
points), writes the dead segment's provider journal, restarts a new child on
the same operation journal, retries, calls `Composition.Reconcile`, closes the
child and runs `agentgate-verify --json` with the keys fingerprint and final
head pinned (pins streamed by the child before it died).

| group | cells | per repetition | what it covers |
|---|---|---|---|
| kill | 7 kill points x (ALLOW payment same-ID, FLAG message same-ID, payment fresh-ID control) | 21 | process crash at each durable transition, exact retry after restart |
| human | pending, approved, after_consume, after_receipt | 4 | crash on the human-approval path (AED 12,400.00) |
| provider | 7 faults on the payment, plus lost response on the flagged message | 8 | provider misbehaves, no kill |
| surrogate | torn journal tail, torn audit tail, reverted head, leftover temp head | 4 | power-loss states applied to a folder killed after EFFECT_EXECUTED |
| journal | read-only journal right after consume | 1 | one journal write failure |
| replay | flagged message, 2 same-process replays, 1 after restart | 1 | replayed answers keep the flag |

Totals: 195 cell runs, 235 operations (195 original, 35 fresh-ID, 5 journal
probes), 220 dispatch requests, 210 provider effects, 455 answers (185
COMMITTED, 30 REJECTED, 70 UNCERTAIN, 35 approval challenges, 135 no answer
because the process died), 135 segments killed with exit 86, 10 terminated by
the parent, 5 restarts refused (exit 3). The suite ran 365 verifications: 155
segment-1-alone, 150 run walks, 40 single segments, 20 untouched as-killed
copies.

Exactly the frozen binaries were used (check_manifest.py before and after:
1868 listed files, 0 differ); nothing was compiled. Elapsed time 181.8 s for
the suite; it is not a performance result (other runners shared the machine).

## 2. Acceptance measures (all required to be 0)

| measure | result |
|---|---|
| cells that could not run or did not test what they model (kill point or fault not fired, attribute not set, interrupted) | **0 / 195** |
| operation IDs with more than one provider effect (provider's signed journal) | **0 / 235** |
| REJECTED answered while the provider held an effect for that operation ID | **0 / 30** REJECTED answers |
| REJECTED/provider_not_committed while the provider holds an effect, checked at the end of the cell (answers and Reconcile states) | **0 / 15** such answers (+ 0 Reconcile states) |
| COMMITTED answered while the provider held no effect | **0 / 185** COMMITTED answers |
| operations unresolved after Reconcile, not deliberate | **0 / 225** operations of non-deliberate cells |
| operations dispatched or holding an effect that are not COMMITTED or REJECTED after Reconcile, not deliberate | **0 / 210** such operations |
| cells where an operation ID was dispatched more than once | **0 / 195** |
| dispatch requests for no operation of the cell | **0 / 220** dispatch requests |
| kill points not reached, or the child died elsewhere | **0 / 145** cells with a kill point |
| interrupted run | none |

All required measures met: **yes** (`summary.md`). `recount_from_disk.py`
recomputed effects per operation ID, duplicates, COMMITTED-without-effect,
not-committed-with-effect and the flag measures from the provider journals and
audit logs on disk: **0 disagreements in 195 cells** (`recount.md`).

## 3. Reported measures

| measure | result | why |
|---|---|---|
| unresolved after Reconcile, deliberate | 10 operations | `lookup_failure_persistent` (5, every lookup 503, stays UNCERTAIN by design, never re-dispatched) and `torn_audit_tail` (5, restart refused) |
| undecided after Reconcile (no final status) | 15 operations | the original operation of the two pre-dispatch fresh-ID controls (`before_consume`, `after_consume`: capability issued or consumed, nothing sent, no retry under that ID; 10) and the journal probe (5) |
| ... not listed by the gateway | 5 | the journal probe, refused before it could be journaled (`journal_unavailable`) |
| REJECTED answers whose operation ID was committed later by the restarted gateway | 10 answers (5 cells) | journal write failure, section 7 |
| fresh-ID controls that committed identical content twice | 25 / 35 fresh-ID cells | the 5 post-dispatch kill points; one effect per operation ID, not per business intent (by design) |
| restarts refused (fail closed) | 5 / 5 `torn_audit_tail` | section 6 |
| human cells whose restart needed a second approval | 15 / 20 | section 8 |
| flagged operations that committed / flag preserved | 45 / 45 | section 4 |
| warnings | `op.outcome_resolved` in 5 folders | the deliberately unresolved `lookup_failure_persistent` operation |

## 4. Flag preservation (build-2 change)

Every RECONCILED(committed) and CALL_RESULT(COMMITTED) entry of a flagged
operation was checked for `flagged: true` in every segment.

| flagged cell (x5) | outcome entries | recovery entries | replays: same process / after restart | flag kept | verifier reports flagged |
|---|---|---|---|---|---|
| kill/before_consume/flag-message/same-id | 1 | 0 (the operation simply ran again) | 0 / 0 | yes | yes |
| kill/after_consume/flag-message/same-id | 1 | 0 (ran again) | 0 / 0 | yes | yes |
| kill/after_provider_response/flag-message/same-id | 2 | 2 (RECONCILED + reconciling CALL_RESULT, segment 2) | 0 / 0 | yes | yes |
| kill/after_receipt/flag-message/same-id | 2 | 2 | 0 / 0 | yes | yes |
| kill/before_effect_executed/flag-message/same-id | 2 | 2 | 0 / 0 | yes | yes |
| kill/after_effect_executed/flag-message/same-id | 2 | 2 | 0 / 0 | yes | yes |
| kill/before_call_result/flag-message/same-id | 1 | 1 | 0 / 1 (from the journal) | yes | yes |
| provider/lost_response/flag-message | 2 | 2 (same process, no restart) | 0 / 0 | yes | yes |
| replay/flag-message/same-process | 4 | 1 | 2 / 1 | yes | yes |
| **total over 45 cells** | **85** | **60** (10 same process, 50 after a restart) | **10 / 10** | **45 / 45** | **45 / 45** |

Flag lost in an outcome entry 0/85, in a recovery entry 0/60, in a replayed
answer 0/20. Every replayed CALL_RESULT has scope `call` (35/35: 25 COMMITTED,
of which 20 flagged; 5 REJECTED/aborted_before_send; 5
REJECTED/provider_not_committed). **The agent's MCP answer carries no
`flagged` member** (0/185 COMMITTED answers report it), so the suite's "flag in
answers" measure is not applicable; flag preservation is measured on the audit
entries and the verifier report only.

## 5. Evidence verification (keys fingerprint and final head pinned by the parent)

| folder | VERIFIED/ANCHORED | FAILED | failing checks |
|---|---|---|---|
| segment 1 alone (restarted cells) | 95 / 155 | 60 | `provider.matches_audit` 50 (kills after the provider commit and before EFFECT_EXECUTED: after_provider_response, after_receipt, before_effect_executed x 3 paths, human/after_receipt); `head.matches` 5 (head_reverted); `chain.entry_hash` + `head.matches` + `head.anchor` 5 (torn_audit_tail) |
| newest segment, chain followed (run walk) | 145 / 150 | 5 | `head.matches` 5 (head_reverted, segment 1 of the chain) |
| single segment (provider cells) | 40 / 40 | 0 | (warning `op.outcome_resolved` 5: lookup_failure_persistent) |
| untouched as-killed copies of the surrogates | 20 / 20 | 0 | none |

**Why segment 1 alone fails after a post-commit kill.** The process died after
the provider committed but before the gateway wrote any outcome entry; the
parent writes the provider's signed journal into the dead segment, so segment
1 holds a provider commit its log never recorded. Verified alone it fails
`provider.matches_audit` ("provider commit #1 ... has no EFFECT_EXECUTED entry
in the audit log"); the continuation (segment 2: RECONCILED committed +
COMMITTED) verifies with the chain followed in every such cell (50/50). This is
the conservative answer for a dead segment read without its continuation.
Without a witness the verifier cannot know a continuation exists. Kills
before the commit (before_consume, after_consume) or after EFFECT_EXECUTED
(after_effect_executed, before_call_result) leave segment 1 VERIFIED.

**Re-verification with the build-2 report fields** (`reverify_dimensions.py`,
same binary and pins, its own process; `reverify.md`, `reverify.csv`): 365/365
folders gave the suite's verdict and failing checks.

- `head_fresh`: `not_checked` in 365/365 (pinned heads, no witness status).
- `run_complete`: never `pass` (needs a fresh witness status); `fail` in 70
  (the 65 FAILED folders and the 5 lookup_failure_persistent folders with an
  unresolved operation), `not_checked` in 295.
- Missing kinds: `freshness` in 360/365 (every folder whose head is anchored;
  the 5 torn-audit folders instead list a head-anchor mismatch, kind `other`),
  `issuer_only` in 75 (every reconciled-only execution: 50 run walks, 25
  provider cells), `unresolved` in 5 (lookup_failure_persistent).

**Classification evidence of the original operation** (newest folder that
VERIFIED; 195 cells): `issuer_adapter` 85 (EFFECT_EXECUTED exists: kills before
the dispatch, after EFFECT_EXECUTED, the human cells with a second run, the
surrogates that restart cleanly, journal, replay), `issuer_only_reconciled` 75
(every recovery that ended in RECONCILED: the 9 post-commit kill cells,
human/after_receipt, and 5 provider cells), `issuer_only_no_effect` 20
(pre-dispatch fresh-ID originals left pending, certified no-effect, delayed
delivery after ABSENT), `issuer_only_unresolved` 5 (lookup_failure_persistent),
not reported because the newest folder FAILED 10 (torn_audit_tail,
head_reverted). No RECONCILED entry carried an adapter effect receipt (0/105
committed RECONCILED entries): every reconciliation here followed a restart
(the receipt is kept in memory only) or a provider fault before any receipt,
so the `issuer_adapter`-through-RECONCILED path was not exercised.

## 6. Power-loss surrogates (applied to a folder killed after EFFECT_EXECUTED)

| state | restart | answer after restart | segment 1 | run walk | as-killed copy | outcome |
|---|---|---|---|---|---|---|
| `torn_journal_tail` (half of the last `operations.jsonl` line, no newline) | proceeds 5/5 | COMMITTED/reconciled, 1 effect | VERIFIED/ANCHORED | VERIFIED/ANCHORED | VERIFIED | the journal discards and truncates the torn line on open (0 torn lines remain in any journal) |
| `torn_audit_tail` (half of the last `audit.jsonl` line) | **refused 5/5** (child exit 3: "restart blocked: audit.jsonl line 8: malformed JSON") | none | FAILED: `chain.entry_hash`, `head.matches`, `head.anchor` | (no segment 2) | VERIFIED | fail closed: the effect the provider applied (1 per cell) has an EFFECT_EXECUTED entry before the torn line, but the agent never gets an answer and the gateway cannot continue until the folder is repaired by hand |
| `head_reverted` (`head.json` = the previous genuine head) | proceeds 5/5 (the continuation takes the head from the log's last line) | COMMITTED/reconciled, 1 effect | **FAILED `head.matches`** | **FAILED `head.matches`** | VERIFIED | **false alarm on an untampered crash state, permanent** (5/5 and 5/5). The finding says entries "were added without the recorder", which reads like tampering |
| `temp_head_left` (a `.head.json.tmp-*` file next to an intact head) | proceeds 5/5 | COMMITTED/reconciled, 1 effect | VERIFIED/ANCHORED | VERIFIED/ANCHORED | VERIFIED | the verifier ignores the leftover file (no warning) |

On Windows a power loss can leave the `head_reverted` state (no directory
flush; `os.Rename` is not write-through), so a pinned or anchored run can
fail `head.matches` without any tampering. The operation journal recovers
from a torn tail; the audit log deliberately does not.

## 7. One journal write failure (`journal/read_only_at_consume`, 5/5 identical)

The journal file was made read-only right after the capability was consumed.

1. First call: the dispatch-intent write fails (EFFECT_FAILED
   `DISPATCH_ADAPTER_WRITE`); answer **REJECTED/aborted_before_send**,
   `dispatched` false, scope `operation`; no request reached the provider.
2. A second operation (probe): REJECTED/`journal_unavailable`, scope `call`,
   never journaled (unlisted after Reconcile).
3. Exact retry in the same process: the stored REJECTED/aborted_before_send,
   replayed, scope `call`.
4. Graceful close, attribute cleared, restart: the journal holds `received`,
   `capability_issued`, `capability_consumed` and no outcome, because the
   refusal could not be recorded. The exact retry **runs again**: a second
   capability is issued and consumed, one dispatch, **COMMITTED, 1 effect**.

So 2 REJECTED answers per cell (10 in all) were followed by a commit of the
same operation ID. Each was true when it was given (nothing had been sent,
the provider held no effect), and the operation got exactly one effect. This
is the documented behaviour ("A REJECTED answer describes the moment it was
given": `docs/demo/CONTRACTS.md` §"REJECTED, defined per call",
`durable.go` `settle`). Note that the first REJECTED has scope `operation`
yet is not durable when the journal cannot record it. An agent that treats it
as final and retries under a fresh ID would get the business duplicate the
fresh-ID controls show. Both segments verify (VERIFIED/ANCHORED 5/5 each); the
first capability is consumed once and never used (`op.single_use` passes).

## 8. Provider faults (no kill; one gateway process; 5/5 identical each)

| fault | answers | after Reconcile | effects | lookups (503) | held dispatch |
|---|---|---|---|---|---|
| lost response (DROP_AFTER_COMMIT), payment | UNCERTAIN/provider_outcome_unknown, COMMITTED/reconciled | COMMITTED | 1 | 1 (0) | - |
| lost response, flagged message | same | COMMITTED (flag kept) | 1 | 1 (0) | - |
| certified no-effect (DROP_BEFORE_COMMIT, signed ABSENT) | UNCERTAIN, REJECTED/provider_not_committed | REJECTED/provider_not_committed | **0** | 1 (0) | - |
| UNKNOWN then APPLIED | UNCERTAIN, UNCERTAIN/provider_status_unknown, COMMITTED/reconciled | COMMITTED | 1 | 2 (0) | - |
| delayed delivery before the lookup | UNCERTAIN/provider_response_lost, COMMITTED/reconciled | COMMITTED | 1 | 1 (0) | released, HTTP 200 |
| delayed delivery after ABSENT | UNCERTAIN/provider_response_lost, REJECTED/provider_not_committed, then the stored REJECTED (replayed) | REJECTED/provider_not_committed | **0** | 1 (0) | released after ABSENT, **HTTP 409** (tombstone refused it) |
| lookup failure x3 | UNCERTAIN, 3 x UNCERTAIN/reconciliation_unavailable | COMMITTED (Reconcile) | 1 | 4 (3) | - |
| lookup failure, persistent | UNCERTAIN, 2 x UNCERTAIN/reconciliation_unavailable | **UNCERTAIN** (deliberate) | 1 | 3 (3) | - |

Every operation was dispatched exactly once (8 x 5 = 40 dispatches); no
UNCERTAIN operation was ever re-dispatched; neither `provider_not_committed`
answer had an effect behind it at the end of the cell (0/15). The persistent
case verifies VERIFIED/ANCHORED with a warning (`op.outcome_resolved`), a
Missing entry of kind `unresolved`, classification `issuer_only_unresolved`
and `run_complete` fail. Not covered: a provider that crashes or restarts
(the provider survives every cell by design), and flagged operations left
unresolved (the build-2 "flagged but unconfirmed" count is never exercised
here).

## 9. Human-approval cells (12,400.00 AED, human mode; 5/5 identical each)

| cell | what dies | after restart | second approval | effects | segment 1 / run walk |
|---|---|---|---|---|---|
| pending | terminated after the challenge, before any decision | challenged again, approved, COMMITTED | yes 5/5 | 1 | VERIFIED / VERIFIED |
| approved | terminated after the approval, before the agent resumed | **challenged again** (the approval was not used, so not recorded), approved, COMMITTED | yes 5/5 | 1 | VERIFIED / VERIFIED |
| after_consume | killed after the approved call's capability was consumed (APPROVAL_VERIFIED and CAPABILITY_ISSUED are in segment 1) | challenged again, approved, new capability, COMMITTED | yes 5/5 | 1 | VERIFIED / VERIFIED |
| after_receipt | killed after the provider committed | COMMITTED/reconciled, no new approval | no | 1 | FAILED (`provider.matches_audit`) / VERIFIED |

Second approval 15/20. An approval that has not led to a dispatch does not
survive a gateway crash: unused (approved), or used for a capability that was
consumed but never dispatched (after_consume). The operation then needs a
fresh approval. Every effect follows an APPROVAL_VERIFIED in the same segment
(segment 2 for pending, approved and after_consume; segment 1 for
after_receipt, whose restart only reconciles). No effect happened twice.

## 10. Comparison with build 1

There is no build-1 run of the kill suite. The closest build-1 experiment is
the in-process crash experiment (frozen build 1, 2026-10-08,
`revision/crash/RESULTS.md`): it abandons a gateway object inside one process,
with fault hooks that return errors, and the provider in the same process.

| measure | build 1, in-process crash (flag run) | build 2, kill suite | explanation |
|---|---|---|---|
| crash model | gateway object abandoned; faults return errors, so the gateway still answers | process exits at the hook (`os.Exit(86)`) or is terminated; no answer, no flush | the kill suite is the OS-level suite the review asked for |
| operation IDs with more than one effect | 0 / 1,120 | 0 / 235 | same property, different schedules |
| REJECTED while the provider held an effect | 0 / 480 | 0 / 30 | build 1's REJECTED were pre-dispatch fault answers; here only the journal cell (10), certified no-effect / delayed-after-ABSENT (15) and journal probe (5) answer REJECTED |
| COMMITTED without an effect | 0 / 1,120 | 0 / 185 | same |
| unresolved after one Reconcile | 0 / 1,120 | 0 / 225 (+10 deliberate) | build 1 had no provider faults and no refused restart |
| kill/fault before consume, exact retry | REJECTED/dispatch_refused, then the stored REJECTED; 0 effects | no answer; after restart COMMITTED; 1 effect | the dying process records no outcome, so the restarted gateway runs the operation again (nothing had been sent; CONTRACTS `settle`) |
| after consume, before the dispatch intent | REJECTED/aborted_before_send, stored REJECTED; 0 effects | no answer; after restart COMMITTED; 1 effect | as above; a second capability is issued |
| lost provider response | UNCERTAIN, then COMMITTED/reconciled; 1 effect | no answer, then COMMITTED/reconciled after restart; 1 effect | same final state |
| after the receipt / at the EFFECT_EXECUTED append | RECONCILIATION_REQUIRED, then COMMITTED/reconciled | no answer, then COMMITTED/reconciled | same final state; classification `issuer_only_reconciled` (no adapter receipt after a restart) |
| head_replace (build 1, emulated) / after_effect_executed | EFFECT_EXECUTED + RECONCILED for one effect | EFFECT_EXECUTED (seg 1) + RECONCILED (seg 2) | same pattern, real process exit |
| segment 1 verified alone | 280 / 280 ANCHORED (160 list unresolved operations) | 95 / 155 VERIFIED/ANCHORED; 50 FAILED `provider.matches_audit`, 10 surrogate failures | in build 1 the abandoned gateway had logged UNCERTAIN / RECONCILIATION_REQUIRED before it was abandoned; a killed process logs nothing after the provider commit |
| run walk (segment 2 with segment 1) | 280 / 280 VERIFIED/ANCHORED | 145 / 150 | the 5 failures are the `head_reverted` surrogate (no build-1 counterpart) |
| replayed answers with scope `call` | 240 / 240 | 35 / 35 | same rule |
| fresh-ID business duplicates | 400 / 1,120 operations | 25 / 35 fresh-ID cells | by design in both; here the pre-dispatch fresh-ID originals stay undecided (10) instead of REJECTED |
| provider faults, flagged path, human path, torn writes, journal write failure | not covered | covered | build-1 "open issues" asked for exactly these |
| classification evidence, `head_fresh`, `run_complete`, Missing kinds | not reported (build-1 verifier) | reported (sections 5, 8) | new verifier output in build 2 |

## 11. Unexpected findings

1. **Local path in signed evidence.** In 5/5 journal cells the probe's
   CALL_RESULT (`journal_unavailable`) embeds the absolute path of
   `operations.jsonl` (user and scratch folders) in its `summary` and
   `refused_reason`. `-host-label` does not cover it, and the entry is signed,
   so it cannot be redacted without breaking verification. Evidence from a
   journal-failure run therefore cannot go into the anonymous archive as is;
   the gateway's refusal text should drop the path (code change, outside this
   experiment). No such folder is in `samples/`.
2. **False alarm on a power-loss state** (`head_reverted`, 5/5): expected by
   the suite's design, but the finding text ("entries ... were added without
   the recorder") suggests tampering.
3. **Wording on a dead segment.** Segment 1 alone after a post-commit kill
   fails with "The provider performed an effect with no authorization trail",
   although the segment holds the operation's capability; only the outcome
   entry is missing.
4. **An operation-scope REJECTED is not durable under a journal write
   failure** (section 7). This is documented in CONTRACTS, but the scope
   `operation` label promises more than the gateway can keep in that case.
5. **An approval does not survive a crash before it leads to a dispatch**
   (15/20 second approvals, including after_consume, where the approval had
   already produced a consumed capability). Safe, but it costs the approver a
   second decision.
6. **The agent's answers carry no `flagged` member**, so the flag can be
   checked only in the audit entries and the verifier report.

No failure, error or false alarm was hidden: the only verifier failures are
the 60 segment-1-alone folders and the 5 head_reverted run walks explained
above, and the only cell-level problems the suite noted are the deliberate
unsettled operations (10).

## 12. Caveats

- One machine, Windows 10; a kill is a process crash, not a power cut. The
  kernel file cache survives, so a killed process never loses a write it
  made. Power loss is only approximated by the four surrogates, which use
  bytes the gateway itself wrote. Directory-entry persistence and `fsync`
  ordering are not tested on real power loss.
- Kills only at instrumented points (7 gateway points, 6 distinct on-disk
  states, plus 2 external terminations). There is no kill inside
  `audit.Append` between the line sync and the head rename (the
  `head_reverted` surrogate stands for it).
- The provider runs in the parent and never crashes or restarts. Provider
  restart (review comment 47) is not covered.
- No witness: segment 1 alone cannot show that a continuation exists, and
  `head_fresh` / `run_complete` cannot pass. The custody experiment covers the
  witness.
- Human cells drive the approval relay's real handlers inside the child with
  a synthetic TLS, loopback and browser-header request; no browser or TLS
  connection is exercised.
- Repetitions show stability (39/39 cells identical in 5/5), not independent
  samples. Elapsed times are not results.
- The re-verification uses the same verifier binary as the suite. It is a
  consistency check, not an independent verification. `recount_from_disk.py`
  is independent of the gateway code, but it reads only what the provider and
  the gateway wrote.

## 13. Files

| file | content |
|---|---|
| `RESULTS.md` | this file |
| `build-manifest.txt` | binaries, check_manifest.py before and after with timestamps, commands, script and result hashes |
| `results.json`, `results.csv`, `summary.md` | the suite's own output, byte copies (the suite writes `<path>` and `<work>` for local paths; `<work>` = `<scratch>/build2-work/killsuite/work`) |
| `run.log` | the suite's stdout, one line per cell run (scratch path replaced by `<scratch>`) |
| `analysis.md`, `analysis.json` | per-cell tables and stability (`analyze.py`) |
| `recount.md`, `recount.json` | recount from the files on disk and comparison with results.json (`recount_from_disk.py`) |
| `reverify.md`, `reverify.csv` | re-verification with the build-2 report fields, 365 folders (`reverify_dimensions.py`) |
| `analyze.py`, `recount_from_disk.py`, `reverify_dimensions.py` | analysis scripts (new for this experiment; the CBOR reader is adapted from build 1's `crash/reanalyze_from_disk.py`) |
| `samples/ks-kill-after_receipt-flag-message-same-id-r1/` | a post-commit kill on the flagged path: segment 1 alone FAILED (`provider.matches_audit`), segment 2 with the chain VERIFIED/ANCHORED, flagged RECONCILED (pins in results.json) |
| `samples/ks-surrogate-head_reverted-r1/` | the false-alarm surrogate: working folder FAILED `head.matches` (both segments), `as-killed/` copy VERIFIED/ANCHORED |

The cell folders (195, 25 MB) stay outside the repository in
`<scratch>/build2-work/killsuite/work`. The samples omit the parent-side
`segment-N.child.json` and `segment-N.stderr.log`, which hold local paths
and no evidence.
