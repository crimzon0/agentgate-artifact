# Kill-suite analysis (build 2)

From results.json by `analyze.py`. Every cell ran 5 times; cells whose measures differ between repetitions: 0.

## Flag preservation (flagged path, per cell; counts are per repetition)

| cell | reps | outcome entries | recovery entries | replays (same process / after restart) | flag in answers / entries / recovery / replays / verifier | preserved |
|---|---|---|---|---|---|---|
| kill/before_consume/flag-message/same-id | 5 | 1 | 0 | 0 / 0 |  / yes /  /  / yes | yes |
| kill/after_consume/flag-message/same-id | 5 | 1 | 0 | 0 / 0 |  / yes /  /  / yes | yes |
| kill/after_provider_response/flag-message/same-id | 5 | 2 | 2 | 0 / 0 |  / yes / yes /  / yes | yes |
| kill/after_receipt/flag-message/same-id | 5 | 2 | 2 | 0 / 0 |  / yes / yes /  / yes | yes |
| kill/before_effect_executed/flag-message/same-id | 5 | 2 | 2 | 0 / 0 |  / yes / yes /  / yes | yes |
| kill/after_effect_executed/flag-message/same-id | 5 | 2 | 2 | 0 / 0 |  / yes / yes /  / yes | yes |
| kill/before_call_result/flag-message/same-id | 5 | 1 | 1 | 0 / 1 |  / yes / yes / yes / yes | yes |
| provider/lost_response/flag-message | 5 | 2 | 2 | 0 / 0 |  / yes / yes /  / yes | yes |
| replay/flag-message/same-process | 5 | 4 | 1 | 2 / 1 |  / yes / yes / yes / yes | yes |

Totals over all repetitions: outcome entries 85, recovery entries 60, replayed answers 20 (same process 10, after a restart 10).

## Verdicts per cell (agentgate-verify, keys and head pinned)

| cell | segment 1 alone (failing) | run walk or single segment (failing) | warnings | as-killed copy | classification |
|---|---|---|---|---|---|
| kill/before_consume/allow-payment/same-id | VERIFIED/ANCHORED | VERIFIED/ANCHORED | - | - | issuer_adapter |
| kill/before_consume/flag-message/same-id | VERIFIED/ANCHORED | VERIFIED/ANCHORED | - | - | issuer_adapter |
| kill/before_consume/allow-payment/fresh-id | VERIFIED/ANCHORED | VERIFIED/ANCHORED | - | - | issuer_only_no_effect |
| kill/after_consume/allow-payment/same-id | VERIFIED/ANCHORED | VERIFIED/ANCHORED | - | - | issuer_adapter |
| kill/after_consume/flag-message/same-id | VERIFIED/ANCHORED | VERIFIED/ANCHORED | - | - | issuer_adapter |
| kill/after_consume/allow-payment/fresh-id | VERIFIED/ANCHORED | VERIFIED/ANCHORED | - | - | issuer_only_no_effect |
| kill/after_provider_response/allow-payment/same-id | FAILED/FAILED (provider.matches_audit) | VERIFIED/ANCHORED | - | - | issuer_only_reconciled |
| kill/after_provider_response/flag-message/same-id | FAILED/FAILED (provider.matches_audit) | VERIFIED/ANCHORED | - | - | issuer_only_reconciled |
| kill/after_provider_response/allow-payment/fresh-id | FAILED/FAILED (provider.matches_audit) | VERIFIED/ANCHORED | - | - | issuer_only_reconciled |
| kill/after_receipt/allow-payment/same-id | FAILED/FAILED (provider.matches_audit) | VERIFIED/ANCHORED | - | - | issuer_only_reconciled |
| kill/after_receipt/flag-message/same-id | FAILED/FAILED (provider.matches_audit) | VERIFIED/ANCHORED | - | - | issuer_only_reconciled |
| kill/after_receipt/allow-payment/fresh-id | FAILED/FAILED (provider.matches_audit) | VERIFIED/ANCHORED | - | - | issuer_only_reconciled |
| kill/before_effect_executed/allow-payment/same-id | FAILED/FAILED (provider.matches_audit) | VERIFIED/ANCHORED | - | - | issuer_only_reconciled |
| kill/before_effect_executed/flag-message/same-id | FAILED/FAILED (provider.matches_audit) | VERIFIED/ANCHORED | - | - | issuer_only_reconciled |
| kill/before_effect_executed/allow-payment/fresh-id | FAILED/FAILED (provider.matches_audit) | VERIFIED/ANCHORED | - | - | issuer_only_reconciled |
| kill/after_effect_executed/allow-payment/same-id | VERIFIED/ANCHORED | VERIFIED/ANCHORED | - | - | issuer_adapter |
| kill/after_effect_executed/flag-message/same-id | VERIFIED/ANCHORED | VERIFIED/ANCHORED | - | - | issuer_adapter |
| kill/after_effect_executed/allow-payment/fresh-id | VERIFIED/ANCHORED | VERIFIED/ANCHORED | - | - | issuer_adapter |
| kill/before_call_result/allow-payment/same-id | VERIFIED/ANCHORED | VERIFIED/ANCHORED | - | - | issuer_adapter |
| kill/before_call_result/flag-message/same-id | VERIFIED/ANCHORED | VERIFIED/ANCHORED | - | - | issuer_adapter |
| kill/before_call_result/allow-payment/fresh-id | VERIFIED/ANCHORED | VERIFIED/ANCHORED | - | - | issuer_adapter |
| human/pending | VERIFIED/ANCHORED | VERIFIED/ANCHORED | - | - | issuer_adapter |
| human/approved | VERIFIED/ANCHORED | VERIFIED/ANCHORED | - | - | issuer_adapter |
| human/after_consume | VERIFIED/ANCHORED | VERIFIED/ANCHORED | - | - | issuer_adapter |
| human/after_receipt | FAILED/FAILED (provider.matches_audit) | VERIFIED/ANCHORED | - | - | issuer_only_reconciled |
| provider/lost_response/allow-payment | - | VERIFIED/ANCHORED | - | - | issuer_only_reconciled |
| provider/certified_no_effect/allow-payment | - | VERIFIED/ANCHORED | - | - | issuer_only_no_effect |
| provider/unknown_then_applied/allow-payment | - | VERIFIED/ANCHORED | - | - | issuer_only_reconciled |
| provider/delayed_release_before_lookup/allow-payment | - | VERIFIED/ANCHORED | - | - | issuer_only_reconciled |
| provider/delayed_release_after_absent/allow-payment | - | VERIFIED/ANCHORED | - | - | issuer_only_no_effect |
| provider/lookup_failure_3/allow-payment | - | VERIFIED/ANCHORED | - | - | issuer_only_reconciled |
| provider/lookup_failure_persistent/allow-payment | - | VERIFIED/ANCHORED | op.outcome_resolved | - | issuer_only_unresolved |
| provider/lost_response/flag-message | - | VERIFIED/ANCHORED | - | - | issuer_only_reconciled |
| surrogate/torn_journal_tail | VERIFIED/ANCHORED | VERIFIED/ANCHORED | - | VERIFIED/ANCHORED | issuer_adapter |
| surrogate/torn_audit_tail | FAILED/FAILED (chain.entry_hash head.anchor head.matches) | restart refused | - | VERIFIED/ANCHORED | not reported (newest folder FAILED) |
| surrogate/head_reverted | FAILED/FAILED (head.matches) | FAILED/FAILED (head.matches) | - | VERIFIED/ANCHORED | not reported (newest folder FAILED) |
| surrogate/temp_head_left | VERIFIED/ANCHORED | VERIFIED/ANCHORED | - | VERIFIED/ANCHORED | issuer_adapter |
| journal/read_only_at_consume | VERIFIED/ANCHORED | VERIFIED/ANCHORED | - | - | issuer_adapter |
| replay/flag-message/same-process | VERIFIED/ANCHORED | VERIFIED/ANCHORED | - | - | issuer_adapter |

## Provider faults

| cell | answers | after Reconcile | effects | dispatches | lookups (503) | held dispatch HTTP status |
|---|---|---|---|---|---|---|
| provider/lost_response/allow-payment | s1:first=UNCERTAIN/provider_outcome_unknown s1:retry-1=COMMITTED/reconciled | COMMITTED/reconciled | {"original": 1} | {"original": 1} | 1 (0) | - |
| provider/certified_no_effect/allow-payment | s1:first=UNCERTAIN/provider_outcome_unknown s1:retry-1=REJECTED/provider_not_committed | REJECTED/provider_not_committed | {"original": 0} | {"original": 1} | 1 (0) | - |
| provider/unknown_then_applied/allow-payment | s1:first=UNCERTAIN/provider_outcome_unknown s1:retry-1=UNCERTAIN/provider_status_unknown s1:retry-2=COMMITTED/reconciled | COMMITTED/reconciled | {"original": 1} | {"original": 1} | 2 (0) | - |
| provider/delayed_release_before_lookup/allow-payment | s1:first=UNCERTAIN/provider_response_lost s1:retry-1=COMMITTED/reconciled | COMMITTED/reconciled | {"original": 1} | {"original": 1} | 1 (0) | 200 |
| provider/delayed_release_after_absent/allow-payment | s1:first=UNCERTAIN/provider_response_lost s1:retry-1=REJECTED/provider_not_committed s1:retry-2=REJECTED/provider_not_committed | REJECTED/provider_not_committed | {"original": 0} | {"original": 1} | 1 (0) | 409 |
| provider/lookup_failure_3/allow-payment | s1:first=UNCERTAIN/provider_outcome_unknown s1:retry-1=UNCERTAIN/reconciliation_unavailable s1:retry-2=UNCERTAIN/reconciliation_unavailable s1:retry-3=UNCERTAIN/reconciliation_unavailable | COMMITTED/reconciled | {"original": 1} | {"original": 1} | 4 (3) | - |
| provider/lookup_failure_persistent/allow-payment | s1:first=UNCERTAIN/provider_outcome_unknown s1:retry-1=UNCERTAIN/reconciliation_unavailable s1:retry-2=UNCERTAIN/reconciliation_unavailable | UNCERTAIN/provider_outcome_unknown | {"original": 1} | {"original": 1} | 3 (3) | - |
| provider/lost_response/flag-message | s1:first=UNCERTAIN/provider_outcome_unknown s1:retry-1=COMMITTED/reconciled | COMMITTED/reconciled | {"original": 1} | {"original": 1} | 1 (0) | - |

## Human, journal, replay and surrogate cells

| cell | answers | after Reconcile | effects | second approval | REJECTED then committed | undecided (unlisted) | restart refused |
|---|---|---|---|---|---|---|---|
| human/pending | s1:first=CHALLENGE s2:retry=CHALLENGE s2:resume=COMMITTED | COMMITTED | {"original": 1} | yes | 0 | 0 (0) | no |
| human/approved | s1:first=CHALLENGE s2:retry=CHALLENGE s2:resume=COMMITTED | COMMITTED | {"original": 1} | yes | 0 | 0 (0) | no |
| human/after_consume | s1:first=CHALLENGE s1:resume=NO_ANSWER s2:retry=CHALLENGE s2:resume=COMMITTED | COMMITTED | {"original": 1} | yes | 0 | 0 (0) | no |
| human/after_receipt | s1:first=CHALLENGE s1:resume=NO_ANSWER s2:retry=COMMITTED/reconciled | COMMITTED/reconciled | {"original": 1} | no | 0 | 0 (0) | no |
| surrogate/torn_journal_tail | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled | COMMITTED/reconciled | {"original": 1} | no | 0 | 0 (0) | no |
| surrogate/torn_audit_tail | s1:first=NO_ANSWER | unknown | {"original": 1} | no | 0 | 0 (0) | yes |
| surrogate/head_reverted | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled | COMMITTED/reconciled | {"original": 1} | no | 0 | 0 (0) | no |
| surrogate/temp_head_left | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled | COMMITTED/reconciled | {"original": 1} | no | 0 | 0 (0) | no |
| journal/read_only_at_consume | s1:first=REJECTED/aborted_before_send s1:probe=REJECTED/journal_unavailable(probe) s1:retry-same-process=REJECTED/aborted_before_send s2:retry=COMMITTED | COMMITTED | {"original": 1, "probe": 0} | no | 2 | 1 (1) | no |
| replay/flag-message/same-process | s1:first=COMMITTED s1:retry-same-process-1=COMMITTED s1:retry-same-process-2=COMMITTED s2:retry-after-restart=COMMITTED | COMMITTED | {"original": 1} | no | 0 | 0 (0) | no |

## Kill cells

| cell | answers | after Reconcile | effects | undecided | fresh-ID duplicate |
|---|---|---|---|---|---|
| kill/before_consume/allow-payment/same-id | s1:first=NO_ANSWER s2:retry=COMMITTED | COMMITTED | {"original": 1} | 0 | no |
| kill/before_consume/flag-message/same-id | s1:first=NO_ANSWER s2:retry=COMMITTED | COMMITTED | {"original": 1} | 0 | no |
| kill/before_consume/allow-payment/fresh-id | s1:first=NO_ANSWER s2:retry=COMMITTED(fresh) | UNDECIDED | {"fresh": 1, "original": 0} | 1 | no |
| kill/after_consume/allow-payment/same-id | s1:first=NO_ANSWER s2:retry=COMMITTED | COMMITTED | {"original": 1} | 0 | no |
| kill/after_consume/flag-message/same-id | s1:first=NO_ANSWER s2:retry=COMMITTED | COMMITTED | {"original": 1} | 0 | no |
| kill/after_consume/allow-payment/fresh-id | s1:first=NO_ANSWER s2:retry=COMMITTED(fresh) | UNDECIDED | {"fresh": 1, "original": 0} | 1 | no |
| kill/after_provider_response/allow-payment/same-id | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled | COMMITTED/reconciled | {"original": 1} | 0 | no |
| kill/after_provider_response/flag-message/same-id | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled | COMMITTED/reconciled | {"original": 1} | 0 | no |
| kill/after_provider_response/allow-payment/fresh-id | s1:first=NO_ANSWER s2:retry=COMMITTED(fresh) | COMMITTED/reconciled | {"fresh": 1, "original": 1} | 0 | yes |
| kill/after_receipt/allow-payment/same-id | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled | COMMITTED/reconciled | {"original": 1} | 0 | no |
| kill/after_receipt/flag-message/same-id | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled | COMMITTED/reconciled | {"original": 1} | 0 | no |
| kill/after_receipt/allow-payment/fresh-id | s1:first=NO_ANSWER s2:retry=COMMITTED(fresh) | COMMITTED/reconciled | {"fresh": 1, "original": 1} | 0 | yes |
| kill/before_effect_executed/allow-payment/same-id | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled | COMMITTED/reconciled | {"original": 1} | 0 | no |
| kill/before_effect_executed/flag-message/same-id | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled | COMMITTED/reconciled | {"original": 1} | 0 | no |
| kill/before_effect_executed/allow-payment/fresh-id | s1:first=NO_ANSWER s2:retry=COMMITTED(fresh) | COMMITTED/reconciled | {"fresh": 1, "original": 1} | 0 | yes |
| kill/after_effect_executed/allow-payment/same-id | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled | COMMITTED/reconciled | {"original": 1} | 0 | no |
| kill/after_effect_executed/flag-message/same-id | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled | COMMITTED/reconciled | {"original": 1} | 0 | no |
| kill/after_effect_executed/allow-payment/fresh-id | s1:first=NO_ANSWER s2:retry=COMMITTED(fresh) | COMMITTED/reconciled | {"fresh": 1, "original": 1} | 0 | yes |
| kill/before_call_result/allow-payment/same-id | s1:first=NO_ANSWER s2:retry=COMMITTED | COMMITTED | {"original": 1} | 0 | no |
| kill/before_call_result/flag-message/same-id | s1:first=NO_ANSWER s2:retry=COMMITTED | COMMITTED | {"original": 1} | 0 | no |
| kill/before_call_result/allow-payment/fresh-id | s1:first=NO_ANSWER s2:retry=COMMITTED(fresh) | COMMITTED | {"fresh": 1, "original": 1} | 0 | yes |

## Totals (results.json)

```
{
 "acceptance_passed": true,
 "as_killed_failing_checks": {},
 "as_killed_verdicts": {
  "VERIFIED/ANCHORED": 20
 },
 "as_killed_warning_checks": {},
 "cell_errors": 0,
 "cells": 195,
 "cells_with_redispatch": 0,
 "classification_evidence": {
  "issuer_adapter": 85,
  "issuer_only_no_effect": 20,
  "issuer_only_reconciled": 75,
  "issuer_only_unresolved": 5,
  "not reported (newest folder FAILED)": 10
 },
 "committed_without_effect": 0,
 "dispatches_for_unknown_operation_ids": 0,
 "failing_checks": {
  "chain.entry_hash": 5,
  "head.anchor": 5,
  "head.matches": 15,
  "provider.matches_audit": 50
 },
 "flag_cells_committed": 45,
 "flag_cells_with_recovery_entries": 35,
 "flag_cells_with_replay_entries": 10,
 "flag_cells_with_same_process_replay_entries": 5,
 "flag_lost": 0,
 "flag_lost_in_answers": 0,
 "flag_lost_in_outcome_entries": 0,
 "flag_lost_in_recovery_entries": 0,
 "flag_lost_in_replay_entries": 0,
 "flag_preserved": 45,
 "fresh_id_business_duplicates": 25,
 "interrupted_cells": 0,
 "kill_point_not_reached": 0,
 "operations": 235,
 "operations_with_more_than_one_effect": 0,
 "provider_not_committed_while_provider_holds_effect": 0,
 "rejected_answers_then_effect_after_restart": 10,
 "rejected_while_provider_holds_effect": 0,
 "restart_blocked": 5,
 "run_walk_verdicts": {
  "FAILED/FAILED": 5,
  "VERIFIED/ANCHORED": 145
 },
 "second_approval_required": 15,
 "segment1_alone_verdicts": {
  "FAILED/FAILED": 60,
  "VERIFIED/ANCHORED": 95
 },
 "single_segment_verdicts": {
  "VERIFIED/ANCHORED": 40
 },
 "undecided_after_reconcile": 15,
 "unlisted_after_reconcile": 5,
 "unresolved_after_reconcile_deliberate": 10,
 "unresolved_after_reconcile_not_deliberate": 0,
 "unsettled_with_dispatch_or_effect_not_deliberate": 0,
 "warning_checks": {
  "op.outcome_resolved": 5
 }
}
```
