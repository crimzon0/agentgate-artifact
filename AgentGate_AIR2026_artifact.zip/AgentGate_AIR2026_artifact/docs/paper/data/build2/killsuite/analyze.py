#!/usr/bin/env python3
"""Per-cell tables of the kill-suite run, from results.json only.

Groups the five repetitions of every cell, checks that the measures below
are identical in every repetition (stability), and writes analysis.md and
analysis.json with:

  * flag preservation per flagged cell: outcome entries, recovery entries,
    replayed answers written by the process that recorded the effect and
    after a restart, the verifier's flag;
  * verdicts per cell: segment 1 alone, run walk or single segment, the
    as-killed copy, failing and warning check IDs;
  * provider faults: answers, status lookups, lookups answered 503, the
    held dispatch's HTTP status, effects and dispatches;
  * human cells and the journal cell: answers, second approvals, REJECTED
    answers whose operation ID was committed later, undecided and unlisted
    operations;
  * classification evidence of the original operation per cell.

Usage: python analyze.py RESULTS_JSON OUT_DIR. Python 3 standard library.
"""
import collections
import json
import os
import sys


def chain(cell):
    parts = []
    for answer in cell.get("answers") or []:
        result = answer["result"]
        if result.get("challenge"):
            text = "CHALLENGE"
        elif result.get("no_answer"):
            text = "NO_ANSWER"
        else:
            text = result.get("status", "?") + ("/" + result["reason"] if result.get("reason") else "")
        if answer["operation"] != "original":
            text += "(%s)" % answer["operation"]
        parts.append("s%d:%s=%s" % (answer["segment"], answer["call"], text))
    return " ".join(parts)


def seg(cell, index):
    for segment in cell.get("segments") or []:
        if segment["index"] == index and segment.get("verify"):
            v = segment["verify"]
            return "%s/%s" % (v.get("verdict"), v.get("assurance")), " ".join(v.get("failing_checks") or []), \
                " ".join(v.get("warning_checks") or [])
    return "", "", ""


def row_of(cell):
    segments = cell.get("segments") or []
    restarted = len(segments) > 1
    s1 = seg(cell, 1)
    s2 = seg(cell, 2) if restarted else ("", "", "")
    as_killed = cell.get("as_killed_copy_verify")
    return {
        "answers": chain(cell),
        "state_after_reconcile": cell.get("original_state_after_reconcile"),
        "effects": json.dumps(cell.get("provider_effects"), sort_keys=True),
        "dispatches": json.dumps(cell.get("dispatch_requests"), sort_keys=True),
        "status_lookups": cell.get("status_lookups", 0),
        "status_lookups_503": cell.get("status_lookups_503", 0),
        "held_dispatch_http_status": cell.get("held_dispatch_http_status", ""),
        "segment1": s1[0] if restarted else "", "segment1_failing": s1[1] if restarted else "",
        "segment2_or_single": s2[0] if restarted else s1[0],
        "segment2_or_single_failing": s2[1] if restarted else s1[1],
        "warnings": " ".join(x for x in (s1[2], s2[2]) if x),
        "as_killed": ("%s/%s %s" % (as_killed.get("verdict"), as_killed.get("assurance"),
                                    " ".join(as_killed.get("failing_checks") or []))).strip() if as_killed else "",
        "restart_blocked": bool(cell.get("restart_blocked")),
        "second_approval": bool(cell.get("second_approval_required")),
        "rejected_then_effect": cell.get("rejected_then_effect", 0),
        "undecided": cell.get("undecided_operations", 0),
        "unlisted": cell.get("unlisted_operations", 0),
        "unresolved": cell.get("unresolved_operations", 0),
        "business_duplicate": bool(cell.get("business_duplicate")),
        "flag_expected": bool(cell.get("flag_expected")),
        "outcome_entries": cell.get("outcome_entries", 0),
        "recovery_entries": cell.get("recovery_entries", 0),
        "replay_entries": cell.get("replay_entries", 0),
        "same_process_replay_entries": cell.get("same_process_replay_entries", 0),
        "flag_in_answers": cell.get("flag_in_committed_answers"),
        "flag_in_outcome_entries": cell.get("flag_in_outcome_entries"),
        "flag_in_recovery_entries": cell.get("flag_in_recovery_entries"),
        "flag_in_replay_entries": cell.get("flag_in_replay_entries"),
        "flag_in_verifier_report": cell.get("flag_in_verifier_report"),
        "flag_preserved": cell.get("flag_preserved"),
        "classification": cell.get("classification_evidence") or (
            "not reported (newest folder FAILED)" if cell.get("classification_folder_verdict", "").startswith("FAILED")
            else "not reported"),
        "error": cell.get("error", ""),
    }


def yn(value):
    return "" if value is None else ("yes" if value else "no")


def main():
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    results_path, out_dir = sys.argv[1:]
    with open(results_path, encoding="utf-8") as handle:
        results = json.load(handle)
    groups = collections.OrderedDict()
    for cell in results["cells"]:
        groups.setdefault(cell["name"], []).append(cell)
    table, unstable = collections.OrderedDict(), []
    for name, cells in groups.items():
        rows = [row_of(cell) for cell in cells]
        variants = {json.dumps(row, sort_keys=True) for row in rows}
        if len(variants) > 1:
            unstable.append(name)
        entry = dict(rows[0])
        entry["reps"] = len(rows)
        entry["stable"] = len(variants) == 1
        entry["group"] = cells[0]["group"]
        table[name] = entry
    totals = results["totals"]
    flag_rows = [(n, e) for n, e in table.items() if e["flag_expected"]]
    sums = collections.Counter()
    for _, e in flag_rows:
        for key in ("outcome_entries", "recovery_entries", "replay_entries", "same_process_replay_entries"):
            sums[key] += e[key] * e["reps"]
    lines = ["# Kill-suite analysis (build 2)", "",
             "From results.json by `analyze.py`. Every cell ran %d times; cells whose measures differ between repetitions: %d%s." % (
                 results["reps"], len(unstable), (" (" + ", ".join(unstable) + ")") if unstable else ""), "",
             "## Flag preservation (flagged path, per cell; counts are per repetition)", "",
             "| cell | reps | outcome entries | recovery entries | replays (same process / after restart) | flag in answers / entries / recovery / replays / verifier | preserved |",
             "|---|---|---|---|---|---|---|"]
    for name, e in flag_rows:
        lines.append("| %s | %d | %d | %d | %d / %d | %s / %s / %s / %s / %s | %s |" % (
            name, e["reps"], e["outcome_entries"], e["recovery_entries"], e["same_process_replay_entries"],
            e["replay_entries"] - e["same_process_replay_entries"], yn(e["flag_in_answers"]), yn(e["flag_in_outcome_entries"]),
            yn(e["flag_in_recovery_entries"]), yn(e["flag_in_replay_entries"]), yn(e["flag_in_verifier_report"]), yn(e["flag_preserved"])))
    lines += ["", "Totals over all repetitions: outcome entries %d, recovery entries %d, replayed answers %d (same process %d, after a restart %d)." % (
        sums["outcome_entries"], sums["recovery_entries"], sums["replay_entries"], sums["same_process_replay_entries"],
        sums["replay_entries"] - sums["same_process_replay_entries"]), ""]
    lines += ["## Verdicts per cell (agentgate-verify, keys and head pinned)", "",
              "| cell | segment 1 alone (failing) | run walk or single segment (failing) | warnings | as-killed copy | classification |",
              "|---|---|---|---|---|---|"]
    for name, e in table.items():
        s1 = ("%s (%s)" % (e["segment1"], e["segment1_failing"]) if e["segment1_failing"] else e["segment1"]) or "-"
        s2 = ("%s (%s)" % (e["segment2_or_single"], e["segment2_or_single_failing"]) if e["segment2_or_single_failing"]
              else e["segment2_or_single"]) or ("restart refused" if e["restart_blocked"] else "-")
        lines.append("| %s | %s | %s | %s | %s | %s |" % (name, s1, s2, e["warnings"] or "-", e["as_killed"] or "-", e["classification"]))
    lines += ["", "## Provider faults", "",
              "| cell | answers | after Reconcile | effects | dispatches | lookups (503) | held dispatch HTTP status |", "|---|---|---|---|---|---|---|"]
    for name, e in table.items():
        if e["group"] == "provider":
            lines.append("| %s | %s | %s | %s | %s | %d (%d) | %s |" % (
                name, e["answers"], e["state_after_reconcile"], e["effects"], e["dispatches"], e["status_lookups"],
                e["status_lookups_503"], e["held_dispatch_http_status"] or "-"))
    lines += ["", "## Human, journal, replay and surrogate cells", "",
              "| cell | answers | after Reconcile | effects | second approval | REJECTED then committed | undecided (unlisted) | restart refused |",
              "|---|---|---|---|---|---|---|---|"]
    for name, e in table.items():
        if e["group"] in ("human", "journal", "replay", "surrogate"):
            lines.append("| %s | %s | %s | %s | %s | %d | %d (%d) | %s |" % (
                name, e["answers"], e["state_after_reconcile"], e["effects"], yn(e["second_approval"]), e["rejected_then_effect"],
                e["undecided"], e["unlisted"], yn(e["restart_blocked"])))
    lines += ["", "## Kill cells", "",
              "| cell | answers | after Reconcile | effects | undecided | fresh-ID duplicate |", "|---|---|---|---|---|---|"]
    for name, e in table.items():
        if e["group"] == "kill":
            lines.append("| %s | %s | %s | %s | %d | %s |" % (
                name, e["answers"], e["state_after_reconcile"], e["effects"], e["undecided"], yn(e["business_duplicate"])))
    lines += ["", "## Totals (results.json)", "", "```", json.dumps(totals, indent=1, sort_keys=True), "```", ""]
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "analysis.md"), "w", encoding="utf-8", newline="\n") as handle:
        handle.write("\n".join(lines))
    with open(os.path.join(out_dir, "analysis.json"), "w", encoding="utf-8", newline="\n") as handle:
        json.dump({"unstable_cells": unstable, "flag_totals": dict(sums), "cells": table}, handle, indent=1)
        handle.write("\n")
    print("\n".join(lines[:4]))
    print("unstable:", unstable, "flag sums:", dict(sums))


if __name__ == "__main__":
    main()
