# Kill suite on an earlier build (before the two flag fixes)

These are the results of the first full kill-suite run (`-reps 5`, 190 cell runs, 2026-10-10 00:20 UTC).
It ran before build 2 was frozen, on the suite's first commit (`f5cdc2a`, based on `f01d1c9`), so the
gateway and the verifier were those of build 1 plus the new suite package.

| binary | SHA-256 |
|---|---|
| agentgate-killsuite (suite and gateway child) | `b31c5cca4ff74a37848b3e918e18fade7421b38f5ea3e5fec58f09a71c73df90` |
| agentgate-verify (build-1 verifier source) | `8acb82033f1c88959709deaa5e9b5ab4391bcb28c5b36963fbd7ffec6ce98443` |

What this run is evidence for:

- **Flag loss after a real kill.** In 20 of the 40 flagged cells that committed, the restarted gateway's
  RECONCILED and CALL_RESULT entries no longer said `flagged` (kills between the dispatch intent and the
  journal's `recorded` record). The verifier of that build accepted those folders (its report re-derived
  the flag from the signed decision but did not compare the recovery records). Build 2 fixes the gateway
  (the dispatch intent records the flag) and the verifier (it fails a recovery record that does not state
  the bound flag). The same-process replay path was found later, while checking the suite, with no kill.
- Every required measure was 0 here as well (no duplicate effect, no COMMITTED without an effect, no call
  answered REJECTED although its own request committed). The suite's acceptance rules were tightened after
  this run (kill-not-reached, undecided operations, unknown dispatches), so totals are not comparable one to
  one with build 2; take every kill-suite number for the paper from `../summary.md` (build 2).

The files are copied unchanged from the run's output folder; they contain no machine name or local path.
