# OS-level crash suite (agentgate-killsuite)

OS-level crash runs of one gateway build on one machine, with a simulated provider in the parent process. Statuses, provider effects and verifier verdicts are observations of these schedules only, not a proof of crash safety for other schedules; a process kill models a gateway crash, not a power loss.

Command: `agentgate-killsuite run -verify ./bin/agentgate-verify.exe -out ./full-r5/out -work ./full-r5/work -reps 5`  
Go go1.26.6 on windows/amd64, 12 CPUs. Repetitions: 5. Cells: 190. Elapsed: 173.0 s.

## Acceptance

| measure | count | required |
|---|---|---|
| cells that could not run | 0 | 0 |
| operation IDs with more than one provider effect | 0 | 0 |
| REJECTED answered while the provider held an effect for that operation ID | 0 | 0 |
| REJECTED/provider_not_committed while the provider holds an effect (checked at the end of the cell) | 0 | 0 |
| COMMITTED answered while the provider held no effect | 0 | 0 |
| operations unresolved after Reconcile (not deliberate) | 0 | 0 |
| cells where an operation ID was dispatched more than once | 0 | 0 |
| operations unresolved after Reconcile (deliberate: endless lookup failure, refused restart) | 10 | reported |
| REJECTED answers whose operation ID was committed later by the restarted gateway (journal write failure) | 10 | reported |
| fresh-ID controls that committed identical content twice (one effect per operation ID, not per intent) | 25 | reported |
| kill point not reached | 0 | reported |
| restarts refused (fail closed) | 5 | reported |
| human cells whose restart required a second approval | 15 | reported |
| flagged operations that committed | 40 | reported |
| ... flag preserved in every answer and outcome entry | 20 | reported |
| ... flag lost in an outcome entry (RECONCILED / CALL_RESULT) | 20 | reported |
| ... flag lost in an answer | 0 | reported |

All required measures met: **yes**.

## Verifier verdicts (agentgate-verify, keys and head pinned by the parent)

| folder | verdict | count |
|---|---|---|
| segment 1 alone (restarted cells) | FAILED/FAILED | 60 |
| segment 1 alone (restarted cells) | VERIFIED/ANCHORED | 90 |
| newest segment, chain followed (run walk) | FAILED/FAILED | 5 |
| newest segment, chain followed (run walk) | VERIFIED/ANCHORED | 140 |
| single segment (no restart) | VERIFIED/ANCHORED | 40 |

| failing check | folders |
|---|---|
| chain.entry_hash | 5 |
| head.anchor | 5 |
| head.matches | 15 |
| provider.matches_audit | 50 |

## Per cell (outcome signature over the repetitions)

Answers are `segment:call=STATUS/reason`; NO_ANSWER means the connection ended because the gateway process died. Verdicts are VERDICT/ASSURANCE from agentgate-verify.

| cell | reps | stable | outcome (most frequent) | models |
|---|---|---|---|---|
| kill/before_consume/allow-payment/same-id | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/; after Reconcile COMMITTED; effects 1; seg1 VERIFIED/ANCHORED; seg2 VERIFIED/ANCHORED | process crash: capability issued and journaled, not consumed; no dispatch intent; nothing sent; restart from disk, exact retry |
| kill/before_consume/flag-message/same-id | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/; after Reconcile COMMITTED; effects 1; seg1 VERIFIED/ANCHORED; seg2 VERIFIED/ANCHORED; flag preserved yes | process crash: capability issued and journaled, not consumed; no dispatch intent; nothing sent; restart from disk, exact retry |
| kill/before_consume/allow-payment/fresh-id | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/(fresh); after Reconcile UNDECIDED; effects 0; fresh effects 1; seg1 VERIFIED/ANCHORED; seg2 VERIFIED/ANCHORED | control: as the same-id cell, but the agent retries with a fresh operation ID for identical content (one effect per operation ID, not per intent) |
| kill/after_consume/allow-payment/same-id | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/; after Reconcile COMMITTED; effects 1; seg1 VERIFIED/ANCHORED; seg2 VERIFIED/ANCHORED | process crash: capability consumed (journaled), dispatch intent not yet journaled; no request byte sent; restart from disk, exact retry |
| kill/after_consume/flag-message/same-id | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/; after Reconcile COMMITTED; effects 1; seg1 VERIFIED/ANCHORED; seg2 VERIFIED/ANCHORED; flag preserved yes | process crash: capability consumed (journaled), dispatch intent not yet journaled; no request byte sent; restart from disk, exact retry |
| kill/after_consume/allow-payment/fresh-id | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/(fresh); after Reconcile UNDECIDED; effects 0; fresh effects 1; seg1 VERIFIED/ANCHORED; seg2 VERIFIED/ANCHORED | control: as the same-id cell, but the agent retries with a fresh operation ID for identical content (one effect per operation ID, not per intent) |
| kill/after_provider_response/allow-payment/same-id | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled; after Reconcile COMMITTED/reconciled; effects 1; seg1 FAILED/FAILED; seg2 VERIFIED/ANCHORED | process crash: dispatch intent journaled, provider committed and answered; the gateway dies before it reads the answer; restart from disk, exact retry |
| kill/after_provider_response/flag-message/same-id | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled; after Reconcile COMMITTED/reconciled; effects 1; seg1 FAILED/FAILED; seg2 VERIFIED/ANCHORED; flag preserved no | process crash: dispatch intent journaled, provider committed and answered; the gateway dies before it reads the answer; restart from disk, exact retry |
| kill/after_provider_response/allow-payment/fresh-id | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/(fresh); after Reconcile COMMITTED/reconciled; effects 1; fresh effects 1; seg1 FAILED/FAILED; seg2 VERIFIED/ANCHORED | control: as the same-id cell, but the agent retries with a fresh operation ID for identical content (one effect per operation ID, not per intent) |
| kill/after_receipt/allow-payment/same-id | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled; after Reconcile COMMITTED/reconciled; effects 1; seg1 FAILED/FAILED; seg2 VERIFIED/ANCHORED | process crash: provider and effect receipts verified and signed (provider_outcome journaled), EFFECT_EXECUTED not appended; restart from disk, exact retry |
| kill/after_receipt/flag-message/same-id | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled; after Reconcile COMMITTED/reconciled; effects 1; seg1 FAILED/FAILED; seg2 VERIFIED/ANCHORED; flag preserved no | process crash: provider and effect receipts verified and signed (provider_outcome journaled), EFFECT_EXECUTED not appended; restart from disk, exact retry |
| kill/after_receipt/allow-payment/fresh-id | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/(fresh); after Reconcile COMMITTED/reconciled; effects 1; fresh effects 1; seg1 FAILED/FAILED; seg2 VERIFIED/ANCHORED | control: as the same-id cell, but the agent retries with a fresh operation ID for identical content (one effect per operation ID, not per intent) |
| kill/before_effect_executed/allow-payment/same-id | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled; after Reconcile COMMITTED/reconciled; effects 1; seg1 FAILED/FAILED; seg2 VERIFIED/ANCHORED | process crash: as after_receipt, at the EFFECT_EXECUTED append itself (the audit_append hook); restart from disk, exact retry |
| kill/before_effect_executed/flag-message/same-id | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled; after Reconcile COMMITTED/reconciled; effects 1; seg1 FAILED/FAILED; seg2 VERIFIED/ANCHORED; flag preserved no | process crash: as after_receipt, at the EFFECT_EXECUTED append itself (the audit_append hook); restart from disk, exact retry |
| kill/before_effect_executed/allow-payment/fresh-id | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/(fresh); after Reconcile COMMITTED/reconciled; effects 1; fresh effects 1; seg1 FAILED/FAILED; seg2 VERIFIED/ANCHORED | control: as the same-id cell, but the agent retries with a fresh operation ID for identical content (one effect per operation ID, not per intent) |
| kill/after_effect_executed/allow-payment/same-id | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled; after Reconcile COMMITTED/reconciled; effects 1; seg1 VERIFIED/ANCHORED; seg2 VERIFIED/ANCHORED | process crash: EFFECT_EXECUTED appended and the head replaced; the journal's 'recorded' record not written; restart from disk, exact retry |
| kill/after_effect_executed/flag-message/same-id | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled; after Reconcile COMMITTED/reconciled; effects 1; seg1 VERIFIED/ANCHORED; seg2 VERIFIED/ANCHORED; flag preserved no | process crash: EFFECT_EXECUTED appended and the head replaced; the journal's 'recorded' record not written; restart from disk, exact retry |
| kill/after_effect_executed/allow-payment/fresh-id | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/(fresh); after Reconcile COMMITTED/reconciled; effects 1; fresh effects 1; seg1 VERIFIED/ANCHORED; seg2 VERIFIED/ANCHORED | control: as the same-id cell, but the agent retries with a fresh operation ID for identical content (one effect per operation ID, not per intent) |
| kill/before_call_result/allow-payment/same-id | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/; after Reconcile COMMITTED; effects 1; seg1 VERIFIED/ANCHORED; seg2 VERIFIED/ANCHORED | process crash: 'recorded' journaled (stored answer); CALL_RESULT not appended; the agent gets no answer; restart from disk, exact retry |
| kill/before_call_result/flag-message/same-id | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/; after Reconcile COMMITTED; effects 1; seg1 VERIFIED/ANCHORED; seg2 VERIFIED/ANCHORED; flag preserved yes | process crash: 'recorded' journaled (stored answer); CALL_RESULT not appended; the agent gets no answer; restart from disk, exact retry |
| kill/before_call_result/allow-payment/fresh-id | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/(fresh); after Reconcile COMMITTED; effects 1; fresh effects 1; seg1 VERIFIED/ANCHORED; seg2 VERIFIED/ANCHORED | control: as the same-id cell, but the agent retries with a fresh operation ID for identical content (one effect per operation ID, not per intent) |
| human/pending | 5 | yes | s1:first=CHALLENGE s2:retry=CHALLENGE s2:resume=COMMITTED/; after Reconcile COMMITTED; effects 1; seg1 VERIFIED/ANCHORED; seg2 VERIFIED/ANCHORED | process crash on the human path: human path: approval challenge answered PENDING, no decision yet; the parent terminates the process; restart from disk, exact retry (approved again if challenged) |
| human/approved | 5 | yes | s1:first=CHALLENGE s2:retry=CHALLENGE s2:resume=COMMITTED/; after Reconcile COMMITTED; effects 1; seg1 VERIFIED/ANCHORED; seg2 VERIFIED/ANCHORED | process crash on the human path: human path: the approver approved, the agent has not resumed yet; the parent terminates the process; restart from disk, exact retry (approved again if challenged) |
| human/after_consume | 5 | yes | s1:first=CHALLENGE s1:resume=NO_ANSWER s2:retry=CHALLENGE s2:resume=COMMITTED/; after Reconcile COMMITTED; effects 1; seg1 VERIFIED/ANCHORED; seg2 VERIFIED/ANCHORED | process crash on the human path: capability consumed (journaled), dispatch intent not yet journaled; no request byte sent; restart from disk, exact retry (approved again if challenged) |
| human/after_receipt | 5 | yes | s1:first=CHALLENGE s1:resume=NO_ANSWER s2:retry=COMMITTED/reconciled; after Reconcile COMMITTED/reconciled; effects 1; seg1 FAILED/FAILED; seg2 VERIFIED/ANCHORED | process crash on the human path: provider and effect receipts verified and signed (provider_outcome journaled), EFFECT_EXECUTED not appended; restart from disk, exact retry (approved again if challenged) |
| provider/lost_response/allow-payment | 5 | yes | s1:first=UNCERTAIN/provider_outcome_unknown s1:retry-1=COMMITTED/reconciled; after Reconcile COMMITTED/reconciled; effects 1; seg1 VERIFIED/ANCHORED | provider committed, its response was lost (DROP_AFTER_COMMIT); the exact retry reconciles |
| provider/certified_no_effect/allow-payment | 5 | yes | s1:first=UNCERTAIN/provider_outcome_unknown s1:retry-1=REJECTED/provider_not_committed; after Reconcile REJECTED/provider_not_committed; effects 0; seg1 VERIFIED/ANCHORED | provider dropped the request before committing (DROP_BEFORE_COMMIT); the retry's lookup draws a signed ABSENT (tombstone): certified no-effect |
| provider/unknown_then_applied/allow-payment | 5 | yes | s1:first=UNCERTAIN/provider_outcome_unknown s1:retry-1=UNCERTAIN/provider_status_unknown s1:retry-2=COMMITTED/reconciled; after Reconcile COMMITTED/reconciled; effects 1; seg1 VERIFIED/ANCHORED | lost response, then a signed UNKNOWN status (STATUS_UNKNOWN), then APPLIED on the next lookup |
| provider/delayed_release_before_lookup/allow-payment | 5 | yes | s1:first=UNCERTAIN/provider_response_lost s1:retry-1=COMMITTED/reconciled; after Reconcile COMMITTED/reconciled; effects 1; seg1 VERIFIED/ANCHORED | the dispatch is held past the gateway's 10 s response timeout and delivered (commits) before the retry's lookup: APPLIED |
| provider/delayed_release_after_absent/allow-payment | 5 | yes | s1:first=UNCERTAIN/provider_response_lost s1:retry-1=REJECTED/provider_not_committed s1:retry-2=REJECTED/provider_not_committed; after Reconcile REJECTED/provider_not_committed; effects 0; seg1 VERIFIED/ANCHORED | the dispatch is held past the timeout; the retry draws a signed ABSENT first; the late delivery must then be refused by the tombstone |
| provider/lookup_failure_3/allow-payment | 5 | yes | s1:first=UNCERTAIN/provider_outcome_unknown s1:retry-1=UNCERTAIN/reconciliation_unavailable s1:retry-2=UNCERTAIN/reconciliation_unavailable s1:retry-3=UNCERTAIN/reconciliation_unavailable; after Reconcile COMMITTED/reconciled; effects 1; seg1 VERIFIED/ANCHORED | lost response, then 3 status lookups answered HTTP 503: UNCERTAIN, never re-dispatched; Reconcile resolves it |
| provider/lookup_failure_persistent/allow-payment | 5 | yes | s1:first=UNCERTAIN/provider_outcome_unknown s1:retry-1=UNCERTAIN/reconciliation_unavailable s1:retry-2=UNCERTAIN/reconciliation_unavailable; after Reconcile UNCERTAIN/provider_outcome_unknown; effects 1; seg1 VERIFIED/ANCHORED | lost response and every status lookup answered HTTP 503: stays UNCERTAIN after Reconcile, never re-dispatched |
| provider/lost_response/flag-message | 5 | yes | s1:first=UNCERTAIN/provider_outcome_unknown s1:retry-1=COMMITTED/reconciled; after Reconcile COMMITTED/reconciled; effects 1; seg1 VERIFIED/ANCHORED; flag preserved yes | lost response on the flagged path; the reconciled answer must stay flagged |
| surrogate/torn_journal_tail | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled; after Reconcile COMMITTED/reconciled; effects 1; seg1 VERIFIED/ANCHORED; seg2 VERIFIED/ANCHORED | power-loss surrogate: a torn final line in operations.jsonl (a record that was being written); the journal discards it and the restart proceeds |
| surrogate/torn_audit_tail | 5 | yes | s1:first=NO_ANSWER; after Reconcile unknown; effects 1; seg1 FAILED/FAILED; restart blocked | power-loss surrogate: a torn final line in audit.jsonl (an entry that was being written); the continuation cannot be read, so the restart is refused (fail closed) |
| surrogate/head_reverted | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled; after Reconcile COMMITTED/reconciled; effects 1; seg1 FAILED/FAILED; seg2 FAILED/FAILED | power-loss surrogate: head.json replaced by the previous genuine head (the line was synced, the head rename did not reach the disk) |
| surrogate/temp_head_left | 5 | yes | s1:first=NO_ANSWER s2:retry=COMMITTED/reconciled; after Reconcile COMMITTED/reconciled; effects 1; seg1 VERIFIED/ANCHORED; seg2 VERIFIED/ANCHORED | power-loss surrogate: a leftover .head.json.tmp-* file next to an intact head (a crash inside the atomic head replacement) |
| journal/read_only_at_consume | 5 | yes | s1:first=REJECTED/aborted_before_send s1:probe=REJECTED/journal_unavailable(probe) s1:retry-same-process=REJECTED/aborted_before_send s2:retry=COMMITTED/; after Reconcile COMMITTED; effects 1; seg1 VERIFIED/ANCHORED; seg2 VERIFIED/ANCHORED | one journal write failure: the journal file is made read-only right after the capability was consumed, so the dispatch-intent write fails; after a graceful close the attribute is cleared and the gateway restarted |
