# Recount of the kill-suite measures from the files on disk

`recount_from_disk.py` (provider journals, audit logs, operation journal; no gateway code).

| measure | count |
|---|---|
| cells | 195 |
| cells_with_disagreement | 0 |
| operations | 235 |
| effects | 210 |
| duplicate_operations | 0 |
| committed_call_results_without_effect | 0 |
| not_committed_call_results_with_effect | 0 |
| flag_cells_committed | 45 |
| flag_outcome_entries | 85 |
| flag_replay_entries | 20 |
| flag_cells_with_unflagged_outcome_entry | 0 |
| torn_audit_lines | 5 |
| torn_journal_lines | 0 |
