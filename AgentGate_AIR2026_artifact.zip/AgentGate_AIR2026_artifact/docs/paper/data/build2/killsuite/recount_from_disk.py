#!/usr/bin/env python3
"""Recount the kill-suite safety measures from the files on disk.

agentgate-killsuite computes its measures from the provider's in-memory state
(its own journal and request counters), the agent's answers and the audit
logs. This script recomputes the countable ones from what was written to disk
only, and compares them with results.json cell by cell:

  * provider effects: the signed receipts in every segment's
    provider-journal.json of the cell (union by commit_seq; decoded with a
    minimal CBOR reader adapted from build 1's crash/reanalyze_from_disk.py;
    signatures are checked by the verifier, not here);
  * audit: RECONCILED and CALL_RESULT entries in every segment's audit.jsonl
    (a torn final line, as the torn_audit_tail surrogate leaves it, is
    counted and skipped);
  * operations.jsonl: records per kind, torn final line counted.

Compared per cell: provider effects by role (original, fresh, probe),
operations with more than one effect, COMMITTED CALL_RESULT entries for an
operation the provider holds no effect for, REJECTED/provider_not_committed
CALL_RESULT entries for an operation the provider holds an effect for, and on
the flagged path the number of outcome entries (RECONCILED committed and
CALL_RESULT COMMITTED of the original operation), whether every one says
flagged, and the number of replayed CALL_RESULT(COMMITTED) entries.

Usage: python recount_from_disk.py RESULTS_JSON WORK_DIR OUT_DIR
Writes recount.json and recount.md into OUT_DIR. Python 3 standard library.
"""
import base64
import collections
import glob
import json
import os
import sys


# --- minimal CBOR (RFC 8949) reader: enough for COSE_Sign1 receipts ---------

def _cbor(data, i):
    head = data[i]
    major, info = head >> 5, head & 0x1F
    i += 1
    if info < 24:
        arg = info
    elif info in (24, 25, 26, 27):
        size = 1 << (info - 24)
        arg = int.from_bytes(data[i:i + size], "big")
        i += size
    else:
        raise ValueError("indefinite or reserved CBOR length")
    if major == 0:
        return arg, i
    if major == 1:
        return -1 - arg, i
    if major == 2:
        return bytes(data[i:i + arg]), i + arg
    if major == 3:
        return data[i:i + arg].decode("utf-8"), i + arg
    if major == 4:
        out = []
        for _ in range(arg):
            value, i = _cbor(data, i)
            out.append(value)
        return out, i
    if major == 5:
        out = {}
        for _ in range(arg):
            key, i = _cbor(data, i)
            value, i = _cbor(data, i)
            out[key] = value
        return out, i
    if major == 6:
        value, i = _cbor(data, i)
        return ("tag", arg, value), i
    if major == 7:
        return {20: False, 21: True, 22: None}.get(info, ("simple", info)), i
    raise ValueError("bad CBOR major type")


def cbor_decode(data):
    value, end = _cbor(data, 0)
    if end != len(data):
        raise ValueError("trailing bytes after CBOR item")
    return value


def receipt_payload(signed_b64):
    item = cbor_decode(base64.b64decode(signed_b64))
    if isinstance(item, tuple) and item[0] == "tag":
        item = item[2]
    if not (isinstance(item, list) and len(item) == 4):
        raise ValueError("not a COSE_Sign1 array")
    return cbor_decode(item[2])


def op_text(raw):
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


# --- files of one cell -------------------------------------------------------

def read_jsonl(path):
    """Parsed lines and the number of unparsable (torn) lines."""
    rows, torn = [], 0
    with open(path, encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except ValueError:
                torn += 1
    return rows, torn


def segment_dirs(cell_dir):
    dirs = [d for d in glob.glob(os.path.join(cell_dir, "segment-*")) if os.path.isdir(d)]
    return sorted(dirs, key=lambda d: int(d.rsplit("-", 1)[1]))


def provider_commits(cell_dir):
    """Effects per operation ID, union of every segment's provider journal."""
    by_seq = {}
    for seg in segment_dirs(cell_dir):
        path = os.path.join(seg, "provider-journal.json")
        if not os.path.exists(path):
            continue
        with open(path, encoding="utf-8") as handle:
            journal = json.load(handle)
        for entry in journal.get("entries", []):
            payload = receipt_payload(entry["signed_receipt"])
            key = entry.get("commit_seq")
            op = op_text(payload["operation_id"])
            if key in by_seq and by_seq[key] != op:
                raise ValueError("commit_seq %s names two operations in %s" % (key, cell_dir))
            by_seq[key] = op
    return collections.Counter(by_seq.values())


def audit_entries(cell_dir):
    out, torn = [], 0
    for seg in segment_dirs(cell_dir):
        path = os.path.join(seg, "audit.jsonl")
        if not os.path.exists(path):
            continue
        rows, bad = read_jsonl(path)
        torn += bad
        index = int(seg.rsplit("-", 1)[1])
        out.extend((index, row["entry"]) for row in rows)
    return out, torn


def recount_cell(cell, cell_dir):
    commits = provider_commits(cell_dir)
    entries, torn_audit = audit_entries(cell_dir)
    journal_kinds, torn_journal = collections.Counter(), 0
    journal_path = os.path.join(cell_dir, "operations.jsonl")
    if os.path.exists(journal_path):
        rows, torn_journal = read_jsonl(journal_path)
        journal_kinds.update(row.get("kind") for row in rows)
    roles = {"original": cell.get("operation_id"), "fresh": cell.get("fresh_operation_id"),
             "probe": cell.get("probe_operation_id")}
    effects = {role: commits.get(op, 0) for role, op in roles.items() if op}
    original = roles["original"]
    committed_without, not_committed_with = 0, 0
    outcome, flagged_all, replays = 0, True, 0
    for _, entry in entries:
        if entry.get("stage") not in ("CALL_RESULT", "RECONCILED"):
            continue
        details = entry.get("details") or {}
        op = entry.get("operation_id")
        status = details.get("status")
        if entry["stage"] == "CALL_RESULT" and status == "COMMITTED" and commits.get(op, 0) == 0:
            committed_without += 1
        if entry["stage"] == "CALL_RESULT" and status == "REJECTED" and details.get("reason") == "provider_not_committed" \
                and commits.get(op, 0) > 0:
            not_committed_with += 1
        if op != original:
            continue
        is_outcome = (entry["stage"] == "RECONCILED" and entry.get("outcome") == "committed") or \
                     (entry["stage"] == "CALL_RESULT" and status == "COMMITTED")
        if is_outcome:
            outcome += 1
            flagged_all = flagged_all and details.get("flagged") is True
            if entry["stage"] == "CALL_RESULT" and details.get("replayed") is True:
                replays += 1
    return {
        "effects": effects,
        "duplicate_operations": sum(1 for count in commits.values() if count > 1),
        "committed_call_results_without_effect": committed_without,
        "not_committed_call_results_with_effect": not_committed_with,
        "outcome_entries": outcome,
        "flag_in_outcome_entries": flagged_all if outcome else None,
        "replay_entries": replays,
        "torn_audit_lines": torn_audit,
        "torn_journal_lines": torn_journal,
        "journal_kinds": dict(journal_kinds),
        "segments": len(segment_dirs(cell_dir)),
    }


def compare(cell, mine):
    diffs = []
    reported = cell.get("provider_effects") or {}
    for role, count in mine["effects"].items():
        if reported.get(role, 0) != count:
            diffs.append("effects[%s] %s vs %s" % (role, reported.get(role), count))
    if cell.get("operations_with_duplicate_effect", 0) != mine["duplicate_operations"]:
        diffs.append("duplicates %s vs %s" % (cell.get("operations_with_duplicate_effect"), mine["duplicate_operations"]))
    if cell.get("flag_expected") and mine["effects"].get("original", 0) > 0:
        if cell.get("outcome_entries", 0) != mine["outcome_entries"]:
            diffs.append("outcome_entries %s vs %s" % (cell.get("outcome_entries"), mine["outcome_entries"]))
        if cell.get("flag_in_outcome_entries") != mine["flag_in_outcome_entries"]:
            diffs.append("flag_in_outcome_entries %s vs %s" % (cell.get("flag_in_outcome_entries"), mine["flag_in_outcome_entries"]))
        if cell.get("replay_entries", 0) != mine["replay_entries"]:
            diffs.append("replay_entries %s vs %s" % (cell.get("replay_entries"), mine["replay_entries"]))
    return diffs


def main():
    if len(sys.argv) != 4:
        sys.exit(__doc__)
    results_path, work_dir, out_dir = sys.argv[1:]
    with open(results_path, encoding="utf-8") as handle:
        results = json.load(handle)
    rows, totals = [], collections.Counter()
    for cell in results["cells"]:
        label = cell.get("label") or os.path.basename(cell["dir"].replace("\\", "/"))
        cell_dir = os.path.join(work_dir, label)
        mine = recount_cell(cell, cell_dir)
        diffs = compare(cell, mine)
        rows.append({"cell": cell["name"], "rep": cell["rep"], "label": label, "recount": mine, "disagreements": diffs})
        totals["cells"] += 1
        totals["cells_with_disagreement"] += 1 if diffs else 0
        totals["operations"] += len(mine["effects"])
        totals["effects"] += sum(mine["effects"].values())
        totals["duplicate_operations"] += mine["duplicate_operations"]
        totals["committed_call_results_without_effect"] += mine["committed_call_results_without_effect"]
        totals["not_committed_call_results_with_effect"] += mine["not_committed_call_results_with_effect"]
        totals["torn_audit_lines"] += mine["torn_audit_lines"]
        totals["torn_journal_lines"] += mine["torn_journal_lines"]
        if cell.get("flag_expected") and mine["effects"].get("original", 0) > 0:
            totals["flag_cells_committed"] += 1
            totals["flag_outcome_entries"] += mine["outcome_entries"]
            totals["flag_replay_entries"] += mine["replay_entries"]
            if mine["flag_in_outcome_entries"] is False:
                totals["flag_cells_with_unflagged_outcome_entry"] += 1
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "recount.json"), "w", encoding="utf-8", newline="\n") as handle:
        json.dump({"totals": dict(totals), "cells": rows}, handle, indent=1, sort_keys=True)
        handle.write("\n")
    lines = ["# Recount of the kill-suite measures from the files on disk", "",
             "`recount_from_disk.py` (provider journals, audit logs, operation journal; no gateway code).", "",
             "| measure | count |", "|---|---|"]
    for key in ["cells", "cells_with_disagreement", "operations", "effects", "duplicate_operations",
                "committed_call_results_without_effect", "not_committed_call_results_with_effect",
                "flag_cells_committed", "flag_outcome_entries", "flag_replay_entries",
                "flag_cells_with_unflagged_outcome_entry", "torn_audit_lines", "torn_journal_lines"]:
        lines.append("| %s | %d |" % (key, totals.get(key, 0)))
    bad = [row for row in rows if row["disagreements"]]
    if bad:
        lines += ["", "## Disagreements", ""]
        for row in bad:
            lines.append("- %s r%d: %s" % (row["cell"], row["rep"], "; ".join(row["disagreements"])))
    with open(os.path.join(out_dir, "recount.md"), "w", encoding="utf-8", newline="\n") as handle:
        handle.write("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
