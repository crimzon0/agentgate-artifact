# Re-verification of the kill-suite folders (build-2 report fields)

`reverify_dimensions.py`: the frozen agentgate-verify again, same pins as the suite. `missing kind` counts Missing entries; `class` counts operations.

## segment1_alone

| measure | count |
|---|---|
| agree | 155 |
| class audit_only | 15 |
| class issuer_adapter | 55 |
| class issuer_only_no_effect | 90 |
| folders | 155 |
| head_fresh not_checked | 155 |
| missing kind freshness | 150 |
| missing kind other | 5 |
| run_complete fail | 60 |
| run_complete not_checked | 95 |
| verdict FAILED/FAILED | 60 |
| verdict VERIFIED/ANCHORED | 95 |

## run_walk

| measure | count |
|---|---|
| agree | 150 |
| class audit_only | 5 |
| class issuer_adapter | 125 |
| class issuer_only_no_effect | 10 |
| class issuer_only_reconciled | 50 |
| folders | 150 |
| head_fresh not_checked | 150 |
| missing kind freshness | 150 |
| missing kind issuer_only | 50 |
| run_complete fail | 5 |
| run_complete not_checked | 145 |
| verdict FAILED/FAILED | 5 |
| verdict VERIFIED/ANCHORED | 145 |

## single

| measure | count |
|---|---|
| agree | 40 |
| class issuer_only_no_effect | 10 |
| class issuer_only_reconciled | 25 |
| class issuer_only_unresolved | 5 |
| folders | 40 |
| head_fresh not_checked | 40 |
| missing kind freshness | 40 |
| missing kind issuer_only | 25 |
| missing kind unresolved | 5 |
| run_complete fail | 5 |
| run_complete not_checked | 35 |
| verdict VERIFIED/ANCHORED | 40 |

## as_killed

| measure | count |
|---|---|
| agree | 20 |
| class issuer_adapter | 20 |
| folders | 20 |
| head_fresh not_checked | 20 |
| missing kind freshness | 20 |
| run_complete not_checked | 20 |
| verdict VERIFIED/ANCHORED | 20 |
