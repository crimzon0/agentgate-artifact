#!/usr/bin/env python3
"""Re-run agentgate-verify on every kill-suite evidence folder and read the
build-2 report fields the suite does not keep.

For every segment the suite verified (and every untouched as-killed copy of a
surrogate cell) this script runs the given agentgate-verify again in its own
process, with the same pins the suite used (keys fingerprint and final head
from results.json), and records: verdict and assurance, failing check IDs
(compared with the suite's record), the derived dimensions head_fresh and
run_complete, missing_kinds, counts.classification_evidence and the
segments walked. Same verifier binary as the suite, so this is a
consistency check of the suite's record, not an independent verification.

Usage: python reverify_dimensions.py RESULTS_JSON WORK_DIR VERIFY_EXE OUT_DIR
Writes reverify.csv and reverify.md into OUT_DIR. Python 3 standard library.
"""
import collections
import csv
import json
import os
import subprocess
import sys


def run_verify(exe, folder, keys, head):
    args = [exe, "--json", "--workers", "1"]
    if keys:
        args += ["--expect-keys", keys]
    if head:
        args += ["--expect-head", head]
    args.append(folder)
    proc = subprocess.run(args, capture_output=True, text=True, encoding="utf-8")
    if proc.returncode not in (0, 1):
        return {"exit": proc.returncode, "error": proc.stderr.strip()[:200]}
    report = json.loads(proc.stdout)
    dims = report.get("dimensions") or {}
    return {
        "exit": proc.returncode,
        "verdict": "%s/%s" % (report.get("verdict"), report.get("assurance")),
        "failing": sorted({f["id"] for f in report.get("failures") or []}),
        "warnings": sorted({w["id"] for w in report.get("warnings") or []}),
        "head_fresh": (dims.get("head_fresh") or {}).get("status", ""),
        "run_complete": (dims.get("run_complete") or {}).get("status", ""),
        "missing_kinds": report.get("missing_kinds") or [],
        "classification": (report.get("counts") or {}).get("classification_evidence") or {},
        "segments_walked": len(report.get("segments") or []) or 1,
    }


def main():
    if len(sys.argv) != 5:
        sys.exit(__doc__)
    results_path, work_dir, exe, out_dir = sys.argv[1:]
    with open(results_path, encoding="utf-8") as handle:
        results = json.load(handle)
    rows = []
    for cell in results["cells"]:
        label = cell["label"]
        segments = cell.get("segments") or []
        targets = []
        for seg in segments:
            if seg.get("verify") is None:
                continue
            if len(segments) == 1:
                role = "single"
            elif seg["index"] == 1:
                role = "segment1_alone"
            else:
                role = "run_walk"
            targets.append((role, os.path.join(work_dir, label, "segment-%d" % seg["index"]),
                            seg.get("keys_sha256", ""), seg.get("pinned_head", ""), seg["verify"]))
        if cell.get("as_killed_copy_verify"):
            seg1 = segments[0]
            targets.append(("as_killed", os.path.join(work_dir, label, "as-killed", "segment-1"),
                            seg1.get("keys_sha256", ""), seg1.get("pinned_head", ""), cell["as_killed_copy_verify"]))
        for role, folder, keys, head, suite in targets:
            mine = run_verify(exe, folder, keys, head)
            suite_verdict = "%s/%s" % (suite.get("verdict"), suite.get("assurance"))
            agree = mine.get("verdict") == suite_verdict and mine.get("failing") == sorted(suite.get("failing_checks") or [])
            rows.append({
                "cell": cell["name"], "rep": cell["rep"], "folder_role": role,
                "verdict": mine.get("verdict", "ERROR"), "suite_verdict": suite_verdict, "agree": "yes" if agree else "no",
                "failing": " ".join(mine.get("failing", [])), "warnings": " ".join(mine.get("warnings", [])),
                "head_fresh": mine.get("head_fresh", ""), "run_complete": mine.get("run_complete", ""),
                "missing_kinds": " ".join(sorted(mine.get("missing_kinds", []))),
                "classification": " ".join("%s=%d" % kv for kv in sorted(mine.get("classification", {}).items())),
                "segments_walked": mine.get("segments_walked", ""), "error": mine.get("error", ""),
            })
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "reverify.csv"), "w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    by_role = collections.defaultdict(collections.Counter)
    for row in rows:
        role = row["folder_role"]
        by_role[role]["folders"] += 1
        by_role[role]["agree"] += row["agree"] == "yes"
        by_role[role]["verdict " + row["verdict"]] += 1
        by_role[role]["head_fresh " + row["head_fresh"]] += 1
        by_role[role]["run_complete " + row["run_complete"]] += 1
        for kind in row["missing_kinds"].split():
            by_role[role]["missing kind " + kind] += 1
        for item in row["classification"].split():
            name, count = item.split("=")
            by_role[role]["class " + name] += int(count)
    lines = ["# Re-verification of the kill-suite folders (build-2 report fields)", "",
             "`reverify_dimensions.py`: the frozen agentgate-verify again, same pins as the suite. "
             "`missing kind` counts Missing entries; `class` counts operations.", ""]
    for role in ["segment1_alone", "run_walk", "single", "as_killed"]:
        if role not in by_role:
            continue
        lines += ["## %s" % role, "", "| measure | count |", "|---|---|"]
        for key in sorted(by_role[role]):
            lines.append("| %s | %d |" % (key, by_role[role][key]))
        lines.append("")
    with open(os.path.join(out_dir, "reverify.md"), "w", encoding="utf-8", newline="\n") as handle:
        handle.write("\n".join(lines))
    print("\n".join(lines))


if __name__ == "__main__":
    main()
