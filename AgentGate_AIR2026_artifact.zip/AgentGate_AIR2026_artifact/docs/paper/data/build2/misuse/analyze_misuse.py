#!/usr/bin/env python3
"""Re-analyse the R6.5 policy-misuse runs (agentgate-eval misuse) from disk.

Inputs
  misuse.json, deny/misuse.json  next to this script (written by agentgate-eval)
  --flag-work DIR, --deny-work DIR  the -work folders of those two runs (evidence
                                    folders misuse-NN/run; kept outside the repo)
  --verify EXE                      optional agentgate-verify binary: every evidence
                                    folder is re-verified by the CLI (no anchors, and
                                    with anchors derived from the folder itself)
  --rep MODE=FILE                   optional repetition misuse.json files (stability)
  --previous MODE=FILE              optional earlier misuse.json (difference list)

Outputs (next to this script)
  misuse_table.csv     one row per request and mode: case, expected, observed,
                       rule(s), harm, status contract fields, provider-journal and
                       audit counts read independently from the evidence folders
  misuse_analysis.json every derived number with its denominator
  cli_crosscheck.csv   CLI verdicts per evidence folder (if --verify)
  repeat_stability.csv observed class per request across repetitions (if --rep)

The provider journal is decoded here with a minimal CBOR reader (COSE_Sign1
payload -> operation_id), independently of the harness's own commit count.
Signatures are not checked here (the verifier does that); this script only
counts.
"""
import argparse
import base64
import csv
import hashlib
import json
import os
import struct
import subprocess
import sys
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))


# --- minimal CBOR ---------------------------------------------------------------
def cbor(b, i=0):
    ib = b[i]
    mt, ai = ib >> 5, ib & 31
    i += 1
    if ai < 24:
        val = ai
    elif ai in (24, 25, 26, 27):
        n = {24: 1, 25: 2, 26: 4, 27: 8}[ai]
        raw = b[i:i + n]
        val = int.from_bytes(raw, "big")
        i += n
    else:
        raise ValueError("indefinite-length CBOR not supported")
    if mt == 0:
        return val, i
    if mt == 1:
        return -1 - val, i
    if mt == 2:
        return bytes(b[i:i + val]), i + val
    if mt == 3:
        return b[i:i + val].decode("utf-8"), i + val
    if mt == 4:
        out = []
        for _ in range(val):
            item, i = cbor(b, i)
            out.append(item)
        return out, i
    if mt == 5:
        out = {}
        for _ in range(val):
            k, i = cbor(b, i)
            v, i = cbor(b, i)
            out[k if not isinstance(k, (list, dict)) else repr(k)] = v
        return out, i
    if mt == 6:
        inner, i = cbor(b, i)
        return ("tag", val, inner), i
    # major type 7
    if ai == 20:
        return False, i
    if ai == 21:
        return True, i
    if ai in (22, 23):
        return None, i
    if ai == 25:
        return ("half", val), i
    if ai == 26:
        return struct.unpack(">f", val.to_bytes(4, "big"))[0], i
    if ai == 27:
        return struct.unpack(">d", val.to_bytes(8, "big"))[0], i
    return ("simple", val), i


def b64url(raw):
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def journal_commits(folder):
    """operation_id (base64url) -> number of provider journal entries."""
    path = os.path.join(folder, "provider-journal.json")
    if not os.path.exists(path):
        return None, []
    journal = json.load(open(path, encoding="utf-8"))
    counts = Counter()
    outcomes = []
    for entry in journal.get("entries", []):
        raw = base64.b64decode(entry["signed_receipt"])
        message, _ = cbor(raw)
        if isinstance(message, tuple) and message[0] == "tag":
            message = message[2]
        payload, _ = cbor(message[2])
        counts[b64url(payload["operation_id"])] += 1
        outcomes.append(payload.get("outcome"))
    return counts, outcomes


def audit_index(folder):
    by_op = defaultdict(list)
    case_id = None
    with open(os.path.join(folder, "audit.jsonl"), encoding="utf-8") as f:
        for line in f:
            entry = json.loads(line)["entry"]
            if entry["stage"] == "RUN_STARTED":
                summary = entry["summary"]
                prefix = "Evaluation run started (misuse case "
                if summary.startswith(prefix):
                    case_id = summary[len(prefix):-2]
            if entry.get("operation_id"):
                by_op[entry["operation_id"]].append(entry)
    return case_id, by_op


RANK = {"DENY": 3, "FLAG": 2, "ESCALATE": 2, "ALLOW_FLAGGED": 2, "ALLOW": 1}


def content_only_outcome(reasons):
    """Most restrictive outcome of the non-DEL rules in a POLICY_DECISION."""
    best = None
    for reason in reasons:
        if reason["rule_id"].startswith("DEL-"):
            continue
        if best is None or RANK.get(reason["outcome"], 0) > RANK.get(best, 0):
            best = reason["outcome"]
    return best


def load(path):
    return json.load(open(path, encoding="utf-8"))


def analyse_mode(mode, result, work):
    folders = {}
    for name in sorted(os.listdir(work)):
        run = os.path.join(work, name, "run")
        if os.path.isdir(run):
            case_id, by_op = audit_index(run)
            folders[case_id] = (name, run, by_op)
    rows = []
    contract = Counter()
    reason_outcomes = Counter()
    for case in result["cases"]:
        name, run, by_op = folders[case["case"]]
        commits, outcomes = journal_commits(run)
        known_ops = set()
        for step in case["steps"]:
            op = step["operation_id"]
            known_ops.add(op)
            r = step["result"]
            entries = by_op.get(op, [])
            stages = [e["stage"] for e in entries]
            decisions = [e for e in entries if e["stage"] == "POLICY_DECISION"]
            reasons = decisions[-1]["details"].get("reasons", []) if decisions else []
            for reason in reasons:
                reason_outcomes[reason["outcome"]] += 1
            deciding = step["deciding_rules"]
            del_rules = [x for x in deciding if x.startswith("DEL-")]
            content_rules = [x for x in deciding if not x.startswith("DEL-")]
            family = ""
            if step["class"] == "blocked":
                family = "both" if del_rules and content_rules else ("delegation (DEL-*) only" if del_rules else "content rules only")
            elif step["class"] == "invalid":
                family = "schema/normalizer (invalid_request)"
            n_commit = commits.get(op, 0) if commits is not None else None
            n_exec = stages.count("EFFECT_EXECUTED")
            row = {
                "mode": mode, "group": step["group"], "case": step["case"], "grant": step["grant"], "step": step["step"],
                "label": step["label"], "tool": step["tool"], "category": step["category"], "expected": step["expected"],
                "observed": step["class"], "matches": step["matches_expectation"], "status": r.get("status", ""),
                "reason": r.get("reason", ""), "dispatched": r.get("dispatched"), "policy_decision": step["policy_decision"],
                "deciding_rules": " ".join(deciding), "fired_rules": " ".join(step["fired_rules"]),
                "content_rules_alone": content_only_outcome(reasons) if reasons else "",
                "blocked_by": family, "harm": step.get("harm", ""),
                "journal_commits": n_commit, "audit_effect_executed": n_exec, "audit_entries": len(entries),
                "audit_stages": " ".join(stages), "committed_so_far": step.get("committed_so_far", ""),
                "folder": name, "evidence_assurance": case["evidence"].get("assurance", ""),
                "policy_replayed": case["evidence"].get("dimensions", {}).get("policy_replayed", ""),
                "delegation_respected": case["evidence"].get("dimensions", {}).get("delegation_respected", ""),
            }
            rows.append(row)
            # status contract (REVISION_CONTRACT R2)
            contract["requests"] += 1
            contract["with_status"] += bool(row["status"])
            if row["status"] == "REJECTED":
                contract["rejected"] += 1
                contract["rejected_dispatched_false"] += row["dispatched"] is False
                contract["rejected_with_effect"] += (n_commit or 0) > 0
                if row["audit_entries"] == 0:
                    contract["rejected_without_audit_entry"] += 1
            if row["status"] == "COMMITTED":
                contract["committed"] += 1
                contract["committed_exactly_one_journal_entry"] += n_commit == 1
                contract["committed_exactly_one_effect_executed"] += n_exec == 1
            if row["status"] not in ("REJECTED", "COMMITTED"):
                contract["other_status"] += 1
            if step["effect_committed"] != ((n_commit or 0) > 0):
                contract["harness_vs_journal_disagree"] += 1
        if commits is not None:
            contract["journal_entries_total"] += sum(commits.values())
            contract["journal_entries_unknown_operation"] += sum(v for k, v in commits.items() if k not in known_ops)
            contract["journal_entries_not_applied"] += sum(1 for o in outcomes if o != "APPLIED")
    return rows, dict(contract), dict(reason_outcomes)


def tallies(rows):
    out = {}
    for category in ("legitimate", "review", "harmful", "malformed"):
        sub = [r for r in rows if r["category"] == category]
        out[category] = {
            "requests": len(sub),
            "by_observed": dict(Counter(r["observed"] for r in sub)),
            "as_specified": sum(r["matches"] for r in sub),
            "effects_committed": sum((r["journal_commits"] or 0) > 0 for r in sub),
        }
    out["total"] = {"requests": len(rows), "by_observed": dict(Counter(r["observed"] for r in rows)),
                    "as_specified": sum(r["matches"] for r in rows),
                    "effects_committed": sum((r["journal_commits"] or 0) > 0 for r in rows)}
    return out


def harm_summary(rows):
    harmful = [r for r in rows if r["category"] == "harmful"]
    granted = [r for r in harmful if r["grant"] != "none"]
    blocked = [r for r in harmful if r["observed"] == "blocked"]
    by_family = Counter(r["blocked_by"] for r in blocked)
    by_rule = Counter()
    for r in blocked:
        for rule in r["deciding_rules"].split():
            by_rule[rule] += 1
    del_only = [r for r in blocked if r["blocked_by"] == "delegation (DEL-*) only"]
    return {
        "harmful_requests": len(harmful),
        "harm": dict(Counter(r["harm"] for r in harmful)),
        "harm_under_a_grant": {"requests": len(granted), **dict(Counter(r["harm"] for r in granted))},
        "blocked_by_family": dict(by_family),
        "blocked_deciding_rule_counts": dict(by_rule),
        "del_only_blocks_content_rules_alone_would_give": dict(Counter(r["content_rules_alone"] for r in del_only)),
        "residual_permitted": [f'{r["case"]} / step {r["step"]} ({r["label"]}) rules {r["deciding_rules"]}' for r in harmful if r["harm"] == "permitted"],
        "flagged_executed": [f'{r["case"]} / step {r["step"]} ({r["label"]}) rules {r["deciding_rules"]}' for r in harmful if r["harm"] == "flagged"],
    }


def other_summaries(rows):
    legit = [r for r in rows if r["category"] == "legitimate"]
    committed = [r for r in rows if r["status"] == "COMMITTED"]
    invalid = [r for r in rows if r["observed"] == "invalid"]
    text = [r for r in rows if r["group"] == "confidential-text"]
    controls = {}
    for case in ("USD budget, 8 x USD 500.00", "USD budget, 8 x USD 500.00, no grant (control)",
                 "5 external releases, MaxCounts 3", "5 external releases, no grant (control)",
                 "AED 60,000.00 split into 12 x 5,000.00"):
        sub = [r for r in rows if r["case"] == case]
        controls[case] = {"requests": len(sub), "committed": sum((r["journal_commits"] or 0) > 0 for r in sub),
                          "observed": [r["observed"] for r in sub],
                          "final_committed_so_far": sub[-1]["committed_so_far"] if sub else ""}
    return {
        "legitimate_incorrectly_blocked": [f'{r["case"]} ({r["deciding_rules"]})' for r in legit if r["observed"] in ("blocked", "invalid")],
        "legitimate_flagged": [f'{r["case"]} ({r["deciding_rules"]})' for r in legit if r["observed"] == "flagged"],
        "committed_effects": len(committed),
        "committed_flagged_without_a_person": {"count": sum(r["observed"] == "flagged" for r in committed),
                                               "by_category": dict(Counter(r["category"] for r in committed if r["observed"] == "flagged"))},
        "invalid_requests": {"count": len(invalid),
                             "with_no_audit_entry": [f'{r["case"]}' for r in invalid if r["audit_entries"] == 0],
                             "with_audit_entries": [f'{r["case"]}: {r["audit_stages"]}' for r in invalid if r["audit_entries"] > 0]},
        "confidential_text": [{"case": r["case"], "category": r["category"], "expected": r["expected"], "observed": r["observed"],
                               "deciding_rules": r["deciding_rules"], "fired_rules": r["fired_rules"],
                               "effect_committed": (r["journal_commits"] or 0) > 0} for r in text],
        "paired_controls": controls,
    }


def evidence_summary(result):
    assurance = Counter(c["evidence"].get("assurance") or ("error: " + c["evidence"].get("error", "")) for c in result["cases"])
    dims = defaultdict(Counter)
    for c in result["cases"]:
        for k, v in c["evidence"].get("dimensions", {}).items():
            dims[k][v] += 1
    return {"folders": len(result["cases"]), "assurance_pinned": dict(assurance), "dimensions": {k: dict(v) for k, v in dims.items()},
            "case_errors": [c["case"] + ": " + c["error"] for c in result["cases"] if c.get("error")]}


def cli_crosscheck(exe, mode, work):
    out = []
    for name in sorted(os.listdir(work)):
        run = os.path.join(work, name, "run")
        if not os.path.isdir(run):
            continue
        keys = hashlib.sha256(open(os.path.join(run, "keys.json"), "rb").read()).hexdigest()
        head = json.load(open(os.path.join(run, "head.json"), encoding="utf-8"))["entry_hash"]
        for anchors, extra in (("none", []), ("self-derived keys+head", ["--expect-keys", keys, "--expect-head", head])):
            proc = subprocess.run([exe, "--json", *extra, run], capture_output=True, text=True)
            try:
                report = json.loads(proc.stdout)
                verdict, assurance = report.get("verdict"), report.get("assurance")
                failures = len(report.get("failures") or [])
                missing = len(report.get("missing") or [])
            except json.JSONDecodeError:
                verdict, assurance, failures, missing = "unparsed", "", -1, -1
            out.append({"mode": mode, "folder": name, "anchors": anchors, "exit": proc.returncode, "verdict": verdict,
                        "assurance": assurance, "failures": failures, "missing": missing})
    return out


def key_of(case, step):
    return f'{case["case"]}#{step["step"]}'


def classes(result):
    return {key_of(c, s): s["class"] for c in result["cases"] for s in c["steps"]}


def write_csv(path, rows):
    if not rows:
        return
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--flag-work", required=True)
    parser.add_argument("--deny-work", required=True)
    parser.add_argument("--verify")
    parser.add_argument("--rep", action="append", default=[])
    parser.add_argument("--previous", action="append", default=[])
    args = parser.parse_args()

    results = {"flag": load(os.path.join(HERE, "misuse.json")), "deny": load(os.path.join(HERE, "deny", "misuse.json"))}
    works = {"flag": args.flag_work, "deny": args.deny_work}
    analysis = {"source": "analyze_misuse.py over misuse.json, deny/misuse.json and the evidence folders of both runs",
                "modes": {}}
    all_rows = []
    for mode in ("flag", "deny"):
        rows, contract, reason_outcomes = analyse_mode(mode, results[mode], works[mode])
        all_rows += rows
        analysis["modes"][mode] = {
            "environment": results[mode]["environment"],
            "cases": len(results[mode]["cases"]),
            "tallies": tallies(rows),
            "harm": harm_summary(rows),
            "other": other_summaries(rows),
            "status_contract": contract,
            "reason_outcome_values_seen": reason_outcomes,
            "evidence": evidence_summary(results[mode]),
            "tool_mismatches": results[mode]["mismatches"],
            "tool_blocked_by": results[mode]["harmful_blocked_by_rule_family"],
        }
    write_csv(os.path.join(HERE, "misuse_table.csv"), all_rows)

    if args.verify:
        cross = cli_crosscheck(args.verify, "flag", works["flag"]) + cli_crosscheck(args.verify, "deny", works["deny"])
        write_csv(os.path.join(HERE, "cli_crosscheck.csv"), cross)
        analysis["cli_crosscheck"] = {f'{m}/{a}': dict(Counter(f'{r["verdict"]}/{r["assurance"]}/exit{r["exit"]}' for r in cross if r["mode"] == m and r["anchors"] == a))
                                      for m in ("flag", "deny") for a in ("none", "self-derived keys+head")}

    if args.rep:
        reps = defaultdict(dict)
        for spec in args.rep:
            mode, path = spec.split("=", 1)
            reps[mode][os.path.basename(os.path.dirname(path)) or path] = classes(load(path))
        stability_rows = []
        analysis["repeat_stability"] = {}
        for mode in ("flag", "deny"):
            main_classes = classes(results[mode])
            identical = 0
            for key, value in main_classes.items():
                row = {"mode": mode, "request": key, "main": value}
                same = True
                for name, cls in sorted(reps[mode].items()):
                    row[name.replace(mode, "").strip("-") or name] = cls.get(key, "")
                    same = same and cls.get(key) == value
                row["identical"] = same
                identical += same
                stability_rows.append(row)
            analysis["repeat_stability"][mode] = {"requests": len(main_classes), "identical_in_all_runs": identical,
                                                  "runs": 1 + len(reps[mode])}
        write_csv(os.path.join(HERE, "repeat_stability.csv"), stability_rows)

    if args.previous:
        analysis["difference_from_previous_run"] = {}
        for spec in args.previous:
            mode, path = spec.split("=", 1)
            before, now = classes(load(path)), classes(results[mode])
            analysis["difference_from_previous_run"][mode] = {
                "requests_compared": len(set(before) & set(now)),
                "changed": [f"{k}: {before[k]} -> {now[k]}" for k in sorted(set(before) & set(now)) if before[k] != now[k]],
                "only_previous": sorted(set(before) - set(now)), "only_now": sorted(set(now) - set(before))}

    with open(os.path.join(HERE, "misuse_analysis.json"), "w", encoding="utf-8") as f:
        json.dump(analysis, f, indent=2, sort_keys=False)
        f.write("\n")
    print(json.dumps({m: {"tallies": v["tallies"], "harm": {k: v["harm"][k] for k in ("harm", "harm_under_a_grant", "blocked_by_family")},
                          "status_contract": v["status_contract"]} for m, v in analysis["modes"].items()}, indent=1))


if __name__ == "__main__":
    sys.exit(main())
