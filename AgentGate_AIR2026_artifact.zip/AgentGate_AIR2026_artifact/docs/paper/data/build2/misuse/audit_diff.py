"""Entry-level comparison of two misuse work folders (previous build vs this build).

For every case folder (matched by the case name in RUN_STARTED), the audit
entries are normalised (IDs, hashes, times, pids, ports, provider references
replaced by placeholders) and compared in order. Prints a census of stages,
of `scope` values and of every differing entry.
usage: python audit_diff.py PREV_WORK NEW_WORK
"""
import json, os, re, sys
from collections import Counter

VOLATILE_KEYS = {"time", "prev_hash", "entry_hash", "signature", "exp", "nbf", "iat", "issued_at", "not_before",
                 "expires_at", "valid_from", "valid_until", "revoked_at", "started_at"}
PATTERNS = [
    (re.compile(r"^[A-Za-z0-9+/=_-]{32,}$"), "<BLOB>"),
    (re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z"), "<TIME>"),
    (re.compile(r"\b[0-9a-f]{16,}\b"), "<HEX>"),
    (re.compile(r"sim-[0-9a-f]+-\d+"), "<SIMREF>"),
    (re.compile(r"pid \d+"), "pid <PID>"),
    (re.compile(r"127\.0\.0\.1:\d+"), "127.0.0.1:<PORT>"),
    (re.compile(r"(?<![A-Za-z0-9_-])[A-Za-z0-9_-]{22}(?![A-Za-z0-9_-])"), "<B64ID>"),
]


def norm(v, key=None):
    if isinstance(v, dict):
        return {k: ("<V>" if k in VOLATILE_KEYS else norm(x, k)) for k, x in sorted(v.items())}
    if isinstance(v, list):
        return [norm(x) for x in v]
    if isinstance(v, str):
        for pat, rep in PATTERNS:
            v = pat.sub(rep, v)
        return v
    return v


def load(work):
    out = {}
    for name in sorted(os.listdir(work)):
        path = os.path.join(work, name, "run", "audit.jsonl")
        if not os.path.exists(path):
            continue
        entries = [json.loads(l)["entry"] for l in open(path, encoding="utf-8")]
        case = entries[0]["summary"]
        out[case] = entries
    return out


def scopes(entries, census):
    def walk(v, stage):
        if isinstance(v, dict):
            for k, x in v.items():
                if k == "scope":
                    census[(stage, json.dumps(x))] += 1
                walk(x, stage)
        elif isinstance(v, list):
            for x in v:
                walk(x, stage)
    for e in entries:
        walk(e, e["stage"])


prev, new = load(sys.argv[1]), load(sys.argv[2])
print("cases: previous %d, this build %d, common %d" % (len(prev), len(new), len(set(prev) & set(new))))
sp, sn = Counter(), Counter()
cp, cn = Counter(), Counter()
diffs = 0
entries_compared = 0
for case in sorted(set(prev) & set(new)):
    a, b = prev[case], new[case]
    cp.update(e["stage"] for e in a)
    cn.update(e["stage"] for e in b)
    scopes(a, sp)
    scopes(b, sn)
    if [e["stage"] for e in a] != [e["stage"] for e in b]:
        diffs += 1
        print("STAGE SEQUENCE DIFFERS:", case, [e["stage"] for e in a], [e["stage"] for e in b])
        continue
    for x, y in zip(a, b):
        entries_compared += 1
        nx, ny = norm(x), norm(y)
        if nx != ny:
            diffs += 1
            keys = sorted(set(nx) | set(ny))
            print("DIFF", case, x["stage"])
            for k in keys:
                if nx.get(k) != ny.get(k):
                    print("   ", k, "\n      prev:", json.dumps(nx.get(k))[:600], "\n      new: ", json.dumps(ny.get(k))[:600])
print("entries compared:", entries_compared, "differing entries/cases:", diffs)
print("stage census identical:", cp == cn, "total entries prev/new:", sum(cp.values()), sum(cn.values()))
print("stage census:", dict(sorted(cn.items())))
print("scope census prev:", dict(sp))
print("scope census new: ", dict(sn))
