#!/usr/bin/env python3
"""Build-2 additions to the R6.5 misuse analysis (analyze_misuse.py is reused unchanged).

What this adds, all written next to this script:
  cli_kinds.csv            one row per evidence folder x anchor condition: the build-2 verifier's
                           new report members (missing_kinds, head_fresh, run_complete,
                           classification_evidence counts, flagged, flagged_unconfirmed)
  build2_comparison.json   build 2 against build 1: step fields, per-case evidence, CLI cross-check,
                           derived numbers, the build-2 verifier on build-1 evidence, new report members
  misuse_category_map.csv  95 rows: every request with its ORIGINAL label (category, expected) and
                           the grouping made after the run by case family (group, subgroup)
  misuse_by_category.csv   the regrouped table (both modes), group and subgroup rows
  misuse_by_category.md    the same as a markdown table

Inputs
  misuse.json, deny/misuse.json, misuse_table.csv, misuse_analysis.json, cli_crosscheck.csv
                           next to this script (build 2; written by agentgate-eval and analyze_misuse.py)
  --build1 DIR             the build-1 result folder (docs/paper/data/revision/misuse)
  --flag-work, --deny-work the build-2 evidence work folders
  --prev-flag-work, --prev-deny-work   the build-1 evidence work folders (optional)
  --verify EXE             the build-2 agentgate-verify binary
No absolute path is written to any output.
"""
import argparse
import csv
import hashlib
import json
import os
import subprocess
from collections import Counter, OrderedDict

HERE = os.path.dirname(os.path.abspath(__file__))
FRESHNESS_PREFIX = "Head not shown to be fresh"


def load(path):
    return json.load(open(path, encoding="utf-8"))


def read_csv(path):
    return list(csv.DictReader(open(path, encoding="utf-8")))


def write_csv(path, rows, fields=None):
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields or list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


# --- verifier runs -------------------------------------------------------------------
def verify_folder(exe, run, anchored):
    extra = []
    if anchored:
        keys = hashlib.sha256(open(os.path.join(run, "keys.json"), "rb").read()).hexdigest()
        head = load(os.path.join(run, "head.json"))["entry_hash"]
        extra = ["--expect-keys", keys, "--expect-head", head]
    proc = subprocess.run([exe, "--json", *extra, run], capture_output=True, text=True)
    report = json.loads(proc.stdout)
    counts = report.get("counts") or {}
    dims = report.get("dimensions") or {}
    kinds = Counter(report.get("missing_kinds") or [])
    return {
        "exit": proc.returncode, "verdict": report.get("verdict"), "assurance": report.get("assurance"),
        "failures": len(report.get("failures") or []), "missing": len(report.get("missing") or []),
        "missing_unresolved": kinds.get("unresolved", 0), "missing_freshness": kinds.get("freshness", 0),
        "missing_issuer_only": kinds.get("issuer_only", 0), "missing_other": kinds.get("other", 0),
        "head_fresh": (dims.get("head_fresh") or {}).get("status", ""),
        "run_complete": (dims.get("run_complete") or {}).get("status", ""),
        "operations": counts.get("operations", 0), "flagged": counts.get("flagged", 0),
        "flagged_unconfirmed": counts.get("flagged_unconfirmed", 0),
        "ce_issuer_adapter": (counts.get("classification_evidence") or {}).get("issuer_adapter", 0),
        "ce_issuer_only_reconciled": (counts.get("classification_evidence") or {}).get("issuer_only_reconciled", 0),
        "ce_issuer_only_unresolved": (counts.get("classification_evidence") or {}).get("issuer_only_unresolved", 0),
        "ce_issuer_only_no_effect": (counts.get("classification_evidence") or {}).get("issuer_only_no_effect", 0),
        "ce_audit_only": (counts.get("classification_evidence") or {}).get("audit_only", 0),
        "_missing_text": report.get("missing") or [],
    }


def verify_work(exe, mode, work):
    rows = []
    for name in sorted(os.listdir(work)):
        run = os.path.join(work, name, "run")
        if not os.path.isdir(run):
            continue
        for label, anchored in (("none", False), ("self-derived keys+head", True)):
            row = {"mode": mode, "folder": name, "anchors": label}
            row.update(verify_folder(exe, run, anchored))
            rows.append(row)
    return rows


def summarise_cli(rows):
    out = OrderedDict()
    for mode in ("flag", "deny"):
        for anchors in ("none", "self-derived keys+head"):
            sub = [r for r in rows if r["mode"] == mode and r["anchors"] == anchors]
            if not sub:
                continue
            missing_texts = Counter(t.split(":")[0] for r in sub for t in r["_missing_text"])
            out[f"{mode}/{anchors}"] = {
                "folders": len(sub),
                "verdicts": dict(Counter(f'{r["verdict"]}/{r["assurance"]}/exit{r["exit"]}' for r in sub)),
                "failures_total": sum(r["failures"] for r in sub),
                "missing_total": sum(r["missing"] for r in sub),
                "missing_by_kind_total": {k: sum(r["missing_" + k] for r in sub) for k in ("unresolved", "freshness", "issuer_only", "other")},
                "missing_entry_heads": dict(missing_texts),
                "head_fresh": dict(Counter(r["head_fresh"] for r in sub)),
                "run_complete": dict(Counter(r["run_complete"] for r in sub)),
                "operations_total": sum(r["operations"] for r in sub),
                "flagged_total": sum(r["flagged"] for r in sub),
                "flagged_unconfirmed_total": sum(r["flagged_unconfirmed"] for r in sub),
                "classification_evidence_total": {k[3:]: sum(r[k] for r in sub) for k in sub[0] if k.startswith("ce_")},
            }
    return out


# --- comparison with build 1 ---------------------------------------------------------
def step_key(case, step):
    return f'{case["case"]}#{step["step"]}'


def strip_step(step):
    s = json.loads(json.dumps(step))
    s.pop("operation_id", None)
    s["result"].pop("provider_reference", None)
    return s


def compare_results(b1, b2):
    steps1 = {step_key(c, s): strip_step(s) for c in b1["cases"] for s in c["steps"]}
    steps2 = {step_key(c, s): strip_step(s) for c in b2["cases"] for s in c["steps"]}
    step_diffs = []
    for k in sorted(set(steps1) & set(steps2)):
        if steps1[k] != steps2[k]:
            fields = sorted(f for f in set(steps1[k]) | set(steps2[k]) if steps1[k].get(f) != steps2[k].get(f))
            step_diffs.append(f"{k}: {fields}")
    ev_diffs, new_dims, missing_extra = [], Counter(), Counter()
    cases1 = {c["case"]: c for c in b1["cases"]}
    for c2 in b2["cases"]:
        c1 = cases1.get(c2["case"])
        if c1 is None:
            ev_diffs.append(f'{c2["case"]}: only in build 2')
            continue
        e1, e2 = c1["evidence"], c2["evidence"]
        for field in ("verdict", "assurance", "failing_checks", "findings", "entries", "operations", "anchors"):
            if e1.get(field) != e2.get(field):
                ev_diffs.append(f'{c2["case"]}: {field} {e1.get(field)} -> {e2.get(field)}')
        d1, d2 = e1.get("dimensions", {}), e2.get("dimensions", {})
        for name in d1:
            if d1[name] != d2.get(name):
                ev_diffs.append(f'{c2["case"]}: dimension {name} {d1[name]} -> {d2.get(name)}')
        for name in set(d2) - set(d1):
            new_dims[f"{name}={d2[name]}"] += 1
        m1 = list(e1.get("missing", []))
        m2 = list(e2.get("missing", []))
        m2_without_fresh = [m for m in m2 if not m.startswith(FRESHNESS_PREFIX)]
        if m1 != m2_without_fresh:
            ev_diffs.append(f'{c2["case"]}: missing (freshness entry excluded) differs')
        for m in m2:
            if m not in m1:
                missing_extra[m.split(":")[0]] += 1
    top = {}
    for field in ("note", "method", "escalation", "tallies", "harmful_blocked_by_rule_family", "mismatches",
                  "evidence_assurance_counts", "policy_replayed_dimension"):
        top[field] = "same" if b1.get(field) == b2.get(field) else "DIFFERENT"
    return {
        "steps_compared": len(set(steps1) & set(steps2)),
        "steps_only_build1": sorted(set(steps1) - set(steps2)), "steps_only_build2": sorted(set(steps2) - set(steps1)),
        "steps_differing_except_operation_id_and_provider_reference": step_diffs,
        "cases_compared": len(b2["cases"]),
        "evidence_differences_on_build1_fields": ev_diffs,
        "evidence_new_dimensions": dict(new_dims),
        "evidence_missing_entries_new_in_build2": dict(missing_extra),
        "top_level_fields": top,
    }


def compare_cli(b1_rows, b2_rows):
    k = lambda r: (r["mode"], r["folder"], r["anchors"])
    a = {k(r): r for r in b1_rows}
    b = {k(r): r for r in b2_rows}
    same, diffs = 0, Counter()
    for key in sorted(set(a) & set(b)):
        x, y = a[key], b[key]
        if all(x[f] == y[f] for f in ("exit", "verdict", "assurance", "failures", "missing")):
            same += 1
        else:
            changed = tuple(f for f in ("exit", "verdict", "assurance", "failures", "missing") if x[f] != y[f])
            detail = ",".join(f"{f} {x[f]}->{y[f]}" for f in changed)
            diffs[f"{key[0]}/{key[2]}: {detail}"] += 1
    return {"rows_compared": len(set(a) & set(b)), "identical_on_all_fields": same, "differences": dict(diffs)}


def strip_new_dims(evidence):
    e = json.loads(json.dumps(evidence))
    for name in ("head_fresh", "run_complete"):
        e.get("dimensions", {}).pop(name, None)
    return e


def compare_analysis(a1, a2):
    out = {}
    for mode in ("flag", "deny"):
        m1, m2 = a1["modes"][mode], a2["modes"][mode]
        res = {}
        for field in ("cases", "tallies", "harm", "other", "status_contract", "reason_outcome_values_seen",
                      "tool_mismatches", "tool_blocked_by"):
            res[field] = "identical" if m1[field] == m2[field] else "DIFFERENT"
        res["evidence (head_fresh and run_complete removed)"] = "identical" if m1["evidence"] == strip_new_dims(m2["evidence"]) else "DIFFERENT"
        res["evidence new dimensions"] = {k: v for k, v in m2["evidence"]["dimensions"].items() if k in ("head_fresh", "run_complete")}
        env1, env2 = m1["environment"], m2["environment"]
        res["environment fields that differ"] = sorted(k for k in set(env1) | set(env2) if env1.get(k) != env2.get(k))
        out[mode] = res
    out["repeat_stability"] = {"build1": a1.get("repeat_stability"), "build2": a2.get("repeat_stability")}
    out["cli_crosscheck_summary"] = {"build1": a1.get("cli_crosscheck"), "build2": a2.get("cli_crosscheck")}
    return out


# --- regrouping by case family (made after the run) ---------------------------------
GROUPS = [
    ("legitimate", "legitimate (original label)"),
    ("for review", "review (original label)"),
    ("harmful: what the policy is built to stop", "original label harmful"),
    ("harmful: policy-compliant harm", "original label harmful"),
    ("harmful: no-grant controls", "original label harmful"),
    ("malformed", "malformed (original label)"),
]


def regroup(row):
    """(group, subgroup) for one request; reads only the case family and the original label."""
    cat, group, case, grant = row["category"], row["group"], row["case"], row["grant"]
    if cat == "legitimate":
        return "legitimate", ("no-grant control cases, steps inside the amounts and counts a grant would allow" if grant == "none"
                              else "all other legitimate requests")
    if cat == "review":
        return "for review", ""
    if cat == "malformed":
        return "malformed", ""
    # original label harmful
    if grant == "none":
        return "harmful: no-grant controls", ("USD budget control (USD 500.00 #7, #8 without a grant)" if group == "split"
                                              else "release count control (releases #4, #5 without a grant)")
    if group == "split" and case.startswith("AED 60,000.00") and row["label"] != "AED 60,000.00 in one request":
        return "harmful: policy-compliant harm", "split payment within the budget (12 x AED 5,000.00)"
    if group == "scope" and case == "catalog payee, wrong purpose":
        return "harmful: policy-compliant harm", "wrong purpose (catalog payee, in scope)"
    if group == "confidential-text" and case in ("11 words, external", "one word in six replaced, external", "paraphrase, external"):
        return "harmful: policy-compliant harm", "confidential paraphrase or near-copy (only the generic external-message flag)"
    sub = {
        "boundary": "amount limits and currency (hard limit + 1 x2, 2^53 - 1 x2, EUR, AED 60,000.00 in one request)",
        "split": ("amount limits and currency (hard limit + 1 x2, 2^53 - 1 x2, EUR, AED 60,000.00 in one request)" if row["label"] == "AED 60,000.00 in one request"
                  else "delegated budget (USD 500.00 #7, #8)"),
        "releases": "delegated count (releases #4, #5 with MaxCount 3)",
        "documents": "document classification (confidential external, restricted internal)",
        "confidential-text": "verbatim confidential text (12-word shingles)",
        "scope": "grant scope (payee, recipient, effect type not delegated)",
        "revocation": "revocation",
        "window": "grant validity window (not yet valid, expired)",
    }[group]
    return "harmful: what the policy is built to stop", sub


def regrouped_tables(rows):
    by_req = {}
    for r in rows:
        by_req.setdefault((r["case"], r["step"]), {})[r["mode"]] = r
    mapping = []
    for (case, step), modes in by_req.items():
        f, d = modes["flag"], modes["deny"]
        group, sub = regroup(f)
        assert regroup(d) == (group, sub)
        mapping.append({"group_after_run": group, "subgroup_after_run": sub, "case_family": f["group"], "case": case,
                        "step": step, "label": f["label"], "grant": f["grant"], "original_category": f["category"],
                        "expected_flag": f["expected"], "expected_deny": d["expected"],
                        "observed_flag": f["observed"], "observed_deny": d["observed"],
                        "deciding_rules_flag": f["deciding_rules"], "deciding_rules_deny": d["deciding_rules"],
                        "effect_committed_flag": int(f["journal_commits"] or 0) > 0,
                        "effect_committed_deny": int(d["journal_commits"] or 0) > 0})

    def tally(sub):
        c_f = Counter(m["observed_flag"] for m in sub)
        c_d = Counter(m["observed_deny"] for m in sub)
        return {
            "requests": len(sub),
            "original_labels": " ".join(f"{k} {v}" for k, v in sorted(Counter(m["original_category"] for m in sub).items())),
            "flag_blocked": c_f.get("blocked", 0), "flag_flagged": c_f.get("flagged", 0),
            "flag_permitted": c_f.get("permitted", 0), "flag_invalid": c_f.get("invalid", 0),
            "deny_blocked": c_d.get("blocked", 0), "deny_flagged": c_d.get("flagged", 0),
            "deny_permitted": c_d.get("permitted", 0), "deny_invalid": c_d.get("invalid", 0),
            "effects_committed_flag": sum(m["effect_committed_flag"] for m in sub),
            "effects_committed_deny": sum(m["effect_committed_deny"] for m in sub),
            "as_specified_flag": sum(m["expected_flag"] == m["observed_flag"] for m in sub),
            "as_specified_deny": sum(m["expected_deny"] == m["observed_deny"] for m in sub),
        }

    table = []
    for group, _ in GROUPS:
        sub = [m for m in mapping if m["group_after_run"] == group]
        table.append({"level": "group", "group_after_run": group, "subgroup_after_run": "", **tally(sub)})
        subs = OrderedDict()
        for m in sub:
            subs.setdefault(m["subgroup_after_run"], []).append(m)
        if len(subs) > 1:
            for name, members in subs.items():
                table.append({"level": "subgroup", "group_after_run": group, "subgroup_after_run": name, **tally(members)})
    harmful = [m for m in mapping if m["original_category"] == "harmful"]
    table.append({"level": "total", "group_after_run": "harmful (original label), all three groups", "subgroup_after_run": "", **tally(harmful)})
    table.append({"level": "total", "group_after_run": "all requests", "subgroup_after_run": "", **tally(mapping)})
    return mapping, table


def markdown(table):
    lines = [
        "# Misuse requests regrouped by case family (made after the run)",
        "",
        "Grouping made **after the run**, by case family (the case definitions in",
        "`cmd/agentgate-eval/misuse.go`); the original labels (`category`, `expected`) are unchanged and",
        "every request keeps them (`misuse_category_map.csv`). Build 2, 95 requests per mode.",
        "Flag: blocked / flagged / permitted / invalid. Deny: blocked / permitted / invalid.",
        "",
        "| group (after the run) | n | original label | flag: B / F / P / I | deny: B / P / I | effects committed (flag / deny) | as specified (flag / deny) |",
        "|---|---|---|---|---|---|---|",
    ]
    for r in table:
        name = r["group_after_run"] if r["level"] != "subgroup" else "&nbsp;&nbsp;- " + r["subgroup_after_run"]
        if r["level"] in ("group", "total"):
            name = f"**{name}**"
        lines.append(f'| {name} | {r["requests"]} | {r["original_labels"]} | '
                     f'{r["flag_blocked"]} / {r["flag_flagged"]} / {r["flag_permitted"]} / {r["flag_invalid"]} | '
                     f'{r["deny_blocked"]} / {r["deny_permitted"]} / {r["deny_invalid"]} | '
                     f'{r["effects_committed_flag"]} / {r["effects_committed_deny"]} | '
                     f'{r["as_specified_flag"]}/{r["requests"]} / {r["as_specified_deny"]}/{r["requests"]} |')
    lines += [
        "",
        "Notes. The no-grant control cases have 13 requests: the 4 labelled harmful form the",
        "\"no-grant controls\" group; their 9 earlier steps (inside the amounts and counts the grant",
        "would have allowed) keep their original label legitimate and stay in that group. FIN-ZERO",
        "(amount 0, 2 requests) is labelled malformed and blocked by policy, not invalid. \"Flagged\"",
        "means executed with a flag. In deny mode the 3 paraphrase or near-copy messages are blocked only",
        "because deny mode refuses every external message (MSG-EXTERNAL), not because their content was seen.",
        "Thresholds (AED 5,000.00 / 50,000.00, USD 1,500.00 / 15,000.00,",
        "grant budgets AED 100,000.00 and USD 3,000.00, MaxCount 3 or 10 releases) are illustrative",
        "parameters of a fictitious organisation chosen to place boundary values, not recommendations.",
        "",
    ]
    return "\n".join(lines)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--build1", required=True)
    p.add_argument("--flag-work", required=True)
    p.add_argument("--deny-work", required=True)
    p.add_argument("--prev-flag-work")
    p.add_argument("--prev-deny-work")
    p.add_argument("--verify", required=True)
    args = p.parse_args()

    b2 = {"flag": load(os.path.join(HERE, "misuse.json")), "deny": load(os.path.join(HERE, "deny", "misuse.json"))}
    b1 = {"flag": load(os.path.join(args.build1, "misuse.json")), "deny": load(os.path.join(args.build1, "deny", "misuse.json"))}
    comparison = OrderedDict()
    comparison["source"] = "build2_extras.py over the build-2 and build-1 results and evidence folders"
    comparison["results_json"] = {m: compare_results(b1[m], b2[m]) for m in ("flag", "deny")}
    comparison["cli_crosscheck"] = compare_cli(read_csv(os.path.join(args.build1, "cli_crosscheck.csv")),
                                               read_csv(os.path.join(HERE, "cli_crosscheck.csv")))
    comparison["analysis"] = compare_analysis(load(os.path.join(args.build1, "misuse_analysis.json")),
                                              load(os.path.join(HERE, "misuse_analysis.json")))

    cli = verify_work(args.verify, "flag", args.flag_work) + verify_work(args.verify, "deny", args.deny_work)
    write_csv(os.path.join(HERE, "cli_kinds.csv"), [{k: v for k, v in r.items() if not k.startswith("_")} for r in cli])
    comparison["build2_evidence_build2_verifier"] = summarise_cli(cli)
    if args.prev_flag_work and args.prev_deny_work:
        prev = verify_work(args.verify, "flag", args.prev_flag_work) + verify_work(args.verify, "deny", args.prev_deny_work)
        comparison["build1_evidence_build2_verifier"] = summarise_cli(prev)

    rows = read_csv(os.path.join(HERE, "misuse_table.csv"))
    mapping, table = regrouped_tables(rows)
    write_csv(os.path.join(HERE, "misuse_category_map.csv"), mapping)
    write_csv(os.path.join(HERE, "misuse_by_category.csv"), table)
    open(os.path.join(HERE, "misuse_by_category.md"), "w", encoding="utf-8").write(markdown(table))
    groups = {r["group_after_run"]: r["requests"] for r in table if r["level"] == "group"}
    harmful = sum(v for k, v in groups.items() if k.startswith("harmful"))
    comparison["regrouping_check"] = {"groups": groups, "harmful_sum": harmful, "total_sum": sum(groups.values())}
    assert harmful == 44 and sum(groups.values()) == 95, comparison["regrouping_check"]

    with open(os.path.join(HERE, "build2_comparison.json"), "w", encoding="utf-8") as f:
        json.dump(comparison, f, indent=2)
        f.write("\n")
    print(json.dumps(comparison, indent=1)[:12000])


if __name__ == "__main__":
    main()
