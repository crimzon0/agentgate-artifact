# Verifier robustness (R6.7) on build 2

This is the rerun for the reply to the supervisor's second review. It uses
**build 2**: the frozen binaries of 2026-10-10 02:24:44 UTC, built from commit
`86643d7` of branch `claude/supervisor-demo`. The source copy was taken at
02:29:21 UTC. Fuzzing ran 02:31-02:42, coverage 02:42-02:45 and mutation
02:45-04:00 UTC.

The method is build 1's
(`docs/paper/data/revision/robustness/RESULTS.md`, the single build of
2026-10-08): the same commands, settings, repetitions and analysis scripts.
Section 1 lists the differences. The held-out mutation operators were **not**
run; another agent runs them later.

**Headline.**
- **Fuzzing:** 0 crashers or property failures in **34,178,449** executions
  over 5 runs.
- **Refusal sites:** 142, as expected.
- **Mutation, full suite:** 142/142 killed (1.000).
- **Mutation, honest score:** **56/142 = 0.394** with the seven post-hoc tests
  of `VERIFIER_CHECKS.md` §6 left out. With build 1's four-test pattern the
  score is 58/142 = 0.408 (build 1: 51/139 = 0.367).
- **Never executed:** **47 of 313** refusal conditions are executed by neither
  the tests nor the fuzz inputs. All 47 are `problem` lines.
- **Statement coverage, full suite:** 3,703/4,085 (90.6 %).
- **Nothing got worse.** Every refusal site has the same result as in build 1
  under the full suite. Every condition that some build-1 suite variant
  executed is still executed by the same variant. The score went up because
  tests added on 2026-10-10 kill 5 more sites (section 5).

## 1. Method

- **Frozen binaries.** These are the six build-2 binaries. Their SHA-256 and
  those of the 1,862 compiled source files were checked with
  `py <singlebuild2>/check_manifest.py` before the runs (02:26:57 UTC) and
  after them (04:03:38 UTC). Both times: "checked 1868 files, 0 differ".
  The binaries were not rebuilt and are not run by this experiment. Fuzzing,
  coverage and mutation need test builds of the verifier, which no frozen
  binary contains (`build-manifest.txt`).
- **Frozen source.** A copy of HEAD `86643d7` (the copied paths are clean in
  git), 94 files, hashes in `raw/snapshot_manifest.sha256`. **This differs
  from build 1**, which copied 57 files: build 2's verifier tests import
  `internal/evalattack` (`keysets_extra_test.go`, `lifecycle_test.go`), so
  that package and its dependencies `internal/audit` and `internal/canon`
  are copied too. The 33 copied files that are compiled into a frozen binary
  match `MANIFEST.txt` exactly. After the runs, the copy and the live tree
  were still identical to the snapshot.
- **Build.** Go 1.26.6 offline, fresh build cache, the same four commands as
  build 1. A verifier built from the copy differs from the frozen one only
  in its VCS stamp. Tool hashes are in `build-manifest.txt`.
- **Starting suite.** The verifier packages (`internal/auditverify` and
  `cmd/agentgate-verify`, the two build 1 counted) have 144 top-level tests:
  141 tests and 3 fuzz targets run on their seeds. They give 589 passes
  including subtests, 0 failures and 0 skips. `tools/refusalmutation` now
  has its own 14 tests (all pass). The same `./internal/auditverify/...`
  pattern runs them, so they also run against every mutant, but they cannot
  kill one: they read the unmutated files from disk (caveats).
- **Post-hoc tests.** There are seven (98 cases); §6 of
  `VERIFIER_CHECKS.md` defines them:
  - build 1's four: `TestRefusalSites` (66 cases), `TestDelegationRefusalSites`
    (12), `TestRestartProviderJournalCutBack` (1),
    `TestRestartContinuationRemovedFromRunRecord` (1);
  - three written on 2026-10-10 together with the new sites:
    `TestRecoveryRecordsStateTheBoundFlag` (7),
    `TestReconciledAdapterReceipt` (5),
    `TestReplayedAndConfirmingAnswersStateTheBoundFlag` (6).
- **Fuzzing.** Same as build 1: 120 s per run, 12 workers, each run starting
  from the seed inputs only, `GODEBUG=fuzzdebug=1`.
- **Refusal-site mutation.** The tool is
  `internal/auditverify/tools/refusalmutation` with `-operator fail` (the
  default, build 1's only operator). It makes one mutant per `X.fail(...)`
  site and runs the suites against each with `go test -overlay`: 6 mutants in
  parallel, 5-minute limit per mutant. Six suite variants
  (`scripts/skip_patterns.sh`):
  - `full`;
  - `without_posthoc`: the seven post-hoc tests left out (build 2's honest
    score);
  - `without_posthoc4`: build 1's four-test pattern, for comparison;
  - `without_refusal_site_tests` and `without_restart_tests`: build 1's third
    and fourth variants;
  - `without_posthoc_strict` (**supplementary**): the seven plus
    `TestLifecycleConflictingHistories`, the "stricter variant" that §6
    mentions.
- **Coverage.** `-covermode=set` over `internal/auditverify`, for the full
  suite and each of the five skip patterns, plus the seed and generated fuzz
  corpora. Build 1's scripts were used, extended to the extra variants. The
  denominator is 4,085 statements (fixture and tools excluded).
- **Supplementary (new in build 2).**
  - The mutation tool records only the first `--- FAIL` line. For the 3 new
    sites and the 4 sites whose result changed,
    `scripts/attribute_kills.py` re-ran each mutant once and listed every
    failing test (`kill_attribution_*.json`). It reproduced the tool's
    killed/survived result in all 10 runs.
  - One coverage probe (`raw/coverage/probe_replay395.txt`).
- **Order and load.** The steps ran one after another. Other build-2
  experiments (compromise, crash, concurrency, misuse, custody) ran during
  the fuzz window (`raw/fuzz/concurrent_*.txt`). None was seen at the start
  of any mutation variant. No elapsed time here is a performance result.
- **Sanitising.** In every file of this folder, paths are replaced by
  `<repo>`, `<scratch>`, `<singlebuild2>` and `<temp>`, the machine name by
  `review-host` and the user name by `user` (`scripts/sanitize.py`). The
  tarballs were written without owner names.

Commands, with REPO = `<repo>`, E = `<scratch>/build2-work/robustness`,
SB = `<singlebuild2>` and OUT = this folder:

```
py <singlebuild2>/check_manifest.py                         # before
bash scripts/snapshot.sh; bash scripts/build_tools.sh; bash scripts/baseline.sh
bash scripts/run_fuzz.sh FuzzParseLogLine FuzzCOSE FuzzRunFiles FuzzRunFiles-min5s FuzzRunFiles-nomin
bash scripts/run_cover.sh
bash scripts/run_mutation.sh full without_posthoc without_posthoc4 without_refusal_site_tests without_restart_tests without_posthoc_strict
#   (scripts/chain.sh ran cover and mutation after the fuzz runs; each mutant:
#    refusalmutation.exe -go $GO -operator fail -skip "<pattern>" -out $E/mut/kill_score_<variant>.json)
python scripts/parse_fuzz.py $E $OUT;  python scripts/cover_merge.py $E $OUT
python scripts/refusal_conditions.py $E $OUT;  python scripts/summarize_mutation.py $E $OUT
python scripts/compare_previous.py $OUT <repo>/docs/paper/data/revision/robustness
python scripts/check_counts.py $E $OUT;  python scripts/robustness_tests.py $E/raw/tests_v.txt $OUT/robustness_tests.csv
python scripts/test_counts.py $E/raw/tests_v.txt $OUT/test_counts.json
python scripts/attribute_kills.py $E $E/raw/fail_sites_list.json $OUT/kill_attribution_without_posthoc.json "<7-test pattern>" <7 site ids>
python scripts/attribute_kills.py $E $E/raw/fail_sites_list.json $OUT/kill_attribution_full.json "" <3 new site ids>
bash scripts/post_check.sh;  py <singlebuild2>/check_manifest.py   # after
```

## 2. Fuzzing

| run | executions | inputs found | coverage bits (start → end) | machine CPU (mean) |
|---|---|---|---|---|
| FuzzParseLogLine | 15,781,402 | 91 | 1,861 → 2,550 | 99.3 % |
| FuzzCOSE | 18,383,289 | 348 | 1,785 → 4,297 | 100.0 % |
| FuzzRunFiles (default 60 s minimisation) | 41 | 12 | 5,052 → 7,078 | 99.9 % |
| FuzzRunFiles, `-fuzzminimizetime=5s` | 1,362 | 228 | 4,994 → 11,334 | 99.4 % |
| FuzzRunFiles, `-fuzzminimizetime=0s` | 12,355 | 804 | 4,997 → 15,220 | 93.6 % |

- **0 crashers and 0 property failures** in all 5 runs (34,178,449
  executions). Every run exited 0 and Go wrote no `testdata/fuzz` file.
- The 1,483 generated inputs and the 150 seeds were replayed through the
  coverage test binary: 0 failures.
- The small runs' inputs are in `raw/fuzz/generated_corpus_small_runs.tar.gz`.
  The 5 s and 0 s FuzzRunFiles inputs (2.1 MB and 15.2 MB archived) are kept
  outside the repository; their SHA-256 are in `build-manifest.txt`.

## 3. Coverage and refusal conditions

| suite | statements covered (of 4,085) |
|---|---|
| full suite | 3,703 (90.6 %) |
| **without the seven post-hoc tests** | **3,571 (87.4 %)** |
| without build 1's four post-hoc tests | 3,602 (88.2 %) |
| without only `TestRefusalSites` and `TestDelegationRefusalSites` | 3,605 (88.2 %) |
| without only the two restart tests | 3,700 (90.6 %) |
| without the seven and `TestLifecycleConflictingHistories` (supplementary) | 3,554 (87.0 %) |
| all generated fuzz inputs | 2,601 (63.7 %); 58 statements (1.4 %) are reached by the fuzz inputs but not by the suite |
| suite or fuzz inputs | 3,761 (92.1 %) |

- Lowest per-file coverage by the suite: `replay.go` 76.7 % (168/219).
- The new file `freshness.go` is at 95.3 % (61/64). `witness.go` is at
  95.4 % (125/131), and 130/131 with the fuzz inputs.

**Refusal conditions.** As in build 1, a refusal condition is a line that
calls `fail`, calls `warn`, or appends to `problems`/`warnings`. It counts
as executed when its coverage block ran. There are **313**: 142 `fail`,
7 `warn` and 164 `problem`.

- Executed by the full suite: 256/313 (fail 142/142, warn 7/7, problem
  107/164).
- Without the seven post-hoc tests: 199/313. **57 conditions (42 fail,
  15 problem) are executed only by the post-hoc tests.** With build 1's
  four-test pattern the count is 48 (40 fail, 8 problem); build 1 had 52
  (43, 9).
- Reached only by fuzz inputs: 10 (all `problem` lines).
- **Never executed by tests or fuzzing: 47/313 (15.0 %), all `problem`
  lines.** Each one feeds a `fail` call that other inputs reach, so every
  check can fail; these particular reasons for failing are untested. Lines
  are build 2's. **+** marks a condition new in build 2. **†** marks one that
  only fuzz inputs reached in build 1 and that this run's fuzz inputs did
  not reach.

| file (function) | lines | condition never executed |
|---|---|---|
| `operations.go` (`requirePolicy`) | 438 † | the last POLICY_FINAL is older than the decision it should confirm |
| `operations.go` (`stateProblems`) | 612, 615, 618 | the signed approval request names another operation; another action; a policy decision not recorded for the operation |
| `operations.go` (`decisionProblems`) | 630, 633, 636, 640, 643, 646, 649 | the human decision names another operation; another action; an unrecorded policy decision; a different decision than the approval request; answers a different approval request; is bound to a different signed request; decision time outside the approval window |
| `operations.go` (`checkCapability`) | 727, 747 | capability audience is not the effect type's adapter; validity window not short-lived |
| `operations.go` (`checkApprovalForCapability`) | 783 | capability issued after the approval expired |
| `operations.go` (`checkReceipts`) | 811, 835, 845 | unreadable provider receipt payload; unreadable adapter receipt payload; adapter receipt for another effect type |
| `operations.go` (`checkReconciledReceipt`) | 902 +, 911 +, 914 +, 921 + | the adapter receipt attached to RECONCILED is unreadable; is for another effect type; reports an outcome other than APPLIED; no verified CAPABILITY_ISSUED precedes it |
| `replay.go` (`checkRecipients`) | 82, 84 | recipient not in the catalog snapshot; recipient's external flag differs |
| `replay.go` (`evaluateMessage`) | 109 | attachment not in the snapshot |
| `replay.go` (`evaluateDocument`) | 153, 155, 178 | document classification differs; document not in the snapshot; unknown classification |
| `delegation.go` (`readGrant`) | 292, 310, 314 | grant for another tenant; a second, different grant in one run; an entry naming another grant ID |
| `delegation.go` (`accountingProblems`) | 937 | a logged block records no total for the action |
| `delegation.go` (`checkScope`) | 964, 971 | effect type not in the grant; recipient not in the grant |
| `segments.go` (`checkContinuity`) | 315, 317, 319 | unusable continuation record in run.json; no RUN_STARTED recording the continuation; RUN_STARTED records none |
| `segments.go` (`previousSegmentProblems`) | 347, 352, 360 | the earlier folder holds another run; its log has no readable last entry; its keys.json is unavailable |
| `reconcile.go` (`checkReconciled`) | 108, 118, 129 | names no stored provider receipt; outcome neither committed nor not_committed; receipt differs from the one the observation names |
| `verify.go` (`checkSegmentLog`) | 860, 867 | a segment's log does not start at entry #1; its first `prev_hash` is not the all-zero start value |
| `decisions.go` (`finalDetailProblems`) | 429 | POLICY_FINAL records an overlay root its decision value does not bind |
| `provider.go` (`checkProviderStateChain`) | 210 | a journal receipt whose outcome is not applied |
| `witness.go` (`readWitness`) | 249 † | the witness public key embedded in the head is not the given witness key |

By file: `operations.go` 21 (10 of them in the human-approval binding),
`replay.go` 6, `delegation.go` 6, `segments.go` 6, `reconcile.go` 3,
`verify.go` 2, and `decisions.go`, `provider.go` and `witness.go` 1 each.
In build 1, `replay.go` had 7; line 395 is now executed (section 5).

## 4. Refusal-site mutation

| test suite | killed | kill score | survivors (executed / not executed by that suite) | build errors | timeouts |
|---|---|---|---|---|---|
| full | 142/142 | 1.000 | 0 | 0 | 0 |
| **without the 7 post-hoc tests** (`VERIFIER_CHECKS.md` §6) | **56/142** | **0.394** | 86 (44 / 42) | 0 | 0 |
| without build 1's 4 post-hoc tests | 58/142 | 0.408 | 84 (44 / 40) | 0 | 0 |
| without only `TestRefusalSites`, `TestDelegationRefusalSites` | 60/142 | 0.423 | 82 (44 / 38) | 0 | 0 |
| without only the 2 restart tests | 140/142 | 0.986 | 2 (0 / 2) | 0 | 0 |
| without the 7 and `TestLifecycleConflictingHistories` (supplementary) | 53/142 | 0.373 | 89 (45 / 44) | 0 | 0 |

Skip patterns: `scripts/skip_patterns.sh` and `run_manifest.json`. The
seven-test pattern is the one §6 prints:
`^(TestRefusalSites|TestDelegationRefusalSites|TestRestartProviderJournalCutBack|TestRestartContinuationRemovedFromRunRecord|TestRecoveryRecordsStateTheBoundFlag|TestReconciledAdapterReceipt|TestReplayedAndConfirmingAnswersStateTheBoundFlag)$`.

- **Sites: 142** (build 1: 139). The three new `fail` sites were all added on
  2026-10-10. The attribution re-runs confirm the §6 statements for the last
  two, but not fully for the first:
  - `operations.go:498`, `checkReconciledFlag`, `op.requires_policy` (the
    flag on recovery records). Against the full suite it is killed by
    `TestRecoveryRecordsStateTheBoundFlag`, `TestLifecycleConflictingHistories`
    **and `TestUnboundFlagsTextsNameTheLogNotTheCapability`**. §6 names only
    the first two (open issue 1). As a result it is also killed in the
    honest and strict variants.
  - `operations.go:935`, `checkReconciledReceipt`, `op.receipts_bound` (the
    adapter receipt attached to RECONCILED). Killed only by
    `TestReconciledAdapterReceipt`, so it survives without the post-hoc
    tests.
  - `operations.go:517`, `checkReplayedFlag`, `op.requires_policy` (the
    flag on replayed COMMITTED answers). Killed only by
    `TestReplayedAndConfirmingAnswersStateTheBoundFlag`, so it survives
    without the post-hoc tests.
- **The 86 survivors without the seven post-hoc tests**, by file: `verify.go`
  37, `operations.go` 13, `provider.go` 13, `delegation.go` 11, `files.go` 6,
  `replay.go` 2, `witness.go` 2 (`keys.anchor` line 394, `head.anchor` line
  410, the same as in build 1), `reconcile.go` 1 and `segments.go` 1.
- **7 of 38 checks have no site killed without the seven post-hoc tests**
  (build 1: 9): `artifact.effect_digest`, `artifact.effect_readable`,
  `delegation.window`, `files.run_id`, `head.signature`,
  `op.requires_validation`, `provider.signature`. `chain.time` and
  `op.single_use` now have kills (section 5). In the strict variant
  `op.single_use` loses its kills again, giving 8.
- **Without only the two restart tests**, the same two sites survive as in
  build 1, at the same lines: `provider.go:150` (journal cut back) and
  `segments.go:308` (continuation removed from run.json).
- **Witness sites.** `head.witness` (`witness.go:214`) and the
  withheld-segment site in `head.anchor` (`witness.go:415`) are killed in
  all six variants, as in build 1.

**Check counts:** 38 check IDs in 6 groups: run files 8, log integrity 8,
signed artifacts 3, authorization chain 7, policy and delegation 8, provider
reconciliation 4. `checks.go` and `VERIFIER_CHECKS.md` list the same set
(`check_counts.json`). This is unchanged. The new `head_fresh` and
`run_complete` are report dimensions, not check IDs.

**Parser-robustness tests** (the R3 list): 37/37 pass, and the list of cases
is identical to build 1's (`robustness_tests.csv`).

## 5. Comparison with build 1

Conditions and sites are matched by file, function, kind and source text,
because line numbers moved (`comparison_with_build1.json`). All 299 build-1
conditions and all 139 build-1 sites have a counterpart, and none was removed.

| measurement | build 1 (2026-10-08) | build 2 (2026-10-10) | why it differs |
|---|---|---|---|
| fuzz crashers / property failures | 0 in 40,542,369 executions | 0 in 34,178,449 executions | Execution counts depend on machine load and the random search. CPU was at 93.6-100 % with other build-2 runs active. This is not a build effect. |
| refusal sites; full suite | 139/139 = 1.000 | 142/142 = 1.000 | Three new `fail` sites (section 4). All 139 matched sites have the same result. |
| **honest score** | **51/139 = 0.367** (4-test pattern) | **56/142 = 0.394** (7-test pattern) | +5 kills (see below). Of the new sites, 1 is killed and 2 survive. |
| same 4-test pattern | 51/139 = 0.367 | 58/142 = 0.408 | Under this pattern the two new sites killed only by their own tests count as killed. |
| without only the 2 doc-named tests | 53/139 = 0.381 | 60/142 = 0.423 | Same +4 matched sites, plus all 3 new sites (their tests are not skipped). |
| without only the 2 restart tests | 137/139 = 0.986 | 140/142 = 0.986 | Same two survivors. The 3 new sites are killed. |
| strict variant (7 + `TestLifecycleConflictingHistories`) | not run | 53/142 = 0.373 | Supplementary. 51 matched kills + `verify.go:885` + `operations.go:498`. |
| survivors without the post-hoc tests (executed / not) | 88 (45 / 43) | 86 (44 / 42) | −4 matched sites now killed, +2 new survivors. |
| checks with no site killed without the post-hoc tests | 9 | 7 | `chain.time` and `op.single_use` now have kills. |
| refusal conditions | 299 (139 fail, 7 warn, 153 problem) | 313 (142, 7, 164) | +14, all in `operations.go`: the 3 new `fail` sites and 11 `problem` lines of `checkReconciledReceipt`. |
| executed by the full suite | 239 | 256 | +10 of the 14 new conditions, +7 matched ones (below). No matched condition lost execution in any suite variant. |
| executed only by the post-hoc tests | 52 (43 fail, 9 problem) | 57 (42, 15) with 7 tests; 48 (40, 8) with build 1's 4 | The new tests now execute 3 fail + 1 problem lines that only post-hoc tests reached. The 3 new post-hoc tests add 2 fail + 7 problem lines that only they reach. |
| executed by tests or fuzzing | 255 (**44 never**) | 266 (**47 never**) | 41 are the same. 3 are now executed by the suite. 2 were reached only by fuzz in build 1 and not this time (†). 4 are new and never executed (+). |
| fuzz-only conditions | 16 | 10 | Fuzz variation: 9 matched conditions reached by fuzz only this time, 10 only last time. |
| statement coverage, full suite | 3,525/3,919 (89.9 %) | 3,703/4,085 (90.6 %) | +166 statements (`freshness.go` 64 new; `operations.go` +62, `assurance.go` +27, `verify.go` +8, `reconcile.go` +5). |
| the same, without the honest pattern | 3,418 (87.2 %) | 3,571 (87.4 %) (7 tests); 3,602 (88.2 %) (4 tests) | |
| suite or fuzz inputs | 3,592 (91.7 %) | 3,761 (92.1 %) | |
| starting suite (verifier packages) | 114 top-level, 516 passes | 144 top-level, 589 passes (+14 tool tests) | New tests: lifecycle, freshness, clock, key sets. |
| check IDs; R3 tests | 38; 37/37 | 38; 37/37 (identical list) | |

**Why the honest score went up (+5 kills).** All 5 come from tests added on
2026-10-10 that are not in the seven-test pattern. Every failing test was
identified (`kill_attribution_without_posthoc.json`):

| site | check | build 1, honest | build 2, 7-test skip | test(s) that fail against the mutant (7-test skip) |
|---|---|---|---|---|
| `operations.go:218` (was 194), `checkOperations` | `op.single_use` | survived (executed) | killed | `TestLifecycleConflictingHistories` |
| `operations.go:352` (was 298), `walkOperation` | `op.single_use` | survived | killed | `TestLifecycleConflictingHistories` |
| `reconcile.go:199`, `checkCallStatus` | `op.outcome_resolved` | survived | killed | `TestLifecycleConflictingHistories` |
| `verify.go:885` (was 822), `checkSegmentLog` | `chain.time` | survived | killed | `TestTimeStepsInsideASegment` (clock attacks, commit `abfe013`) |
| `operations.go:498` (new), `checkReconciledFlag` | `op.requires_policy` | n/a | killed | `TestLifecycleConflictingHistories`, `TestUnboundFlagsTextsNameTheLogNotTheCapability` (commit `d084ef9`) |

- `TestLifecycleConflictingHistories` (commit `afe8730`) is the lifecycle
  mutation test review 3 asked for. It accounts for 3 of the 5. The strict
  variant leaves it out and scores 53/142 = 0.373.
- §6 lists none of these tests as post-hoc. All were written on 2026-10-10
  for review-3 requests (lifecycle mutations, clock attacks, reporting
  texts), but after build 1's survivor list was published.
- Leaving out `TestUnboundFlagsTextsNameTheLogNotTheCapability` as well (it
  was written about an hour after the recovery-record rule and targets that
  rule's texts) would make `operations.go:498` survive: against the full
  suite only these three tests fail on that mutant. That variant was not run
  as a whole, so it is not known whether other kills depend on that test.

**Conditions newly executed by the suite** (7 matched; all `problem` lines):
- `TestLifecycleConflictingHistories` executes `reconcile.go` 91, 94, 97,
  115 and 131 (`checkReconciled`) and `operations.go` 831 (`checkReceipts`,
  "no effect_receipt"). `reconcile.go` 91 and 115 were in build 1's
  never-executed list.
- `keysets_extra_test.go` executes `replay.go` 395 (escalation mode differs
  from the policy snapshot; `raw/coverage/probe_replay395.txt`). It was in
  build 1's never-executed list.
- Without the post-hoc tests, four more lines are newly executed:
  - `operations.go:352`, `reconcile.go:199` and `operations.go:864`, by
    `TestLifecycleConflictingHistories`. The strict variant does not execute
    them.
  - `verify.go:885`, by a test outside the strict pattern.
    `TestTimeStepsInsideASegment` fails against its mutant.

**Expected effects of the other build-2 changes.** These are the
classification evidence, `Missing` kinds, `head_fresh` and `run_complete`,
the replay and recovery flag checks, and the custody fetch time. They add no
`fail` site apart from the three above. Most of the new code
(`freshness.go`, `assurance.go`) reports through `missing`/dimension
structures, which the refusal-condition definition does not count (caveats).
The 142 sites match the count §6 expects. `evalattack` (the flag on
RECONCILED commits) enters this experiment only as a test dependency. The
custody runner, the gateway and the killsuite binary are outside the tested
packages.

## 6. Caveats

- **0.394 is the honest score under the documented pattern.** The 1.000 is
  not independent evidence. Five of the honest score's kills come from tests
  written on 2026-10-10, after build 1's survivor list existed, though for
  other review-3 requests. The strict variant (0.373) and section 5 show
  their share. A survivor usually means another check catches the same
  tampering, not that the tampering would be accepted.
- **One mutation operator**: deleting one `fail` call. The held-out
  operators (`append`, `boundary`, `equality`) were not run here. The
  "first failing test" in the tool's reports is only the first `--- FAIL`
  line printed. For the 7 sites in section 5, every failing test was listed
  separately.
- **The tool's own tests run against every mutant.** Build 1's tool package
  had no tests. Its 14 tests read the verifier sources from disk, which
  `-overlay` does not change, so they pass for every mutant. They add run
  time but cannot change a result.
- **Short fuzz runs on a loaded machine.** 120 s per run and a fully used
  CPU, so execution counts are lower bounds and not comparable between
  builds. Which rare conditions the fuzz inputs reach varies from run to
  run: 2 conditions reached by fuzz in build 1 were not reached here (†),
  and 9 others were reached only here. FuzzRunFiles' starting coverage bits
  varied between 4,994 and 5,052 from identical seeds.
- **What the fuzz properties check**: crashes, errors and exact-form
  parsing, not semantic acceptance. FuzzRunFiles never re-signs evidence.
  No fuzz target supplies a witness run status.
- **Statement coverage only**: "executed" means the line ran, not that a
  test checked its message.
- **The refusal-condition definition is build 1's.** It counts `fail`,
  `warn` and `problems`/`warnings` appends. Build 2's new
  classification-evidence and `Missing` code (`missing = append(...)`,
  dimensions) is therefore not counted as refusal conditions, although its
  statements are in the coverage denominator.
- **Copied-source difference**: build 1's snapshot had 57 files. Build 2's
  has 94, because the tests now import `internal/evalattack`. The tested
  verifier package itself still depends on no other AgentGate package.
- **Script copies**: in this folder, `run_fuzz.sh` and `run_mutation.sh` call
  `typeperf.exe` by name. The executed copies used its full Windows system
  path. It is the same program.

## 7. Open issues (not changed here)

1. **`VERIFIER_CHECKS.md` §6** says the recovery-record flag site
   (`checkReconciledFlag`) is killed by `TestRecoveryRecordsStateTheBoundFlag`
   "and one case of `TestLifecycleConflictingHistories`". The full-suite
   attribution also finds `TestUnboundFlagsTextsNameTheLogNotTheCapability`.
   §6 also still shows build 1's numbers (139 sites, 0.367, 44/299 never
   executed, 9 checks) and build 1's line numbers. The build-2 numbers are
   sections 3-4 here.
2. **`refusalmutation/main.go`**: its package comment and the `-skip` flag
   help still give the four-test pattern as the example. §6 now prescribes
   seven.
3. **Whether to count more tests as post-hoc is the owner's choice.**
   Candidates: `TestUnboundFlagsTextsNameTheLogNotTheCapability` (targets
   the recovery-record rule's texts), and `TestLifecycleConflictingHistories`
   and `TestTimeStepsInsideASegment` (written for review 3 after build 1's
   survivors were public). The paper should name the pattern behind any
   score it quotes.
4. **Untested failure reasons**: the 47 never-executed conditions. They are
   mostly human-approval binding, catalog replay, delegation grant, restart
   segments and the RECONCILED adapter receipt (4 new). Add to them the 7
   checks that only the post-hoc tests kill.
5. **Variable check IDs** (minor, unchanged): two sites pass a variable check
   ID and are filed under "id": `provider.go:60` and `verify.go:783` (build
   1: line 720, the missing-log site).
6. **Build 1's tarballs** (`revision/robustness/raw/fuzz/*.tar.gz`,
   `raw/coverage/*.tar.gz`) record the Windows user name as the file owner
   in their headers (seen with `tar tv`). They were not changed here. This
   folder's tarballs were written with `--owner=0 --group=0`.

## 8. Files

- `fuzz_summary.json`, `fuzz_runs.csv`: one row per fuzz run.
- `coverage_summary.json`, `coverage_by_file.csv`: per suite variant and
  corpus; per file.
- `refusal_conditions.{json,csv}`: every condition and which source executes
  it, including the never-executed, fuzz-only and post-hoc-only lists.
- `kill_score_{full,without_posthoc,without_posthoc4,without_refusal_site_tests,without_restart_tests,without_posthoc_strict}.json`:
  the raw tool reports.
- `kill_score_summary.json`, `mutation_sites.csv` (one row per site, all
  variants, with coverage), `kill_by_check.csv`.
- `kill_attribution_without_posthoc.json`, `kill_attribution_full.json`:
  supplementary; every failing test for the 7 sites of section 5.
- `comparison_with_build1.json`: conditions and sites matched with build 1,
  with variant pairs.
- `check_counts.json`, `robustness_tests.csv`, `test_counts.json`.
- `run_manifest.json`: timeline, settings, skip patterns, headline.
- `build-manifest.txt`: the frozen binaries' hashes, `check_manifest.py`
  before and after, the frozen-source check and the tool hashes.
- `raw/`:
  - `tests_v.txt`, `baseline_tests.txt`;
  - the snapshot manifest, time, HEAD and git status, and its comparison
    with `MANIFEST.txt`;
  - `version_m_*.txt`, `fail_sites_list.json` (the tool's `-list` of the
    142 sites);
  - `check_manifest_{before,after}.txt`, `post_check.txt`,
    `build_tools.txt`, `baseline_times.txt`, `chain_times.txt`;
  - `fuzz/`: logs, CPU samples, concurrent processes, small corpora, the
    large corpora's hashes;
  - `coverage/`: cover profiles, `go test` outputs, the replay.go:395 probe;
  - `mutation/`: tool logs, CPU samples, concurrent processes, attribution
    logs.
- `scripts/`: every script used. These are build 1's scripts, extended to
  the build-2 variants, plus `snapshot.sh`, `build_tools.sh`, `baseline.sh`,
  `skip_patterns.sh`, `chain.sh`, `test_counts.py`, `attribute_kills.py`,
  `write_run_manifest.py` and `assemble.sh`. `env.sh` needs `REPO` and `E`;
  `snapshot.sh`, `build_tools.sh` and `post_check.sh` also need `SB`.

Total wall time: 02:26:57-04:03:39 UTC (1 h 37 min). Of this, fuzzing took
10 min 45 s, coverage 2 min 51 s and mutation 75 min 13 s (six variants).
These are not performance results: the machine was shared.
