#!/usr/bin/env bash
# Copies the summaries, raw logs and scripts of this run into the repository folder
# $OUT (docs/paper/data/build2/robustness), passing every text file through sanitize.py
# (paths -> <repo>/<scratch>/<singlebuild2>/<temp>, machine -> review-host, user -> user).
# Needs E, OUT, SANITIZE_USER and SANITIZE_HOST.
: "${E:?}" "${OUT:?}" "${SANITIZE_USER:?}" "${SANITIZE_HOST:?}"
D="$(dirname "$0")"
san() { mkdir -p "$(dirname "$2")"; python "$D/sanitize.py" "$1" "$2"; }
mkdir -p "$OUT/raw/fuzz" "$OUT/raw/coverage" "$OUT/raw/mutation" "$OUT/scripts"
for f in fuzz_summary.json fuzz_runs.csv coverage_summary.json coverage_by_file.csv refusal_conditions.json refusal_conditions.csv \
         kill_score_summary.json mutation_sites.csv kill_by_check.csv comparison_with_build1.json check_counts.json \
         robustness_tests.csv test_counts.json kill_attribution_without_posthoc.json kill_attribution_full.json; do
  san "$E/out/$f" "$OUT/$f"
done
for v in full without_posthoc without_posthoc4 without_refusal_site_tests without_restart_tests without_posthoc_strict; do
  san "$E/mut/kill_score_$v.json" "$OUT/kill_score_$v.json"
  san "$E/logs/mutation_$v.log" "$OUT/raw/mutation/mutation_$v.txt"
  san "$E/logs/cpu_mutation_$v.csv" "$OUT/raw/mutation/cpu_mutation_$v.csv"
  san "$E/logs/concurrent_mutation_$v.txt" "$OUT/raw/mutation/concurrent_mutation_$v.txt"
done
san "$E/logs/run_mutation_driver.txt" "$OUT/raw/mutation/run_mutation_driver.txt"
san "$E/logs/attribution_without_posthoc.txt" "$OUT/raw/mutation/attribution_without_posthoc.txt"
san "$E/logs/attribution_full.txt" "$OUT/raw/mutation/attribution_full.txt"
for t in FuzzParseLogLine FuzzCOSE FuzzRunFiles FuzzRunFiles-min5s FuzzRunFiles-nomin; do
  san "$E/logs/fuzz_$t.log" "$OUT/raw/fuzz/fuzz_$t.txt"
  san "$E/logs/cpu_$t.csv" "$OUT/raw/fuzz/cpu_$t.csv"
  san "$E/logs/concurrent_$t.txt" "$OUT/raw/fuzz/concurrent_$t.txt"
done
san "$E/logs/run_fuzz_driver.txt" "$OUT/raw/fuzz/run_fuzz_driver.txt"
cp "$E/repo_raw/fuzz/generated_corpus_small_runs.tar.gz" "$OUT/raw/fuzz/"
san "$E/repo_raw/fuzz/large_corpora_not_committed.sha256" "$OUT/raw/fuzz/large_corpora_not_committed.sha256"
cp "$E/repo_raw/coverage/cover_profiles.tar.gz" "$OUT/raw/coverage/"
san "$E/logs/run_cover.txt" "$OUT/raw/coverage/run_cover.txt"
for s in suite suite_without_posthoc suite_without_posthoc4 suite_without_refusal_site_tests suite_without_restart_tests suite_without_posthoc_strict; do
  san "$E/cov/$s.txt" "$OUT/raw/coverage/${s}_output.txt"
done
for f in baseline_tests.txt tests_v.txt snapshot_manifest.sha256 snapshot_time.txt snapshot_head.txt snapshot_git_status.txt \
         snapshot_vs_manifest.txt version_m_copy.txt version_m_frozen.txt fail_sites_list.json post_check.txt; do
  san "$E/raw/$f" "$OUT/raw/$f"
done
san "$E/check_before.txt" "$OUT/raw/check_manifest_before.txt"
san "$E/check_after.txt" "$OUT/raw/check_manifest_after.txt"
san "$E/logs/build_tools.txt" "$OUT/raw/build_tools.txt"
san "$E/logs/baseline.txt" "$OUT/raw/baseline_times.txt"
san "$E/logs/chain.txt" "$OUT/raw/chain_times.txt"
for f in "$D"/*; do [ -f "$f" ] && san "$f" "$OUT/scripts/$(basename "$f")"; done
san "$E/logs/probe_replay395.txt" "$OUT/raw/coverage/probe_replay395.txt"
# The executed scripts called typeperf by its full Windows system path; the repository copies
# call it by name (same program, found on PATH) so that no absolute local path is written.
sed -i 's#[A-Za-z]:/Windows/System32/typeperf.exe#typeperf.exe#' "$OUT/scripts/run_fuzz.sh" "$OUT/scripts/run_mutation.sh"
