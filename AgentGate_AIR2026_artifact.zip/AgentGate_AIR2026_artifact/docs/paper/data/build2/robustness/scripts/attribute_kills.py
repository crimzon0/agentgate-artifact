"""Supplementary: for selected refusal sites, lists EVERY top-level test that fails against the
site's 'fail' mutant (the mutation tool reports only the first FAIL line printed).

usage: python attribute_kills.py EXPDIR SITES_JSON OUT_JSON SKIP_PATTERN SITE_ID [SITE_ID ...]
  SITES_JSON  the tool's -list report (sites with "original" and "mutation" text)
  SITE_ID     "file:line:column" as in the tool's reports
Builds each mutant exactly as the tool describes it: the call statement starting at
line:column (its extent found by matching parentheses outside string literals) is
replaced by the tool's own one-line "mutation" text; the mutant is passed to
"go test -overlay" (the frozen copy is never modified), with -skip SKIP_PATTERN
('' for the full suite). Needs GO and the env of env.sh (run from $E/src)."""
import json, os, re, subprocess, sys, tempfile

EXP, SITES, OUT, SKIP = sys.argv[1:5]
IDS = sys.argv[5:]
SRC = os.path.join(EXP, "src")
PKG = os.path.join(SRC, "internal", "auditverify")
sites = {m["id"]: m for m in json.load(open(SITES))["mutants"]}


def call_end(text, start):
    """index just after the call statement that starts at `start` (the closing paren)."""
    i, depth, n = start, 0, len(text)
    while i < n:
        c = text[i]
        if c == '"':
            i += 1
            while text[i] != '"':
                i += 2 if text[i] == "\\" else 1
        elif c == "`":
            i = text.index("`", i + 1)
        elif c == "'":
            i += 1
            while text[i] != "'":
                i += 2 if text[i] == "\\" else 1
        elif c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
            if depth == 0:
                return i + 1
        i += 1
    raise ValueError("unbalanced call")


res = {"skip": SKIP, "sites": {}}
for sid in IDS:
    m = sites[sid]
    path = os.path.join(PKG, m["file"])
    text = open(path, encoding="utf-8").read()
    lines = text.split("\n")
    off = sum(len(l) + 1 for l in lines[: m["line"] - 1]) + m["column"] - 1
    end = call_end(text, off)
    original = re.sub(r"\s+", " ", text[off:end])
    if original.replace(" ", "") != m["original"].replace(" ", ""):
        sys.exit(f"{sid}: located text does not match the tool's original:\n{original}\n{m['original']}")
    mutant = text[:off] + m["mutation"] + text[end:]
    d = tempfile.mkdtemp(prefix="attr_", dir=EXP)
    mp = os.path.join(d, m["file"])
    open(mp, "w", encoding="utf-8", newline="").write(mutant)
    ov = os.path.join(d, "overlay.json")
    json.dump({"Replace": {os.path.abspath(path): os.path.abspath(mp)}}, open(ov, "w"))
    args = [os.environ["GO"], "test", "-count=1", "-timeout=5m"] + ([f"-skip={SKIP}"] if SKIP else []) + \
           [f"-overlay={ov}", "./internal/auditverify/...", "./cmd/agentgate-verify/"]
    p = subprocess.run(args, cwd=SRC, capture_output=True, text=True, encoding="utf-8", errors="replace")
    out = p.stdout + p.stderr
    failing = sorted({l.split()[2] for l in out.splitlines() if l.startswith("--- FAIL: ")})
    res["sites"][sid] = {"check": m["check"], "func": m.get("func", ""), "exit": p.returncode,
                         "build_failed": "[build failed]" in out, "failing_top_level_tests": failing}
    print(sid, m["check"], "exit", p.returncode, failing, flush=True)
json.dump(res, open(OUT, "w"), indent=2)
