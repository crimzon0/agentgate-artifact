#!/usr/bin/env bash
# The starting suite on the frozen copy: once verbose (raw/tests_v.txt, used by
# robustness_tests.py and for the test counts) and once plain (raw/baseline_tests.txt).
source "$(dirname "$0")/env.sh"
cd "$E/src" || exit 1
echo "verbose start $(date -u +%FT%TZ)"
"$GO" test -count=1 -v ./internal/auditverify/... ./cmd/agentgate-verify/ > "$E/raw/tests_v.txt" 2>&1; echo "verbose exit=$? end $(date -u +%FT%TZ)"
"$GO" test -count=1 ./internal/auditverify/... ./cmd/agentgate-verify/ > "$E/raw/baseline_tests.txt" 2>&1; echo "plain exit=$? end $(date -u +%FT%TZ)"
