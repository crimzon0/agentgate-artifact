#!/usr/bin/env bash
# Builds the test tools from the frozen copy ($E/src) with a fresh GOCACHE
# (the same four commands as build 1), records their SHA-256 and compares the
# verifier built from the copy with the frozen one (go version -m).
# Needs REPO, E and SB (the singlebuild2 folder).
source "$(dirname "$0")/env.sh"
: "${SB:?}"
rm -rf "$E/gocache"; mkdir -p "$E/bin"
cd "$E/src" || exit 1
"$GO" version
"$GO" build -o "$E/bin/agentgate-verify.exe" ./cmd/agentgate-verify/ && echo "built agentgate-verify.exe"
"$GO" build -o "$E/bin/refusalmutation.exe" ./internal/auditverify/tools/refusalmutation/ && echo "built refusalmutation.exe"
"$GO" test -c -o "$E/bin/auditverify.test.exe" ./internal/auditverify/ && echo "built auditverify.test.exe"
"$GO" test -c -covermode=set -coverpkg=agentgate/internal/auditverify -o "$E/bin/auditverify.cover.test.exe" ./internal/auditverify/ && echo "built auditverify.cover.test.exe"
( cd "$E/bin" && sha256sum -b *.exe )
"$GO" version -m "$E/bin/agentgate-verify.exe" > "$E/raw/version_m_copy.txt"
"$GO" version -m "$SB/bin/agentgate-verify.exe" > "$E/raw/version_m_frozen.txt"
diff <(grep -E '^\s+(dep|build)\s' "$E/raw/version_m_copy.txt" | grep -v 'vcs' | sed 's/^\s*//') \
     <(grep -E '^\s+(dep|build)\s' "$E/raw/version_m_frozen.txt" | grep -v 'vcs' | sed 's/^\s*//') \
  && echo "go version -m: dependency and build settings identical apart from vcs.* lines" \
  || echo "go version -m: differences above"
grep -E 'vcs|mod\s' "$E/raw/version_m_frozen.txt" | sed 's/^/frozen: /'
grep -E 'vcs|mod\s' "$E/raw/version_m_copy.txt" | sed 's/^/copy:   /'
