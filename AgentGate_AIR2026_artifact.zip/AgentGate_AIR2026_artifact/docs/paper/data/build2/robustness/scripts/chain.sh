#!/usr/bin/env bash
# Runs the steps one after another (as build 1 did): waits for run_fuzz.sh to finish,
# then coverage, then the six mutation variants. Needs REPO and E.
: "${REPO:?}" "${E:?}"
D="$(dirname "$0")"
until grep -q 'FuzzRunFiles-nomin testdata crashers' "$E/logs/run_fuzz_driver.txt" 2>/dev/null; do sleep 5; done
echo "coverage start $(date -u +%FT%TZ)"
bash "$D/run_cover.sh" > "$E/logs/run_cover.txt" 2>&1
echo "coverage end $(date -u +%FT%TZ)"
bash "$D/run_mutation.sh" full without_posthoc without_posthoc4 without_refusal_site_tests without_restart_tests without_posthoc_strict > "$E/logs/run_mutation_driver.txt" 2>&1
echo "mutation end $(date -u +%FT%TZ)"
