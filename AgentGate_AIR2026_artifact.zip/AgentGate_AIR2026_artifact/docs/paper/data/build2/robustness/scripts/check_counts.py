"""Counts the verifier's check IDs: the Check* string constants of
internal/auditverify/checks.go and the '### `id`' sections (with their
'Group: ...' line) of docs/demo/VERIFIER_CHECKS.md, both from the frozen copy.

usage: python check_counts.py EXPDIR OUTDIR -> OUTDIR/check_counts.json"""
import hashlib, json, os, re, sys

EXP, OUT = sys.argv[1], sys.argv[2]
doc_path = os.path.join(EXP, "src", "docs", "demo", "VERIFIER_CHECKS.md")
go_path = os.path.join(EXP, "src", "internal", "auditverify", "checks.go")
doc = open(doc_path, encoding="utf-8").read().replace("\r\n", "\n").split("\n")
code = open(go_path, encoding="utf-8").read()
in_code = re.findall(r'^\s*Check\w+\s*=\s*"([a-z_.]+)"', code, re.M)
groups, order = {}, []
for i, line in enumerate(doc):
    m = re.match(r"^### `([a-z_.]+)`$", line)
    if m and i + 1 < len(doc):
        g = re.match(r"^Group: (.+?) · Dimension: ([a-z_]+) · Mechanism: (.+)$", doc[i + 1])
        order.append(m.group(1))
        groups.setdefault(g.group(1) if g else "?", []).append(m.group(1))
res = {"source_doc": "docs/demo/VERIFIER_CHECKS.md (frozen copy)",
       "source_doc_sha256": hashlib.sha256(open(doc_path, "rb").read()).hexdigest(),
       "source_code": "internal/auditverify/checks.go (frozen copy)",
       "source_code_sha256": hashlib.sha256(open(go_path, "rb").read()).hexdigest(),
       "documented_checks": len(order), "check_ids_in_checks_go": len(set(in_code)),
       "same_set": set(order) == set(in_code),
       "only_in_doc": sorted(set(order) - set(in_code)), "only_in_code": sorted(set(in_code) - set(order)),
       "by_group": {g: {"count": len(v), "checks": v} for g, v in groups.items()}}
json.dump(res, open(os.path.join(OUT, "check_counts.json"), "w"), indent=2)
print(json.dumps({k: v for k, v in res.items() if k != "by_group"}, indent=1), {g: v["count"] for g, v in res["by_group"].items()})
