"""Compares this run (build 2) with build 1's robustness run.

usage: python compare_previous.py NEW_OUT OLD_OUT -> NEW_OUT/comparison_with_build1.json

NEW_OUT is this run's output folder, OLD_OUT build 1's
(docs/paper/data/revision/robustness). Suite variants are compared in pairs
(build-2 variant, build-1 variant): the same skip pattern where both builds ran
it, plus build 2's seven-test honest variant against build 1's four-test honest
variant (different patterns; the pair is labelled so). Line numbers moved between the
two source copies, so a refusal condition (and a mutation site, which is a
`fail` condition) is matched by (file, function, kind, source text of the
line, occurrence of that text in the function), as listed in each folder's
refusal_conditions.csv. Conditions with no counterpart are reported as added
or removed."""
import collections, csv, json, os, sys

NEW, OLD = sys.argv[1], sys.argv[2]


def conditions(folder):
    rows = list(csv.DictReader(open(os.path.join(folder, "refusal_conditions.csv"), encoding="utf-8")))
    seen = collections.Counter()
    out = {}
    for r in rows:
        k = (r["file"], r["function"], r["kind"], r["text"])
        seen[k] += 1
        out[k + (seen[k],)] = r
    return out


def sites(folder):
    rows = list(csv.DictReader(open(os.path.join(folder, "mutation_sites.csv"), encoding="utf-8")))
    return {(r["file"], int(r["line"])): r for r in rows}


def label(key, row):
    return f'{row["file"]}:{row["line"]} {row["function"]} [{row["kind"]}] {row["text"][:110]}'


cn, co = conditions(NEW), conditions(OLD)
sn, so = sites(NEW), sites(OLD)
never = lambda r: r["suite"] == "False" and r["fuzz"] == "False"
res = {"matching": __doc__.split("\n\n", 2)[1].strip(), "conditions": {}, "never_executed": {}, "mutation_sites": {}}
common = sorted(set(cn) & set(co))
res["conditions"] = {"new_build": len(cn), "previous_build": len(co), "matched": len(common),
                     "added": [label(k, cn[k]) for k in sorted(set(cn) - set(co))],
                     "removed": [label(k, co[k]) for k in sorted(set(co) - set(cn))]}
res["never_executed"] = {
    "new_build": sum(never(r) for r in cn.values()), "previous_build": sum(never(r) for r in co.values()),
    "still_never_executed": [label(k, cn[k]) for k in common if never(cn[k]) and never(co[k])],
    "now_executed": [label(k, cn[k]) + f' (suite={cn[k]["suite"]}, fuzz={cn[k]["fuzz"]})' for k in common if never(co[k]) and not never(cn[k])],
    "newly_never_executed": [label(k, cn[k]) for k in common if never(cn[k]) and not never(co[k])],
    "added_and_never_executed": [label(k, cn[k]) for k in sorted(set(cn) - set(co)) if never(cn[k])],
}
COND_PAIRS = [("suite", "suite"), ("suite_without_posthoc4", "suite_without_posthoc"),
              ("suite_without_posthoc", "suite_without_posthoc"),
              ("suite_without_refusal_site_tests", "suite_without_refusal_site_tests"),
              ("suite_without_restart_tests", "suite_without_restart_tests"), ("fuzz", "fuzz")]
for nc, oc in COND_PAIRS:
    if nc not in next(iter(cn.values())) or oc not in next(iter(co.values())):
        continue
    res["conditions"][f"executed_by_{nc}(build2)_vs_{oc}(build1)_changed_on_matched"] = [
        label(k, cn[k]) + f' ({co[k][oc]} -> {cn[k][nc]})' for k in common if cn[k][nc] != co[k][oc]]
# mutation sites: join each site to its fail condition, then match conditions
cond_by_line_new = {(r["file"], int(r["line"])): k for k, r in cn.items() if r["kind"] == "fail"}
cond_by_line_old = {(r["file"], int(r["line"])): k for k, r in co.items() if r["kind"] == "fail"}
skey_new = {cond_by_line_new.get(s): v for s, v in sn.items()}
skey_old = {cond_by_line_old.get(s): v for s, v in so.items()}
PAIRS = [("full", "full", "same suite"),
         ("without_posthoc4", "without_posthoc", "same pattern: build 1's four post-hoc tests"),
         ("without_posthoc", "without_posthoc", "each build's honest pattern: seven tests (build 2) vs four (build 1)"),
         ("without_refusal_site_tests", "without_refusal_site_tests", "same pattern"),
         ("without_restart_tests", "without_restart_tests", "same pattern")]
PAIRS = [x for x in PAIRS if x[0] in next(iter(sn.values())) and x[1] in next(iter(so.values()))]
variants = [x[0] for x in PAIRS]
ms = {"new_build_sites": len(sn), "previous_build_sites": len(so),
      "unmapped_new": sorted(f"{f}:{l}" for (f, l) in sn if (f, l) not in cond_by_line_new),
      "unmapped_old": sorted(f"{f}:{l}" for (f, l) in so if (f, l) not in cond_by_line_old),
      "added_sites": [f'{v["file"]}:{v["line"]} {v["call"]} ({v["check"]})' + "".join(f' {x}={v.get(x)}' for x in variants)
                      for k, v in skey_new.items() if k not in skey_old],
      "removed_sites": [f'{v["file"]}:{v["line"]} {v["call"]} ({v["check"]})' for k, v in skey_old.items() if k not in skey_new],
      "by_variant": {}}
for var, ovar, note in PAIRS:
    changed = []
    for k, v in skey_new.items():
        o = skey_old.get(k)
        if o is not None and o.get(ovar) != v.get(var):
            changed.append(f'{v["file"]}:{v["line"]} (was {o["file"]}:{o["line"]}) {v["call"]} ({v["check"]}): {o.get(ovar)} -> {v.get(var)}')
    ms["by_variant"][f"{var} (build 2) vs {ovar} (build 1)"] = {
        "note": note,
        "killed_new": sum(1 for v in sn.values() if v.get(var) == "killed"),
        "killed_previous": sum(1 for v in so.values() if v.get(ovar) == "killed"),
        "matched_sites": sum(1 for k in skey_new if k in skey_old),
        "matched_sites_result_changed": changed,
        "matched_sites_same_result": sum(1 for k, v in skey_new.items() if k in skey_old and skey_old[k].get(ovar) == v.get(var)),
    }
res["mutation_sites"] = ms
json.dump(res, open(os.path.join(NEW, "comparison_with_build1.json"), "w"), indent=2)
print(json.dumps({"conditions": {k: (v if isinstance(v, int) else len(v)) for k, v in res["conditions"].items()},
                  "never_executed": {k: (v if isinstance(v, int) else len(v)) for k, v in res["never_executed"].items()},
                  "mutation": {"sites": [len(sn), len(so)], "added": len(ms["added_sites"]), "removed": len(ms["removed_sites"]),
                               **{var: {**{x: y for x, y in d.items() if isinstance(y, int)}, "changed": len(d["matched_sites_result_changed"])}
                                  for var, d in ms["by_variant"].items()}}}, indent=1))
