"""Merges the coverage profiles written by run_cover.sh.

usage: python cover_merge.py EXPDIR OUTDIR -> OUTDIR/coverage_summary.json, OUTDIR/coverage_by_file.csv
Denominator: statements of internal/auditverify (non-test files; fixture/ and
tools/ excluded) as listed in the cover profiles.
Build 2: suite_without_posthoc leaves out the seven post-hoc tests of
VERIFIER_CHECKS.md section 6; suite_without_posthoc4 build 1's four;
suite_without_posthoc_strict the seven plus TestLifecycleConflictingHistories."""
import collections, csv, json, os, sys

EXP, OUT = sys.argv[1], sys.argv[2]
C = os.path.join(EXP, "cov")
GEN = ["gen_FuzzParseLogLine", "gen_FuzzCOSE", "gen_FuzzRunFiles", "gen_FuzzRunFiles-min5s", "gen_FuzzRunFiles-nomin"]
SPEC = ["gen_FuzzParseLogLine", "gen_FuzzCOSE", "gen_FuzzRunFiles-min5s"]
NAMES = ["suite", "suite_without_posthoc", "suite_without_posthoc4", "suite_without_refusal_site_tests", "suite_without_restart_tests", "suite_without_posthoc_strict", "seed_FuzzParseLogLine", "seed_FuzzCOSE", "seed_FuzzRunFiles"] + GEN


def load(name):
    blocks = {}
    for line in open(os.path.join(C, name + ".out")):
        if line.startswith("mode:"):
            continue
        loc, n, cnt = line.rsplit(" ", 2)
        if not loc.startswith("agentgate/internal/auditverify/") or "/fixture/" in loc or "/tools/" in loc:
            continue
        prev = blocks.get(loc)
        blocks[loc] = (int(n), max(int(cnt), prev[1] if prev else 0))
    return blocks


P = {n: load(n) for n in NAMES if os.path.exists(os.path.join(C, n + ".out"))}
allblocks = {}
for b in P.values():
    for k, (n, _) in b.items():
        allblocks[k] = n
total = sum(allblocks.values())
cov = lambda keys: sum(allblocks[k] for k in keys)
covered = lambda name: {k for k, (n, c) in P[name].items() if c > 0}
res = {"package": "agentgate/internal/auditverify (non-test files, fixture/ and tools/ excluded)",
       "mode": "set", "denominator_statements": total, "denominator_blocks": len(allblocks), "statements": {}}
for n in P:
    res["statements"][n] = cov(covered(n))
seed_union = set().union(*(covered(n) for n in P if n.startswith("seed_")))
gen_union = set().union(*(covered(n) for n in GEN if n in P))
spec_union = set().union(*(covered(n) for n in SPEC if n in P))
suite, suite_wo = covered("suite"), covered("suite_without_posthoc")
suite_wo4 = covered("suite_without_posthoc4")
res["statements"].update({
    "seed_union": cov(seed_union), "gen_union_all_runs": cov(gen_union),
    "gen_union_recommended_runs (ParseLogLine, COSE, RunFiles-min5s)": cov(spec_union),
    "gen_new_over_seed_union": cov(gen_union - seed_union),
    "gen_union_not_in_suite": cov(gen_union - suite), "suite_or_gen": cov(suite | gen_union),
    "suite_minus_suite_without_posthoc": cov(suite - suite_wo),
    "suite_minus_suite_without_posthoc4": cov(suite - suite_wo4),
})
res["percent"] = {k: round(100 * v / total, 1) for k, v in res["statements"].items()}
byfile = collections.Counter()
for k in gen_union - suite:
    byfile[k.split(":")[0].rsplit("/", 1)[1]] += allblocks[k]
res["gen_not_in_suite_by_file"] = dict(sorted(byfile.items()))
res["gen_not_in_suite_blocks"] = sorted(k.split("/")[-1] for k in gen_union - suite)
res["posthoc_only_blocks"] = sorted(k.split("/")[-1] for k in suite - suite_wo)
pf = collections.defaultdict(lambda: [0, 0, 0, 0, 0])
# (statements, suite, suite without the seven post-hoc tests, suite or any generated fuzz corpus, suite without build 1's four)
for k, n in allblocks.items():
    f = k.split(":")[0].rsplit("/", 1)[1]
    pf[f][0] += n
    pf[f][1] += n if k in suite else 0
    pf[f][2] += n if k in suite_wo else 0
    pf[f][3] += n if k in (suite | gen_union) else 0
    pf[f][4] += n if k in suite_wo4 else 0
res["by_file"] = {f: {"statements": a, "suite": b, "suite_without_posthoc": c, "suite_without_posthoc4": e, "suite_or_gen": d,
                      "suite_pct": round(100 * b / a, 1)} for f, (a, b, c, d, e) in sorted(pf.items())}
json.dump(res, open(os.path.join(OUT, "coverage_summary.json"), "w"), indent=2)
with open(os.path.join(OUT, "coverage_by_file.csv"), "w", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["file", "statements", "suite", "suite_without_posthoc", "suite_without_posthoc4", "suite_or_fuzz_generated", "suite_pct"])
    for f, v in res["by_file"].items():
        w.writerow([f, v["statements"], v["suite"], v["suite_without_posthoc"], v["suite_without_posthoc4"], v["suite_or_gen"], v["suite_pct"]])
print(json.dumps({"denominator": total, **res["statements"]}, indent=1))
