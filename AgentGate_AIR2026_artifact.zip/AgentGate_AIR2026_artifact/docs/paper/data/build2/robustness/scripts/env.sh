# Common environment for the build-2 robustness runs (sourced by the other scripts).
# Set REPO (the AgentGate checkout: offline module cache and Go toolchain) and
# E (a scratch directory holding the frozen source copy in $E/src, made by
# snapshot.sh: go.mod, go.sum, internal/auditverify/, cmd/agentgate-verify/,
# internal/audit/, internal/canon/, internal/evalattack/ (imported by build 2's
# verifier tests), docs/demo/VERIFIER_CHECKS.md and docs/demo/REVISION_CONTRACT.md;
# compare it with ../raw/snapshot_manifest.sha256) and the binaries in $E/bin
# (build_tools.sh; hashes in ../build-manifest.txt).
: "${REPO:?set REPO to the AgentGate checkout}"
: "${E:?set E to the experiment scratch directory}"
export GOMODCACHE="$REPO/.tools/go-host-cache-20260916/mod" GOPROXY=off GOFLAGS=-mod=readonly GOTOOLCHAIN=local GOCACHE="$E/gocache"
GO="$REPO/.tools/go-1.26.6/bin/go.exe"
export GO
