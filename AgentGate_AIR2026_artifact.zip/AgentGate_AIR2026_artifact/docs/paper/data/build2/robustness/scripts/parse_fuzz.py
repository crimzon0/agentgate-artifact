"""Summarises the fuzz logs written by run_fuzz.sh.

usage: python parse_fuzz.py EXPDIR OUTDIR
Reads EXPDIR/logs/fuzz_<tag>.log and cpu_<tag>.csv, writes OUTDIR/fuzz_summary.json
and OUTDIR/fuzz_runs.csv (one row per run)."""
import csv, json, os, re, statistics, sys

EXP, OUT = sys.argv[1], sys.argv[2]
TAGS = ["FuzzParseLogLine", "FuzzCOSE", "FuzzRunFiles", "FuzzRunFiles-min5s", "FuzzRunFiles-nomin"]
MIN = {"FuzzRunFiles": "60s (go default)", "FuzzRunFiles-min5s": "5s", "FuzzRunFiles-nomin": "0s"}
out = {}
for tag in TAGS:
    p = os.path.join(EXP, "logs", f"fuzz_{tag}.log")
    if not os.path.exists(p):
        continue
    t = open(p, encoding="utf-8", errors="replace").read()
    r = {"target": tag.split("-")[0], "run": tag, "fuzztime": "120s",
         "fuzzminimizetime": MIN.get(tag, "60s (go default)"), "log": os.path.basename(p)}
    stats = re.findall(r"fuzz: elapsed: (?:(\d+)m)?(\d+)s, execs: (\d+) \((\d+)/sec\), new interesting: (\d+) \(total: (\d+)\)", t)
    if stats:
        m_, s_, n, rate, k, tot = stats[-1]
        e = int(m_ or 0) * 60 + int(s_)
        r.update(fuzz_elapsed_s=e, execs=int(n), new_interesting=int(k), corpus_total=int(tot),
                 mean_execs_per_s=round(int(n) / max(1, e), 1), status_lines=len(stats))
    m = re.search(r"gathering baseline coverage: \d+/(\d+) completed, now fuzzing with (\d+) workers", t)
    if m:
        r.update(baseline_inputs=int(m.group(1)), workers=int(m.group(2)))
    m = re.search(r"initial coverage bits: (\d+)", t)
    if m:
        r["initial_coverage_bits"] = int(m.group(1))
    bits = re.findall(r"new interesting input, .*?total bits: (\d+)", t)
    r["final_coverage_bits"] = int(bits[-1]) if bits else r.get("initial_coverage_bits")
    r["new_interesting_logged"] = len(bits)
    r["minimizations_logged"] = len(re.findall(r"DEBUG input minimized", t))
    r["crasher_minimizations"] = len(re.findall(r"crasher: true", t))
    r["failures_reported"] = len(re.findall(r"--- FAIL|Failing input written to|found crasher", t))
    r["passed"] = bool(re.search(r"^PASS$", t, re.M)) and bool(re.search(r"^ok\s", t, re.M))
    m = re.search(r"exit=(\d+) wall_seconds=(\d+) end (\S+)", t)
    if m:
        r.update(exit_code=int(m.group(1)), wall_s=int(m.group(2)), end_utc=m.group(3))
    m = re.search(r"start (\S+) cmd: (.*)$", t, re.M)
    if m:
        r.update(start_utc=m.group(1), command=m.group(2))
    m = re.search(r"corpus files: (\d+)", t)
    if m:
        r["generated_corpus_files"] = int(m.group(1))
    m = re.search(r"testdata crashers: (\d+)", t)
    if m:
        r["testdata_crashers"] = int(m.group(1))
    c = os.path.join(EXP, "logs", f"cpu_{tag}.csv")
    if os.path.exists(c):
        vals = []
        for row in list(csv.reader(open(c, encoding="utf-8", errors="replace")))[1:]:
            try:
                vals.append(float(row[1]))
            except (ValueError, IndexError):
                pass
        if vals:
            r.update(cpu_total_pct_mean=round(statistics.mean(vals), 1), cpu_total_pct_min=round(min(vals), 1), cpu_samples=len(vals))
    cc = os.path.join(EXP, "logs", f"concurrent_{tag}.txt")
    if os.path.exists(cc):
        r["concurrent_processes_at_start"] = [l.strip() for l in open(cc, encoding="utf-8", errors="replace") if l.strip()]
    out[tag] = r
json.dump(out, open(os.path.join(OUT, "fuzz_summary.json"), "w"), indent=2)
cols = ["run", "target", "fuzztime", "fuzzminimizetime", "workers", "start_utc", "end_utc", "wall_s", "fuzz_elapsed_s", "execs",
        "mean_execs_per_s", "baseline_inputs", "new_interesting", "corpus_total", "generated_corpus_files", "initial_coverage_bits",
        "final_coverage_bits", "minimizations_logged", "failures_reported", "testdata_crashers", "crasher_minimizations", "passed", "exit_code",
        "cpu_total_pct_mean", "cpu_total_pct_min", "cpu_samples"]
with open(os.path.join(OUT, "fuzz_runs.csv"), "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(cols)
    for r in out.values():
        w.writerow([r.get(k, "") for k in cols])
print(json.dumps({k: {x: v.get(x) for x in ["execs", "final_coverage_bits", "failures_reported", "passed"]} for k, v in out.items()}, indent=1))
