#!/usr/bin/env bash
# After the runs: (1) re-hash the frozen copy against raw/snapshot_manifest.sha256,
# (2) re-hash the live repository files the copy was taken from (same list),
# (3) re-check the frozen binaries and every compiled source file MANIFEST.txt lists
# (check_manifest.py next to it, run as the brief prescribes: py check_manifest.py),
# (4) look for crashers written by go test -fuzz, (5) git HEAD and status of the copied paths.
# Needs REPO, E and SB (the singlebuild2 folder).
: "${REPO:?}" "${E:?}" "${SB:?}"
echo "== post-run checks $(date -u +%FT%TZ)"
( cd "$E/src" && sha256sum -c --quiet "$E/raw/snapshot_manifest.sha256" ) && echo "frozen copy: identical to snapshot_manifest.sha256"
( cd "$REPO" && sha256sum -c --quiet "$E/raw/snapshot_manifest.sha256" ) && echo "live repository files: identical to snapshot_manifest.sha256"
py "$SB/check_manifest.py"
echo "check_manifest.py exit=$?"
( cd "$SB" && sha256sum bin/*.exe )
if [ -d "$E/src/internal/auditverify/testdata/fuzz" ]; then
  echo "testdata/fuzz in the frozen copy:"; find "$E/src/internal/auditverify/testdata/fuzz" -type f
else
  echo "no testdata/fuzz directory in the frozen copy (no crasher written)"
fi
echo "repository HEAD: $(cd "$REPO" && git rev-parse HEAD)"
echo "git status of the copied paths (empty = clean):"
( cd "$REPO" && git status --porcelain -- go.mod go.sum internal/auditverify cmd/agentgate-verify internal/audit internal/canon internal/evalattack docs/demo )
echo "== end $(date -u +%FT%TZ)"
