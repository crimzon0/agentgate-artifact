"""Lists the outcome of the verifier's parser-robustness tests (REVISION_CONTRACT R3 list) from a
'go test -v' log. usage: python robustness_tests.py TESTS_V_TXT OUT_CSV
Mapping of a test (or one subtest) to the R3 item it exercises is by test name; a case can serve two items."""
import csv, re, sys
ITEMS = [
    ("malformed envelopes", r"^TestMalformedCOSEEnvelopesAreRefused/(?!ES256_algorithm|no_algorithm|duplicate_header_keys)"),
    ("unknown algorithm IDs", r"^TestMalformedCOSEEnvelopesAreRefused/(ES256_algorithm|no_algorithm)$|^TestKeysAndMembersAreClosed/unknown_algorithm$"),
    ("duplicate/case-variant fields", r"^TestMalformedCOSEEnvelopesAreRefused/duplicate_header_keys$|^TestKeysAndMembersAreClosed/(duplicate_member|case-variant_member|capital_struct_field)$|^TestCurrencyMembersAreTheOnlyCapitals$|^TestAmbiguousLinesAndFilesFail$"),
    ("unknown key roles / key-role mismatch", r"^TestKeysAndMembersAreClosed/(unknown_role|second_audit_key)$|^TestArtifactKeyAndRoleChecks/"),
    ("malformed decision values", r"^TestDecisionValueShapes/"),
    ("oversized inputs", r"^TestOversized"),
    ("malformed files never panic", r"^TestMalformedInputNeverPanics$|^TestPanicGuardReportsVerifierError$"),
]
results = {}
for line in open(sys.argv[1], encoding="utf-8", errors="replace"):
    m = re.match(r"\s*--- (PASS|FAIL|SKIP): (\S+) \(", line)
    if m:
        results[m.group(2)] = m.group(1)
rows = []
for name, res in results.items():
    has_children = any(k.startswith(name + "/") for k in results)
    for item, pat in ITEMS:
        if re.search(pat, name) and not has_children:
            rows.append((item, name.split("/")[0], name.split("/", 1)[1] if "/" in name else "", res))
with open(sys.argv[2], "w", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["r3_item", "test", "case", "result"])
    w.writerows(sorted(rows))
import collections
c = collections.Counter((r[0], r[3]) for r in rows)
print(dict(c), len(rows))
