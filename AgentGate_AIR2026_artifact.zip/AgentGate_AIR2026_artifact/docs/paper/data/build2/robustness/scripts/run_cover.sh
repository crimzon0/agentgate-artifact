#!/usr/bin/env bash
# Statement coverage (set mode) of internal/auditverify by the whole test suite
# and by the suite with each skip pattern of skip_patterns.sh left out:
#   suite_without_posthoc          the seven post-hoc tests (VERIFIER_CHECKS.md section 6; build 2's honest variant)
#   suite_without_posthoc4         build 1's four post-hoc tests
#   suite_without_refusal_site_tests  only TestRefusalSites and TestDelegationRefusalSites
#   suite_without_restart_tests    only the two restart post-hoc tests
#   suite_without_posthoc_strict   the seven plus TestLifecycleConflictingHistories
# then each fuzz target's seed corpus and each fuzz run's generated corpus (copied
# into testdata/fuzz/<target> of a scratch working directory, so the coverage test
# binary replays it as ordinary test inputs). Same commands as build 1.
source "$(dirname "$0")/env.sh"
source "$(dirname "$0")/skip_patterns.sh"
cd "$E/src" || exit 1
mkdir -p "$E/cov"
suite() { # $1 label, $2 skip pattern or empty
  echo "$1 start $(date -u +%FT%TZ)"
  if [ -n "$2" ]; then
    "$GO" test -count=1 -skip="$2" -covermode=set -coverpkg=agentgate/internal/auditverify -coverprofile="$E/cov/$1.out" ./internal/auditverify/... ./cmd/agentgate-verify/ > "$E/cov/$1.txt" 2>&1
  else
    "$GO" test -count=1 -covermode=set -coverpkg=agentgate/internal/auditverify -coverprofile="$E/cov/$1.out" ./internal/auditverify/... ./cmd/agentgate-verify/ > "$E/cov/$1.txt" 2>&1
  fi
  echo "$1 exit=$? end $(date -u +%FT%TZ)"
}
suite suite ""
suite suite_without_posthoc "$POSTHOC7"
suite suite_without_posthoc4 "$POSTHOC4"
suite suite_without_refusal_site_tests "$REFUSAL2"
suite suite_without_restart_tests "$RESTART2"
suite suite_without_posthoc_strict "$STRICT8"
run() { # $1 label, $2 target, $3 corpus dir or empty
  D="$E/cov/cwd_$1"; rm -rf "$D"; mkdir -p "$D/testdata/fuzz/$2"
  [ -n "$3" ] && cp "$3"/* "$D/testdata/fuzz/$2/"
  ( cd "$D" && "$E/bin/auditverify.cover.test.exe" -test.run="^$2\$" -test.count=1 -test.v -test.coverprofile="$E/cov/$1.out" > "$E/cov/$1.txt" 2>&1 )
  echo "$1 exit=$? inputs=$(ls "$D/testdata/fuzz/$2" | wc -l) subtests_passed=$(grep -c -- "--- PASS: $2/" "$E/cov/$1.txt") failed=$(grep -c -- "--- FAIL" "$E/cov/$1.txt")"
}
run seed_FuzzParseLogLine FuzzParseLogLine ""
run seed_FuzzCOSE FuzzCOSE ""
run seed_FuzzRunFiles FuzzRunFiles ""
for TAG in FuzzParseLogLine FuzzCOSE FuzzRunFiles FuzzRunFiles-min5s FuzzRunFiles-nomin; do
  run "gen_$TAG" "${TAG%%-*}" "$E/corpus/$TAG"
done
