#!/usr/bin/env bash
# Runs each fuzz target of internal/auditverify for 120 s on the frozen source
# copy ($E/src), every run starting from the seed corpus only (the fuzz cache
# of a target is moved aside before the run and copied to $E/corpus/<tag>).
# Tags: FuzzParseLogLine, FuzzCOSE, FuzzRunFiles (default 60 s minimisation),
# FuzzRunFiles-min5s (-fuzzminimizetime=5s), FuzzRunFiles-nomin (=0s).
# Workers: go test default (-parallel = GOMAXPROCS = 12 on this machine).
source "$(dirname "$0")/env.sh"
cd "$E/src" || exit 1
mkdir -p "$E/logs" "$E/corpus"
CACHE="$E/gocache/fuzz/agentgate/internal/auditverify"
for TAG in "$@"; do
  T="${TAG%%-*}"; EXTRA=""
  case "$TAG" in *-min5s) EXTRA="-fuzzminimizetime=5s";; *-nomin) EXTRA="-fuzzminimizetime=0s";; esac
  [ -d "$CACHE/$T" ] && mv "$CACHE/$T" "$E/gocache-fuzz-$T-before-$TAG"
  typeperf.exe "\Processor(_Total)\% Processor Time" -si 5 -sc 45 -y -f CSV -o "$E/logs/cpu_$TAG.csv" >/dev/null 2>&1 &
  TP=$!
  powershell -NoProfile -ExecutionPolicy Bypass -File "$(cygpath -w "$E/concurrent.ps1")" > "$E/logs/concurrent_$TAG.txt" 2>&1
  START=$(date -u +%FT%TZ); S=$(date +%s)
  echo "== $TAG start $START cmd: go test -run=^\$ -fuzz=^$T\$ -fuzztime=120s $EXTRA ./internal/auditverify/ (GODEBUG=fuzzdebug=1)" | tee "$E/logs/fuzz_$TAG.log"
  GODEBUG=fuzzdebug=1 "$GO" test -run='^$' -fuzz="^$T\$" -fuzztime=120s $EXTRA ./internal/auditverify/ >> "$E/logs/fuzz_$TAG.log" 2>&1
  RC=$?
  echo "== $TAG exit=$RC wall_seconds=$(( $(date +%s)-S )) end $(date -u +%FT%TZ)" | tee -a "$E/logs/fuzz_$TAG.log"
  kill $TP 2>/dev/null
  mkdir -p "$E/corpus/$TAG"
  cp -r "$CACHE/$T/." "$E/corpus/$TAG/" 2>/dev/null
  echo "== $TAG corpus files: $(ls "$E/corpus/$TAG" | wc -l)" | tee -a "$E/logs/fuzz_$TAG.log"
  # crashers would be written by go test under testdata/fuzz/<target>
  if [ -d "$E/src/internal/auditverify/testdata/fuzz/$T" ]; then
    echo "== $TAG testdata crashers: $(ls "$E/src/internal/auditverify/testdata/fuzz/$T" | wc -l)" | tee -a "$E/logs/fuzz_$TAG.log"
  else
    echo "== $TAG testdata crashers: 0" | tee -a "$E/logs/fuzz_$TAG.log"
  fi
done
