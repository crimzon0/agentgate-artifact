#!/usr/bin/env bash
# Refusal-site ('fail' operator) mutation on the frozen copy, one run per suite variant
# (skip patterns in skip_patterns.sh):
#   full                         every test of ./internal/auditverify/... and ./cmd/agentgate-verify/
#   without_posthoc              -skip the seven post-hoc tests (VERIFIER_CHECKS.md section 6): build 2's honest score
#   without_posthoc4             -skip build 1's four post-hoc tests (build 1's honest score, for comparison)
#   without_refusal_site_tests   -skip only TestRefusalSites|TestDelegationRefusalSites (build 1's third variant)
#   without_restart_tests        -skip only the two restart post-hoc tests (build 1's fourth variant)
#   without_posthoc_strict       -skip the seven plus TestLifecycleConflictingHistories (the stricter variant section 6 mentions)
# Workers: the tool's default (-parallel = NumCPU/2 = 6), per-mutant timeout 5 min (tool default). Same tool
# invocation as build 1. The held-out operators (-operator append|boundary|equality) are NOT run here.
source "$(dirname "$0")/env.sh"
source "$(dirname "$0")/skip_patterns.sh"
cd "$E/src" || exit 1
mkdir -p "$E/mut" "$E/logs"
for V in "$@"; do
  case "$V" in
    full) SKIP="";;
    without_posthoc) SKIP="$POSTHOC7";;
    without_posthoc4) SKIP="$POSTHOC4";;
    without_refusal_site_tests) SKIP="$REFUSAL2";;
    without_restart_tests) SKIP="$RESTART2";;
    without_posthoc_strict) SKIP="$STRICT8";;
    *) echo "unknown variant $V"; exit 2;;
  esac
  typeperf.exe "\Processor(_Total)\% Processor Time" -si 10 -sc 360 -y -f CSV -o "$E/logs/cpu_mutation_$V.csv" >/dev/null 2>&1 &
  TP=$!
  powershell -NoProfile -ExecutionPolicy Bypass -File "$(cygpath -w "$E/concurrent.ps1")" > "$E/logs/concurrent_mutation_$V.txt" 2>&1
  S=$(date +%s)
  echo "== $V start $(date -u +%FT%TZ) skip=[$SKIP]" | tee "$E/logs/mutation_$V.log"
  "$E/bin/refusalmutation.exe" -go "$GO" -operator fail -skip "$SKIP" -out "$E/mut/kill_score_$V.json" >> "$E/logs/mutation_$V.log" 2>&1
  echo "== $V exit=$? wall_seconds=$(( $(date +%s)-S )) end $(date -u +%FT%TZ)" | tee -a "$E/logs/mutation_$V.log"
  kill $TP 2>/dev/null
done
