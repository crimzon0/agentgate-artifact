"""Copies a text file, replacing local paths, the user name and the machine name.

usage: SANITIZE_USER=<user> SANITIZE_HOST=<machine> python sanitize.py SRC DST
(The executed copy was given the two names in the environment; they are not
written here.) Replacements, longest first: this experiment's scratch folder
(.../scratchpad/build2-work/robustness) -> <scratch>/build2-work/robustness,
the frozen build folder (.../scratchpad/singlebuild2) -> <singlebuild2>, the
session scratchpad -> <scratch>, the user's temp folder -> <temp>, the
repository -> <repo>, then the machine name -> review-host and the user name ->
user (only where no letter or digit touches it, so hex digests are left alone). Separators may be '/' or a backslash, drives C: or /c/; /tmp/claude/...
(the msys view of the same temp folder) is handled too."""
import os, re, sys

src, dst = sys.argv[1], sys.argv[2]
user, host = os.environ["SANITIZE_USER"], os.environ["SANITIZE_HOST"]
u = re.escape(user)
S = r"[\\/]+"  # either path separator (escaped backslashes in JSON included)
DRIVE = r"(?:[A-Za-z]:|/[A-Za-z])"
TEMP = DRIVE + S + "Users" + S + u + S + "AppData" + S + "Local" + S + "Temp"
TMP = r"(?:" + TEMP + r"|/tmp)"
SCR = TMP + S + "claude" + S + r"[^\\/\s\"']+" + S + r"[0-9a-f-]{36}" + S + "scratchpad"
t = open(src, encoding="utf-8", errors="replace").read()
for pat, rep in [
    (SCR + S + "build2-work" + S + "robustness", "<scratch>/build2-work/robustness"),
    (SCR + S + "singlebuild2", "<singlebuild2>"),
    (SCR, "<scratch>"),
    (TEMP, "<temp>"),
    (DRIVE + S + "Users" + S + u + S + "Documents" + S + "Codex" + S + "2026-09-15" + S + "oka" + S
     + "outputs" + S + "AgentGate-recovered", "<repo>"),
    (re.escape(host), "review-host"),
    (r"(?<![0-9A-Za-z])" + u + r"(?![0-9A-Za-z])", "user"),  # not inside hex digests
]:
    t = re.sub(pat, lambda m: rep, t, flags=re.I)
open(dst, "w", encoding="utf-8", newline="").write(t)
