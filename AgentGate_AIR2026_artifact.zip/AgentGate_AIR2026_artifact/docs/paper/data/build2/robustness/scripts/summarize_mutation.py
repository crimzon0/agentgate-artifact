"""Joins the refusal-site mutation reports and the coverage of each site.

usage: python summarize_mutation.py EXPDIR OUTDIR
Reads EXPDIR/mut/kill_score_<variant>.json and OUTDIR/refusal_conditions.csv
(run refusal_conditions.py first); writes OUTDIR/kill_score_summary.json,
OUTDIR/mutation_sites.csv (one row per site) and OUTDIR/kill_by_check.csv."""
import collections, csv, json, os, sys

EXP, OUT = sys.argv[1], sys.argv[2]
VARIANTS = ["full", "without_posthoc", "without_posthoc4", "without_refusal_site_tests", "without_restart_tests", "without_posthoc_strict"]
# build 2: without_posthoc = the seven post-hoc tests left out (VERIFIER_CHECKS.md section 6);
# without_posthoc4 = build 1's four; without_posthoc_strict = the seven plus TestLifecycleConflictingHistories
reports = {}
for v in VARIANTS:
    p = os.path.join(EXP, "mut", f"kill_score_{v}.json")
    if os.path.exists(p):
        reports[v] = json.load(open(p))
cover = {(r["file"], int(r["line"])): r for r in csv.DictReader(open(os.path.join(OUT, "refusal_conditions.csv")))}
sites = collections.OrderedDict()
for v, rep in reports.items():
    for m in rep["mutants"]:
        key = (m["file"], m["line"], m["call"])
        row = sites.setdefault(key, {"id": m.get("id", ""), "file": m["file"], "line": m["line"], "function": m.get("func", ""),
                                     "call": m["call"], "check": m["check"]})
        row[f"{v}"] = m["result"]
        row[f"{v}_first_failure"] = m.get("detail", "") if m["result"] == "killed" else ""
for row in sites.values():
    c = cover.get((row["file"], row["line"]))
    row["executed_by_suite"] = c["suite"] if c else "unknown"
    row["executed_by_suite_without_posthoc"] = c["suite_without_posthoc"] if c else "unknown"
    row["executed_by_suite_without_posthoc4"] = c["suite_without_posthoc4"] if c else "unknown"
    row["executed_by_suite_without_refusal_site_tests"] = c["suite_without_refusal_site_tests"] if c else "unknown"
    if "without_restart_tests" in reports:
        row["executed_by_suite_without_restart_tests"] = c.get("suite_without_restart_tests", "unknown") if c else "unknown"
    if "without_posthoc_strict" in reports:
        row["executed_by_suite_without_posthoc_strict"] = c.get("suite_without_posthoc_strict", "unknown") if c else "unknown"
    row["executed_by_fuzz"] = c["fuzz"] if c else "unknown"
cols = ["id", "file", "line", "function", "call", "check"]
for v in reports:
    cols += [v, f"{v}_first_failure"]
cols += ["executed_by_suite", "executed_by_suite_without_posthoc", "executed_by_suite_without_posthoc4", "executed_by_suite_without_refusal_site_tests"]
if "without_restart_tests" in reports:
    cols += ["executed_by_suite_without_restart_tests"]
if "without_posthoc_strict" in reports:
    cols += ["executed_by_suite_without_posthoc_strict"]
cols += ["executed_by_fuzz"]
with open(os.path.join(OUT, "mutation_sites.csv"), "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=cols)
    w.writeheader()
    w.writerows(sites.values())
summary = {"operator": "delete one X.fail(...) call statement (replaced by an assignment that keeps its arguments in use); one mutant per site",
           "sites_definition": "call statements X.fail(...) in non-test files of internal/auditverify (fixture/ and tools/ excluded)",
           "kill": "the test packages fail (go test exit != 0, not a build failure) against the mutant",
           "variants": {}}
for v, rep in reports.items():
    k, s = rep["killed"], rep["survived"]
    surv = [m for m in rep["mutants"] if m["result"] == "survived"]
    profile = {"full": "suite", "without_posthoc": "suite_without_posthoc", "without_posthoc4": "suite_without_posthoc4",
               "without_posthoc_strict": "suite_without_posthoc_strict",
               "without_refusal_site_tests": "suite_without_refusal_site_tests",
               "without_restart_tests": "suite_without_restart_tests"}[v]
    executed = sum(1 for m in surv if cover.get((m["file"], m["line"]), {}).get(profile) == "True")
    summary["variants"][v] = {
        "generated_at": rep["generated_at"], "go_version": rep["go_version"], "test_packages": rep["test_packages"],
        "skipped_tests": rep.get("skipped_tests", ""), "sites": rep["sites"], "killed": k, "survived": s,
        "build_errors": rep["build_errors"], "timeouts": rep["timeouts"], "kill_score": round(rep["kill_score"], 4),
        "kill_score_fraction": f"{k}/{k + s}", "baseline_suite_seconds": round(rep["baseline_seconds"]["suite"], 1),
        "survivors_executed_by_that_suite": executed, "survivors_not_executed_by_that_suite": len(surv) - executed,
        "checks_with_no_site_killed": sorted(c for c, t in rep["by_check"].items() if t["killed"] == 0),
        "survivors": rep["survivors"]}
json.dump(summary, open(os.path.join(OUT, "kill_score_summary.json"), "w"), indent=2)
checks = sorted({c for rep in reports.values() for c in rep["by_check"]})
with open(os.path.join(OUT, "kill_by_check.csv"), "w", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["check", "sites"] + [f"killed_{v}" for v in reports])
    for c in checks:
        w.writerow([c, next(iter(reports.values()))["by_check"].get(c, {}).get("sites", 0)] +
                   [rep["by_check"].get(c, {}).get("killed", 0) for rep in reports.values()])
print(json.dumps({v: {k: x[k] for k in ["sites", "killed", "survived", "build_errors", "timeouts", "kill_score",
                                         "survivors_executed_by_that_suite", "survivors_not_executed_by_that_suite"]}
                  for v, x in summary["variants"].items()}, indent=1))
