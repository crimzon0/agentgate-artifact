"""Counts the starting suite from a 'go test -v' log (raw/tests_v.txt) per package, and the cases
of the post-hoc tests. usage: python test_counts.py TESTS_V_TXT OUT_JSON"""
import collections, json, re, sys

POSTHOC7 = ["TestRefusalSites", "TestDelegationRefusalSites", "TestRestartProviderJournalCutBack",
            "TestRestartContinuationRemovedFromRunRecord", "TestRecoveryRecordsStateTheBoundFlag",
            "TestReconciledAdapterReceipt", "TestReplayedAndConfirmingAnswersStateTheBoundFlag"]
STRICT_EXTRA = ["TestLifecycleConflictingHistories"]
pkgs, cur = collections.OrderedDict(), []
for line in open(sys.argv[1], encoding="utf-8", errors="replace"):
    m = re.match(r"^\s*--- (PASS|FAIL|SKIP): (\S+) \(", line)
    if m:
        cur.append((m.group(1), m.group(2), not line.startswith(" ")))
    m = re.match(r"^(ok|FAIL)\s+(\S+)", line)
    if m:
        pkgs[m.group(2)] = {"result": m.group(1), "entries": cur}
        cur = []
out = {"packages": {}}
names = {}
for p, d in pkgs.items():
    e = d["entries"]
    top = [x for x in e if x[2]]
    out["packages"][p] = {"result": d["result"], "top_level": len(top),
                          "top_level_fuzz_targets": sum(1 for x in top if x[1].startswith("Fuzz")),
                          "passes_including_subtests": sum(1 for x in e if x[0] == "PASS"),
                          "failures": sum(1 for x in e if x[0] == "FAIL"), "skips": sum(1 for x in e if x[0] == "SKIP")}
    for x in e:
        names[x[1]] = x[0]
verifier = [p for p in out["packages"] if not p.endswith("/tools/refusalmutation")]
out["verifier_packages (auditverify + cmd/agentgate-verify, the two build 1 counted)"] = {
    k: sum(out["packages"][p][k] for p in verifier) for k in ("top_level", "top_level_fuzz_targets", "passes_including_subtests", "failures", "skips")}
def cases(t):
    subs = [n for n in names if n.startswith(t + "/") and "/" not in n[len(t) + 1:]]
    return {"present": t in names, "result": names.get(t), "subtests": len(subs), "cases": max(1, len(subs)) if t in names else 0}
out["posthoc_tests"] = {t: cases(t) for t in POSTHOC7}
out["posthoc_cases_7"] = sum(v["cases"] for v in out["posthoc_tests"].values())
out["posthoc_cases_4"] = sum(out["posthoc_tests"][t]["cases"] for t in POSTHOC7[:4])
out["strict_extra"] = {t: cases(t) for t in STRICT_EXTRA}
json.dump(out, open(sys.argv[2], "w"), indent=2)
print(json.dumps(out, indent=1))
