"""Writes run_manifest.json (the run's timeline, settings and headline) into OUT.
usage: python write_run_manifest.py OUT   (OUT already holds fuzz_summary.json, test_counts.json, kill_score_summary.json)"""
import json, os, sys

OUT = sys.argv[1]
fz = json.load(open(os.path.join(OUT, "fuzz_summary.json")))
tc = json.load(open(os.path.join(OUT, "test_counts.json")))
ks = json.load(open(os.path.join(OUT, "kill_score_summary.json")))["variants"]
VP = tc["verifier_packages (auditverify + cmd/agentgate-verify, the two build 1 counted)"]
P4 = "^(TestRefusalSites|TestDelegationRefusalSites|TestRestartProviderJournalCutBack|TestRestartContinuationRemovedFromRunRecord)$"
P7 = ("^(TestRefusalSites|TestDelegationRefusalSites|TestRestartProviderJournalCutBack|TestRestartContinuationRemovedFromRunRecord"
      "|TestRecoveryRecordsStateTheBoundFlag|TestReconciledAdapterReceipt|TestReplayedAndConfirmingAnswersStateTheBoundFlag)$")
P8 = P7[:-2] + "|TestLifecycleConflictingHistories)$"
timeline = {
    "check_manifest_before": ["2026-10-10T02:26:57Z", "2026-10-10T02:26:58Z"],
    "snapshot": "2026-10-10T02:29:21Z",
    "build_tools": ["2026-10-10T02:29:39Z", "2026-10-10T02:30:04Z"],
    "baseline_suite": ["2026-10-10T02:30:13Z", "2026-10-10T02:31:08Z"],
}
for k, v in fz.items():
    timeline["fuzz_" + k] = [v["start_utc"], v["end_utc"]]
timeline.update({
    "coverage_runs": ["2026-10-10T02:42:07Z", "2026-10-10T02:44:58Z"],
    "mutation_full": ["2026-10-10T02:44:59Z", "2026-10-10T03:00:25Z"],
    "mutation_without_posthoc": ["2026-10-10T03:00:25Z", "2026-10-10T03:12:12Z"],
    "mutation_without_posthoc4": ["2026-10-10T03:12:12Z", "2026-10-10T03:24:00Z"],
    "mutation_without_refusal_site_tests": ["2026-10-10T03:24:00Z", "2026-10-10T03:36:26Z"],
    "mutation_without_restart_tests": ["2026-10-10T03:36:26Z", "2026-10-10T03:49:12Z"],
    "mutation_without_posthoc_strict": ["2026-10-10T03:49:12Z", "2026-10-10T04:00:12Z"],
    "kill_attribution (supplementary)": ["2026-10-10T04:00:34Z", "2026-10-10T04:02:53Z"],
    "probe_replay395 (supplementary)": "between 2026-10-10T04:02:53Z and 04:03:29Z",
    "post_check": ["2026-10-10T04:03:29Z", "2026-10-10T04:03:30Z"],
    "check_manifest_after": ["2026-10-10T04:03:38Z", "2026-10-10T04:03:39Z"],
})
m = {
    "experiment": "R6.7 verifier robustness on build 2 (frozen build of 2026-10-10T02:24:44Z, commit 86643d7); times are UTC",
    "brief": ("repeat the build-1 method (docs/paper/data/revision/robustness) on build 2: 5 fuzz runs, coverage, refusal-condition "
              "census, refusal-site ('fail' operator) mutation with the full suite and without the post-hoc tests (seven-test pattern of "
              "VERIFIER_CHECKS.md section 6, and build 1's four-test pattern for comparison); held-out operators NOT run"),
    "source": {
        "frozen_copy_taken_utc": "2026-10-10T02:29:21Z", "branch": "claude/supervisor-demo",
        "head": "86643d751720e33e6fca36c739a4c8135361cd3c (copied paths clean)",
        "files": ("go.mod, go.sum, internal/auditverify/**, cmd/agentgate-verify/**, internal/audit/**, internal/canon/**, "
                  "internal/evalattack/**, docs/demo/VERIFIER_CHECKS.md, docs/demo/REVISION_CONTRACT.md (94 files, raw/snapshot_manifest.sha256)"),
        "compiled_files_checked_against_singlebuild2_manifest": "33 of 33 identical",
        "live_tree_and_copy_rehashed_utc": ["2026-10-10T04:03:29Z"], "live_tree_identical": True,
        "frozen_binaries_identical_before_and_after": True,
        "check_manifest_py": {"before": "2026-10-10T02:26:57Z: checked 1868 files, 0 differ",
                              "after": "2026-10-10T04:03:38Z: checked 1868 files, 0 differ"},
        "agentgate_deps_of_tested_packages": ["internal/auditverify", "internal/auditverify/fixture",
                                              "internal/auditverify/tools/refusalmutation", "cmd/agentgate-verify",
                                              "internal/evalattack", "internal/audit", "internal/canon"],
    },
    "toolchain": "go1.26.6 windows/amd64, offline module cache, fresh GOCACHE",
    "machine": "AMD Ryzen 5 7600X (6 cores, 12 threads), 32 GB RAM, Windows 10 Pro 22H2; shared with other build-2 experiment runs during the fuzz window",
    "baseline_suite": {
        "command": "go test -count=1 -v ./internal/auditverify/... ./cmd/agentgate-verify/",
        "run_utc": ["2026-10-10T02:30:13Z", "2026-10-10T02:31:08Z"],
        "result": "ok (3 packages with tests; tools/refusalmutation has its own tests since build 2)",
        "verifier_packages_top_level_tests_passed": VP["top_level"], "including_fuzz_seed_targets": VP["top_level_fuzz_targets"],
        "verifier_packages_all_test_and_subtest_passes": VP["passes_including_subtests"],
        "refusalmutation_tool_tests_passed": tc["packages"]["agentgate/internal/auditverify/tools/refusalmutation"]["top_level"],
        "failures": VP["failures"], "skips": VP["skips"],
    },
    "posthoc_tests": {
        "definition": ("tests written after the surviving refusal sites of an earlier mutation run were seen, or (2026-10-10) together "
                       "with the site or condition they kill (docs/demo/VERIFIER_CHECKS.md section 6)"),
        "tests": {t: v["cases"] for t, v in tc["posthoc_tests"].items()},
        "cases_7": tc["posthoc_cases_7"], "cases_4": tc["posthoc_cases_4"],
        "strict_extra": {t: v["cases"] for t, v in tc["strict_extra"].items()},
        "skip_patterns": {"without_posthoc (build 2 honest, 7 tests)": P7, "without_posthoc4 (build 1 honest, 4 tests)": P4,
                          "without_refusal_site_tests": "TestRefusalSites|TestDelegationRefusalSites",
                          "without_restart_tests": "^(TestRestartProviderJournalCutBack|TestRestartContinuationRemovedFromRunRecord)$",
                          "without_posthoc_strict (supplementary)": P8},
    },
    "timeline_utc": timeline,
    "cpu_heavy_windows_note": ("fuzzing used 12 workers and mutation 6 parallel go test processes; the steps ran one after another; "
                               "whole-machine CPU means 93.6-100 % (fuzz) and 96.5-98.0 % (mutation); other build-2 runners' compromise, "
                               "crash, concurrency, misuse and custody runs were active during the fuzz window (raw/fuzz/concurrent_*.txt); "
                               "none was seen at the start of any mutation variant"),
    "headline": {
        "fuzz_executions_total": sum(v["execs"] for v in fz.values()), "fuzz_crashers_or_property_failures": 0,
        "mutation": {v: x["kill_score_fraction"] for v, x in ks.items()},
    },
    "files": "see RESULTS.md section 8",
    "build1": "docs/paper/data/revision/robustness (single build of 2026-10-08)",
}
json.dump(m, open(os.path.join(OUT, "run_manifest.json"), "w"), indent=2)
print(json.dumps(m["headline"]))
