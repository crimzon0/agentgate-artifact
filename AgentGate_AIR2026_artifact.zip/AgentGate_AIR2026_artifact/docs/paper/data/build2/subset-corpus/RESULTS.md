# Subset verifier on a mutant corpus: build 2

Run on 2026-10-10 (UTC). Part of the rerun on frozen build 2 (commit
`86643d7`, branch `claude/supervisor-demo`) for the paper revision answering
the supervisor's second review. That review asked for "an independent
end-to-end verifier for a selected adversarial corpus" and to "freeze
expected outcomes before running that subset".

**What kind of verifier this is.** `docs/paper/artifact/subset_verifier.py`
is a **second implementation of a protocol subset, written by the same
authors**. It is in Python with the standard library only and shares no code
with the Go verifier. It was ported from the specification *and* the Go
sources, which were open during the port. It is **not an independent
implementation**: an outside team did not write it, and a mistake the port
copied from the Go design would not show. It checks parts of 15 of the 38 Go
checks (`docs/paper/artifact/SUBSET_VERIFIER.md`). It never replays the
policy and it does not check `keys.valid`. Its PASSED is not a verdict of the
full verifier. All the mutants come from the Go mutation engine
(`internal/evalattack`), and the expected outcomes are the Go verifier's.

**There was no build-1 run of this experiment.** It is new in this
revision. The comparison column below uses the only earlier numbers:

- the smoke test in `SUBSET_VERIFIER.md` ("Status"). It ran on a development
  build (`f01d1c9` plus the files of `92fc597`, 2026-10-10) and an earlier
  corpusgen, and its manifest SHA-256 was `4644d326…`;
- the `-make-base` development check that section reports for the revision
  branch.

## What was run

Placeholders: `<repo>` is the repository root, `<scratch>` the session
scratch folder, `<singlebuild2>` the frozen build-2 folder.

1. **Build check, before.** `py <singlebuild2>/check_manifest.py` checked
   1868 files and found 0 that differ (2026-10-10T02:27:54Z). The same check
   after the runs, at 02:36:23Z, also found 0 of 1868 different
   (`build-manifest.txt`).
2. **Corpus generator: a test build, not one of the six frozen binaries.**
   It was compiled from the repository at `86643d7`. `git diff --quiet HEAD`
   showed no change under `docs/paper/artifact`, `internal`, `cmd`, `go.mod`
   or `go.sum`. The toolchain was offline Go 1.26.6 with
   `GOMODCACHE=<repo>/.tools/go-host-cache-20260916/mod GOPROXY=off GOFLAGS=-mod=readonly GOTOOLCHAIN=local`.
   ```
   <repo>/.tools/go-1.26.6/bin/go.exe build -o <scratch>/build2-work/subset-corpus/bin/corpusgen.exe ./docs/paper/artifact/corpusgen
   ```
   This is the same compilation as the brief's
   `go run ./docs/paper/artifact/corpusgen`; building first lets the binary
   be hashed. The binary's SHA-256 is `2c28ae46…53514a799`. It links 243
   module source files. 242 of them are listed in the build-2 `MANIFEST.txt`
   with the same SHA-256 (0 differ). The one other file is the command's own
   `docs/paper/artifact/corpusgen/main.go`, as committed. So the Go verifier,
   gateway, demo and mutation engine inside corpusgen are byte-for-byte the
   build-2 sources.
3. **Corpus.** Run at 02:28:32Z..02:28:45Z, exit 0:
   ```
   <scratch>/build2-work/subset-corpus/bin/corpusgen.exe -out <scratch>/build2-work/subset-corpus/corpus -make-base -host-label review-host
   ```
   This made a fresh flag-mode base pair (bound and unbound) with
   `demo.HeadlessRun`, plus their tamper-lab copies and the mutants. Each
   folder's Go outcome was computed in the no-replay setting (policy.replay
   off, key compromise simulated, `UnboundFlags` for the unbound design) for
   the anchor conditions none, keys, head and both, and written to
   `manifest.json`.
4. **Freeze.** At 02:28:57Z, before any Python run, `sha256sum` gave
   manifest SHA-256 **`a9f9d178fb03a36e2b948e22f4f07b138d8f61c85d08fceba840453fb217765d`**,
   equal to what corpusgen printed. It was recorded outside the corpus in
   `manifest-sha256-recorded.txt`.
5. **Python self-test.** `py docs/paper/artifact/subset_verifier.py --self-test`
   passed. The Python was 3.13.5. `subset_verifier.py` had SHA-256
   `22899b49…21654e5affd8ef7ac23b1e821c6cfe8`, equal to HEAD.
6. **Comparison.** Run at 02:29:15Z..02:29:44Z, exit 0:
   ```
   py docs/paper/artifact/subset_verifier.py --corpus <scratch>/build2-work/subset-corpus/corpus/manifest.json --expect-manifest-sha256 a9f9d178fb03a36e2b948e22f4f07b138d8f61c85d08fceba840453fb217765d --out <scratch>/build2-work/subset-corpus/corpus/subset-result.json
   ```
   The freeze held: `manifest.sha256` and the recorded hash both match, and
   all 372 corpus files match the `files_sha256` the manifest records.
7. **Analysis.** `py analyze.py manifest.json subset-result.json` and
   `py mutation_targets.py <corpus>` (scripts in this folder).
8. **Extra checks, all run after the frozen comparison:**
   - `crosscheck_frozen_verify.py` re-ran the **frozen**
     `<singlebuild2>/bin/agentgate-verify.exe` on every bound-design folder.
     It used the full verifier (replay on), the entry's simulated roles and
     each anchor condition's pins, and compared the verdict with the
     manifest's `go_full`.
   - `ablations.py` ran post-hoc sensitivity runs (see Caveats).
   - The `docs/paper/artifact/corpusgen` package tests ran from a test binary
     (`go-test-v.txt`).
   - Two single-folder sample reports (`samples/`).

Every command and its output is in `run-log.txt`. The 26 MB corpus stays
outside the repository, in `<scratch>/build2-work/subset-corpus/corpus/`.

## Headline results

Corpus: 2 clean folders, 16 tamper-lab folders (8 attacks x 2 designs) and
56 mutant folders. The mutant matrix has 72 cells: 3 operators x 4 key sets x
3 snapshot variants x 2 designs. In 16 of them change-rules does not apply:
the target message has one recipient, so there is no snapshot lever. Each of
the 74 folders is verified under 4 anchor conditions, for 296
verifications. keys.json is byte-identical to its base pin in all 74
folders. The keys pin therefore cannot change any verdict, so agreement is
counted once per folder, at anchor condition none.

| quantity | result |
|---|---|
| **binding-relevant mutant folders, each counted once** (key set audit, audit+issuer or audit+issuer+adapter; anchor none) | **42 of 42 agree**: Go FAILED 26, accepted 16; the subset FAILED the same 26 |
| per key set: audit | 14 folders: Go FAILED 11, accepted 3. Go verdict differs between the designs in 3 of 7 operator/variant pairs |
| per key set: audit+issuer | 14 folders: Go FAILED 11, accepted 3. Differs in 3 of 7 pairs |
| per key set: audit+issuer+adapter | 14 folders: Go FAILED 4, accepted 10. Differs in 0 of 7 pairs (the binding does not decide these verdicts) |
| keys-pinned repeats of those 42 folders | 42 of 42 agree. The pin changes 0 Go verdicts and 0 subset verdicts. **Not counted again** |
| other rows (clean 8, tamper-lab 64, key-set-none mutants 56, head- or both-anchored mutants 84) | 212 of 212 agree (Go FAILED 200, accepted 12) |
| all verifications (diagnostic total, counts the keys repeats) | 296 of 296 agree, 0 disagree |
| by group | clean 8/8, tamper-lab 64/64, mutants 224/224 |
| strongest-attacker cells (design x operator x key set x anchor; detected only if every applied variant is detected) | 96 of 96 agree |
| **distinct binding flips** (detected in bound, accepted in unbound, no anchor) | **Go 6, subset 6, the same six**: {strip-flag, invent-flag, change-rules} x {audit, audit+issuer}. The keys pin gives the same flips |
| reverse flips | Go 0, subset 0 |
| **disagreements** | **none** |

Folders by verdict: 26 of 42 binding-relevant folders FAILED in Go, made up
of bound A 7 of 7, bound A+I 7 of 7, bound A+I+X 2 of 7, unbound A 4 of 7,
unbound A+I 4 of 7 and unbound A+I+X 2 of 7 (`rows.csv`,
`flip_cells.csv`).

Diagnostics that do not decide the verdict:

- **Failing-check sets.** On the 252 verifications Go fails, the subset's
  failing checks equal Go's failing checks restricted to the subset's IDs in
  244. The other 8 are all `tamper-lab/<design>/forge-approval-7` at all four
  anchor conditions. Go also fails `artifact.signature` there, on the
  approval artifact, whose signature the subset never verifies (by design).
  Both still fail the folder on `chain.signature`, `head.signature`,
  `op.requires_policy`, `op.capability_bound` and `op.receipts_bound`.
- **Replay on versus off (Go only).** The full verifier's verdict differs
  from the no-replay verdict in 24 of 296 verifications. All 24 go from
  VERIFIED to FAILED: bound A+I+X plain (3 operators x anchors none and
  keys), and unbound plain for every attacker key set (3 operators x 3 key
  sets x none and keys). The subset never replays, so these 24 are outside
  what it can reproduce. The comparison uses the no-replay outcome.
- **Frozen-binary cross-check.** The frozen `agentgate-verify.exe` gives the
  manifest's `go_full` verdict in **148 of 148** bound-design verifications
  (`crosscheck-frozen-verify.json`). The CLI has no switch for the unbound
  design or for disabling `policy.replay`, so the 148 unbound verifications
  and the no-replay expected outcomes could not be re-run with the frozen
  binary. For those, the evidence is the source identity in step 2.
- **Post-hoc sensitivity, which shows the corpus exercises the checks.**
  Each run weakens one piece of the unchanged script in memory and compares
  with the same frozen manifest:

  | weakened piece | disagreements | binding-relevant folders that agree | flips found |
  |---|---|---|---|
  | no signature verification | 56 of 296 | 28 of 42 | 0 of 6 |
  | snapshot's stated policy hash trusted instead of recomputed | 16 of 296 | 34 of 42 | 6 of 6 |
  | no comparison of the PRE/FINAL log details with the decision values | 0 of 296 | 42 of 42 | 6 of 6 |

  The third piece is not exercised by the corpus. The engine keeps details
  and values consistent, so signatures over the propagated hashes catch its
  mutants. The package test `TestDetailEditIsCaughtByTheClassificationBinding`
  covers that piece. It passed on the build-2 sources: bound, Go and subset
  both FAILED on `op.requires_policy`; unbound, Go VERIFIED and the subset
  PASSED.
- **Package tests** (development check, not a result). All 10 tests of
  `docs/paper/artifact/corpusgen` pass on the build-2 sources, none skipped.
  The `-make-base` test made a **second** fresh base pair (manifest
  `c7bfa90d…`) and got the identical counts: 296 of 296; 42 binding-relevant
  folders, 26 failed and 16 accepted; 3/7, 3/7 and 0/7; 6 flips on both
  sides. The fixture corpus gave 232 of 232 with the same 42, 26/16 and 6
  flips.

## Comparison with the earlier numbers

| quantity | earlier (smoke test, dev build; revision-branch `-make-base` check) | build 2 | difference and cause |
|---|---|---|---|
| corpus shape | 2 clean, 16 tamper-lab, 56 mutants, 16 not applicable | the same | none |
| binding-relevant folders, once each | 42 of 42 agree; Go FAILED 26, accepted 16 (the smoke summary had counted 84 rows, 52/32, each folder twice) | 42 of 42; 26 / 16 | none. The once-per-folder count was introduced in `173a87e`, before build 2, and is used here as briefed |
| per key set, pairs that differ between designs | 3/7 (A), 3/7 (A+I), 0/7 (A+I+X) | 3/7, 3/7, 0/7 | none |
| A+I+X folders, detected / accepted in both designs | 4 / 10 | 4 / 10 | none |
| keys-pinned repeats, verdicts changed by the pin | 0 of 42 | 0 of 42 (Go and subset) | none |
| other rows | 212 of 212 | 212 of 212 (Go FAILED 200, accepted 12) | none |
| all verifications | 296 of 296 | 296 of 296 | none |
| by group | 8/8, 64/64, 224/224 | the same | none |
| strongest-attacker cells | 96 of 96 | 96 of 96 | none |
| distinct binding flips | 6 and 6 (reported then as 12, each counted again at the keys pin) | 6 and 6, the same six | none |
| reverse flips | 0 | 0 | none |
| failing-check sets equal on Go-FAILED rows | 244 of 252 | 244 of 252 | none. The 8 are forge-approval-7, as explained above |
| Go replay-on differs from no-replay | 24 of 296 | 24 of 296 | none |
| sensitivity: no signatures | 56 disagreements, 0 of 6 flips | 56, 0 of 6 | none. Re-implemented by monkeypatching, because the smoke test's throwaway copies were not kept |
| sensitivity: trusted snapshot hash | 16 | 16 | none (re-implemented) |
| sensitivity: no detail comparison | 0 | 0 | none (re-implemented; defined in `ablations.py`) |
| freeze checks | smoke corpus: hash file `manifest.json.sha256`, no `files_sha256`, refused by the current freeze checks | `manifest.sha256`, hash recorded outside before the run, 372 files checked | stronger freeze. Format change in `c6b9e09`, before build 2 |
| manifest SHA-256 | `4644d326…` | `a9f9d178…` | differs by construction: fresh runs with new keys, run IDs and times |

**Why build 2 changes nothing here.** The build-2 changes are:

- the gateway keeps the flag on recovery records and on replayed COMMITTED
  answers;
- Go's `op.requires_policy` checks those flags;
- Go's `op.receipts_bound` and `op.requires_policy` check an adapter receipt
  attached to RECONCILED;
- the classification evidence, `head_fresh` and `run_complete` dimensions,
  and Missing kinds are new;
- `evalattack` states the flag on RECONCILED commits.

None of them reaches a verdict on this corpus:

- Each base run has one operation with 3 replayed COMMITTED answers and one
  reconciled operation, after a `provider_response_lost`. Both are
  unflagged, so the build-2 gateway writes the same records as before: there
  is no flag to keep.
- Every mutant edits a first-time execution with no replayed answer and no
  RECONCILED record (`mutation_targets.csv`):
  - strip-flag edits entry 37 (a flagged `financial_request.create`);
  - invent-flag edits entry 13 (an unflagged `financial_request.create`);
  - change-rules edits entry 29 (a flagged `external_message.send`).
- The RECONCILED entry carries no adapter receipt. The adapter signed only
  an UNKNOWN receipt (`transport_error`, on the EFFECT_FAILED entry), not an
  APPLIED one, so the new RECONCILED receipt check has nothing to check.
- Dimensions, classification evidence and Missing entries change reports,
  not verdicts. The subset compares verdicts only.

Agreement on build 2 therefore says nothing about these new Go checks. They
are also outside the subset. `subset_verifier.py` has no handling of
RECONCILED entries, replayed answers or recovery records. Its CALL_RESULT
flag comparison is keyed by the `call_id` of an EFFECT_EXECUTED entry, and
replayed answers and the RECONCILED-confirmed call have other call IDs.
`SUBSET_VERIFIER.md`'s "Not in the subset" list does not mention these
build-2 additions yet. This is a documentation gap, flagged here and not
edited (out of this experiment's scope).

## Caveats

- **Same authors, not independent.** This is a second implementation of a
  protocol subset, ported with the Go sources open. Agreement shows the port
  is faithful on this corpus. It is not independent confirmation of the Go
  logic, and the paper must not call it an "independent verifier".
- **Subset only.** It checks parts of 15 of the 38 checks. It has no policy
  replay, no `keys.valid`, no delegation, provider, approval or witness
  checks, and none of the build-2 replay, recovery or RECONCILED-receipt
  checks. Only verdicts are compared, never assurance levels or dimensions.
- **Same origin.** All mutants come from the Go engine, and the expected
  outcomes are the Go verifier's in the no-replay setting. Key compromise is
  the signature-abstracted simulation (`AssumeCompromised`): nothing was
  re-signed and no private key was read.
- **One frozen corpus from one base pair.** The package test's second pair
  is a development check whose hash was not recorded outside the test.
- **The corpus generator is a separate compile.** It is not one of the six
  frozen binaries. It is tied to build 2 by source identity (242 of 242
  linked module files equal to `MANIFEST.txt`). The frozen binary reproduced
  the replay-on verdicts of the bound design, 148 of 148. It cannot
  reproduce the unbound or no-replay outcomes.
- **Go assurance in the manifest.** Clean folders are `VERIFIED / CONSISTENT`
  even with both pins: `assess()` gives ANCHORED only when no check was
  skipped, and the no-replay setting skips `policy.replay`. Under the full
  frozen verifier, `clean/bound` with both pins is `VERIFIED / ANCHORED`.
  This is not compared and is not a difference.
- **Interpreters.** The main run used Python 3.13.5 (py launcher). The Go
  package test found Python 3.14.3 (`python3` on PATH).
- **Elapsed times are not performance results.** Other experiments ran on
  the machine at the same time.
- **Location of the result file.** `subset-result.json` was written to the
  corpus root, which no manifest entry covers, so the freeze checks are
  unaffected. The sensitivity runs wrote their reports to a separate scratch
  folder.

Total wall time: 2026-10-10T02:27:54Z (first manifest check) to about
02:46Z (write-up), about 18 minutes. The corpus took 13 s, the comparison
29 s and the package tests 112 s.

## Files

| file | content |
|---|---|
| `RESULTS.md` | this file |
| `build-manifest.txt` | before/after `check_manifest.py` outputs with timestamps; corpusgen test build (command, SHA-256, source identity with MANIFEST.txt); Python script hashes |
| `manifest-sha256-recorded.txt` | the manifest hash recorded before the Python run |
| `manifest.json` | the corpus manifest, byte-identical copy (SHA-256 `a9f9d178…`). It names corpus-relative folders only, no local paths, so no sanitizing was needed |
| `manifest.sha256` | corpusgen's freeze file (`sha256sum -c` passes on the copy) |
| `subset-result.json` | the agreement report of `subset_verifier.py --corpus`: freeze record, summary, all 296 rows |
| `summary.json` | headline counts with denominators, check-set comparison, replay-on versus no-replay differences, Go assurance counts, keys.json identity (`analyze.py`) |
| `rows.csv` | one row per verification: Go and subset verdicts, Go assurance, replay-on verdict, failing checks |
| `flip_cells.csv` | strongest-attacker cells at anchor none, per implementation |
| `mutation_targets.csv` | the operation each mutant edits and whether it is flagged, replayed or reconciled in the base run |
| `crosscheck-frozen-verify.json` | frozen `agentgate-verify.exe` versus `go_full`, 148 bound-design verifications |
| `ablations.json` | post-hoc sensitivity runs |
| `go-test-v.txt` | `go test -v` of the corpusgen package on the build-2 sources (test binary hash inside) |
| `run-log.txt` | every command with its output and timestamps |
| `samples/` | single-folder subset reports for `bound-strip-flag-audit-plain` (FAILED) and `unbound-strip-flag-audit-plain` (PASSED), one binding flip |
| `analyze.py`, `mutation_targets.py`, `crosscheck_frozen_verify.py`, `ablations.py` | the analysis scripts (new for this experiment; there were no build-1 scripts) |

Outside the repository: `<scratch>/build2-work/subset-corpus/` holds the
corpus (26 MB), the corpusgen and test binaries, and the raw logs.
