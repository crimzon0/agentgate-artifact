"""POST-HOC sensitivity runs (not part of the frozen comparison): does the
corpus exercise the subset's checks? Each run loads subset_verifier.py
unchanged, weakens one piece in memory (monkeypatching, no file is edited)
and runs the same --corpus comparison against the same frozen manifest.

  no-signatures     verify_signature always succeeds (entry, head, COSE)
  trust-snapshot    policy.snapshot_bound uses the snapshot's stated
                    policy_hash instead of recomputing it
  no-detail-compare op.requires_policy (bound design) no longer compares the
                    PRE/FINAL log details (outcome, decision, flagged,
                    escalation, reasons/rules, FLAG reasons, human_approved,
                    overlay root, pre_decision_hash) with the decision values;
                    the CALL_RESULT flag comparison is kept

The SUBSET_VERIFIER.md smoke test ran similar throwaway copies; those copies
were not kept, so these are re-implementations of the same ideas, not the
same code.

usage: py ablations.py SUBSET_VERIFIER_PY MANIFEST_JSON EXPECT_SHA256 WORK_DIR OUT_JSON
"""
import contextlib
import importlib.util
import io
import json
import os
import sys

script, manifest, expect, work, out_path = sys.argv[1:6]

DETAIL_PATTERNS = ("records outcome", "records decision", "records flagged", "records escalation mode",
                   "gives reasons from rules", "FLAG reason(s)", "records human_approved",
                   "records another overlay root", "but its details name")


def load():
    spec = importlib.util.spec_from_file_location("subset_verifier", script)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def no_signatures(m):
    m.verify_signature = lambda public, message, signature: True


def trust_snapshot(m):
    def stated(snapshot, run_mode):
        value = snapshot.get("policy_hash") if isinstance(snapshot, dict) else None
        try:
            return bytes.fromhex(value), ""
        except (TypeError, ValueError):
            return None, "states no policy hash"
    m.snapshot_policy_hash = stated


def no_detail_compare(m):
    original = m._decision_binding

    def binding(line, final, final_value, op, unbound, run_mode, content_run):
        problems = original(line, final, final_value, op, unbound, run_mode, content_run)
        if unbound:
            return problems
        return [p for p in problems if not any(pattern in p for pattern in DETAIL_PATTERNS)]
    m._decision_binding = binding


results = {}
for name, patch in (("no-signatures", no_signatures), ("trust-snapshot", trust_snapshot), ("no-detail-compare", no_detail_compare)):
    module = load()
    patch(module)
    report = os.path.join(work, "ablation-%s.json" % name)
    with contextlib.redirect_stdout(io.StringIO()):
        status = module.run_corpus(manifest, report, expect)
    s = json.load(open(report, encoding="utf-8"))["summary"]
    results[name] = {
        "exit": status, "verifications": s["verifications"], "agree": s["agree"], "disagree": s["disagree"],
        "binding_relevant_agree": s["binding_relevant"]["agree"], "binding_relevant": s["binding_relevant"]["verifications"],
        "strongest_cells_agree": s["strongest_cells_agree"], "strongest_cells": s["strongest_cells"],
        "binding_flips_go": len(s["binding_flips_go"]), "binding_flips_subset": len(s["binding_flips_subset"]),
        "reverse_flips_subset": len(s["reverse_flips_subset"]),
        "disagreements_by_group": {g: v["verifications"] - v["agree"] for g, v in s["groups"].items()},
        "disagreement_examples": s["disagreements"][:5],
    }
    print("%-18s %3d/%d agree, %d disagree; binding-relevant %d/%d; flips Go %d, subset %d (reverse %d)" % (
        name, s["agree"], s["verifications"], s["disagree"], s["binding_relevant"]["agree"], s["binding_relevant"]["verifications"],
        len(s["binding_flips_go"]), len(s["binding_flips_subset"]), len(s["reverse_flips_subset"])))
NOTE = ("POST-HOC sensitivity runs, not part of the frozen comparison: subset_verifier.py loaded unchanged and "
        "weakened in memory, one piece per run (see ablations.py), compared with the same frozen manifest")
json.dump({"note": NOTE, "manifest_sha256": expect, "runs": results},
          open(out_path, "w", encoding="utf-8"), indent=1)
