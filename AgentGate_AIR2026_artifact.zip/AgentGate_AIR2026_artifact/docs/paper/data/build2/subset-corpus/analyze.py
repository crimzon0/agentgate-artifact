"""Summarise one subset-corpus run (build 2).

Reads the corpus manifest (corpusgen) and the agreement report
(subset_verifier.py --corpus --out) and writes, next to this script:

  summary.json   headline counts with denominators, check-set comparison,
                 replay-on versus no-replay differences, flips per cell
  rows.csv       one row per verification (folder x anchor condition)
  flip_cells.csv the strongest-attacker cells at anchor condition none

Only file names and corpus-relative folders are written, never local paths.

usage: py analyze.py MANIFEST_JSON RESULT_JSON
"""
import collections
import csv
import json
import os
import sys

here = os.path.dirname(os.path.abspath(__file__))
manifest_path, result_path = sys.argv[1:3]
manifest = json.load(open(manifest_path, encoding="utf-8"))
result = json.load(open(result_path, encoding="utf-8"))
entries = {e["id"]: e for e in manifest["entries"]}
rows = result["rows"]
summary = result["summary"]

# 1. Per-row table, with Go assurance and the replay-on verdict (go_full).
table = []
for r in rows:
    e = entries[r["id"]]
    go_full = e.get("go_full", {}).get(r["anchors"], "")
    go_set = sorted(r["go_failing_subset_checks"])
    py_set = sorted(r["subset_failing_checks"])
    table.append({
        "id": r["id"], "group": r["group"], "design": r["design"], "operator": r["operator"],
        "keyset": r["keyset"], "variant": r["variant"], "anchors": r["anchors"],
        "go_verdict": r["go_verdict"], "go_assurance": e["expected"][r["anchors"]]["assurance"],
        "go_full_verdict": go_full, "subset_verdict": r["subset_verdict"], "agree": r["agree"],
        "go_failing_checks": " ".join(r["go_failing_checks"]),
        "go_failing_subset_checks": " ".join(go_set),
        "subset_failing_checks": " ".join(py_set),
        "check_sets_equal": go_set == py_set,
    })
with open(os.path.join(here, "rows.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(table[0].keys()))
    w.writeheader()
    w.writerows(table)

# 2. Check-set comparison on the rows Go fails (diagnostic only: each subset
# check is narrower than its Go namesake, so the sets need not match).
go_failed = [t for t in table if t["go_verdict"] == "FAILED"]
equal = [t for t in go_failed if t["check_sets_equal"]]
patterns = collections.Counter()
examples = {}
for t in go_failed:
    if t["check_sets_equal"]:
        continue
    go_set, py_set = set(t["go_failing_subset_checks"].split()), set(t["subset_failing_checks"].split())
    key = "Go only: %s | subset only: %s | design %s" % (
        ",".join(sorted(go_set - py_set)) or "-", ",".join(sorted(py_set - go_set)) or "-", t["design"])
    patterns[key] += 1
    examples.setdefault(key, []).append("%s @%s" % (t["id"], t["anchors"]))

# 3. Replay on versus off (Go only; the subset never replays).
replay_diff = [t for t in table if t["go_full_verdict"] and t["go_full_verdict"] != t["go_verdict"]]
replay_by = collections.Counter("%s %s/%s %s->%s" % (t["design"], t["operator"] or t["group"], t["keyset"] or "-",
                                                     t["go_verdict"], t["go_full_verdict"]) for t in replay_diff)

# 4. Go assurance per group and verdict.
assurance = collections.Counter("%s %s %s" % (t["group"], t["go_verdict"], t["go_assurance"]) for t in table)

# 5. Strongest-attacker cells at anchor none: detected when every applied
# variant is detected (as subset_verifier.strongest and agentgate-eval).
cells = {}
for t in table:
    if t["group"] != "mutant" or t["anchors"] != "none":
        continue
    c = cells.setdefault((t["operator"], t["keyset"], t["design"]), {"go": True, "subset": True, "variants": 0})
    c["go"] = c["go"] and t["go_verdict"] == "FAILED"
    c["subset"] = c["subset"] and t["subset_verdict"] == "FAILED"
    c["variants"] += 1
flip_rows = []
for op in manifest["operators"]:
    for ks in manifest["keysets"]:
        b, u = cells.get((op, ks, "bound")), cells.get((op, ks, "unbound"))
        if not b or not u:
            continue
        flip_rows.append({
            "operator": op, "keyset": ks, "variants_applied": b["variants"],
            "go_bound": "detected" if b["go"] else "evaded", "go_unbound": "detected" if u["go"] else "evaded",
            "subset_bound": "detected" if b["subset"] else "evaded", "subset_unbound": "detected" if u["subset"] else "evaded",
            "flip_go": b["go"] and not u["go"], "flip_subset": b["subset"] and not u["subset"],
        })
with open(os.path.join(here, "flip_cells.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(flip_rows[0].keys()))
    w.writeheader()
    w.writerows(flip_rows)

applied = [e for e in manifest["entries"] if e.get("applied")]
# The keys pin cannot change a verdict when no folder edits keys.json.
keys_same = collections.Counter("%s %s" % (e["group"], e["files_sha256"].get("keys.json") == manifest["bases"][e["design"]]["keys_sha256"])
                                for e in applied)
out = {
    "manifest": os.path.basename(manifest_path), "manifest_sha256": result["manifest_sha256"],
    "freeze_checked": result["freeze_checked"], "setting": result["setting"],
    "folders": {"clean": sum(e["group"] == "clean" for e in applied),
                "tamper-lab": sum(e["group"] == "tamper-lab" for e in applied),
                "mutant": sum(e["group"] == "mutant" for e in applied),
                "mutants_not_applicable": sum(not e.get("applied") for e in manifest["entries"])},
    "keys_json_equals_base_pin": dict(sorted(keys_same.items())),
    "unrepaired_notes": sorted({n for e in applied for n in (e.get("unrepaired") or [])}),
    "verifications": summary["verifications"], "agree": summary["agree"], "disagree": summary["disagree"],
    "binding_relevant_folders": summary["binding_relevant"], "binding_by_keyset": summary["binding_by_keyset"],
    "binding_keys_repeat": summary["binding_keys_repeat"], "other_rows": summary["other_rows"],
    "groups": summary["groups"],
    "strongest_cells": summary["strongest_cells"], "strongest_cells_agree": summary["strongest_cells_agree"],
    "binding_flips_go": summary["binding_flips_go"], "binding_flips_subset": summary["binding_flips_subset"],
    "reverse_flips_go": summary["reverse_flips_go"], "reverse_flips_subset": summary["reverse_flips_subset"],
    "binding_flips_same_at_keys_pin": summary["binding_flips_go_keys_pin"] == summary["binding_flips_go"]
    and summary["binding_flips_subset_keys_pin"] == summary["binding_flips_subset"],
    "disagreements": summary["disagreements"],
    "check_sets_on_go_failed": {"go_failed": len(go_failed), "subset_set_equals_go_restricted": len(equal),
                                "patterns": [{"pattern": k, "count": v, "examples": examples[k][:4]}
                                             for k, v in patterns.most_common()]},
    "replay_on_differs_from_no_replay": {"count": len(replay_diff), "of": len(table),
                                         "by": dict(sorted(replay_by.items()))},
    "go_assurance": dict(sorted(assurance.items())),
}
with open(os.path.join(here, "summary.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, indent=1)
    f.write("\n")
print(json.dumps({k: out[k] for k in ("verifications", "agree", "disagree", "binding_flips_go", "binding_flips_subset",
                                      "check_sets_on_go_failed", "replay_on_differs_from_no_replay", "go_assurance")}, indent=1))
