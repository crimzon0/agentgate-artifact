"""Extra provenance check (not part of the subset method): re-verify every
bound-design corpus folder with the FROZEN build-2 agentgate-verify binary,
full verifier (replay on), with the entry's simulated roles and the anchor
condition's pins, and compare the verdict with the manifest's go_full (which
corpusgen computed with auditverify compiled from the same source). The CLI
has no switch for the unbound design or for disabling policy.replay, so the
unbound folders and the no-replay expected outcomes cannot be re-run this way.

usage: py crosscheck_frozen_verify.py AGENTGATE_VERIFY_EXE CORPUS_DIR OUT_JSON
"""
import json, os, subprocess, sys
exe, corpus, out_path = sys.argv[1:4]
manifest = json.load(open(os.path.join(corpus, "manifest.json"), encoding="utf-8"))
rows, mismatches = [], 0
for e in manifest["entries"]:
    if not e.get("applied") or e["design"] != "bound":
        continue
    for cond in manifest["anchor_conditions"]:
        args = [exe, "--json"]
        if cond in ("keys", "both"):
            args += ["--expect-keys", e["anchors"]["keys"]]
        if cond in ("head", "both"):
            args += ["--expect-head", e["anchors"]["head"]]
        if e["assume_compromised"]:
            args += ["--assume-compromised", ",".join(e["assume_compromised"])]
        args.append(os.path.join(corpus, e["dir"]))
        p = subprocess.run(args, capture_output=True, text=True, encoding="utf-8")
        report = json.loads(p.stdout)
        same = report["verdict"] == e["go_full"][cond]
        mismatches += not same
        rows.append({"id": e["id"], "anchors": cond, "exit": p.returncode, "frozen_verdict": report["verdict"],
                     "frozen_assurance": report.get("assurance"), "manifest_go_full": e["go_full"][cond], "same": same})
result = {"binary": os.path.basename(exe), "verifications": len(rows), "same_verdict": len(rows) - mismatches,
          "mismatches": [r for r in rows if not r["same"]], "rows": rows}
json.dump(result, open(out_path, "w", encoding="utf-8"), indent=1)
print("frozen agentgate-verify vs manifest go_full (bound design, replay on): %d of %d verdicts equal" % (len(rows) - mismatches, len(rows)))
