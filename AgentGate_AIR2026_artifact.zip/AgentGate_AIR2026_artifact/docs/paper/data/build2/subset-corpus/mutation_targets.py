"""Which operation each mutant edits (diagnostic). For every mutant folder,
the first audit entry that differs from its base run (every later entry
differs too, through prev_hash), the POLICY_DECISION whose stated
classification it changes (the target), and what the base
run says about that operation: flagged, replayed COMMITTED answers, a
RECONCILED record. Writes mutation_targets.csv next to this script; only
corpus-relative folder names are written.

usage: py mutation_targets.py CORPUS_DIR
"""
import csv, json, os, sys
corpus = sys.argv[1]
here = os.path.dirname(os.path.abspath(__file__))
manifest = json.load(open(os.path.join(corpus, "manifest.json"), encoding="utf-8"))

def load(folder):
    return [json.loads(line)["entry"] for line in open(os.path.join(corpus, folder, "audit.jsonl"), encoding="utf-8")]

bases = {d: load(manifest["bases"][d]["dir"]) for d in manifest["bases"]}
facts = {}
for design, entries in bases.items():
    for e in entries:
        op = e.get("operation_id")
        if not op:
            continue
        f = facts.setdefault((design, op), {"flagged": False, "replayed_answers": 0, "reconciled": False})
        det = e.get("details") or {}
        if e["stage"] == "POLICY_FINAL" and det.get("flagged"):
            f["flagged"] = True
        if e["stage"] == "CALL_RESULT" and det.get("replayed"):
            f["replayed_answers"] += 1
        if e["stage"] == "RECONCILED":
            f["reconciled"] = True
rows = []
for e in manifest["entries"]:
    if e["group"] != "mutant" or not e.get("applied"):
        continue
    base, mutant = bases[e["design"]], load(e["dir"])
    first = next((b for b, m in zip(base, mutant) if b != m), None)
    # The snapshot variants also rewrite run.json (whose hash RUN_STARTED
    # carries) and restate the policy hash in every decision, so their first
    # changed entry is seq 1. The target is the POLICY_DECISION whose stated
    # classification (flagged or reasons) differs from the base run.
    target = None
    for b, m in zip(base, mutant):
        if b["stage"] != "POLICY_DECISION":
            continue
        db, dm = b.get("details") or {}, m.get("details") or {}
        if db.get("flagged") != dm.get("flagged") or db.get("reasons") != dm.get("reasons"):
            target = b
            break
    f = facts.get((e["design"], target.get("operation_id"))) if target else None
    rows.append({"folder": e["dir"], "design": e["design"], "operator": e["operator"], "keyset": e["keyset"], "variant": e["variant"],
                 "first_changed_seq": first["seq"] if first else "", "first_changed_stage": first["stage"] if first else "",
                 "target_seq": target["seq"] if target else "", "target_stage": target["stage"] if target else "",
                 "target_operation": (target.get("operation_id") or "")[:12] if target else "",
                 "target_effect_type": target.get("effect_type", "") if target else "",
                 "base_flagged": f["flagged"] if f else "", "base_replayed_answers": f["replayed_answers"] if f else "",
                 "base_reconciled": f["reconciled"] if f else ""})
with open(os.path.join(here, "mutation_targets.csv"), "w", newline="", encoding="utf-8") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(rows)
summary = {}
for r in rows:
    key = (r["operator"], r["target_stage"], r["base_flagged"], r["base_replayed_answers"], r["base_reconciled"])
    summary[key] = summary.get(key, 0) + 1
for k, v in sorted(summary.items(), key=str):
    print(v, "operator=%s target_stage=%s base_flagged=%s replayed_answers=%s reconciled=%s" % k)
