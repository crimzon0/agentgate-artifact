# Baselines, load, per-stage cost and witness push on build 3 (R6.8, review 5 item 1)

Session 2026-10-20 18:30:17-18:54:02 UTC on **frozen build 3** (commit
`8a30fd4`, reproducible binaries, `agentgate-eval` SHA-256
`cc4b9613...6e768e`, manifest `0c436fc9...6968eb`, see `build-manifest.txt`),
after every other build-3 experiment had written its results. This is the only
build-3 experiment whose times are results. The build-2 method
(`../../build2/baseline/RESULTS.md`, itself build 1's) is repeated exactly:
same scripts (copied unchanged into `tools/`), sizes, seed, resamples and
analysis. A location diagnostic (section 10) was added afterwards to explain a
difference; it is not a headline.

**Headline.** Six runs (five financial R1-R5, one message M1): **0 of 62,500
measured calls and 0 of 4,100 warm-up calls failed; 230/230 evidence folders
ANCHORED with no failing check** (and 230/230 VERIFIED by the standalone
build-3 verifier, none with an unresolved operation). Per call (primary run
R2, paired medians over 500 trials with block-level 95 % intervals): mediation
**3.14 ms [3.05, 3.25]**, signed durable recording **11.77 ms [11.53,
11.95]**, total **14.95 ms [14.73, 15.30]**. Full recording levels off at
**88.2 calls/s** (median of the 15 cells at 4-16 clients) with 1.1 cores busy;
by Little's law its mean latency at 16 clients in R2 is 16 / 92.7 s = 172.6 ms
(observed 170.3 ms). One durable append costs 1.75 ms on average, 70 % of it
replacing `head.json`, 25 % the fsync of `audit.jsonl`, 4.7 % encoding,
hashing and signing; six appends are 87 % of the 11.77 ms. A witness push
would add about 2.2 ms per call (one push per call) or 10.6 ms (one per entry);
**no reported latency includes one**, and enrollment adds nothing per push.

**Against build 2** (11.29 ms, 92.5 calls/s): recording **+0.48 ms (+4 %)**,
full saturation **−4.6 %**, full at 1 client −10 %, journal +0.34 ms; mediation,
CPU-bound throughput, allocation, memory and evidence unchanged. **None of it is
new code**: every source file on the timed path is byte-identical to build 2,
and the stage-test binary is byte-identical to build 2's yet shows appends
**3 % slower today**. The machine changed: Microsoft Defender's platform was
updated on 2026-10-15, system CPU during the sequential phase rose from
2.5-3.2 to 4.1-5.2 cores (Defender alone 2.0-3.2 cores in the diagnostic), and
there were more drive slowdowns. Ten runs of the same build-3 binary today give
recording medians of **11.27-12.03 ms**; one of them (11.27 ms, 92-94 calls/s
at 4-16 clients) matches build 2 (sections 9 and 10).

## 1. What was run

Everything from the repository root; `<repo>`, `<work>` (=
`<repo>/.tools/build3-work`) and `<singlebuild3>` stand for local paths.
Hashes, idle checks and the timeline are in `build-manifest.txt`.

```bash
# before and after: py <singlebuild3>/check_manifest.py   -> "checked 1870 files, 0 differ" (18:28:31Z, 18:55:28Z, and 19:11:57Z after the diagnostic)
# source: HEAD = 8a30fd4; git diff 8a30fd4 --stat -- internal cmd go.mod go.sum   -> empty
# test binaries (the stage and witness measurements are test-only), compiled before the idle check, same command as build 2:
go test -c -o <work>/baseline/testbin/audit.test.exe ./internal/audit/              # 31251d66...47a63bd = build 2's binary, byte for byte
go test -c -o <work>/baseline/testbin/headwitness.test.exe ./internal/headwitness/  # d9b12802...309a82 (package changed: enrollment)
# the whole session, one step after another (build 2's run_session.sh, unchanged):
EVAL=<singlebuild3>/bin/agentgate-eval.exe TESTBIN=<work>/baseline/testbin REPO=<repo> HOST_LABEL=review-host \
  bash docs/paper/data/build3/baseline/tools/run_session.sh <work>/baseline/session
#   1. tools/drive_runs.sh -> tools/run_baseline.sh (typeperf + process snapshots):
#        R1..R5: agentgate-eval -host-label review-host baseline -out <session>/runs/Rn -work <session>/work/Rn
#        M1:     agentgate-eval -host-label review-host baseline -out <session>/runs/M1 -work <session>/work/M1 \
#                  -workload message -configs direct,policy-only,full,full+journal
#   2. agentgate-eval -host-label review-host cost -n 2000 -batches 5 -repeat 20 -out <session>/cost -work <session>/cost-work
#   3. tools/run_stagecost.sh: in internal/audit, three times (run1..run3) and once on R3's replayed full evidence (run-corpus):
#        audit.test.exe -test.count=1 -test.v -test.run '^TestStageCost$' -stagecost=10000 -stagecost.warmup=200 \
#          -stagecost.work=<dir> -stagecost.out=<run> [-stagecost.corpus=<session>/work/R3/baseline-c16-full/run]
#      in internal/headwitness, three times (run1..run3):
#        headwitness.test.exe -test.count=1 -test.v -test.run '^TestWitnessPushCost$' -witnesspush=2000 -witnesspush.warmup=50 -witnesspush.out=<run>
#      audit.test.exe -test.run '^$' -test.bench AppendStageCPU -test.benchmem
# after the timed session:
py docs/paper/data/build3/baseline/verify_evidence.py <singlebuild3>/bin/agentgate-verify.exe <work>/baseline/session/work  # new: evidence-standalone.json
py docs/paper/data/build3/baseline/analyze_baseline.py   # build 2's script + a build-2 comparison block; seed 20261007, 10,000 resamples
py docs/paper/data/build3/baseline/compare_builds.py     # comparison-builds.csv (builds 1, 2, 3; build 2's compare_build1.py plus a column)
py docs/paper/data/build3/baseline/slow_calls.py         # slow-calls.json (build 2's script; primary label only)
py docs/paper/data/build3/baseline/stage_summary.py      # stagecost/summary.csv (build 2's script; wording only)
# diagnostic (section 10; new, not a headline):
EVAL=... TESTBIN=... REPO=<repo> HOST_LABEL=review-host bash docs/paper/data/build3/baseline/tools/run_location_ab.sh <work>/baseline/diag <scratchpad>/diag-work
py docs/paper/data/build3/baseline/diag_summary.py       # diagnostic/location-ab.json
```

Method (unchanged since build 1): one JSON-RPC transport over loopback and the
same simulated provider (own listener and Ed25519 key, same process, a fresh
TCP connection per provider request) for every configuration: **direct**
(normalizer, `adapters.Prepare`, adapter transport and receipt check; a lower
bound, not a secure alternative), **policy-only** (gateway with policy, grant,
capability and signed receipts; no audit, no journal), **full** (plus the
signed hash-chained audit log, fsync per entry, `head.json` replaced through a
synced temporary file), **full+journal** (plus the fsynced operation journal),
**full-flagged** (full with an AED 6,000.00 payment that FIN-APPROVAL-LIMIT
flags). Sequential: 500 paired trials in 10 blocks of 50, 10 warm-up calls per
configuration and block, order rotated by one position per trial. Concurrent:
closed-loop clients 1, 2, 4, 8, 16, 400 calls per cell, each configuration
alone. Every call is kept. Intervals: bootstrap over trials and, as the
headline, **over the 10 blocks** (cluster bootstrap).

Idle machine: before the session `tasklist` showed no agentgate, go, compile,
link, go-build, python, py, typeperf or test process (18:30:12Z; every other
build-3 experiment had finished), and `tools/watch_procs.ps1` (every 5 s, 547
samples) saw only the session's own binaries, never two at once. No attempt was
discarded. Desktop load in the 5 s snapshots around each run: 0.07-1.27 logical
cores without the shells and the logger, mostly a browser (build 2:
0.36-0.50, mostly coding agents). The snapshots cannot see protected or SYSTEM
processes (Defender, the search indexer); section 9 measures those. **R2 is
primary** by build 1's rule (lowest snapshot load, 0.156 cores; others
0.23-0.67). Every key number also gives the R1-R5 range.

## 2. Paired added latency per call (R2 medians, block-level 95 % CI; ms)

Population: 500 paired trials of R2 (10 blocks x 50), every measured call.

| difference | median | block 95 % CI | trial 95 % CI | range R1-R5 | mean [block CI] |
|---|---|---|---|---|---|
| mediation (policy-only − direct) | **3.14** | [3.05, 3.25] | [3.09, 3.21] | 3.13-3.20 | 3.26 [3.13, 3.42] |
| signed durable recording (full − policy-only) | **11.77** | [11.53, 11.95] | [11.61, 11.89] | 11.71-12.03 | 12.36 [11.80, 13.26] |
| total (full − direct) | **14.95** | [14.73, 15.30] | [14.85, 15.12] | 14.95-15.22 | 15.62 [14.94, 16.67] |
| operation journal (full+journal − full) | 3.77 | [3.54, 3.89] | [3.54, 3.89] | 3.63-3.77 | 3.80 [3.58, 4.07] |
| flagging (full-flagged − full) | 0.22 | [0.07, 0.38] | [0.07, 0.35] | 0.09-0.22 | −0.02 [−0.90, 0.61] |
| everything (full+journal − direct) | 18.70 | [18.37, 19.11] | [18.50, 18.83] | 18.61-18.99 | 19.42 [18.76, 20.35] |

Medians of different rows do not add (each is the median of its own per-trial
differences); means do (3.26 + 12.36 = 15.62). 3.14 + 11.77 = 14.91 is close to
14.95 only because the distributions are narrow.

**Flagging changed sign.** Flagged calls were now slower in all five runs
(+0.09 to +0.22 ms; all five block intervals exclude zero) and in all four
diagnostic runs (+0.19 to +0.29); in build 2 they were faster (−0.07 to −0.19),
in build 1 more so (−0.15 to −0.32). The flagged path's code is byte-identical
in builds 2 and 3. As before, the rotation balances positions but not
predecessors (full-flagged follows full+journal in 400 of 500 trials), so the
sign follows the disk's carry-over from the journal's extra durable writes, not
the flag. Say "flagging added no measurable latency (within about 0.4 ms, 2.5 %
of a full call, either way, across three builds)".

Message workload (M1): mediation 3.34 [3.27, 3.43], recording 11.97
[11.66, 12.28], total 15.29 [14.95, 15.58], journal 3.69 [3.56, 3.82] (block
intervals).

## 3. Sequential latency per configuration (R2, 500 calls each, nothing removed; ms)

| config | p50 | p95 | p99 | max | range R1-R5: p50 / p99 / max |
|---|---|---|---|---|---|
| direct | 1.29 | 1.74 | 2.04 | 3.05 | 1.29-1.32 / 1.99-2.14 / 2.30-4.23 |
| policy-only | 4.45 | 5.60 | 6.32 | 31.22 | 4.45-4.52 / 6.17-6.82 / 6.41-31.22 |
| full | 16.31 | 19.51 | **21.86** | 163.89 | 16.31-16.52 / 20.71-101.48 / 22.18-163.89 |
| full+journal | 20.01 | 23.99 | 27.33 | 177.19 | 19.93-20.27 / 26.35-71.79 / 36.45-366.01 |
| full-flagged | 16.56 | 19.83 | 25.25 | 44.35 | 16.50-16.70 / 21.51-56.98 / 24.96-151.02 |

R2 has no sequential disk slowdown (9 calls over 30 ms, 5 over 42 ms, among
them one policy-only call of 31.2 ms, the first call of trial 486; the rest
durable). Runs without a sequential slowdown (R1, R2, R3, R5): full p99
20.71-24.29 ms (build 2: 20.33-20.54). R4's blocks 1-3 coincide with a slowdown
(section 6): full p95/p99 50.3/101.5 ms. M1: direct 1.41 / 1.95 / 2.20 / 2.52,
policy-only 4.78 / 6.23 / 7.02 / 8.17, full 16.72 / 20.23 / 21.88 / 35.02,
full+journal 20.54 / 24.13 / 26.47 / 46.85.

## 4. Throughput, saturation and Little's law (calls/s, median of R1-R5 [min-max])

Population: one cell of 400 measured calls per configuration, client count and
run.

| clients | direct | policy-only | full | full+journal |
|---|---|---|---|---|
| 1 | 920 [828-1,007] | 235 [211-243] | 56.5 [48.7-60.4] | 48.4 [39.6-49.4] |
| 2 | 1,647 | 404 | 78.4 [59.0-83.4] | 68.7 [36.9-71.0] |
| 4 | 2,348 | 607 [484-621] | 88.2 [**46.6**-88.7] | 81.1 [**38.9**-83.4] |
| 8 | 2,794 | 690 | 91.4 [**46.6**-92.3] | 82.4 [71.1-84.8] |
| 16 | 3,085 [2,420-3,255] | 742 | 86.3 [**46.8**-92.7] | 80.3 [**39.2**-85.1] |

The bold minima are R3's disk slowdown (section 6). CPU-bound cells vary more
than in build 2 (direct down to −22 % of the median, build 2 within 6 %),
consistent with more background CPU (section 9).

- **Saturation point: 4 clients.** Full recording levels off at **88.2
  calls/s** (pooled median of the 15 cells at 4-16 clients; the cells outside
  R3's slowdown span 76.9-92.7, mostly 84.7-92.7); at 2 clients 78.4, 89 % of
  it; 1.1 cores busy (median at 16 clients 1.14; 0.56-1.40 over the 15 cells).
  full+journal levels off at 81.1. policy-only is CPU-bound (5.25 cores at 16
  clients, 4.41-6.35); direct reaches 6.07.
- **Why it saturates** (unchanged): one audit log per gateway, appends
  serialized by one mutex, an fsync of `audit.jsonl` and a synced replacement
  of `head.json` per entry, six entries per call, no group commit. The mean
  append of the quoted stage run (1,751 us, section 5) gives 6 x 1.751 =
  10.5 ms of serialized disk work per call, a ceiling of 95.2 calls/s; the
  observed 88.2 means 11.3 ms per call, so the standalone appends explain
  about 93 % of it (build 2: 94 %); the remaining ~0.8 ms per call is not
  measured here.
- **Little's law** (L = X x W, means, closed loop): full at 16 clients in R2:
  16 / 92.70 = 172.6 ms against an observed mean of 170.3 ms (p50 171.2). In
  every full and full+journal cell of every run (M1 included, slowed cells
  included) N / X and the observed mean agree within 1.7 %. Full's median
  latency (median of five runs) is 17.1 ms at 1 client, 24.4 at 2, 44.4 at 4,
  86.1 at 8 and 176.7 at 16, about N x 11 ms.
- **Latency under load** (ms, median of the five runs, p50 / p95 / p99 / max):
  1 client: direct 1.00 / 1.37 / 1.63 / 1.81, policy-only 4.15 / 4.87 / 5.82 /
  6.65, full 17.12 / 21.54 / 24.58 / 36.36, full+journal 20.13 / 23.82 /
  25.96 / 39.92; 16 clients: direct 5.06 / 6.17 / 8.32 / 9.92, policy-only
  21.47 / 26.28 / 34.58 / 37.58, full 176.65 / 211.96 / 238.28 / 266.52,
  full+journal 191.19 / 219.73 / 330.25 / 353.46. Every cell is in
  `analysis.json` and the `baseline-concurrent-summary.csv` files.
- **CPU per call** (1 client, whole process including kernel time, median of
  the five runs [min-max]): direct 1.52 [1.37-2.15], policy-only 6.09
  [5.12-6.45], full 13.48 [11.21-16.09], full+journal 13.63 [12.50-15.82] ms.
  `GetProcessTimes` advances in 15.6 ms ticks. Full's kernel time per call is
  unchanged (median 5.1 ms, build 2 4.8); its user time rose (8.4 versus
  6.5 ms); not resolved here.
- Message workload (M1): direct 963 → 2,982 calls/s, policy-only 231 → 720,
  full 59.1 at 1, 85.7 at 2, 90.6 at 8 clients (45.5 at 4 and 45.4 at 16: disk
  slowdowns), full+journal 46.7 at 1, 63.3 at 2 (38.8-41.1 at 4-16: slowdown).

## 5. Per-stage cost of a durable append and its relation to the 11.77 ms

`TestStageCost` (method: build 1's `STAGE_COST.md`; **the test binary is
byte-identical to build 2's**) splits every `audit.Append` into its stages,
timed with QueryPerformanceCounter, paired entry by entry with an
uninstrumented `Append` on a second fresh log; 200 warm-up and 10,000 timed
appends per path, synthetic six-entry financial call (mean line 2,133 bytes).
Uninstrumented appends over 10 ms: **run1 0**, run2 2, run3 8 of 10,000, so
**run1 is quoted**. `Append` medians of the three runs: 1,690.2-1,772.9 us
(means 1,751.3-1,886.7; build 2: 1,641.0-1,653.9 and 1,699.7-1,713.6).

| group (stages) | median us | p99 us | mean us | share of the mean |
|---|---|---|---|---|
| encode + hash (encode entry, decode copy, SHA-256, line, bookkeeping, head JSON, head digest) | 39.9 | 86.0 | 42.7 | 2.4 % |
| Ed25519 signing (entry, head) | 37.3 | 69.6 | 40.3 | 2.3 % |
| log line write (O_APPEND) | 8.7 | 54.3 | 10.8 | 0.6 % |
| **log fsync** (`audit.jsonl`, FlushFileBuffers) | 407.1 | 765.2 | 434.3 | **24.7 %** |
| temp head write (create, write, close) | 201.2 | 296.9 | 209.2 | 11.9 % |
| **head fsync** (temporary `head.json`) | 727.2 | 1,322.5 | 770.9 | **43.9 %** |
| head rename (MoveFileEx, replace) | 235.4 | 365.4 | 249.2 | 14.2 % |
| directory fsync | 0.1 | 0.3 | 0.1 | 0.0 % (none on Windows) |
| staged total | 1,691.4 | 2,641.4 | 1,757.5 | 100 % |
| `Append`, uninstrumented | 1,690.2 | 2,633.6 | 1,751.3 | |

- **Where the time goes** (same shares as build 2 within 0.3 points): the two
  fsyncs are 68.6 % of an append; the whole `head.json` replacement 69.9 %
  (about 1.23 of 1.76 ms); CPU work (encoding, hashing, signing) 4.7 %.
  Directory fsync: none on Windows (`syncDir` returns at once); rename
  durability rests on NTFS metadata logging and is not tested here.
- **Relation to the recording median.** The median of the sums of six
  consecutive appends is **10.24 ms** (run1-run3: 10.24-10.81), **87 %** of
  11.77 ms (build 2: 9.95 ms, 88 % of 11.29). About 1.5 ms of the recording
  cost is spent outside `Append` (the gateway building the six events). The
  two figures come from different measurements, so this is approximate.
- **Staged versus uninstrumented:** medians 1,691.4 versus 1,690.2 us, means
  1,757.5 versus 1,751.3 (0.4 %).
- **Replayed baseline entries** (run-corpus: R3's `baseline-c16-full`, 2,462
  events, mean line 2,083 bytes): `Append` median 1,716.4 us, mean 1,784.2,
  shares within 0.4 points of run1.
- **Cross-check with `agentgate-eval cost`** (2,986 entries of a fresh 20-suite
  self-test run, mean line 1,625 bytes; median of 5 batch means): durable
  1,761.0 us per entry versus the `Append` mean 1,751.3 (+0.6 %). The split
  agrees less well than in build 2: no-fsync 701.0 us (build 2: 515.2), so
  no-fsync − sign-only 647.8 us versus log write + temp head write + rename
  469.2 us (+38 %; build 2 +0.4 %), and durable − no-fsync 1,059.9 versus the
  two fsyncs 1,205.2 (−12 %; build 2 −4 %). Without flushes the file
  operations of the cost tool now cost more; the durable totals still agree.
- **CPU-only stages** (`BenchmarkAppendStageCPU`, largest synthetic entry):
  encode 5.0 us, 11.3 KB, 21 allocations; decode copy 18.7 us, 19.7 KB, 58;
  SHA-256 1.7 us; Ed25519 entry 15.9 us and head 16.0 us; head JSON 1.6 us,
  1.5 KB; about 33 KB allocated per append. The same binary as build 2 ran
  these 1-24 % faster (build 2: 5.3 / 20.5 / 1.9 / 16.0 / 16.1 / 2.1 us): the
  CPU is not slower; the disk path is.
- **What an optimization may not change** (unchanged): group commit, one
  `head.json` replacement per call, or an in-place head update would attack
  the 70 % head share, but each must still flush a recorded step before that
  step creates authority (persistence before authority, R4).

## 6. Disk slowdowns (kept in the data)

Per-second typeperf logs (`load/system-load.csv`, `session-logs/
stagecost-load.csv`; `slow-calls.json` counts the calls). Seconds with a mean
write time over 0.15 ms, merged:

- **R4 sequential, blocks 1-3** (18:37:00-18:37:17 UTC; mean write time up to
  2.7 ms, writes down to 617/s): 166 durable calls over 30 ms (164 over
  42 ms; full 57, full+journal 66, full-flagged 43); the recording median
  stays 11.85 ms, the mean rises to 16.6 ms; sequential phase 45 s instead of
  38 s.
- **R3 concurrent** (18:35:31-18:36:45 UTC, 58 s over the threshold): full at
  2, 4, 8, 16 clients 59.0, 46.6, 46.6, 46.8 calls/s; full+journal at 2, 4, 16
  clients 36.9, 38.9, 39.2.
- **M1 concurrent** (18:42:03-18:43:03 UTC): full at 4 and 16 clients 45.5 and
  45.4; full+journal at 4, 8, 16 clients 38.8, 41.1, 39.0.
- R1 (18:31:06-18:31:09, write time 4.7 ms) and R2 (four 1-2 s events): a few
  single calls only (R1 5, R2 9 over 30 ms).
- Stage and witness window: one 31 s period during the cost run (18:43:13-
  18:43:46) and a long stretch at about 1,100 writes/s with write times up to
  0.95 ms during witness runs 1 and 2 (18:46:40-18:50:11); the four stage runs
  and witness run 3 had none.

Build 2 saw four such periods in its baseline runs (R2, R3, R4, M1), build 1
fewer. The drive
is at the same fill level as in build 2 (97.5 %). The cause is not
established (consistent with drive-internal housekeeping on a nearly full
consumer SSD, or with the heavier antivirus load of section 9).

## 7. Witness update cost (not in any reported latency)

`TestWitnessPushCost` (build-3 test binary): a witness in a test temporary
folder, served over loopback in the test process; two durable logs, each
**registered once with a registration signed by the gateway enrollment key
before timing** (new in build 3: the witness refuses unsigned registrations);
50 warm-up and 2,000 timed calls per mode, alternating (mean line 2,107
bytes). A push is timed at the client (HTTP round trip, the witness's checks
of head and lines, cosignature, store fsync); saving the cosigned head
(`WriteJSONAtomic`) is a separate row. Run 3 had no disk slowdown; runs 1 and 2
overlapped the slow stretch of section 6, which inflates their means and tails.

| row | median ms (run1 / run2 / run3) | mean ms (run1 / run2 / run3) | p99 ms run3 |
|---|---|---|---|
| push per call (head + 6 lines) | 1.26 / 1.22 / 1.21 | 1.73 / 1.45 / 1.26 | 1.81 |
| save per call | 1.12 / 1.05 / 0.93 | 1.47 / 1.22 / 0.96 | 1.33 |
| push per entry (head + 1 line) | 0.82 / 0.79 / 0.78 | 1.27 / 1.02 / 0.82 | 1.25 |
| save per entry | 1.11 / 1.04 / 0.91 | 1.46 / 1.20 / 0.95 | 1.35 |
| six per-entry pushes and saves, summed per call | 11.95 / 11.33 / 10.28 | 16.36 / 13.31 / 10.59 | 14.69 |

Waiting for one witness update per call would add the mean push plus save,
about **2.2 ms per call** (run 3: 1.26 + 0.96; about 14 % of a 16.3 ms full
call; build 2: 2.4 ms); one update per entry about **10.6 ms** (build 2:
11.3), roughly doubling the recording cost. **Enrollment has no per-push
cost**: the push path (`POST /heads`) did not change in build 3; enrollment
signs and checks the registration once per run, outside the timed loop. The
bench client is not pinned (`NewClient(server.URL)`), so the one extra Ed25519
verification of the cosigned head that a pinned gateway client
(`WithPinnedWitness`, as the demo uses) performs per push is not in these rows
(the CPU-only benchmark puts one Ed25519 operation at about 16 us for signing;
verification was not timed). **No latency in this report or the paper includes
a push**: the baseline runs no witness (`cmd/agentgate-eval/baseline.go`,
byte-identical in builds 1-3).

## 8. Storage configuration, memory, evidence

- **Storage** (every run, `<work>`, the scratchpad, the test temporary
  folders): KINGSTON SNV2S2000G, 2 TB consumer NVMe SSD (firmware SBM02103,
  health OK); C: NTFS, **cluster 4,096 bytes**, 1,862.4 GiB, **47.3 GiB free
  (97.5 % full)** at the start, 46.1 GiB at the end (build 2: 47.9, 97.4 %);
  compression off, volume indexing on. **New: the evidence folders are in
  `<repo>/.tools/build3-work`, which Windows Search indexes**; builds 1 and 2
  wrote them to the session scratchpad under `%LOCALAPPDATA%\Temp`, which it
  does not (SystemIndex SCOPE query; section 10). **Device write-cache
  setting: not determinable without administrator rights**
  (`Get-StorageAdvancedProperty`: "failed with ErrorCode 40001"). Microsoft
  Defender real-time protection on, unchanged by us; **platform 4.18.26090.9,
  installed 2026-10-15** (build 2 ran on 4.18.26080.4); exclusions not
  readable. Directory fsync: none on Windows.
- **Allocation volume is not resident memory.** A call allocates about 423
  KiB (direct), 2,681 (policy-only), 3,040 (full) and 3,063 KiB
  (full+journal) (1 client, median of five runs); a sequential phase
  allocates 7.50 GiB, all short-lived. Peak working set of the whole process
  **≤ 87.6 MiB**, peak Go heap ≤ 49.1 MiB; sequential phase peak working set
  57.2-58.9 MiB with 0.65-0.80 cores busy. The append itself allocates about
  33 KB per entry.
- **Evidence and the build-3 verifier.** The baseline verifies each folder in
  process with the keys fingerprint and final head pinned and stores the
  assurance and failing checks: 230/230 ANCHORED, none failing (200 financial,
  30 message; 34,800 durable operations, 209,260 entries). The standalone
  build-3 `agentgate-verify --json` (no pins: nothing pinned survives the run)
  gives 230/230 VERIFIED, CONSISTENT, structural, decisions_authenticated
  (including the new capability `cnf` = adapter key rule on every capability),
  policy_replayed, provider_reconciled and delegation_respected pass in all
  230; **no Missing entry of kind `unresolved` and no pending operation**, so
  the build-3 rule "pending or unresolved is always incomplete" changes
  nothing here; `head_fresh` and `run_complete` are not_checked (no witness
  status), as expected for a baseline that runs no witness; the witness
  linkage, earlier-segment keys and enrollment rules are not exercised (one
  segment, no witness). `evidence-standalone.json` has every folder.

## 9. Comparison with builds 2 and 1 (review 5, item 1)

Build 1 = 2026-10-08 session, primary R3 (`../../revision/baseline/`); build 2
= 2026-10-10, primary R2 (`../../build2/baseline/`); build 3 = this session,
primary R2. Same scripts, seed and resamples; `comparison-builds.csv` has
every row. Units and populations as in sections 2-5: paired medians over the
primary run's 500 trials with block CIs (range over R1-R5); saturation =
median of the 15 full cells at 4-16 clients over R1-R5 (400 calls each).

**What changed between builds 2 and 3 on the timed path: nothing.** `git diff
86643d7 8a30fd4` has no change in `internal/devcomposition`, `internal/audit`
or any other package `go list -deps` lists for them (adapters, capability,
devapproval, effects, mcp, opjournal, signed, simulator, ...), nor in
`cmd/agentgate-eval/baseline.go`, `harness.go`, `resources.go`, `cost.go`.
What changed: `internal/auditverify` (runs after the timed calls),
`internal/headwitness` and `cmd/agentgate-eval/custody.go` (not used by the
baseline), and how the binary was built (reproducible: `-trimpath`, no VCS
stamp or build ID, `CGO_ENABLED=0`, vendored modules). The stage-test binary is
byte-identical to build 2's.

**What changed on the machine** between 2026-10-10 and 2026-10-20: Defender
platform 4.18.26080.4 → 4.18.26090.9 (2026-10-15); system CPU during the
sequential phase (eval about 0.7 cores) 2.5-3.2 cores in builds 1-2 versus
4.1-5.2 now; in the diagnostic, MsMpEng (Defender) alone used **2.0-3.2 cores**
whenever durable appends ran (0.02 at idle), the search indexer 0.0-1.05;
more drive slowdowns; the evidence location (indexed now); the desktop
(a browser instead of coding agents). Build 1 → 2 had no code change on the
timed path either (build 2's section 9).

| measure | build 1 | build 2 | build 3 | change 2 → 3 | cause |
|---|---|---|---|---|---|
| mediation, ms (block CI) (R1-R5) | 3.32 [3.25, 3.37] (3.22-3.33) | 3.18 [3.13, 3.25] (3.10-3.19) | 3.14 [3.05, 3.25] (3.13-3.20) | −0.04 | none (ranges overlap) |
| signed durable recording | 11.40 [11.35, 11.47] (11.33-11.58) | 11.29 [11.19, 11.43] (11.29-11.57) | **11.77 [11.53, 11.95] (11.71-12.03)** | **+0.48 (+4 %)** | machine state, not code. Same-binary stage test: append median +2.7 %, mean +3.0 % (6 appends ≈ +0.27-0.31 ms); ten runs of the build-3 binary today span 11.27-12.03 (diagnostic T1 = 11.27, build 2's value) |
| total (full − direct) | 14.69 [14.64, 14.75] | 14.46 [14.39, 14.54] | 14.95 [14.73, 15.30] (14.95-15.22) | +0.49 | the recording shift |
| operation journal | 3.20 [3.15, 3.29] | 3.43 [3.23, 3.57] | 3.77 [3.54, 3.89] (3.63-3.77) | +0.34 | machine state (the journal is one more fsynced write; `opjournal` unchanged); diagnostic 3.60-3.92 |
| everything (full+journal − direct) | 17.84 [17.75, 17.91] | 17.87 [17.74, 18.03] | 18.70 [18.37, 19.11] | +0.83 | the two shifts above |
| flagging | −0.27 [−0.36, −0.18] | −0.07 [−0.13, 0.01] | +0.22 [0.07, 0.38] (0.09-0.22) | +0.29 | carry-over of the rotated order (same code in 2 and 3); claim widened to "within about 0.4 ms" |
| sequential p50, full / full+journal | 15.94 / 19.08 | 15.72 / 19.14 | 16.31 / 20.01 | +0.59 / +0.87 | as recording and journal |
| sequential p99, full (primary; clean runs) | 20.38 (20.31-21.60) | 68.42 (20.33-20.54) | 21.86 (20.71-24.29) | −46.6 (+0.4 to +3.8 clean) | build 2's primary had a slowdown, build 3's has none; clean-run tails are 2-18 % longer now |
| full saturation, 4-16 clients | 94.3 calls/s | 92.5 | **88.2** | **−4.6 %** | machine state: same `audit.go`; serial ceiling from the mean append 98 → 95.2 calls/s; R3's slowdown cells and lower steady cells (84.7-92.7). Diagnostic T1: 92-94 calls/s at 4-16 clients with this binary |
| full+journal saturation | 87.1 | 88.0 | 81.1 | −7.8 % | as above, one more fsynced file |
| full at 1 client | 62.5 [48.1-63.1] | 62.7 [62.5-62.9] | 56.5 [48.7-60.4] | −10 % | machine state (build 1 had 48-52 in two runs too); diagnostic 55.7-61.0 |
| direct / policy-only at 16 clients | 3,029 / 706 | 3,006 / 706 | 3,085 / 742 | +2.6 % / +5.1 % | CPU-bound paths not slower (the CPU-only benchmark is 1-24 % faster on the same binary) |
| full latency at 16 clients, p50 | 168.8 ms | 172.1 | 176.7 | +4.5 | follows throughput (Little's law) |
| CPU per call, 1 client (direct / policy-only / full / full+journal) | 1.48 / 5.43 / 11.45 / 12.62 | 1.80 / 6.02 / 11.25 / 12.77 | 1.52 / 6.09 / 13.48 / 13.63 | −0.3 / +0.1 / +2.2 / +0.9 | full: user time +1.9 ms, kernel time unchanged; not resolved (15.6 ms ticks; wider spread 11.2-16.1) |
| allocation per call, 1 client (KiB) | 422 / 2,681 / 3,045 / 3,076 | 420 / 2,678 / 3,046 / 3,072 | 423 / 2,681 / 3,040 / 3,063 | none | same code |
| peak heap / working set (MiB) | ≤ 48.1 / ≤ 87.0 | ≤ 48.3 / ≤ 86.3 | ≤ 49.1 / ≤ 87.6 | none | |
| failed calls; evidence | 0 / 62,500; 230/230 ANCHORED | 0 / 62,500; 230/230 ANCHORED | 0 / 62,500; 230/230 ANCHORED | none | build-3 verifier rules change nothing here (section 8) |
| M1 mediation / recording / total / journal | 3.46 / 11.48 / 14.96 / 3.17 | 3.36 / 11.39 / 14.72 / 3.43 | 3.34 / 11.97 / 15.29 / 3.69 | −0.02 / +0.58 / +0.57 / +0.26 | same pattern as the financial runs |
| `Append` median / mean, us (quoted stage run) | smoke only | 1,645.7 / 1,699.7 | 1,690.2 / 1,751.3 | +2.7 % / +3.0 % | **byte-identical test binary**: machine state |
| shares: head replacement / log fsync / CPU | smoke only | 70.0 / 24.8 / 4.5 % | 69.9 / 24.7 / 4.7 % | none | |
| six appends, share of recording | smoke only | 9.95 ms, 88 % | 10.24 ms, 87 % | +0.29 ms | as `Append` |
| `cost` durable / no-fsync per entry, us | 1,672 / - (2026-10-06) | 1,735.1 / 515.2 | 1,761.0 / 701.0 | +1.5 % / +36 % | machine state; the no-fsync mode is the most sensitive to it |
| witness push per call, median (runs 1-3) | smoke 1.30 | 1.28-1.30 ms | 1.21-1.26 ms | −0.05 | push path unchanged; enrollment is per registration, not per push |
| one push + save per call / per entry, ms (clean run) | - | 2.4 / 11.3 | 2.2 / 10.6 | −0.2 / −0.7 | the witness test writes under `%LOCALAPPDATA%\Temp`; within run-to-run variation |

**Reconciliation for the paper (review 5, item 1).** The figures 11.40 ms and
94 calls/s are build 1 (2026-10-08), 11.29 ms and 92.5 calls/s build 2
(2026-10-10), 11.77 ms and 88.2 calls/s build 3 (2026-10-20); each is the
primary run's paired median over 500 trials and the median of the 15 full
cells at 4-16 clients over five runs. None of the differences is new code,
changed tests, changed counting or a correction: the timed code is identical
in all three builds, and the scripts and rules are the same. They are
session-to-session variation of one desktop machine whose durable-write path
became slower (same-binary appends +3 %, more background antivirus CPU,
more drive slowdowns). Across the three sessions: recording 11.29-11.77 ms
(primary medians; run medians 11.29-12.03), full saturation 88-94 calls/s.
Quote ranges, or quote build 3 with this table.

## 10. Diagnostic: does the evidence location matter? (not a headline)

The build-3 brief keeps raw folders in `<repo>/.tools/build3-work` (indexed);
builds 1 and 2 used the scratchpad under `%LOCALAPPDATA%\Temp` (not indexed).
`tools/run_location_ab.sh` alternated the two with the same build-3 binaries
right after the session (19:00-19:10 UTC, idle check and process logger as
above): four baseline runs at default sizes (T1 D1 T2 D2) and four stage runs,
under one typeperf log with the CPU of SearchIndexer, MsMpEng and System
(`diagnostic/location-ab.json`):

| arm | recording ms [block CI] | flagging | full calls/s at 1 / 4 / 16 | `Append` median / mean us | MsMpEng cores | SearchIndexer cores |
|---|---|---|---|---|---|---|
| T1 (Temp) | 11.27 [11.09, 11.46] | 0.22 | 61.0 / 94.1 / 93.1 | 1,756 / 1,836 | 2.52 | 0.03 |
| D1 (repo) | 11.61 [11.36, 11.78] | 0.19 | 55.7 / 91.0 / 90.7 | 1,725 / 2,292 | 2.46 | 0.81 |
| T2 (Temp) | 11.78 [11.70, 12.07] | 0.29 | 59.1 / 85.4 / 90.9 | 1,765 / 2,896 | 2.51 | 0.51 |
| D2 (repo) | 11.69 [11.56, 11.84] | 0.20 | 56.6 / 55.0 / 86.8 | 1,741 / 1,969 | 2.04 | 0.96 |

(Load columns: means over the baseline run; the stage runs show MsMpEng
2.1-3.2 cores.) With two runs per arm the location shows **no consistent
effect** on the recording median or the append cost; full at 1 client was
higher in both Temp runs (61.0, 59.1 versus 55.7, 56.6), at the resolution
limit. What every arm shows is Defender scanning at 2-3 cores whenever durable
appends run, in both locations, and the search indexer lagging behind the
repository writes into the next runs. T1 reproduces build 2's numbers with the
build-3 binary. The diagnostic's evidence (160/160 ANCHORED) and full results
are in `diagnostic/`.

## 11. Caveats

- One machine; loopback provider in the same process; small fixed payloads and
  short logs; closed-loop clients (throughput at saturation, latency includes
  queueing). Performance is a single-machine prototype result, not evidence of
  production readiness; there is no independent replication.
- Durable costs depend on this consumer NVMe drive at 97.5 % full, NTFS and
  Windows flush semantics, Defender's real-time scanning (a platform update
  between builds 2 and 3) and the drive slowdowns of section 6; the
  write-cache setting is unknown. Build 3's durable numbers are 3-12 % worse
  than build 2's on the same timed code; the attribution to machine state
  rests on byte-identical code, a byte-identical stage binary and the
  diagnostic, not on a same-day run of the build-2 eval binary (not kept).
- The process snapshots that pick the primary run cannot see Defender or the
  search indexer; their CPU was measured only in the diagnostic. Background
  CPU during the session was higher than in builds 1-2 (sequential phase
  4.1-5.2 versus 2.5-3.2 cores system-wide).
- The rotated order balances positions, not predecessors: differences of a few
  tenths of a millisecond (flagging's sign, the journal) are not resolved.
- `GetProcessTimes` ticks about 15.6 ms (CPU per call is coarse). Go's wall
  clock step (environment field) was 0.5 ms in four runs and 0.01-0.08 ms in
  two, following the system timer resolution other applications request; the
  latencies use QueryPerformanceCounter and do not depend on it.
- The stage and witness measurements are test-only code on a separate test
  build of the same commit; the stage path is a copy of `Append` guarded by a
  byte-equality test and a source check. Directory fsync does not exist on
  Windows; rename durability is not tested here. The witness bench client is
  unpinned (section 7).
- The share of the 11.77 ms inside the appends crosses two measurement
  settings and is approximate.

## 12. Files

| file | content |
|---|---|
| `RESULTS.md` | this report |
| `build-manifest.txt` | binaries, the three manifest checks with timestamps, test build and hashes, source checks, idle checks, timeline, storage, Defender versions, machine |
| `source-manifest.txt` | copy of `<singlebuild3>/MANIFEST.txt` with the repository path replaced by `<repo>` |
| `baseline.json`, `baseline.md`, `baseline-sequential.csv`, `baseline-concurrent.csv`, `baseline-concurrent-summary.csv`, `load/` | primary run R2 (raw per-call CSVs, every call) |
| `repeats/R1`, `R3`, `R4`, `R5` | the other financial runs, same files |
| `message/` | M1, same files |
| `analysis.json` | every derived number per run, plus build 1's and build 2's primary runs and spreads |
| `analyze_baseline.py` | build 2's analysis script; one added block copies build 2's numbers for comparison |
| `compare_builds.py`, `comparison-builds.csv` | headline numbers of builds 1, 2 and 3 side by side |
| `slow_calls.py`, `slow-calls.json` | slow calls per run, configuration and block; low-throughput cells; disk write-time intervals |
| `stage_summary.py`, `stagecost/summary.csv` | stage groups, shares, per-call sums, serial rate and witness rows of every run |
| `stagecost/run1..run3/`, `stagecost/run-corpus/` | `stagecost.{json,md}` and (run1-run3) `witnesspush.{json,md}` as written by the tests |
| `stagecost/bench-cpu.txt`, `stagecost/stagecost-drive.log` | CPU-only stage benchmark; stage/witness timeline |
| `cost/cost.{json,md}`, `cost/stdout.txt` | the `agentgate-eval cost` run |
| `verify_evidence.py`, `evidence-standalone.json` | new: standalone build-3 verification of all 230 evidence folders |
| `session-logs/` | `drive.log`, `session.log`, `watch-procs.csv` (idle guard), `idle-check.txt`, `stagecost-load.csv` (typeperf during cost, stage and witness runs) |
| `tools/` | build 2's `drive_runs.sh`, `run_baseline.sh`, `procsnap.ps1`, `sanitize_load.py`, `run_session.sh`, `run_stagecost.sh`, `watch_procs.ps1` (unchanged); new `run_location_ab.sh` |
| `diag_summary.py`, `diagnostic/` | the location diagnostic: `location-ab.json`, per-arm baseline and stage results, `diag.log`, `diag-load.csv`, `watch-procs.csv`, `idle-check.txt` |
| `charts/` | `baseline_latency_ecdf.{pdf,png}` (R2's sequential calls) and `baseline_throughput.{pdf,png}` (median of five runs, min-max whiskers; the long whiskers are R3's slowdown); not copied to `../charts/` |

The 569 MB of evidence folders, the cost run's self-test folder, the test
binaries, the smoke runs and the diagnostic's raw output stay in
`<work>/baseline/` (outside git). Evidence was written with
`-host-label review-host` (460 files name it; none names the machine or a user
path). Every file above was checked the same way; process snapshots are
aggregated into categories and typeperf headers have the machine name
replaced (`tools/sanitize_load.py`).
