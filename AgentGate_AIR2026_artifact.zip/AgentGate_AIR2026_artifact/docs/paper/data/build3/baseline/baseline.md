# Baselines and load

Local measurements on one machine with simulated providers over loopback. They compare matched configurations of this prototype under one synthetic workload; they are not a general performance claim, and repeated timing calls are not independent workloads.

Command: `agentgate-eval -host-label review-host baseline -out .tools/build3-work/baseline/session/runs/R2 -work <work>`. Workload: financial. Go go1.26.6 on windows/amd64, 12 CPUs, GOMAXPROCS 12.  
Timer: QueryPerformanceCounter (kernel32 via golang.org/x/sys/windows), frequency 10000000 Hz, tick 100.0 ns. Wall-clock step observed for time.Now: 0.5046 ms.

## Configurations

- **direct**: no gateway: normalize (gateway normalizer), adapters.Prepare, adapters.HTTPTransport to the provider, verify the provider receipt
- **policy-only**: gateway with policy, grant, capability and signed receipts; audit sink off, no operation journal
- **full**: policy-only plus the signed hash-chained audit log, durable (fsync per entry)
- **full+journal**: full plus the fsynced operation journal
- **full-flagged**: full; the request is above the automatic limit and is flagged for audit

## Method

- Identical transport: every configuration is reached by JSON-RPC tools/call over loopback HTTP (keep-alive client, one per configuration) and reaches the provider with the adapter's HTTP transport (one fresh TCP connection per provider request).
- Identical provider: a provider host (internal/simulator behind its own loopback listener and key); every configuration has its own instance (same code, same transport, its own state) per sequential block and per concurrent cell, so state growth is equal and each evidence folder's provider journal holds only its own effects.
- Sequential: 500 paired trials in blocks of 50; in each trial every configuration gets one call, in an order rotated by one position per trial; each block starts fresh (provider, gateways, audit logs, journal) after 10 warm-up calls per configuration.
- Concurrent: client counts [1 2 4 8 16]; each configuration alone per cell, 10 warm-up calls then 400 measured calls split over the clients, back to back; CPU time is the whole process (client, server, gateway, provider host), memory peaks are sampled every 5ms.
- Every observation is kept: raw CSVs hold warm-up calls (marked) and every measured call, failed or not; summaries use every measured call (no outlier removal).
- Paired differences: per trial b - a; median with a distribution-free 95% interval (sign test order statistics), mean, and the share of trials in which b was slower.

## Sequential, paired trials (500 trials, 10 blocks, 38.2 s)

Latency per call in microseconds (all measured calls).

| config | n | min | p50 | p90 | p95 | p99 | max | mean | not committed | audit entries/call | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| direct | 500 | 998 | 1290 | 1617 | 1745 | 2039 | 3048 | 1342 | 0 | 0.00 |  |
| policy-only | 500 | 3740 | 4451 | 5314 | 5598 | 6324 | 31220 | 4603 | 0 | 0.00 |  |
| full | 500 | 14162 | 16314 | 18566 | 19507 | 21858 | 163886 | 16961 | 0 | 6.00 | ANCHORED x10 |
| full+journal | 500 | 17554 | 20011 | 22929 | 23987 | 27333 | 177188 | 20765 | 0 | 6.00 | ANCHORED x10 |
| full-flagged | 500 | 14266 | 16559 | 18937 | 19831 | 25250 | 44354 | 16944 | 0 | 6.00 | ANCHORED x10 |

Paired differences (per trial, microseconds; 95% interval of the median from the sign test):

| difference | n | median | 95% CI | mean | p95 | share of trials slower |
|---|---|---|---|---|---|---|
| policy-only - direct | 500 | 3142 | [3088, 3207] | 3261 | 4298 | 100.0% |
| full - policy-only | 500 | 11769 | [11626, 11887] | 12358 | 14980 | 100.0% |
| full - direct | 500 | 14947 | [14855, 15123] | 15619 | 18266 | 100.0% |
| full+journal - full | 500 | 3768 | [3568, 3895] | 3804 | 7583 | 95.8% |
| full-flagged - full | 500 | 222 | [67, 350] | -17 | 3630 | 56.0% |
| full+journal - direct | 500 | 18703 | [18499, 18833] | 19422 | 22525 | 100.0% |

Whole sequential phase: CPU 29156 ms (user 18750, kernel 10406) over 38200 ms wall; 7677.9 MiB allocated; peak working set 57.7 MiB (sampled).

## Concurrent load

Each cell runs one configuration alone; latency in microseconds; CPU is the whole process.

| clients | config | calls | not committed | calls/s | p50 | p95 | p99 | max | CPU ms/call | CPU cores busy | KiB alloc/call | peak heap MiB | peak working set MiB | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | direct | 400 | 0 | 920.2 | 1001 | 1371 | 1630 | 1756 | 1.367 | 1.26 | 424.4 | 4.6 | 52.3 |  |
| 1 | policy-only | 400 | 0 | 210.6 | 4368 | 5415 | 7170 | 95065 | 6.445 | 1.36 | 2678.5 | 20.0 | 45.5 |  |
| 1 | full | 400 | 0 | 53.1 | 17649 | 21614 | 32305 | 117368 | 13.477 | 0.72 | 3039.7 | 40.1 | 65.4 | ANCHORED |
| 1 | full+journal | 400 | 0 | 39.6 | 23751 | 33675 | 49166 | 73650 | 15.820 | 0.63 | 3060.3 | 39.7 | 67.1 | ANCHORED |
| 2 | direct | 400 | 0 | 1701.8 | 1160 | 1425 | 1561 | 1998 | 1.875 | 3.19 | 425.5 | 48.8 | 82.9 |  |
| 2 | policy-only | 400 | 0 | 364.2 | 5389 | 6476 | 7025 | 7140 | 6.094 | 2.22 | 2694.6 | 19.6 | 74.7 |  |
| 2 | full | 400 | 0 | 74.2 | 25783 | 36505 | 51040 | 78986 | 14.063 | 1.04 | 3044.4 | 40.4 | 67.6 | ANCHORED |
| 2 | full+journal | 400 | 0 | 63.4 | 29095 | 45105 | 72214 | 96796 | 16.172 | 1.02 | 3064.6 | 39.4 | 66.6 | ANCHORED |
| 4 | direct | 400 | 0 | 2489.2 | 1560 | 1992 | 2210 | 2504 | 1.914 | 4.76 | 437.9 | 45.4 | 85.2 |  |
| 4 | policy-only | 400 | 0 | 607.7 | 6258 | 8857 | 10259 | 10895 | 6.289 | 3.82 | 2703.2 | 21.0 | 50.1 |  |
| 4 | full | 400 | 0 | 88.7 | 43914 | 54061 | 67376 | 80213 | 12.383 | 1.10 | 3048.8 | 38.6 | 67.1 | ANCHORED |
| 4 | full+journal | 400 | 0 | 83.4 | 47175 | 55014 | 61169 | 69907 | 13.203 | 1.10 | 3078.6 | 40.2 | 70.8 | ANCHORED |
| 8 | direct | 400 | 0 | 2794.3 | 2878 | 3395 | 3760 | 4097 | 1.680 | 4.69 | 432.7 | 40.7 | 85.4 |  |
| 8 | policy-only | 400 | 0 | 699.8 | 11151 | 14437 | 17690 | 18077 | 7.578 | 5.30 | 2705.6 | 20.9 | 54.7 |  |
| 8 | full | 400 | 0 | 92.3 | 85445 | 99472 | 112419 | 116727 | 15.195 | 1.40 | 3045.8 | 41.1 | 72.3 | ANCHORED |
| 8 | full+journal | 400 | 0 | 84.1 | 94606 | 107043 | 118108 | 129530 | 14.492 | 1.22 | 3072.8 | 41.2 | 70.9 | ANCHORED |
| 16 | direct | 400 | 0 | 3254.8 | 4878 | 5573 | 6108 | 6536 | 2.539 | 8.26 | 421.2 | 46.1 | 85.7 |  |
| 16 | policy-only | 400 | 0 | 748.6 | 21034 | 26089 | 32797 | 34998 | 8.477 | 6.35 | 2684.4 | 26.9 | 60.8 |  |
| 16 | full | 400 | 0 | 92.7 | 171236 | 183792 | 194968 | 230108 | 13.242 | 1.23 | 3040.7 | 41.7 | 73.3 | ANCHORED |
| 16 | full+journal | 400 | 0 | 85.1 | 186639 | 201391 | 213653 | 236245 | 16.016 | 1.36 | 3063.1 | 41.1 | 77.9 | ANCHORED |

CPU source: GetProcessTimes (user + kernel) (resolution: scheduler tick (about 15.6 ms on an idle system)). Memory: K32GetProcessMemoryInfo (working set), sampled every 5 ms; heap = runtime/metrics /memory/classes/heap/objects:bytes.

## Files

- concurrent_observations: `baseline-concurrent.csv`
- concurrent_summary: `baseline-concurrent-summary.csv`
- sequential_observations: `baseline-sequential.csv`
