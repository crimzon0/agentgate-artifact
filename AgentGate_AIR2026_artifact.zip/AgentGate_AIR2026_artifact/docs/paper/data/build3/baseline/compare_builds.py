"""Headline numbers of the baseline on build 3 next to builds 2 and 1.

    py docs/paper/data/build3/baseline/compare_builds.py

Build-3 version of docs/paper/data/build2/baseline/compare_build1.py: the same
rows, computed the same way, with one more column. Reads analysis.json next to
this script (build 3, written by analyze_baseline.py),
../../build2/baseline/analysis.json (build 2, 2026-10-10) and
../../revision/baseline/analysis.json (build 1, 2026-10-08), and writes
comparison-builds.csv: one row per headline number with the build-1, build-2
and build-3 values and the change from build 2 to build 3. All three files come
from the same analysis script (same seed, same resamples):

- paired medians: primary run, with the block-level 95 % interval (cluster
  bootstrap over the 10 blocks) and the range over the five financial runs;
- sequential percentiles: primary run, every measured call;
- concurrent cells: median over the five financial runs (min-max);
- latency under load, CPU per call, allocation: median over the five runs;
  peaks: maximum over the five runs and all cells;
- sequential-phase resources: range over the five financial runs.
The primary run of each build is the one with the lowest background load
(build 1: R3; build 2: R2; build 3: PRIMARY_B3 below).
"""
import csv
import json
import os
import statistics as st

HERE = os.path.dirname(os.path.abspath(__file__))
PRIMARY_B3 = "R2"  # set at assembly from the background-load rule (build-manifest.txt)
FIN = ["primary", "repeat-R1", "repeat-R2", "repeat-R3", "repeat-R4", "repeat-R5"]
PAIRS = [("mediation (policy-only - direct)", "policy-only - direct"),
         ("signed durable recording (full - policy-only)", "full - policy-only"),
         ("total (full - direct)", "full - direct"),
         ("operation journal (full+journal - full)", "full+journal - full"),
         ("flagging (full-flagged - full)", "full-flagged - full"),
         ("everything (full+journal - direct)", "full+journal - direct")]


def load(path):
    with open(path) as handle:
        data = json.load(handle)
    runs = {name: run for name, run in data["runs"].items() if name in FIN}
    return data, runs


def ms(us):
    return round(us / 1000.0, 2)


def paired(runs, compare):
    row = next(p for p in runs["primary"]["paired_differences"] if p["compare"] == compare)
    vals = [p["median_us"] for r in runs.values() for p in r["paired_differences"] if p["compare"] == compare]
    return (f"{ms(row['median_us']):.2f} [{ms(row['median_ci95_blocks'][0]):.2f}, {ms(row['median_ci95_blocks'][1]):.2f}] "
            f"({ms(min(vals)):.2f} to {ms(max(vals)):.2f})"), row["median_us"]


def cell(runs, config, clients, key):
    return [x[key] for r in runs.values() for x in r["concurrent"] if x["config"] == config and x["clients"] == clients]


def main():
    _, b3 = load(os.path.join(HERE, "analysis.json"))
    _, b2 = load(os.path.normpath(os.path.join(HERE, "..", "..", "build2", "baseline", "analysis.json")))
    _, b1 = load(os.path.normpath(os.path.join(HERE, "..", "..", "revision", "baseline", "analysis.json")))
    builds = (b1, b2, b3)
    rows = []
    for label, compare in PAIRS:
        texts, values = zip(*(paired(b, compare) for b in builds))
        rows.append([f"paired median, ms: {label}", *texts, f"{ms(values[2] - values[1]):+.2f}"])
    for config in ["direct", "policy-only", "full", "full+journal", "full-flagged"]:
        f = lambda s: " / ".join(f"{ms(s[k]):.2f}" for k in ("p50_us", "p95_us", "p99_us", "max_us"))  # noqa: E731
        s = [b["primary"]["sequential"][config] for b in builds]
        rows.append([f"sequential p50 / p95 / p99 / max, ms (primary): {config}", *(f(x) for x in s), f"p50 {ms(s[2]['p50_us'] - s[1]['p50_us']):+.2f}"])
        p = [[r["sequential"][config]["p99_us"] for r in b.values()] for b in builds]
        rows.append([f"sequential p99 range over 5 runs, ms: {config}", *(f"{ms(min(x)):.2f}-{ms(max(x)):.2f}" for x in p), ""])
        p = [[r["sequential"][config]["p50_us"] for r in b.values()] for b in builds]
        rows.append([f"sequential p50 range over 5 runs, ms: {config}", *(f"{ms(min(x)):.2f}-{ms(max(x)):.2f}" for x in p), ""])
    for config in ["direct", "policy-only", "full", "full+journal"]:
        for clients in [1, 2, 4, 8, 16]:
            t = [cell(b, config, clients, "throughput_calls_per_s") for b in builds]
            m = [st.median(x) for x in t]
            rows.append([f"throughput, calls/s, median [min-max]: {config} @ {clients}", *(f"{st.median(x):.1f} [{min(x):.1f}-{max(x):.1f}]" for x in t),
                         f"{100 * (m[2] - m[1]) / m[1]:+.1f} %"])
    for config in ["full", "full+journal"]:
        t = [[v for n in (4, 8, 16) for v in cell(b, config, n, "throughput_calls_per_s")] for b in builds]
        m = [st.median(x) for x in t]
        rows.append([f"saturation throughput, calls/s, median of the 15 cells at 4-16 clients: {config}", *(f"{x:.1f}" for x in m), f"{100 * (m[2] - m[1]) / m[1]:+.1f} %"])
    for config in ["direct", "policy-only", "full", "full+journal"]:
        for clients in [1, 16]:
            f = lambda runs: " / ".join(f"{ms(st.median(cell(runs, config, clients, k))):.2f}" for k in ("p50_us", "p95_us", "p99_us", "max_us"))  # noqa: E731
            rows.append([f"latency under load p50 / p95 / p99 / max, ms (median of 5): {config} @ {clients}", *(f(b) for b in builds), ""])
        c = [cell(b, config, 1, "cpu_ms_per_call") for b in builds]
        rows.append([f"CPU per call at 1 client, ms, median [min-max]: {config}", *(f"{st.median(x):.2f} [{min(x):.2f}-{max(x):.2f}]" for x in c),
                     f"{st.median(c[2]) - st.median(c[1]):+.2f}"])
        k = [cell(b, config, 16, "cpu_cores_busy") for b in builds]
        rows.append([f"cores busy at 16 clients, median [min-max]: {config}", *(f"{st.median(x):.2f} [{min(x):.2f}-{max(x):.2f}]" for x in k), ""])
        a = [cell(b, config, 1, "alloc_kib_per_call") for b in builds]
        rows.append([f"allocation per call at 1 client, KiB, median of 5 runs: {config}", *(f"{st.median(x):.0f}" for x in a), f"{st.median(a[2]) - st.median(a[1]):+.0f}"])
        a = [[v for n in (1, 2, 4, 8, 16) for v in cell(b, config, n, "alloc_kib_per_call")] for b in builds]
        rows.append([f"allocation per call, KiB, median of all cells: {config}", *(f"{st.median(x):.0f}" for x in a), f"{st.median(a[2]) - st.median(a[1]):+.0f}"])
    for key, label in (("peak_heap_mib", "peak Go heap, MiB (max over cells and runs)"), ("peak_working_set_mib", "peak working set, MiB (max over cells and runs)")):
        v = [max(x[key] for r in b.values() for x in r["concurrent"]) for b in builds]
        rows.append([label, *(f"{x:.1f}" for x in v), f"{v[2] - v[1]:+.1f}"])
    for key, label, scale in (("cpu_utilization_cores", "sequential phase: cores busy", 1), ("peak_working_set_bytes", "sequential phase: peak working set, MiB", 2 ** 20),
                              ("alloc_bytes", "sequential phase: allocated, GiB", 2 ** 30), ("wall_ms", "sequential phase: wall time, s", 1000)):
        v = [[r["sequential_phase_resources"][key] / scale for r in b.values()] for b in builds]
        rows.append([f"{label} (range over 5 runs)", *(f"{min(x):.2f}-{max(x):.2f}" for x in v), ""])
    out = os.path.join(HERE, "comparison-builds.csv")
    with open(out, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["measure", "build 1 (2026-10-08, primary R3)", "build 2 (2026-10-10, primary R2)",
                         f"build 3 (2026-10-20, primary {PRIMARY_B3})", "change build 2 -> 3"])
        writer.writerows(rows)
    for row in rows:
        print(" | ".join(row))
    print("wrote", out)


if __name__ == "__main__":
    main()
