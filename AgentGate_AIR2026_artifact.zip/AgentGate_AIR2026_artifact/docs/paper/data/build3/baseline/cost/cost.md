# Cost of evidence

Local measurements on one computer under normal desktop load; absolute values depend on the disk, the file system, antivirus scanning and the Windows timer. Gateway latencies are quantized to the clock granularity.

- Command: `agentgate-eval -host-label review-host cost -n 2000 -batches 5 -repeat 20 -out .tools/build3-work/baseline/session/cost -work <work>`; Go go1.26.6 on windows/amd64, 12 CPUs; clock granularity 0.010 ms; total 58 s.
- Source run: run-20261020-184312-266e68 (self-test, 20 suites, SELF-TEST PASSED in autonomous flag mode (320/320 scenario runs = 16 scenarios x 20, 40 skipped as human-approval only, 60/60 custom requests, verifier VERIFIED / ANCHORED, 8/8 tamper attacks detected, 4/4 revision checks)), 2986 entries, 4852890 bytes of audit.jsonl.

## (a) audit.Append cost per entry

Per-entry cost of audit.Append, from timed batches of consecutive appends of the run's own events (replayed in order) into a fresh log per batch; per-entry = batch time / appends. Corpus: 2986 real entries, mean 1625 bytes per line. 5 batches x 2000 appends per mode.

| Mode | What it does | Median us/entry | Min | Max | Entries/s (from median) |
|---|---|---|---|---|---|
| durable | default: write line, fsync audit.jsonl, replace head.json via a synced temporary file and rename | 1761.0 | 1748.9 | 1800.0 | 568 |
| no-fsync | same writes as durable, both fsync calls skipped (experiment only) | 701.0 | 665.0 | 811.1 | 1426 |
| sign-only | entry and head encoded, hashed and Ed25519-signed; nothing written (experiment only) | 53.3 | 49.5 | 55.0 | 18772 |

Derived: fsync = 1059.9 us/entry, file writes (line + head replace) = 647.8 us/entry. fsync cost = durable median - no-fsync median; write cost = no-fsync median - sign-only median (differences of medians).

## (b) Gateway call latency by outcome

Wall-clock time of each agent MCP tools/call at the gateway's MCP handler (request received to response complete), from the demo self-test's own timer. Includes the gateway's audit appends and, for applied calls, the loopback HTTP round trip to the simulated provider. Outcome is the result kind the agent received; (resumed) marks the call that resumes after a human decision; applied (duplicate) is a repeated identical call (replay scenario) answered with the original result, with no new effect and no EFFECT_EXECUTED entry (identified from the matched audit segment).

| Outcome | n | Median ms | p95 ms | Mean ms | Max ms | Gateway entries/call | Est. append ms (share of median) | Est. fsync ms |
|---|---|---|---|---|---|---|---|---|
| applied | 202 | 18.00 | 51.62 | 28.74 | 56.38 | 6 | 10.57 (59%) | 6.36 |
| applied (duplicate) | 61 | 5.17 | 7.00 | 6.96 | 73.55 | 2 | 3.52 (68%) | 2.12 |
| denied | 179 | 7.80 | 41.10 | 11.53 | 43.49 | 3 | 5.28 (68%) | 3.18 |
| mcp_rejected | 20 | 2.00 | 2.52 | 2.05 | 3.00 | 0 | 0.00 (0%) | 0.00 |
| refused | 40 | 4.00 | 37.30 | 8.04 | 39.06 | 2 | 3.52 (88%) | 2.12 |
| uncertain | 1 | 16.51 | n<20 | 16.51 | 16.51 | 6 | 10.57 (64%) | 6.36 |
| all calls | 503 | 8.86 | 51.00 | 17.24 | 73.55 | - | - | - |

503 timed gateway calls, 503 agent call segments (AGENT_PROPOSED..AGENT_RECEIVED) in the audit log; calls are sequential in the self-test, so the i-th call is matched with the i-th segment when the counts agree.

(c) The append share is an estimate (gateway entries per call x durable per-entry median from (a)), not a measurement with the recorder switched off: the gateway fails closed without its recorder.
