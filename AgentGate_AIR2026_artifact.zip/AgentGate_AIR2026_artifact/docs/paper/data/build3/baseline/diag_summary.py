"""Summarise the evidence-location diagnostic (tools/run_location_ab.sh; new in
build 3, not part of the build-2 method and not a headline).

    py docs/paper/data/build3/baseline/diag_summary.py

Reads diagnostic/runs/<arm>/ (agentgate-eval baseline, default sizes),
diagnostic/stage/<arm>/stagecost.json (TestStageCost, 10,000 appends),
diagnostic/diag.log (UTC start/end of every step) and diagnostic/diag-load.csv
(typeperf, 1 s: total CPU, disk writes, CPU of SearchIndexer, MsMpEng and
System). Arms: T = evidence written under %LOCALAPPDATA%\\Temp (not indexed by
Windows Search; where builds 1 and 2 wrote it), D = under <repo>/.tools/
build3-work (indexed; where the build-3 session wrote it); order T1 D1 T2 D2.
Paired medians use analyze_baseline.py's own functions (same seed and
resamples; block-level intervals). Writes diagnostic/location-ab.json.
"""
import csv
import datetime as dt
import json
import os
import re
import statistics as st

import numpy as np

import analyze_baseline as ab

HERE = os.path.dirname(os.path.abspath(__file__))
DIAG = os.path.join(HERE, "diagnostic")
ARMS = ["T1", "D1", "T2", "D2"]


def windows():
    out = {}
    with open(os.path.join(DIAG, "diag.log")) as handle:
        for line in handle:
            parts = line.split()
            if len(parts) >= 4 and parts[0] in ("baseline", "stage"):
                key = f"{parts[0]} {parts[1]}"
                when = dt.datetime.strptime(parts[-1], "%Y-%m-%dT%H:%M:%SZ")
                out.setdefault(key, [None, None])[0 if parts[2] == "start" else 1] = when
    return out


def load_by_window(spans):
    with open(os.path.join(DIAG, "diag-load.csv"), encoding="utf-8") as handle:
        rows = list(csv.reader(handle))
    offset = int(re.search(r"\((-?\d+)\)\"?$", rows[0][0]).group(1))
    samples = []
    for row in rows[1:]:
        try:
            when = dt.datetime.strptime(row[0], "%m/%d/%Y %H:%M:%S.%f") + dt.timedelta(minutes=offset)
            samples.append((when, [float(x) for x in row[1:]]))
        except ValueError:
            continue
    out = {}
    for key, (start, end) in spans.items():
        sel = [v for t, v in samples if start <= t <= end]
        col = lambda i: [v[i] for v in sel]  # noqa: E731
        out[key] = {"samples_1s": len(sel), "total_cores_busy": round(st.mean(col(0)) * 12 / 100, 2),
                    "disk_writes_per_s": round(st.mean(col(1))), "disk_mean_write_ms": round(st.mean(col(2)) * 1000, 3),
                    "SearchIndexer_cores": round(st.mean(col(3)) / 100, 2), "MsMpEng_cores": round(st.mean(col(4)) / 100, 2),
                    "System_cores": round(st.mean(col(5)) / 100, 2)}
    return out


def main():
    rng = np.random.default_rng(ab.SEED)
    spans = windows()
    load = load_by_window(spans)
    result = {"method": __doc__.strip(), "arms": {}}
    for arm in ARMS:
        run_dir = os.path.join(DIAG, "runs", arm)
        with open(os.path.join(run_dir, "baseline.json")) as handle:
            meta = json.load(handle)
        _, paired, _ = ab.analyse_sequential(run_dir, rng)
        cells = ab.read_concurrent(run_dir)
        full = {k: float(cells[("full", k)]["throughput_calls_per_s"]) for k in (1, 2, 4, 8, 16)}
        journal = {k: float(cells[("full+journal", k)]["throughput_calls_per_s"]) for k in (1, 2, 4, 8, 16)}
        with open(os.path.join(DIAG, "stage", arm, "stagecost.json")) as handle:
            stage = json.load(handle)
        result["arms"][arm] = {
            "location": "Temp (not indexed)" if arm.startswith("T") else "repo .tools (indexed)",
            "clock_granularity_ms": meta["environment"]["clock_granularity_ms"],
            "paired_ms": {p["compare"]: {"median": round(p["median_us"] / 1000, 2),
                                          "block_ci95": [round(x / 1000, 2) for x in p["median_ci95_blocks"]]} for p in paired},
            "full_calls_per_s": full, "full+journal_calls_per_s": journal,
            "stage_append_us": {"median": stage["append_uninstrumented"]["median_us"], "mean": stage["append_uninstrumented"]["mean_us"],
                                "over_10ms": stage["per_call"]["appends_over_10ms"]},
            "load_baseline": load.get(f"baseline {arm}"), "load_stage": load.get(f"stage {arm}"),
        }
    out = os.path.join(DIAG, "location-ab.json")
    with open(out, "w") as handle:
        json.dump(result, handle, indent=1)
    for arm, r in result["arms"].items():
        p = r["paired_ms"]
        print(arm, r["location"], "clock", r["clock_granularity_ms"],
              "| mediation", p["policy-only - direct"]["median"], "recording", p["full - policy-only"]["median"], p["full - policy-only"]["block_ci95"],
              "journal", p["full+journal - full"]["median"], "flagging", p["full-flagged - full"]["median"], p["full-flagged - full"]["block_ci95"],
              "| full", r["full_calls_per_s"], "| f+j", r["full+journal_calls_per_s"],
              "| stage", r["stage_append_us"], "| load", r["load_baseline"], r["load_stage"])
    print("wrote", out)


if __name__ == "__main__":
    main()
