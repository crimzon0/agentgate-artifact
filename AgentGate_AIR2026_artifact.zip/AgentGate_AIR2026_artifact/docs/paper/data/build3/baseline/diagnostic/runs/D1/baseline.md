# Baselines and load

Local measurements on one machine with simulated providers over loopback. They compare matched configurations of this prototype under one synthetic workload; they are not a general performance claim, and repeated timing calls are not independent workloads.

Command: `agentgate-eval -host-label review-host baseline -out .tools/build3-work/baseline/diag/runs/D1 -work <work>`. Workload: financial. Go go1.26.6 on windows/amd64, 12 CPUs, GOMAXPROCS 12.  
Timer: QueryPerformanceCounter (kernel32 via golang.org/x/sys/windows), frequency 10000000 Hz, tick 100.0 ns. Wall-clock step observed for time.Now: 0.5071 ms.

## Configurations

- **direct**: no gateway: normalize (gateway normalizer), adapters.Prepare, adapters.HTTPTransport to the provider, verify the provider receipt
- **policy-only**: gateway with policy, grant, capability and signed receipts; audit sink off, no operation journal
- **full**: policy-only plus the signed hash-chained audit log, durable (fsync per entry)
- **full+journal**: full plus the fsynced operation journal
- **full-flagged**: full; the request is above the automatic limit and is flagged for audit

## Method

- Identical transport: every configuration is reached by JSON-RPC tools/call over loopback HTTP (keep-alive client, one per configuration) and reaches the provider with the adapter's HTTP transport (one fresh TCP connection per provider request).
- Identical provider: a provider host (internal/simulator behind its own loopback listener and key); every configuration has its own instance (same code, same transport, its own state) per sequential block and per concurrent cell, so state growth is equal and each evidence folder's provider journal holds only its own effects.
- Sequential: 500 paired trials in blocks of 50; in each trial every configuration gets one call, in an order rotated by one position per trial; each block starts fresh (provider, gateways, audit logs, journal) after 10 warm-up calls per configuration.
- Concurrent: client counts [1 2 4 8 16]; each configuration alone per cell, 10 warm-up calls then 400 measured calls split over the clients, back to back; CPU time is the whole process (client, server, gateway, provider host), memory peaks are sampled every 5ms.
- Every observation is kept: raw CSVs hold warm-up calls (marked) and every measured call, failed or not; summaries use every measured call (no outlier removal).
- Paired differences: per trial b - a; median with a distribution-free 95% interval (sign test order statistics), mean, and the share of trials in which b was slower.

## Sequential, paired trials (500 trials, 10 blocks, 37.8 s)

Latency per call in microseconds (all measured calls).

| config | n | min | p50 | p90 | p95 | p99 | max | mean | not committed | audit entries/call | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| direct | 500 | 1038 | 1289 | 1673 | 1875 | 2125 | 2509 | 1362 | 0 | 0.00 |  |
| policy-only | 500 | 3776 | 4486 | 5271 | 5580 | 6455 | 7522 | 4564 | 0 | 0.00 |  |
| full | 500 | 14393 | 16128 | 18515 | 19194 | 21511 | 41374 | 16488 | 0 | 6.00 | ANCHORED x10 |
| full+journal | 500 | 17672 | 19824 | 22441 | 23414 | 24971 | 32742 | 20193 | 0 | 6.00 | ANCHORED x10 |
| full-flagged | 500 | 14440 | 16306 | 18741 | 19578 | 21743 | 71649 | 16762 | 0 | 6.00 | ANCHORED x10 |

Paired differences (per trial, microseconds; 95% interval of the median from the sign test):

| difference | n | median | 95% CI | mean | p95 | share of trials slower |
|---|---|---|---|---|---|---|
| policy-only - direct | 500 | 3160 | [3101, 3198] | 3202 | 4073 | 100.0% |
| full - policy-only | 500 | 11606 | [11518, 11714] | 11924 | 14606 | 100.0% |
| full - direct | 500 | 14775 | [14674, 14905] | 15126 | 17675 | 100.0% |
| full+journal - full | 500 | 3654 | [3516, 3784] | 3705 | 6930 | 98.2% |
| full-flagged - full | 500 | 193 | [51, 348] | 275 | 3016 | 56.2% |
| full+journal - direct | 500 | 18476 | [18362, 18578] | 18832 | 21898 | 100.0% |

Whole sequential phase: CPU 29672 ms (user 19781, kernel 9891) over 37790 ms wall; 7671.8 MiB allocated; peak working set 57.3 MiB (sampled).

## Concurrent load

Each cell runs one configuration alone; latency in microseconds; CPU is the whole process.

| clients | config | calls | not committed | calls/s | p50 | p95 | p99 | max | CPU ms/call | CPU cores busy | KiB alloc/call | peak heap MiB | peak working set MiB | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | direct | 400 | 0 | 887.3 | 1018 | 1467 | 1683 | 1866 | 1.641 | 1.46 | 424.8 | 28.9 | 56.8 |  |
| 1 | policy-only | 400 | 0 | 223.3 | 4270 | 5442 | 8241 | 10274 | 5.234 | 1.17 | 2681.7 | 20.7 | 45.0 |  |
| 1 | full | 400 | 0 | 55.7 | 17578 | 20678 | 22652 | 28696 | 13.711 | 0.76 | 3039.2 | 40.3 | 65.7 | ANCHORED |
| 1 | full+journal | 400 | 0 | 46.6 | 20926 | 24657 | 26137 | 42749 | 15.469 | 0.72 | 3064.8 | 39.4 | 70.2 | ANCHORED |
| 2 | direct | 400 | 0 | 1660.3 | 1185 | 1476 | 1608 | 2207 | 1.250 | 2.08 | 428.3 | 47.7 | 81.0 |  |
| 2 | policy-only | 400 | 0 | 371.0 | 5316 | 6321 | 6710 | 7086 | 6.289 | 2.33 | 2699.4 | 18.7 | 77.4 |  |
| 2 | full | 400 | 0 | 81.2 | 23459 | 30528 | 38474 | 46778 | 13.477 | 1.09 | 3048.4 | 40.3 | 66.6 | ANCHORED |
| 2 | full+journal | 400 | 0 | 73.0 | 26606 | 31663 | 37634 | 51547 | 14.766 | 1.08 | 3073.2 | 39.6 | 69.5 | ANCHORED |
| 4 | direct | 400 | 0 | 2311.1 | 1633 | 2185 | 2456 | 2918 | 2.070 | 4.79 | 438.5 | 43.7 | 85.6 |  |
| 4 | policy-only | 400 | 0 | 582.7 | 6663 | 8727 | 10079 | 11048 | 5.586 | 3.25 | 2707.7 | 21.0 | 50.0 |  |
| 4 | full | 400 | 0 | 91.0 | 43248 | 48419 | 53020 | 62335 | 13.828 | 1.26 | 3051.2 | 39.3 | 67.5 | ANCHORED |
| 4 | full+journal | 400 | 0 | 83.3 | 47476 | 53090 | 55811 | 59069 | 15.156 | 1.26 | 3078.3 | 40.6 | 79.0 | ANCHORED |
| 8 | direct | 400 | 0 | 2678.4 | 2942 | 3529 | 3859 | 4104 | 1.875 | 5.02 | 438.9 | 42.9 | 85.0 |  |
| 8 | policy-only | 400 | 0 | 584.8 | 12822 | 18704 | 24078 | 25808 | 6.758 | 3.95 | 2703.9 | 21.7 | 53.4 |  |
| 8 | full | 400 | 0 | 83.5 | 94314 | 114327 | 129046 | 147460 | 15.703 | 1.31 | 3046.4 | 41.2 | 71.2 | ANCHORED |
| 8 | full+journal | 400 | 0 | 76.9 | 103366 | 119405 | 132627 | 140199 | 15.430 | 1.19 | 3071.5 | 41.5 | 71.1 | ANCHORED |
| 16 | direct | 400 | 0 | 2977.4 | 5382 | 6158 | 6439 | 6750 | 2.422 | 7.21 | 420.4 | 43.5 | 87.0 |  |
| 16 | policy-only | 400 | 0 | 700.0 | 22371 | 28735 | 33227 | 42280 | 6.641 | 4.65 | 2687.2 | 26.0 | 60.6 |  |
| 16 | full | 400 | 0 | 90.7 | 174864 | 187087 | 198622 | 235943 | 13.320 | 1.21 | 3036.6 | 41.8 | 72.8 | ANCHORED |
| 16 | full+journal | 400 | 0 | 82.2 | 192204 | 207045 | 212712 | 245294 | 15.938 | 1.31 | 3066.9 | 42.1 | 76.6 | ANCHORED |

CPU source: GetProcessTimes (user + kernel) (resolution: scheduler tick (about 15.6 ms on an idle system)). Memory: K32GetProcessMemoryInfo (working set), sampled every 5 ms; heap = runtime/metrics /memory/classes/heap/objects:bytes.

## Files

- concurrent_observations: `baseline-concurrent.csv`
- concurrent_summary: `baseline-concurrent-summary.csv`
- sequential_observations: `baseline-sequential.csv`
