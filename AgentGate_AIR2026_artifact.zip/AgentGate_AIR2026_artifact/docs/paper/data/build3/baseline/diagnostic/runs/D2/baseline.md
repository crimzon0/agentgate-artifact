# Baselines and load

Local measurements on one machine with simulated providers over loopback. They compare matched configurations of this prototype under one synthetic workload; they are not a general performance claim, and repeated timing calls are not independent workloads.

Command: `agentgate-eval -host-label review-host baseline -out .tools/build3-work/baseline/diag/runs/D2 -work <work>`. Workload: financial. Go go1.26.6 on windows/amd64, 12 CPUs, GOMAXPROCS 12.  
Timer: QueryPerformanceCounter (kernel32 via golang.org/x/sys/windows), frequency 10000000 Hz, tick 100.0 ns. Wall-clock step observed for time.Now: 0.0076 ms.

## Configurations

- **direct**: no gateway: normalize (gateway normalizer), adapters.Prepare, adapters.HTTPTransport to the provider, verify the provider receipt
- **policy-only**: gateway with policy, grant, capability and signed receipts; audit sink off, no operation journal
- **full**: policy-only plus the signed hash-chained audit log, durable (fsync per entry)
- **full+journal**: full plus the fsynced operation journal
- **full-flagged**: full; the request is above the automatic limit and is flagged for audit

## Method

- Identical transport: every configuration is reached by JSON-RPC tools/call over loopback HTTP (keep-alive client, one per configuration) and reaches the provider with the adapter's HTTP transport (one fresh TCP connection per provider request).
- Identical provider: a provider host (internal/simulator behind its own loopback listener and key); every configuration has its own instance (same code, same transport, its own state) per sequential block and per concurrent cell, so state growth is equal and each evidence folder's provider journal holds only its own effects.
- Sequential: 500 paired trials in blocks of 50; in each trial every configuration gets one call, in an order rotated by one position per trial; each block starts fresh (provider, gateways, audit logs, journal) after 10 warm-up calls per configuration.
- Concurrent: client counts [1 2 4 8 16]; each configuration alone per cell, 10 warm-up calls then 400 measured calls split over the clients, back to back; CPU time is the whole process (client, server, gateway, provider host), memory peaks are sampled every 5ms.
- Every observation is kept: raw CSVs hold warm-up calls (marked) and every measured call, failed or not; summaries use every measured call (no outlier removal).
- Paired differences: per trial b - a; median with a distribution-free 95% interval (sign test order statistics), mean, and the share of trials in which b was slower.

## Sequential, paired trials (500 trials, 10 blocks, 38.1 s)

Latency per call in microseconds (all measured calls).

| config | n | min | p50 | p90 | p95 | p99 | max | mean | not committed | audit entries/call | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| direct | 500 | 1028 | 1303 | 1721 | 1849 | 2230 | 3526 | 1376 | 0 | 0.00 |  |
| policy-only | 500 | 3749 | 4484 | 5362 | 5800 | 6360 | 8748 | 4612 | 0 | 0.00 |  |
| full | 500 | 14334 | 16289 | 18538 | 19422 | 21861 | 33323 | 16634 | 0 | 6.00 | ANCHORED x10 |
| full+journal | 500 | 17693 | 19870 | 22672 | 23843 | 26647 | 48016 | 20393 | 0 | 6.00 | ANCHORED x10 |
| full-flagged | 500 | 14253 | 16497 | 18837 | 19676 | 21393 | 28284 | 16799 | 0 | 6.00 | ANCHORED x10 |

Paired differences (per trial, microseconds; 95% interval of the median from the sign test):

| difference | n | median | 95% CI | mean | p95 | share of trials slower |
|---|---|---|---|---|---|---|
| policy-only - direct | 500 | 3152 | [3078, 3212] | 3235 | 4408 | 100.0% |
| full - policy-only | 500 | 11693 | [11608, 11868] | 12022 | 14776 | 100.0% |
| full - direct | 500 | 14963 | [14872, 15032] | 15258 | 17820 | 100.0% |
| full+journal - full | 500 | 3639 | [3500, 3745] | 3760 | 7164 | 97.6% |
| full-flagged - full | 500 | 205 | [126, 319] | 165 | 3179 | 58.2% |
| full+journal - direct | 500 | 18553 | [18445, 18686] | 19017 | 22389 | 100.0% |

Whole sequential phase: CPU 30844 ms (user 20156, kernel 10688) over 38061 ms wall; 7675.7 MiB allocated; peak working set 57.8 MiB (sampled).

## Concurrent load

Each cell runs one configuration alone; latency in microseconds; CPU is the whole process.

| clients | config | calls | not committed | calls/s | p50 | p95 | p99 | max | CPU ms/call | CPU cores busy | KiB alloc/call | peak heap MiB | peak working set MiB | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | direct | 400 | 0 | 929.4 | 985 | 1361 | 1450 | 1564 | 1.445 | 1.34 | 424.0 | 4.7 | 51.4 |  |
| 1 | policy-only | 400 | 0 | 226.9 | 4300 | 5090 | 5710 | 6209 | 5.742 | 1.30 | 2680.1 | 21.2 | 45.6 |  |
| 1 | full | 400 | 0 | 56.6 | 17310 | 20423 | 22625 | 43353 | 14.102 | 0.80 | 3038.4 | 39.0 | 64.8 | ANCHORED |
| 1 | full+journal | 400 | 0 | 26.5 | 25166 | 57257 | 66702 | 133211 | 13.555 | 0.36 | 3069.8 | 40.4 | 66.4 | ANCHORED |
| 2 | direct | 400 | 0 | 1501.2 | 1295 | 1631 | 1774 | 2539 | 1.758 | 2.64 | 432.0 | 48.5 | 83.3 |  |
| 2 | policy-only | 400 | 0 | 385.1 | 5088 | 6097 | 6493 | 7047 | 5.742 | 2.21 | 2697.3 | 19.5 | 71.0 |  |
| 2 | full | 400 | 0 | 41.9 | 54387 | 71704 | 89539 | 97067 | 12.813 | 0.54 | 3052.7 | 40.2 | 66.7 | ANCHORED |
| 2 | full+journal | 400 | 0 | 34.5 | 60728 | 95876 | 100088 | 103402 | 15.508 | 0.54 | 3079.5 | 39.8 | 69.2 | ANCHORED |
| 4 | direct | 400 | 0 | 2246.9 | 1678 | 2153 | 2426 | 2727 | 2.227 | 5.00 | 441.9 | 23.6 | 87.0 |  |
| 4 | policy-only | 400 | 0 | 588.4 | 6540 | 8444 | 9455 | 10942 | 7.070 | 4.16 | 2708.7 | 18.5 | 49.9 |  |
| 4 | full | 400 | 0 | 55.0 | 71309 | 104333 | 128668 | 199363 | 12.773 | 0.70 | 3049.5 | 38.4 | 66.7 | ANCHORED |
| 4 | full+journal | 400 | 0 | 84.5 | 46818 | 52715 | 56257 | 61309 | 15.586 | 1.32 | 3077.2 | 40.2 | 73.9 | ANCHORED |
| 8 | direct | 400 | 0 | 2577.2 | 3038 | 3683 | 4234 | 5134 | 2.734 | 7.05 | 439.3 | 5.9 | 86.1 |  |
| 8 | policy-only | 400 | 0 | 658.3 | 11590 | 16235 | 17679 | 19312 | 6.523 | 4.29 | 2701.2 | 21.2 | 54.0 |  |
| 8 | full | 400 | 0 | 89.1 | 89100 | 100802 | 112435 | 117942 | 11.523 | 1.03 | 3048.4 | 39.8 | 69.0 | ANCHORED |
| 8 | full+journal | 400 | 0 | 81.6 | 97363 | 107269 | 113431 | 136608 | 15.156 | 1.24 | 3070.4 | 40.7 | 70.7 | ANCHORED |
| 16 | direct | 400 | 0 | 3091.7 | 5216 | 5779 | 6072 | 6302 | 2.383 | 7.37 | 421.1 | 43.7 | 87.9 |  |
| 16 | policy-only | 400 | 0 | 698.0 | 22385 | 27722 | 36256 | 37593 | 6.914 | 4.83 | 2685.9 | 27.2 | 61.0 |  |
| 16 | full | 400 | 0 | 86.8 | 180919 | 206975 | 220631 | 226531 | 14.375 | 1.25 | 3040.5 | 42.2 | 73.6 | ANCHORED |
| 16 | full+journal | 400 | 0 | 79.2 | 199685 | 217630 | 231646 | 274882 | 14.961 | 1.19 | 3060.0 | 41.7 | 79.2 | ANCHORED |

CPU source: GetProcessTimes (user + kernel) (resolution: scheduler tick (about 15.6 ms on an idle system)). Memory: K32GetProcessMemoryInfo (working set), sampled every 5 ms; heap = runtime/metrics /memory/classes/heap/objects:bytes.

## Files

- concurrent_observations: `baseline-concurrent.csv`
- concurrent_summary: `baseline-concurrent-summary.csv`
- sequential_observations: `baseline-sequential.csv`
