# Baselines and load

Local measurements on one machine with simulated providers over loopback. They compare matched configurations of this prototype under one synthetic workload; they are not a general performance claim, and repeated timing calls are not independent workloads.

Command: `agentgate-eval -host-label review-host baseline -out .tools/build3-work/baseline/diag/runs/T1 -work <work>`. Workload: financial. Go go1.26.6 on windows/amd64, 12 CPUs, GOMAXPROCS 12.  
Timer: QueryPerformanceCounter (kernel32 via golang.org/x/sys/windows), frequency 10000000 Hz, tick 100.0 ns. Wall-clock step observed for time.Now: 0.0095 ms.

## Configurations

- **direct**: no gateway: normalize (gateway normalizer), adapters.Prepare, adapters.HTTPTransport to the provider, verify the provider receipt
- **policy-only**: gateway with policy, grant, capability and signed receipts; audit sink off, no operation journal
- **full**: policy-only plus the signed hash-chained audit log, durable (fsync per entry)
- **full+journal**: full plus the fsynced operation journal
- **full-flagged**: full; the request is above the automatic limit and is flagged for audit

## Method

- Identical transport: every configuration is reached by JSON-RPC tools/call over loopback HTTP (keep-alive client, one per configuration) and reaches the provider with the adapter's HTTP transport (one fresh TCP connection per provider request).
- Identical provider: a provider host (internal/simulator behind its own loopback listener and key); every configuration has its own instance (same code, same transport, its own state) per sequential block and per concurrent cell, so state growth is equal and each evidence folder's provider journal holds only its own effects.
- Sequential: 500 paired trials in blocks of 50; in each trial every configuration gets one call, in an order rotated by one position per trial; each block starts fresh (provider, gateways, audit logs, journal) after 10 warm-up calls per configuration.
- Concurrent: client counts [1 2 4 8 16]; each configuration alone per cell, 10 warm-up calls then 400 measured calls split over the clients, back to back; CPU time is the whole process (client, server, gateway, provider host), memory peaks are sampled every 5ms.
- Every observation is kept: raw CSVs hold warm-up calls (marked) and every measured call, failed or not; summaries use every measured call (no outlier removal).
- Paired differences: per trial b - a; median with a distribution-free 95% interval (sign test order statistics), mean, and the share of trials in which b was slower.

## Sequential, paired trials (500 trials, 10 blocks, 36.9 s)

Latency per call in microseconds (all measured calls).

| config | n | min | p50 | p90 | p95 | p99 | max | mean | not committed | audit entries/call | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| direct | 500 | 1027 | 1226 | 1638 | 1777 | 2086 | 7127 | 1318 | 0 | 0.00 |  |
| policy-only | 500 | 3756 | 4345 | 5022 | 5374 | 6300 | 7666 | 4448 | 0 | 0.00 |  |
| full | 500 | 14145 | 15582 | 17907 | 18542 | 21796 | 29818 | 16010 | 0 | 6.00 | ANCHORED x10 |
| full+journal | 500 | 17733 | 19229 | 22541 | 23460 | 25676 | 30445 | 19821 | 0 | 6.00 | ANCHORED x10 |
| full-flagged | 500 | 14325 | 15858 | 18730 | 19407 | 22774 | 42772 | 16380 | 0 | 6.00 | ANCHORED x10 |

Paired differences (per trial, microseconds; 95% interval of the median from the sign test):

| difference | n | median | 95% CI | mean | p95 | share of trials slower |
|---|---|---|---|---|---|---|
| policy-only - direct | 500 | 3083 | [3040, 3123] | 3131 | 4038 | 99.8% |
| full - policy-only | 500 | 11273 | [11176, 11368] | 11561 | 13873 | 100.0% |
| full - direct | 500 | 14335 | [14235, 14406] | 14692 | 17284 | 100.0% |
| full+journal - full | 500 | 3603 | [3472, 3730] | 3812 | 7187 | 97.8% |
| full-flagged - full | 500 | 220 | [93, 350] | 370 | 3486 | 58.8% |
| full+journal - direct | 500 | 17924 | [17804, 18104] | 18504 | 22190 | 100.0% |

Whole sequential phase: CPU 29969 ms (user 19281, kernel 10688) over 36935 ms wall; 7688.1 MiB allocated; peak working set 58.7 MiB (sampled).

## Concurrent load

Each cell runs one configuration alone; latency in microseconds; CPU is the whole process.

| clients | config | calls | not committed | calls/s | p50 | p95 | p99 | max | CPU ms/call | CPU cores busy | KiB alloc/call | peak heap MiB | peak working set MiB | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | direct | 400 | 0 | 972.1 | 941 | 1268 | 1376 | 1429 | 1.797 | 1.75 | 419.4 | 28.3 | 54.6 |  |
| 1 | policy-only | 400 | 0 | 242.5 | 4072 | 4559 | 4706 | 5099 | 5.469 | 1.33 | 2678.7 | 19.9 | 45.7 |  |
| 1 | full | 400 | 0 | 61.0 | 15777 | 20030 | 24739 | 25491 | 13.203 | 0.81 | 3040.7 | 40.3 | 65.2 | ANCHORED |
| 1 | full+journal | 400 | 0 | 49.2 | 19698 | 23576 | 25691 | 47345 | 14.141 | 0.69 | 3072.8 | 40.5 | 67.3 | ANCHORED |
| 2 | direct | 400 | 0 | 1777.2 | 1115 | 1344 | 1557 | 2142 | 1.211 | 2.15 | 429.3 | 46.3 | 84.2 |  |
| 2 | policy-only | 400 | 0 | 370.6 | 5350 | 6372 | 7027 | 7401 | 6.250 | 2.32 | 2697.3 | 19.5 | 83.3 |  |
| 2 | full | 400 | 0 | 85.9 | 22710 | 26838 | 30691 | 41553 | 11.992 | 1.03 | 3051.8 | 39.0 | 69.6 | ANCHORED |
| 2 | full+journal | 400 | 0 | 74.8 | 26066 | 30360 | 36004 | 43142 | 14.727 | 1.10 | 3078.8 | 40.2 | 67.6 | ANCHORED |
| 4 | direct | 400 | 0 | 2404.6 | 1559 | 2043 | 2245 | 3526 | 1.758 | 4.23 | 444.4 | 44.1 | 84.6 |  |
| 4 | policy-only | 400 | 0 | 604.4 | 6417 | 8332 | 9031 | 10107 | 5.156 | 3.12 | 2704.8 | 19.9 | 49.9 |  |
| 4 | full | 400 | 0 | 94.1 | 41876 | 46505 | 48591 | 55390 | 10.742 | 1.01 | 3046.4 | 39.7 | 67.7 | ANCHORED |
| 4 | full+journal | 400 | 0 | 80.0 | 48028 | 65463 | 78847 | 88290 | 15.859 | 1.27 | 3085.4 | 40.3 | 68.8 | ANCHORED |
| 8 | direct | 400 | 0 | 2780.8 | 2772 | 3356 | 4922 | 6172 | 1.602 | 4.45 | 441.6 | 48.2 | 86.7 |  |
| 8 | policy-only | 400 | 0 | 709.5 | 10923 | 14565 | 16365 | 19383 | 6.719 | 4.77 | 2701.9 | 20.7 | 52.8 |  |
| 8 | full | 400 | 0 | 92.0 | 86932 | 96463 | 101291 | 116046 | 12.813 | 1.18 | 3047.8 | 41.2 | 69.7 | ANCHORED |
| 8 | full+journal | 400 | 0 | 78.9 | 98770 | 120464 | 125580 | 130926 | 18.320 | 1.45 | 3077.6 | 40.0 | 69.7 | ANCHORED |
| 16 | direct | 400 | 0 | 3041.2 | 5140 | 5995 | 6232 | 6382 | 1.875 | 5.70 | 424.0 | 46.2 | 85.0 |  |
| 16 | policy-only | 400 | 0 | 721.3 | 21662 | 27958 | 36494 | 38012 | 7.070 | 5.10 | 2685.9 | 24.5 | 60.5 |  |
| 16 | full | 400 | 0 | 93.1 | 170638 | 182020 | 189583 | 228144 | 11.602 | 1.08 | 3041.0 | 41.0 | 72.0 | ANCHORED |
| 16 | full+journal | 400 | 0 | 84.1 | 187102 | 209836 | 219807 | 235157 | 13.516 | 1.14 | 3074.3 | 44.0 | 79.9 | ANCHORED |

CPU source: GetProcessTimes (user + kernel) (resolution: scheduler tick (about 15.6 ms on an idle system)). Memory: K32GetProcessMemoryInfo (working set), sampled every 5 ms; heap = runtime/metrics /memory/classes/heap/objects:bytes.

## Files

- concurrent_observations: `baseline-concurrent.csv`
- concurrent_summary: `baseline-concurrent-summary.csv`
- sequential_observations: `baseline-sequential.csv`
