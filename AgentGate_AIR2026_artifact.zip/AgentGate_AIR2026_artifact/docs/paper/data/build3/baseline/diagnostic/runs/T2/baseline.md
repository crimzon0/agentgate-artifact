# Baselines and load

Local measurements on one machine with simulated providers over loopback. They compare matched configurations of this prototype under one synthetic workload; they are not a general performance claim, and repeated timing calls are not independent workloads.

Command: `agentgate-eval -host-label review-host baseline -out .tools/build3-work/baseline/diag/runs/T2 -work <work>`. Workload: financial. Go go1.26.6 on windows/amd64, 12 CPUs, GOMAXPROCS 12.  
Timer: QueryPerformanceCounter (kernel32 via golang.org/x/sys/windows), frequency 10000000 Hz, tick 100.0 ns. Wall-clock step observed for time.Now: 0.5060 ms.

## Configurations

- **direct**: no gateway: normalize (gateway normalizer), adapters.Prepare, adapters.HTTPTransport to the provider, verify the provider receipt
- **policy-only**: gateway with policy, grant, capability and signed receipts; audit sink off, no operation journal
- **full**: policy-only plus the signed hash-chained audit log, durable (fsync per entry)
- **full+journal**: full plus the fsynced operation journal
- **full-flagged**: full; the request is above the automatic limit and is flagged for audit

## Method

- Identical transport: every configuration is reached by JSON-RPC tools/call over loopback HTTP (keep-alive client, one per configuration) and reaches the provider with the adapter's HTTP transport (one fresh TCP connection per provider request).
- Identical provider: a provider host (internal/simulator behind its own loopback listener and key); every configuration has its own instance (same code, same transport, its own state) per sequential block and per concurrent cell, so state growth is equal and each evidence folder's provider journal holds only its own effects.
- Sequential: 500 paired trials in blocks of 50; in each trial every configuration gets one call, in an order rotated by one position per trial; each block starts fresh (provider, gateways, audit logs, journal) after 10 warm-up calls per configuration.
- Concurrent: client counts [1 2 4 8 16]; each configuration alone per cell, 10 warm-up calls then 400 measured calls split over the clients, back to back; CPU time is the whole process (client, server, gateway, provider host), memory peaks are sampled every 5ms.
- Every observation is kept: raw CSVs hold warm-up calls (marked) and every measured call, failed or not; summaries use every measured call (no outlier removal).
- Paired differences: per trial b - a; median with a distribution-free 95% interval (sign test order statistics), mean, and the share of trials in which b was slower.

## Sequential, paired trials (500 trials, 10 blocks, 38.5 s)

Latency per call in microseconds (all measured calls).

| config | n | min | p50 | p90 | p95 | p99 | max | mean | not committed | audit entries/call | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| direct | 500 | 1037 | 1324 | 1686 | 1832 | 2066 | 2671 | 1388 | 0 | 0.00 |  |
| policy-only | 500 | 3795 | 4597 | 5502 | 5933 | 7052 | 13027 | 4728 | 0 | 0.00 |  |
| full | 500 | 14466 | 16389 | 18140 | 19131 | 22408 | 42752 | 16798 | 0 | 6.00 | ANCHORED x10 |
| full+journal | 500 | 17834 | 20357 | 23202 | 24187 | 26712 | 28690 | 20787 | 0 | 6.00 | ANCHORED x10 |
| full-flagged | 500 | 14664 | 16782 | 18568 | 19561 | 23752 | 44512 | 17109 | 0 | 6.00 | ANCHORED x10 |

Paired differences (per trial, microseconds; 95% interval of the median from the sign test):

| difference | n | median | 95% CI | mean | p95 | share of trials slower |
|---|---|---|---|---|---|---|
| policy-only - direct | 500 | 3249 | [3202, 3300] | 3340 | 4446 | 100.0% |
| full - policy-only | 500 | 11778 | [11722, 11938] | 12070 | 14401 | 100.0% |
| full - direct | 500 | 15029 | [14938, 15163] | 15410 | 17684 | 100.0% |
| full+journal - full | 500 | 3920 | [3826, 4018] | 3989 | 7230 | 98.0% |
| full-flagged - full | 500 | 289 | [131, 396] | 311 | 2698 | 58.0% |
| full+journal - direct | 500 | 18977 | [18827, 19137] | 19399 | 22804 | 100.0% |

Whole sequential phase: CPU 31844 ms (user 21375, kernel 10469) over 38510 ms wall; 7684.8 MiB allocated; peak working set 58.2 MiB (sampled).

## Concurrent load

Each cell runs one configuration alone; latency in microseconds; CPU is the whole process.

| clients | config | calls | not committed | calls/s | p50 | p95 | p99 | max | CPU ms/call | CPU cores busy | KiB alloc/call | peak heap MiB | peak working set MiB | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | direct | 400 | 0 | 928.5 | 984 | 1342 | 1460 | 1585 | 1.289 | 1.20 | 427.3 | 27.4 | 57.7 |  |
| 1 | policy-only | 400 | 0 | 230.5 | 4262 | 4920 | 5553 | 6040 | 5.664 | 1.31 | 2680.2 | 20.1 | 45.4 |  |
| 1 | full | 400 | 0 | 59.1 | 16582 | 19828 | 21181 | 41548 | 11.445 | 0.68 | 3043.4 | 40.2 | 65.9 | ANCHORED |
| 1 | full+journal | 400 | 0 | 48.3 | 20330 | 23442 | 25136 | 26405 | 15.391 | 0.74 | 3072.4 | 40.0 | 66.8 | ANCHORED |
| 2 | direct | 400 | 0 | 1821.9 | 1082 | 1336 | 1521 | 1820 | 1.211 | 2.21 | 423.9 | 48.0 | 84.5 |  |
| 2 | policy-only | 400 | 0 | 371.4 | 5380 | 6314 | 6661 | 6993 | 5.977 | 2.22 | 2698.4 | 20.0 | 78.5 |  |
| 2 | full | 400 | 0 | 85.9 | 22963 | 26703 | 28549 | 30828 | 12.109 | 1.04 | 3054.2 | 39.9 | 66.2 | ANCHORED |
| 2 | full+journal | 400 | 0 | 71.5 | 27276 | 31738 | 34176 | 51953 | 15.000 | 1.07 | 3080.2 | 39.5 | 67.0 | ANCHORED |
| 4 | direct | 400 | 0 | 2361.1 | 1612 | 2096 | 2425 | 2655 | 1.836 | 4.33 | 437.8 | 44.2 | 86.0 |  |
| 4 | policy-only | 400 | 0 | 583.6 | 6624 | 8933 | 9998 | 11073 | 5.547 | 3.24 | 2705.7 | 20.8 | 50.3 |  |
| 4 | full | 400 | 0 | 85.4 | 46233 | 52693 | 56820 | 60636 | 13.789 | 1.18 | 3052.2 | 40.1 | 68.0 | ANCHORED |
| 4 | full+journal | 400 | 0 | 84.5 | 46756 | 53568 | 57778 | 67304 | 15.000 | 1.27 | 3090.3 | 39.4 | 72.9 | ANCHORED |
| 8 | direct | 400 | 0 | 2542.5 | 3112 | 3838 | 4178 | 4503 | 2.344 | 5.96 | 431.4 | 41.9 | 86.9 |  |
| 8 | policy-only | 400 | 0 | 682.2 | 11037 | 16069 | 18592 | 20737 | 6.680 | 4.56 | 2700.3 | 20.9 | 53.9 |  |
| 8 | full | 400 | 0 | 89.5 | 87881 | 102774 | 116491 | 123343 | 12.813 | 1.15 | 3053.5 | 41.2 | 70.7 | ANCHORED |
| 8 | full+journal | 400 | 0 | 84.5 | 94274 | 101859 | 105750 | 131036 | 15.859 | 1.34 | 3076.5 | 41.3 | 71.2 | ANCHORED |
| 16 | direct | 400 | 0 | 3143.3 | 5038 | 5979 | 6412 | 6689 | 1.563 | 4.91 | 421.2 | 46.4 | 83.3 |  |
| 16 | policy-only | 400 | 0 | 745.5 | 21172 | 26421 | 29563 | 36519 | 7.422 | 5.53 | 2690.9 | 25.9 | 60.2 |  |
| 16 | full | 400 | 0 | 90.9 | 174398 | 189482 | 198255 | 240753 | 14.258 | 1.30 | 3040.6 | 41.4 | 72.4 | ANCHORED |
| 16 | full+journal | 400 | 0 | 83.7 | 188152 | 201856 | 216988 | 232551 | 15.391 | 1.29 | 3068.6 | 40.7 | 81.1 | ANCHORED |

CPU source: GetProcessTimes (user + kernel) (resolution: scheduler tick (about 15.6 ms on an idle system)). Memory: K32GetProcessMemoryInfo (working set), sampled every 5 ms; heap = runtime/metrics /memory/classes/heap/objects:bytes.

## Files

- concurrent_observations: `baseline-concurrent.csv`
- concurrent_summary: `baseline-concurrent-summary.csv`
- sequential_observations: `baseline-sequential.csv`
