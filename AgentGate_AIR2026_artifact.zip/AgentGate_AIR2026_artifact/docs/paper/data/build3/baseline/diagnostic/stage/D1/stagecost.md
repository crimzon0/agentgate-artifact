# Per-stage cost of a durable audit append

Per-entry stage times of audit.Append (WriteDurable) on one computer; absolute values depend on the disk, its fill level, the file system, antivirus scanning and background load. Only a run on an idle machine counts.

- Command: `go test -count=1 -v -run '^TestStageCost$' ./internal/audit/ -stagecost=10000 -stagecost.warmup=200 -stagecost.work=<dir>`; go1.26.6 on windows/amd64, 12 CPUs; 46.6 s.
- Storage: volume C:\, NTFS, 2000 GB, 98 % full.
- Timer: QueryPerformanceCounter, 10000000 Hz (tick 100.0 ns); one read costs about 65.6 ns (a staged append has 18 reads).
- Corpus: synthetic six-entry financial call (stageCallShape) (6 events, cycled); mean line 2133 bytes. 200 warm-up + 10000 timed appends per path. staged and uninstrumented appends alternate entry by entry; the first position alternates from entry to entry and flips once per pass over the corpus, so each event goes first on each path equally often; two fresh logs on the same volume.

## Stages (us per entry)

| Stage | What | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode_entry | lock, checks, clock, Entry built (artifacts to base64), encodeCompact (encode + hash) | 12.30 | 39.20 | 13.82 | 280.90 |
| decode_entry | decodeEntry: the copy Append returns (encode + hash) | 19.50 | 55.70 | 21.70 | 274.70 |
| hash_entry | SHA-256 entry hash, hex (encode + hash) | 1.20 | 2.90 | 1.35 | 39.20 |
| sign_entry | Ed25519 signature of the entry hash, base64 (Ed25519 signing) | 18.00 | 49.40 | 20.64 | 177.80 |
| format_line | audit.jsonl line assembled (encode + hash) | 1.10 | 8.80 | 1.54 | 164.90 |
| write_line | write of the line to audit.jsonl (O_APPEND) (log line write) | 8.90 | 48.60 | 10.60 | 174.40 |
| fsync_log | fsync of audit.jsonl (FlushFileBuffers) (log fsync) | 408.70 | 882.67 | 599.58 | 74198.50 |
| bookkeeping | seq, head hash, time and stored line updated (encode + hash) | 0.30 | 0.90 | 0.42 | 164.40 |
| sign_head | Ed25519 signature of the head message, Head built (Ed25519 signing) | 18.80 | 52.50 | 21.03 | 160.20 |
| encode_head | head.json bytes (indented JSON) (encode + hash) | 4.70 | 16.90 | 5.60 | 137.60 |
| create_temp | os.CreateTemp next to head.json (temp head write) | 137.80 | 264.01 | 147.27 | 558.50 |
| write_temp | write of the head bytes to the temporary file (temp head write) | 35.20 | 82.30 | 38.11 | 248.80 |
| fsync_temp | fsync of the temporary head file (head fsync) | 732.30 | 1661.32 | 1105.35 | 272622.60 |
| close_temp | close of the temporary head file (temp head write) | 34.60 | 77.81 | 37.31 | 512.80 |
| rename | rename over head.json (MoveFileEx, replace existing) (head rename) | 248.60 | 428.40 | 260.81 | 3128.10 |
| fsync_dir | syncDir: returns at once on Windows (no directory fsync) (directory fsync) | 0.10 | 0.30 | 0.14 | 30.90 |
| head_digest | SHA-256 of the head bytes, computed and discarded by WriteJSONAtomic (encode + hash) | 1.00 | 3.50 | 1.26 | 41.40 |

## Groups (us per entry; a group's value is the sum of its stages within each entry)

| Group | Stages | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode + hash | encode_entry, decode_entry, hash_entry, format_line, bookkeeping, encode_head, head_digest | 42.30 | 100.50 | 45.69 | 323.00 |
| Ed25519 signing | sign_entry, sign_head | 39.05 | 80.60 | 41.67 | 205.70 |
| log line write | write_line | 8.90 | 48.60 | 10.60 | 174.40 |
| log fsync | fsync_log | 408.70 | 882.67 | 599.58 | 74198.50 |
| temp head write | create_temp, write_temp, close_temp | 211.00 | 374.21 | 222.68 | 719.90 |
| head fsync | fsync_temp | 732.30 | 1661.32 | 1105.35 | 272622.60 |
| head rename | rename | 248.60 | 428.40 | 260.81 | 3128.10 |
| directory fsync | fsync_dir | 0.10 | 0.30 | 0.14 | 30.90 |
| staged total | sum of the stages of one staged append (includes the timer reads between stages) | 1725.40 | 33599.52 | 2286.52 | 274169.80 |
| Append | audit.Append timed as a whole on the second log (no timer reads inside) | 1724.80 | 33668.89 | 2292.14 | 201173.10 |

## Per call (6 gateway entries)

- Sums of 6 consecutive appends (one call) (1666 blocks): median 10.58 ms, p99 48.94 ms, mean 13.75 ms; the median is 93 % of the 11.40 ms recorded-minus-mediated paired median (not an exact decomposition).
- Serial rate predicted from the mean append: 1e6 / (6 x 2292.14 us) = 72.7 calls/s (observed in the baseline: 94.3).
- Uninstrumented appends over 10 ms: 140 of 10000.

With the synthetic corpus any six consecutive entries hold each event of the call once, so a block sum is one call's worth of appends. It is not an exact decomposition of the recorded-minus-mediated median: that median also contains the gateway's work to build the six events (not timed here), and the two figures come from different measurements (a paired difference of call latencies in the baseline session against a sum of appends timed here on their own). Appends of one log are serialized by its mutex, so with everything else running in parallel the log predicts about 1e6 / (entries per call x mean append us) calls/s for calls of this corpus's entries; the mean, not the median, sets that rate, so slow flushes lower it.

- Directory fsync: none on Windows: AgentGate's syncDir returns at once there (audit.go), so the fsync_dir stage times only that call. On other systems syncDir opens and fsyncs the run directory once per append, after the rename.
- Witness update: measured separately by internal/headwitness's TestWitnessPushCost (push_bench_test.go): a push is a separate round trip to the witness after the append. No reported latency includes one (the baseline runs no witness; the demo pushes the head after each agent step, outside the gateway call).
