# Per-stage cost of a durable audit append

Per-entry stage times of audit.Append (WriteDurable) on one computer; absolute values depend on the disk, its fill level, the file system, antivirus scanning and background load. Only a run on an idle machine counts.

- Command: `go test -count=1 -v -run '^TestStageCost$' ./internal/audit/ -stagecost=10000 -stagecost.warmup=200 -stagecost.work=<dir>`; go1.26.6 on windows/amd64, 12 CPUs; 40.2 s.
- Storage: volume C:\, NTFS, 2000 GB, 98 % full.
- Timer: QueryPerformanceCounter, 10000000 Hz (tick 100.0 ns); one read costs about 54.7 ns (a staged append has 18 reads).
- Corpus: synthetic six-entry financial call (stageCallShape) (6 events, cycled); mean line 2133 bytes. 200 warm-up + 10000 timed appends per path. staged and uninstrumented appends alternate entry by entry; the first position alternates from entry to entry and flips once per pass over the corpus, so each event goes first on each path equally often; two fresh logs on the same volume.

## Stages (us per entry)

| Stage | What | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode_entry | lock, checks, clock, Entry built (artifacts to base64), encodeCompact (encode + hash) | 12.50 | 45.90 | 15.85 | 4941.50 |
| decode_entry | decodeEntry: the copy Append returns (encode + hash) | 20.10 | 59.81 | 23.07 | 790.40 |
| hash_entry | SHA-256 entry hash, hex (encode + hash) | 1.20 | 3.30 | 1.39 | 35.90 |
| sign_entry | Ed25519 signature of the entry hash, base64 (Ed25519 signing) | 18.40 | 52.10 | 22.58 | 4830.00 |
| format_line | audit.jsonl line assembled (encode + hash) | 1.10 | 8.60 | 1.59 | 159.10 |
| write_line | write of the line to audit.jsonl (O_APPEND) (log line write) | 9.20 | 66.00 | 12.32 | 1307.10 |
| fsync_log | fsync of audit.jsonl (FlushFileBuffers) (log fsync) | 414.00 | 3056.02 | 503.68 | 7933.10 |
| bookkeeping | seq, head hash, time and stored line updated (encode + hash) | 0.30 | 0.80 | 0.42 | 192.10 |
| sign_head | Ed25519 signature of the head message, Head built (Ed25519 signing) | 19.00 | 52.40 | 22.76 | 4020.00 |
| encode_head | head.json bytes (indented JSON) (encode + hash) | 4.80 | 19.90 | 6.65 | 4573.00 |
| create_temp | os.CreateTemp next to head.json (temp head write) | 138.20 | 326.40 | 156.45 | 7616.30 |
| write_temp | write of the head bytes to the temporary file (temp head write) | 35.20 | 95.10 | 39.62 | 3800.70 |
| fsync_temp | fsync of the temporary head file (head fsync) | 736.80 | 3107.61 | 836.91 | 26297.60 |
| close_temp | close of the temporary head file (temp head write) | 34.80 | 89.70 | 39.04 | 1674.70 |
| rename | rename over head.json (MoveFileEx, replace existing) (head rename) | 253.45 | 603.10 | 282.41 | 11030.10 |
| fsync_dir | syncDir: returns at once on Windows (no directory fsync) (directory fsync) | 0.10 | 0.30 | 0.13 | 8.40 |
| head_digest | SHA-256 of the head bytes, computed and discarded by WriteJSONAtomic (encode + hash) | 1.00 | 3.80 | 1.28 | 49.10 |

## Groups (us per entry; a group's value is the sum of its stages within each entry)

| Group | Stages | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode + hash | encode_entry, decode_entry, hash_entry, format_line, bookkeeping, encode_head, head_digest | 43.00 | 118.01 | 50.25 | 4989.90 |
| Ed25519 signing | sign_entry, sign_head | 39.80 | 92.70 | 45.34 | 4876.50 |
| log line write | write_line | 9.20 | 66.00 | 12.32 | 1307.10 |
| log fsync | fsync_log | 414.00 | 3056.02 | 503.68 | 7933.10 |
| temp head write | create_temp, write_temp, close_temp | 210.10 | 516.32 | 235.11 | 7764.50 |
| head fsync | fsync_temp | 736.80 | 3107.61 | 836.91 | 26297.60 |
| head rename | rename | 253.45 | 603.10 | 282.41 | 11030.10 |
| directory fsync | fsync_dir | 0.10 | 0.30 | 0.13 | 8.40 |
| staged total | sum of the stages of one staged append (includes the timer reads between stages) | 1743.60 | 6275.50 | 1966.16 | 27409.50 |
| Append | audit.Append timed as a whole on the second log (no timer reads inside) | 1741.25 | 6181.73 | 1968.52 | 113753.20 |

## Per call (6 gateway entries)

- Sums of 6 consecutive appends (one call) (1666 blocks): median 10.64 ms, p99 28.61 ms, mean 11.81 ms; the median is 93 % of the 11.40 ms recorded-minus-mediated paired median (not an exact decomposition).
- Serial rate predicted from the mean append: 1e6 / (6 x 1968.52 us) = 84.7 calls/s (observed in the baseline: 94.3).
- Uninstrumented appends over 10 ms: 14 of 10000.

With the synthetic corpus any six consecutive entries hold each event of the call once, so a block sum is one call's worth of appends. It is not an exact decomposition of the recorded-minus-mediated median: that median also contains the gateway's work to build the six events (not timed here), and the two figures come from different measurements (a paired difference of call latencies in the baseline session against a sum of appends timed here on their own). Appends of one log are serialized by its mutex, so with everything else running in parallel the log predicts about 1e6 / (entries per call x mean append us) calls/s for calls of this corpus's entries; the mean, not the median, sets that rate, so slow flushes lower it.

- Directory fsync: none on Windows: AgentGate's syncDir returns at once there (audit.go), so the fsync_dir stage times only that call. On other systems syncDir opens and fsyncs the run directory once per append, after the rename.
- Witness update: measured separately by internal/headwitness's TestWitnessPushCost (push_bench_test.go): a push is a separate round trip to the witness after the append. No reported latency includes one (the baseline runs no witness; the demo pushes the head after each agent step, outside the gateway call).
