# Per-stage cost of a durable audit append

Per-entry stage times of audit.Append (WriteDurable) on one computer; absolute values depend on the disk, its fill level, the file system, antivirus scanning and background load. Only a run on an idle machine counts.

- Command: `go test -count=1 -v -run '^TestStageCost$' ./internal/audit/ -stagecost=10000 -stagecost.warmup=200 -stagecost.work=<dir>`; go1.26.6 on windows/amd64, 12 CPUs; 37.5 s.
- Storage: volume C:\, NTFS, 2000 GB, 98 % full.
- Timer: QueryPerformanceCounter, 10000000 Hz (tick 100.0 ns); one read costs about 50.4 ns (a staged append has 18 reads).
- Corpus: synthetic six-entry financial call (stageCallShape) (6 events, cycled); mean line 2133 bytes. 200 warm-up + 10000 timed appends per path. staged and uninstrumented appends alternate entry by entry; the first position alternates from entry to entry and flips once per pass over the corpus, so each event goes first on each path equally often; two fresh logs on the same volume.

## Stages (us per entry)

| Stage | What | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode_entry | lock, checks, clock, Entry built (artifacts to base64), encodeCompact (encode + hash) | 12.70 | 40.90 | 14.27 | 664.20 |
| decode_entry | decodeEntry: the copy Append returns (encode + hash) | 20.20 | 55.30 | 22.50 | 227.60 |
| hash_entry | SHA-256 entry hash, hex (encode + hash) | 1.20 | 3.10 | 1.41 | 87.10 |
| sign_entry | Ed25519 signature of the entry hash, base64 (Ed25519 signing) | 18.60 | 50.50 | 21.46 | 141.90 |
| format_line | audit.jsonl line assembled (encode + hash) | 1.10 | 8.60 | 1.57 | 92.40 |
| write_line | write of the line to audit.jsonl (O_APPEND) (log line write) | 9.60 | 72.21 | 11.94 | 169.50 |
| fsync_log | fsync of audit.jsonl (FlushFileBuffers) (log fsync) | 414.15 | 806.51 | 446.78 | 6356.40 |
| bookkeeping | seq, head hash, time and stored line updated (encode + hash) | 0.30 | 0.80 | 0.41 | 188.90 |
| sign_head | Ed25519 signature of the head message, Head built (Ed25519 signing) | 19.00 | 49.50 | 21.48 | 320.60 |
| encode_head | head.json bytes (indented JSON) (encode + hash) | 4.90 | 17.30 | 5.84 | 169.10 |
| create_temp | os.CreateTemp next to head.json (temp head write) | 142.00 | 258.50 | 152.02 | 3203.70 |
| write_temp | write of the head bytes to the temporary file (temp head write) | 36.20 | 89.40 | 39.23 | 562.20 |
| fsync_temp | fsync of the temporary head file (head fsync) | 735.30 | 1355.01 | 778.15 | 2577.70 |
| close_temp | close of the temporary head file (temp head write) | 35.50 | 83.10 | 38.65 | 3264.90 |
| rename | rename over head.json (MoveFileEx, replace existing) (head rename) | 263.60 | 459.41 | 277.03 | 10880.50 |
| fsync_dir | syncDir: returns at once on Windows (no directory fsync) (directory fsync) | 0.10 | 0.30 | 0.14 | 27.20 |
| head_digest | SHA-256 of the head bytes, computed and discarded by WriteJSONAtomic (encode + hash) | 1.10 | 3.50 | 1.29 | 168.30 |

## Groups (us per entry; a group's value is the sum of its stages within each entry)

| Group | Stages | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode + hash | encode_entry, decode_entry, hash_entry, format_line, bookkeeping, encode_head, head_digest | 43.70 | 107.20 | 47.28 | 712.10 |
| Ed25519 signing | sign_entry, sign_head | 40.30 | 80.90 | 42.94 | 339.80 |
| log line write | write_line | 9.60 | 72.21 | 11.94 | 169.50 |
| log fsync | fsync_log | 414.15 | 806.51 | 446.78 | 6356.40 |
| temp head write | create_temp, write_temp, close_temp | 216.30 | 386.90 | 229.90 | 3434.60 |
| head fsync | fsync_temp | 735.30 | 1355.01 | 778.15 | 2577.70 |
| head rename | rename | 263.60 | 459.41 | 277.03 | 10880.50 |
| directory fsync | fsync_dir | 0.10 | 0.30 | 0.14 | 27.20 |
| staged total | sum of the stages of one staged append (includes the timer reads between stages) | 1759.45 | 2809.22 | 1834.17 | 12440.80 |
| Append | audit.Append timed as a whole on the second log (no timer reads inside) | 1756.00 | 2784.01 | 1835.52 | 27814.00 |

## Per call (6 gateway entries)

- Sums of 6 consecutive appends (one call) (1666 blocks): median 10.75 ms, p99 14.01 ms, mean 11.01 ms; the median is 94 % of the 11.40 ms recorded-minus-mediated paired median (not an exact decomposition).
- Serial rate predicted from the mean append: 1e6 / (6 x 1835.52 us) = 90.8 calls/s (observed in the baseline: 94.3).
- Uninstrumented appends over 10 ms: 2 of 10000.

With the synthetic corpus any six consecutive entries hold each event of the call once, so a block sum is one call's worth of appends. It is not an exact decomposition of the recorded-minus-mediated median: that median also contains the gateway's work to build the six events (not timed here), and the two figures come from different measurements (a paired difference of call latencies in the baseline session against a sum of appends timed here on their own). Appends of one log are serialized by its mutex, so with everything else running in parallel the log predicts about 1e6 / (entries per call x mean append us) calls/s for calls of this corpus's entries; the mean, not the median, sets that rate, so slow flushes lower it.

- Directory fsync: none on Windows: AgentGate's syncDir returns at once there (audit.go), so the fsync_dir stage times only that call. On other systems syncDir opens and fsyncs the run directory once per append, after the rename.
- Witness update: measured separately by internal/headwitness's TestWitnessPushCost (push_bench_test.go): a push is a separate round trip to the witness after the append. No reported latency includes one (the baseline runs no witness; the demo pushes the head after each agent step, outside the gateway call).
