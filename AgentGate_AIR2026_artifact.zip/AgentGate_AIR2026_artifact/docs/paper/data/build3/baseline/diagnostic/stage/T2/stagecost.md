# Per-stage cost of a durable audit append

Per-entry stage times of audit.Append (WriteDurable) on one computer; absolute values depend on the disk, its fill level, the file system, antivirus scanning and background load. Only a run on an idle machine counts.

- Command: `go test -count=1 -v -run '^TestStageCost$' ./internal/audit/ -stagecost=10000 -stagecost.warmup=200 -stagecost.work=<dir>`; go1.26.6 on windows/amd64, 12 CPUs; 59.5 s.
- Storage: volume C:\, NTFS, 2000 GB, 98 % full.
- Timer: QueryPerformanceCounter, 10000000 Hz (tick 100.0 ns); one read costs about 48.2 ns (a staged append has 18 reads).
- Corpus: synthetic six-entry financial call (stageCallShape) (6 events, cycled); mean line 2133 bytes. 200 warm-up + 10000 timed appends per path. staged and uninstrumented appends alternate entry by entry; the first position alternates from entry to entry and flips once per pass over the corpus, so each event goes first on each path equally often; two fresh logs on the same volume.

## Stages (us per entry)

| Stage | What | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode_entry | lock, checks, clock, Entry built (artifacts to base64), encodeCompact (encode + hash) | 13.80 | 47.91 | 15.85 | 1201.30 |
| decode_entry | decodeEntry: the copy Append returns (encode + hash) | 21.00 | 62.00 | 23.84 | 2733.20 |
| hash_entry | SHA-256 entry hash, hex (encode + hash) | 1.20 | 3.50 | 1.40 | 44.90 |
| sign_entry | Ed25519 signature of the entry hash, base64 (Ed25519 signing) | 19.50 | 58.11 | 22.37 | 909.40 |
| format_line | audit.jsonl line assembled (encode + hash) | 1.20 | 8.70 | 1.60 | 46.60 |
| write_line | write of the line to audit.jsonl (O_APPEND) (log line write) | 9.90 | 54.20 | 12.20 | 1809.60 |
| fsync_log | fsync of audit.jsonl (FlushFileBuffers) (log fsync) | 411.80 | 28279.79 | 802.87 | 48625.50 |
| bookkeeping | seq, head hash, time and stored line updated (encode + hash) | 0.30 | 1.00 | 0.54 | 447.00 |
| sign_head | Ed25519 signature of the head message, Head built (Ed25519 signing) | 19.10 | 61.30 | 22.33 | 733.10 |
| encode_head | head.json bytes (indented JSON) (encode + hash) | 5.20 | 19.30 | 6.12 | 467.40 |
| create_temp | os.CreateTemp next to head.json (temp head write) | 145.30 | 295.31 | 161.04 | 32410.90 |
| write_temp | write of the head bytes to the temporary file (temp head write) | 37.50 | 88.51 | 40.82 | 896.20 |
| fsync_temp | fsync of the temporary head file (head fsync) | 734.50 | 33249.89 | 1449.28 | 61255.50 |
| close_temp | close of the temporary head file (temp head write) | 35.90 | 100.10 | 39.95 | 890.20 |
| rename | rename over head.json (MoveFileEx, replace existing) (head rename) | 272.30 | 512.12 | 297.04 | 110065.00 |
| fsync_dir | syncDir: returns at once on Windows (no directory fsync) (directory fsync) | 0.10 | 0.30 | 0.15 | 33.80 |
| head_digest | SHA-256 of the head bytes, computed and discarded by WriteJSONAtomic (encode + hash) | 1.10 | 4.70 | 1.39 | 116.70 |

## Groups (us per entry; a group's value is the sum of its stages within each entry)

| Group | Stages | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode + hash | encode_entry, decode_entry, hash_entry, format_line, bookkeeping, encode_head, head_digest | 45.90 | 116.90 | 50.74 | 2807.50 |
| Ed25519 signing | sign_entry, sign_head | 41.50 | 93.30 | 44.70 | 965.30 |
| log line write | write_line | 9.90 | 54.20 | 12.20 | 1809.60 |
| log fsync | fsync_log | 411.80 | 28279.79 | 802.87 | 48625.50 |
| temp head write | create_temp, write_temp, close_temp | 223.20 | 429.91 | 241.82 | 32529.60 |
| head fsync | fsync_temp | 734.50 | 33249.89 | 1449.28 | 61255.50 |
| head rename | rename | 272.30 | 512.12 | 297.04 | 110065.00 |
| directory fsync | fsync_dir | 0.10 | 0.30 | 0.15 | 33.80 |
| staged total | sum of the stages of one staged append (includes the timer reads between stages) | 1766.55 | 35806.03 | 2898.79 | 111601.30 |
| Append | audit.Append timed as a whole on the second log (no timer reads inside) | 1765.40 | 36091.02 | 2896.42 | 113068.60 |

## Per call (6 gateway entries)

- Sums of 6 consecutive appends (one call) (1666 blocks): median 10.94 ms, p99 48.49 ms, mean 17.38 ms; the median is 96 % of the 11.40 ms recorded-minus-mediated paired median (not an exact decomposition).
- Serial rate predicted from the mean append: 1e6 / (6 x 2896.42 us) = 57.5 calls/s (observed in the baseline: 94.3).
- Uninstrumented appends over 10 ms: 322 of 10000.

With the synthetic corpus any six consecutive entries hold each event of the call once, so a block sum is one call's worth of appends. It is not an exact decomposition of the recorded-minus-mediated median: that median also contains the gateway's work to build the six events (not timed here), and the two figures come from different measurements (a paired difference of call latencies in the baseline session against a sum of appends timed here on their own). Appends of one log are serialized by its mutex, so with everything else running in parallel the log predicts about 1e6 / (entries per call x mean append us) calls/s for calls of this corpus's entries; the mean, not the median, sets that rate, so slow flushes lower it.

- Directory fsync: none on Windows: AgentGate's syncDir returns at once there (audit.go), so the fsync_dir stage times only that call. On other systems syncDir opens and fsyncs the run directory once per append, after the rename.
- Witness update: measured separately by internal/headwitness's TestWitnessPushCost (push_bench_test.go): a push is a separate round trip to the witness after the append. No reported latency includes one (the baseline runs no witness; the demo pushes the head after each agent step, outside the gateway call).
