# Baselines and load

Local measurements on one machine with simulated providers over loopback. They compare matched configurations of this prototype under one synthetic workload; they are not a general performance claim, and repeated timing calls are not independent workloads.

Command: `agentgate-eval -host-label review-host baseline -out .tools/build3-work/baseline/session/runs/M1 -work <work> -workload message -configs direct,policy-only,full,full+journal`. Workload: message. Go go1.26.6 on windows/amd64, 12 CPUs, GOMAXPROCS 12.  
Timer: QueryPerformanceCounter (kernel32 via golang.org/x/sys/windows), frequency 10000000 Hz, tick 100.0 ns. Wall-clock step observed for time.Now: 0.5067 ms.

## Configurations

- **direct**: no gateway: normalize (gateway normalizer), adapters.Prepare, adapters.HTTPTransport to the provider, verify the provider receipt
- **policy-only**: gateway with policy, grant, capability and signed receipts; audit sink off, no operation journal
- **full**: policy-only plus the signed hash-chained audit log, durable (fsync per entry)
- **full+journal**: full plus the fsynced operation journal
- **full-flagged**: full; the request is above the automatic limit and is flagged for audit

## Method

- Identical transport: every configuration is reached by JSON-RPC tools/call over loopback HTTP (keep-alive client, one per configuration) and reaches the provider with the adapter's HTTP transport (one fresh TCP connection per provider request).
- Identical provider: a provider host (internal/simulator behind its own loopback listener and key); every configuration has its own instance (same code, same transport, its own state) per sequential block and per concurrent cell, so state growth is equal and each evidence folder's provider journal holds only its own effects.
- Sequential: 500 paired trials in blocks of 50; in each trial every configuration gets one call, in an order rotated by one position per trial; each block starts fresh (provider, gateways, audit logs, journal) after 10 warm-up calls per configuration.
- Concurrent: client counts [1 2 4 8 16]; each configuration alone per cell, 10 warm-up calls then 400 measured calls split over the clients, back to back; CPU time is the whole process (client, server, gateway, provider host), memory peaks are sampled every 5ms.
- Every observation is kept: raw CSVs hold warm-up calls (marked) and every measured call, failed or not; summaries use every measured call (no outlier removal).
- Paired differences: per trial b - a; median with a distribution-free 95% interval (sign test order statistics), mean, and the share of trials in which b was slower.

## Sequential, paired trials (500 trials, 10 blocks, 27.9 s)

Latency per call in microseconds (all measured calls).

| config | n | min | p50 | p90 | p95 | p99 | max | mean | not committed | audit entries/call | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| direct | 500 | 1106 | 1415 | 1799 | 1948 | 2199 | 2521 | 1471 | 0 | 0.00 |  |
| policy-only | 500 | 3891 | 4776 | 5908 | 6231 | 7015 | 8168 | 4918 | 0 | 0.00 |  |
| full | 500 | 14460 | 16716 | 19254 | 20234 | 21882 | 35024 | 17077 | 0 | 6.00 | ANCHORED x10 |
| full+journal | 500 | 17739 | 20543 | 23252 | 24129 | 26466 | 46850 | 20877 | 0 | 6.00 | ANCHORED x10 |

Paired differences (per trial, microseconds; 95% interval of the median from the sign test):

| difference | n | median | 95% CI | mean | p95 | share of trials slower |
|---|---|---|---|---|---|---|
| policy-only - direct | 500 | 3336 | [3293, 3405] | 3447 | 4723 | 100.0% |
| full - policy-only | 500 | 11968 | [11805, 12065] | 12159 | 15199 | 100.0% |
| full - direct | 500 | 15287 | [15112, 15421] | 15606 | 18664 | 100.0% |
| full+journal - full | 500 | 3690 | [3574, 3794] | 3800 | 7112 | 96.8% |
| full+journal - direct | 500 | 19056 | [18931, 19229] | 19406 | 22425 | 100.0% |

Whole sequential phase: CPU 23766 ms (user 16266, kernel 7500) over 27920 ms wall; 6083.6 MiB allocated; peak working set 49.6 MiB (sampled).

## Concurrent load

Each cell runs one configuration alone; latency in microseconds; CPU is the whole process.

| clients | config | calls | not committed | calls/s | p50 | p95 | p99 | max | CPU ms/call | CPU cores busy | KiB alloc/call | peak heap MiB | peak working set MiB | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | direct | 400 | 0 | 963.2 | 948 | 1266 | 1346 | 1456 | 1.406 | 1.35 | 447.8 | 22.6 | 50.1 |  |
| 1 | policy-only | 400 | 0 | 230.6 | 4276 | 4766 | 4885 | 5586 | 4.805 | 1.11 | 2817.9 | 19.9 | 45.5 |  |
| 1 | full | 400 | 0 | 59.1 | 16535 | 19424 | 23730 | 38026 | 12.500 | 0.74 | 3226.5 | 40.1 | 66.1 | ANCHORED |
| 1 | full+journal | 400 | 0 | 46.7 | 20524 | 24863 | 34619 | 131366 | 14.336 | 0.67 | 3257.7 | 40.5 | 70.6 | ANCHORED |
| 2 | direct | 400 | 0 | 1572.5 | 1247 | 1523 | 1738 | 2044 | 2.461 | 3.87 | 463.1 | 46.3 | 83.4 |  |
| 2 | policy-only | 400 | 0 | 382.9 | 5101 | 6748 | 7828 | 8785 | 5.234 | 2.00 | 2836.3 | 20.1 | 81.6 |  |
| 2 | full | 400 | 0 | 85.7 | 22870 | 27298 | 32470 | 38947 | 14.141 | 1.21 | 3232.2 | 39.1 | 66.4 | ANCHORED |
| 2 | full+journal | 400 | 0 | 63.3 | 27599 | 63908 | 68402 | 104179 | 14.375 | 0.91 | 3259.8 | 40.2 | 67.8 | ANCHORED |
| 4 | direct | 400 | 0 | 2200.3 | 1682 | 2334 | 2837 | 3602 | 2.031 | 4.47 | 470.8 | 47.8 | 85.0 |  |
| 4 | policy-only | 400 | 0 | 559.8 | 6856 | 9208 | 10157 | 11400 | 7.969 | 4.46 | 2849.6 | 22.2 | 50.7 |  |
| 4 | full | 400 | 0 | 45.5 | 82584 | 120513 | 124527 | 142324 | 14.648 | 0.67 | 3239.0 | 40.0 | 68.5 | ANCHORED |
| 4 | full+journal | 400 | 0 | 38.8 | 105563 | 134503 | 147844 | 158737 | 15.742 | 0.61 | 3266.9 | 41.1 | 69.4 | ANCHORED |
| 8 | direct | 400 | 0 | 2468.2 | 3122 | 3842 | 4624 | 5668 | 2.344 | 5.79 | 463.9 | 44.2 | 82.0 |  |
| 8 | policy-only | 400 | 0 | 610.9 | 12476 | 17573 | 20261 | 21195 | 7.070 | 4.32 | 2845.1 | 23.1 | 54.8 |  |
| 8 | full | 400 | 0 | 90.6 | 87169 | 101239 | 114322 | 122734 | 13.281 | 1.20 | 3234.7 | 40.8 | 70.5 | ANCHORED |
| 8 | full+journal | 400 | 0 | 41.1 | 207175 | 243369 | 251234 | 278534 | 14.570 | 0.60 | 3258.6 | 42.0 | 72.6 | ANCHORED |
| 16 | direct | 400 | 0 | 2981.8 | 5350 | 6220 | 6520 | 6825 | 2.539 | 7.57 | 448.5 | 43.5 | 84.9 |  |
| 16 | policy-only | 400 | 0 | 719.6 | 21489 | 27981 | 33683 | 40927 | 7.500 | 5.40 | 2830.8 | 24.9 | 59.0 |  |
| 16 | full | 400 | 0 | 45.4 | 346581 | 396257 | 420583 | 442400 | 12.852 | 0.58 | 3222.4 | 42.6 | 73.7 | ANCHORED |
| 16 | full+journal | 400 | 0 | 39.0 | 410988 | 453771 | 465674 | 498563 | 16.758 | 0.65 | 3251.8 | 43.3 | 79.8 | ANCHORED |

CPU source: GetProcessTimes (user + kernel) (resolution: scheduler tick (about 15.6 ms on an idle system)). Memory: K32GetProcessMemoryInfo (working set), sampled every 5 ms; heap = runtime/metrics /memory/classes/heap/objects:bytes.

## Files

- concurrent_observations: `baseline-concurrent.csv`
- concurrent_summary: `baseline-concurrent-summary.csv`
- sequential_observations: `baseline-sequential.csv`
