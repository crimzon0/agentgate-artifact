# Baselines and load

Local measurements on one machine with simulated providers over loopback. They compare matched configurations of this prototype under one synthetic workload; they are not a general performance claim, and repeated timing calls are not independent workloads.

Command: `agentgate-eval -host-label review-host baseline -out .tools/build3-work/baseline/session/runs/R1 -work <work>`. Workload: financial. Go go1.26.6 on windows/amd64, 12 CPUs, GOMAXPROCS 12.  
Timer: QueryPerformanceCounter (kernel32 via golang.org/x/sys/windows), frequency 10000000 Hz, tick 100.0 ns. Wall-clock step observed for time.Now: 0.5072 ms.

## Configurations

- **direct**: no gateway: normalize (gateway normalizer), adapters.Prepare, adapters.HTTPTransport to the provider, verify the provider receipt
- **policy-only**: gateway with policy, grant, capability and signed receipts; audit sink off, no operation journal
- **full**: policy-only plus the signed hash-chained audit log, durable (fsync per entry)
- **full+journal**: full plus the fsynced operation journal
- **full-flagged**: full; the request is above the automatic limit and is flagged for audit

## Method

- Identical transport: every configuration is reached by JSON-RPC tools/call over loopback HTTP (keep-alive client, one per configuration) and reaches the provider with the adapter's HTTP transport (one fresh TCP connection per provider request).
- Identical provider: a provider host (internal/simulator behind its own loopback listener and key); every configuration has its own instance (same code, same transport, its own state) per sequential block and per concurrent cell, so state growth is equal and each evidence folder's provider journal holds only its own effects.
- Sequential: 500 paired trials in blocks of 50; in each trial every configuration gets one call, in an order rotated by one position per trial; each block starts fresh (provider, gateways, audit logs, journal) after 10 warm-up calls per configuration.
- Concurrent: client counts [1 2 4 8 16]; each configuration alone per cell, 10 warm-up calls then 400 measured calls split over the clients, back to back; CPU time is the whole process (client, server, gateway, provider host), memory peaks are sampled every 5ms.
- Every observation is kept: raw CSVs hold warm-up calls (marked) and every measured call, failed or not; summaries use every measured call (no outlier removal).
- Paired differences: per trial b - a; median with a distribution-free 95% interval (sign test order statistics), mean, and the share of trials in which b was slower.

## Sequential, paired trials (500 trials, 10 blocks, 38.6 s)

Latency per call in microseconds (all measured calls).

| config | n | min | p50 | p90 | p95 | p99 | max | mean | not committed | audit entries/call | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| direct | 500 | 1051 | 1311 | 1696 | 1851 | 2144 | 4226 | 1385 | 0 | 0.00 |  |
| policy-only | 500 | 3806 | 4503 | 5362 | 5845 | 6819 | 8004 | 4633 | 0 | 0.00 |  |
| full | 500 | 14303 | 16524 | 19233 | 20103 | 22035 | 131079 | 17165 | 0 | 6.00 | ANCHORED x10 |
| full+journal | 500 | 17873 | 20270 | 23543 | 24350 | 28268 | 48910 | 20866 | 0 | 6.00 | ANCHORED x10 |
| full-flagged | 500 | 14616 | 16704 | 19382 | 20131 | 22134 | 32224 | 17081 | 0 | 6.00 | ANCHORED x10 |

Paired differences (per trial, microseconds; 95% interval of the median from the sign test):

| difference | n | median | 95% CI | mean | p95 | share of trials slower |
|---|---|---|---|---|---|---|
| policy-only - direct | 500 | 3167 | [3114, 3209] | 3247 | 4406 | 100.0% |
| full - policy-only | 500 | 12030 | [11889, 12165] | 12532 | 15314 | 100.0% |
| full - direct | 500 | 15224 | [15114, 15316] | 15780 | 18687 | 100.0% |
| full+journal - full | 500 | 3713 | [3563, 3870] | 3701 | 7105 | 97.4% |
| full-flagged - full | 500 | 90 | [-16, 280] | -84 | 3200 | 54.0% |
| full+journal - direct | 500 | 18991 | [18752, 19103] | 19480 | 23017 | 100.0% |

Whole sequential phase: CPU 29641 ms (user 19531, kernel 10109) over 38593 ms wall; 7679.4 MiB allocated; peak working set 57.2 MiB (sampled).

## Concurrent load

Each cell runs one configuration alone; latency in microseconds; CPU is the whole process.

| clients | config | calls | not committed | calls/s | p50 | p95 | p99 | max | CPU ms/call | CPU cores busy | KiB alloc/call | peak heap MiB | peak working set MiB | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | direct | 400 | 0 | 887.9 | 1019 | 1576 | 1845 | 2005 | 1.523 | 1.35 | 422.2 | 4.6 | 52.9 |  |
| 1 | policy-only | 400 | 0 | 235.8 | 4131 | 4716 | 4929 | 6145 | 5.742 | 1.35 | 2679.1 | 20.5 | 45.5 |  |
| 1 | full | 400 | 0 | 48.7 | 18908 | 28189 | 49734 | 79672 | 16.094 | 0.78 | 3036.4 | 38.4 | 64.9 | ANCHORED |
| 1 | full+journal | 400 | 0 | 42.8 | 21075 | 29422 | 67508 | 174126 | 14.180 | 0.61 | 3066.6 | 40.6 | 69.4 | ANCHORED |
| 2 | direct | 400 | 0 | 1646.8 | 1195 | 1481 | 1568 | 2364 | 1.406 | 2.32 | 437.1 | 47.2 | 83.9 |  |
| 2 | policy-only | 400 | 0 | 375.4 | 5286 | 6106 | 6671 | 7174 | 5.898 | 2.21 | 2694.6 | 20.3 | 75.2 |  |
| 2 | full | 400 | 0 | 81.8 | 23730 | 28598 | 39861 | 46521 | 12.188 | 1.00 | 3048.2 | 40.3 | 67.8 | ANCHORED |
| 2 | full+journal | 400 | 0 | 69.9 | 27671 | 33344 | 40114 | 83674 | 14.453 | 1.01 | 3075.3 | 39.0 | 70.2 | ANCHORED |
| 4 | direct | 400 | 0 | 2358.4 | 1617 | 2080 | 2553 | 3244 | 1.875 | 4.42 | 438.4 | 46.9 | 84.4 |  |
| 4 | policy-only | 400 | 0 | 483.6 | 7990 | 11322 | 12128 | 13341 | 6.719 | 3.25 | 2706.3 | 19.7 | 50.2 |  |
| 4 | full | 400 | 0 | 84.7 | 45386 | 60325 | 75962 | 82295 | 13.203 | 1.12 | 3049.5 | 40.1 | 69.0 | ANCHORED |
| 4 | full+journal | 400 | 0 | 70.2 | 53941 | 78590 | 99246 | 110060 | 15.664 | 1.10 | 3074.4 | 39.8 | 75.7 | ANCHORED |
| 8 | direct | 400 | 0 | 2859.2 | 2765 | 3400 | 3804 | 4296 | 1.563 | 4.47 | 432.4 | 44.4 | 87.1 |  |
| 8 | policy-only | 400 | 0 | 703.3 | 11065 | 14907 | 18047 | 22570 | 6.758 | 4.75 | 2702.5 | 21.8 | 54.0 |  |
| 8 | full | 400 | 0 | 92.3 | 86111 | 98902 | 104221 | 115600 | 12.266 | 1.13 | 3047.5 | 40.0 | 69.9 | ANCHORED |
| 8 | full+journal | 400 | 0 | 80.3 | 96001 | 126947 | 148770 | 153624 | 16.328 | 1.31 | 3066.6 | 40.7 | 71.0 | ANCHORED |
| 16 | direct | 400 | 0 | 2419.8 | 5414 | 14132 | 19919 | 25354 | 2.148 | 5.20 | 422.3 | 43.5 | 86.6 |  |
| 16 | policy-only | 400 | 0 | 747.2 | 20784 | 26003 | 32715 | 37580 | 7.031 | 5.25 | 2688.8 | 25.3 | 58.6 |  |
| 16 | full | 400 | 0 | 91.8 | 171910 | 183164 | 212813 | 266524 | 12.461 | 1.14 | 3038.1 | 41.6 | 73.1 | ANCHORED |
| 16 | full+journal | 400 | 0 | 81.2 | 189430 | 225427 | 330252 | 353457 | 13.594 | 1.10 | 3059.8 | 43.2 | 78.3 | ANCHORED |

CPU source: GetProcessTimes (user + kernel) (resolution: scheduler tick (about 15.6 ms on an idle system)). Memory: K32GetProcessMemoryInfo (working set), sampled every 5 ms; heap = runtime/metrics /memory/classes/heap/objects:bytes.

## Files

- concurrent_observations: `baseline-concurrent.csv`
- concurrent_summary: `baseline-concurrent-summary.csv`
- sequential_observations: `baseline-sequential.csv`
