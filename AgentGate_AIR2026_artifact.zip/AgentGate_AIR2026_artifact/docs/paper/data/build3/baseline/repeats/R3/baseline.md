# Baselines and load

Local measurements on one machine with simulated providers over loopback. They compare matched configurations of this prototype under one synthetic workload; they are not a general performance claim, and repeated timing calls are not independent workloads.

Command: `agentgate-eval -host-label review-host baseline -out .tools/build3-work/baseline/session/runs/R3 -work <work>`. Workload: financial. Go go1.26.6 on windows/amd64, 12 CPUs, GOMAXPROCS 12.  
Timer: QueryPerformanceCounter (kernel32 via golang.org/x/sys/windows), frequency 10000000 Hz, tick 100.0 ns. Wall-clock step observed for time.Now: 0.0838 ms.

## Configurations

- **direct**: no gateway: normalize (gateway normalizer), adapters.Prepare, adapters.HTTPTransport to the provider, verify the provider receipt
- **policy-only**: gateway with policy, grant, capability and signed receipts; audit sink off, no operation journal
- **full**: policy-only plus the signed hash-chained audit log, durable (fsync per entry)
- **full+journal**: full plus the fsynced operation journal
- **full-flagged**: full; the request is above the automatic limit and is flagged for audit

## Method

- Identical transport: every configuration is reached by JSON-RPC tools/call over loopback HTTP (keep-alive client, one per configuration) and reaches the provider with the adapter's HTTP transport (one fresh TCP connection per provider request).
- Identical provider: a provider host (internal/simulator behind its own loopback listener and key); every configuration has its own instance (same code, same transport, its own state) per sequential block and per concurrent cell, so state growth is equal and each evidence folder's provider journal holds only its own effects.
- Sequential: 500 paired trials in blocks of 50; in each trial every configuration gets one call, in an order rotated by one position per trial; each block starts fresh (provider, gateways, audit logs, journal) after 10 warm-up calls per configuration.
- Concurrent: client counts [1 2 4 8 16]; each configuration alone per cell, 10 warm-up calls then 400 measured calls split over the clients, back to back; CPU time is the whole process (client, server, gateway, provider host), memory peaks are sampled every 5ms.
- Every observation is kept: raw CSVs hold warm-up calls (marked) and every measured call, failed or not; summaries use every measured call (no outlier removal).
- Paired differences: per trial b - a; median with a distribution-free 95% interval (sign test order statistics), mean, and the share of trials in which b was slower.

## Sequential, paired trials (500 trials, 10 blocks, 38.3 s)

Latency per call in microseconds (all measured calls).

| config | n | min | p50 | p90 | p95 | p99 | max | mean | not committed | audit entries/call | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| direct | 500 | 977 | 1322 | 1688 | 1796 | 2044 | 2311 | 1370 | 0 | 0.00 |  |
| policy-only | 500 | 3704 | 4520 | 5677 | 5958 | 6394 | 9337 | 4651 | 0 | 0.00 |  |
| full | 500 | 14049 | 16325 | 19316 | 19994 | 24291 | 44592 | 16849 | 0 | 6.00 | ANCHORED x10 |
| full+journal | 500 | 17500 | 19973 | 23301 | 24772 | 28205 | 36449 | 20556 | 0 | 6.00 | ANCHORED x10 |
| full-flagged | 500 | 14088 | 16497 | 19436 | 20738 | 23110 | 30611 | 17028 | 0 | 6.00 | ANCHORED x10 |

Paired differences (per trial, microseconds; 95% interval of the median from the sign test):

| difference | n | median | 95% CI | mean | p95 | share of trials slower |
|---|---|---|---|---|---|---|
| policy-only - direct | 500 | 3190 | [3119, 3241] | 3280 | 4462 | 100.0% |
| full - policy-only | 500 | 11751 | [11644, 11964] | 12198 | 15237 | 100.0% |
| full - direct | 500 | 15014 | [14845, 15205] | 15478 | 18634 | 100.0% |
| full+journal - full | 500 | 3668 | [3542, 3756] | 3707 | 7251 | 96.8% |
| full-flagged - full | 500 | 182 | [64, 287] | 179 | 3553 | 56.4% |
| full+journal - direct | 500 | 18617 | [18386, 18790] | 19186 | 23135 | 100.0% |

Whole sequential phase: CPU 30516 ms (user 19734, kernel 10781) over 38307 ms wall; 7679.5 MiB allocated; peak working set 58.5 MiB (sampled).

## Concurrent load

Each cell runs one configuration alone; latency in microseconds; CPU is the whole process.

| clients | config | calls | not committed | calls/s | p50 | p95 | p99 | max | CPU ms/call | CPU cores busy | KiB alloc/call | peak heap MiB | peak working set MiB | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | direct | 400 | 0 | 827.7 | 1103 | 1603 | 1910 | 4734 | 2.148 | 1.78 | 418.6 | 27.8 | 57.7 |  |
| 1 | policy-only | 400 | 0 | 235.2 | 4146 | 4870 | 5817 | 6879 | 6.172 | 1.45 | 2681.1 | 19.7 | 45.1 |  |
| 1 | full | 400 | 0 | 60.4 | 16073 | 19347 | 21134 | 34289 | 11.211 | 0.68 | 3037.9 | 39.1 | 64.6 | ANCHORED |
| 1 | full+journal | 400 | 0 | 49.4 | 19856 | 23313 | 25425 | 27548 | 13.633 | 0.67 | 3061.8 | 39.8 | 66.2 | ANCHORED |
| 2 | direct | 400 | 0 | 1841.1 | 1059 | 1289 | 1373 | 1604 | 1.484 | 2.73 | 424.5 | 47.9 | 84.2 |  |
| 2 | policy-only | 400 | 0 | 405.1 | 4920 | 5781 | 6210 | 6768 | 5.938 | 2.40 | 2701.0 | 19.7 | 78.1 |  |
| 2 | full | 400 | 0 | 59.0 | 24348 | 58789 | 63151 | 72703 | 13.945 | 0.82 | 3051.1 | 38.9 | 66.1 | ANCHORED |
| 2 | full+journal | 400 | 0 | 36.9 | 58095 | 76884 | 96793 | 101467 | 14.414 | 0.53 | 3076.1 | 39.8 | 66.9 | ANCHORED |
| 4 | direct | 400 | 0 | 2277.8 | 1676 | 2188 | 2341 | 2939 | 1.602 | 3.65 | 439.5 | 44.4 | 79.9 |  |
| 4 | policy-only | 400 | 0 | 621.3 | 6044 | 8498 | 10046 | 11786 | 6.953 | 4.32 | 2709.3 | 19.8 | 48.8 |  |
| 4 | full | 400 | 0 | 46.6 | 78949 | 116377 | 122136 | 131069 | 11.953 | 0.56 | 3054.2 | 39.4 | 68.0 | ANCHORED |
| 4 | full+journal | 400 | 0 | 38.9 | 107513 | 135152 | 150120 | 154099 | 15.625 | 0.61 | 3076.9 | 40.4 | 72.2 | ANCHORED |
| 8 | direct | 400 | 0 | 2794.9 | 2825 | 3463 | 3920 | 4318 | 2.617 | 7.32 | 440.2 | 47.3 | 86.3 |  |
| 8 | policy-only | 400 | 0 | 689.0 | 11290 | 14666 | 17383 | 19728 | 6.445 | 4.44 | 2703.9 | 20.8 | 54.7 |  |
| 8 | full | 400 | 0 | 46.6 | 172872 | 211149 | 218166 | 232652 | 12.305 | 0.57 | 3038.7 | 40.8 | 72.4 | ANCHORED |
| 8 | full+journal | 400 | 0 | 71.1 | 93502 | 214323 | 243401 | 277652 | 15.547 | 1.10 | 3071.6 | 41.8 | 70.8 | ANCHORED |
| 16 | direct | 400 | 0 | 3107.7 | 4965 | 5836 | 8318 | 9920 | 2.031 | 6.31 | 424.8 | 47.2 | 85.7 |  |
| 16 | policy-only | 400 | 0 | 720.1 | 21710 | 28209 | 37358 | 39493 | 6.211 | 4.47 | 2685.7 | 29.2 | 61.5 |  |
| 16 | full | 400 | 0 | 46.8 | 337850 | 381648 | 396376 | 413360 | 12.852 | 0.60 | 3037.7 | 41.3 | 72.1 | ANCHORED |
| 16 | full+journal | 400 | 0 | 39.2 | 409827 | 448619 | 456798 | 502231 | 15.195 | 0.60 | 3063.3 | 41.4 | 77.6 | ANCHORED |

CPU source: GetProcessTimes (user + kernel) (resolution: scheduler tick (about 15.6 ms on an idle system)). Memory: K32GetProcessMemoryInfo (working set), sampled every 5 ms; heap = runtime/metrics /memory/classes/heap/objects:bytes.

## Files

- concurrent_observations: `baseline-concurrent.csv`
- concurrent_summary: `baseline-concurrent-summary.csv`
- sequential_observations: `baseline-sequential.csv`
