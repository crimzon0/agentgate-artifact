# Baselines and load

Local measurements on one machine with simulated providers over loopback. They compare matched configurations of this prototype under one synthetic workload; they are not a general performance claim, and repeated timing calls are not independent workloads.

Command: `agentgate-eval -host-label review-host baseline -out .tools/build3-work/baseline/session/runs/R4 -work <work>`. Workload: financial. Go go1.26.6 on windows/amd64, 12 CPUs, GOMAXPROCS 12.  
Timer: QueryPerformanceCounter (kernel32 via golang.org/x/sys/windows), frequency 10000000 Hz, tick 100.0 ns. Wall-clock step observed for time.Now: 0.5049 ms.

## Configurations

- **direct**: no gateway: normalize (gateway normalizer), adapters.Prepare, adapters.HTTPTransport to the provider, verify the provider receipt
- **policy-only**: gateway with policy, grant, capability and signed receipts; audit sink off, no operation journal
- **full**: policy-only plus the signed hash-chained audit log, durable (fsync per entry)
- **full+journal**: full plus the fsynced operation journal
- **full-flagged**: full; the request is above the automatic limit and is flagged for audit

## Method

- Identical transport: every configuration is reached by JSON-RPC tools/call over loopback HTTP (keep-alive client, one per configuration) and reaches the provider with the adapter's HTTP transport (one fresh TCP connection per provider request).
- Identical provider: a provider host (internal/simulator behind its own loopback listener and key); every configuration has its own instance (same code, same transport, its own state) per sequential block and per concurrent cell, so state growth is equal and each evidence folder's provider journal holds only its own effects.
- Sequential: 500 paired trials in blocks of 50; in each trial every configuration gets one call, in an order rotated by one position per trial; each block starts fresh (provider, gateways, audit logs, journal) after 10 warm-up calls per configuration.
- Concurrent: client counts [1 2 4 8 16]; each configuration alone per cell, 10 warm-up calls then 400 measured calls split over the clients, back to back; CPU time is the whole process (client, server, gateway, provider host), memory peaks are sampled every 5ms.
- Every observation is kept: raw CSVs hold warm-up calls (marked) and every measured call, failed or not; summaries use every measured call (no outlier removal).
- Paired differences: per trial b - a; median with a distribution-free 95% interval (sign test order statistics), mean, and the share of trials in which b was slower.

## Sequential, paired trials (500 trials, 10 blocks, 45.3 s)

Latency per call in microseconds (all measured calls).

| config | n | min | p50 | p90 | p95 | p99 | max | mean | not committed | audit entries/call | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| direct | 500 | 993 | 1292 | 1642 | 1776 | 2014 | 2302 | 1349 | 0 | 0.00 |  |
| policy-only | 500 | 3767 | 4447 | 5358 | 5720 | 6292 | 6795 | 4544 | 0 | 0.00 |  |
| full | 500 | 13900 | 16334 | 44586 | 50296 | 101485 | 161238 | 21176 | 0 | 6.00 | ANCHORED x10 |
| full+journal | 500 | 17481 | 19954 | 49100 | 54200 | 71786 | 366015 | 25677 | 0 | 6.00 | ANCHORED x10 |
| full-flagged | 500 | 14241 | 16605 | 21709 | 48773 | 56977 | 151018 | 19950 | 0 | 6.00 | ANCHORED x10 |

Paired differences (per trial, microseconds; 95% interval of the median from the sign test):

| difference | n | median | 95% CI | mean | p95 | share of trials slower |
|---|---|---|---|---|---|---|
| policy-only - direct | 500 | 3132 | [3067, 3180] | 3194 | 4295 | 100.0% |
| full - policy-only | 500 | 11847 | [11700, 12058] | 16632 | 46020 | 100.0% |
| full - direct | 500 | 15007 | [14885, 15175] | 19826 | 48892 | 100.0% |
| full+journal - full | 500 | 3630 | [3462, 3778] | 4501 | 37020 | 88.0% |
| full-flagged - full | 500 | 223 | [93, 459] | -1225 | 15416 | 57.6% |
| full+journal - direct | 500 | 18611 | [18365, 18790] | 24328 | 52943 | 100.0% |

Whole sequential phase: CPU 29484 ms (user 19594, kernel 9891) over 45306 ms wall; 7679.0 MiB allocated; peak working set 58.9 MiB (sampled).

## Concurrent load

Each cell runs one configuration alone; latency in microseconds; CPU is the whole process.

| clients | config | calls | not committed | calls/s | p50 | p95 | p99 | max | CPU ms/call | CPU cores busy | KiB alloc/call | peak heap MiB | peak working set MiB | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | direct | 400 | 0 | 958.3 | 958 | 1303 | 1454 | 1812 | 1.563 | 1.50 | 422.9 | 26.9 | 56.8 |  |
| 1 | policy-only | 400 | 0 | 231.8 | 4199 | 5126 | 5879 | 6654 | 5.117 | 1.19 | 2682.1 | 20.0 | 45.6 |  |
| 1 | full | 400 | 0 | 56.5 | 17124 | 21540 | 24582 | 36357 | 14.023 | 0.79 | 3041.1 | 39.8 | 65.3 | ANCHORED |
| 1 | full+journal | 400 | 0 | 49.3 | 19983 | 23660 | 25239 | 30750 | 12.656 | 0.62 | 3062.6 | 39.5 | 65.4 | ANCHORED |
| 2 | direct | 400 | 0 | 1626.1 | 1190 | 1593 | 1773 | 1921 | 1.680 | 2.73 | 426.7 | 48.2 | 84.8 |  |
| 2 | policy-only | 400 | 0 | 408.2 | 4886 | 5695 | 6064 | 6366 | 6.016 | 2.46 | 2696.9 | 20.7 | 77.1 |  |
| 2 | full | 400 | 0 | 83.4 | 23561 | 28413 | 32628 | 35806 | 12.930 | 1.08 | 3050.1 | 39.7 | 68.2 | ANCHORED |
| 2 | full+journal | 400 | 0 | 71.0 | 26728 | 38657 | 44647 | 72956 | 15.469 | 1.10 | 3076.8 | 39.6 | 69.9 | ANCHORED |
| 4 | direct | 400 | 0 | 2293.1 | 1618 | 2211 | 2341 | 2595 | 2.188 | 5.02 | 443.1 | 20.2 | 81.7 |  |
| 4 | policy-only | 400 | 0 | 607.0 | 6448 | 8209 | 9288 | 10669 | 7.344 | 4.46 | 2709.1 | 20.2 | 50.2 |  |
| 4 | full | 400 | 0 | 88.7 | 44431 | 50704 | 52659 | 57191 | 12.930 | 1.15 | 3049.5 | 39.9 | 67.9 | ANCHORED |
| 4 | full+journal | 400 | 0 | 82.6 | 47897 | 53922 | 56245 | 58500 | 16.016 | 1.32 | 3074.9 | 40.7 | 71.6 | ANCHORED |
| 8 | direct | 400 | 0 | 2586.5 | 2995 | 3964 | 4660 | 5604 | 2.656 | 6.87 | 439.0 | 46.4 | 83.7 |  |
| 8 | policy-only | 400 | 0 | 684.7 | 11298 | 15274 | 18099 | 19991 | 7.422 | 5.08 | 2705.1 | 21.9 | 53.0 |  |
| 8 | full | 400 | 0 | 91.4 | 85733 | 104440 | 135512 | 140960 | 13.320 | 1.22 | 3047.9 | 40.4 | 70.3 | ANCHORED |
| 8 | full+journal | 400 | 0 | 84.8 | 93486 | 104451 | 113603 | 129302 | 13.438 | 1.14 | 3067.9 | 40.8 | 69.9 | ANCHORED |
| 16 | direct | 400 | 0 | 3085.1 | 5062 | 6165 | 7697 | 8947 | 1.875 | 5.79 | 425.3 | 44.8 | 86.3 |  |
| 16 | policy-only | 400 | 0 | 741.9 | 21467 | 26284 | 34580 | 35451 | 5.938 | 4.41 | 2688.5 | 23.8 | 60.4 |  |
| 16 | full | 400 | 0 | 76.9 | 176650 | 313999 | 322547 | 345886 | 13.047 | 1.00 | 3036.7 | 41.1 | 71.6 | ANCHORED |
| 16 | full+journal | 400 | 0 | 80.3 | 191191 | 219734 | 343963 | 392158 | 16.836 | 1.35 | 3067.1 | 41.9 | 75.9 | ANCHORED |

CPU source: GetProcessTimes (user + kernel) (resolution: scheduler tick (about 15.6 ms on an idle system)). Memory: K32GetProcessMemoryInfo (working set), sampled every 5 ms; heap = runtime/metrics /memory/classes/heap/objects:bytes.

## Files

- concurrent_observations: `baseline-concurrent.csv`
- concurrent_summary: `baseline-concurrent-summary.csv`
- sequential_observations: `baseline-sequential.csv`
