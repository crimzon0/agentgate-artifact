# Baselines and load

Local measurements on one machine with simulated providers over loopback. They compare matched configurations of this prototype under one synthetic workload; they are not a general performance claim, and repeated timing calls are not independent workloads.

Command: `agentgate-eval -host-label review-host baseline -out .tools/build3-work/baseline/session/runs/R5 -work <work>`. Workload: financial. Go go1.26.6 on windows/amd64, 12 CPUs, GOMAXPROCS 12.  
Timer: QueryPerformanceCounter (kernel32 via golang.org/x/sys/windows), frequency 10000000 Hz, tick 100.0 ns. Wall-clock step observed for time.Now: 0.0124 ms.

## Configurations

- **direct**: no gateway: normalize (gateway normalizer), adapters.Prepare, adapters.HTTPTransport to the provider, verify the provider receipt
- **policy-only**: gateway with policy, grant, capability and signed receipts; audit sink off, no operation journal
- **full**: policy-only plus the signed hash-chained audit log, durable (fsync per entry)
- **full+journal**: full plus the fsynced operation journal
- **full-flagged**: full; the request is above the automatic limit and is flagged for audit

## Method

- Identical transport: every configuration is reached by JSON-RPC tools/call over loopback HTTP (keep-alive client, one per configuration) and reaches the provider with the adapter's HTTP transport (one fresh TCP connection per provider request).
- Identical provider: a provider host (internal/simulator behind its own loopback listener and key); every configuration has its own instance (same code, same transport, its own state) per sequential block and per concurrent cell, so state growth is equal and each evidence folder's provider journal holds only its own effects.
- Sequential: 500 paired trials in blocks of 50; in each trial every configuration gets one call, in an order rotated by one position per trial; each block starts fresh (provider, gateways, audit logs, journal) after 10 warm-up calls per configuration.
- Concurrent: client counts [1 2 4 8 16]; each configuration alone per cell, 10 warm-up calls then 400 measured calls split over the clients, back to back; CPU time is the whole process (client, server, gateway, provider host), memory peaks are sampled every 5ms.
- Every observation is kept: raw CSVs hold warm-up calls (marked) and every measured call, failed or not; summaries use every measured call (no outlier removal).
- Paired differences: per trial b - a; median with a distribution-free 95% interval (sign test order statistics), mean, and the share of trials in which b was slower.

## Sequential, paired trials (500 trials, 10 blocks, 37.7 s)

Latency per call in microseconds (all measured calls).

| config | n | min | p50 | p90 | p95 | p99 | max | mean | not committed | audit entries/call | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| direct | 500 | 981 | 1296 | 1639 | 1740 | 1991 | 2415 | 1350 | 0 | 0.00 |  |
| policy-only | 500 | 3759 | 4508 | 5427 | 5710 | 6172 | 6412 | 4594 | 0 | 0.00 |  |
| full | 500 | 14152 | 16358 | 18748 | 19564 | 20712 | 22177 | 16585 | 0 | 6.00 | ANCHORED x10 |
| full+journal | 500 | 17668 | 19929 | 22773 | 23564 | 26347 | 44881 | 20377 | 0 | 6.00 | ANCHORED x10 |
| full-flagged | 500 | 14204 | 16532 | 18911 | 19966 | 21508 | 24956 | 16836 | 0 | 6.00 | ANCHORED x10 |

Paired differences (per trial, microseconds; 95% interval of the median from the sign test):

| difference | n | median | 95% CI | mean | p95 | share of trials slower |
|---|---|---|---|---|---|---|
| policy-only - direct | 500 | 3198 | [3138, 3229] | 3245 | 4249 | 100.0% |
| full - policy-only | 500 | 11709 | [11629, 11885] | 11991 | 14845 | 100.0% |
| full - direct | 500 | 14973 | [14848, 15185] | 15236 | 18253 | 100.0% |
| full+journal - full | 500 | 3632 | [3495, 3826] | 3792 | 6911 | 97.4% |
| full-flagged - full | 500 | 140 | [-35, 293] | 251 | 3302 | 53.4% |
| full+journal - direct | 500 | 18612 | [18464, 18748] | 19028 | 22283 | 100.0% |

Whole sequential phase: CPU 29188 ms (user 18375, kernel 10812) over 37679 ms wall; 7678.5 MiB allocated; peak working set 57.4 MiB (sampled).

## Concurrent load

Each cell runs one configuration alone; latency in microseconds; CPU is the whole process.

| clients | config | calls | not committed | calls/s | p50 | p95 | p99 | max | CPU ms/call | CPU cores busy | KiB alloc/call | peak heap MiB | peak working set MiB | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | direct | 400 | 0 | 1007.0 | 905 | 1195 | 1256 | 1381 | 1.367 | 1.38 | 425.6 | 4.4 | 52.3 |  |
| 1 | policy-only | 400 | 0 | 242.7 | 4044 | 4566 | 4828 | 5266 | 6.094 | 1.48 | 2681.3 | 19.8 | 45.2 |  |
| 1 | full | 400 | 0 | 59.8 | 16412 | 19250 | 21934 | 26904 | 11.602 | 0.69 | 3042.4 | 40.1 | 65.9 | ANCHORED |
| 1 | full+journal | 400 | 0 | 48.4 | 20130 | 23824 | 25957 | 39921 | 12.500 | 0.60 | 3062.9 | 40.0 | 76.7 | ANCHORED |
| 2 | direct | 400 | 0 | 1467.3 | 1326 | 1689 | 1865 | 2649 | 2.656 | 3.90 | 439.2 | 49.1 | 85.2 |  |
| 2 | policy-only | 400 | 0 | 404.3 | 4894 | 5716 | 6072 | 6339 | 5.195 | 2.10 | 2698.1 | 21.5 | 78.7 |  |
| 2 | full | 400 | 0 | 78.4 | 24480 | 30998 | 48108 | 60321 | 13.984 | 1.10 | 3045.3 | 39.1 | 66.2 | ANCHORED |
| 2 | full+journal | 400 | 0 | 68.7 | 27596 | 35890 | 59475 | 111110 | 14.922 | 1.02 | 3070.2 | 40.3 | 71.3 | ANCHORED |
| 4 | direct | 400 | 0 | 2347.7 | 1632 | 2100 | 2320 | 2706 | 2.305 | 5.41 | 439.1 | 47.0 | 87.6 |  |
| 4 | policy-only | 400 | 0 | 586.4 | 6644 | 8573 | 9841 | 10900 | 6.680 | 3.92 | 2704.9 | 20.8 | 50.1 |  |
| 4 | full | 400 | 0 | 88.2 | 43783 | 52607 | 69638 | 78903 | 14.922 | 1.32 | 3051.9 | 40.4 | 68.0 | ANCHORED |
| 4 | full+journal | 400 | 0 | 81.1 | 48902 | 56084 | 59256 | 60160 | 16.602 | 1.35 | 3073.9 | 40.6 | 74.2 | ANCHORED |
| 8 | direct | 400 | 0 | 2688.6 | 2909 | 3561 | 3994 | 4930 | 1.602 | 4.31 | 436.5 | 6.8 | 85.0 |  |
| 8 | policy-only | 400 | 0 | 690.2 | 11138 | 14958 | 16878 | 20159 | 7.734 | 5.34 | 2703.7 | 21.2 | 54.1 |  |
| 8 | full | 400 | 0 | 87.1 | 90186 | 105624 | 139716 | 149537 | 13.398 | 1.17 | 3043.0 | 40.2 | 70.5 | ANCHORED |
| 8 | full+journal | 400 | 0 | 82.4 | 96734 | 105012 | 111515 | 138561 | 16.211 | 1.34 | 3068.2 | 40.0 | 71.0 | ANCHORED |
| 16 | direct | 400 | 0 | 2679.6 | 5818 | 7177 | 9503 | 11048 | 2.266 | 6.07 | 421.1 | 45.0 | 86.1 |  |
| 16 | policy-only | 400 | 0 | 669.4 | 23472 | 29391 | 35047 | 44366 | 8.125 | 5.44 | 2691.6 | 29.7 | 61.7 |  |
| 16 | full | 400 | 0 | 86.3 | 182307 | 211958 | 238281 | 264204 | 14.102 | 1.22 | 3040.5 | 41.6 | 73.2 | ANCHORED |
| 16 | full+journal | 400 | 0 | 79.6 | 199183 | 215408 | 223692 | 247302 | 16.875 | 1.34 | 3066.6 | 41.5 | 77.6 | ANCHORED |

CPU source: GetProcessTimes (user + kernel) (resolution: scheduler tick (about 15.6 ms on an idle system)). Memory: K32GetProcessMemoryInfo (working set), sampled every 5 ms; heap = runtime/metrics /memory/classes/heap/objects:bytes.

## Files

- concurrent_observations: `baseline-concurrent.csv`
- concurrent_summary: `baseline-concurrent-summary.csv`
- sequential_observations: `baseline-sequential.csv`
