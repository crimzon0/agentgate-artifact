"""Slow calls and disk slowdowns of the build-3 baseline session (build 2's
script; only the primary run's label changed, PRIMARY_LABEL below).

    py docs/paper/data/build3/baseline/slow_calls.py

For the primary run (this folder), repeats/*/ and message/:
- sequential calls over 30 ms per configuration and per block (every measured
  call; warm-up excluded), and calls over 42 ms;
- concurrent cells of the durable configurations whose throughput is below
  80 % of the median of the same cell over all runs of the session;
- seconds of the run's typeperf log (load/system-load.csv) whose mean disk
  write time is over 0.15 ms (typical 0.04-0.08 ms in this session), merged
  into intervals, in UTC (the log's local time minus the offset in its header).
The same interval scan is applied to session-logs/stagecost-load.csv (cost
subcommand, stage runs, witness runs). Writes slow-calls.json.
"""
import csv
import datetime as dt
import glob
import json
import os
import re
import statistics as st

HERE = os.path.dirname(os.path.abspath(__file__))
DURABLE = ("full", "full+journal", "full-flagged")
PRIMARY_LABEL = "R2 (primary)"  # set at assembly (build-manifest.txt)


def intervals(path, threshold_ms=0.15):
    with open(path, newline="", encoding="utf-8") as handle:
        rows = list(csv.reader(handle))
    offset = int(re.search(r"\((-?\d+)\)\"?$", rows[0][0]).group(1))  # minutes, PDH convention: UTC = local + offset
    hits = []
    for row in rows[1:]:
        try:
            when = dt.datetime.strptime(row[0], "%m/%d/%Y %H:%M:%S.%f") + dt.timedelta(minutes=offset)
            writes, wlat = float(row[3]), float(row[4]) * 1000
        except (ValueError, IndexError):
            continue
        if wlat > threshold_ms:
            hits.append((when, writes, wlat))
    merged = []
    for when, writes, wlat in hits:
        if merged and (when - merged[-1]["end"]).total_seconds() <= 3:
            m = merged[-1]
            m["end"] = when
            m["seconds"] += 1
            m["max_write_ms"] = max(m["max_write_ms"], wlat)
            m["min_writes_per_s"] = min(m["min_writes_per_s"], writes)
        else:
            merged.append({"start": when, "end": when, "seconds": 1, "max_write_ms": wlat, "min_writes_per_s": writes})
    return [{"start_utc": m["start"].strftime("%H:%M:%S"), "end_utc": m["end"].strftime("%H:%M:%S"), "seconds_over": m["seconds"],
             "max_mean_write_ms": round(m["max_write_ms"], 3), "min_writes_per_s": round(m["min_writes_per_s"])} for m in merged]


def main():
    runs = [(PRIMARY_LABEL, HERE)] + [(os.path.basename(d), d) for d in sorted(glob.glob(os.path.join(HERE, "repeats", "*")))]
    runs.append(("M1 (message)", os.path.join(HERE, "message")))
    cells = {}
    for _, d in runs:
        with open(os.path.join(d, "baseline-concurrent-summary.csv"), newline="") as handle:
            for row in csv.DictReader(handle):
                cells.setdefault((row["config"], int(row["clients"])), []).append(float(row["throughput_calls_per_s"]))
    out = {"method": __doc__.strip(), "runs": {}}
    for name, d in runs:
        with open(os.path.join(d, "baseline-sequential.csv"), newline="") as handle:
            seq = [r for r in csv.DictReader(handle) if r["warmup"] not in ("yes", "true")]
        slow = [r for r in seq if float(r["latency_us"]) > 30000]
        over42 = [r for r in seq if float(r["latency_us"]) > 42000]
        by_config = {c: sum(1 for r in slow if r["config"] == c) for c in sorted({r["config"] for r in seq})}
        by_block = {}
        for r in slow:
            by_block[int(r["block"])] = by_block.get(int(r["block"]), 0) + 1
        low = []
        with open(os.path.join(d, "baseline-concurrent-summary.csv"), newline="") as handle:
            for row in csv.DictReader(handle):
                key = (row["config"], int(row["clients"]))
                tp = float(row["throughput_calls_per_s"])
                if row["config"] in DURABLE and tp < 0.8 * st.median(cells[key]):
                    low.append({"config": key[0], "clients": key[1], "throughput": tp, "session_median": round(st.median(cells[key]), 1),
                                "p99_ms": round(float(row["p99_us"]) / 1000, 1)})
        with open(os.path.join(d, "load", "run-start-utc.txt")) as handle:
            start = handle.read().strip()
        out["runs"][name] = {"run_start_utc": start, "sequential_calls": len(seq), "sequential_over_30ms": len(slow),
                             "sequential_over_30ms_by_config": by_config, "sequential_over_30ms_by_block": dict(sorted(by_block.items())),
                             "sequential_over_42ms": len(over42), "low_throughput_durable_cells": low,
                             "disk_write_time_over_0.15ms": intervals(os.path.join(d, "load", "system-load.csv"))}
    out["stagecost_window"] = {"disk_write_time_over_0.15ms": intervals(os.path.join(HERE, "session-logs", "stagecost-load.csv"))}
    path = os.path.join(HERE, "slow-calls.json")
    with open(path, "w") as handle:
        json.dump(out, handle, indent=2)
    for name, r in out["runs"].items():
        print(name, r["sequential_over_30ms"], r["sequential_over_30ms_by_config"], r["sequential_over_30ms_by_block"], "over42", r["sequential_over_42ms"])
        for c in r["low_throughput_durable_cells"]:
            print("   low cell", c)
        for i in r["disk_write_time_over_0.15ms"]:
            print("   disk", i)
    print("stagecost window")
    for i in out["stagecost_window"]["disk_write_time_over_0.15ms"]:
        print("   disk", i)
    print("wrote", path)


if __name__ == "__main__":
    main()
