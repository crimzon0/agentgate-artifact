# Per-stage cost of a durable audit append

Per-entry stage times of audit.Append (WriteDurable) on one computer; absolute values depend on the disk, its fill level, the file system, antivirus scanning and background load. Only a run on an idle machine counts.

- Command: `go test -count=1 -v -run '^TestStageCost$' ./internal/audit/ -stagecost=10000 -stagecost.warmup=200 -stagecost.corpus=<run> -stagecost.work=<dir>`; go1.26.6 on windows/amd64, 12 CPUs; 36.5 s.
- Storage: volume C:\, NTFS, 2000 GB, 98 % full.
- Timer: QueryPerformanceCounter, 10000000 Hz (tick 100.0 ns); one read costs about 66.3 ns (a staged append has 18 reads).
- Corpus: replayed audit.jsonl of run (2462 events, cycled); mean line 2083 bytes. 200 warm-up + 10000 timed appends per path. staged and uninstrumented appends alternate entry by entry; the first position alternates from entry to entry and flips once per pass over the corpus, so each event goes first on each path equally often; two fresh logs on the same volume.

## Stages (us per entry)

| Stage | What | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode_entry | lock, checks, clock, Entry built (artifacts to base64), encodeCompact (encode + hash) | 12.80 | 37.80 | 14.18 | 152.00 |
| decode_entry | decodeEntry: the copy Append returns (encode + hash) | 20.70 | 53.50 | 24.01 | 15869.30 |
| hash_entry | SHA-256 entry hash, hex (encode + hash) | 1.20 | 2.80 | 1.33 | 82.20 |
| sign_entry | Ed25519 signature of the entry hash, base64 (Ed25519 signing) | 18.20 | 44.50 | 20.70 | 154.20 |
| format_line | audit.jsonl line assembled (encode + hash) | 1.00 | 8.10 | 1.44 | 113.50 |
| write_line | write of the line to audit.jsonl (O_APPEND) (log line write) | 9.10 | 62.40 | 12.32 | 167.60 |
| fsync_log | fsync of audit.jsonl (FlushFileBuffers) (log fsync) | 411.30 | 770.52 | 442.22 | 7899.40 |
| bookkeeping | seq, head hash, time and stored line updated (encode + hash) | 0.30 | 0.80 | 0.39 | 142.70 |
| sign_head | Ed25519 signature of the head message, Head built (Ed25519 signing) | 19.00 | 43.90 | 20.76 | 479.50 |
| encode_head | head.json bytes (indented JSON) (encode + hash) | 4.80 | 15.20 | 5.52 | 68.90 |
| create_temp | os.CreateTemp next to head.json (temp head write) | 137.00 | 226.30 | 144.56 | 1686.00 |
| write_temp | write of the head bytes to the temporary file (temp head write) | 33.80 | 72.11 | 36.15 | 170.30 |
| fsync_temp | fsync of the temporary head file (head fsync) | 730.10 | 1348.12 | 773.26 | 25987.20 |
| close_temp | close of the temporary head file (temp head write) | 34.40 | 64.10 | 36.43 | 1775.90 |
| rename | rename over head.json (MoveFileEx, replace existing) (head rename) | 246.40 | 401.10 | 261.00 | 10805.10 |
| fsync_dir | syncDir: returns at once on Windows (no directory fsync) (directory fsync) | 0.10 | 0.40 | 0.14 | 28.00 |
| head_digest | SHA-256 of the head bytes, computed and discarded by WriteJSONAtomic (encode + hash) | 1.10 | 3.10 | 1.20 | 45.80 |

## Groups (us per entry; a group's value is the sum of its stages within each entry)

| Group | Stages | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode + hash | encode_entry, decode_entry, hash_entry, format_line, bookkeeping, encode_head, head_digest | 43.70 | 93.20 | 48.08 | 15916.30 |
| Ed25519 signing | sign_entry, sign_head | 38.70 | 71.50 | 41.46 | 505.70 |
| log line write | write_line | 9.10 | 62.40 | 12.32 | 167.60 |
| log fsync | fsync_log | 411.30 | 770.52 | 442.22 | 7899.40 |
| temp head write | create_temp, write_temp, close_temp | 207.50 | 329.40 | 217.13 | 1932.30 |
| head fsync | fsync_temp | 730.10 | 1348.12 | 773.26 | 25987.20 |
| head rename | rename | 246.40 | 401.10 | 261.00 | 10805.10 |
| directory fsync | fsync_dir | 0.10 | 0.40 | 0.14 | 28.00 |
| staged total | sum of the stages of one staged append (includes the timer reads between stages) | 1721.10 | 2720.31 | 1795.61 | 27071.40 |
| Append | audit.Append timed as a whole on the second log (no timer reads inside) | 1716.40 | 2687.01 | 1784.23 | 28113.40 |

## Per call (6 gateway entries)

- Sums of 6 consecutive appends (not a call) (1666 blocks): median 10.40 ms, p99 13.38 ms, mean 10.71 ms; share of the recorded-minus-mediated median: n/a, the blocks of a replayed run are not calls.
- Serial rate predicted from the mean append: 1e6 / (6 x 1784.23 us) = 93.4 calls/s (observed in the baseline: 94.3).
- Uninstrumented appends over 10 ms: 4 of 10000.

With a replayed run, six consecutive entries are not one call (the run also holds agent and run entries, and its lines have another mean size), so no share of the recorded-minus-mediated median is given. Appends of one log are serialized by its mutex, so with everything else running in parallel the log predicts about 1e6 / (entries per call x mean append us) calls/s for calls of this corpus's entries; the mean, not the median, sets that rate, so slow flushes lower it.

- Directory fsync: none on Windows: AgentGate's syncDir returns at once there (audit.go), so the fsync_dir stage times only that call. On other systems syncDir opens and fsyncs the run directory once per append, after the rename.
- Witness update: measured separately by internal/headwitness's TestWitnessPushCost (push_bench_test.go): a push is a separate round trip to the witness after the append. No reported latency includes one (the baseline runs no witness; the demo pushes the head after each agent step, outside the gateway call).
