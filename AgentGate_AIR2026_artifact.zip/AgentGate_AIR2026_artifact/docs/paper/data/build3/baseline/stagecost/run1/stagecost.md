# Per-stage cost of a durable audit append

Per-entry stage times of audit.Append (WriteDurable) on one computer; absolute values depend on the disk, its fill level, the file system, antivirus scanning and background load. Only a run on an idle machine counts.

- Command: `go test -count=1 -v -run '^TestStageCost$' ./internal/audit/ -stagecost=10000 -stagecost.warmup=200 -stagecost.work=<dir>`; go1.26.6 on windows/amd64, 12 CPUs; 35.8 s.
- Storage: volume C:\, NTFS, 2000 GB, 98 % full.
- Timer: QueryPerformanceCounter, 10000000 Hz (tick 100.0 ns); one read costs about 50.6 ns (a staged append has 18 reads).
- Corpus: synthetic six-entry financial call (stageCallShape) (6 events, cycled); mean line 2133 bytes. 200 warm-up + 10000 timed appends per path. staged and uninstrumented appends alternate entry by entry; the first position alternates from entry to entry and flips once per pass over the corpus, so each event goes first on each path equally often; two fresh logs on the same volume.

## Stages (us per entry)

| Stage | What | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode_entry | lock, checks, clock, Entry built (artifacts to base64), encodeCompact (encode + hash) | 11.40 | 34.60 | 12.47 | 419.50 |
| decode_entry | decodeEntry: the copy Append returns (encode + hash) | 18.80 | 49.70 | 20.77 | 133.50 |
| hash_entry | SHA-256 entry hash, hex (encode + hash) | 1.20 | 2.90 | 1.33 | 74.40 |
| sign_entry | Ed25519 signature of the entry hash, base64 (Ed25519 signing) | 17.80 | 42.20 | 20.08 | 149.40 |
| format_line | audit.jsonl line assembled (encode + hash) | 1.00 | 7.90 | 1.43 | 105.20 |
| write_line | write of the line to audit.jsonl (O_APPEND) (log line write) | 8.70 | 54.30 | 10.82 | 126.30 |
| fsync_log | fsync of audit.jsonl (FlushFileBuffers) (log fsync) | 407.10 | 765.20 | 434.30 | 7886.80 |
| bookkeeping | seq, head hash, time and stored line updated (encode + hash) | 0.30 | 0.70 | 0.36 | 139.30 |
| sign_head | Ed25519 signature of the head message, Head built (Ed25519 signing) | 18.80 | 42.40 | 20.22 | 159.30 |
| encode_head | head.json bytes (indented JSON) (encode + hash) | 4.50 | 13.90 | 5.22 | 356.30 |
| create_temp | os.CreateTemp next to head.json (temp head write) | 133.00 | 212.40 | 139.29 | 1338.30 |
| write_temp | write of the head bytes to the temporary file (temp head write) | 32.90 | 73.21 | 35.16 | 1129.90 |
| fsync_temp | fsync of the temporary head file (head fsync) | 727.20 | 1322.50 | 770.92 | 27012.80 |
| close_temp | close of the temporary head file (temp head write) | 33.50 | 57.50 | 34.75 | 141.90 |
| rename | rename over head.json (MoveFileEx, replace existing) (head rename) | 235.40 | 365.40 | 249.16 | 5879.80 |
| fsync_dir | syncDir: returns at once on Windows (no directory fsync) (directory fsync) | 0.10 | 0.30 | 0.13 | 14.50 |
| head_digest | SHA-256 of the head bytes, computed and discarded by WriteJSONAtomic (encode + hash) | 1.00 | 2.70 | 1.11 | 29.80 |

## Groups (us per entry; a group's value is the sum of its stages within each entry)

| Group | Stages | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode + hash | encode_entry, decode_entry, hash_entry, format_line, bookkeeping, encode_head, head_digest | 39.90 | 86.00 | 42.69 | 495.80 |
| Ed25519 signing | sign_entry, sign_head | 37.30 | 69.60 | 40.30 | 184.90 |
| log line write | write_line | 8.70 | 54.30 | 10.82 | 126.30 |
| log fsync | fsync_log | 407.10 | 765.20 | 434.30 | 7886.80 |
| temp head write | create_temp, write_temp, close_temp | 201.20 | 296.90 | 209.20 | 1583.00 |
| head fsync | fsync_temp | 727.20 | 1322.50 | 770.92 | 27012.80 |
| head rename | rename | 235.40 | 365.40 | 249.16 | 5879.80 |
| directory fsync | fsync_dir | 0.10 | 0.30 | 0.13 | 14.50 |
| staged total | sum of the stages of one staged append (includes the timer reads between stages) | 1691.35 | 2641.42 | 1757.51 | 28024.00 |
| Append | audit.Append timed as a whole on the second log (no timer reads inside) | 1690.20 | 2633.62 | 1751.34 | 5438.20 |

## Per call (6 gateway entries)

- Sums of 6 consecutive appends (one call) (1666 blocks): median 10.24 ms, p99 13.01 ms, mean 10.51 ms; the median is 90 % of the 11.40 ms recorded-minus-mediated paired median (not an exact decomposition).
- Serial rate predicted from the mean append: 1e6 / (6 x 1751.34 us) = 95.2 calls/s (observed in the baseline: 94.3).
- Uninstrumented appends over 10 ms: 0 of 10000.

With the synthetic corpus any six consecutive entries hold each event of the call once, so a block sum is one call's worth of appends. It is not an exact decomposition of the recorded-minus-mediated median: that median also contains the gateway's work to build the six events (not timed here), and the two figures come from different measurements (a paired difference of call latencies in the baseline session against a sum of appends timed here on their own). Appends of one log are serialized by its mutex, so with everything else running in parallel the log predicts about 1e6 / (entries per call x mean append us) calls/s for calls of this corpus's entries; the mean, not the median, sets that rate, so slow flushes lower it.

- Directory fsync: none on Windows: AgentGate's syncDir returns at once there (audit.go), so the fsync_dir stage times only that call. On other systems syncDir opens and fsyncs the run directory once per append, after the rename.
- Witness update: measured separately by internal/headwitness's TestWitnessPushCost (push_bench_test.go): a push is a separate round trip to the witness after the append. No reported latency includes one (the baseline runs no witness; the demo pushes the head after each agent step, outside the gateway call).
