# Per-stage cost of a durable audit append

Per-entry stage times of audit.Append (WriteDurable) on one computer; absolute values depend on the disk, its fill level, the file system, antivirus scanning and background load. Only a run on an idle machine counts.

- Command: `go test -count=1 -v -run '^TestStageCost$' ./internal/audit/ -stagecost=10000 -stagecost.warmup=200 -stagecost.work=<dir>`; go1.26.6 on windows/amd64, 12 CPUs; 36.3 s.
- Storage: volume C:\, NTFS, 2000 GB, 98 % full.
- Timer: QueryPerformanceCounter, 10000000 Hz (tick 100.0 ns); one read costs about 50.1 ns (a staged append has 18 reads).
- Corpus: synthetic six-entry financial call (stageCallShape) (6 events, cycled); mean line 2133 bytes. 200 warm-up + 10000 timed appends per path. staged and uninstrumented appends alternate entry by entry; the first position alternates from entry to entry and flips once per pass over the corpus, so each event goes first on each path equally often; two fresh logs on the same volume.

## Stages (us per entry)

| Stage | What | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode_entry | lock, checks, clock, Entry built (artifacts to base64), encodeCompact (encode + hash) | 11.90 | 35.20 | 13.13 | 161.70 |
| decode_entry | decodeEntry: the copy Append returns (encode + hash) | 19.60 | 50.70 | 21.54 | 189.40 |
| hash_entry | SHA-256 entry hash, hex (encode + hash) | 1.20 | 2.80 | 1.33 | 38.50 |
| sign_entry | Ed25519 signature of the entry hash, base64 (Ed25519 signing) | 18.00 | 45.50 | 20.51 | 244.20 |
| format_line | audit.jsonl line assembled (encode + hash) | 1.10 | 8.10 | 1.47 | 80.10 |
| write_line | write of the line to audit.jsonl (O_APPEND) (log line write) | 8.90 | 56.50 | 11.49 | 137.60 |
| fsync_log | fsync of audit.jsonl (FlushFileBuffers) (log fsync) | 409.70 | 765.81 | 442.75 | 25908.10 |
| bookkeeping | seq, head hash, time and stored line updated (encode + hash) | 0.30 | 0.70 | 0.37 | 183.80 |
| sign_head | Ed25519 signature of the head message, Head built (Ed25519 signing) | 18.80 | 44.30 | 20.60 | 297.10 |
| encode_head | head.json bytes (indented JSON) (encode + hash) | 4.60 | 13.60 | 5.31 | 112.30 |
| create_temp | os.CreateTemp next to head.json (temp head write) | 135.00 | 224.10 | 142.83 | 5860.60 |
| write_temp | write of the head bytes to the temporary file (temp head write) | 33.70 | 72.90 | 36.08 | 1270.50 |
| fsync_temp | fsync of the temporary head file (head fsync) | 731.20 | 1325.01 | 769.17 | 8325.00 |
| close_temp | close of the temporary head file (temp head write) | 34.20 | 60.50 | 36.62 | 7545.10 |
| rename | rename over head.json (MoveFileEx, replace existing) (head rename) | 243.10 | 382.61 | 256.65 | 10534.80 |
| fsync_dir | syncDir: returns at once on Windows (no directory fsync) (directory fsync) | 0.10 | 0.30 | 0.13 | 15.20 |
| head_digest | SHA-256 of the head bytes, computed and discarded by WriteJSONAtomic (encode + hash) | 1.00 | 2.90 | 1.17 | 51.10 |

## Groups (us per entry; a group's value is the sum of its stages within each entry)

| Group | Stages | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode + hash | encode_entry, decode_entry, hash_entry, format_line, bookkeeping, encode_head, head_digest | 41.60 | 88.50 | 44.32 | 250.60 |
| Ed25519 signing | sign_entry, sign_head | 38.30 | 72.20 | 41.11 | 321.20 |
| log line write | write_line | 8.90 | 56.50 | 11.49 | 137.60 |
| log fsync | fsync_log | 409.70 | 765.81 | 442.75 | 25908.10 |
| temp head write | create_temp, write_temp, close_temp | 204.90 | 317.81 | 215.53 | 7777.90 |
| head fsync | fsync_temp | 731.20 | 1325.01 | 769.17 | 8325.00 |
| head rename | rename | 243.10 | 382.61 | 256.65 | 10534.80 |
| directory fsync | fsync_dir | 0.10 | 0.30 | 0.13 | 15.20 |
| staged total | sum of the stages of one staged append (includes the timer reads between stages) | 1709.80 | 2682.31 | 1781.15 | 27389.50 |
| Append | audit.Append timed as a whole on the second log (no timer reads inside) | 1706.80 | 2663.20 | 1772.32 | 17689.70 |

## Per call (6 gateway entries)

- Sums of 6 consecutive appends (one call) (1666 blocks): median 10.35 ms, p99 13.30 ms, mean 10.63 ms; the median is 91 % of the 11.40 ms recorded-minus-mediated paired median (not an exact decomposition).
- Serial rate predicted from the mean append: 1e6 / (6 x 1772.32 us) = 94.0 calls/s (observed in the baseline: 94.3).
- Uninstrumented appends over 10 ms: 2 of 10000.

With the synthetic corpus any six consecutive entries hold each event of the call once, so a block sum is one call's worth of appends. It is not an exact decomposition of the recorded-minus-mediated median: that median also contains the gateway's work to build the six events (not timed here), and the two figures come from different measurements (a paired difference of call latencies in the baseline session against a sum of appends timed here on their own). Appends of one log are serialized by its mutex, so with everything else running in parallel the log predicts about 1e6 / (entries per call x mean append us) calls/s for calls of this corpus's entries; the mean, not the median, sets that rate, so slow flushes lower it.

- Directory fsync: none on Windows: AgentGate's syncDir returns at once there (audit.go), so the fsync_dir stage times only that call. On other systems syncDir opens and fsyncs the run directory once per append, after the rename.
- Witness update: measured separately by internal/headwitness's TestWitnessPushCost (push_bench_test.go): a push is a separate round trip to the witness after the append. No reported latency includes one (the baseline runs no witness; the demo pushes the head after each agent step, outside the gateway call).
