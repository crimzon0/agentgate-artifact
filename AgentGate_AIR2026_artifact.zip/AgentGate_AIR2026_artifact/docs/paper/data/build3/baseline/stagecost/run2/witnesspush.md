# Witness update cost

Witness update cost on one computer, witness and client in one process over loopback; absolute values depend on the disk, its fill level, the file system, antivirus scanning and background load. Only a run on an idle machine counts.

- Command: `go test -count=1 -v -run '^TestWitnessPushCost$' ./internal/headwitness/ -witnesspush=2000 -witnesspush.warmup=50`; go1.26.6 on windows/amd64, 12 CPUs; 141.8 s.
- Storage: volume C:\, NTFS, 2000 GB, 98 % full (the test temporary folder).
- Timer: QueryPerformanceCounter, 10000000 Hz.
- 50 warm-up + 2000 timed calls per mode; mean audit line 2107 bytes. per-call and per-entry modes alternate call by call, first position alternating; one witness, two registered runs, one volume.

| Row | What | n | Median (us) | p99 (us) | Mean (us) | Max (us) |
|---|---|---|---|---|---|---|
| push per call | PushHeadWithEntries with the head and 6 new lines (round trip, witness checks, cosignature, store fsync) | 2000 | 1218.95 | 2098.79 | 1454.42 | 35997.80 |
| save per call | audit.WriteJSONAtomic of the cosigned head (temporary file, fsync, rename), as the demo saves it | 2000 | 1054.20 | 1758.72 | 1219.13 | 36266.60 |
| push per entry | PushHeadWithEntries with the head and 1 new line | 12000 | 791.90 | 1512.32 | 1022.64 | 54484.80 |
| save per entry | audit.WriteJSONAtomic of the cosigned head | 12000 | 1044.75 | 1661.81 | 1195.50 | 118873.30 |
| 6 per-entry pushes and saves | sum over the 6 entries of one call when every entry is pushed | 2000 | 11330.30 | 44875.22 | 13308.82 | 127887.70 |

A witness update is not part of any latency in the paper: the baseline runs no witness and the demo pushes after each agent step, outside the gateway call. These rows say what a deployment would add per call if each call waited for one push (push per call plus save per call) or for one push per entry. The witness serializes pushes with one mutex and fsyncs its store once per push.
