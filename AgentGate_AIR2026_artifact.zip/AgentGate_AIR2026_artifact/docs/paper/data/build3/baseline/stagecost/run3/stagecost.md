# Per-stage cost of a durable audit append

Per-entry stage times of audit.Append (WriteDurable) on one computer; absolute values depend on the disk, its fill level, the file system, antivirus scanning and background load. Only a run on an idle machine counts.

- Command: `go test -count=1 -v -run '^TestStageCost$' ./internal/audit/ -stagecost=10000 -stagecost.warmup=200 -stagecost.work=<dir>`; go1.26.6 on windows/amd64, 12 CPUs; 38.5 s.
- Storage: volume C:\, NTFS, 2000 GB, 98 % full.
- Timer: QueryPerformanceCounter, 10000000 Hz (tick 100.0 ns); one read costs about 57.6 ns (a staged append has 18 reads).
- Corpus: synthetic six-entry financial call (stageCallShape) (6 events, cycled); mean line 2133 bytes. 200 warm-up + 10000 timed appends per path. staged and uninstrumented appends alternate entry by entry; the first position alternates from entry to entry and flips once per pass over the corpus, so each event goes first on each path equally often; two fresh logs on the same volume.

## Stages (us per entry)

| Stage | What | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode_entry | lock, checks, clock, Entry built (artifacts to base64), encodeCompact (encode + hash) | 13.70 | 43.60 | 15.30 | 254.20 |
| decode_entry | decodeEntry: the copy Append returns (encode + hash) | 20.90 | 58.10 | 23.47 | 641.30 |
| hash_entry | SHA-256 entry hash, hex (encode + hash) | 1.20 | 3.10 | 1.38 | 72.90 |
| sign_entry | Ed25519 signature of the entry hash, base64 (Ed25519 signing) | 19.35 | 50.10 | 21.85 | 661.30 |
| format_line | audit.jsonl line assembled (encode + hash) | 1.20 | 9.00 | 1.66 | 111.30 |
| write_line | write of the line to audit.jsonl (O_APPEND) (log line write) | 10.00 | 62.90 | 13.24 | 263.50 |
| fsync_log | fsync of audit.jsonl (FlushFileBuffers) (log fsync) | 417.00 | 900.34 | 460.37 | 27347.80 |
| bookkeeping | seq, head hash, time and stored line updated (encode + hash) | 0.30 | 0.90 | 0.44 | 175.20 |
| sign_head | Ed25519 signature of the head message, Head built (Ed25519 signing) | 19.00 | 52.30 | 22.33 | 1273.20 |
| encode_head | head.json bytes (indented JSON) (encode + hash) | 5.10 | 18.60 | 6.05 | 146.10 |
| create_temp | os.CreateTemp next to head.json (temp head write) | 149.20 | 310.70 | 163.63 | 5875.50 |
| write_temp | write of the head bytes to the temporary file (temp head write) | 37.60 | 90.80 | 40.39 | 1478.10 |
| fsync_temp | fsync of the temporary head file (head fsync) | 742.40 | 1452.61 | 796.47 | 8631.60 |
| close_temp | close of the temporary head file (temp head write) | 35.80 | 76.61 | 38.69 | 2053.20 |
| rename | rename over head.json (MoveFileEx, replace existing) (head rename) | 265.80 | 486.31 | 276.71 | 8155.30 |
| fsync_dir | syncDir: returns at once on Windows (no directory fsync) (directory fsync) | 0.10 | 0.30 | 0.13 | 6.20 |
| head_digest | SHA-256 of the head bytes, computed and discarded by WriteJSONAtomic (encode + hash) | 1.20 | 3.50 | 1.38 | 121.70 |

## Groups (us per entry; a group's value is the sum of its stages within each entry)

| Group | Stages | Median | p99 | Mean | Max |
|---|---|---|---|---|---|
| encode + hash | encode_entry, decode_entry, hash_entry, format_line, bookkeeping, encode_head, head_digest | 45.60 | 114.90 | 49.67 | 697.80 |
| Ed25519 signing | sign_entry, sign_head | 41.10 | 84.80 | 44.18 | 1301.50 |
| log line write | write_line | 10.00 | 62.90 | 13.24 | 263.50 |
| log fsync | fsync_log | 417.00 | 900.34 | 460.37 | 27347.80 |
| temp head write | create_temp, write_temp, close_temp | 227.10 | 441.84 | 242.71 | 6036.50 |
| head fsync | fsync_temp | 742.40 | 1452.61 | 796.47 | 8631.60 |
| head rename | rename | 265.80 | 486.31 | 276.71 | 8155.30 |
| directory fsync | fsync_dir | 0.10 | 0.30 | 0.13 | 6.20 |
| staged total | sum of the stages of one staged append (includes the timer reads between stages) | 1776.40 | 3198.93 | 1883.49 | 29068.40 |
| Append | audit.Append timed as a whole on the second log (no timer reads inside) | 1772.90 | 3198.73 | 1886.66 | 36643.20 |

## Per call (6 gateway entries)

- Sums of 6 consecutive appends (one call) (1666 blocks): median 10.81 ms, p99 18.58 ms, mean 11.32 ms; the median is 95 % of the 11.40 ms recorded-minus-mediated paired median (not an exact decomposition).
- Serial rate predicted from the mean append: 1e6 / (6 x 1886.66 us) = 88.3 calls/s (observed in the baseline: 94.3).
- Uninstrumented appends over 10 ms: 8 of 10000.

With the synthetic corpus any six consecutive entries hold each event of the call once, so a block sum is one call's worth of appends. It is not an exact decomposition of the recorded-minus-mediated median: that median also contains the gateway's work to build the six events (not timed here), and the two figures come from different measurements (a paired difference of call latencies in the baseline session against a sum of appends timed here on their own). Appends of one log are serialized by its mutex, so with everything else running in parallel the log predicts about 1e6 / (entries per call x mean append us) calls/s for calls of this corpus's entries; the mean, not the median, sets that rate, so slow flushes lower it.

- Directory fsync: none on Windows: AgentGate's syncDir returns at once there (audit.go), so the fsync_dir stage times only that call. On other systems syncDir opens and fsyncs the run directory once per append, after the rename.
- Witness update: measured separately by internal/headwitness's TestWitnessPushCost (push_bench_test.go): a push is a separate round trip to the witness after the append. No reported latency includes one (the baseline runs no witness; the demo pushes the head after each agent step, outside the gateway call).
