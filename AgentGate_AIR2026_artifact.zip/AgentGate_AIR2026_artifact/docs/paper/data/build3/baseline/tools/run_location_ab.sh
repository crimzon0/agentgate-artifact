#!/usr/bin/env bash
# Diagnostic added in build 3 (not part of the build-2 method): does the folder
# the evidence is written to change the durable costs?
#
# Builds 1 and 2 wrote every evidence folder into the session scratchpad under
# %LOCALAPPDATA%\Temp, which Windows Search does not index. The build-3 brief
# puts raw folders under <repo>/.tools/build3-work, inside the user's Documents
# tree, which Windows Search indexes (checked with a SystemIndex SCOPE query).
# This script alternates the two locations with the same frozen binaries:
#   baseline (default sizes, as R1-R5):  T1 D1 T2 D2
#   TestStageCost (10,000 appends):      T1 D1 T2 D2
# T = -work / -stagecost.work in TEMPWORK (not indexed), D = in DIAG/work (indexed).
# The -out folders (results) are in DIAG for both. One typeperf log for the
# whole diagnostic records total CPU, disk writes and the CPU of the Windows
# Search indexer (SearchIndexer; its short-lived helper processes are not
# logged), Microsoft Defender (MsMpEng) and the System process.
#
#   EVAL=<singlebuild3>/bin/agentgate-eval.exe TESTBIN=<work>/baseline/testbin REPO=<repo> HOST_LABEL=review-host \
#     bash run_location_ab.sh DIAG TEMPWORK
set -u
EVAL="${EVAL:?set EVAL}"; TB="${TESTBIN:?set TESTBIN}"; REPO="${REPO:?set REPO}"
DIAG="${1:?diag dir}"; TW="${2:?temp work dir}"
mkdir -p "$DIAG/runs" "$DIAG/work" "$DIAG/stage" "$TW"
LOG="$DIAG/diag.log"
stamp() { echo "$1 $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$LOG"; }
typeperf "\Processor(_Total)\% Processor Time" "\PhysicalDisk(_Total)\Disk Writes/sec" "\PhysicalDisk(_Total)\Avg. Disk sec/Write" \
  "\Process(SearchIndexer)\% Processor Time" "\Process(MsMpEng)\% Processor Time" "\Process(System)\% Processor Time" \
  -si 1 -sc 7200 -f CSV -o "$(cygpath -w "$DIAG/diag-load.csv")" -y > /dev/null 2>&1 &
sleep 2
stamp "diag start"
for i in 1 2; do
  for loc in T D; do
    if [ "$loc" = T ]; then WORK="$TW/$loc$i"; else WORK="$DIAG/work/$loc$i"; fi
    stamp "baseline $loc$i start"
    "$EVAL" ${HOST_LABEL:+-host-label "$HOST_LABEL"} baseline -out "$DIAG/runs/$loc$i" -work "$WORK" > "$DIAG/runs/$loc$i.stdout.txt" 2>&1
    stamp "baseline $loc$i exit $?"
  done
done
for i in 1 2; do
  for loc in T D; do
    if [ "$loc" = T ]; then WORK="$TW/stage-$loc$i"; else WORK="$DIAG/work/stage-$loc$i"; fi
    mkdir -p "$WORK"
    stamp "stage $loc$i start"
    (cd "$REPO/internal/audit" && "$TB/audit.test.exe" -test.count=1 -test.v -test.run '^TestStageCost$' \
      -stagecost=10000 -stagecost.warmup=200 -stagecost.work="$WORK" -stagecost.out="$DIAG/stage/$loc$i") > "$DIAG/stage/$loc$i.log" 2>&1
    stamp "stage $loc$i exit $?"
  done
done
stamp "diag end"
sleep 1
taskkill //F //IM typeperf.exe > /dev/null 2>&1
