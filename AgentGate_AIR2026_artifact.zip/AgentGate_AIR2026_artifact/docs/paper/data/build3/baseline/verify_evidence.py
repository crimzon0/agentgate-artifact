"""Re-verify every baseline evidence folder with the frozen build-3 verifier
binary (new in build 3; not a timing, run after the timed session).

    py docs/paper/data/build3/baseline/verify_evidence.py <singlebuild3>/bin/agentgate-verify.exe <work>/baseline/session/work

The baseline itself verifies each evidence folder in process with the keys
fingerprint and final head it held outside the folder ("keys+head pinned") and
stores only the assurance level and the failing check IDs (baseline.json).
This script runs the standalone `agentgate-verify --json DIR` on every folder
that has an audit.jsonl, without pins (nothing pinned is kept outside the
folders after the run), to show what the build-3 verifier rules say about
these runs: every dimension's status, the Missing list by kind (an
`unresolved` entry would mean an operation left pending or unsettled, which
build 3 always reports as incomplete), the failing checks and warnings.
Without pins the assurance is CONSISTENT, never ANCHORED; that is expected.
Writes evidence-standalone.json next to this script (folders named relative to
the work folder).
"""
import collections
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def main(verifier, work):
    folders = sorted(os.path.dirname(os.path.join(root, "audit.jsonl")) for root, _, files in os.walk(work) if "audit.jsonl" in files)
    rows = []
    summary = {"folders": len(folders), "exit_codes": collections.Counter(), "verdict": collections.Counter(), "assurance": collections.Counter(),
               "dimensions": collections.defaultdict(collections.Counter), "missing_kinds": collections.Counter(),
               "warning_ids": collections.Counter(), "failing_check_ids": collections.Counter(), "folders_with_failures": 0,
               "entries": 0, "operations": 0, "unresolved_operations": 0}
    for folder in folders:
        proc = subprocess.run([verifier, "--json", folder], capture_output=True, text=True)
        rel = os.path.relpath(folder, work).replace("\\", "/")
        summary["exit_codes"][str(proc.returncode)] += 1
        try:
            report = json.loads(proc.stdout)
        except json.JSONDecodeError:
            rows.append({"folder": rel, "exit": proc.returncode, "error": "no JSON report"})
            continue
        dims = {name: d.get("status") for name, d in (report.get("dimensions") or {}).items()}
        failing = sorted({f.get("id") for f in report.get("failures") or []})
        warnings = sorted({w.get("id") for w in report.get("warnings") or []})
        kinds = collections.Counter(report.get("missing_kinds") or [])
        counts = report.get("counts") or {}
        rows.append({"folder": rel, "exit": proc.returncode, "verdict": report.get("verdict"), "assurance": report.get("assurance"),
                     "dimensions": dims, "missing_kinds": dict(kinds), "failing_checks": failing, "warnings": warnings,
                     "entries": counts.get("entries"), "operations": counts.get("operations"), "unresolved": counts.get("unresolved", 0)})
        summary["verdict"][report.get("verdict")] += 1
        summary["assurance"][report.get("assurance")] += 1
        for name, status in dims.items():
            summary["dimensions"][name][status] += 1
        summary["missing_kinds"].update(kinds)
        summary["warning_ids"].update(warnings)
        summary["failing_check_ids"].update(failing)
        summary["folders_with_failures"] += 1 if failing else 0
        summary["entries"] += counts.get("entries") or 0
        summary["operations"] += counts.get("operations") or 0
        summary["unresolved_operations"] += counts.get("unresolved") or 0
    summary = json.loads(json.dumps(summary))
    out = os.path.join(HERE, "evidence-standalone.json")
    with open(out, "w") as handle:
        json.dump({"method": __doc__.strip(), "summary": summary, "folders": rows}, handle, indent=1)
    print(json.dumps(summary, indent=1))
    print("wrote", out)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
