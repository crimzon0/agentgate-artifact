# build-manifest.txt

Copy of the build-3 manifest (`MANIFEST.txt` in the frozen build folder `.tools/singlebuild3`, outside git) with local paths replaced by `<repo>` (lines 3-4). The original file's SHA-256, which every experiment re-hashed against, is `0c436fc9fec8989638dccf4d3e62d609ec033a884d421b659f7ed820886968eb`. Build 3 is reproducible: `py docs/paper/build/make_build.py --commit 8a30fd4` rebuilds byte-identical binaries (see docs/paper/artifact/REPRODUCIBILITY.md).
