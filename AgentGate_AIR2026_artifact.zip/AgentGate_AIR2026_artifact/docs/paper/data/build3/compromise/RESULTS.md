# Flag-binding ablation and key-compromise simulation: build 3 rerun

Run on 2026-10-20 from 15:01:03 to 15:16:56 UTC, on **frozen build 3** (six
reproducible binaries built from commit `8a30fd4`, branch
`claude/supervisor-demo`; `MANIFEST.txt` SHA-256 `0c436fc9...68eb`), results
format `agentgate-compromise/v2`. It repeats the build-2 experiment
(`../../build2/compromise/RESULTS.md`, run 2026-10-10) for the answer to the
external review. The commands, parameters, repetitions and
analysis scripts are the same; only the binaries changed. As before, this is
a key-compromise **simulation**: nothing was re-signed, and no private key
was read, exported or generated. A first attempt of the same command was
aborted in run 6 of 10 by a base-run self-test failure (section 5,
`attempt1_failure.txt`); every number below comes from the second, complete
attempt.

**Headline.** Build 3 gives the same result as build 2 (and build 1) in
every cell. All 51,840 result rows have the same verdict, assurance,
`detected`, `simulated`, `applied` value, failing checks (in the same order)
and `not_applicable` text. Every derived file is byte-identical to build 2's
(section 3). 0 of 2,688 cells changed.

**Unit of analysis.** A *cell* is one operator x one attacker key set under
one anchor condition and one verifier setting: 7 operators x 12 key sets =
**84 cells per anchor condition**; the four anchor conditions give **336
attack cells** per verifier setting, of which **168 have no head anchor**
(anchors none and keys) and **168 have one** (head and both). A *binding
flip* is a cell that the bound design detects and the unbound design accepts
(strongest attacker, in 10/10 runs). The oracle's 10 key sets give 140 / 280
of those cells.

- **Binding flips** (of 336 attack cells; of the 168 without a head anchor):
  - full verifier: **0 of 336** (0 of 168);
  - only `policy.snapshot_bound` off (`no-snapshot-bound-only`): **8 of 336**
    (8 of 168);
  - `policy.replay` off (`no-replay`): **12 of 336** (12 of 168);
  - `no-replay-no-snapshot`: **12 of 336** (12 of 168).
  - The head-anchored subset is **all detected**: 0 of 168 flips in every
    setting, and 0 accepted cell-runs among the 13,440 strongest-attacker
    cell-runs with a head anchor (1,344 head-anchored cells x 10 runs, both
    designs, all four settings). There are no reverse flips.
- **Detections per design, full verifier, strongest attacker:** bound
  3,130/3,360 cell-runs detected (230 accepted), unbound 3,130/3,360 (230
  accepted). It defeats every check except the anchors in **46 of 672** cells
  per run (all 10 runs), in two cases: strip-flag and invent-flag with
  `forge-restate` and audit+issuer+adapter or larger key sets, and
  change-amount with audit+issuer+adapter+provider or larger.
- **Oracle agreement** on the frozen oracle (`docs/paper/oracle`, SHA-256
  unchanged since build 1):
  - full: **540/560** cells against the strongest attacker
    (`snapshot_bound+mode_checked`; 270/280 per design) and **560/560**
    against the plain attacker (`no_snapshot_forgery+mode_checked`);
  - no-snapshot-bound-only, strongest: **536/560** (`mode_checked`; bound
    270/280, unbound 266/280);
  - both no-replay settings: **560/560** (`mode_checked`, both attackers);
  - the 44 disagreements with the mapped readings are C1 (24) and C2 (20);
    all 1,888 disagreeing rows across every reading have a named cause; 0 are
    unexplained.
- **False alarms: 0.** 0 of 1,280 runner clean controls; the self-test pins
  of all 40 base runs give 40/40 VERIFIED/ANCHORED (35/35 checks); the
  separate `agentgate-verify` CLI accepts all 20 bound base runs at every
  anchor condition (ANCHORED with both anchors). The 20 unbound base runs
  fail in the CLI **by design** (no ablation option, `op.requires_policy`).
- **Stability.** 0 of 2,688 cells changed outcome across the 10 runs; no
  failing-check set changed.

## 1. What was run

**Method.** Unchanged from build 2 (`../../build2/compromise/RESULTS.md` §1)
and build 1 (`../../revision/compromise/RESULTS.md` §1):

- 7 operators x 12 attacker key sets x 4 anchor conditions x 2 designs
  (bound, unbound) x 4 verifier configurations = **2,688 cells per run**,
  10 runs.
- Each cell is tried with up to 3 snapshot variants (`plain`,
  `forge-snapshot`, `forge-restate`); a cell counts as detected only if every
  applicable variant is detected.
- Each run makes 4 base runs with the real gateway (flag and human mode,
  each bound and unbound): 40 base runs.
- Volume: 49,920 mutant verifications and 1,920 not-applicable rows; 6,720
  strongest-attacker cell-runs per configuration; 1,280 clean-control
  verifications.
- **Detected** means verdict FAILED; **accepted** means VERIFIED with any
  assurance, warnings or `missing` entries.

**Commands**, from the repository root (`<singlebuild3>` = the frozen build
folder, `<work>` = the persistent work folder outside git):

```
py <singlebuild3>/check_manifest.py                                   # before: 1,870 files, 0 differ (14:51:11Z; again 15:00:53Z before attempt 2)
<singlebuild3>/bin/agentgate-eval.exe -host-label review-host compromise -runs 10 -work <work>/compromise/work -out docs/paper/data/build3/compromise
py <singlebuild3>/check_manifest.py                                   # after the run and the analysis: 1,870 files, 0 differ (15:20:05Z; again 15:27:00Z after the probes)
cd docs/paper/data/build3/compromise
python analyze_compromise.py
python base_controls.py <work>/compromise/work <singlebuild3>/bin/agentgate-verify.exe .
python breakdown.py
python compare_build2.py                 # row- and file-level comparison with build 2
python cells_diff.py                     # cell-level comparison with build 2 (new)
python baserun_check.py <build-2 work> <work>/compromise/work > baserun_check.json        (new)
python earlier_keys_probe.py <work>/compromise/work <singlebuild3>/bin/agentgate-verify.exe .   (new; not a headline)
```

- **Scripts.** `analyze_compromise.py`, `base_controls.py`, `breakdown.py`
  and `baserun_structure.py` are byte-identical copies of build 2's (same
  SHA-256; the oracle path resolves from this folder unchanged).
  `compare_build2.py` and `compiled_files.py` are build 2's
  `compare_build1.py` and `compiled_files.py` with only the paths and labels
  changed. `cells_diff.py`, `baserun_check.py` and `earlier_keys_probe.py`
  are new; they read data or run the frozen verifier. Hashes:
  `build-manifest.txt`.
- **Binaries.** Only the build-3 binaries were used: `agentgate-eval`
  `cc4b9613...768e` (the experiment) and `agentgate-verify`
  `04038f9f...eb47` (CLI cross-checks). The manifest check re-hashed all
  1,870 entries four times (before each attempt, after the analysis, after the probes) with 0 differences.

**Validation of the simulation.** The same test packages as in build 2,
built with `go test -c` from HEAD (`git diff 8a30fd4 --stat -- internal cmd
go.mod go.sum` is empty) and run with `-test.count=1 -test.v`:

| package | top-level tests passed, build 3 | build 2 |
|---|---|---|
| `internal/auditverify` | 153/153 | 134/134 |
| `internal/auditverify/tools/refusalmutation` | 14/14 | 14/14 |
| `internal/evalattack` | 17/17 | 17/17 |
| `cmd/agentgate-eval` | 29/29 | 27/27 |

- The 19 + 2 extra tests are the round-4 and round-5 tests added since build
  2 (listed in `build-manifest.txt`): cnf, status date and order, pending
  operations, earlier-segment keys, witness status v2 and continuation
  linkage, real-signature lifecycle tests, enrollment probes.
- `TestSimulationAgreesWithRealAuditKeyResigning`: 11 audit-log edits x 4
  anchor conditions, each re-signed with the fixture's real audit key and
  verified unsigned under `AssumeCompromised=[AUDIT_LOG]`: **44/44 cells
  identical**, and the 44 logged lines are identical to build 2's apart from
  the test's duration (`validation_sim_vs_real.txt`).
- The role-by-role simulation tests passed: `TestEachRoleUnderSimulation`,
  `TestWitnessRoleUnderSimulation`, `TestReplacementKeysNeedAnAnchor`,
  `TestSimulationIsLabelled`, `TestAssumeCompromisedNamesAreChecked`,
  `TestEscalationModeCheckIsSymmetric`.
- As before, only the audit-key simulation has been compared with real
  re-signing in this experiment's validation.

## 2. Results

### 2.1 Binding flips per verifier setting and anchor condition

Of 84 cells per anchor condition, 168 without a head anchor, 168 with one,
336 in all (`flips_by_anchor.csv`, `flips.csv`). Every flip occurs in 10/10
runs.

| verifier setting | none | keys | head | both | **without head anchor** | with head anchor | **all** | oracle key sets (no head / all) | reverse |
|---|---|---|---|---|---|---|---|---|---|
| full | 0/84 | 0/84 | 0/84 | 0/84 | **0/168** | 0/168 | **0/336** | 0/140 / 0/280 | 0 |
| no-snapshot-bound-only | 4/84 | 4/84 | 0/84 | 0/84 | **8/168** | 0/168 | **8/336** | 8/140 / 8/280 | 0 |
| no-replay | 6/84 | 6/84 | 0/84 | 0/84 | **12/168** | 0/168 | **12/336** | 12/140 / 12/280 | 0 |
| no-replay-no-snapshot | 6/84 | 6/84 | 0/84 | 0/84 | **12/168** | 0/168 | **12/336** | 12/140 / 12/280 | 0 |

The flipped cells are the same as in builds 1 and 2:

- **no-replay** (12): {strip-flag, invent-flag, change-rules} x {audit,
  audit+issuer} x {none, keys}. The bound design catches them with
  `artifact.signature`, `op.capability_bound` and `op.receipts_bound` (audit
  key alone) or `artifact.signature` and `op.receipts_bound`
  (audit+issuer); in the unbound design `plain` evades.
- **no-snapshot-bound-only** (8): {strip-flag, invent-flag} x {audit,
  audit+issuer} x {none, keys}; in the unbound design the audit-key-only
  `forge-snapshot` evades.
- The plain attacker alone gives the same 12 flips in both no-replay
  configurations and none elsewhere.

### 2.2 Detections per design (strongest attacker, cell-runs)

| configuration | accepted (of 6,720) | bound accepted (of 3,360) | unbound accepted (of 3,360) | accepted with a head anchor |
|---|---|---|---|---|
| full | **460** | 230 | 230 | 0 |
| no-snapshot-bound-only | 540 | 230 | 310 | 0 |
| no-replay | 940 | 410 | 530 | 0 |
| no-replay-no-snapshot | 940 | 410 | 530 | 0 |

Detected = the rest (full: 6,260/6,720; 3,130/3,360 per design). All 4,780
accepted rows (of 49,920) are `SIMULATED_CONSISTENT`; none is ANCHORED. With
the full verifier the plain attacker gets only change-amount through: 100 of
6,720.

### 2.3 Strongest-attacker matrix

Full verifier, no anchor; bound and unbound are identical. "U" = accepted in
10/10 runs, "." = detected in 10/10 runs; strongest attacker, then the plain
attacker in brackets. Key sets: A audit, I issuer, D adapter (all three
adapter keys), P provider, G delegation, H approval, ALLs all-stolen, ALLr
all-replaced.

| operator | - | A | I | D | P | G | AI | AID | AIDP | AIDH | ALLs | ALLr |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| strip-flag | . | . | . | . | . | . | . | U[.] | U[.] | U[.] | U[.] | U[.] |
| invent-flag | . | . | . | . | . | . | . | U[.] | U[.] | U[.] | U[.] | U[.] |
| change-rules | . | . | . | . | . | . | . | . | . | . | . | . |
| change-escalation | . | . | . | . | . | . | . | . | . | . | . | . |
| swap-decisions | . | . | . | . | . | . | . | . | . | . | . | . |
| change-amount | . | . | . | . | . | . | . | . | U[U] | . | U[U] | U[U] |
| relabel-approved | . | . | . | . | . | . | . | . | . | . | . | . |

- **Keys anchor** removes only the ALLr column; a **head anchor** (head or
  both) makes every cell detected in every configuration.
- **no-replay**: strip-flag, invent-flag and change-rules are accepted with
  AID and larger in the bound design but with **A** and larger in the unbound
  design; relabel-approved with AID and larger in both (control).
- **no-snapshot-bound-only** differs from full only for unbound strip-flag
  and invent-flag, accepted with A and AI (`forge-snapshot`).
- All 64 matrices are in `matrices.json`; the minimal and necessary key sets
  (`keysets.json`) are unchanged: strip-flag and invent-flag need
  audit+issuer+adapter (every member necessary), change-amount needs
  audit+issuer+adapter+provider; the delegation key is never needed and the
  approval key never helped. As in build 2, "need" and "necessary" mean among
  the 12 tested key sets, for the canonical targets, on the receipt path
  (build 2's correction note applies unchanged).

### 2.4 Replacement keys (`replacement_keys.csv`, 14 rows per anchor condition)

| anchor | full: all-replaced [all-stolen] accepted | no-replay: all-replaced [all-stolen] |
|---|---|---|
| none | 6/14 [6/14] | 10/14 [10/14] |
| keys | 0/14 [6/14] | 0/14 [10/14] |
| head | 0/14 [0/14] | 0/14 [0/14] |
| both | 0/14 [0/14] | 0/14 [0/14] |

### 2.5 Oracle agreement (`oracle_agreement.csv`, `breakdown.json`)

Cells out of 560 (7 operators x 10 key sets x 4 anchors x 2 designs);
strongest / plain attacker; bold = mapped reading. The runner's counts are
10 times larger (one per run; it printed 5400/5600 and 5360/5600).

| reading | full | no-snapshot-bound-only | no-replay (both configs) |
|---|---|---|---|
| primary | 514 / 494 | 522 / 494 | 546 / 546 |
| no_snapshot_forgery | 526 / 546 | 518 / 546 | 494 / 494 |
| snapshot_bound | 526 / 506 | 518 / 506 | 534 / 534 |
| mode_checked | 528 / 508 | **536** / 508 | **560 / 560** |
| receipt_decision_unchecked | 502 / 482 | 510 / 482 | 534 / 534 |
| snapshot_bound + mode_checked | **540** / 520 | 532 / 520 | 548 / 548 |
| no_snapshot_forgery + mode_checked | 540 / **560** | 532 / **560** | 508 / 508 |

- Per design (mapped readings): full strongest 270/280 bound and unbound;
  full plain 280/280 each; no-snapshot-bound-only strongest 270/280 bound,
  266/280 unbound; no-replay 280/280 each.
- The 44 disagreements with the mapped readings: C1 (change-rules has no
  snapshot lever for the single-recipient target; 10 in full + 14 in
  no-snapshot-bound-only) and C2 (the engine does not delete the two
  never-executed approval requests a relabel-approved forgery would
  reclassify; 10 + 10). Limits of the canonical runs, not verifier gaps.
- All 1,888 disagreeing rows across every configuration, reading and
  attacker (`oracle_mismatches.csv`) have a cause from build 1's list (A3,
  A6, P1, C1, C2, S1, S2, F1, V2); none is unexplained.

### 2.6 Clean controls (false alarms)

| control | result |
|---|---|
| Runner controls: every unmutated base run, verified for real and with all six roles assumed compromised, under every anchor condition and configuration (`controls.csv`) | **1,280/1,280 VERIFIED, 0 false alarms**. Real: 600 CONSISTENT, 40 ANCHORED. Simulated: 600 SIMULATED_CONSISTENT, 40 SIMULATED_ANCHORED |
| Self-test pins of the 40 base runs (`base_controls.csv`) | 40/40 self-tests passed, VERIFIED/ANCHORED, 35/35 checks, 0 failed |
| `agentgate-verify` CLI (separate process) on the 20 bound base runs | 20/20 VERIFIED at every anchor condition (CONSISTENT; ANCHORED with both anchors); head equals the self-test pin in 40/40 |
| `agentgate-verify` CLI on the 20 unbound base runs | 20/20 FAILED by design (`op.requires_policy`; the CLI has no ablation option). Not a false alarm |
| Open operations in the 40 base runs (round-5 pending rule; `baserun_open_ops.txt`) | 0 pending, 0 unresolved, 0 warnings, no `unresolved` Missing entry |

## 3. Comparison with build 2 (and build 1)

Build 2 is `../../build2/compromise/` (agentgate-eval `485e4ce0...fdca`,
run 2026-10-10); build 1 is `../../revision/compromise/` (run 2026-10-08).
Build 2 had every number below, so build 1 is given for reference only; it
equals build 2 in every row.

| headline number | build 1 | build 2 | build 3 | difference and cause |
|---|---|---|---|---|
| binding flips, full | 0/336 (0/168) | 0/336 (0/168) | 0/336 (0/168) | none |
| binding flips, no-snapshot-bound-only | 8/336 (8/168) | 8/336 (8/168) | 8/336 (8/168) | none; same 8 cells |
| binding flips, no-replay | 12/336 (12/168) | 12/336 (12/168) | 12/336 (12/168) | none; same 12 cells |
| binding flips, no-replay-no-snapshot | 12/336 (12/168) | 12/336 (12/168) | 12/336 (12/168) | none |
| flips with a head anchor, any setting | 0/168 | 0/168 | 0/168 | none |
| reverse flips | 0 | 0 | 0 | none |
| accepted cell-runs, full (bound / unbound) | 460/6,720 (230 / 230) | 460/6,720 (230 / 230) | 460/6,720 (230 / 230) | none |
| accepted cell-runs, no-snapshot-bound-only | 540/6,720 (230 / 310) | 540/6,720 (230 / 310) | 540/6,720 (230 / 310) | none |
| accepted cell-runs, each no-replay setting | 940/6,720 (410 / 530) | 940/6,720 (410 / 530) | 940/6,720 (410 / 530) | none |
| accepted cell-runs with a head anchor | 0 | 0 | 0 | none |
| cells defeating every non-anchor check, full, per run | 46/672 | 46/672 | 46/672 | none |
| accepted rows | 4,780/49,920 | 4,780/49,920 | 4,780/49,920, all SIMULATED_CONSISTENT | none |
| plain attacker accepted, full | 100/6,720 | 100/6,720 | 100/6,720 | none |
| oracle, full, strongest / plain | 540/560 / 560/560 | 540/560 / 560/560 | 540/560 / 560/560 | none |
| oracle, no-snapshot-bound-only, strongest | 536/560 | 536/560 | 536/560 | none |
| oracle, no-replay, `mode_checked` | 560/560 | 560/560 | 560/560 | none |
| unexplained oracle disagreements | 0 of 1,888 | 0 of 1,888 | 0 of 1,888 | none |
| replacement keys, no anchor (full / no-replay) | 6/14 / 10/14 | 6/14 / 10/14 | 6/14 / 10/14 | none |
| runner clean controls | 1,280/1,280, 0 false alarms | the same | the same | none |
| CLI controls, bound / unbound | 20/20 VERIFIED / 20/20 FAILED by design | the same | the same | none |
| unstable cells across runs | 0/2,688 | 0/2,688 | 0/2,688 | none |
| simulation vs real audit-key re-signing | 44/44 | 44/44 | 44/44 | none |
| validation tests, `internal/auditverify` / `cmd/agentgate-eval` | – | 134 / 27 | 153 / 29 | **changed tests**: 19 + 2 tests added for rounds 4-5; all pass |
| manifest entries re-hashed | 1,809 (build 1 manifest) | 1,868 | 1,870 | **new build**: 6 binaries + 258 module files (256 in build 2) |
| base-run self-test failures | – | 0/40 | 0/40 in the reported run; 1 of 23 in the aborted first attempt | **new observation** of an old race (section 5); no effect on any number |

**Every cell is unchanged** (`cells_diff.json`: 0 of 2,688 cells differ in
any column, including the oracle columns). `compare_build2.py`
(`compare_build2.json`) does the comparison build 2 made against build 1:

- **Byte-identical to build 2:** `results.csv`, `strongest.csv`,
  `controls.csv`, `compromise.md`, `cells.csv`, `matrices.json`,
  `flips.csv`, `keysets.json`, `replacement_keys.csv`,
  `oracle_agreement.csv`, `oracle_mismatches.csv`, `unrepaired.csv`,
  `analysis.json`, `base_controls.csv`, `base_controls.json`,
  `flips_by_anchor.csv`, `breakdown.json`.
- **`results.json` differs only in run-specific values:**
  `environment.started_at`, `environment.clock_granularity_ms` (0.9999 vs
  1.0001 ms; not used), the `-out` path in `environment.command`, and the
  operation IDs inside the `unrepaired` notes of the 7,680
  relabel-approved x {forge-snapshot, forge-restate} rows.
- **Rows.** With those IDs normalised, all **51,840 rows** are equal, in the
  same order and with the same field set; `binding_flips`, `oracle`,
  `oracle_plain` and `controls` are equal.
- **Base runs.** Build 2's base-run audit logs are no longer on disk (its
  work folder was in a temporary directory that has been cleaned), so build
  2's entry-by-entry comparison could not be repeated (`baserun_structure.txt`
  says so). Instead (`baserun_check.json`): the 80 build-3 audit segments
  have **one** entry signature per (base, segment) across the 10 runs
  (174 / 4 entries in flag mode, 216 / 4 in human mode); against the files
  that survive from build 2, all 40 base runs have identical self-test
  scenario, custom-request and revision-check outcomes and verifier summaries
  (40/40), and all 80 provider journals have the same commit count (80/80).
  The replayed and reconciled records are the same as in build 2's
  `baserun_structure.txt`: one RECONCILED-committed AED 400.00 per base run
  (provider receipt and status, no adapter receipt, unflagged), 3 replayed
  answers of the AED 900.00 payment and 1 after the restart.

## 4. Why the build-3 changes do not move this experiment

**What changed in the compiled code.** 242 main-module files are compiled
into `agentgate-eval` and `agentgate-verify`; compared with build 2's 240,
**18 changed and 2 are new** (`internal/headwitness/enrollment.go`,
`pin.go`); all 242 equal the build-3 manifest (`build-manifest.txt`). The
experiment's own code did not change: `cmd/agentgate-eval/compromise.go`,
`compromise_oracle.go`, `harness.go`, `internal/evalattack/*` and
`internal/devcomposition/*` (the gateway) are byte-identical to build 2. The
changes are in the verifier, the witness and the CLI:

1. **Status-date and status-order rules for RECONCILED** (`reconcile.go`,
   `checks.go`; `op.outcome_resolved`). Each base run has one RECONCILED
   entry, the committed AED 400.00 payment in the first segment. It follows
   that operation's `EFFECT_FAILED` UNCERTAIN and the first call's
   `CALL_RESULT` UNCERTAIN, and is written by the retry's call (the order
   rule's reason; read in a run-03 base run, and all 10 runs have the same
   entry signature, `baserun_check.json`) and its provider status
   is dated inside the run (the date rule), so it passes: 1,280/1,280 controls
   VERIFIED. No operator targets that operation, and the engine changes no
   entry time. The new rule added `op.outcome_resolved` to no row: the failing
   checks are identical in all 51,840 rows (where `op.outcome_resolved`
   appears, e.g. some `forge-restate` mutants, it did so in build 2 for the
   same reasons).
2. **Pending and unresolved operations always incomplete**
   (`operations.go`, `freshness.go`, `assurance.go`, `provider.go`,
   `verify.go`). No base run has a pending or unresolved operation
   (`baserun_open_ops.txt`). The rule adds a warning, a Missing entry of kind
   `unresolved` and a `run_complete` status; none of them is a failing check,
   and the rows record verdict, assurance and failing checks only. The one
   failure it touches (`provider.matches_audit` for a provider receipt whose
   operation has a capability but no outcome) was already a failure in build
   2, with a different message.
3. **Capability cnf compared with the adapter key** (`operations.go`,
   `cose.go`; `op.capability_bound`). Every capability of the base runs names
   its effect type's adapter key (controls pass). No operator edits a cnf
   claim, nothing is re-signed, and the replacement key set substitutes the
   public keys but keeps every non-audit key ID, so cnf still names a listed
   key of the right adapter role and the receipt's signer key ID still equals
   cnf. An all-replaced attacker holds the issuer key and could re-issue cnf
   anyway, so the kept key IDs do not understate it.
4. **Earlier-segment keys pins and the "keys anchored for the newest segment
   only" report** (`segments.go`, `verify.go`, `assurance.go`). The runner
   and `base_controls.py` verify the base run's first folder (the one with
   `selftest-report.json`), which records no continuation, so the rule never
   applies here (`earlier_segments` 0). A probe on the 40 continuation
   segments (`earlier_keys_probe.csv`, real verification, frozen CLI) shows
   the build-3 behaviour this experiment does not measure: with only
   `--expect-keys`, `anchored_keys` is `not_checked` with one `keys.anchor`
   warning and the verdict and assurance are unchanged (20 bound runs
   VERIFIED/CONSISTENT); with `--expect-earlier-keys` it passes (`pins`);
   with a head pin it passes through the head (`head_pin`, ANCHORED); a wrong
   earlier pin fails `keys.anchor` (40/40). The unbound runs fail
   `op.requires_policy` in the CLI by design throughout.
5. **Witness changes** (`witness.go`, `internal/headwitness/*`,
   `internal/demo/custody.go`, `segment.go`, `cmd/agentgate-eval/custody.go`:
   enrollment key, pinned witness key, run status v2, continuation linkage).
   The compromise runs use no witness.
6. **`cmd/agentgate-verify/main.go`**: the `--expect-earlier-keys` flag and
   output text. The JSON verdict, assurance and failures that
   `base_controls.py` reads are unchanged (`base_controls.csv`
   byte-identical).
7. **Refusal sites** (150 in build 3, 142 in build 2): by a count of the
   `fail(Check...)` lines in the verifier diff, 9 were added and 1 removed
   (net 8): `keys.anchor` +5, `op.outcome_resolved` +2 / -1,
   `op.capability_bound` +1, `provider.matches_audit` +1. None of them
   changed any row.

**Consequence.** As in builds 1 and 2, the identical result is a regression
check: the build-3 changes did not alter any verdict this experiment
measures. It **does not test** the new rules: no mutated operation is
reconciled, pending or multi-segment, and no capability's cnf is edited. The
crash, killsuite, custody and fixture experiments are where those rules are
measured. Build 2's note on the engine gap (call-scope replayed COMMITTED
answers not rewritten by `rewriteDecision`) still applies unchanged
(`evalattack` did not change) and still affects no number here, because no
target has a replayed answer.

## 5. Unexpected: the aborted first attempt (`attempt1_failure.txt`)

- **What happened.** The first attempt (14:51:25-14:59:41Z) stopped with exit
  1 in run 6 of 10: the runner requires every base-run self-test to pass, and
  run 6's human/bound base run failed one of its 5 revision checks,
  `fault-response-lost`: the self-test saw the first call's run status
  "uncertain" but an empty gateway status (expected UNCERTAIN). Everything
  else in that self-test passed (18/18 scenarios, VERIFIED / ANCHORED, 8/8
  tampers). No results were written.
- **Investigation.** The audit log is correct: `CALL_RESULT` UNCERTAIN
  (`provider_response_lost`) at #205, the exact retry reconciled (#208
  RECONCILED committed, #209 COMMITTED reconciled), one provider effect. The
  dashboard's `GET /api/runs/{id}` handler snapshots the audit entries before
  it locks the server and reads the run; if the `CALL_RESULT` is appended and
  the run finishes in between (a window of a few milliseconds; #205 to #206
  is 5 ms), the view shows a finished run with no gateway status. It is an
  observation race in the demo's API and self-test, hit while other build-3
  runners loaded the machine. The files involved are byte-identical in builds
  1, 2 and 3, so build 3 did not introduce it; it is not fixed here (frozen
  build).
- **Action.** The failed work folder was kept aside, the manifest re-checked
  (0 differ) and the identical command re-run: exit 0, 40/40 base-run
  self-tests passed. Base-run self-test failures over both attempts: 1 of 63.
  It is not a false alarm of the verifier and changes no number.

## 6. Caveats

- **Simulation.** Signatures of the assumed-compromised roles are accepted
  without checking. Only the audit key has been compared with real re-signing
  in this validation (44/44). The other roles are validated one at a time,
  never against real re-signed COSE artifacts here; the simulator is a
  structural attack model, not cryptographic exploitation.
- **Sufficient vs necessary key sets.** Observed in simulation, among the 12
  tested key sets, for the canonical targets and on the receipt path; key
  counts count roles held in one process ("adapter" = all three adapter
  keys). Build 2's correction note (reconciliation path: audit + issuer keys
  with access to the provider's status interface sufficed in fixture runs)
  is unchanged.
- **Engine limits** (unchanged): one canonical target per operator, no
  multi-recipient change-rules target (C1); the never-executed approval
  requests are not deleted (C2); swap-decisions is a verbatim transplant; the
  provider receipt's effect-row and state hashes, the request digest and the
  approval-artifact hash lists are not recomputed; call-scope replayed
  answers are not rewritten.
- **Coverage of build 3's rules.** None of the round-5 verifier rules is
  exercised by a mutant here (section 4); identical results mean only that
  they caused no regression on these 2,688 cells.
- **Base-run comparison with build 2** uses the surviving self-test reports
  and provider journals, not the audit logs (deleted with build 2's temporary
  work folder).
- **Scope and timing.** The 10 repetitions re-run the same deterministic
  scripts with fresh keys and IDs (stability, not independent workloads); the
  anchors are the harness's own pins; one machine. Other build-3 experiment
  runners used the machine at the same time: the 15 min 53 s wall-clock time
  of the reported attempt (8 min 16 s for the aborted one) is not a
  performance result.

## 7. Files

| file | contents |
|---|---|
| `results.json`, `results.csv` | the runner's output: 51,840 rows, one per mutant verification (21 MB / 8.8 MB) |
| `strongest.csv` | one row per cell and run: strongest attacker, evading variants, plain outcome |
| `controls.csv` | 1,280 clean-control verifications |
| `compromise.md` | the runner's de-duplicated summary |
| `cells.csv`, `matrices.json`, `flips.csv`, `keysets.json`, `replacement_keys.csv`, `oracle_agreement.csv`, `oracle_mismatches.csv`, `unrepaired.csv`, `analysis.json` | `analyze_compromise.py` (unchanged since build 1) |
| `base_controls.csv`, `base_controls.json` | self-test and CLI verification of the 40 base runs (`base_controls.py`, unchanged) |
| `flips_by_anchor.csv`, `breakdown.json` | flips per setting and anchor condition, oracle agreement per design (`breakdown.py`, unchanged from build 2) |
| `compare_build2.json` | file-by-file and row-by-row comparison with build 2 (`compare_build2.py`) |
| `cells_diff.json`, `cells_diff.csv` | cell-level comparison with build 2: 0 changed cells (`cells_diff.py`; the CSV has only its header) |
| `baserun_structure.txt` | build 2's `baserun_structure.py` on the build-3 base runs: replayed and reconciled records (the comparison part is vacuous, see its note) |
| `baserun_check.json` | cross-run stability of the 80 build-3 audit segments and comparison with build 2's surviving self-test reports and journals (`baserun_check.py`) |
| `baserun_open_ops.txt` | pending / unresolved operations in the 40 base runs (none) |
| `earlier_keys_probe.csv` | 160 CLI verifications of the continuation segments under four pin sets (`earlier_keys_probe.py`; not a headline) |
| `validation_sim_vs_real.txt` | the 44 cells of `TestSimulationAgreesWithRealAuditKeyResigning` on build 3's source |
| `attempt1_failure.txt` | the aborted first attempt: failure, evidence, cause, action |
| `build-manifest.txt` | the four manifest checks with times, binary, script, oracle and test-binary hashes, test results, and the 242 compiled files with the 20 that differ from build 2 (`compiled_files.py`) |
| `analyze_compromise.py`, `base_controls.py`, `breakdown.py`, `baserun_structure.py`, `compare_build2.py`, `compiled_files.py`, `cells_diff.py`, `baserun_check.py`, `earlier_keys_probe.py` | analysis scripts (standard library only) |

The base runs, the aborted attempt and the logs stay outside the repository,
under `<work>/compromise/` (`work/`, `work-attempt1-failed/`, `testbin/`).
Mutants are generated, verified in memory and deleted.
