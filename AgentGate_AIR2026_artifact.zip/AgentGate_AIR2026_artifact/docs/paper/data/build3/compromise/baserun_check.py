#!/usr/bin/env python3
"""Base-run structure checks for the build-3 compromise rerun (new in build 3; reads data only).

Build 2's entry-by-entry comparison (baserun_structure.py) needs build 2's base-run
audit logs, and those are no longer on disk: build 2 kept its work folder in a
temporary directory that has since been cleaned, and only provider-journal.json
and selftest-report.json survive in its base-run folders. So this script does two
checks instead:

  1. Within build 3: for every (base run, segment index), the order-aligned entry
     signature (stage, outcome, effect_type, flag stated, scope, replayed, status)
     of the 10 runs; the number of distinct signatures must be 1.
  2. Build 2 vs build 3, from the files that survive in both: per (run, base) the
     self-test's scenario and custom-request outcomes (id, decision, statuses,
     provider effects, flagged, paused, passed), its revision checks (id, passed),
     its verifier summary (verdict, assurance, checks passed/failed, entries,
     operations), the restart folder's 4 entries count, and the provider journal
     of each segment (commit_seq and number of receipts).
Usage: python baserun_check.py BUILD2_WORK BUILD3_WORK
"""
import collections
import glob
import json
import os
import sys

b2, b3 = sys.argv[1], sys.argv[2]


def segments(work):
    out = {}
    for run in sorted(glob.glob(os.path.join(work, "run-*"))):
        for base in sorted(glob.glob(os.path.join(run, "*-*bound"))):
            out[(os.path.basename(run), os.path.basename(base))] = sorted(
                d for d in glob.glob(os.path.join(base, "run-*")) if os.path.isdir(d))
    return out


def sig(e):
    d = e.get("details") or {}
    return (e.get("stage"), e.get("outcome"), e.get("effect_type"), bool(d.get("flagged")), d.get("scope"),
            d.get("replayed"), d.get("status"))


def report_facts(seg_dir):
    path = os.path.join(seg_dir, "selftest-report.json")
    if not os.path.exists(path):
        return None
    r = json.load(open(path, encoding="utf-8"))
    pick = ("id", "decision", "want_status", "got_status", "want_provider_effects", "got_provider_effects",
            "want_flagged", "got_flagged", "paused_for_approval", "passed")
    v = r.get("verifier") or {}
    return {
        "passed": r.get("passed"),
        "scenarios": [tuple(s.get(k) for k in pick) for s in r.get("scenarios") or []],
        "custom": [tuple(s.get(k) for k in pick) for s in r.get("custom_requests") or []],
        "revision": [(c.get("id"), c.get("passed")) for c in r.get("revision_checks") or []],
        "verifier": tuple(v.get(k) for k in ("verdict", "assurance", "checks_passed", "checks_failed",
                                              "entries", "operations")),
    }


def journal(seg_dir):
    path = os.path.join(seg_dir, "provider-journal.json")
    if not os.path.exists(path):
        return None
    j = json.load(open(path, encoding="utf-8"))
    return (j.get("commit_seq"), len(j.get("entries") or []))


S2, S3 = segments(b2), segments(b3)
out = collections.OrderedDict()

# 1. stability of the build-3 base-run logs across the 10 runs
sigs = collections.defaultdict(set)
logs = 0
for (run, base), segs in S3.items():
    for i, seg in enumerate(segs):
        p = os.path.join(seg, "audit.jsonl")
        es = [json.loads(line)["entry"] for line in open(p, encoding="utf-8")]
        sigs[(base, i)].add(tuple(sig(e) for e in es))
        logs += 1
out["build3_audit_logs"] = logs
out["build3_distinct_signatures_per_base_and_segment"] = {"%s segment %d" % k: len(v) for k, v in sorted(sigs.items())}
out["build3_entries_per_base_and_segment"] = {"%s segment %d" % k: sorted({len(s) for s in v}) for k, v in sorted(sigs.items())}

# 2. build 2 vs build 3 on the surviving files
b2_audit = sum(1 for segs in S2.values() for s in segs if os.path.exists(os.path.join(s, "audit.jsonl")))
out["build2_base_run_audit_logs_on_disk"] = b2_audit
diffs = collections.Counter()
compared = collections.Counter()
examples = []
for key in sorted(set(S2) | set(S3)):
    s2, s3 = S2.get(key, []), S3.get(key, [])
    if len(s2) != len(s3):
        diffs["segment count"] += 1
        continue
    for i, (d2, d3) in enumerate(zip(s2, s3)):
        f2, f3 = report_facts(d2), report_facts(d3)
        if f2 is not None or f3 is not None:
            for field in ("passed", "scenarios", "custom", "revision", "verifier"):
                compared["self-test " + field] += 1
                if (f2 or {}).get(field) != (f3 or {}).get(field):
                    diffs["self-test " + field] += 1
                    if len(examples) < 5:
                        examples.append({"key": list(key), "segment": i, "field": field,
                                         "build2": (f2 or {}).get(field), "build3": (f3 or {}).get(field)})
        j2, j3 = journal(d2), journal(d3)
        compared["provider journal (commit_seq, receipts)"] += 1
        if j2 != j3:
            diffs["provider journal (commit_seq, receipts)"] += 1
            if len(examples) < 5:
                examples.append({"key": list(key), "segment": i, "field": "journal", "build2": j2, "build3": j3})
out["build2_vs_build3_base_runs"] = len(set(S2) & set(S3))
out["compared"] = dict(compared)
out["differences"] = dict(diffs)
out["difference_examples"] = examples
print(json.dumps(out, indent=1))
