#!/usr/bin/env python3
"""Cell-level comparison of this build-3 compromise analysis with build 2's (new in build 3).

Reads cells.csv (written by analyze_compromise.py) in this folder and in
docs/paper/data/build2/compromise, keys each cell by (verifier_config, anchors,
design, operator, keyset) and compares every outcome column: the strongest
attacker's outcome, detected_runs, each snapshot variant's outcome, modal
failing checks and assurance, the evading variants and checks_stable. The
oracle columns are compared too (the oracle is frozen, so they must be equal).
Writes cells_diff.csv (one row per changed cell and column) and
cells_diff.json (counts) next to this script. Standard library only.
Usage: python cells_diff.py [BUILD3_DIR] [BUILD2_DIR]
"""
import collections
import csv
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
B3 = sys.argv[1] if len(sys.argv) > 1 else HERE
B2 = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, "..", "..", "build2", "compromise")
KEY = ("verifier_config", "anchors", "design", "operator", "keyset")


def load(d):
    with open(os.path.join(d, "cells.csv"), encoding="utf-8") as f:
        return {tuple(r[k] for k in KEY): r for r in csv.DictReader(f)}


c2, c3 = load(B2), load(B3)
cols = [c for c in next(iter(c3.values())).keys() if c not in KEY]
out_rows = []
per_col = collections.Counter()
changed_cells = set()
for k in sorted(set(c2) & set(c3)):
    a, b = c2[k], c3[k]
    for c in cols:
        if a.get(c) != b.get(c):
            per_col[c] += 1
            changed_cells.add(k)
            out_rows.append(dict(zip(KEY, k), column=c, build2=a.get(c), build3=b.get(c)))
summary = {
    "cells_build2": len(c2), "cells_build3": len(c3),
    "only_build2": len(set(c2) - set(c3)), "only_build3": len(set(c3) - set(c2)),
    "columns_only_build2": sorted(set(next(iter(c2.values())).keys()) - set(next(iter(c3.values())).keys())),
    "columns_only_build3": sorted(set(next(iter(c3.values())).keys()) - set(next(iter(c2.values())).keys())),
    "cells_with_any_change": len(changed_cells),
    "changes_per_column": dict(per_col),
    "cells_whose_strongest_outcome_changed": sum(1 for k in changed_cells if c2[k]["outcome"] != c3[k]["outcome"]),
    "cells_whose_plain_outcome_changed": sum(1 for k in changed_cells if c2[k]["plain"] != c3[k]["plain"]),
}
with open(os.path.join(HERE, "cells_diff.csv"), "w", encoding="utf-8", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(KEY) + ["column", "build2", "build3"], lineterminator="\n")
    w.writeheader()
    w.writerows(out_rows)
with open(os.path.join(HERE, "cells_diff.json"), "w", encoding="utf-8", newline="\n") as f:
    json.dump(summary, f, indent=1)
    f.write("\n")
print(json.dumps(summary, indent=1))
