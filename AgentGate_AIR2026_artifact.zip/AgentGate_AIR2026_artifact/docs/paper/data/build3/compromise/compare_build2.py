#!/usr/bin/env python3
"""Compare this build-3 compromise run with build 2 (docs/paper/data/build2/compromise).

A copy of build 2's compare_build1.py with only the paths, the output labels (build2 = previous,
build3 = this run) and the output name changed. The same comparison:
  * byte comparison of every output file both folders have;
  * results.json rows keyed by (run, verifier_config, anchors, design, mode,
    operator, keyset, variant), compared on verdict, assurance, detected,
    simulated, applied, failing checks (in order) and not_applicable text, with
    operation IDs and hashes in the unrepaired notes normalised;
  * fields a row has in one build only;
  * the top-level summary fields (binding_flips, oracle, oracle_plain, controls);
  * controls.csv rows.
Writes compare_build2.json next to this script. Standard library only.
Usage: python compare_build2.py [BUILD3_DIR] [BUILD2_DIR]
"""
import collections
import csv
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
B2 = sys.argv[1] if len(sys.argv) > 1 else HERE
B1 = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, "..", "..", "build2", "compromise")

KEY = ("run", "verifier_config", "anchors", "design", "mode", "operator", "keyset", "variant")
FIELDS = ("verdict", "assurance", "detected", "simulated", "applied", "failing_checks", "not_applicable")
FILES = ["results.csv", "strongest.csv", "controls.csv", "compromise.md", "cells.csv", "matrices.json",
         "flips.csv", "keysets.json", "replacement_keys.csv", "oracle_agreement.csv", "oracle_mismatches.csv",
         "unrepaired.csv", "analysis.json", "base_controls.csv", "base_controls.json", "flips_by_anchor.csv",
         "breakdown.json", "results.json"]


def norm(text):
    text = re.sub(r"operation [A-Za-z0-9_-]{6,}", "operation X", text)
    text = re.sub(r"run-[0-9]{8}-[0-9]{6}-[0-9a-f]{6}", "run-X", text)
    return re.sub(r"\b[0-9a-f]{32,}\b", "<hash>", text)


def load(d):
    with open(os.path.join(d, "results.json"), encoding="utf-8") as f:
        return json.load(f)


def main():
    out = {"files": {}}
    for name in FILES:
        p1, p2 = os.path.join(B1, name), os.path.join(B2, name)
        if not (os.path.exists(p1) and os.path.exists(p2)):
            out["files"][name] = "missing in " + ("build 2" if not os.path.exists(p1) else "build 3")
            continue
        out["files"][name] = "identical" if open(p1, "rb").read() == open(p2, "rb").read() else "differs"

    r1, r2 = load(B1), load(B2)
    rows1 = {tuple(r.get(k) for k in KEY): r for r in r1["rows"]}
    rows2 = {tuple(r.get(k) for k in KEY): r for r in r2["rows"]}
    out["rows"] = {"build2": len(rows1), "build3": len(rows2),
                   "only_build2": len(set(rows1) - set(rows2)), "only_build3": len(set(rows2) - set(rows1))}
    diffs = collections.Counter()
    examples = collections.defaultdict(list)
    unrep_diff = 0
    for k in sorted(set(rows1) & set(rows2), key=lambda t: tuple(str(x) for x in t)):
        a, b = rows1[k], rows2[k]
        for f in FIELDS:
            if a.get(f) != b.get(f):
                diffs[f] += 1
                if len(examples[f]) < 5:
                    examples[f].append({"key": dict(zip(KEY, k)), "build2": a.get(f), "build3": b.get(f)})
        if [norm(x) for x in a.get("unrepaired") or []] != [norm(x) for x in b.get("unrepaired") or []]:
            unrep_diff += 1
            if len(examples["unrepaired"]) < 5:
                examples["unrepaired"].append({"key": dict(zip(KEY, k)), "build2": a.get("unrepaired"), "build3": b.get("unrepaired")})
    out["row_field_differences"] = dict(diffs)
    out["row_unrepaired_differences_after_normalising"] = unrep_diff
    out["row_difference_examples"] = examples
    f1 = collections.Counter(f for r in r1["rows"] for f in r)
    f2 = collections.Counter(f for r in r2["rows"] for f in r)
    out["row_fields_only_build2"] = {f: n for f, n in f1.items() if f not in f2}
    out["row_fields_only_build3"] = {f: n for f, n in f2.items() if f not in f1}
    out["top_level_keys_only_build2"] = sorted(set(r1) - set(r2))
    out["top_level_keys_only_build3"] = sorted(set(r2) - set(r1))
    out["summary_fields"] = {k: ("equal" if r1.get(k) == r2.get(k) else "differs")
                             for k in ("binding_flips", "oracle", "oracle_plain", "controls", "format", "runs",
                                       "keysets", "operators", "variants", "verifier_configs", "anchors", "note")}
    out["environment_build2"] = r1.get("environment")
    out["environment_build3"] = r2.get("environment")

    def ctrl(d):
        with open(os.path.join(d, "controls.csv"), encoding="utf-8") as f:
            return list(csv.DictReader(f))
    c1, c2 = ctrl(B1), ctrl(B2)
    out["controls_csv"] = {"build2_rows": len(c1), "build3_rows": len(c2),
                           "columns_only_build2": sorted(set(c1[0]) - set(c2[0])) if c1 and c2 else [],
                           "columns_only_build3": sorted(set(c2[0]) - set(c1[0])) if c1 and c2 else []}
    common = [c for c in (c1[0].keys() if c1 else []) if c2 and c in c2[0]]
    out["controls_csv"]["rows_differing_on_common_columns"] = sum(
        1 for a, b in zip(c1, c2) if any(a[c] != b[c] for c in common))
    with open(os.path.join(HERE, "compare_build2.json"), "w", encoding="utf-8", newline="\n") as f:
        json.dump(out, f, indent=1)
        f.write("\n")
    print(json.dumps({k: v for k, v in out.items() if k not in ("row_difference_examples",)}, indent=1))


if __name__ == "__main__":
    main()
