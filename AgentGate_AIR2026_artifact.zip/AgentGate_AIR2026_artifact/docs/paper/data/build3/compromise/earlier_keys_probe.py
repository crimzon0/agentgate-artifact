#!/usr/bin/env python3
"""Probe of build 3's earlier-segment keys rule on the compromise base runs (new in build 3; not a headline).

The compromise runner and base_controls.py verify the first segment of each base
run (the folder holding selftest-report.json), which records no continuation, so
the round-5 rule "keys anchored for the newest segment only" never applies to
them. This probe verifies the second segment of every base run (the restart
continuation, which continues the first) with the frozen agentgate-verify CLI,
REAL verification (no simulation), under four pin sets:
  keys           --expect-keys <newest keys.json SHA-256>
  keys+earlier   --expect-keys ... --expect-earlier-keys <first segment's keys.json SHA-256>
  both           --expect-keys ... --expect-head <newest head entry_hash>
  wrong-earlier  --expect-keys ... --expect-earlier-keys <64 zeros>
and records verdict, assurance, anchored_keys, the keys.anchor warnings and
failures, Missing kinds and anchors.earlier_keys_anchored_by.
Writes earlier_keys_probe.csv into OUT_DIR. Usage: python earlier_keys_probe.py WORK_DIR VERIFY_EXE OUT_DIR
"""
import collections
import csv
import glob
import hashlib
import json
import os
import subprocess
import sys

work, verify_exe, out_dir = sys.argv[1], sys.argv[2], sys.argv[3]


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


rows = []
for base_dir in sorted(glob.glob(os.path.join(work, "run-*", "*-*bound"))):
    segs = sorted(d for d in glob.glob(os.path.join(base_dir, "run-*")) if os.path.isdir(d))
    if len(segs) != 2:
        continue
    first, newest = segs
    keys, earlier = sha(os.path.join(newest, "keys.json")), sha(os.path.join(first, "keys.json"))
    head = json.load(open(os.path.join(newest, "head.json"), encoding="utf-8"))["entry_hash"]
    pinsets = {"keys": ["--expect-keys", keys],
               "keys+earlier": ["--expect-keys", keys, "--expect-earlier-keys", earlier],
               "both": ["--expect-keys", keys, "--expect-head", head],
               "wrong-earlier": ["--expect-keys", keys, "--expect-earlier-keys", "0" * 64]}
    for name, pins in pinsets.items():
        proc = subprocess.run([verify_exe, "--json"] + pins + [newest], capture_output=True)
        rep = json.loads(proc.stdout.decode("utf-8"))
        warns = [w for w in rep.get("warnings") or [] if w.get("id") == "keys.anchor"]
        fails = sorted({x.get("id") for x in rep.get("failures") or []})
        rows.append({"run": os.path.basename(os.path.dirname(base_dir)), "base": os.path.basename(base_dir),
                     "pins": name, "verdict": rep.get("verdict"), "assurance": rep.get("assurance"),
                     "anchored_keys": rep["dimensions"]["anchored_keys"]["status"],
                     "keys_anchor_warnings": len(warns), "failing_checks": " ".join(fails),
                     "missing_kinds": " ".join(rep.get("missing_kinds") or []),
                     "earlier_segments": (rep.get("anchors") or {}).get("earlier_segments", 0),
                     "earlier_keys_anchored_by": (rep.get("anchors") or {}).get("earlier_keys_anchored_by", ""),
                     "exit": proc.returncode})
with open(os.path.join(out_dir, "earlier_keys_probe.csv"), "w", encoding="utf-8", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()), lineterminator="\n")
    w.writeheader()
    w.writerows(rows)
print(len(rows), "verifications of", len(rows) // 4, "continuation segments")
for k, n in sorted(collections.Counter((r["pins"], r["verdict"], r["assurance"], r["anchored_keys"], r["keys_anchor_warnings"],
                                         r["failing_checks"], r["earlier_keys_anchored_by"]) for r in rows).items()):
    print(n, k)
