# Concurrency on build 3 (R6.4, rerun for review round 5)

This folder holds the concurrency experiment rerun on **frozen build 3**
(commit `8a30fd4`, reproducible binaries, 2026-10-20 14:55:57-15:10:01 UTC).
The method is build 2's (`docs/paper/data/build2/concurrency/RESULTS.md`,
2026-10-10), unchanged:
- the same seven runs and sizes;
- the same harness (`cmd/agentgate-eval/concurrency.go` and `harness.go` are
  byte-identical to build 2, and `concurrency.go` to build 1);
- the same analysis scripts (`analyze.py`, `aggregate.py`, `replay_scope.py`,
  `verifier_fields.py`, `join_cpu.py`, `sampler.ps1` are byte-identical to
  build 2's);
- the same unit tests, plus four for build 3's change on this path.

Only the binaries changed. Four scripts are new (§1, Analysis):
`build3_fields.py`, `compare_verifiers.py`, `record_shapes.py` and
`scan_names.py`.

**Headline.** Every invariant held in all **1,820 scenario-repetitions**
(260 repetitions x 7 scenarios, 33,040 calls, 10,740 operations):
- at most one provider effect per operation ID;
- no COMMITTED answer without an effect;
- no budget or count overshoot.

**Evidence.** All 260 evidence folders verify with 0 failing checks (0 false
alarms) in every one of 1,560 verifications:
- with keys and head pinned (the harness): 260/260 VERIFIED/ANCHORED;
- with the standalone verifier and no anchors: 260/260 VERIFIED/CONSISTENT,
  three times (780 runs);
- on the standalone verifier's pinned code path: 260/260 VERIFIED/ANCHORED;
- with the build-2 verifier (rebuilt from build 2's source) on the same
  folders: 260/260 VERIFIED/CONSISTENT.

**Lease.** With the 30 s development dispatch lease there were 0 lease expiries
in 3,640 dispatches. The closest any dispatch came to its deadline was
28.36 s away.

**Replay scope.** All 15,220 repeated answers are logged with scope `call`.

**Race detector.** 0 reports in 60 instrumented repetitions.

**What differs from build 2.** The safety, completion, journal, replay and
verifier-field results are identical to build 2's, number for number. Two
things in the evidence differ, both from build 3's verifier:
- **The report lists a fifth assumption**, "One clock" (the status-date rule
  compares times stamped by the provider, the capability issuer and the audit
  recorder). The build-2 verifier, run on the same 260 folders, gives a
  report identical in every other field: verdict, assurance, all 34 check
  statuses and detail texts, Missing entries and kinds, counts, dimensions,
  anchors and operations (§4.2).
- **The new rules were exercised and accepted the genuine evidence.** The
  260 RECONCILED entries (one per folder, the lost-response operation) pass
  the new status-date and status-order rules, the 3,640 capabilities pass
  the new confirmation-key (cnf) rule, and no operation is pending with a
  capability (§4.1).

Otherwise: **which tool won cross-tool-reuse** (the scheduler picks it) and
**timing** (the machine was loaded).

This is one local run on one machine, not a proof.

## 1. Method

The method is unchanged from builds 1 and 2. In each repetition N goroutines
wait on one barrier, and each sends one JSON-RPC `tools/call` to the
in-process MCP handler. Each repetition gets:
- a fresh provider host (in process, own key, loopback HTTP);
- a fresh gateway with its own operation journal;
- a signed grant (budget USD 3,000.00, `document.release` MaxCount 3);
- an evidence folder.

Escalation mode is `flag`, the harness default. None of the requests fires a
flag rule: 0 of 33,040 CALL_RESULT entries carry `flagged=true`. Effects are
counted from the provider's signed journal. Every run used
`-host-label review-host`.

**Commands** (`analysis/run_all.sh`, sequential; `<work>` is
`<repo>/.tools/build3-work`, and the harness's work folder is
`<work>/concurrency/work/<run>`):

```
<singlebuild3>/bin/agentgate-eval.exe -host-label review-host concurrency \
    -out docs/paper/data/build3/concurrency/<run> -work <work>/concurrency/work/<run> -repeat <R> -n <N>
GOMAXPROCS=1 <singlebuild3>/bin/agentgate-eval.exe ...           (gomaxprocs1-*)
<work>/concurrency/agentgate-eval-race.exe ...                   (race-*)
```

| run (folder) | N | repetitions | note | UTC | median machine CPU |
|---|---|---|---|---|---|
| `n8` | 8 | 50 | | 14:55:57-14:57:11 | 100 % |
| `n32` | 32 | 50 | | 14:57:11-15:00:30 | 100 % |
| `replicate-n8` | 8 | 50 | | 15:00:30-15:01:19 | 99.5 % |
| `gomaxprocs1-n8` | 8 | 20 | GOMAXPROCS=1 | 15:01:19-15:01:37 | 95.0 % |
| `race-n8` | 8 | 30 | `-race` build | 15:01:37-15:03:36 | 100 % |
| `race-n32` | 32 | 30 | `-race` build | 15:03:36-15:08:09 | 100 % |
| `gomaxprocs1-n32` | 32 | 30 | GOMAXPROCS=1 | 15:08:09-15:10:01 | 100 % |

**Totals (the units counted)**

| unit | count |
|---|---|
| repetitions | 260 (150 at N=8, 110 at N=32) |
| scenario-repetitions | 1,820 |
| calls | 33,040 |
| logical operations (operation IDs) | 10,740 |
| capability consumptions, dispatch intents and provider effects | 3,640 each |
| evidence folders | 260 |
| audit entries / journal records | 77,240 / 36,820 |
| verifications | 1,560: 260 in the harness (pinned) + 780 by the frozen standalone verifier without anchors (`analyze.py`, `verifier_fields.py`, `compare_verifiers.py`, 260 each) + 260 by the frozen standalone verifier on its pinned code path (`build3_fields.py`) + 260 by the build-2-source verifier (`compare_verifiers.py`) |

Seven runs exited 0. None logged `VIOLATED`. No repetition had an error.

### Build (`build-manifest.txt`)

**Binaries.**
- The five runs without `-race` used the frozen `agentgate-eval.exe`
  (`cc4b9613...6e768e`).
- The analysis used the frozen `agentgate-verify.exe` (`04038f9f...f432f`).

Both come from `<singlebuild3>/bin`. Its manifest (`MANIFEST.txt`, SHA-256
`0c436fc9...968eb`) has 1,870 entries:
- the 6 binaries;
- 258 module files;
- 385 third-party files;
- 1,221 standard-library files.

`check_manifest.py` re-hashed all of them four times, with 0 differences each
time (UTC):
- before any build or run (14:53:25-14:53:26);
- after the race build (14:55:10-14:55:12);
- after the last harness run (15:10:16-15:10:17);
- after the analysis and unit tests (15:15:30-15:15:31).

The working tree was at `8a30fd4`; `git diff 8a30fd4 --stat -- internal cmd
go.mod go.sum` is empty. Its only differences from the commit are a modified
PDF and untracked files, none of them compiled.

**Race build.** `race-n8` and `race-n32` used `agentgate-eval-race.exe`,
SHA-256 `10e450a91d2bcfdbde82f5b2674e8b09af445257732e956579e0559e834145de`.
- It was built at 14:53:59-14:55:01 UTC from the source of HEAD with the
  frozen build's own recipe plus `-race`: `git archive 8a30fd4 go.mod go.sum
  cmd internal`, `go mod vendor`, then
  `CGO_ENABLED=1 GOFLAGS=-mod=vendor go build -race -trimpath -buildvcs=false -ldflags=-buildid= -o <work>/concurrency/agentgate-eval-race.exe ./cmd/agentgate-eval/`.
- The staged source was checked: its 258 module files equal the hashes in
  `MANIFEST.txt` (0 differ).
- Toolchain: Go 1.26.6, offline flags, CGO through msys64 ucrt64 gcc 15.2.0.
- Its `go version -m` differs from the frozen `agentgate-eval.exe` only in
  `build -race=true` and `CGO_ENABLED=1` (the race detector needs cgo; the
  frozen build uses `CGO_ENABLED=0`). Module path, dependencies and the other
  build settings are the same. (Build 2's frozen binaries carried VCS
  stamps; build 3's are built with `-buildvcs=false`, so neither binary has
  a `vcs.revision` line.)

**Build-2-source verifier** (one cross-check only, §4.2). Build 2's raw
evidence folders and its binaries were kept in a temporary folder that no
longer exists. To attribute differences in the verifier's report anyway,
`agentgate-verify` was rebuilt from commit `86643d7` (build 2): `git archive`,
`go mod vendor`, `go build -trimpath -buildvcs=false -ldflags=-buildid=`,
SHA-256 `c6f2a8dd...24e8`. All 256 module files of the staged source equal the
hashes in build 2's `build-manifest.txt` (0 differ). It is not build 2's
binary (`83d0786a...`); only the source is the same.

**What changed since build 2 on this code path.** Of the 256 module files of
build 2, 19 changed and 2 were added (258 in build 3). On this path only the
verifier changed:
- `internal/auditverify/{assurance,checks,cose,freshness,operations,provider,reconcile,segments,verify,witness}.go`,
  linked into `agentgate-eval` for the harness's pinned verification;
- `cmd/agentgate-verify/main.go`, the standalone CLI.

The other changed files are the witness enrollment and custody code
(`internal/headwitness`, `internal/demo/{custody,segment}.go`,
`cmd/agentgate-eval/custody.go`, `cmd/agentgate-witness/main.go`), which the
concurrency subcommand never calls. The gateway (`internal/devcomposition`),
`capability`, `controlpoint`, `simulator`, `opjournal`, `audit`, `adapters`
and the harness files are byte-identical to build 2. go.mod and go.sum are
unchanged.

What build 3's verifier changed (`docs/demo/VERIFIER_CHECKS.md`, "build 3";
no check ID was added), and whether this experiment exercises it:

| build-3 verifier change | exercised here? |
|---|---|
| `op.outcome_resolved`: the status observation of a RECONCILED entry is dated (at most entry time + 5 s; for `committed` at least the capability's `iat` - 5 s), and a RECONCILED `committed` entry that records the effect needs a reason to reconcile | yes: 260 RECONCILED entries, all accepted (§4.1) |
| an operation pending with a verified capability and no outcome is reported incomplete (warning, Missing kind `unresolved`, `run_complete` not pass) | only its absence: 0 such operations (all 10,740 are resolved) |
| `op.capability_bound` compares the capability's `cnf` with the adapter key | yes: 3,640 capabilities, all accepted |
| `assumptions` lists "One clock" | yes: in 260/260 reports |
| `keys.anchor` for earlier segments (`--expect-earlier-keys`, "keys anchored for the newest segment only") | no: every folder is one segment; `anchors.earlier_segments` is absent in 260/260 |
| witness continuation linkage, pinned enrollment, run status v2 | no: the harness starts no witness |

### Analysis

**Same scripts as build 2** (byte-identical).
- `analyze.py`:
  - decodes the provider receipts with its own CBOR decoder;
  - checks every operation's journal transitions;
  - counts safety apart from completion;
  - measures the lease;
  - runs the standalone verifier without anchors on every folder;
  - scans every evidence file for the machine name.
- `aggregate.py` collects its totals.
- `replay_scope.py` counts the CALL_RESULT entries by scope.
- `verifier_fields.py` reads the build-2 verifier fields (`head_fresh`,
  `run_complete`, Missing kinds, check-status counts, classification
  evidence, flagged counts).
- `join_cpu.py` joins the CPU samples (`sampler.ps1`) to the runs.

**New scripts.**
- `build3_fields.py` reads what build 3's verifier rules read, on its own:
  - for every RECONCILED entry, the margins of the status-date rule and which
    reasons to reconcile are present;
  - operations pending with a capability;
  - whether each capability's `confirmation_kid` names the adapter key of
    the role its audience implies.

  It also runs the frozen CLI on its pinned code path. The harness does not
  store its in-memory pins in `concurrency.json`, so the pins are taken from
  the folder itself (SHA-256 of `keys.json`, `head.json`'s entry hash). This
  exercises the CLI's pinned path and build 3's single-segment `keys.anchor`
  rule; it is **not** an independent anchor.
- `compare_verifiers.py` runs the frozen build-3 verifier and the
  build-2-source verifier on each folder and compares every report field.
- `record_shapes.py` counts the audit entries by (stage, detail keys) and the
  journal records by (kind, data keys), and writes them to a file so that a
  later build can be compared file to file. Build 2 compared shapes by hand
  and kept no file.
- `scan_names.py` counts the machine name and the Windows user name in every
  raw evidence file, and classifies each user-name hit by the hex run around
  it. Build 2 did the user-name part by hand.

`analysis_all.sh` runs them in the order used.

## 2. Results (260 repetitions per scenario)

| scenario | the N calls | provider effects | answers |
|---|---|---|---|
| exact-payment | N identical payments, one ID | exactly 1 in 260/260 | 4,720/4,720 COMMITTED, one provider reference |
| exact-message | N identical internal messages, one ID | exactly 1 in 260/260 | 4,720/4,720 COMMITTED |
| conflicting-reuse | one ID, N different amounts | exactly 1 in 260/260 | 260 COMMITTED + 4,460 REJECTED/operation_id_conflict |
| cross-tool-reuse | one ID, N/2 payments + N/2 messages | exactly 1 in 260/260 | 2,360 COMMITTED + 2,360 REJECTED/operation_id_conflict; payment won 62, message won 198 |
| lost-response | N identical payments, response loss armed once | exactly 1 in 260/260 | 260 UNCERTAIN/provider_response_lost + 4,460 COMMITTED/reconciled; 0 REJECTED |
| budget-race | N fresh-ID USD 500.00 payments, budget USD 3,000.00 | exactly 6 (USD 3,000.00) in 260/260 | 1,560 COMMITTED + 3,160 REJECTED/policy_denied |
| count-race | N fresh-ID public releases, MaxCount 3 | exactly 3 in 260/260 | 780 COMMITTED + 3,940 REJECTED/policy_denied |

Within each run every repetition had the same answer pattern (one pattern
per scenario per N).

**Invariants (out of 1,820 scenario-repetitions unless stated)**

| invariant | result |
|---|---|
| harness invariant (`assessRace`) | 1,820 / 1,820 |
| safety, counted separately from completion (the five conditions are listed below the table) | 1,820 / 1,820 |
| completion: the expected number of effects, and every caller of the winning request COMMITTED | 1,820 / 1,820 |
| consistency: identical requests got identical answers, and the CALL_RESULT answers in the audit log equal what the callers received | 1,820 / 1,820 (each part 1,820 / 1,820) |
| journal transitions in an allowed order | 10,740 / 10,740 operations; journal sequence numbers have no gaps in 260/260 repetitions |
| independent effect count equals the harness's | 1,820 / 1,820. 3,640 receipts, all APPLIED, 14 per repetition; dispatch intents equal effects everywhere |
| each operation with a receipt has exactly one EFFECT_EXECUTED (3,380) or one RECONCILED (260) | 3,640 / 3,640; the 7,100 operations without a receipt have neither |
| delegation after each repetition: reservations back to 0, USD committed exactly 300,000 minor units, releases exactly 3 | 260 / 260 |
| race detector reports | 0 in 60 instrumented repetitions (420 scenario-repetitions) |
| answers `UNCERTAIN/dispatch_lease_expired` | 0 |

The safety row requires all of these:
- at most 1 effect per operation ID;
- 0 of 33,040 answers COMMITTED without an effect;
- 0 REJECTED answers to a request identical to the one that produced the
  effect;
- 0 REJECTED answers in lost-response;
- no budget or count overshoot.

How the 10,740 operations ended:
- **7,100 REJECTED:** `received > recorded REJECTED`.
- **3,380 COMMITTED:** `received > capability_issued > capability_consumed >
  dispatch_intent > provider_outcome > recorded COMMITTED`.
- **260 UNCERTAIN, then COMMITTED:** `... recorded UNCERTAIN > reconcile_query
  > reconciled > recorded COMMITTED`.

No operation had a dispatch intent and ended REJECTED.

**Dispatch lease** (3,640 dispatches, 30 s development lease)

| run | consume to dispatch intent, median | p99 | max | minimum slack to the deadline |
|---|---|---|---|---|
| n8 / replicate-n8 / n32 | 5.2 / 4.0 / 4.3 ms | 40.6 / 23.7 / 81.3 ms | 57.6 / 119.0 / 162.8 ms | 28,942.6 / 28,995.4 / 28,904.3 ms |
| race-n8 / race-n32 | 19.4 / 18.0 ms | 149.0 / 190.0 ms | 375.2 / 369.9 ms | 28,894.7 / 28,364.0 ms |
| gomaxprocs1-n8 / gomaxprocs1-n32 | 15.0 / 12.0 ms | 68.9 / 82.5 ms | 91.3 / 154.1 ms | 28,965.4 / 28,910.4 ms |

- The deadline is taken as min(floor(capability issued) + 30 s, capability
  expiry). This is a lower bound.
- The minimum slack was 28,364.0 ms, in `race-n32` repetition 1
  (count-race). It is made of 0.736 s of the whole-second floor, 0.662 s
  from issue to consumption and 0.238 s from consumption to the dispatch
  intent. That repetition was the first one of the race-instrumented process
  at 100 % machine CPU; its calls took up to 3.3 s. No dispatch came within
  28 s of its deadline: `below_28s` is 0 in every run.
- There were 0 lease expiries.
- No capability was consumed without a dispatch intent.

**Evidence, with keys and head pinned** (the harness, in process; the
build-3 verifier code linked into `agentgate-eval`)
- 260/260 VERIFIED/ANCHORED with 0 failing checks.
- The seven check-based dimensions pass in 260/260.
- `head_fresh` and `run_complete` are `not_checked` in 260/260. This is the
  specified result for a pinned head: only a fetched signed witness run
  status can make them pass. The harness starts no witness.
- `missing` has exactly 2 entries in 260/260 (`missing_by_kind`: freshness
  1, issuer_only 1, unresolved 0, other 0):
  - **freshness:** "Head not shown to be fresh";
  - **issuer_only:** the lost-response operation, executed only according to
    a RECONCILED entry without an adapter receipt
    (`issuer_only_reconciled`).

**Evidence, standalone verifier without anchors** (frozen
`agentgate-verify --json --workers 1`)
- 260/260 VERIFIED/CONSISTENT with exit 0.
- 34 checks per folder: 32 pass, and 2 warn (`head.anchor` and `keys.anchor`).
- Of the nine dimensions, 5 pass in 260/260. The other 4 are `not_checked`:
  `anchored_keys` and `anchored_head` (no anchors given), `head_fresh` and
  `run_complete` (they need a fetched witness status).
- `missing` has 3 entries in 260/260, with `missing_kinds` other, other,
  issuer_only: the two missing anchors and the lost-response operation.
- Classification evidence of the 10,740 operations:
  - 3,380 `issuer_adapter`, the operations executed with EFFECT_EXECUTED;
  - 260 `issuer_only_reconciled`, one per folder, all of them the
    lost-response operations (`counts.reconciled` = 1 per folder);
  - 7,100 `audit_only`, the denied and refused operations.
- `counts.flagged` is 0 in 260/260. `counts.flagged_unconfirmed` and
  `counts.unresolved` are absent in 260/260, which means 0 (the JSON fields
  are omitted when 0).
- All 41 totals that `verifier_fields.py` reports are equal to build 2's
  (`analysis/verifier_fields.json` against build 2's file).

**Evidence, standalone verifier on its pinned code path** (frozen
`agentgate-verify --json --workers 1 --expect-keys K --expect-head H`, pins
read from the folder; `build3_fields.py`)
- 260/260 VERIFIED/ANCHORED with exit 0; 34/34 checks pass, `keys.anchor`
  and `head.anchor` included.
- `missing_kinds` freshness, issuer_only in 260/260: the same two gaps the
  harness reports.
- `anchors.earlier_segments` is absent in 260/260: one segment, so no
  "keys anchored for the newest segment only" entry.
- `assumptions` has 5 entries in 260/260, the fifth "One clock".

**Other evidence results**
- **False alarms:** 0 in 1,560 verifications (§1 Totals).
- **Machine name:** it appears 0 times in all files of all 260 folders,
  journals included. "review-host" appears in every folder.
- **Windows user name:** 23 times in the raw folders (14 files). Every time
  it was by chance, inside a 64-character hex SHA-256 digest (`scan_names.py`
  classifies all 23 as `hex64`, 0 as text). No file in this repository folder
  contains the machine name, the user name or a local path. One four-letter
  term of the project's double-blind term list appears twice in this folder,
  by chance, inside one random base64url operation ID
  (`analysis/journal_operations.csv` and `n8/concurrency.json`).
- **Folder shape:** the same as builds 1 and 2. At N=8 there are 160 audit
  entries and 21 operations; at N=32, 484 and 69.
- **Record shape:** 77,240 audit entries in 14 (stage, detail keys) shapes
  and 36,820 journal records in 11 (kind, data keys) shapes
  (`analysis/record_shapes.tsv`). The totals equal build 2's; no entry or
  record carries a flag field, as in build 2.

**Unit tests** (`analysis/unit-tests.txt`) were run on the repository source
at HEAD after the last run (15:11:34-15:15:21 UTC). All 17 were ok.
- The 13 of build 2 (build 1's 10 and build 2's 3 replay-flag tests), with
  the same commands (`-race -count=20`, or `-count=5` for the verifier tests).
- Added for build 3's change on this path, with `-count=5` like the other
  verifier tests: `TestReconciledStatusDate`, `TestReconciledNeedsAReason`
  (its 14 subtests include "a concurrent retry reconciled first"),
  `TestPendingCapabilityIsIncomplete`, `TestCapabilityConfirmationKey`.
- A `-v` pass confirmed that all 17 tests exist and ran (45 subtests, all
  PASS).

## 3. Replay scope

`analysis/replay_scope.tsv` counts the 33,040 CALL_RESULT entries. The counts
are identical to builds 1 and 2:

| answer (audit summary) | status / reason | build 2: scope | build 3: scope |
|---|---|---|---|
| Call completed (the winning call) | COMMITTED | 3,380 `operation` | 3,380 `operation` |
| Reconciled with the provider | COMMITTED/reconciled | 260 `operation` | 260 `operation` |
| The provider's answer was lost | UNCERTAIN/provider_response_lost | 260 `operation` | 260 `operation` |
| Call denied by policy | REJECTED/policy_denied | 7,100 `operation` | 7,100 `operation` |
| Call refused during the operation check | REJECTED/operation_id_conflict | 6,820 `call` | 6,820 `call` |
| Repeated call (`replayed=true`) | COMMITTED | 11,020 `call` | 11,020 `call` |
| Repeated call (`replayed=true`) | COMMITTED/reconciled | 4,200 `call` | 4,200 `call` |

There are 0 repeats of a completed operation outside scope `call`
(`replay_scope.py` exits 0).

## 4. Build 3's verifier on this evidence

### 4.1 The new rules on genuine concurrent evidence

`build3_fields.py` read, on its own, what the new rules read
(`analysis/build3_fields.csv`, `analysis/build3_fields_reconciled.csv`):

| new rule | population | result |
|---|---|---|
| status date, upper bound (observed_at <= entry time + 5 s) | 260 RECONCILED entries, all `committed` and recording the effect | 260 / 260 within; entry time minus observed_at 0.018-1.020 s, so at least 5.018 s from the bound |
| status date, lower bound (observed_at >= capability iat - 5 s; `committed` only) | the same 260 | 260 / 260 within; observed_at equals iat in 244 and is 1 s later in 16, so at least 5 s from the bound |
| status order: a reason to reconcile after the capability | the same 260 | 260 / 260 have reason (a): the failed call's EFFECT_FAILED UNCERTAIN and its CALL_RESULT UNCERTAIN (scope `operation`, another call ID) are logged before the RECONCILED entry. Reason (b), another call's unresolved answer logged after it, occurred 0 times; reason (c), a restart, cannot occur (one segment) |
| pending with a capability | 10,740 operations | 0: every latest capability is followed by an outcome |
| capability `cnf` | 3,640 capabilities | 3,640 / 3,640 name the adapter key of the role their audience implies |

The verifier agrees: no check fails in any of the 1,560 verifications, and
`op.outcome_resolved`, `op.capability_bound` and `provider.matches_audit`
pass in every frozen standalone run whose check statuses were recorded
(`verifier_fields.py`, `build3_fields.py`, `compare_verifiers.py`: 780 runs;
`analyze.py` records failing checks only). Its detail text for
`op.outcome_resolved` reads, for example, "All 56 reported call statuses and
reconciliations agree with the recorded evidence" (N=8).

The whole-second `observed_at` and one machine clock make these margins
structural here: the provider signs its status right after the dispatch, in
the second the capability was issued or the next. The margins say nothing
about separate hosts (the "One clock" assumption).

### 4.2 Build-3 verifier against build-2 verifier on the same folders

`compare_verifiers.py` ran both verifiers, without anchors, on the 260
build-3 folders (`analysis/compare_verifiers.{csv,json}`):
- both give VERIFIED/CONSISTENT with exit 0 in 260/260;
- the reports differ in exactly one field, in 260/260: `assumptions`. The
  build-2 verifier lists 4 assumptions, the build-3 verifier the same 4 plus
  "One clock";
- every other field is identical in 260/260: verdict, assurance, format, the
  nine dimensions, all 34 check IDs with status and detail text, `missing`,
  `missing_kinds`, `counts`, `anchors`, warnings, failures and the full
  operations list.

So build 3's verifier changes nothing else in the report on this evidence:
the new rules hold silently, and every number in §2 that comes from the
verifier would be the same with build 2's verifier.

## 5. Comparison with build 2 (and build 1)

| headline number | build 2 (2026-10-10) | build 3 (this run) | why it differs |
|---|---|---|---|
| repetitions / scenario-repetitions / calls / operations | 260 / 1,820 / 33,040 / 10,740 | 260 / 1,820 / 33,040 / 10,740 | same method |
| harness invariant, safety, completion, consistency | 1,820 / 1,820 each | 1,820 / 1,820 each | - |
| journal transitions; gapless sequences | 10,740 / 10,740; 260 / 260 | 10,740 / 10,740; 260 / 260 | - |
| effects (independent = harness = dispatch intents) | 3,640 | 3,640 | - |
| EFFECT_EXECUTED / RECONCILED per receipt | 3,380 / 260 | 3,380 / 260 | - |
| delegation exact after each repetition | 260 / 260 | 260 / 260 | - |
| answer patterns per scenario and N | one each | the same one each | - |
| race detector reports | 0 in 60 repetitions | 0 in 60 repetitions | different race binary (`d3c919d3...` vs `10e450a9...`): new source, and build 3's reproducible flags (`-trimpath -buildvcs=false -ldflags=-buildid=`) |
| lease expiries | 0 / 3,640 | 0 / 3,640 | - |
| minimum slack to the lease deadline | 28,460.1 ms (n32) | 28,364.0 ms (race-n32) | load and scheduling: the first repetition of the race-instrumented process at 100 % CPU; 0.66 s from issue to consumption plus 0.74 s of the whole-second floor. Still more than 28 s from the deadline. Not a performance result |
| maximum consume-to-intent | 864.0 ms (n32) | 375.2 ms (race-n8) | load; not a performance result |
| cross-tool winner (payment / message) | 77 / 183 | 62 / 198 | the scheduler picks it. With GOMAXPROCS=1 the message won 19/20 and 30/30, the same as builds 1 and 2 |
| harness (pinned) verdict, dimensions | 260 / 260 VERIFIED/ANCHORED; 7 check-based pass; `head_fresh`, `run_complete` `not_checked` | the same | - |
| harness `missing` | 2 entries in 260 / 260 (freshness 1, issuer_only 1) | the same | - |
| CLI (no anchors) verdict and checks | 260 / 260 CONSISTENT, exit 0; 34 checks: 32 pass, 2 warn | the same | build 3 added no check ID |
| CLI `missing` | 3 (two anchors, kind `other`; one `issuer_only`) | the same | - |
| classification evidence (10,740 operations) | 3,380 `issuer_adapter`, 260 `issuer_only_reconciled`, 7,100 `audit_only` | the same | - |
| flagged operations; flagged but unconfirmed | 0; 0 | 0; 0 | no request fires a flag rule |
| `verifier_fields.py` totals | 41 totals | all 41 equal | - |
| assumptions in the report | 4 (not reported) | 5, the fifth "One clock" | new code: build 3's status-date rule assumes one clock (§4.2) |
| RECONCILED entries passing the status-date and status-order rules | (rules did not exist) | 260 / 260; margins at least 5 s; reason (a) 260, reason (b) 0 | new rule, new measurement (§4.1) |
| capabilities passing the cnf rule | (rule did not exist) | 3,640 / 3,640 | new rule, new measurement |
| operations pending with a capability | (not reported) | 0 / 10,740 | new rule; nothing to report here |
| CLI on its pinned code path | (not run) | 260 / 260 ANCHORED, 34/34 pass, the harness's 2 gaps, no earlier segments | new measurement (pins read from the folder, not an anchor) |
| cross-build verifier check | build-2 verifier on build 1's 260 folders: identical in every field it reads | build-2-source verifier on build 3's 260 folders: identical except `assumptions` | changed method: build 2's raw folders no longer exist, so the check runs the other way |
| repeated answers with scope `call` | 15,220 / 15,220 | 15,220 / 15,220 | - |
| folder shape; audit entries / journal records | 160/21 and 484/69; 77,240 / 36,820 | the same; 77,240 / 36,820 (14 and 11 shapes, now in a file) | - |
| machine name in the evidence | 0 | 0 | - |
| user name in raw folders (all inside hex digests) | 11 in 6 files | 23 in 14 files | chance: the user name is a valid hex string, and the digests are random per run |
| verifications | 780 (+260 of build 1's folders) | 1,560 | new cross-checks (§1 Totals) |
| unit tests | 13, all ok | the same 13 ok, plus 4 build-3 verifier tests ok | build 3 added tests for its change on this path |
| median machine CPU per run | 47.5-100 % | 95.0-100 % | other runners; not a result |
| slowest call | 7.1 s (n32, count-race) | 3.3 s (race-n32 repetition 1, budget-race, REJECTED/policy_denied) | load; not a result |
| wall time of the seven runs | 14 min 40 s | 14 min 4 s | load; not a result |

## 6. Caveats

- **Loaded, shared machine.** Other build-3 experiment runners were working
  at the same time, so no elapsed time here is a performance result.
  - Median CPU per run was 95.0-100 %.
  - Up to 3 `agentgate-eval` processes (this run's included), 9 other
    agentgate processes and 9 Go toolchain processes ran at once (none of the
    toolchain processes was this experiment's during the runs: its race build
    ended before the first run).
  - The details are in `analysis/runs.tsv` and `analysis/cpu-samples.tsv`.
- **Scope.** One process, one tenant and one principal, a loopback provider on
  one machine. Invariants that held here are not a proof for all
  interleavings.
- **Same-ID calls do not truly race.** The per-operation lock
  (`lockOperation`) serializes them, and PRE reservations run under the global
  `ledgerOrder` lock. "At most one effect" under simultaneous retries comes
  from that mutual exclusion.
- **Only one of the order rule's reasons was exercised.** In all 260
  lost-response operations the failed call's answer was logged before the
  retry reconciled (reason (a)). Reason (b), a concurrent retry reconciling
  before the failed call's answer is written, did not occur; it is covered
  only by `TestReconciledNeedsAReason`.
- **One clock.** The status-date margins (at least 5 s) hold on one machine
  by construction; components on separate hosts are not tested.
- **Not exercised here:** build 3's earlier-segment keys rule, witness
  continuation linkage, witness enrollment and run status v2 (no witness, one
  segment per folder), and the pending-with-capability report (no such
  operation). Build 3's 150 refusal sites are measured by the robustness
  experiment, not here.
- **No flagged operation.** The harness runs in flag mode, but no request
  fires a flag rule. The flag on replayed and stored COMMITTED answers is
  covered only by the unit tests.
- **`issuer_only` is a reported gap, not a failure.** The lost-response
  operation is classified `issuer_only_reconciled` in every folder, as in
  build 2.
- **Freshness.** ANCHORED with a pinned head is not "complete latest run".
  `run_complete` stays `not_checked` without a fetched witness status.
- **The pinned CLI run is not an anchor.** Its pins come from the folder it
  checks; it shows only that the CLI's pinned path agrees with the harness.
- **Cross-build check.** It used `agentgate-verify` rebuilt from build 2's
  source (all 256 module files checked), not build 2's binary, and it ran on
  build 3's folders, not on build 2's (they no longer exist).
- **Race build.** It is not one of the six frozen binaries. It was built from
  the verified source of HEAD (§1) and has its own hash.
- **Untested:** reuse of an ID across principals; races during a restart; two
  calls presenting one capability to the dispatch path (unit tests only);
  flagged operations under concurrency.

## 7. Open issues (eval-engine, unchanged since build 1)

The file `cmd/agentgate-eval/concurrency.go` has not changed (`53667d0b...`).
- **`assessRace` counts an expired lease as a violation.** None happened
  here: 0 answers and 0 operations recorded with that reason;
  `harness_violation_explained_by_lease_expiry_only` 0 and
  `harness_violation_with_safety_breach` 0.
- **`assessRace` mixes safety and completion.** The analysis script separates
  them.
- **Call start times are not recorded.**

## 8. Files

- `<run>/concurrency.{json,csv,md}`: the harness output of the seven runs.
- `build-manifest.txt`:
  - the frozen binary hashes and the manifest hash;
  - git HEAD and status;
  - the race build's command, hash, source check and `go version -m`
    difference;
  - the build-2-source verifier's command, hash and source check;
  - the four manifest checks with timestamps;
  - the module files changed since build 2;
  - the module source hashes.
- `analysis/`:
  - `analyze.py` (byte-identical to build 2's), `summary.json`,
    `scenario_repetitions.csv` (1,820 rows), `journal_operations.csv`
    (10,740 rows), `evidence.csv` (260 rows);
  - `aggregate.py`, which prints the totals quoted above;
  - `replay_scope.py` (byte-identical) and `replay_scope.tsv`;
  - `verifier_fields.py` (byte-identical), `verifier_fields.csv` (260 rows)
    and `verifier_fields.json`;
  - `build3_fields.py` (new), `build3_fields.csv` (260 rows),
    `build3_fields_reconciled.csv` (260 rows) and `build3_fields.json`;
  - `compare_verifiers.py` (new), `compare_verifiers.csv` (260 rows) and
    `compare_verifiers.json`;
  - `record_shapes.py` (new) and `record_shapes.tsv`;
  - `scan_names.py` (new);
  - `run_all.sh`, `analysis_all.sh`, `sampler.ps1`, `join_cpu.py`,
    `runs.tsv` (times, exit codes, race reports, CPU) and `cpu-samples.tsv`;
  - `unit_tests.sh` and `unit-tests.txt`;
  - `write_manifest.py`;
  - `logs/`: the harness console output of each run.

The evidence folders (about 172 MB) stay outside the repository, in
`<work>/concurrency/work/`, together with:
- the race binary and the build-2-source verifier, with their staged sources;
- the raw manifest-check outputs and the raw unit-test output;
- the raw outputs of `aggregate.py`, `replay_scope.py`,
  `verifier_fields.py`, `build3_fields.py`, `compare_verifiers.py` and
  `scan_names.py`.

Total time for this experiment, from the first manifest check to the end of
the analysis, unit tests and write-up: 14:53:25-15:21 UTC (about 28 min).
The seven harness runs took 14 min 4 s; the analysis (15:11:27-15:13:40) and
the unit tests (15:11:34-15:15:21) ran side by side.
