#!/usr/bin/env bash
# Analysis of the build-3 concurrency rerun, in the order it was run (after run_all.sh; new in build 3 as one script,
# build 2 ran the same steps by hand). MACHINE and USER are the machine name and the Windows user name, given at run time
# and never written to the repository.
set -u
REPO="<repo>"
F="<work>/concurrency"
FROZEN="<singlebuild3>/bin"
O="$REPO/docs/paper/data/build3/concurrency"
A="$O/analysis"
MACHINE="$1"
USER_NAME="$2"
V="n8 n32 replicate-n8 gomaxprocs1-n8 race-n8 race-n32 gomaxprocs1-n32"
cd "$REPO" || exit 1
mkdir -p "$F/raw" "$A/logs"
specs_analyze=""; specs_fields=""
for v in $V; do
  specs_analyze="$specs_analyze $v=$O/$v::$F/work/$v"
  specs_fields="$specs_fields build3=$O/$v::$F/work/$v::$v"
done
# 1) build 1/2 analysis (byte-identical scripts), frozen verifier, no anchors
py "$A/analyze.py" "$A" "$FROZEN/agentgate-verify.exe" "$MACHINE" review-host $specs_analyze 2> "$F/raw/analyze.stderr"
py "$A/aggregate.py" "$A/summary.json" "$A/journal_operations.csv" > "$F/raw/aggregate.txt"
py "$A/replay_scope.py" "$A/replay_scope.tsv" "frozen-build3=$F/work" > "$F/raw/replay_scope.txt"; echo "replay_scope rc=$?" >> "$F/raw/replay_scope.txt"
py "$A/verifier_fields.py" "$A/verifier_fields" "$FROZEN/agentgate-verify.exe" $specs_fields > "$F/raw/verifier_fields.txt" 2>&1
# 2) new in build 3
py "$A/build3_fields.py" "$A/build3_fields" "$FROZEN/agentgate-verify.exe" $specs_fields > "$F/raw/build3_fields.txt" 2>&1
py "$A/compare_verifiers.py" "$A/compare_verifiers" "$FROZEN/agentgate-verify.exe" "$F/agentgate-verify-build2src.exe" $specs_fields > "$F/raw/compare_verifiers.txt" 2>&1
py "$A/join_cpu.py" "$F/runs.tsv" "$F/cpu-samples.tsv" "$A/runs.tsv" > /dev/null
cp "$F/cpu-samples.tsv" "$A/cpu-samples.tsv"
for v in $V; do cp "$F/logs/$v.log" "$A/logs/$v.log"; done
py "$A/scan_names.py" "$MACHINE" "$USER_NAME" "$F/work" > "$F/raw/scan_work.txt"; echo "rc=$?" >> "$F/raw/scan_work.txt"
echo ANALYSIS-DONE
