"""Build-3 verifier rules on the concurrency evidence (new in the build-3 rerun).

analyze.py and verifier_fields.py are byte-identical to build 2's. Build 3
changed only the verifier on this code path (docs/demo/VERIFIER_CHECKS.md,
"build 3"; no check ID was added):
  - op.outcome_resolved dates the provider's status observation of a
    RECONCILED entry (observed_at <= entry time + 5 s; for `committed` also
    observed_at >= capability iat - 5 s) and requires a reason to reconcile
    a RECONCILED `committed` entry that records the effect: (a) an
    unresolved state of the operation logged before it (CALL_RESULT of scope
    `operation` or none reporting UNCERTAIN / RECONCILIATION_REQUIRED, or an
    EFFECT_FAILED reporting UNCERTAIN), (b) such a CALL_RESULT of another
    call logged after it, (c) a restart between capability and entry; an
    unresolved CALL_RESULT with the same non-empty call_id as the RECONCILED
    entry never counts;
  - an operation that holds a verified capability and no outcome is reported
    incomplete (pending; warning, Missing kind `unresolved`, run_complete not
    pass, counts.unresolved);
  - op.capability_bound compares the capability's confirmation key (cnf)
    with the adapter key;
  - the report lists a fifth assumption ("One clock").
This script measures, per evidence folder and independently of the verifier
(its own reading of audit.jsonl and keys.json), what the new rules read:
  - every RECONCILED entry: outcome, the margins of the status-date rule in
    seconds (upper: entry time + 5 - observed_at; lower, committed only:
    observed_at - (iat - 5)), and which reasons to reconcile (a)/(b) are
    present (c is impossible: one segment);
  - operations whose latest CAPABILITY_ISSUED is followed by no outcome
    (EFFECT_EXECUTED, EFFECT_FAILED, RECONCILED);
  - every CAPABILITY_ISSUED: whether confirmation_kid names a key of
    keys.json with the adapter role its audience implies;
and, from the frozen verifier CLI run on the pinned code path
(VERIFY_EXE --json --workers 1 --expect-keys K --expect-head H RUN_DIR; the
harness does not store its in-memory pins in concurrency.json, so K is the
SHA-256 of the folder's keys.json computed here and H is head.json's
entry_hash: this exercises the CLI's pinned path and its build-3 keys.anchor
rule for a run of one segment, it is NOT an independent anchor):
verdict, assurance, exit, check counts, the statuses and details of
op.outcome_resolved and op.capability_bound, Missing kinds, counts.unresolved,
the assumptions, the build-3 anchors fields and the operation statuses.

Usage: python build3_fields.py OUT_PREFIX VERIFY_EXE LABEL=OUT_DIR::WORK_DIR::VARIANT [...]
  Writes OUT_PREFIX.csv (one row per folder), OUT_PREFIX_reconciled.csv (one row
  per RECONCILED entry) and OUT_PREFIX.json (totals per label).
"""
import collections
import csv
import datetime
import hashlib
import json
import os
import subprocess
import sys

TOL = 5
AUDIENCE_ROLE = {
    'urn:agentgate:adapter:financial-request:v1': 'ADAPTER_FINANCIAL',
    'urn:agentgate:adapter:external-message:v1': 'ADAPTER_MESSAGE',
    'urn:agentgate:adapter:document-release:v1': 'ADAPTER_DOCUMENT',
}
OUTCOME_STAGES = ('EFFECT_EXECUTED', 'EFFECT_FAILED', 'RECONCILED')
UNRESOLVED = ('UNCERTAIN', 'RECONCILIATION_REQUIRED')


def ts(s):
    s = s.rstrip('Z')
    main, _, frac = s.partition('.')
    t = datetime.datetime.strptime(main, '%Y-%m-%dT%H:%M:%S').replace(tzinfo=datetime.timezone.utc).timestamp()
    return t + (float('0.' + frac) if frac else 0.0)


def kv(counter):
    return ' '.join('%s=%s' % (k, counter[k]) for k in sorted(counter))


def audit_facts(run_dir):
    entries = [json.loads(line)['entry'] for line in open(os.path.join(run_dir, 'audit.jsonl'), encoding='utf-8')]
    keys = json.load(open(os.path.join(run_dir, 'keys.json'), encoding='utf-8'))['keys']
    roles = {k['kid']: k['role'] for k in keys}
    by_op = collections.defaultdict(list)
    for index, e in enumerate(entries):
        if e.get('operation_id'):
            by_op[e['operation_id']].append((index, e))
    cnf = collections.Counter()
    pending = 0
    reconciled = []
    for op, items in by_op.items():
        caps = [(i, e) for i, e in items if e['stage'] == 'CAPABILITY_ISSUED']
        for i, e in caps:
            d = e.get('details') or {}
            want = AUDIENCE_ROLE.get(d.get('audience'))
            got = roles.get(d.get('confirmation_kid'))
            cnf['cnf_matches_adapter_role' if want and got == want else 'cnf_mismatch(%s,%s)' % (want, got)] += 1
        if caps:
            last_cap = caps[-1][0]
            if not any(i > last_cap and e['stage'] in OUTCOME_STAGES for i, e in items):
                pending += 1
        for i, e in items:
            if e['stage'] != 'RECONCILED':
                continue
            d = e.get('details') or {}
            status = str(d.get('provider_status', '')).upper()
            outcome = 'committed' if status == 'APPLIED' else ('not_committed' if status == 'ABSENT' else status)
            cap_before = [(ci, ce) for ci, ce in caps if ci < i]
            iat = (cap_before[-1][1].get('details') or {}).get('issued_at') if cap_before else None
            cap_index = cap_before[-1][0] if cap_before else -1
            obs = d.get('observed_at')
            rec_t = ts(e['time'])
            upper = None if obs is None else rec_t + TOL - obs
            lower = None if (obs is None or iat is None or outcome != 'committed') else obs - (iat - TOL)
            call = d.get('call_id') or ''
            reason_a = reason_b = False
            for j, x in items:
                xd = x.get('details') or {}
                if x['stage'] == 'EFFECT_FAILED' and cap_index < j < i and \
                        (str(xd.get('outcome', '')).lower() == 'uncertain' or xd.get('status') == 'UNCERTAIN'):
                    reason_a = True
                if x['stage'] == 'CALL_RESULT' and xd.get('scope') in (None, '', 'operation') and xd.get('status') in UNRESOLVED:
                    other = (xd.get('call_id') or '') != call or not call
                    if cap_index < j < i and other:
                        reason_a = True
                    if j > i and (xd.get('call_id') or '') and (xd.get('call_id') or '') != call:
                        reason_b = True
            executed_before = any(x['stage'] == 'EFFECT_EXECUTED' and j < i for j, x in items)
            reconciled.append({'operation_id': op, 'outcome': outcome, 'records_effect': not executed_before,
                               'observed_at': obs, 'entry_time': e['time'], 'capability_iat': iat,
                               'observed_minus_iat_s': None if (obs is None or iat is None) else obs - iat,
                               'entry_minus_observed_s': None if obs is None else round(rec_t - obs, 6),
                               'upper_margin_s': None if upper is None else round(upper, 6),
                               'lower_margin_s': None if lower is None else round(lower, 6),
                               'reason_a': reason_a, 'reason_b': reason_b})
    return cnf, pending, reconciled, len(entries)


def main():
    prefix, verify_exe = sys.argv[1:3]
    rows, rec_rows = [], []
    totals = collections.defaultdict(collections.Counter)
    margins = collections.defaultdict(lambda: collections.defaultdict(list))
    for spec in sys.argv[3:]:
        label, _, rest = spec.partition('=')
        out_dir, work_dir, variant = rest.split('::')
        d = json.load(open(os.path.join(out_dir, 'concurrency.json'), encoding='utf-8'))
        for r in d['repetitions']:
            rep = r['repeat']
            run_dir = os.path.join(work_dir, 'concurrency-r%02d' % rep, 'run')
            t = totals[label]
            t['folders'] += 1
            cnf, pending, reconciled, n_entries = audit_facts(run_dir)
            for k, v in cnf.items():
                t['capabilities ' + k] += v
            t['operations pending with a capability (own reading)=%d' % pending] += 1
            t['reconciled entries per folder=%d' % len(reconciled)] += 1
            for x in reconciled:
                t['reconciled outcome=%s records_effect=%s' % (x['outcome'], x['records_effect'])] += 1
                t['reconciled reasons a=%s b=%s' % (x['reason_a'], x['reason_b'])] += 1
                for key in ('upper_margin_s', 'lower_margin_s', 'observed_minus_iat_s', 'entry_minus_observed_s'):
                    if x[key] is not None:
                        margins[label][key].append(x[key])
                rec_rows.append([label, variant, d['simultaneous_calls'], rep, x['operation_id'], x['outcome'], x['records_effect'],
                                 x['observed_at'], x['entry_time'], x['capability_iat'], x['observed_minus_iat_s'],
                                 x['entry_minus_observed_s'], x['upper_margin_s'], x['lower_margin_s'], x['reason_a'], x['reason_b']])
            keys_pin = hashlib.sha256(open(os.path.join(run_dir, 'keys.json'), 'rb').read()).hexdigest()
            head_pin = json.load(open(os.path.join(run_dir, 'head.json'), encoding='utf-8')).get('entry_hash')
            args = [verify_exe, '--json', '--workers', '1']
            if keys_pin:
                args += ['--expect-keys', keys_pin]
            if head_pin:
                args += ['--expect-head', head_pin]
            proc = subprocess.run(args + [run_dir], capture_output=True)
            cli = json.loads(proc.stdout.decode('utf-8')) if proc.stdout else {}
            checks = {c['id']: c for c in cli.get('checks', [])}
            status = collections.Counter(c.get('status') for c in cli.get('checks', []))
            counts = cli.get('counts') or {}
            anchors = cli.get('anchors') or {}
            assumptions = cli.get('assumptions') or []
            opstat = collections.Counter(o.get('status') for o in cli.get('operations') or [])
            pins = 'keys+head' if keys_pin and head_pin else ('keys' if keys_pin else ('head' if head_pin else 'none'))
            t['cli pins=%s' % pins] += 1
            t['cli %s/%s exit=%d' % (cli.get('verdict'), cli.get('assurance'), proc.returncode)] += 1
            t['cli checks %s' % kv(status)] += 1
            for cid in ('op.outcome_resolved', 'op.capability_bound', 'keys.anchor', 'head.anchor', 'provider.matches_audit'):
                c = checks.get(cid) or {}
                t['cli %s=%s' % (cid, c.get('status', 'absent'))] += 1
            t['cli missing_kinds %s' % ' '.join(cli.get('missing_kinds') or [])] += 1
            t['cli counts.unresolved=%s' % counts.get('unresolved', 'absent')] += 1
            t['cli assumptions=%d one_clock=%s' % (len(assumptions), any(a.startswith('One clock') for a in assumptions))] += 1
            t['cli anchors.earlier_segments=%s earlier_keys_anchored=%s' % (anchors.get('earlier_segments', 'absent'), anchors.get('earlier_keys_anchored', 'absent'))] += 1
            t['cli anchors.keys_match=%s head_match=%s' % (anchors.get('keys_match'), anchors.get('head_match'))] += 1
            t['cli operation statuses %s' % kv(opstat)] += 1
            t['cli dims head_fresh=%s run_complete=%s anchored_keys=%s anchored_head=%s' % tuple(
                ((cli.get('dimensions') or {}).get(k) or {}).get('status') for k in ('head_fresh', 'run_complete', 'anchored_keys', 'anchored_head'))] += 1
            rows.append([label, variant, d['simultaneous_calls'], rep, n_entries, pins, cli.get('verdict'), cli.get('assurance'), proc.returncode,
                         sum(status.values()), status.get('pass', 0), status.get('warn', 0), status.get('fail', 0),
                         (checks.get('op.outcome_resolved') or {}).get('status'), (checks.get('op.outcome_resolved') or {}).get('detail'),
                         (checks.get('op.capability_bound') or {}).get('status'), (checks.get('op.capability_bound') or {}).get('detail'),
                         ' '.join(cli.get('missing_kinds') or []), counts.get('unresolved', 'absent'), len(assumptions),
                         anchors.get('earlier_segments', 'absent'), kv(opstat), kv(cnf), pending, len(reconciled)])
        print('checked', label, variant, file=sys.stderr)
    with open(prefix + '.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['label', 'variant', 'n', 'repeat', 'entries', 'cli_pins', 'cli_verdict', 'cli_assurance', 'cli_exit', 'cli_checks',
                    'cli_pass', 'cli_warn', 'cli_fail', 'outcome_resolved_status', 'outcome_resolved_detail', 'capability_bound_status',
                    'capability_bound_detail', 'cli_missing_kinds', 'cli_counts_unresolved', 'cli_assumptions', 'cli_earlier_segments',
                    'cli_operation_statuses', 'capability_cnf_own_reading', 'pending_with_capability_own_reading', 'reconciled_entries'])
        w.writerows(rows)
    with open(prefix + '_reconciled.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['label', 'variant', 'n', 'repeat', 'operation_id', 'outcome', 'records_effect', 'observed_at', 'entry_time',
                    'capability_iat', 'observed_minus_iat_s', 'entry_minus_observed_s', 'upper_margin_s', 'lower_margin_s',
                    'reason_a_unresolved_before', 'reason_b_other_call_unresolved_after'])
        w.writerows(rec_rows)
    summary = {}
    for label, t in totals.items():
        m = {k: {'n': len(v), 'min': min(v), 'max': max(v)} for k, v in margins[label].items()}
        summary[label] = {'totals': dict(sorted(t.items())), 'margins_s': m}
    json.dump({'method': __doc__, 'labels': summary}, open(prefix + '.json', 'w', encoding='utf-8'), indent=1)
    for label, s in summary.items():
        print('==', label)
        for k, v in s['totals'].items():
            print('  %6d  %s' % (v, k))
        for k, v in s['margins_s'].items():
            print('  margin', k, v)


if __name__ == '__main__':
    main()
