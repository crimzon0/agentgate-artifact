"""Build-3 verifier against the build-2 verifier on the same build-3 folders (new in the build-3 rerun).

Build 2 attributed its verifier differences by running the new verifier on
the previous build's folders. Build 2's evidence folders were kept in a
temporary folder that no longer exists, so this rerun does the converse:
both verifiers read the same build-3 folder, without anchors
(VERIFY --json --workers 1 RUN_DIR):
  NEW  the frozen build-3 agentgate-verify;
  OLD  agentgate-verify rebuilt from the source of commit 86643d7 (build 2;
       every module file checked against build 2's build-manifest.txt). It is
       not build 2's binary; only the source is the same.
Since the gateway, adapters, simulator and harness are byte-identical between
the builds, any difference between the two reports is the verifier's.
Per folder it compares: exit code, verdict, assurance, format, the nine
dimensions, the check IDs with status and detail text, missing, missing_kinds,
assumptions, counts, anchors, warnings, failures, and the operations list
(status, classification_evidence, flagged). It prints the fields that differ
and how often.

Usage: python compare_verifiers.py OUT_PREFIX NEW_VERIFY OLD_VERIFY LABEL=OUT_DIR::WORK_DIR::VARIANT [...]
  Writes OUT_PREFIX.csv (one row per folder) and OUT_PREFIX.json (difference census and examples).
"""
import collections
import csv
import json
import os
import subprocess
import sys

SKIP = {'checked_at', 'dir'}


def run(exe, run_dir):
    p = subprocess.run([exe, '--json', '--workers', '1', run_dir], capture_output=True)
    return p.returncode, (json.loads(p.stdout.decode('utf-8')) if p.stdout else {})


def flat(report):
    out = {}
    for k, v in report.items():
        if k in SKIP:
            continue
        if k == 'checks':
            for c in v:
                out['check %s status' % c['id']] = c.get('status')
                out['check %s detail' % c['id']] = c.get('detail')
            out['check ids'] = ' '.join(c['id'] for c in v)
        elif k == 'operations':
            out['operations'] = json.dumps([[o.get('operation_id'), o.get('status'), o.get('classification_evidence'), o.get('flagged')]
                                            for o in v])
            out['operations full'] = json.dumps(v, sort_keys=True)
        elif k == 'dimensions':
            for d, x in (v or {}).items():
                out['dimension %s' % d] = json.dumps(x, sort_keys=True)
        elif k == 'counts':
            for d, x in (v or {}).items():
                out['counts.%s' % d] = json.dumps(x, sort_keys=True)
        elif k == 'anchors':
            for d, x in (v or {}).items():
                out['anchors.%s' % d] = json.dumps(x, sort_keys=True)
        else:
            out[k] = json.dumps(v, sort_keys=True)
    return out


def main():
    prefix, new_exe, old_exe = sys.argv[1:4]
    rows = []
    census = collections.Counter()
    examples = {}
    totals = collections.Counter()
    for spec in sys.argv[4:]:
        label, _, rest = spec.partition('=')
        out_dir, work_dir, variant = rest.split('::')
        d = json.load(open(os.path.join(out_dir, 'concurrency.json'), encoding='utf-8'))
        for r in d['repetitions']:
            rep = r['repeat']
            run_dir = os.path.join(work_dir, 'concurrency-r%02d' % rep, 'run')
            ne, new = run(new_exe, run_dir)
            oe, old = run(old_exe, run_dir)
            fn, fo = flat(new), flat(old)
            fn['exit'], fo['exit'] = str(ne), str(oe)
            diff = sorted(k for k in set(fn) | set(fo) if fn.get(k) != fo.get(k))
            totals['folders'] += 1
            totals['identical reports (except checked_at, dir)'] += not diff
            totals['new %s/%s exit=%d' % (new.get('verdict'), new.get('assurance'), ne)] += 1
            totals['old %s/%s exit=%d' % (old.get('verdict'), old.get('assurance'), oe)] += 1
            for k in diff:
                census[k] += 1
                if k not in examples:
                    examples[k] = {'variant': variant, 'repeat': rep, 'old': fo.get(k), 'new': fn.get(k)}
            rows.append([label, variant, d['simultaneous_calls'], rep, ne, oe, new.get('verdict'), old.get('verdict'),
                         new.get('assurance'), old.get('assurance'), len(diff), ' | '.join(diff)])
        print('compared', label, variant, file=sys.stderr)
    with open(prefix + '.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['label', 'variant', 'n', 'repeat', 'new_exit', 'old_exit', 'new_verdict', 'old_verdict', 'new_assurance',
                    'old_assurance', 'differing_fields', 'fields'])
        w.writerows(rows)
    json.dump({'method': __doc__, 'totals': dict(totals), 'differing_fields': dict(census.most_common()), 'first_example': examples},
              open(prefix + '.json', 'w', encoding='utf-8'), indent=1)
    for k, v in sorted(totals.items()):
        print('  %6d  %s' % (v, k))
    for k, v in census.most_common():
        print('  DIFF %6d  %s' % (v, k))
        ex = examples[k]
        print('        old:', str(ex['old'])[:400])
        print('        new:', str(ex['new'])[:400])


if __name__ == '__main__':
    main()
