"""Record shapes of the concurrency evidence (new in the build-3 rerun; build 2 compared shapes by hand and kept no file).

Counts, over every evidence folder of WORK_ROOT/<variant>/concurrency-rNN/,
the audit entries (run/audit.jsonl) by (stage, sorted detail keys) and the
operation-journal records (operations.jsonl) by (kind, sorted data keys), and
the entries and operations per folder by N. Writes OUT_TSV with one row per
shape, so a later build can be compared file to file.

Usage: python record_shapes.py OUT_TSV WORK_ROOT
"""
import collections
import glob
import json
import os
import sys

VARIANTS = ['n8', 'n32', 'replicate-n8', 'gomaxprocs1-n8', 'race-n8', 'race-n32', 'gomaxprocs1-n32']


def main():
    out, root = sys.argv[1:3]
    audit = collections.Counter()
    journal = collections.Counter()
    per_folder = collections.Counter()
    totals = collections.Counter()
    for v in VARIANTS:
        n = 32 if '32' in v else 8
        for folder in sorted(glob.glob(os.path.join(root, v, 'concurrency-r*'))):
            entries = 0
            ops = set()
            for line in open(os.path.join(folder, 'run', 'audit.jsonl'), encoding='utf-8'):
                e = json.loads(line)['entry']
                audit[(e['stage'], ','.join(sorted((e.get('details') or {}).keys())))] += 1
                entries += 1
                if e.get('operation_id'):
                    ops.add(e['operation_id'])
            records = 0
            for line in open(os.path.join(folder, 'operations.jsonl'), encoding='utf-8'):
                j = json.loads(line)
                journal[(j['kind'], ','.join(sorted((j.get('data') or {}).keys())))] += 1
                records += 1
            per_folder[(n, entries, len(ops))] += 1
            totals['folders'] += 1
            totals['audit entries'] += entries
            totals['journal records'] += records
    with open(out, 'w', encoding='utf-8', newline='') as f:
        f.write('record\ttype\tkeys\tcount\n')
        for (stage, keys), c in sorted(audit.items()):
            f.write('audit\t%s\t%s\t%d\n' % (stage, keys, c))
        for (kind, keys), c in sorted(journal.items()):
            f.write('journal\t%s\t%s\t%d\n' % (kind, keys, c))
    print(dict(totals))
    print('distinct audit shapes', len(audit), 'distinct journal shapes', len(journal))
    for (n, e, o), c in sorted(per_folder.items()):
        print('N=%d: %d folders with %d audit entries and %d operations' % (n, c, e, o))


if __name__ == '__main__':
    main()
