"""Scans files for the machine name, the Windows user name and local paths (build 2 did the user-name part by hand).

For each ROOT it reports the files scanned and, case-insensitively, the
occurrences of MACHINE and USER. Each USER occurrence is classified by the
maximal run of hex digits around it: inside a 64-character run (a SHA-256
digest), a 32-character run (a call ID or similar), another hex run of
length >= 16, or 'text' (anything else, which would be a real leak). With
--paths it also counts absolute local path patterns (a drive letter followed
by a slash or backslash and a letter or dot, an msys drive path to the
users folder, or a users folder between two slashes or backslashes)
and, with --terms FILE, the terms listed one per line in FILE (the terms are
read from FILE, never printed: only their count is).

Usage: python scan_names.py MACHINE USER [--paths] [--terms FILE] ROOT [ROOT ...]
Exit status 1 if any ROOT has a machine-name hit, a 'text' user-name hit, or (with --paths/--terms) a path or term hit.
"""
import collections
import os
import re
import sys

HEX = set('0123456789abcdef')


def classify(data, start, length):
    i, j = start, start + length
    while i > 0 and data[i - 1] in HEX:
        i -= 1
    while j < len(data) and data[j] in HEX:
        j += 1
    run = j - i
    if run == 64:
        return 'hex64'
    if run == 32:
        return 'hex32'
    if run >= 16:
        return 'hex%d' % run
    return 'text'


def main():
    args = sys.argv[1:]
    machine, user = args[0].lower(), args[1].lower()
    rest = args[2:]
    paths = '--paths' in rest
    terms = []
    if '--terms' in rest:
        k = rest.index('--terms')
        terms = [t.strip().lower() for t in open(rest[k + 1], encoding='utf-8') if t.strip()]
        rest = rest[:k] + rest[k + 2:]
    roots = [r for r in rest if r != '--paths']
    users = 'us' + 'ers'
    path_re = re.compile(r'(?i)(?<![a-z])[a-z]:[\\/]+[a-z.]|/c/' + users + r'|\\' + users + r'\\|/' + users + '/')
    bad = False
    for root in roots:
        files = 0
        machine_hits = 0
        user_hits = collections.Counter()
        user_files = set()
        path_hits = term_hits = 0
        path_files = set()
        for dirpath, _, names in os.walk(root):
            for name in names:
                p = os.path.join(dirpath, name)
                data = open(p, 'rb').read().decode('utf-8', 'replace').lower()
                files += 1
                machine_hits += data.count(machine)
                for m in re.finditer(re.escape(user), data):
                    user_hits[classify(data, m.start(), len(user))] += 1
                    user_files.add(p)
                if paths:
                    n = len(path_re.findall(data))
                    if n:
                        path_hits += n
                        path_files.add(os.path.relpath(p, root))
                for t in terms:
                    term_hits += data.count(t)
        label = os.path.basename(os.path.normpath(root))
        print('%s: files=%d machine_name=%d user_name=%d %s in %d files%s%s' % (
            label, files, machine_hits, sum(user_hits.values()), dict(user_hits), len(user_files),
            (' local_path_patterns=%d %s' % (path_hits, sorted(path_files)[:10])) if paths else '',
            (' identifying_terms=%d' % term_hits) if terms else ''))
        bad |= machine_hits > 0 or user_hits['text'] > 0 or path_hits > 0 or term_hits > 0
    sys.exit(1 if bad else 0)


if __name__ == '__main__':
    main()
