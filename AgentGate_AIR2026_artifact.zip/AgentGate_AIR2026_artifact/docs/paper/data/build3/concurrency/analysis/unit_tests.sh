#!/usr/bin/env bash
# Unit tests on the repository source at HEAD (commit 8a30fd4; git diff 8a30fd4 -- internal cmd go.mod go.sum is empty),
# same commands as build 2 (build 1's plus the build-2 replay-flag tests), plus the build-3 verifier tests on this path.
R="<repo>"   # <repo> and <msys64> (the msys64 installation, for cgo) stand for local folders in this copy
W="$1"
cd "$R" || exit 1
export PATH="<msys64>/ucrt64/bin:$PATH" GOMODCACHE="$R/.tools/go-host-cache-20260916/mod" GOPROXY=off GOFLAGS=-mod=readonly GOTOOLCHAIN=local CGO_ENABLED=1
GO=./.tools/go-1.26.6/bin/go.exe
out="$W/unit-tests.raw"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out"
run() { echo "## go test $*" >> "$out"; $GO test "$@" >> "$out" 2>&1; echo "rc=$?" >> "$out"; }
run -race -count=20 -run 'TestConcurrentConsumeBarrierCommitsExactlyOnce|TestIssueExactConcurrentBarrierAndOperationConflict' ./internal/capability/
run -race -count=20 -run 'TestMemoryOperationStoreConcurrentBeginAndEffectConflict' ./internal/controlpoint/
run -race -count=20 -run 'TestDelegationReservationsAreConsistentUnderConcurrency|TestConcurrentRetriesYieldOneEffect' ./internal/devcomposition/
run -race -count=20 -run 'TestConcurrentDuplicatesCommitExactlyOnce' ./internal/simulator/
run -race -count=20 -run 'TestConcurrentAppendsAreNumberedWithoutGaps' ./internal/opjournal/
run -race -count=20 -run 'TestConcurrentAppendsKeepValidChain' ./internal/audit/
run -count=5 -run 'TestDelegationAccountingDoesNotDependOnLogOrder' ./internal/auditverify/
run -race -count=20 -run '^(TestReplayedAnswersAreCallScoped)$' ./internal/devcomposition/
echo "## build-2 additions (the change on this code path: COMMITTED answers, replayed ones included, state the flag)" >> "$out"
run -race -count=20 -run '^(TestReplayedCommittedAnswersKeepTheFlag|TestNotCommittedAnswersStateNoFlag)$' ./internal/devcomposition/
run -count=5 -run '^(TestCallScopeReplayedAnswers)$' ./internal/auditverify/
echo "## build-3 additions (the change on this code path is in the verifier only: status date and order of RECONCILED, pending with a capability, capability cnf)" >> "$out"
run -count=5 -run '^(TestReconciledStatusDate|TestReconciledNeedsAReason|TestPendingCapabilityIsIncomplete|TestCapabilityConfirmationKey)$' ./internal/auditverify/
date -u +%Y-%m-%dT%H:%M:%SZ >> "$out"
v="$W/unit-tests-v.raw"
: > "$v"
for spec in "./internal/capability/ TestIssueExactConcurrentBarrierAndOperationConflict|TestConcurrentConsumeBarrierCommitsExactlyOnce" \
            "./internal/controlpoint/ TestMemoryOperationStoreConcurrentBeginAndEffectConflict" \
            "./internal/devcomposition/ TestDelegationReservationsAreConsistentUnderConcurrency|TestConcurrentRetriesYieldOneEffect|TestReplayedAnswersAreCallScoped|TestReplayedCommittedAnswersKeepTheFlag|TestNotCommittedAnswersStateNoFlag" \
            "./internal/simulator/ TestConcurrentDuplicatesCommitExactlyOnce" \
            "./internal/opjournal/ TestConcurrentAppendsAreNumberedWithoutGaps" \
            "./internal/audit/ TestConcurrentAppendsKeepValidChain" \
            "./internal/auditverify/ TestDelegationAccountingDoesNotDependOnLogOrder|TestCallScopeReplayedAnswers|TestReconciledStatusDate|TestReconciledNeedsAReason|TestPendingCapabilityIsIncomplete|TestCapabilityConfirmationKey"; do
  pkg=${spec%% *}; names=${spec#* }
  $GO test -count=1 -v -run "^($names)\$" "$pkg" >> "$v" 2>&1; echo "rc=$?" >> "$v"
done
date -u +%Y-%m-%dT%H:%M:%SZ >> "$out"
