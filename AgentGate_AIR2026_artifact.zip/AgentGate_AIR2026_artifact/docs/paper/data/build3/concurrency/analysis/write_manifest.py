"""Writes build-manifest.txt for the build-3 concurrency rerun (adapted from build 2's write_manifest.py).

usage: python write_manifest.py MANIFEST3 BUILD2_MANIFEST_TXT OUT RACE_INFO B2VERIFY_INFO GO_VERSION_M_DIFF_FILE GIT_STATUS_FILE CHECK_LINE...
  MANIFEST3            <singlebuild3>/MANIFEST.txt (build 3)
  BUILD2_MANIFEST_TXT  docs/paper/data/build2/concurrency/build-manifest.txt (lists build 2's 256 module files; build 2's own
                       MANIFEST.txt was in a temporary folder that no longer exists)
  RACE_INFO            "sha256|utc-start|utc-end|module files checked|module files differing"
  B2VERIFY_INFO        "sha256|utc-start|utc-end|module files checked|module files differing"
  CHECK_LINE           "label|utc-start|utc-end|output" lines of check_manifest.py, in order
No absolute local path is written: paths are given as <repo>, <work> (= <repo>/.tools/build3-work), <singlebuild3>.
"""
import hashlib
import re
import sys

manifest, prev, out, raceinfo, b2info, vdiff, gitstatus = sys.argv[1:8]
checks = sys.argv[8:]
text = open(manifest, encoding='utf-8').read()


def load(p):
    d = {}
    for line in open(p, encoding='utf-8'):
        m = re.match(r'^([0-9a-f]{64}) \*(.+)$', line.strip())
        if m:
            d[m.group(2)] = m.group(1)
    return d


new, old = load(manifest), load(prev)
mod = lambda d: {k: v for k, v in d.items() if not k.startswith('$') and not k.startswith('bin/')}
nm, om = mod(new), mod(old)
changed = sorted(k for k in set(nm) & set(om) if nm[k] != om[k])
added = sorted(set(nm) - set(om))
removed = sorted(set(om) - set(nm))
nt = {k: v for k, v in new.items() if k.startswith('$')}
bins = [l for l in text.splitlines() if re.match(r'^[0-9a-f]{64} \*bin/', l)]
module = sorted(('%s *%s' % (v, k) for k, v in nm.items()), key=lambda s: s.split('*', 1)[1])
written = re.search(r'^written: (\S+)', text, re.M).group(1)
rsha, rt0, rt1, rchecked, rdiff = raceinfo.split('|')
bsha, bt0, bt1, bchecked, bdiff = b2info.split('|')
path_files = ['cmd/agentgate-eval/concurrency.go', 'cmd/agentgate-eval/harness.go']
path_dirs = ('internal/devcomposition/', 'internal/capability/', 'internal/simulator/', 'internal/opjournal/', 'internal/audit/',
             'internal/controlpoint/', 'internal/adapters/')
on_path_changed = [k for k in changed if k in path_files or k.startswith(path_dirs)]
L = []
L.append('# Build manifest for the concurrency rerun on FROZEN BUILD 3 (2026-10-20 UTC)')
L.append('# The harness runs used ONLY the frozen binaries of <singlebuild3>/bin (manifest written %s by the build step,' % written)
L.append('# reproducible build of commit 8a30fd4 of branch claude/supervisor-demo from `git archive` + `go mod vendor`, flags')
L.append('# -trimpath -buildvcs=false -ldflags=-buildid=, CGO_ENABLED=0; byte-identical across two build folders); full manifest:')
L.append('#   <singlebuild3>/MANIFEST.txt, SHA-256 %s' % hashlib.sha256(open(manifest, 'rb').read()).hexdigest())
L.append('#   (%d entries: 6 binaries + %d compiled source/embedded files: %d module, %d third-party, %d stdlib)'
         % (len(new), len(new) - len(bins), len(nm), sum(1 for k in nt if k.startswith('$GOMODCACHE/')), sum(1 for k in nt if k.startswith('$GOROOT/'))))
L.append('# git rev-parse HEAD and git status --porcelain (research/ omitted) before the runs (the build3/ folder is this output and the')
L.append('# other build-3 experiments\' output); git diff 8a30fd4 --stat -- internal cmd go.mod go.sum: empty (no compiled file differs):')
for line in open(gitstatus, encoding='utf-8'):
    L.append('#   ' + line.rstrip())
L.append('# frozen binaries (sha256), checked against MANIFEST.txt before the first run:')
for l in bins:
    L.append('#   ' + l)
L.append('# used here: bin/agentgate-eval.exe (n8, n32, replicate-n8, gomaxprocs1-n8, gomaxprocs1-n32) and bin/agentgate-verify.exe')
L.append('#   (analysis CLI cross-checks on this run\'s folders: analyze.py, verifier_fields.py, build3_fields.py, compare_verifiers.py).')
L.append('# race build (race-n8, race-n32): the frozen set has no -race binary, so it was built from the source of HEAD (8a30fd4) after')
L.append('#   check_manifest.py reported 0 differences, %s-%s, with the frozen build\'s own recipe plus -race' % (rt0, rt1))
L.append('#   (git archive 8a30fd4 go.mod go.sum cmd internal; go mod vendor; GOFLAGS=-mod=vendor; CGO via msys64 ucrt64 gcc 15.2.0):')
L.append('#   CGO_ENABLED=1 go build -race -trimpath -buildvcs=false -ldflags=-buildid= -o <work>/concurrency/agentgate-eval-race.exe ./cmd/agentgate-eval/')
L.append('#   %s *agentgate-eval-race.exe' % rsha)
L.append('#   its staged source: %s module files of MANIFEST.txt re-hashed, %s differ' % (rchecked, rdiff))
L.append('#   go version -m of the race build against the frozen bin/agentgate-eval.exe (diff, paths replaced):')
for line in open(vdiff, encoding='utf-8'):
    L.append('#     ' + line.rstrip('\n'))
L.append('#   i.e. identical module path, dependencies and build settings, except "build -race=true" and CGO_ENABLED=1 (the race')
L.append('#   detector needs cgo). It also links runtime/race and runtime/cgo files that MANIFEST.txt does not list (not one of the six).')
L.append('# build-2 verifier, rebuilt for one cross-check only (build-2 verifier on build-3 folders; NOT a frozen binary, NOT build 2\'s')
L.append('#   binary 83d0786a..., whose folder no longer exists): git archive 86643d7 go.mod go.sum cmd internal; go mod vendor;')
L.append('#   GOFLAGS=-mod=vendor CGO_ENABLED=0 go build -trimpath -buildvcs=false -ldflags=-buildid= -o <work>/concurrency/agentgate-verify-build2src.exe ./cmd/agentgate-verify/')
L.append('#   %s-%s; %s *agentgate-verify-build2src.exe' % (bt0, bt1, bsha))
L.append('#   its staged source: %s module files listed in build 2\'s build-manifest.txt re-hashed, %s differ' % (bchecked, bdiff))
L.append('# check_manifest.py (re-hash of all %d MANIFEST entries: binaries, module, third-party, stdlib), py <singlebuild3>/check_manifest.py:' % len(new))
for c in checks:
    label, t0, t1, output = c.split('|', 3)
    L.append('#   %-34s %s .. %s: %s' % (label + ':', t0, t1, output))
L.append('# Changed against build 2 (module files listed in docs/paper/data/build2/concurrency/build-manifest.txt, %d files;' % len(om))
L.append('#   go.mod and go.sum are unchanged, git diff 86643d7 8a30fd4 -- go.mod go.sum is empty):')
L.append('#   changed (%d): %s' % (len(changed), ', '.join(changed)))
L.append('#   added (%d): %s' % (len(added), ', '.join(added) or '-'))
L.append('#   removed (%d): %s' % (len(removed), ', '.join(removed) or '-'))
L.append('#   On the concurrency code path: only the verifier changed (internal/auditverify/*, linked into agentgate-eval for the')
L.append('#   harness\'s pinned verification, and cmd/agentgate-verify/main.go, the standalone CLI). The other changed files are the')
L.append('#   witness enrollment and custody code (internal/headwitness, internal/demo/{custody,segment}.go, cmd/agentgate-eval/custody.go,')
L.append('#   cmd/agentgate-witness/main.go), which the concurrency subcommand never calls (concurrency.go imports devcomposition and')
L.append('#   effects; harness.go imports audit, auditverify, canon, devcomposition, effects, mcp, signed, simulator).')
L.append('#   cmd/agentgate-eval/{concurrency,harness}.go and internal/{devcomposition,capability,controlpoint,simulator,opjournal,audit,')
L.append('#   adapters}/ are byte-identical to build 2 (changed files on that list: %s).' % (', '.join(on_path_changed) or 'none'))
L.append('# agentgate module files compiled into the six frozen binaries (sha256, from MANIFEST.txt):')
L.extend(module)
open(out, 'w', encoding='utf-8', newline='\n').write('\n'.join(L) + '\n')
print(len(module), 'module entries;', len(changed), 'changed;', len(added), 'added;', len(removed), 'removed:', changed, added, removed,
      'on path:', on_path_changed)
