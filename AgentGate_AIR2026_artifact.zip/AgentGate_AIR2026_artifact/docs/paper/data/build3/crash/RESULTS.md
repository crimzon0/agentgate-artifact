# Crash, response loss and restart (R6.3), rerun on frozen build 3

Run 2026-10-20 14:52:36-14:55:18 UTC (flag mode) and 14:55:18-14:56:58 UTC
(deny mode) with **frozen build 3** (`agentgate-eval` `cc4b9613...768e`,
`agentgate-verify` `04038f9f...821a`, reproducible build of commit `8a30fd4`
of `claude/supervisor-demo`; `build-manifest.txt`). It repeats the build-2 run
of 2026-10-10 (`../../build2/crash/RESULTS.md`) with the same commands,
parameters, repetitions and analysis scripts. It is part of the paper revision
for the external review.

**Headline.** All build-2 results hold on build 3, number for number:

- 0 of 1,120 operations produced two provider effects (0 of 560 in deny).
- 0 of 480 REJECTED answers came while the provider held an effect (0 of 240).
- 0 of 1,120 COMMITTED answers had no provider effect (0 of 560).
- After one `Reconcile`, 0 of 1,120 operations were unresolved (0 of 560).
- **All 840 evidence folders are VERIFIED/ANCHORED (flag), and 420 of 420 in
  deny.** That includes the 280 second segments after a restart, which are
  walked together with segment 1 as one run (140 of 140 in deny).
- Every replayed answer is logged with scope `call` (240 of 240; 120 of 120).
- Every `call_id` ties to a later answer.

**Nothing in the harness output changed.** I compared all 560 schedules
(280 in deny) with build 2 after removing IDs and timings, with nothing
stripped and the verifier's Missing texts included: none differs, and the
totals are equal. The cell tables, folder tables, disk recount, `call_id`
counts, recovery-record counts, restart tamper probes and the CLI
cross-check columns shared with build 2 are byte-identical or row-identical
(§4).

**Why nothing changed.** Build 3 changed no gateway or harness code this
experiment uses: `crash.go`, `harness.go`, `common.go`, `internal/devcomposition`
and `internal/adapters` are the same as in build 2. What changed is the
verifier (`internal/auditverify`, `agentgate-verify`) and the witness. The
new verifier rules all ran on this evidence and **none fired** on the
genuine runs:

- **Status order (new):** all 480 RECONCILED-committed entries that record
  the effect (240 in deny) have a reason to reconcile. On the 240 restart
  segments (120 in deny) there are two reasons each: an unresolved answer
  logged in segment 1, and the restart between the capability and the
  entry. 0 entries had no reason.
- **Status date (new):** 0 of 640 RECONCILED entries (0 of 320) fall
  outside the 5 s bounds. The largest gaps are 1.0 s between the entry time
  and the provider's observation, and 2.0 s between the capability's `iat`
  and the observation (deny: 1.0 s and 1.0 s).
- **Capability `cnf` (new):** 1,680 of 1,680 capabilities (840 of 840) name
  the run's adapter key for their effect type, and `op.capability_bound`
  passed in every folder.
- **Pending with a capability (new):** no operation in this experiment is
  pending, so the classification counts and unresolved counts are build 2's.
- **Earlier-segment keys (new):** the harness pins keys and head. The head
  pin also anchors segment 1's keys, so all 280 segment-2 chains (140 in
  deny) report `earlier_keys_anchored_by: head_pin` and list no "Keys
  anchored for the newest segment only" entry. A new probe (§5.2) shows the
  rule at work on the same evidence. With only the newest keys pinned, all
  280 chains get the new warning. A pin of segment 1's genuine keys clears
  it in 280 of 280. Another run's segment-1 keys fail `keys.anchor` in 280
  of 280. Earlier pins given for a one-segment run fail in 280 of 280.
- **One-clock assumption (new):** every report lists it (1,680 of 1,680
  CLI runs; 840 of 840 in deny).

## 0. Comparison with build 2 (and build 1)

| headline number (flag run; deny in brackets) | build 1 (2026-10-08) | build 2 (2026-10-10) | build 3 (2026-10-20) | why it differs |
|---|---|---|---|---|
| more than one provider effect for one operation ID | 0 / 1,120 (0 / 560) | 0 / 1,120 (0 / 560) | **0 / 1,120 (0 / 560)** | same |
| REJECTED answered while the provider holds an effect | 0 / 480 (0 / 240) | 0 / 480 (0 / 240) | **0 / 480 (0 / 240)** | same; all `dispatched=false`: 240 `dispatch_refused`, 240 `aborted_before_send` (120 + 120) |
| COMMITTED answered with no provider effect | 0 / 1,120 (0 / 560) | 0 / 1,120 (0 / 560) | **0 / 1,120 (0 / 560)** | same |
| provider effect with no EFFECT_EXECUTED / RECONCILED(committed) | 0 / 1,360 (0 / 680) | 0 / 1,360 (0 / 680) | **0 / 1,360 (0 / 680)** | same |
| unresolved after the retry, then after one `Reconcile` | 320 then 0 / 1,120 | 320 then 0 / 1,120 (160 then 0 / 560) | **320 then 0 / 1,120 (160 then 0 / 560)** | same |
| same-ID retry of an unresolved operation: COMMITTED/reconciled, 0 new effects | 320 / 320 | 320 / 320 (160 / 160) | **320 / 320 (160 / 160)** | same |
| same content committed twice under a fresh ID (by design) | 400 / 1,120 | 400 / 1,120 (200 / 560) | **400 / 1,120 (200 / 560)** | same |
| replayed answers logged with scope `call` | 240 / 240 | 240 / 240 (120 / 120) | **240 / 240 (120 / 120)** | same; `call_ids.txt` byte-identical (flag and deny) |
| EFFECT_EXECUTED with `call_id` that a later CALL_RESULT answers | 880 / 880 | 880 / 880 (440 / 440) | **880 / 880 (440 / 440)** | same |
| RECONCILED (same-ID retry) with `call_id` that a later CALL_RESULT answers | 320 / 320 | 320 / 320 (160 / 160) | **320 / 320 (160 / 160)** | same; the 320 (160) RECONCILED written by `Reconcile` have no `call_id`, as specified |
| evidence folders VERIFIED/ANCHORED | 840 / 840 (420 / 420) | 840 / 840 (420 / 420) | **840 / 840 (420 / 420)** | same; 0 FAILED |
| restart segment 2, verified as a chain of 2 | 280 / 280 (140 / 140) | 280 / 280 (140 / 140) | **280 / 280 (140 / 140)** | same; the CLI walked 2 segments in 560 / 560 rows (280 / 280) |
| folders whose seven check-based dimensions all pass | 840 / 840 | 840 / 840 (420 / 420) | **840 / 840 (420 / 420)** | same |
| folders listing any Missing entry | 160 / 840 | 840 / 840 (420 / 420) | **840 / 840 (420 / 420)** | same as build 2 (every pinned folder lists the freshness gap) |
| ... of kind `unresolved` | 160 | 160 / 840 (80 / 420), 2 entries each | **160 / 840 (80 / 420)**, 2 entries each | same folders, same texts (restart segment 1 of the four post-dispatch fault points) |
| ... of kind `freshness` | did not exist | 840 / 840 (420 / 420) | **840 / 840 (420 / 420)** | same |
| ... of kind `issuer_only` | did not exist | 160 / 840 (80 / 420) | **160 / 840 (80 / 420)** | same |
| ... of kind `other` (pinned) | | 0 / 840 (0 / 420) | **0 / 840 (0 / 420)** | same; the new "Keys anchored for the newest segment only" entry is not listed, because the head pin anchors the earlier segment |
| `head_fresh` / `run_complete` | did not exist | not_checked 840; fail 160, not_checked 680 (deny 80 / 340) | **not_checked 840; fail 160, not_checked 680 (deny 80 / 340)** | same; build 3's "pending is incomplete" rule adds no case here |
| classification evidence (operations in the final view of each schedule) | did not exist | `issuer_adapter` 1,040; `issuer_only_reconciled` 320; `issuer_only_no_effect` 320 of 1,680 (deny 520 / 160 / 160 of 840) | **the same** | same; no operation is pending with a capability, so none moves from `issuer_only_no_effect` to `issuer_only_unresolved` (build-3 rule) |
| CLI cross-check agrees with the harness | 1,680 / 1,680 | 1,680 / 1,680 (840 / 840) | **1,680 / 1,680 (840 / 840)** | same; all 33 columns shared with build 2's CSV are identical row by row |
| restart tamper probes detected (5 edits x 560) / clean copy accepted | 2,800 / 2,800, 560 / 560 | 2,800 / 2,800, 560 / 560 | **2,800 / 2,800, 560 / 560** | same; `continuity_probes.csv` byte-identical (same failing checks per row) |
| recount from disk: disagreements with the harness / answers = logged CALL_RESULT | 0, 1,120 / 1,120 | 0, 1,120 / 1,120 (0, 560 / 560) | **0, 1,120 / 1,120 (0, 560 / 560)** | same; `reanalysis.md` byte-identical, totals in `reanalysis.json` equal |
| armed faults that fired / schedules failed / unstable cells | 960 / 960, 0 / 560, 0 / 56 | same (deny 480 / 480, 0 / 280, 0 / 56) | **960 / 960, 0 / 560, 0 / 56** (deny 480 / 480, 0 / 280, 0 / 56) | same; `crash.cells.csv`, `crash.folders.csv` byte-identical (flag and deny) |
| flag and deny cell results | 0 of 336 differ | 0 of 336 (0 of 504 shares, 0 of 112 folder fields) | **0 of 336** (0 of 504, 0 of 112) | same |
| run.json with `"host": "review-host"` | 1,260 / 1,260 | 1,260 / 1,260 | **1,260 / 1,260** | same; no evidence file contains the machine name, the Windows user name or a local path |
| RECONCILED-committed entries that record the effect with a reason to reconcile (status order) | not checked | not checked | **480 / 480 (240 / 240)**: 240 by (a) alone, 240 by (a)+(c) | **new rule** (build 3, `op.outcome_resolved`); recounted from disk by `status_rules.py` |
| RECONCILED entries inside the status-date bounds | not checked | not checked | **640 / 640 (320 / 320)** | **new rule** (build 3) |
| capabilities whose `cnf` names the run's adapter key for the effect type | not checked | not checked | **1,680 / 1,680 (840 / 840)** | **new rule** (build 3, `op.capability_bound`) |
| segment-2 chains whose earlier keys are anchored (harness pins) | not reported | not reported | **280 / 280 (140 / 140)**, by the head pin | **new report field** (build 3, `anchors.earlier_keys_anchored_by`) |
| earlier-segment keys probes (flag; §5.2) | | | keys pin only: new warning 280 / 280; genuine earlier pin: pass 280 / 280; foreign earlier pin: fail 280 / 280; earlier pin on a one-segment run: fail 280 / 280 | **new measurement** |
| reports listing the one-clock assumption | | | **1,680 / 1,680 (840 / 840)** CLI runs | **new report text** (build 3) |

## 1. What the build-3 changes do here

Build 3 changed 19 compiled module files and added 2 (`build-manifest.txt`).
For this experiment only the verifier matters. The crash harness reaches no
witness code, and no gateway code changed.

- **`op.outcome_resolved`, status order.** A RECONCILED-committed entry that
  records the effect now needs a reason to reconcile after the operation's
  latest capability: (a) an unresolved state logged before it, (b) another
  call's unresolved answer logged after it, or (c) a gateway restart between
  the capability and the entry. The crash run has 640 RECONCILED entries
  (320 in deny):
  - **480 record the effect** (240 in deny). These are
    `provider_response_lost`, `after_receipt_before_audit` and `audit_append`,
    with and without a restart, and with same-ID and fresh-ID retries.
  - **160 are confirming** (80 in deny): `head_replace`, where the
    EFFECT_EXECUTED entry is already logged. The rule does not cover these.

  Without a restart (240; 120 in deny), the reason is (a): the original
  call's UNCERTAIN or RECONCILIATION_REQUIRED answer, plus for
  `provider_response_lost` the EFFECT_FAILED `UNCERTAIN`.

  **On restart segments** (240; 120 in deny), the capability is in segment 1
  and the RECONCILED entry is in segment 2. So both (a), the answer logged in
  segment 1, and (c), the restart, hold. The rule reads across the walked
  chain.

  Reason (b) never occurs, because the crash runs are sequential. The
  round-5 same-call rule excluded nothing: 0 unresolved answers carried the
  reconciling call's own `call_id`. In each same-ID retry, the reconciling
  call has a new `call_id`, and `Reconcile` records none.

  `op.outcome_resolved` passed in every folder that settles all its
  operations (1,360 of 1,680 CLI runs). It is a warning in the other 320
  (restart segment 1 alone, 160 folders x 2 anchor conditions), exactly as
  in build 2.
- **`op.outcome_resolved`, status date.** Every observation is dated at most
  1.0 s before its RECONCILED entry and at most 2.0 s after the capability's
  `iat`, against a tolerance of 5 s. Observation times are whole seconds,
  hence the 1 s steps. One process on one machine stamped all of them, which
  is the new "One clock" assumption the report now states.
- **Pending with a capability is incomplete.** Since build 3, an operation
  that holds a verified capability and has no outcome after it counts as
  unresolved (warning, `unresolved` Missing entry, `issuer_only_unresolved`,
  `run_complete` not pass). No crash operation is in that state. Every
  operation that received a capability also has an answer in the same
  segment: refused, unresolved or executed. So the 320 `issuer_only_no_effect`
  operations (refusals after a capability) keep their class.
- **`op.capability_bound`, confirmation key.** All 1,680 capabilities (840)
  carry `cnf` = the key ID of the run's ADAPTER_FINANCIAL (840; 420 in deny)
  or ADAPTER_MESSAGE (840; 420) key, equal to `details.confirmation_kid`. The
  check passed in all 1,680 (840) CLI runs.
- **`keys.anchor` for earlier segments.** For a restarted run, a keys pin of
  the newest segment no longer anchors segment 1's keys. Segment 1's keys are
  anchored by a head pin of the newest segment, by their own pins
  (`--expect-earlier-keys`) or by the witness's run status. The harness pins
  the head, so its 280 (140) chains report `earlier_keys_anchored_by:
  head_pin`, and `anchored_keys` stays pass. The unanchored CLI pass reports
  `earlier_segments: 1` and `earlier_keys_anchored: false`, and still lists
  only "No keys anchor" and "No head anchor". The new entry is listed only
  when the newest keys *are* pinned and nothing anchors the earlier ones
  (§5.2).
- **Witness changes** (continuation linkage, enrollment-key pinning, run
  status v2): not exercised, because the crash harness registers no witness.
- **Refusal sites** (150 in build 3, 142 in build 2): none of the new `fail`
  sites fired on genuine evidence. 0 folders failed.
- **Restart tamper probes.** The five edits fail the same checks in every row
  as in build 2 (`continuity_probes.csv` byte-identical). Where a probe
  removes segment 1, the RECONCILED entries in segment 2 lose their
  capability and already failed `op.outcome_resolved` in build 2. The new
  date and order rules add no new failing check ID to any row.

## 2. Method (unchanged from build 2)

Commands, run from the repository root; nothing was compiled:

```
<singlebuild3>/bin/agentgate-eval -host-label review-host crash -repeat 20 -out docs/paper/data/build3/crash -work <work>/wf
<singlebuild3>/bin/agentgate-eval -host-label review-host crash -escalation deny -repeat 10 -out docs/paper/data/build3/crash/deny -work <work>/wd
```

`<work>` is `<repo>/.tools/build3-work/crash`. Both commands exited 0 with
empty stderr. `run.log` and `deny/run.log` are their stdout. They are
byte-identical to build 2 apart from the last line, which names the output
folder.

**Schedules** (as in builds 1 and 2): a fresh gateway with an fsynced JSONL
operation journal, per-run keys and an effectively unlimited signed grant
sends an AED 400.00 payment and an internal message. The factors are:

- 7 fault points (`none`, `before_capability_consume`,
  `after_capability_consume`, `provider_response_lost`,
  `after_receipt_before_audit`, `audit_append`, `head_replace` emulated);
- retry with the same ID or a fresh ID;
- restart: none, or journal (a new gateway with new keys on the same journal
  and provider);
- 20 repetitions (deny: 10).

That gives 560 schedules, 1,120 operations, 2,240 answers, 1,360 provider
effects and 840 evidence folders (deny: half). The order of each schedule
is: first calls, the optional restart, retries, one `Composition.Reconcile`,
close. Then each folder is verified in process with its keys fingerprint and
final head pinned.

**Build check.** `check_manifest.py` re-hashed the 1,870 files listed in
`MANIFEST.txt` twice: before the runs (14:51:10Z) and after every run,
cross-check and probe (15:00:51Z). Both times 0 differed
(`build-manifest.txt`). HEAD was `8a30fd4` throughout, and `git diff 8a30fd4
--stat -- internal cmd go.mod go.sum` was empty.

**Analysis.** The build-2 scripts were copied here. Unchanged copies:
`cells.py`, `reanalyze_from_disk.py`, `call_ids.py`, `recovery_records.py`,
`continuity_probes.py` and `flag_vs_deny.py`. Changed:

- `cli_crosscheck.py` records the new report fields (earlier-segment keys
  anchor, the status of three checks, the one-clock assumption,
  `counts.unresolved`). Its agreement test is unchanged.
- `compare_crash_json.py` has a `--build3` mode that strips nothing. It also
  normalises the shortened operation IDs in Missing texts.

New:

- `status_rules.py`: the status date, status order and `cnf` rules,
  recounted from the files;
- `earlier_keys_probes.py`: earlier-segment keys pins on the genuine restart
  evidence.

## 3. Results (flag run; deny shows the same pattern at half the counts)

Answers: COMMITTED 1,120, of which 320 reconciled; REJECTED 480 (240
`dispatch_refused`, 240 `aborted_before_send`); RECONCILIATION_REQUIRED 480
(`evidence_incomplete`); UNCERTAIN 160 (`provider_response_lost`); PENDING 0.
No answer had reason `dispatch_lease_expired`, and no EFFECT_FAILED has
`lease_expired=true` (lease 30 s).

| fault point | first answer | exact retry | provider effects | classification of the original operation (final view) | build-3 order reason of its RECONCILED entry |
|---|---|---|---|---|---|
| none | COMMITTED | COMMITTED (stored, scope `call`) | 1 | `issuer_adapter` | (no RECONCILED) |
| before_capability_consume | REJECTED / dispatch_refused | the stored REJECTED (scope `call`) | 0 | `issuer_only_no_effect` | (no RECONCILED) |
| after_capability_consume | REJECTED / aborted_before_send | the stored REJECTED (scope `call`) | 0 | `issuer_only_no_effect` | (no RECONCILED) |
| provider_response_lost | UNCERTAIN | COMMITTED / reconciled | 1 | `issuer_only_reconciled` (with or without restart) | (a); after a restart (a)+(c) |
| after_receipt_before_audit, audit_append | RECONCILIATION_REQUIRED | COMMITTED / reconciled | 1 | `issuer_adapter` without restart (receipt on RECONCILED); `issuer_only_reconciled` after a restart | (a); after a restart (a)+(c) |
| head_replace (emulated) | RECONCILIATION_REQUIRED | COMMITTED / reconciled | 1 | `issuer_adapter` (EFFECT_EXECUTED present) | confirming: not covered by the order rule |

A fresh-ID retry commits the same content once more under the new ID, as
`issuer_adapter`. The original operation is then reconciled by
`Composition.Reconcile`, which records no `call_id`, for the same reason as
in the table.

## 4. Evidence verification and cross-checks

| folders | verdict / assurance | Missing by kind (folders) | derived dimensions | earlier keys (build 3) |
|---|---|---|---|---|
| all | **840 / 840 VERIFIED/ANCHORED**, 0 FAILED, 7 check-based dimensions pass in all | freshness 840, unresolved 160 (320 entries), issuer_only 160, other 0 | head_fresh not_checked 840; run_complete fail 160, not_checked 680 | |
| no restart (280) | 280 / 280 ANCHORED | freshness 280; issuer_only 40 (provider_response_lost) | run_complete not_checked 280 | 0 earlier segments |
| restart, segment 1 verified alone (280) | 280 / 280 ANCHORED | freshness 280; unresolved 160 (2 operations each, settled in segment 2) | run_complete **fail** 160, not_checked 120 | 0 earlier segments |
| restart, segment 2 walked with segment 1 (280) | **280 / 280 VERIFIED/ANCHORED**, 0 failing checks | freshness 280; issuer_only 120 (provider_response_lost, after_receipt_before_audit, audit_append) | run_complete not_checked 280 | 1 earlier segment, anchored by the head pin in 280 / 280 |
| deny run | 420 / 420 ANCHORED; segment 2: 140 / 140 | freshness 420, unresolved 80, issuer_only 80, other 0 | run_complete fail 80, not_checked 340 | 140 / 140 by the head pin |

**Classification evidence** (CLI, pinned pass; the harness does not record
it). It is identical to build 2 in every cell:

| scope | operations | issuer_adapter | issuer_only_reconciled | issuer_only_unresolved | issuer_only_no_effect | audit_only |
|---|---|---|---|---|---|---|
| final view of each schedule, flag | 1,680 | 1,040 | 320 | 0 | 320 | 0 |
| same, deny | 840 | 520 | 160 | 0 | 160 | 0 |
| every pinned verification, flag (a segment-2 chain counts both segments) | 2,240 | 1,200 | 320 | 240 (160 reconciliation_required + 80 uncertain, all in restart segment 1) | 480 | 0 |

The executed operations of the final views, 1,040 + 320 = 1,360, equal the
1,360 provider effects.

**CLI verifier in a separate process** (`cli_crosscheck.py` with the frozen
`agentgate-verify`). Each folder was checked with no anchors (expected
VERIFIED/CONSISTENT) and with the pins read from the folder (expected
VERIFIED/ANCHORED). It agreed with the in-process result in 840 of 840 checks
of each kind (1,680 of 1,680; deny 840 of 840). This uses the same verifier
code, so it is not an independent check. All 33 columns shared with build 2's
CSV are identical row by row, including the per-operation
`status:classification_evidence` lists. The expected Missing kinds are
unchanged from build 2 (none: harness kinds without `freshness`, with
`other` + 2; pinned: exactly the harness kinds).

**Recount from the files on disk** (`reanalyze_from_disk.py`): 0
disagreements with the harness; the agent's answer equals the logged
CALL_RESULT in 1,120 of 1,120 (560 of 560); `reanalysis.md` is
byte-identical to build 2. `call_ids.txt` and `recovery_records.txt` (flag
and deny) are byte-identical to build 2. `details.flagged` is absent from
every CALL_RESULT and RECONCILED entry, and `counts.flagged` /
`flagged_unconfirmed` are 0 in 840 of 840 reports (420 of 420).

**Restart tamper probes** (`continuity_probes.py`; 280 restart schedules x 2
anchor conditions = 560 per edit): the clean copy was accepted 560 of 560.
Each of the five edits was detected 560 of 560: segment 1 deleted, cut short,
rolled back by a simulated audit-key holder, link removed, or swapped for
another run's. `continuity_probes.csv` is byte-identical to build 2.

## 5. New measurements in build 3

### 5.1 Status date, status order and `cnf`, recounted from disk (`status_rules.py`)

The script walks each schedule's segments in order. It decodes the signed
provider status (`observed_at`) and the capability (`iat`, `cnf`) with the
CBOR reader of `reanalyze_from_disk.py`, and applies the build-3 rules as
VERIFIER_CHECKS §2 states them. It checks no signatures and is not the
verifier's code. The verifier's own verdict is that `op.outcome_resolved`
and `op.capability_bound` failed in 0 folders.

| measure (flag; deny in brackets) | result |
|---|---|
| RECONCILED entries | 640 (320): 480 committed that record the effect, 160 committed confirming (`head_replace`) (240 / 80) |
| ... recording the effect, by reason to reconcile | (a) only: 240 (120), no-restart schedules; (a)+(c): 240 (120), restart schedules, RECONCILED in segment 2; (b): 0; none: **0** |
| ... by who reconciled | the same-ID retry (MCP call, with `call_id`): 240 (120); `Composition.Reconcile` after a fresh-ID retry (no `call_id`): 240 (120) |
| unresolved answers excluded because they carry the reconciling call's own `call_id` | 0 |
| outside the status-date bounds (5 s) | **0 / 640 (0 / 320)**; entry time - `observed_at` 0.003 to 1.000 s (0.004 to 0.996); `observed_at` - capability `iat` 0 to 2 s (0 to 1) |
| capabilities whose `cnf` is the segment's ADAPTER_* key for the effect type | **1,680 / 1,680 (840 / 840)**; equal to `details.confirmation_kid` in 1,680 / 1,680 (840 / 840) |

### 5.2 Earlier-segment keys anchor on the restart evidence (`earlier_keys_probes.py`, flag)

These probes verify the untouched folders in place with the standalone CLI
and edit nothing. K1 and K2 are the keys fingerprints of segments 1 and 2,
H2 is segment 2's final head, and K1' is segment 1's fingerprint from the
next repetition of the same cell.

| probe (280 runs each) | verdict / assurance | `anchored_keys` | earlier keys anchored by | Missing (pinned kinds) | failing |
|---|---|---|---|---|---|
| `--expect-keys K2` | 280 VERIFIED/CONSISTENT | **not_checked** 280 | - | "Keys anchored for the newest segment only" in **280 / 280** (+ "No head anchor"; issuer_only in 120) | none |
| `--expect-keys K2 --expect-earlier-keys K1` | 280 VERIFIED/CONSISTENT | pass 280 | `pins` 280 | "No head anchor" only (+ issuer_only 120) | none |
| `--expect-keys K2 --expect-earlier-keys K1'` | **280 FAILED** (exit 1) | fail 280 | - | "Keys anchor MISMATCH" + "No head anchor" | `keys.anchor` only, 280 / 280 |
| `--expect-keys K2 --expect-head H2` (the harness's pins) | 280 VERIFIED/ANCHORED | pass 280 | `head_pin` 280 | freshness (+ issuer_only 120) | none |
| all three pins | 280 VERIFIED/ANCHORED | pass 280 | `pins` 280 | freshness (+ issuer_only 120) | none |
| one-segment run (no restart) with `--expect-earlier-keys K` added to keys and head pins | **280 FAILED** (exit 1) | fail 280 | - | freshness + "Keys anchor MISMATCH" (+ issuer_only 40) | `keys.anchor` only, 280 / 280 |

So on genuine restart evidence, the build-3 rule behaves as specified:

- 0 false alarms with the genuine pins (560 of 560 verified);
- the warning appears exactly when only the newest keys are pinned (280 of
  280);
- a foreign segment-1 pin is refused (280 of 280);
- earlier pins on a run of one segment are refused (280 of 280).

These are genuine folders, not attacks. A made-up segment 1 signed with keys
of its own is tested in the verifier's unit tests
(`TestEarlierSegmentKeysAnchor`), not here.

## 6. Caveats

All build-1 and build-2 caveats still apply:

- The crash abandons the gateway object inside one process. No process is
  killed, and the provider never restarts. The kill suite covers OS-level
  kills.
- `head_replace` is emulated.
- There is one fault per operation and at most one restart.
- No provider-side faults are injected, so a reconciliation to "not
  committed" is never exercised. The status-date rule's
  `not_committed`-only branch (no lower bound) is therefore not reached here.
- Only plain ALLOW operations are used, with no budget pressure, so the deny
  run exercises the same paths and no flagged recovery occurs.
- No witness is used, so `head_fresh` and `run_complete` never pass, and
  the build-3 witness changes are not exercised.
- Repetitions are stability checks, not independent samples.
- The freshness entry is constant. Read the Missing counts by kind.

New or sharpened in build 3:

- **The new rules are shown to hold on genuine evidence, not to detect
  anything here.** The status date and order rules and the `cnf` rule
  passed on every genuine RECONCILED entry and capability. Whether they
  catch forgeries is the robustness and compromise experiments' question,
  and the verifier's unit tests'. Reason (b) of the order rule never occurs,
  because the crash runs are sequential.
- **One clock.** All timestamps come from one process on one machine. The
  date-rule margins (at most 2 s of 5 s) say nothing about separate hosts.
- **`status_rules.py` is a recount, not a second verifier.** It follows the
  rule as documented and reads payloads without checking signatures.
- **A count observation that is not a build-3 change.** In the 40 restart
  segment-1 folders of `head_replace` (20 in deny), the report lists 2
  `unresolved` Missing entries ("reported RECONCILIATION_REQUIRED ... and
  never reconciled"), but `counts.unresolved` is 0. The operations' status
  is `executed`, because segment 1 holds their EFFECT_EXECUTED, and
  `counts.unresolved` counts only operations whose status is uncertain or
  reconciliation_required (or, since build 3, pending with a capability).
  Build 2's code counted the same way (`verify.go` at `86643d7`). The field
  is recorded here for the first time, because `cli_crosscheck.py` now
  records it. In the other 120 unresolved folders (60 in deny),
  `counts.unresolved` = 2 = the Missing entries. Verdicts and dimensions do
  not depend on this count (`run_complete` fails in all 160).
- **Timings are not performance results.** Other experiment runners used the
  machine at the same time, and the clock granularity was 1.0 ms:
  - flag: 162 s (build 2: 121 s), median schedule 173 ms (build 2: 194 ms);
  - deny: 100 s (build 2: 150 s), median schedule 327 ms (build 2: 223 ms).

## 7. Open issues

- **eval-engine** (unchanged from build 2):
  - The harness's verification record does not say how many segments were
    verified.
  - `crash.json` does not record the `call_id` the agent received.
  - `crash.json` does not record `classification_evidence`.
- **eval-engine, coverage still missing:**
  - provider faults (which would reach the `not_committed` date branch);
  - a flagged AED 10,000 payment across fault points;
  - a tight-budget fresh-ID case;
  - a stall past the 30 s lease;
  - concurrent same-ID retries (order reason (b));
  - restart segments registered with a witness (continuation linkage,
    run status v2, `head_fresh` / `run_complete` pass, the earlier-keys
    anchor through the witness's run status);
  - an operation left pending with a capability (the build-3 pending rule;
    a killed process can leave one, as in the kill suite).
- **verifier (optional):** `counts.unresolved` could also count an executed
  operation whose last answer is unresolved, to match the Missing entries
  (§6). It changes no verdict.
- **For `RESULTS_REVISION.md`:** the crash rows can cite build 3 with
  unchanged numbers. The new rows to add are the status-order and date
  recount (480 of 480 with a reason; 0 of 640 outside the bounds), the `cnf`
  count (1,680 of 1,680) and the earlier-keys probe (§5.2).

## 8. Files

Flag run (deny run in `deny/`):

| file | what it is | also in `deny/` |
|---|---|---|
| `crash.json`, `crash.csv`, `crash.md` | harness output (same schema as build 2) | yes |
| `run.log` | harness stdout | yes |
| `crash.cells.csv`, `crash.cells.json`, `crash.folders.csv` | `cells.py` output | yes |
| `reanalysis.json`, `reanalysis.md` | `reanalyze_from_disk.py` output | yes |
| `call_ids.txt` | `call_ids.py` output | yes |
| `recovery_records.txt` | `recovery_records.py` output | yes |
| `status_rules.txt` | `status_rules.py` output (new) | yes |
| `cli_crosscheck.csv`, `cli_crosscheck.summary.json` | `cli_crosscheck.py` output; 9 new `cli_*` columns and 3 new `b3_*` summary members | yes |
| `continuity_probes.csv` | `continuity_probes.py` output | no (flag only) |
| `earlier_keys_probes.csv` | `earlier_keys_probes.py` output (new) | no (flag only) |
| `analysis_console.txt` | console output of the comparison, cross-check and probe scripts, and the byte comparisons with build 2 | no |
| `build-manifest.txt` | binary hashes, manifest checks before and after, run times and commands, module files changed since build 2, compiled module sources | no |

Scripts: `cells.py`, `reanalyze_from_disk.py`, `call_ids.py`,
`recovery_records.py`, `continuity_probes.py` and `flag_vs_deny.py`
(unchanged); `cli_crosscheck.py` and `compare_crash_json.py` (changed, see
their docstrings); `status_rules.py` and `earlier_keys_probes.py` (new).

The evidence folders (72 MB flag, 36 MB deny) stay outside the repository,
under `<repo>/.tools/build3-work/crash/` (`wf`, `wd`).
