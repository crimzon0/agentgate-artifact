"""Schedule-by-schedule comparison of two crash.json files after removing
run-specific identifiers (operation IDs, provider references, fault-arming IDs)
and timings. Also compares crash.csv the same way.

Build-3 copy of the build-2 script. Build 3 changed no crash harness code
(cmd/agentgate-eval/crash.go and harness.go are byte-identical to build 2) and
no gateway code the crash run uses, so crash.json has no new field. Changes:
  * mode "--build3" (OLD = build 2, NEW = build 3): nothing is stripped; the
    schedules are compared directly after normalisation, Missing texts
    included, and every field that differs is printed with how often;
  * without "--build3" the script behaves as the build-2 copy (OLD = build 1,
    NEW = build 2 or 3: the build-2 additions are stripped from NEW);
  * normalisation also replaces the shortened operation IDs the verifier
    prints in Missing texts ("BCSerENz55...") by "<id>...", because the
    issuer_only entries of two runs name different IDs.

Build-2 notes (kept): the build-2 additions are
  * segment fields missing_by_kind and the derived dimensions head_fresh and
    run_complete;
  * Missing entries of kind freshness and issuer_only (identified by
    missing_by_kind and by their fixed wording);
  * totals.segments_with_missing_items(_by_kind), which build 2 counts with the
    freshness entries (every pinned folder);
  * crash.csv columns segment1_missing_kinds and segment2_missing_kinds.

usage: python compare_crash_json.py [--build3] OLD_DIR NEW_DIR"""
import collections
import csv
import json
import re
import sys

DROP = {"operation_id", "fresh_operation_id", "provider_reference", "elapsed_ms", "started_at", "clock_granularity_ms"}
NEW_SEGMENT_FIELDS = {"missing_by_kind"}
NEW_DIMENSIONS = {"head_fresh", "run_complete"}
NEW_MISSING_PREFIXES = ("Head not shown to be fresh:",)
NEW_CSV_COLUMNS = {"segment1_missing_kinds", "segment2_missing_kinds"}


def norm(x):
    if isinstance(x, dict):
        return {k: norm(v) for k, v in x.items() if k not in DROP and not k.endswith("_ms")}
    if isinstance(x, list):
        return [norm(v) for v in x]
    if isinstance(x, str):
        x = re.sub(r"(?<![A-Za-z0-9_-])[A-Za-z0-9_-]{22}(?![A-Za-z0-9_-])", "<id>", x)
        x = re.sub(r"sim-[0-9a-f]{8}-\d+", "sim-<ref>", x)
        x = re.sub(r"(?<![A-Za-z0-9_-])[A-Za-z0-9_-]{10}\.\.\.", "<id>...", x)
        return x
    return x


def strip_new(schedule):
    """Remove the build-2 additions from one (normalised) schedule (not in --build3 mode)."""
    out = json.loads(json.dumps(schedule))
    if BUILD3:
        for segment in out.get("evidence_segments", []):
            segment["_dropped_missing"] = segment["_dropped_expected"] = 0
        return out
    for segment in out.get("evidence_segments", []):
        kinds = segment.pop("missing_by_kind", None) or {}
        for name in NEW_DIMENSIONS:
            (segment.get("dimensions") or {}).pop(name, None)
        missing = segment.get("missing") or []
        kept = [m for m in missing if not m.startswith(NEW_MISSING_PREFIXES) and "rests on the capability issuer's signature alone" not in m]
        segment["missing"] = kept
        segment["_dropped_missing"] = len(missing) - len(kept)
        segment["_dropped_expected"] = kinds.get("freshness", 0) + kinds.get("issuer_only", 0)
    return out


def diff_paths(a, b, path=""):
    if isinstance(a, dict) and isinstance(b, dict):
        for k in sorted(set(a) | set(b)):
            if k.startswith("_"):
                continue
            yield from diff_paths(a.get(k), b.get(k), path + "." + k)
    elif isinstance(a, list) and isinstance(b, list) and len(a) == len(b):
        for i, (x, y) in enumerate(zip(a, b)):
            yield from diff_paths(x, y, path + "[]")
    elif a != b:
        yield path


args = sys.argv[1:]
BUILD3 = "--build3" in args
args = [a for a in args if a != "--build3"]
old, new = args[0], args[1]
print("mode:", "build 2 -> build 3, nothing stripped" if BUILD3 else "build 1 -> build 2+, build-2 additions stripped")
a = json.load(open(old + "/crash.json", encoding="utf-8"))
b = json.load(open(new + "/crash.json", encoding="utf-8"))
print("top-level keys equal:", sorted(a) == sorted(b))
for key in ("note", "method", "escalation", "totals"):
    print("%-10s equal: %s" % (key, a[key] == b[key]))
ta, tb = a["totals"], b["totals"]
print("totals that differ:", {k: (ta.get(k), tb.get(k)) for k in sorted(set(ta) | set(tb)) if ta.get(k) != tb.get(k)})
ea, eb = dict(a["environment"]), dict(b["environment"])
print("environment differs in:", sorted(k for k in set(ea) | set(eb) if ea.get(k) != eb.get(k)))
sa = {s["label"]: s for s in a["schedules"]}
sb = {s["label"]: s for s in b["schedules"]}
print("schedules:", len(sa), len(sb), "same labels:", set(sa) == set(sb))
diff = [k for k in sa if norm(sa[k]) != norm(sb.get(k))]
print("schedules differing after normalisation:", len(diff))
paths = collections.Counter()
remaining = []
dropped_ok = 0
dropped_total = 0
for k in sa:
    x, y = norm(sa[k]), strip_new(norm(sb[k]))
    for segment in y.get("evidence_segments", []):
        dropped_total += 1
        dropped_ok += segment["_dropped_missing"] == segment["_dropped_expected"]
    found = list(diff_paths(x, y))
    if found:
        remaining.append(k)
        for p in set(found):
            paths[p] += 1
if not BUILD3:
    print("segments where the removed Missing entries equal the freshness+issuer_only count: %d / %d" % (dropped_ok, dropped_total))
print("schedules differing after %s:" % ("normalisation (Missing texts included)" if BUILD3 else "removing the build-2 additions"), len(remaining), remaining[:5])
for p, n in sorted(paths.items()):
    print("  field %s differs in %d schedules" % (p, n))
ids_a = sum(len(s["operations"]) for s in a["schedules"])
print("operations compared:", ids_a)


def rows(path):
    with open(path, encoding="utf-8", newline="") as h:
        r = list(csv.DictReader(h))
    return r


ra, rb = rows(old + "/crash.csv"), rows(new + "/crash.csv")
cols = list(ra[0].keys())
print("crash.csv rows:", len(ra), len(rb), "same columns:", cols == list(rb[0].keys()),
      "new columns:", [c for c in rb[0].keys() if c not in cols])
varying = set()
for x, y in zip(ra, rb):
    for c in cols:
        if x[c] != y.get(c):
            varying.add(c)
print("crash.csv columns that differ in some row:", sorted(varying))
rest = [c for c in varying if not (c.endswith("_ms") or "operation_id" in c or "reference" in c or c in DROP)]
print("crash.csv differing columns other than IDs/timings:", sorted(rest))
