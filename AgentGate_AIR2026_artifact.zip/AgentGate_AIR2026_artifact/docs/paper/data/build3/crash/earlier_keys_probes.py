#!/usr/bin/env python3
"""Earlier-segment keys anchor on the crash restart evidence (new in build 3).

Build 3 (round-5 review fixes) changed keys.anchor for a run of several
segments (VERIFIER_CHECKS.md, keys.anchor): a keys pin of the newest segment
(--expect-keys) no longer counts as anchoring the earlier segments' keys,
which only the newest segment's continuation record names. They are anchored
by their own pins (--expect-earlier-keys) or by an anchor of the newest
segment's log (a head pin, a witness head checked as an extension, the
witness's run status). Otherwise anchored_keys is not_checked with the
Missing entry "Keys anchored for the newest segment only" (kind other).
Pins given for a run of one segment fail.

The harness and cli_crosscheck.py pin keys AND head, so they never meet the
new warning. This script exercises the new rule on the genuine crash
evidence, read-only (no folder is copied or edited), with the standalone CLI:

  for every restart schedule, segment 2 (verified as a chain of 2 segments):
    keys_only          --expect-keys K2                      (new warning expected)
    keys_earlier       --expect-keys K2 --expect-earlier-keys K1
    keys_wrong_earlier --expect-keys K2 --expect-earlier-keys K1' (segment 1 of
                       the next repetition of the same cell: a genuine folder
                       of another run; keys.anchor must fail)
    keys_head          --expect-keys K2 --expect-head H2     (the harness's pins)
    all_pins           --expect-keys K2 --expect-head H2 --expect-earlier-keys K1
  for every schedule without a restart (one segment):
    single_with_earlier --expect-keys K --expect-head H --expect-earlier-keys K
                       (pins for a run with no earlier segment: must fail)

K, H are SHA-256 of keys.json and entry_hash of head.json, read from the
untouched folders after the run.

Usage: python earlier_keys_probes.py VERIFY_EXE CRASH_JSON WORK_DIR OUT_CSV [WORKERS]
Python 3 standard library only.
"""
import collections
import concurrent.futures
import csv
import hashlib
import json
import os
import subprocess
import sys

NEWEST_ONLY = "Keys anchored for the newest segment only"


def keys_sha(folder):
    with open(os.path.join(folder, "keys.json"), "rb") as handle:
        return hashlib.sha256(handle.read()).hexdigest()


def head_hash(folder):
    with open(os.path.join(folder, "head.json"), encoding="utf-8") as handle:
        return json.load(handle)["entry_hash"]


def verify(exe, folder, args):
    proc = subprocess.run([exe, "--json", "--workers", "1"] + args + [folder], capture_output=True, text=True, encoding="utf-8")
    try:
        report = json.loads(proc.stdout)
    except ValueError:
        return {"exit": proc.returncode, "error": (proc.stderr or proc.stdout).strip()[:300]}
    anchors = report.get("anchors") or {}
    checks = {c.get("id"): c.get("status") for c in report.get("checks") or []}
    return {
        "exit": proc.returncode, "verdict": report.get("verdict", ""), "assurance": report.get("assurance", ""),
        "failing": " ".join(sorted({c.get("id", "") for c in report.get("failures") or []})),
        "anchored_keys": ((report.get("dimensions") or {}).get("anchored_keys") or {}).get("status", ""),
        "keys_anchor_check": checks.get("keys.anchor", ""),
        "missing_kinds": " ".join("%s=%d" % kv for kv in sorted(collections.Counter(report.get("missing_kinds") or []).items())),
        "newest_only_missing": any(m.startswith(NEWEST_ONLY) for m in report.get("missing") or []),
        "earlier_segments": anchors.get("earlier_segments", 0),
        "earlier_keys_anchored": anchors.get("earlier_keys_anchored", False),
        "earlier_keys_anchored_by": anchors.get("earlier_keys_anchored_by", ""),
        "error": "",
    }


def main():
    if len(sys.argv) < 5:
        sys.exit(__doc__)
    exe, crash_json, work, out_csv = sys.argv[1:5]
    workers = int(sys.argv[5]) if len(sys.argv) > 5 else 6
    with open(crash_json, encoding="utf-8") as handle:
        result = json.load(handle)
    schedules = [s for s in result["schedules"] if not s.get("error")]
    by_cell = collections.defaultdict(dict)
    for schedule in schedules:
        if schedule["restart"] == "journal":
            by_cell[(schedule["fault_point"], schedule["retry"])][schedule["repeat"]] = schedule["label"]
    jobs = []
    for schedule in schedules:
        base = os.path.join(work, schedule["label"])
        if schedule["restart"] == "journal":
            seg1, seg2 = os.path.join(base, "segment-1"), os.path.join(base, "segment-2")
            cell = by_cell[(schedule["fault_point"], schedule["retry"])]
            repeats = sorted(cell)
            partner = cell[repeats[(repeats.index(schedule["repeat"]) + 1) % len(repeats)]]
            k1, k2, h2 = keys_sha(seg1), keys_sha(seg2), head_hash(seg2)
            k1_other = keys_sha(os.path.join(work, partner, "segment-1"))
            probes = {
                "keys_only": ["--expect-keys", k2],
                "keys_earlier": ["--expect-keys", k2, "--expect-earlier-keys", k1],
                "keys_wrong_earlier": ["--expect-keys", k2, "--expect-earlier-keys", k1_other],
                "keys_head": ["--expect-keys", k2, "--expect-head", h2],
                "all_pins": ["--expect-keys", k2, "--expect-head", h2, "--expect-earlier-keys", k1],
            }
            for probe, args in probes.items():
                if probe == "keys_wrong_earlier" and (partner == schedule["label"] or k1_other == k1):
                    continue
                jobs.append((schedule, "segment-2 chain", probe, seg2, args))
        else:
            seg = os.path.join(base, "segment-1")
            k, h = keys_sha(seg), head_hash(seg)
            jobs.append((schedule, "single segment", "single_with_earlier", seg,
                         ["--expect-keys", k, "--expect-head", h, "--expect-earlier-keys", k]))
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        outcomes = list(pool.map(lambda job: verify(exe, job[3], job[4]), jobs))
    rows = []
    summary = collections.Counter()
    for (schedule, scope, probe, folder, args), out in zip(jobs, outcomes):
        row = {"label": schedule["label"], "fault_point": schedule["fault_point"], "retry": schedule["retry"],
               "restart": schedule["restart"], "repeat": schedule["repeat"], "scope": scope, "probe": probe}
        row.update(out)
        rows.append(row)
        summary[(probe, out.get("verdict", "ERROR"), out.get("assurance", ""), out.get("anchored_keys", ""),
                 out.get("keys_anchor_check", ""), out.get("earlier_keys_anchored_by", "") or "-",
                 out.get("newest_only_missing", ""), out.get("failing", ""), out.get("missing_kinds", ""), out.get("exit"))] += 1
    with open(out_csv, "w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print("probe runs: %d" % len(rows))
    print("probe | verdict/assurance | anchored_keys | keys.anchor | earlier keys anchored by | 'newest segment only' Missing | failing | missing kinds | exit: count")
    for key in sorted(summary, key=str):
        print("  %s | %s/%s | %s | %s | %s | %s | %s | %s | exit %s: %d" % (key + (summary[key],)))


if __name__ == "__main__":
    main()
