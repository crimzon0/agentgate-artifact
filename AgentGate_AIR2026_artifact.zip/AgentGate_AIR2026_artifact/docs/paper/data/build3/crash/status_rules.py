#!/usr/bin/env python3
"""Build-3 verifier rules on the crash evidence, recounted from the files (new in build 3).

Build 3 (round 5) added three rules that the crash evidence exercises
(VERIFIER_CHECKS.md section 2):

  * op.outcome_resolved, status date: a RECONCILED entry's provider status
    observation (signed provider_status, member observed_at, Unix seconds) is
    at most the entry time + 5 s, and for outcome committed at least the
    operation's latest capability iat - 5 s;
  * op.outcome_resolved, status order: a RECONCILED committed entry that
    records the effect (no EFFECT_EXECUTED of the operation before it) needs a
    reason to reconcile after the operation's latest capability:
      (a) an unresolved state logged before it: CALL_RESULT of scope operation
          (or none) with status UNCERTAIN / RECONCILIATION_REQUIRED, or
          EFFECT_FAILED with outcome uncertain or status UNCERTAIN; a
          CALL_RESULT with the same non-empty call_id as the RECONCILED entry
          never counts (round-5 fix);
      (b) such a CALL_RESULT of another call (different non-empty call_id)
          logged after it;
      (c) a gateway restart between the capability and the entry (the entry
          lies in a later segment than the capability);
  * op.capability_bound, confirmation key: the capability's cnf claim
    ({3: kid}) names the run's ADAPTER_* key for its effect type in that
    segment's keys.json, and equals the entry's details.confirmation_kid.

This script reads every audit.jsonl and keys.json under WORK_DIR
(<schedule>/segment-N/, as written by `agentgate-eval crash -work WORK_DIR`),
walks each schedule's segments in order as one log, and counts, per cell, how
each RECONCILED entry meets the date and order rules (with the margins) and
how each capability meets the cnf rule. It decodes the COSE payloads with the
CBOR reader of reanalyze_from_disk.py (same folder); it does not check
signatures (the verifier does). It is a disk-side counterpart, not the
verifier's code: a rule the verifier applies is passed when no folder fails
op.outcome_resolved / op.capability_bound (cli_crosscheck.py).

Usage: python status_rules.py WORK_DIR [OUT_TXT]
Python 3 standard library only.
"""
import collections
import importlib.util
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
_spec = importlib.util.spec_from_file_location("reanalyze_from_disk", os.path.join(HERE, "reanalyze_from_disk.py"))
_ra = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_ra)
payload = _ra.receipt_payload

LABEL = re.compile(r"crash-(.*)-(same-id|fresh-id)-(none|journal)-r\d+$")
UNRESOLVED = ("UNCERTAIN", "RECONCILIATION_REQUIRED")
TOLERANCE = 5.0
ROLE = {"financial_request.create": "ADAPTER_FINANCIAL", "external_message.send": "ADAPTER_MESSAGE",
        "document.release": "ADAPTER_DOCUMENT"}


def epoch(text):
    """RFC 3339 UTC time with up to 9 fractional digits -> Unix seconds (float)."""
    match = re.match(r"^(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)(?:\.(\d+))?Z$", text)
    if not match:
        raise ValueError("unexpected time " + text)
    y, mo, d, h, mi, s, frac = match.groups()
    import calendar
    whole = calendar.timegm((int(y), int(mo), int(d), int(h), int(mi), int(s), 0, 0, 0))
    return whole + (int(frac) / 10 ** len(frac) if frac else 0.0)


def unresolved_state(entry):
    stage, details = entry.get("stage"), entry.get("details") or {}
    if stage == "CALL_RESULT":
        return details.get("scope", "operation") in ("operation", "", None) and details.get("status") in UNRESOLVED
    if stage == "EFFECT_FAILED":
        return entry.get("outcome") == "uncertain" or details.get("status") == "UNCERTAIN"
    return False


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    root = sys.argv[1]
    out_path = sys.argv[2] if len(sys.argv) > 2 else None
    reconciled = collections.Counter()
    reasons = collections.Counter()
    date_fail = collections.Counter()
    order_fail = collections.Counter()
    same_call = collections.Counter()
    margins = collections.defaultdict(list)
    cnf = collections.Counter()
    for schedule in sorted(os.listdir(root)):
        match = LABEL.match(schedule)
        if not match:
            continue
        point, retry, restart = match.groups()
        segments = sorted((d for d in os.listdir(os.path.join(root, schedule)) if d.startswith("segment-")),
                          key=lambda d: int(d.split("-")[1]))
        log = []  # (segment number, entry)
        for name in segments:
            number = int(name.split("-")[1])
            folder = os.path.join(root, schedule, name)
            with open(os.path.join(folder, "keys.json"), encoding="utf-8") as handle:
                keys = {k["kid"]: k["role"] for k in json.load(handle)["keys"]}
            with open(os.path.join(folder, "audit.jsonl"), encoding="utf-8") as handle:
                for line in handle:
                    if line.strip():
                        entry = json.loads(line)["entry"]
                        log.append((number, entry))
                        if entry.get("stage") == "CAPABILITY_ISSUED":
                            claims = payload(entry["artifacts"]["capability_token"])
                            kid = (claims.get(8) or {}).get(3, b"").hex()
                            want = ROLE.get(entry.get("effect_type"))
                            logged = (entry.get("details") or {}).get("confirmation_kid", "")
                            cnf["capabilities"] += 1
                            cnf["cnf = the segment's %s key" % want] += keys.get(kid) == want
                            cnf["cnf = details.confirmation_kid"] += kid == logged
        for index, (segment, entry) in enumerate(log):
            if entry.get("stage") != "RECONCILED":
                continue
            op = entry.get("operation_id")
            details = entry.get("details") or {}
            call_id = details.get("call_id", "")
            caps = [(s, payload(e["artifacts"]["capability_token"])[6]) for s, e in log[:index]
                    if e.get("stage") == "CAPABILITY_ISSUED" and e.get("operation_id") == op]
            cap_segment, iat = caps[-1] if caps else (None, None)
            cap_index = max(i for i, (s, e) in enumerate(log[:index]) if e.get("stage") == "CAPABILITY_ISSUED" and e.get("operation_id") == op) if caps else -1
            status = payload(entry["artifacts"]["provider_status"])
            observed = status.get("observed_at")
            when = epoch(entry["time"])
            outcome = entry.get("outcome")
            executed_before = any(e.get("stage") == "EFFECT_EXECUTED" and e.get("operation_id") == op for _, e in log[:index])
            who = "MCP call" if call_id else "Composition.Reconcile"
            cell = "%s %s restart=%s RECONCILED in segment %d by %s" % (point, retry, restart, segment, who)
            kind = "%s/%s" % (outcome, "confirming (EFFECT_EXECUTED before)" if executed_before else "records the effect")
            reconciled[(cell, kind)] += 1
            # date rule
            upper = observed is not None and observed <= when + TOLERANCE
            lower = outcome != "committed" or (iat is not None and observed is not None and observed >= iat - TOLERANCE)
            if not (upper and lower):
                date_fail[cell] += 1
            if observed is not None:
                margins["entry time - observed_at (s)"].append(when - observed)
                if iat is not None:
                    margins["observed_at - capability iat (s)"].append(observed - iat)
            # order rule
            if outcome == "committed" and not executed_before:
                a = b = False
                for i, (s, e) in enumerate(log):
                    if e.get("operation_id") != op or not unresolved_state(e):
                        continue
                    other = (e.get("details") or {}).get("call_id", "")
                    if cap_index < i < index:
                        if call_id and other == call_id:
                            same_call[cell] += 1
                            continue
                        a = True
                    elif i > index and e.get("stage") == "CALL_RESULT" and other and other != call_id:
                        b = True
                c = cap_segment is not None and segment > cap_segment
                label = "+".join(name for name, value in (("a", a), ("b", b), ("c", c)) if value) or "none"
                reasons[(cell, label)] += 1
                if label == "none":
                    order_fail[cell] += 1
    lines = ["# status_rules.py: build-3 verifier rules recounted from the files (%s)" % os.path.basename(os.path.normpath(root))]
    lines.append("## RECONCILED entries by cell and kind")
    total = collections.Counter()
    for (cell, kind), count in sorted(reconciled.items()):
        lines.append("  %-95s %-42s %d" % (cell, kind, count))
        total[kind] += count
    lines.append("  total: %s (all %d)" % (dict(total), sum(total.values())))
    lines.append("## status order: reasons to reconcile of the RECONCILED committed entries that record the effect")
    lines.append("   (a) unresolved state before it, (b) another call's unresolved CALL_RESULT after it, (c) restart between capability and entry")
    by_reason = collections.Counter()
    for (cell, label), count in sorted(reasons.items()):
        lines.append("  %-95s %-6s %d" % (cell, label, count))
        by_reason[label] += count
    lines.append("  total by reason: %s (all %d); with no reason (would fail): %d" % (dict(sorted(by_reason.items())), sum(by_reason.values()), sum(order_fail.values())))
    lines.append("  unresolved states skipped because they carry the RECONCILED entry's own call_id: %d" % sum(same_call.values()))
    lines.append("## status date (tolerance %.0f s): entries outside the bounds: %d" % (TOLERANCE, sum(date_fail.values())))
    for name, values in sorted(margins.items()):
        if values:
            lines.append("  %s: n=%d min %.3f max %.3f" % (name, len(values), min(values), max(values)))
    lines.append("## capability confirmation key (cnf)")
    for name, count in cnf.items():
        lines.append("  %s: %d" % (name, count))
    text = "\n".join(lines) + "\n"
    sys.stdout.write(text)
    if out_path:
        with open(out_path, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(text)


if __name__ == "__main__":
    main()
