# Custody on build 3: witness enrollment, rollback anchors, restart segments, signed witness status, freshness and run completeness

20 runs on 2026-10-20, 14:53:43-15:07:52 UTC: 15 in flag mode (the canonical
run plus 14 repeats, 2 of them under a process monitor) and 5 in deny mode.
After them came the relay probe of the signed run status (15:08:08-15:10:22).

This is the build-2 custody experiment (`../../build2/custody/RESULTS.md`,
2026-10-10) repeated on **frozen build 3**: commit `8a30fd4` of
`claude/supervisor-demo`, the six reproducible binaries in
`<singlebuild3>/bin`, SHA-256 in `build-manifest.txt`. Nothing was rebuilt,
and no test build was needed.

It answers review 5, required revision 2 ("require authenticated witness
enrollment and continuation linkage"), and gives the measured part of
required revision 3 (custody assumptions). Build 2 listed registration
preemption and substitution as "not measured"; section 4 measures them at
the witness interface.

## Headline

- **All 20 runs passed.** Each passed 9/9 revision checks (180/180).
- **No build-2 outcome changed.** `compare_build2.json` compares every cell
  with build 2:
  - 110/110 matrix cells (36 in process, 74 CLI), outcome counts and
    failing checks;
  - 74/74 rollback cells;
  - 160/160 tamper-lab rows;
  - 110/110 derived-dimension cells (assurance, `head_fresh`,
    `run_complete` and the Missing kinds listed);
  - 14/14 relay-probe cells (outcomes, failing checks, `head_fresh`,
    `run_complete`).

  The only differing values are two timings and the witness's answers to
  the registration probes (section 4), which the new enrollment rule
  changes on purpose.
- **Witness enrollment works as specified: every registration without the
  gateway's enrollment key was refused.**

  | probe (20 runs) | build 2 | build 3 |
  |---|---|---|
  | `agentgate-eval` enrollment probes: new run ID unsigned / forged signature, the run's ID with other keys, false continuation unsigned / forged (5 per run) | did not exist | **refused 100/100** (403 `enrollment`); no trace left 20/20 |
  | `probe.py`, build 2's five registrations sent unchanged (unsigned) | 409 `run_conflict` 20/20, 200 idempotent 20/20, 409 `continuity` 40/40, 200 idempotent 20/20 | **403 `enrollment` 100/100** |
  | the same five registrations signed with the gateway's enrollment key (new) | – | **build 2's answers 100/100**: 409 `run_conflict` 20/20, 200 idempotent 20/20, 409 `continuity` 40/40, 200 idempotent 20/20 |
  | witness store copy unchanged after the probes | 20/20 | 20/20 |

  The witness key equals the key the gateway pinned 20/20. The signed run
  status is format v2 and names the gateway's enrollment key in 40/40
  statuses (both segments), with a signature that verifies under
  independent code (`status_sig.py`) 40/40.
- **Freshness and run completeness: every build-2 number holds.**
  - `head_fresh` passes 180/180 CLI and 100/100 in process with the live
    witness, and 0/1,300 CLI and 0/620 in process with any other anchor.
  - `run_complete` passes only for the clean whole run with the live
    witness: 20/20 CLI, 20/20 in process. It passes on tampered evidence
    0/1,300 CLI and 0/600 in process, and fails on clean evidence 0/120
    CLI and 0/120 in process.
  - With the live witness, the withheld segment gives `run_complete` fail
    40/40 CLI and 40/40 in process.
  - Without the live witness, every ANCHORED verdict reports `head_fresh`
    and `run_complete` not_checked and lists a `freshness` entry: 200/200
    CLI, 140/140 in process.
- **New report: keys anchored for the newest segment only** (section 7).
  - 100/1,480 CLI and 20/720 in-process verifications list it. Each one
    pins the segment's keys and has neither a matching head anchor of the
    newest log nor the live witness status.
  - In those verifications `anchored_keys` is not_checked. Before, the
    newest segment's keys pin counted for the earlier segment.
  - In the clean whole run with only the segment's keys pinned, this
    changed `anchored_keys` from pass to not_checked (20/20). No verdict
    and no assurance level changed.
  - The new earlier-segment keys pin worked as specified in every one of
    its 120 verifications (6 cells × 20 runs):
    - the genuine earlier keys gave `anchored_keys` pass 20/20;
    - a wrong earlier fingerprint failed `keys.anchor` 20/20;
    - a pin given for a run of one segment failed `keys.anchor` 20/20.
- **The other build-3 verifier changes ran on genuine evidence only, and
  they refused none of it** (section 8):
  - 20 RECONCILED entries were accepted under the new status-date and
    status-order rules.
  - No operation was pending with a capability in any of the 2,200
    verifications (no `unresolved` Missing entry).
  - The capability's `cnf` key passed in all 120 clean CLI verifications.
  - The new continuation linkage refused no genuine witness answer:
    `head.witness` failed 0 times in the 180 CLI verifications with the
    live witness. It added its reason to one relay-probe refusal (20/20),
    whose outcome was the same as in build 2.

## 1. What was run

The commands are the build-2 commands. Only the binaries, the folders and
the witness start flag differ. Times are in `build-manifest.txt`.

```
# before and after the runs (recorded verbatim in build-manifest.txt)
py <singlebuild3>/check_manifest.py                      # 1870 files, 0 differ (14:53:29Z and 15:11:45Z)

# canonical run (from <repo>)
<singlebuild3>/bin/agentgate-eval.exe -host-label review-host custody \
    -work <work>/canonical/work -out docs/paper/data/build3/custody
# from this folder
python scripts/probe.py <singlebuild3>/bin <work>/canonical/work <work>/canonical/probe custody.json
sh scripts/repeat.sh <work> <repo>                     # 2 monitored + 12 flag + 5 deny
python scripts/status_probe.py <singlebuild3>/bin <work> custody.json \
    <work>/canonical/work <work>/canonical/probe .
python scripts/aggregate.py <work> custody.json <work>/canonical/probe <work>/agg
python scripts/tamper_lab.py <work> custody.json <work>/canonical/work tamper_lab.csv
python scripts/evidence_facts.py <singlebuild3>/bin <work> custody.json \
    <work>/canonical/work evidence_facts.csv evidence_facts_summary.json
python scripts/copy_process_observation.py <work> process_observation
# new for build 3
python scripts/compare_build2.py ../../build2/custody . compare_build2.json
python scripts/hide_work_path.py <work> <work>/raw-before-hide custody.json custody.md repeats.csv
```

`<work>` is `<repo>/.tools/build3-work/custody` (outside git).
`<work>/bin` is a directory junction to `<singlebuild3>/bin`, as in builds
1 and 2. `agentgate-eval` starts `agentgate-provider` and
`agentgate-witness` from that same folder. Every eval, monitor, probe and
analysis step exited 0. The per-run evidence (work folders, probe folders,
raw stdout) stays in `<work>`.

**The method is unchanged** (build-2 RESULTS.md §1). Each run executes the
demo self-test with the operation journal, using the provider and the witness
as separate processes:

- the self-test runs every scenario, the tamper lab, a witness outage and
  a gateway restart with a 4-entry restart segment registered at the
  witness, plus 9 revision checks;
- `agentgate-eval custody` then verifies 36 evidence × anchor cells in
  process;
- `probe.py` runs the witness probes, builds the extra rollback and segment
  variants, runs 74 CLI cells per run and checks the signed run status;
- `status_probe.py` puts a loopback relay in front of a witness on a copy
  of each run's store (14 cells per run).

**What build 3 adds to the runner.** `agentgate-eval custody` itself:

- restarts the witness with the gateway's enrollment public key;
- reads the witness through a client pinned to the saved witness key;
- records five enrollment probes of a party without the enrollment private
  key, before the matrix (section 4).

**Script changes for build 3.** These are additions only. Build 2's
versions are in `../../build2/custody/scripts/`.

- `probe.py`:
  - Both witness starts pass `-enroll-key`, because the build-3 witness
    does not start without it.
  - Build 2's five registration probes are sent unchanged. The same five
    are then sent signed with the gateway's enrollment key (new,
    `enroll_sig.py`).
  - An error answer to the two "own keys.json" probes now keeps the
    witness's code. Build 2 replaced that body with a message, but build 2
    never got an error there.
  - The status checks record the format and `enrollment_kid`.
  - The CLI rows gain `anchored_keys`, `keys_newest_only` and
    `witness_enrollment_kid_matches`.
  - New `earlier_keys_probe`: 6 CLI verifications per run, outside the 74
    cells.
- `status_sig.py`: also checks run status v2, which has its own label and
  `enrollment_kid` as the 16th signed field. The v1 path is unchanged.
- `status_probe.py`: the witness copy gets `-enroll-key`, and the rows gain
  `witness_enrollment_kid_matches`.
- `aggregate.py`: enrollment and earlier-segment keys columns, the new
  `keys_anchor_by_cell.csv`, and two new summary blocks, `enrollment` and
  `earlier_segment_keys`.
- New scripts:
  - `enroll_sig.py`: Ed25519 signing in pure Python, checked against
    RFC 8032 test 1 at import;
  - `compare_build2.py`: `compare_build1.py` with build 2 as the base,
    plus the build-2 columns;
  - `hide_work_path.py`, which replaces a repository-relative work path
    with `<work>`. The reason is in section 10.
- Unchanged: `repeat.sh`, `tamper_lab.py`, `monitor-run.ps1`,
  `evidence_facts.py` and `copy_process_observation.py`.
- Every variant, anchor, cell and outcome rule is the same as in build 2.

## 2. Self-test, tamper lab and matrices

Every number in this section equals build 2 (and build 1).

- **Self-test:** passed 20/20, with 9/9 revision checks in each run. The
  check IDs are the same as in build 2.
- **Tamper lab** (`tamper_lab.csv`, 160 rows, identical to build 2):
  - 7 ordinary edits per run: detected 140/140 without anchors and 140/140
    with keys and head pinned;
  - the coherent rollback: detected 0/20 without anchors, 20/20 with them.
- **In-process matrix** (36 cells × 20 runs = 720 verifications):
  - tampered: 300/600 detected;
  - **false alarms on clean evidence: 0/120**;
  - clean evidence reaching ANCHORED: 60/120.
  - The 300 undetected verifications are the same cells as in builds 1 and
    2:
    - the withheld segment under 6 anchor conditions, with either journal;
    - the folder-journal rollback under none, keys only and the stale
      head.
- **CLI cross-check:** agrees with the in-process verifier on 720/720 shared
  verifications.
- **Extended CLI matrix** (74 cells × 20 runs = 1,480 verifications):
  - **clean: 120/120 accepted, 0 false alarms**;
  - wrong-run anchor: 60/60 refused (`head.witness`);
  - tampered: 740/1,300 detected (560 not detected);
  - every cell gave the same result in all 20 runs (`matrix_stability.csv`).

## 3. Rollback, restart segments and the withheld segment (CLI, out of 20 runs)

The detection tables of build-2 RESULTS.md §3 and §4 hold unchanged, cell by
cell. `rollback_by_anchor.csv` equals build 2's in 74/74 cells, and
`dimensions_by_cell.csv` equals it in 110/110. The key facts:

- **The folder rollback (R1, rollback to #168 of 183; deny #159 of 174):**
  - undetected without anchors, with the keys pinned, and with the saved
    stale witness head (ANCHORED 20/20, `head_fresh` not_checked,
    `run_complete` not_checked, freshness entry);
  - detected 20/20 with the latest witness head (saved or live), the head
    pin, or keys + head.
- **The segment:**
  - **Registration: 20/20.** The witness registered the segment as the
    continuation, cosigned its heads #3 and #4, and its signed
    `GET /runs/{run}` names the segment in `continued_by`. The segment's
    `continues` equals its `run.json`.
  - The registration is now signed with the gateway's enrollment key and
    the witness accepted it. The status of both segments names that key
    (20/20).
- **The withheld segment (R5, R5j):**
  - detected 20/20 each with the live witness (`head.anchor`, `head_fresh`
    pass, `run_complete` fail);
  - not detected with the first run's pins or saved head (ANCHORED, 80/80
    qualified by the freshness entry);
  - the verify-time check: `--witness-url` on the first folder alone exited
    1 (`head.anchor`), with `head_fresh` pass and `run_complete` fail,
    20/20;
  - on the segment: exit 0, ANCHORED, `head_fresh` pass, `run_complete`
    pass, 20/20.
- **Against the stopped witness:** exit 2 (connection refused, 0.02-0.24
  s), 20/20. There is no fallback.

## 4. Witness enrollment (new in build 3; review 5, required revisions 2 and 3)

The build-3 witness registers a run or a continuation only when the request
is signed by a gateway enrollment key it was started with (`-enroll-key`;
`docs/demo/CONTRACTS.md`, "Witness enrollment"). It checks the signature
before it looks up the run ID. The gateway pins the key of the first witness
of its custody folder.

### 4.1 Registrations of a party without the enrollment key

These are the probes of `agentgate-eval custody`, 5 per run. Nothing is
signed; a forged signature is 64 random bytes.

| probe | refused with 403 `enrollment` |
|---|---|
| new run ID, unsigned (preemption of an unregistered ID) | 20/20 |
| new run ID, the gateway's enrollment key ID with a forged signature | 20/20 |
| the run's own ID with other keys, unsigned (substitution of the registered keys) | 20/20 |
| false continuation of the newest segment, unsigned | 20/20 |
| false continuation of the newest segment, forged signature | 20/20 |

- **Refused 100/100.** The witness's state was unchanged afterwards in
  20/20 runs:
  - no probed run ID became known;
  - the segment was not continued;
  - the run kept its registered keys, enrollment key, `continued_by` and
    latest head.

### 4.2 Build 2's registration probes, next to build 2

`probe.py` sends its five registration probes to a fresh witness on a copy
of the run's store, first exactly as build 2 did (unsigned) and then signed
with the gateway's enrollment key. A holder of that key is the gateway, or
any process of the same OS user.

| probe (20 runs each) | build 2 (unsigned) | build 3, unsigned | build 3, signed with the enrollment key |
|---|---|---|---|
| re-register this run ID with other keys | 409 `run_conflict` 20/20 | **403 `enrollment` 20/20** | 409 `run_conflict` 20/20 |
| re-register this run ID with its own keys.json | 200 idempotent 20/20 | **403 `enrollment` 20/20** | 200 idempotent 20/20 (same keys fingerprint, the gateway's enrollment key) |
| register a second continuation of the same run | 409 `continuity` 20/20 | **403 `enrollment` 20/20** | 409 `continuity` (already continued) 20/20 |
| register a continuation naming other keys for the earlier run | 409 `continuity` 20/20 | **403 `enrollment` 20/20** | 409 `continuity` 20/20 |
| re-register the segment with its own keys.json and continues | 200 idempotent 20/20 | **403 `enrollment` 20/20** | 200 idempotent 20/20 |

- Without the key, every registration is refused before the witness's other
  rules apply: 100/100. That includes the two that build 2's witness
  accepted as idempotent.
- With the key, build 2's rules still decide: 100/100 answers equal build
  2's. So enrollment is an additional gate in front of `run_conflict` and
  `continuity`, not a replacement for them.
- The witness probes that do not register (key, latest heads, rollback and
  forged-head pushes, the two signed statuses) answered as in build 2,
  20/20 each.
- The store copy was unchanged after all 10 registration probes: 20/20.
- **Combined:** 200/200 registrations without the enrollment key were
  refused (100 by the runner, 100 by `probe.py`).

### 4.3 Pinned identities and the signed status

| fact (20 runs) | result |
|---|---|
| the gateway's enrollment key exists in the custody folder; `probe.py` reads the same key ID as `custody.json` | 20/20 |
| the restarted witness's key equals the key the gateway pinned (`witness-pin.txt`), and the pin file equals the saved witness key | 20/20 |
| signed run status format `agentgate-witness-run-status/v2`, both segments | 40/40 |
| its signature verifies with the saved witness key (`status_sig.py`, independent code, v2 message) | 40/40 |
| its `enrollment_kid` is the gateway's enrollment key (the runner's check and `probe.py`'s) | 20/20 and 40/40 |
| `enrollment_kid` the CLI reports for a checked status equals the gateway's | 180/180 `--witness-url` verifications; relay 60/60 |

`agentgate-verify` reports the `enrollment_kid` it checked. It does not
compare it with an enrollment key given out of band (VERIFIER_CHECKS.md,
`head.witness`), so the comparison with the gateway's key above is the
probe's, not the verifier's.

### 4.4 What enrollment does not show here

- **A holder of the enrollment key registers like the gateway.**
  - The signed probes show this for the idempotent re-registrations.
  - A new run ID registered with the key was not sent, because it would
    change the witness copy's store, which build 2 checks to be unchanged.
    The unit test `registration_attack_test.go` covers it.
- **On one OS user account every process can read `enrollment-key.json`.**
  Enrollment keeps out a registrant that cannot read the gateway's files.
  It is not independent custody.
- **No race was run.** A party registering the gateway's own run ID before
  the gateway does was not tested: run IDs carry a random part, and the
  runner cannot schedule that race. The "new run ID" probes show the refusal
  such a party would meet.

## 5. The signed witness run status and the relay probe

### 5.1 What the witness answered (20 runs, both segments)

| fact (checked by `probe.py` and `status_sig.py`, not by AgentGate code) | first run | segment |
|---|---|---|
| format | `agentgate-witness-run-status/v2` 20/20 (build 2: v1) | v2 20/20 (build 2: v1) |
| signature verifies with the saved witness key | 20/20 | 20/20 |
| names the head that `GET /runs/{id}/latest` returned | 20/20 | 20/20 |
| `status_at` is after that head's `witnessed_at` | 20/20 | 20/20 |
| `continued_by` | the segment, 20/20 | absent, 20/20 |

- `status_at` was 0.3-1.4 ms before `probe.py` received the answer, over
  the 40 statuses (build 2: 0.3-1.7 ms).
- The witness-copy probe saw the same, and the store copy did not change
  (20/20).
- **CLI:** all 180 `--witness-url` verifications read the status as
  "checked"; 0 were "given; INVALID". 120 say "continued_by=the segment"
  and 60 say "not continued".

### 5.2 An intermediary that answers in the witness's place (`status_probe.csv`, 280 cells)

Outcomes, failing checks, `head_fresh` and `run_complete` are identical to
build 2 in 14/14 cells.

| relay answer | S0 (clean) | R5 (withheld) | R1 (rollback) | `head_fresh` / `run_complete` |
|---|---|---|---|---|
| unchanged (control) | **ANCHORED 20/20** | detected 20/20 (`head.anchor`) | detected 20/20 (`head.anchor`) | S0: **pass / pass**; R5, R1: pass / fail |
| `continued_by` removed | – | **detected 20/20** (`head.witness`) | – | fail / fail |
| status replaced by the old unsigned format | refused 20/20 | **detected 20/20** | – | fail / fail |
| the segment's genuine status served for the first run | – | **detected 20/20** | – | fail / fail |
| an earlier genuine head served as the latest, with the current status | refused 20/20 | detected 20/20 | **detected 20/20** | fail / fail |
| a genuine (head, status) pair served again 135-611.3 s after signing | refused 20/20 | detected 20/20 | – | fail / fail |
| status withheld (404) | – | exit 2, 20/20 | exit 2, 20/20 (with the stale head) | no report |

- Every changed or swapped answer was refused (`head.witness`): 180/180. A
  withheld status ended the CLI with exit 2: 40/40.
- Relay requests: 2 per cell in 220 cells and 6 in 60 cells, as in build 2.
  The witness store copies were unchanged: 20/20.
- **What build 3 changes in this table:** only the reasons, never the
  outcomes.
  - "The segment's genuine status served for the first run" is now refused
    for two reasons. One is build 2's run ID mismatch. The other is the new
    continuation linkage: the status records a continuation, but the
    verified chain records none (20/20).
  - The unsigned-format refusal now names both signed formats.
- **Not tested, as in build 2:**
  - a replay within the 2-minute window, which is accepted by design;
  - a genuine status from before the continuation was registered.

## 6. Freshness and run completeness (`head_fresh`, `run_complete`)

The build-2 tables of RESULTS.md §6 hold unchanged. `dimensions_by_cell.csv`
equals build 2 in 110/110 cells, including the Missing kinds each cell
lists. Over all 1,480 CLI verifications:

| anchor type | verifications | assurance / `head_fresh` / `run_complete` (count) |
|---|---|---|
| live witness (`--witness-url`) | 180 | ANCHORED / pass / pass 20 (S0); FAILED / pass / fail 160 |
| every other anchor (pins, saved heads, none, wrong run) | 1,300 | `head_fresh` not_checked 1,300; `run_complete` pass 0 |

- **`head_fresh`:**
  - pass 180/180 CLI and 100/100 in process with the live witness;
  - pass 0/1,300 CLI and 0/620 in process otherwise.
- **`run_complete`:**
  - pass only for S0 with the live witness: 20/20 CLI, 20/20 in process;
  - pass on tampered evidence 0/1,300 CLI and 0/600 in process;
  - fail on clean evidence 0/120 CLI and 0/120 in process.
  - In total CLI: pass 20, fail 800, not_checked 660; in process: 20 / 300
    / 400.
- **ANCHORED without the live witness:**
  - 200/200 CLI and 140/140 in process report `head_fresh` and
    `run_complete` not_checked and list a freshness entry.
  - This includes the saved stale head on R1 (20/20) and the first run's
    saved head or pins on the withheld segment (80/80).
- **The freshness entry is listed in 340 CLI and 220 in-process
  verifications**, as in build 2.
- **Build 3's pending rule changes nothing here.** It sends every operation
  that holds a capability and has no outcome to `run_complete` fail, but no
  such operation occurs (section 8).

## 7. Earlier-segment keys (new report in build 3)

Before build 3, a keys pin on the newest segment also counted for the earlier
segments. Their keys.json files are named only by the continuation record in
the newest segment's RUN_STARTED entry, which the newest segment's audit key
alone signs. Build 3 anchors the earlier segments' keys only in three ways:

- their own pins (`--expect-earlier-keys`);
- a head anchor of the newest log;
- the witness's signed status.

Otherwise `keys.anchor` warns, `anchored_keys` is not_checked, and
`missing` lists "Keys anchored for the newest segment only"
(VERIFIER_CHECKS.md `keys.anchor`).

**Where it appears in the matrix** (`keys_anchor_by_cell.csv`):

| cell (20 runs each) | verdict (unchanged from build 2) | newest-only entry, `anchored_keys` |
|---|---|---|
| S0 (whole run, clean), keys pinned (segment) | VERIFIED / CONSISTENT | listed 20/20, not_checked (build 2 in-process: pass) |
| R6 (segment + rolled-back first folder), keys pinned (segment) | FAILED (`files.continuity`, `provider.matches_audit`) | listed 20/20 |
| R7 (segment rolled back to #3), keys pinned (segment) | VERIFIED / CONSISTENT (not detected) | listed 20/20 |
| R7, keys+head pinned (segment) | FAILED (`head.anchor`) | listed 20/20 (the head pin does not match, so it anchors nothing) |
| R7, segment's saved witness head | FAILED (`head.anchor`) | listed 20/20 |
| in process: S0, keys pinned (segment) | VERIFIED / CONSISTENT | listed 20/20, not_checked |

- **Totals:** CLI 100/1,480, in process 20/720.
- **No other cell lists the entry.**
  - Single-segment folders (R1-R4, R5) have no earlier segment.
  - Every other segment cell has a head anchor or the live witness status,
    or no keys pin at all.
- **No verdict or assurance level changed.** ANCHORED needs a head anchor,
  and a head anchor covers the earlier segments.
- **In-process differences against build 2's canonical run:** 1 of 36
  cells. In S0 with only the segment's keys pinned, `anchored_keys` went
  from pass to not_checked and one `other` Missing entry was added. Every
  other field of all 36 cells is equal.

**The earlier-segment keys pin** (`probe.py` `earlier_keys_probe`, new,
6 CLI verifications per run):

| cell | expected | result (20 runs) |
|---|---|---|
| S0, segment keys pinned (= the matrix cell) | CONSISTENT, `anchored_keys` not_checked, entry listed | 20/20 |
| S0, segment keys + the first run's keys as `--expect-earlier-keys` | CONSISTENT, `anchored_keys` pass, no entry | 20/20 |
| S0, segment keys + another earlier fingerprint | FAILED `keys.anchor` | 20/20 (the wrong pin matches no segment and segment 1's keys match no pin) |
| S0, earlier keys pinned only | CONSISTENT, `anchored_keys` not_checked (the newest keys unpinned) | 20/20 |
| S0, segment keys + head + earlier keys | ANCHORED, `anchored_keys` pass | 20/20 |
| R5 (first folder alone), keys + earlier keys | FAILED `keys.anchor` (earlier pins for a run of one segment) | 20/20 |

So a verifier that holds both segments' keys fingerprints anchors the
earlier segment without a head anchor (20/20). A wrong earlier pin is
refused (20/20). An earlier pin on a folder that has no earlier segment is
refused too (20/20), so presenting the first folder alone against a
two-segment pin set is caught even without the witness.

## 8. Build-3 verifier and gateway changes: what this experiment exercises

| build-3 change | exercised here | result |
|---|---|---|
| status-date and status-order rules for RECONCILED (`op.outcome_resolved`) | 20 genuine RECONCILED-committed entries, 1 per run: the fault-injection payment whose response was lost and which an exact retry reconciled. Its observation was dated within the run, after an UNCERTAIN status | accepted in every verification of clean evidence (120/120 CLI, 120/120 in process); classification `issuer_only_reconciled` 1 per run, as in build 2 |
| pending or unresolved operations always reported incomplete | 2,200 verifications, including the first folder verified alone (a dead segment) | 0 `unresolved` Missing entries: no operation holds a capability without an outcome. The gateway restart came after the run closed |
| capability `cnf` compared with the adapter key | every capability of every run | `op.capability_bound` failed in none of the 1,480 CLI verifications (the only failing checks are `head.anchor`, `head.witness`, `files.continuity`, `provider.matches_audit`) and clean evidence was accepted 120/120 |
| witness continuation linkage (`head.witness`) | 180 CLI and 100 in-process live-witness verifications. In 60 CLI ones the chain holds the continuation (S0, R6, R7) | `head.witness` never failed on a genuine answer. The linkage added a reason to the relay's "other run's status" refusal (20/20) |
| earlier-segment keys pins and the newest-only report | section 7 | 100 CLI + 20 in-process entries; probe 120/120 as specified |
| witness enrollment and pinned witness key; run status v2 | section 4 | 200/200 unauthenticated registrations refused; build-2 rules behind it 100/100; v2 status 40/40 |
| 150 refusal sites (robustness) | not measured here | – |
| reproducible binaries | all six hashed before and after | equal to MANIFEST.txt, 6/6 |

**Not exercised:**

- the kill-suite binary;
- a RECONCILED entry with an adapter receipt (none occurs);
- a flagged replay (0/80 replayed answers are flagged, as in build 2);
- an ABSENT (`not_committed`) reconciliation.

## 9. Outage, probes, restarts, replayed answers and processes

- **Outage (20/20, unchanged).**
  - There is 1 WITNESS_UNAVAILABLE entry. Pushes: 31 succeeded, 1 failed.
  - The restarted witness caught up to #177 (deny #168).
  - In the witness history the outage is a jump of 9 entries, against
    ordinary jumps of up to 8.
- **Restarts (20/20, unchanged).**
  - The witness kept its key, and its latest head equals the saved anchor.
  - The provider kept its key, and its journal matches the folder: 14
    commits in flag mode, 11 in deny mode.
  - The gateway replayed 22 operations, and the provider commits stayed
    the same.
- **Replayed answers** (`evidence_facts.csv`, 40 run folders):
  - 80 CALL_RESULT entries, all COMMITTED with scope `call`: 3 in the
    first folder and 1 in the segment per run;
  - flag matches the decision 80/80, flagged 0/80.
  - Classification evidence per whole run: flag mode `issuer_adapter` 13,
    `issuer_only_reconciled` 1, `audit_only` 11 (15/15); deny mode 10 / 1
    / 14 (5/5).
  - All unchanged.
- **Process monitor** (2 runs, all listeners on 127.0.0.1;
  `process_observation/`).
  - The children appeared in the same order as in builds 1 and 2:
    1. the provider;
    2. the first witness (killed for the outage);
    3. the restarted witness;
    4. the provider for the gateway restart;
    5. the witness for the segment registration;
    6. the runner's post-run witness;
    7. the post-run provider.
  - Every witness command line now carries `-enroll-key` with the public
    enrollment key.
  - The post-run witness was up 0.85-1.07 s (build 2: 2.4-2.8 s).
  - The short post-run provider was seen in 2 of 2 runs (build 2: 2 of 2).
    In monitored-01 it lived 92 ms; in monitored-02 it was seen in one
    sample. Its listener was seen in both.

## 10. Comparison with build 2 (and build 1)

| measure (20 runs) | build 1 (2026-10-08) | build 2 (2026-10-10, eval `485e4ce0...`) | build 3 (2026-10-20, eval `cc4b9613...`) | why |
|---|---|---|---|---|
| self-test passed; revision checks | 20/20; 180/180 | 20/20; 180/180 | 20/20; 180/180 | – |
| tamper lab: ordinary edits; rollback without / with anchors | 140/140; 0/20 / 20/20 | the same | the same; 160/160 rows identical | – |
| in-process matrix | 300/600, 0/120 false alarms, 60/120 ANCHORED | the same | the same (110/110 cells equal) | – |
| CLI matrix | 1,480; clean 120/120; wrong-run 60/60; tampered 740/1,300 | the same | the same (74/74 cells equal) | – |
| CLI = in-process | 720/720 | 720/720 | 720/720 | – |
| `head_fresh` live / other | not reported | 180/180 / 0/1,300 (CLI); 100/100 / 0/620 | the same (110/110 dimension cells equal) | – |
| `run_complete` pass: S0 live / tampered; fail on clean | not reported | 20/20 / 0/1,300; 0/120 | the same | – |
| withheld segment via `--witness-url`: detected; `run_complete` fail | 20/20 each | 40/40; 40/40 | 40/40; 40/40 | – |
| ANCHORED without live witness qualified by the freshness entry | – | 200/200 CLI, 140/140 in process | the same | – |
| relay probe: changed answers refused; withheld status exit 2; control | 180/180; 40/40; 20/20 | the same | the same (14/14 cells equal) | – |
| relay "other run's status" refusal reason | run ID mismatch | run ID mismatch | run ID mismatch **and** continuation linkage (20/20) | new code (continuation linkage) |
| registrations without the enrollment key | no enrollment | no enrollment; 409/200/409/409/200 (100 probes) | **403 `enrollment` 100/100** (probe.py) + **100/100** (runner's probes) | new code (authenticated enrollment) |
| the same registrations signed with the enrollment key | – | – | build 2's answers 100/100 | new measurement |
| witness key equals the gateway's pin; status names the gateway's enrollment key | – | – | 20/20; 40/40 (CLI 180/180) | new code (pinned witness, status v2) |
| signed status format; independent signature check | v1; 20/20 per segment | v1; 20/20 per segment | **v2**; 20/20 per segment | new code (status v2); `status_sig.py` extended for v2 |
| registration preemption and substitution | not measured | not measured | refused without the key: new ID 40/40, substituted keys 40/40, false continuation 80/80 | new measurement |
| "Keys anchored for the newest segment only" | – | – | CLI 100/1,480, in process 20/720 | new code (earlier-segment keys rule) |
| S0, segment keys pinned only: `anchored_keys` | pass | pass (in process) | **not_checked** (20/20), one more `other` Missing entry | new code; verdict and assurance unchanged |
| earlier-segment keys pin (`--expect-earlier-keys`) | – | – | as specified 120/120 | new code, new measurement |
| `probe_witness_statuses` key of `repeats_summary.json` | 15 answers | 15 answers | 20 answers (5 signed probes appended; the 5 unsigned now 403) | new code + new measurement |
| status lag (`status_at` to the probe's receipt) | 0.3-1.3 ms | 0.3-1.7 ms | 0.3-1.4 ms | timing; the only differing key of `repeats_summary.json` besides `probe_witness_statuses` (63/65 equal) |
| replayed (head, status) pair age | 135-420 s | 135-584.5 s | 135-611.3 s | timing (the canonical pair is older when replayed); outcome the same |
| genuine RECONCILED entries accepted under the date/order rules | (no rule) | (no rule) | 20/20 | new code, exercised on genuine evidence |
| post-run witness lifetime (monitor) | 0.9-1.0 s | 2.4-2.8 s | 0.85-1.07 s | shared machine; not a behaviour change |
| per-run time | 7.6-17.1 s | 4.5-42.6 s | 4.4-24.1 s | shared machine (other build-3 experiments ran at the same time); not a performance result |
| binaries | not reproducible | not reproducible | reproducible; 6/6 equal to MANIFEST.txt before and after | new build procedure |

**Compiled module files changed against build 2** (from the two manifests,
listed in `build-manifest.txt`): 19 changed and 2 added, 0 removed:

- `internal/headwitness/enrollment.go` and `pin.go` are new;
- changed: `client.go`, `http.go`, `process.go` and `witness.go` in
  `internal/headwitness`; 10 files of `internal/auditverify`;
  `internal/demo/custody.go` and `segment.go`; and the `main.go` (or
  `custody.go`) of `agentgate-eval`, `agentgate-verify` and
  `agentgate-witness`.

## 11. Open issues

From build 2 §9:

1. **(eval live anchor without a fetch time).** Closed in build 2;
   `head_fresh` passes in process 100/100.
2. **Still by design.** A stale witness head given as a file yields
   ANCHORED, marked unfresh (20/20). Requiring `run_complete` = pass
   rejects it.
3. **(withheld-segment gap in `missing`).** Closed in build 2; 40/40.
4. **`internal/headwitness`:**
   - **Registration is now authenticated.** 200/200 registrations without
     the enrollment key were refused, and the registration rules still
     apply with the key (100/100). A holder of the key, which on one user
     account means any process of that user, still registers like the
     gateway.
   - **Clock assumption.** The one-clock assumption is now stated in every
     report's `assumptions`. Clocks were still not varied here.
   - **`Client.Registration`** still returns the registration without
     checking a signature. The runner and the demo read the status through
     `Client.RunStatus` on a pinned client, which does check it.
5. **Unchanged.**
   - There is no live-journal variant of the segment.
   - The segment pins are read from the folder.
   - `started_at` (14:53:53Z) is taken after the self-test, while the run
     ID says 14:53:43Z.
6. **Outside this folder.** The paper and the build summary should take the
   enrollment results (section 4), the earlier-segment keys report
   (section 7) and the build-3 hashes from here.

**Minor observations.** These are reporting texts only; no number is
affected.

- **Still present from build 2:**
  - For a saved witness head that mismatches the log, the `head_fresh`
    reason still says "anchored by a saved witness head".
  - The `custody.md` header still says that every cell anchored by a pin
    or a saved head lists the freshness gap. In the data this holds only
    when the anchor matches the log end.
- **New: a work path the eval does not hide.** `agentgate-eval` hides only
  the absolute work folder. With the work folder inside the repository
  (`<repo>/.tools/build3-work`, as required here), the demo names it
  relative to the repository, so 4 texts in `custody.json` / `custody.md`
  and 20 in `repeats.csv` showed `.tools/build3-work/...`.
  `hide_work_path.py` replaced exactly those folder names with `<work>`;
  the unmodified files are in `<work>/raw-before-hide`. In build 2 the
  work folder was outside the repository.
- **Fixed in the script.** Build 2's `probe.py` replaced the body of an
  answer to the "own keys.json" probes with a message even when the
  witness refused, which would have hidden the refusal code. Build 2 never
  got a refusal there. Build 3's `probe.py` keeps the code.

## 12. Caveats

- **One machine, one user account.**
  - The provider and the witness are separate processes, not separate
    custodians.
  - The enrollment key, the witness key file and the witness pin are files
    that any process of the same user can read.
  - Authenticated enrollment keeps out a registrant that cannot read the
    gateway's files (for example another account, or anything that only
    reaches the loopback port). It does not establish independent custody.
- **The probes model a party without the key by not signing.**
  - The forged signatures are random bytes.
  - The signed probes use the gateway's own key, read from the custody
    folder.
- **Elapsed times are not performance results.** Other build-3 experiments
  ran at the same time.
- **Same code.** The derived dimensions and the keys report are computed by
  the same `internal/auditverify` code in the CLI and in process. Only the
  status signature (v1/v2) and the enrollment signatures were checked or
  made by independent code (`status_sig.py`, `enroll_sig.py`).
- **Freshness assumes agreeing clocks.** The witness and the verifier share
  one clock here.
- **A replay within 2 minutes is accepted by design.**
- **Narrow failure cases.** Only one witness hard kill and one gateway
  restart per run were exercised.
- **The scripts were extended.** The additions send or read new things
  only, and build 2's versions are kept in `../../build2/custody/scripts/`.

## 13. Files

| file | contents |
|---|---|
| `custody.json`, `custody.csv`, `custody.md` | the canonical flag run (the tool's output, 36 cells, with the enrollment facts and probes; work paths hidden, section 11) |
| `witness_probe.json` | the canonical run's `probe.json`: witness and registration probes (unsigned and signed), signed statuses (format, `enrollment_kid`), live witness, verify-time checks, rollback probe, `enrollment`, `earlier_keys_probe` |
| `cli_crosscheck.csv` | the canonical run's 74 CLI cells, with `head_fresh`, `run_complete`, `missing_kinds`, `anchored_keys`, `keys_newest_only`, `witness_enrollment_kid_matches` |
| `status_probe.csv`, `status_probe_summary.json` | the relay probe: 14 cells per run plus the store-copy check, 20 runs |
| `repeats.csv`, `repeats_summary.json` | one row per run (20) and the summary with denominators, including `derived_dimensions`, `enrollment` and `earlier_segment_keys` |
| `matrix_stability.csv`, `rollback_by_anchor.csv`, `dimensions_by_cell.csv` | every cell over the 20 runs, in the build-2 format |
| `keys_anchor_by_cell.csv` | new: `anchored_keys` and the newest-only entry per cell over the 20 runs (in process and CLI) |
| `tamper_lab.csv` | the self-test tamper lab of the 20 runs |
| `evidence_facts.csv`, `evidence_facts_summary.json` | the 80 replayed answers and the classification-evidence counts per run |
| `compare_build2.json` | new: the cell-by-cell comparison with `../../build2/custody/` |
| `process_observation/` | the 2 monitored runs (process tree, listeners), paths replaced by `<exp>` |
| `scripts/` | build 2's scripts: `probe.py`, `status_sig.py`, `status_probe.py` and `aggregate.py` extended; `repeat.sh`, `tamper_lab.py`, `monitor-run.ps1`, `evidence_facts.py` and `copy_process_observation.py` unchanged. New: `enroll_sig.py`, `compare_build2.py`, `hide_work_path.py` |
| `build-manifest.txt` | the six binaries' SHA-256, `check_manifest.py` before and after (with timestamps), the source check, commands, times, the script changes, the 19 changed and 2 added module files against build 2, and the 258 compiled module files |

The per-run evidence stays outside the repository, in `<work>` =
`<repo>/.tools/build3-work/custody/`: work folders, probe folders, raw
stdout, `logs/` and `raw-before-hide/`.
