# Custody: provider and witness processes

One demo run on one machine with the provider and the witness as separate local processes (separate keys and directories, same user account and disk). The witness registers only runs signed with the gateway's enrollment key, and the gateway pins the witness key; both keys are files any process of the same user can read. It demonstrates the custody boundary of this prototype; it is not independent organisational custody.

Command: `agentgate-eval -host-label review-host custody -work <work> -out docs/paper/data/build3/custody`. Elapsed 10.7 s.

## Method

- demo.RunSelfTest with Durable, ProviderExecutable, WitnessExecutable: every scenario, the witness outage (the self-test kills the witness, runs one action, restarts it), a gateway restart on the operation journal with a restarted provider process, and the tamper lab.
- After the run: the provider process and the witness are restarted on their own directories and queried over loopback HTTP (GET /key, GET /journal; GET /runs/{id}/latest, /heads and GET /runs/{id}, the run status with continued_by and enrollment_kid). The witness keeps running through the verification matrix.
- Witness enrollment: the witness is restarted with the gateway's enrollment public key from the demo's custody folder and read through a client pinned to the witness key saved with the run. Enrollment probes (a party without the enrollment private key; nothing is signed, a forged signature is random bytes): a new run ID unsigned and with a forged signature, the run's own ID with other keys, a false continuation of the newest segment unsigned and with a forged signature. Each must be refused with the witness's enrollment error and leave the witness's state unchanged; they run before the matrix.
- Variants: the restart segment (newest folder, verified with the first folder it continues: the whole run); the first folder presented alone (the restart segment withheld, counted as tampered); a coherent rollback of the first folder; each with the live provider journal.
- Rollback: auditverify.TamperRollback applied to a copy, restoring the earlier head.json and provider journal the tamper lab saved for this run.
- Live provider journal: the copy's provider-journal.json is replaced by the restarted provider process's GET /journal.
- Pinned values: the first run's are the ones the demo process held (keys fingerprint at startup, head after shutdown); the segment's are SHA-256 of its keys.json and its last entry hash, taken from the genuine folder after the run. Witness anchors: the saved latest cosigned head (a file, without the run status), and 'witness latest via --witness-url': the latest cosigned head and run status fetched from the running witness when the cell is verified, as agentgate-verify --witness-url does, verified in process. The witness key is the one saved outside the run folder.

## The run

Self-test: passed (SELF-TEST PASSED in autonomous flag mode with provider process + witness (16/16 scenarios, 2 skipped as human-approval only, 3/3 custom requests, verifier VERIFIED / ANCHORED, 8/8 tamper attacks detected, 9/9 revision checks)). Console: `<work>/selftest-console.txt`.

| self-test custody check | result | detail |
|---|---|---|
| Signed delegation grant recorded at startup | pass | grant grant-20261020-145343-30a1ee, budgets AED 100,000.00, USD 3,000.00, valid until 2026-10-21T14:53:43Z |
| Fault injection: provider response lost, then an exact retry reconciles | pass | UNCERTAIN -> exact retry -> COMMITTED (reconciled); provider effects 1 (want 1) |
| Witness outage: the gateway keeps running and records WITNESS_UNAVAILABLE | pass | 1 WITNESS_UNAVAILABLE entry; after the restart the witness caught up to entry #177 |
| Provider in its own process with its own key and journal | pass | pid 3432 at http://127.0.0.1:64120, 14 signed commits, state in <work>/custody/provider |
| Revoking the grant stops the next action (DEL-REVOKED) | pass | revoked through POST /api/delegation/revoke; the next AED 100.00 payment was denied (DEL-REVOKED) |
| Verifier assurance: ANCHORED, every dimension passes | pass | ANCHORED (structural=pass, decisions_authenticated=pass, policy_replayed=pass, provider_reconciled=pass, delegation_respected=pass, anchored_keys=pass, anchored_head=pass) |
| Closed run verified with the witness's cosigned head as its only anchor | pass | VERIFIED / ANCHORED from <work>/custody/anchors/run-20261020-145343-30a1ee/witness-head.json |
| Restart on the operation journal: stored outcome, no new provider effect, budget and revocation restored, continuation segment | pass | 22 operations replayed; retry answered COMMITTED from the journal; provider commits 14 -> 14; budget used AED 36,100.00, USD 2,800.00; grant revoked: true; continuation segment <work>/runs/run-20261020-145353-3a0873 (continues run-20261020-145343-30a1ee at 3cffbb404f66…, 4 entries); segment verification VERIFIED / ANCHORED |
| Continuation segment registered with the witness; its live cosigned head anchors the restarted run | pass | run run-20261020-145343-30a1ee continued by run-20261020-145353-3a0873 at the witness; live cosigned head #4 of the segment: VERIFIED / ANCHORED over 2 segments (anchor saved in <work>/custody/anchors/run-20261020-145353-3a0873/witness-head.json) |

## After the run

| fact | value |
|---|---|
| final audit head (seq) | 183 |
| WITNESS_UNAVAILABLE entries in the log | 1 |
| witness: latest cosigned seq after its restart | 183 |
| witness: latest after restart equals the saved anchor | yes |
| witness: same key after restart | yes |
| witness: cosigned heads in its history | 31 |
| witness: run status of the first run, continued_by | run-20261020-145353-3a0873 |
| witness: continued_by names the restart segment | yes |
| gateway enrollment key (kid) | 76feb7ec878595becb49b2e8a9e34ae1bc3033a716d8313695f1bd72e5e510cb |
| witness: run status enrollment_kid equals the gateway's | yes |
| witness: key after restart equals the key pinned for the custody folder | yes |
| enrollment probes refused with the enrollment error | 5 of 5 |
| enrollment probes left the witness's state unchanged | yes |
| restart segment: run / entries / witness latest cosigned seq | run-20261020-145353-3a0873 / 4 / 4 |
| provider: key after restart equals keys.json SIMULATOR_PROVIDER | yes |
| provider: commits in its own journal after restart | 14 |
| run folder provider-journal.json commits | 14 |
| rollback copy: cut to seq / provider commits | 168 / 13 |
| stale witness anchor seq | 168 |

## Enrollment probes (no enrollment private key)

| registration | refused (enrollment) | witness answer |
|---|---|---|
| new run ID, unsigned | yes | headwitness: the registration is not signed by an enrolled gateway key: registration of run run-probe-48d2a94a-new carries no enrollment signature; this witness registers only runs signed by an enrolled gateway key (HTTP 403) |
| new run ID, gateway's enrollment key ID with a forged signature | yes | headwitness: the registration is not signed by an enrolled gateway key: registration of run run-probe-48d2a94a-new: the enrollment signature does not verify with enrollment key 76feb7ec878595becb49b2e8a9e34ae1bc3033a716d8313695f1bd72e5e510cb (HTTP 403) |
| the run's own ID with other keys, unsigned | yes | headwitness: the registration is not signed by an enrolled gateway key: registration of run run-20261020-145343-30a1ee carries no enrollment signature; this witness registers only runs signed by an enrolled gateway key (HTTP 403) |
| false continuation of the newest segment, unsigned | yes | headwitness: the registration is not signed by an enrolled gateway key: registration of run run-probe-48d2a94a-continuation carries no enrollment signature; this witness registers only runs signed by an enrolled gateway key (HTTP 403) |
| false continuation of the newest segment, gateway's enrollment key ID with a forged signature | yes | headwitness: the registration is not signed by an enrolled gateway key: registration of run run-probe-48d2a94a-continuation: the enrollment signature does not verify with enrollment key 76feb7ec878595becb49b2e8a9e34ae1bc3033a716d8313695f1bd72e5e510cb (HTTP 403) |

## Verification matrix

head fresh / run complete: the verifier's derived dimensions; missing: the kinds of the gaps it lists (every cell anchored by a pin or a saved head lists the freshness gap).

| evidence | anchors | verdict | assurance | outcome | failing checks | head fresh / run complete | missing |
|---|---|---|---|---|---|---|---|
| continuation segment withheld (earlier folder presented as the whole run) | none | VERIFIED | CONSISTENT | NOT detected |  | not_checked / not_checked | issuer_only other |
| continuation segment withheld (earlier folder presented as the whole run) | keys pinned | VERIFIED | CONSISTENT | NOT detected |  | not_checked / not_checked | issuer_only other |
| continuation segment withheld (earlier folder presented as the whole run) | head pinned | VERIFIED | CONSISTENT | NOT detected |  | not_checked / not_checked | freshness issuer_only other |
| continuation segment withheld (earlier folder presented as the whole run) | keys+head pinned | VERIFIED | ANCHORED | NOT detected |  | not_checked / not_checked | freshness issuer_only other |
| continuation segment withheld (earlier folder presented as the whole run) | witness latest cosigned head | VERIFIED | ANCHORED | NOT detected |  | not_checked / not_checked | freshness issuer_only other |
| continuation segment withheld (earlier folder presented as the whole run) | witness latest via --witness-url | FAILED | FAILED | detected | head.anchor | pass / fail | issuer_only other |
| continuation segment withheld (earlier folder presented as the whole run) | stale witness head (#168) | VERIFIED | CONSISTENT | NOT detected |  | not_checked / not_checked | issuer_only other |
| continuation segment withheld (earlier folder presented as the whole run) | head pinned = run's final head (segment) | FAILED | FAILED | detected | head.anchor | not_checked / fail | issuer_only other |
| coherent rollback | none | VERIFIED | CONSISTENT | NOT detected |  | not_checked / not_checked | issuer_only other |
| coherent rollback | keys pinned | VERIFIED | CONSISTENT | NOT detected |  | not_checked / not_checked | issuer_only other |
| coherent rollback | head pinned | FAILED | FAILED | detected | head.anchor | not_checked / fail | issuer_only other |
| coherent rollback | keys+head pinned | FAILED | FAILED | detected | head.anchor | not_checked / fail | issuer_only other |
| coherent rollback | witness latest cosigned head | FAILED | FAILED | detected | head.anchor | not_checked / fail | issuer_only other |
| coherent rollback | witness latest via --witness-url | FAILED | FAILED | detected | head.anchor | pass / fail | issuer_only other |
| coherent rollback | stale witness head (#168) | VERIFIED | ANCHORED | NOT detected |  | not_checked / not_checked | freshness issuer_only |
| continuation segment withheld (earlier folder presented as the whole run) + provider journal from the provider process | none | VERIFIED | CONSISTENT | NOT detected |  | not_checked / not_checked | issuer_only other |
| continuation segment withheld (earlier folder presented as the whole run) + provider journal from the provider process | keys pinned | VERIFIED | CONSISTENT | NOT detected |  | not_checked / not_checked | issuer_only other |
| continuation segment withheld (earlier folder presented as the whole run) + provider journal from the provider process | head pinned | VERIFIED | CONSISTENT | NOT detected |  | not_checked / not_checked | freshness issuer_only other |
| continuation segment withheld (earlier folder presented as the whole run) + provider journal from the provider process | keys+head pinned | VERIFIED | ANCHORED | NOT detected |  | not_checked / not_checked | freshness issuer_only other |
| continuation segment withheld (earlier folder presented as the whole run) + provider journal from the provider process | witness latest cosigned head | VERIFIED | ANCHORED | NOT detected |  | not_checked / not_checked | freshness issuer_only other |
| continuation segment withheld (earlier folder presented as the whole run) + provider journal from the provider process | witness latest via --witness-url | FAILED | FAILED | detected | head.anchor | pass / fail | issuer_only other |
| continuation segment withheld (earlier folder presented as the whole run) + provider journal from the provider process | stale witness head (#168) | VERIFIED | CONSISTENT | NOT detected |  | not_checked / not_checked | issuer_only other |
| continuation segment withheld (earlier folder presented as the whole run) + provider journal from the provider process | head pinned = run's final head (segment) | FAILED | FAILED | detected | head.anchor | not_checked / fail | issuer_only other |
| coherent rollback + provider journal from the provider process | none | FAILED | FAILED | detected | provider.matches_audit | not_checked / fail | issuer_only other |
| coherent rollback + provider journal from the provider process | keys pinned | FAILED | FAILED | detected | provider.matches_audit | not_checked / fail | issuer_only other |
| coherent rollback + provider journal from the provider process | head pinned | FAILED | FAILED | detected | head.anchor, provider.matches_audit | not_checked / fail | issuer_only other |
| coherent rollback + provider journal from the provider process | keys+head pinned | FAILED | FAILED | detected | head.anchor, provider.matches_audit | not_checked / fail | issuer_only other |
| coherent rollback + provider journal from the provider process | witness latest cosigned head | FAILED | FAILED | detected | head.anchor, provider.matches_audit | not_checked / fail | issuer_only other |
| coherent rollback + provider journal from the provider process | witness latest via --witness-url | FAILED | FAILED | detected | head.anchor, provider.matches_audit | pass / fail | issuer_only other |
| coherent rollback + provider journal from the provider process | stale witness head (#168) | FAILED | FAILED | detected | provider.matches_audit | not_checked / fail | freshness issuer_only |
| continuation segment (newest folder; earlier folder followed) | none | VERIFIED | CONSISTENT | accepted |  | not_checked / not_checked | issuer_only other |
| continuation segment (newest folder; earlier folder followed) | keys pinned (segment) | VERIFIED | CONSISTENT | accepted |  | not_checked / not_checked | issuer_only other |
| continuation segment (newest folder; earlier folder followed) | head pinned (segment) | VERIFIED | CONSISTENT | accepted |  | not_checked / not_checked | freshness issuer_only other |
| continuation segment (newest folder; earlier folder followed) | keys+head pinned (segment) | VERIFIED | ANCHORED | accepted |  | not_checked / not_checked | freshness issuer_only other |
| continuation segment (newest folder; earlier folder followed) | segment's witness latest cosigned head (saved) | VERIFIED | ANCHORED | accepted |  | not_checked / not_checked | freshness issuer_only other |
| continuation segment (newest folder; earlier folder followed) | witness latest via --witness-url | VERIFIED | ANCHORED | accepted |  | pass / pass | issuer_only other |
