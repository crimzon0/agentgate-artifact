"""Aggregate the canonical custody run and its repetitions (facts, matrices, probes).

Usage: python aggregate.py EXP CANONICAL_CUSTODY_JSON CANONICAL_PROBE_DIR OUTDIR
  EXP/runs/<name>/{out/custody.json, probe/probe.json, probe/cli_crosscheck.csv}
  are the repetitions; the canonical run's files are given explicitly.
Writes OUTDIR/repeats.csv, matrix_stability.csv, rollback_by_anchor.csv and
summary.json (every count with its denominator).

2026-10-08 verifier fix: also collects the in-process facts of the witness
run status (continued_by, segment pins) and the CLI check of --witness-url on
the earlier folder alone (the withheld segment, expected exit 1 head.anchor).

2026-10-08 single build: also collects the signed run status as checked by
probe.py (signature with its own Ed25519 code, the latest head it names,
signed after that head was cosigned, fetch lag) and how many --witness-url
CLI cells read a checked or an INVALID status.

Build 2 (2026-10-10, commit 86643d7): also collects the verifier's derived
dimensions head_fresh and run_complete and the kinds of the Missing entries
(in process: custody.json's dimensions / missing_by_kind; CLI: probe.py's new
columns) per cell into OUTDIR/dimensions_by_cell.csv, and the summary gains
"derived_dimensions": the three cases the reviewer asked about (live witness
fetch, saved stale witness head, withheld segment) plus the clean whole run,
each with its denominator. Everything else is unchanged.

Build 3 (2026-10-20, commit 8a30fd4): additions only, every build-2 output
column and file keeps its meaning:
  - repeats.csv gains the enrollment facts (custody.json: enrollment key,
    witness key equals the pin, run status enrollment_kid, the five
    enrollment probes and their trace check; probe.py: status formats, the
    signed registration probes, enrollment_kid seen by the CLI) and the
    earlier-segment keys report (cells listing "Keys anchored for the newest
    segment only", probe.py's earlier_keys_probe);
  - new OUTDIR/keys_anchor_by_cell.csv: anchored_keys and the newest-only
    entry per cell over the runs (in process and CLI);
  - summary.json gains "enrollment" and "earlier_segment_keys".
"""
import csv, glob, json, os, re, sys
from collections import Counter, defaultdict

exp, canonical_json, canonical_probe, outdir = sys.argv[1:5]
runs = [("canonical", canonical_json, canonical_probe)]
for d in sorted(glob.glob(os.path.join(exp, "runs", "*", ""))):
    name = os.path.basename(os.path.dirname(d))
    runs.append((name, os.path.join(d, "out", "custody.json"), os.path.join(d, "probe")))

def norm(text):
    return re.sub(r"#\d+", "#k", text)

def read_json(path):
    return json.load(open(path, encoding="utf-8"))

rows, eval_cells, cli_cells = [], defaultdict(Counter), defaultdict(Counter)
cli_outcomes = defaultdict(Counter)   # (variant, anchors) -> outcome counts
cli_failing = defaultdict(Counter)
# build 2: derived dimensions per cell (source, variant, anchors) -> Counter of "assurance|head_fresh|run_complete|freshness_missing"
dim_cells = defaultdict(Counter)
dim_kinds = defaultdict(Counter)      # missing kinds (count of cells listing each kind)
NEWEST_ONLY = "Keys anchored for the newest segment only"
keys_cells = defaultdict(Counter)     # build 3: (source, variant, anchors) -> Counter of "anchored_keys|newest_only"
earlier_probe = defaultdict(Counter)  # build 3: earlier_keys_probe cell -> Counter of "verdict/assurance|anchored_keys|failing|newest_only"
for name, cj, pdir in runs:
    d = read_json(cj)
    p = read_json(os.path.join(pdir, "probe.json"))
    f = d["facts"]
    mode = "deny" if "deny" in name else "flag"
    checks = d["selftest_revision_checks"]
    tampered = [c for c in d["verification_matrix"] if c["tampered"]]
    clean = [c for c in d["verification_matrix"] if not c["tampered"]]
    for c in d["verification_matrix"]:
        v = c["verification"]
        eval_cells[(c["variant"], norm(c["anchors"]))]["%s/%s" % (v["verdict"], v["assurance"])] += 1
        dm = v.get("dimensions") or {}
        kinds = sorted(k for k, n in (v.get("missing_by_kind") or {}).items() if n)
        key3 = ("in-process", c["variant"], norm(c["anchors"]))
        dim_cells[key3]["%s|%s|%s" % (v["assurance"], dm.get("head_fresh", "-"), dm.get("run_complete", "-"))] += 1
        for k in kinds or ["(none)"]:
            dim_kinds[key3][k] += 1
        newest = any(m.startswith(NEWEST_ONLY) for m in (v.get("missing") or []))
        keys_cells[key3]["%s|%s" % (dm.get("anchored_keys", "-"), "newest-only" if newest else "-")] += 1
    for e in p.get("earlier_keys_probe") or []:
        earlier_probe[e["cell"]]["%s/%s|%s|%s|%s" % (e["verdict"], e["assurance"], e["anchored_keys"], " ".join(e["failing"]) or "-",
                                                     "newest-only" if e["keys_newest_only"] else "-")] += 1
    ss = (p.get("live_witness") or {}).get("signed_status") or {}
    reg = (p.get("segment_witness") or {}).get("registration") or {}
    wu_rows = []
    for r in csv.DictReader(open(os.path.join(pdir, "cli_crosscheck.csv"), encoding="utf-8")):
        if "--witness-url" in r["anchors"]:
            wu_rows.append(r)
        key = (norm(r["variant"]), norm(r["anchors"]))
        cli_cells[key]["%s/%s" % (r["cli_verdict"], r["cli_assurance"]) if r["cli_exit"] != "2" else "exit 2"] += 1
        cli_outcomes[key][r["outcome"]] += 1
        cli_failing[key][r["cli_failing"] or "-"] += 1
        key3 = ("CLI",) + key
        assurance = r["cli_assurance"] if r["cli_exit"] != "2" else "exit 2"
        dim_cells[key3]["%s|%s|%s" % (assurance, r.get("head_fresh") or "-", r.get("run_complete") or "-")] += 1
        for k in sorted(set((r.get("missing_kinds") or "").split())) or ["(none)"]:
            dim_kinds[key3][k] += 1
        keys_cells[key3]["%s|%s" % (r.get("anchored_keys") or "-", "newest-only" if r.get("keys_newest_only") == "True" else "-")] += 1
    by_id = {c["id"]: c for c in checks}
    wu = by_id.get("witness-outage", {}).get("detail", "")
    rj = by_id.get("restart-journal", {}).get("detail", "")
    m = re.search(r"(\d+) operations replayed.*provider commits (\d+) -> (\d+).*, (\d+) entries\)", rj)
    outage = p["witness_history"]["outage"] or {}
    vto = p["verify_time_outage"]
    rows.append({
        "run": name, "mode": mode, "selftest_passed": d["selftest_passed"],
        "revision_checks_passed": "%d/%d" % (sum(c["passed"] for c in checks), len(checks)),
        "elapsed_s": d["elapsed_s"], "final_head_seq": f["final_head_seq"],
        "witness_unavailable_entries": f["witness_unavailable_entries"],
        "witness_caught_up_to": wu.split("#")[-1] if "#" in wu else "",
        "witness_pushes_ok": d["custody_view"]["pushes"], "witness_push_failures": d["custody_view"]["failures"],
        "witness_cosigned_heads": f["witness_cosigned_heads"], "witness_latest_seq": f["witness_latest_cosigned_seq"],
        "witness_key_same_after_restart": f["witness_key_same_after_restart"],
        "witness_latest_equals_saved_anchor": f["witness_latest_after_restart_equals_saved_anchor"],
        "witness_history_outage_jump": outage.get("jump"), "witness_history_max_other_jump": outage.get("max_other_jump"),
        "provider_kid_same_after_restart": f["provider_key_after_restart_equals_keys_json"],
        "provider_commits_process": f["provider_commits_after_restart"], "provider_commits_folder": f["run_folder_provider_journal_commits"],
        "restart_ops_replayed": m.group(1) if m else "", "restart_provider_commits_before": m.group(2) if m else "",
        "restart_provider_commits_after": m.group(3) if m else "", "segment_entries": m.group(4) if m else "",
        "segment_known_to_witness": (p["segment_run_id"] in p["witness_runs_in_store"]) if p["segment_run_id"] else "",
        "segment_registered_with_witness": (p["segment_run_id"] in p.get("witness_runs_registered", [])) if p["segment_run_id"] else "",
        "segment_cosigned_seqs": " ".join(str(x) for x in (p.get("segment_witness") or {}).get("cosigned_seqs", [])),
        "earlier_run_continued_by_segment": ((p.get("live_witness") or {}).get("earlier_run_continued_by") == p["segment_run_id"]) if p["segment_run_id"] else "",
        "segment_live_latest_seq": (p.get("live_witness") or {}).get("segment_latest_seq"),
        "restart_witness_check": ("pass" if by_id["restart-witness"]["passed"] else "FAIL") if "restart-witness" in by_id else "absent",
        "restart_witness_detail": re.sub(r"run-[0-9]{8}-[0-9]{6}-[0-9a-f]{6}", "run-X", by_id.get("restart-witness", {}).get("detail", ""))[:200],
        "segment_rollback_to": (p.get("segment_witness") or {}).get("rollback_to"),
        "rollback_seq": f["rollback_seq"], "rollback_folder_commits": f["rollback_folder_provider_journal_commits"],
        "stale_witness_seq": f["stale_witness_seq"],
        "eval_tampered_cells_detected": "%d/%d" % (sum(c["detected"] for c in tampered), len(tampered)),
        "eval_clean_cells_false_alarm": "%d/%d" % (sum(c["false_alarm"] for c in clean), len(clean)),
        "eval_clean_cells_anchored": "%d/%d" % (sum(c["anchored"] for c in clean), len(clean)),
        "notes": len(f["notes"]),
        "probe_witness_statuses": " ".join(str(x["http_status"]) + (":" + x["code"] if x["code"] else "") for x in p["witness_probe"]["probes"]),
        "probe_witness_store_unchanged": p["witness_probe"]["store_unchanged"],
        "live_witness_latest_seq": p["live_witness"]["latest_seq"],
        "live_witness_latest_equals_saved_anchor": p["live_witness"]["latest_equals_saved_anchor"],
        "live_witness_store_unchanged": p["live_witness"]["store_unchanged_by_restart_and_queries"],
        "probe_rollback_cut_to": p["rollback_probe"]["cut_to_seq"], "probe_last_effect_seq": p["rollback_probe"]["last_provider_effect_seq"],
        "probe_rollback_dropped": len(p["rollback_probe"]["dropped_stages"]),
        "verify_witness_url_witness_stopped_exit": vto.get("witness_stopped", {}).get("exit"),
        "verify_witness_url_on_segment_exit": vto.get("segment_witness_url", {}).get("exit"),
        "verify_witness_url_on_earlier_folder_exit": vto.get("earlier_folder_witness_url", {}).get("exit"),
        "verify_witness_url_on_earlier_folder_failing": " ".join(vto.get("earlier_folder_witness_url", {}).get("failing") or []),
        "eval_witness_run_continued_by_segment": f.get("witness_run_continued_by_segment"),
        "eval_segment_witness_latest_seq": f.get("segment_witness_latest_seq"),
        "eval_segment_head_seq": f.get("segment_head_seq"),
        "eval_witness_pid_recorded": bool(f.get("witness_pid_after_restart")),
        "cli_agrees_with_eval": "%d/%d" % (p["cli_agree"], p["cli_compared"]),
        # signed run status (2026-10-08 single build), checked by probe.py's own code
        "status_signature_ok_earlier_run": ss.get("earlier_run", {}).get("signature_ok"),
        "status_signature_ok_segment": ss.get("segment", {}).get("signature_ok"),
        "status_names_latest_head_earlier_run": ss.get("earlier_run", {}).get("names_latest_head"),
        "status_names_latest_head_segment": ss.get("segment", {}).get("names_latest_head"),
        "status_signed_after_cosign_both": bool(ss.get("earlier_run", {}).get("status_after_cosign")) and bool(ss.get("segment", {}).get("status_after_cosign")),
        "status_fetch_lag_ms_max": max(ss.get("earlier_run", {}).get("fetch_minus_status_at_ms", -1), ss.get("segment", {}).get("fetch_minus_status_at_ms", -1)),
        "status_witness_copy_signature_ok_both": bool(reg.get("earlier_run", {}).get("signature_ok")) and bool(reg.get("segment", {}).get("signature_ok")),
        "cli_witness_url_cells": len(wu_rows),
        "cli_witness_url_status_checked": sum(1 for r in wu_rows if r["witness_run_status"].startswith("checked")),
        "cli_witness_url_status_invalid": sum(1 for r in wu_rows if r["witness_run_status"] == "given; INVALID"),
        "cli_witness_url_status_at_set": sum(1 for r in wu_rows if r.get("witness_run_status_at")),
        # build 2: derived dimensions of the verify-time checks with --witness-url
        "verify_witness_url_on_segment_head_fresh": vto.get("segment_witness_url", {}).get("head_fresh"),
        "verify_witness_url_on_segment_run_complete": vto.get("segment_witness_url", {}).get("run_complete"),
        "verify_witness_url_on_earlier_folder_head_fresh": vto.get("earlier_folder_witness_url", {}).get("head_fresh"),
        "verify_witness_url_on_earlier_folder_run_complete": vto.get("earlier_folder_witness_url", {}).get("run_complete"),
        # build 3: witness enrollment (custody.json facts and probe.py)
        "enrollment_kid_present": bool(f.get("enrollment_kid")),
        "witness_key_equals_pin": f.get("witness_key_equals_pin"),
        "status_enrollment_kid_equals_gateway": bool(f.get("enrollment_kid")) and f.get("witness_run_status_enrollment_kid") == f.get("enrollment_kid"),
        "eval_enrollment_probes_refused": "%d/%d" % (sum(1 for x in f.get("enrollment_probes") or [] if x.get("refused")), len(f.get("enrollment_probes") or [])),
        "eval_enrollment_probes_left_no_trace": f.get("enrollment_probes_left_no_trace"),
        "eval_enrollment_probe_answers": " | ".join("%s: %s" % (x.get("name"), "refused (enrollment)" if x.get("refused") else "NOT refused")
                                                     for x in f.get("enrollment_probes") or []),
        "probe_enrollment_kid_equals_custody_json": (p.get("enrollment") or {}).get("equals_custody_json_kid"),
        "probe_witness_pin_equals_saved_witness_key": (p.get("enrollment") or {}).get("witness_pin_equals_saved_witness_key"),
        "status_format_earlier_run": ss.get("earlier_run", {}).get("format"),
        "status_format_segment": ss.get("segment", {}).get("format"),
        "status_enrollment_kid_is_gateways_both": bool(ss.get("earlier_run", {}).get("enrollment_kid_is_gateways")) and bool(ss.get("segment", {}).get("enrollment_kid_is_gateways")),
        "probe_unsigned_registrations": " ".join("%s:%s" % (x["http_status"], x["code"]) for x in p["witness_probe"]["probes"]
                                                 if x["probe"].startswith(("re-register", "register")) and "[signed" not in x["probe"]),
        "probe_signed_registrations": " ".join("%s:%s" % (x["http_status"], x["code"] or "-") for x in p["witness_probe"]["probes"] if "[signed" in x["probe"]),
        "cli_witness_url_enrollment_kid_matches": sum(1 for r in wu_rows if r.get("witness_enrollment_kid_matches") == "True"),
        "cli_witness_url_enrollment_kid_reported": sum(1 for r in wu_rows if r.get("witness_enrollment_kid_matches") not in ("", None)),
        # build 3: earlier-segment keys report
        "cli_cells_keys_newest_only": sum(1 for r in csv.DictReader(open(os.path.join(pdir, "cli_crosscheck.csv"), encoding="utf-8")) if r.get("keys_newest_only") == "True"),
        "eval_cells_keys_newest_only": sum(1 for c in d["verification_matrix"] if any(m.startswith(NEWEST_ONLY) for m in (c["verification"].get("missing") or []))),
        "earlier_keys_probe": " | ".join("%s/%s %s" % (e["verdict"], e["assurance"], e["anchored_keys"]) for e in p.get("earlier_keys_probe") or []),
    })

os.makedirs(outdir, exist_ok=True)
with open(os.path.join(outdir, "repeats.csv"), "w", newline="", encoding="utf-8") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
with open(os.path.join(outdir, "matrix_stability.csv"), "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh)
    w.writerow(["source", "variant", "anchors", "runs", "outcomes (count over runs)", "failing checks (count over runs)"])
    for (v, a), c in eval_cells.items():
        w.writerow(["agentgate-eval (in-process verifier)", v, a, sum(c.values()), "; ".join("%s x%d" % kv for kv in sorted(c.items())), ""])
    for (v, a), c in cli_cells.items():
        w.writerow(["agentgate-verify CLI (separate process)", v, a, sum(c.values()), "; ".join("%s x%d" % kv for kv in sorted(c.items())),
                    "; ".join("%s x%d" % kv for kv in sorted(cli_failing[(v, a)].items()))])
# rollback detection by anchor condition (CLI, every run)
with open(os.path.join(outdir, "rollback_by_anchor.csv"), "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh)
    w.writerow(["variant", "anchors", "runs", "detected", "not_detected", "accepted_clean", "false_alarm", "rejected_wrong_anchor", "error_exit2", "assurance (count)", "failing checks (count)"])
    for (v, a), c in cli_outcomes.items():
        w.writerow([v, a, sum(c.values()), c.get("detected", 0), c.get("NOT detected", 0), c.get("accepted", 0), c.get("FALSE ALARM", 0),
                    c.get("rejected (wrong anchor)", 0), c.get("ERROR (exit 2)", 0), "; ".join("%s x%d" % kv for kv in sorted(cli_cells[(v, a)].items())),
                    "; ".join("%s x%d" % kv for kv in sorted(cli_failing[(v, a)].items()))])
with open(os.path.join(outdir, "dimensions_by_cell.csv"), "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh)
    w.writerow(["source", "variant", "anchors", "runs", "assurance|head_fresh|run_complete (count over runs)", "missing kinds listed (cells over runs)"])
    for (src, v, a), c in sorted(dim_cells.items()):
        w.writerow([src, v, a, sum(c.values()), "; ".join("%s x%d" % kv for kv in sorted(c.items())),
                    "; ".join("%s x%d" % kv for kv in sorted(dim_kinds[(src, v, a)].items()))])


with open(os.path.join(outdir, "keys_anchor_by_cell.csv"), "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh)
    w.writerow(["source", "variant", "anchors", "runs", "anchored_keys|newest-only entry (count over runs)"])
    for (src, v, a), c in sorted(keys_cells.items()):
        w.writerow([src, v, a, sum(c.values()), "; ".join("%s x%d" % kv for kv in sorted(c.items()))])


def pick(src, variant_test, anchor_test):
    """Sum the derived-dimension outcomes of every matching cell (all runs)."""
    total, combos, kinds, cells = 0, Counter(), Counter(), []
    for (s2, v, a), c in dim_cells.items():
        if s2 == src and variant_test(v) and anchor_test(a):
            total += sum(c.values()); combos.update(c); kinds.update(dim_kinds[(s2, v, a)]); cells.append([v, a])
    return {"verifications": total, "assurance|head_fresh|run_complete": dict(combos), "cells_listing_kind": dict(kinds), "cells": cells}


WITHHELD = "continuation segment withheld"
SEGMENT_CLEAN = "continuation segment (newest folder; earlier folder followed)"
derived = {
    "live witness fetch (--witness-url), every variant": {src: pick(src, lambda v: True, lambda a: "--witness-url" in a) for src in ("CLI", "in-process")},
    "live witness fetch, clean whole run (S0)": {src: pick(src, lambda v: v == SEGMENT_CLEAN, lambda a: "--witness-url" in a) for src in ("CLI", "in-process")},
    "live witness fetch, withheld segment (R5, R5j)": {src: pick(src, lambda v: v.startswith(WITHHELD), lambda a: "--witness-url" in a) for src in ("CLI", "in-process")},
    "saved stale witness head, every variant": {src: pick(src, lambda v: True, lambda a: a.startswith("stale ")) for src in ("CLI", "in-process")},
    "saved stale witness head, tamper-lab rollback R1 (folder journal)": {src: pick(src, lambda v: v == "coherent rollback", lambda a: a.startswith("stale witness head")) for src in ("CLI", "in-process")},
    "saved stale witness head, segment rolled back R7": {"CLI": pick("CLI", lambda v: v.startswith("continuation segment rolled back"), lambda a: a.startswith("stale segment"))},
    "saved latest witness head file, withheld segment (R5, R5j)": {src: pick(src, lambda v: v.startswith(WITHHELD), lambda a: a == "witness latest cosigned head") for src in ("CLI", "in-process")},
    "pins (keys+head), withheld segment (R5, R5j)": {src: pick(src, lambda v: v.startswith(WITHHELD), lambda a: a == "keys+head pinned") for src in ("CLI", "in-process")},
    "clean whole run (S0), every anchor": {src: pick(src, lambda v: v == SEGMENT_CLEAN, lambda a: True) for src in ("CLI", "in-process")},
}
summary = {"runs": len(rows), "flag_runs": sum(r["mode"] == "flag" for r in rows), "deny_runs": sum(r["mode"] == "deny" for r in rows),
           "eval_cells_with_more_than_one_outcome": [list(k) for k, c in eval_cells.items() if len(c) > 1],
           "cli_cells_with_more_than_one_outcome": [list(k) for k, c in cli_cells.items() if len(c) > 1]}
for col in ("selftest_passed", "witness_key_same_after_restart", "witness_latest_equals_saved_anchor", "provider_kid_same_after_restart",
            "probe_witness_store_unchanged", "live_witness_latest_equals_saved_anchor", "live_witness_store_unchanged", "segment_known_to_witness",
            "segment_registered_with_witness", "earlier_run_continued_by_segment", "eval_witness_run_continued_by_segment",
            "eval_witness_pid_recorded", "status_signature_ok_earlier_run", "status_signature_ok_segment",
            "status_names_latest_head_earlier_run", "status_names_latest_head_segment", "status_signed_after_cosign_both",
            "status_witness_copy_signature_ok_both"):
    summary[col] = "%d/%d" % (sum(1 for r in rows if r[col] is True), len(rows))
summary["status_fetch_lag_ms_max"] = max(r["status_fetch_lag_ms_max"] for r in rows)
for col in ("cli_witness_url_cells", "cli_witness_url_status_checked", "cli_witness_url_status_invalid", "cli_witness_url_status_at_set"):
    summary[col] = sum(r[col] for r in rows)
for col in ("revision_checks_passed", "witness_unavailable_entries", "witness_pushes_ok", "witness_push_failures", "witness_history_outage_jump",
            "witness_history_max_other_jump", "final_head_seq", "witness_caught_up_to", "rollback_seq", "stale_witness_seq", "probe_rollback_cut_to",
            "probe_last_effect_seq", "probe_rollback_dropped", "restart_ops_replayed", "segment_entries", "verify_witness_url_witness_stopped_exit",
            "verify_witness_url_on_segment_exit", "cli_agrees_with_eval", "probe_witness_statuses", "eval_tampered_cells_detected",
            "eval_clean_cells_false_alarm", "eval_clean_cells_anchored", "restart_witness_check", "segment_cosigned_seqs", "segment_live_latest_seq",
            "segment_rollback_to", "verify_witness_url_on_earlier_folder_exit", "verify_witness_url_on_earlier_folder_failing",
            "eval_segment_witness_latest_seq", "eval_segment_head_seq"):
    summary[col] = dict(Counter("%s|%s" % (r["mode"], r[col]) for r in rows))
summary["provider_commits_process_eq_folder"] = "%d/%d" % (sum(1 for r in rows if r["provider_commits_process"] == r["provider_commits_folder"]), len(rows))
for col in ("verify_witness_url_on_segment_head_fresh", "verify_witness_url_on_segment_run_complete",
            "verify_witness_url_on_earlier_folder_head_fresh", "verify_witness_url_on_earlier_folder_run_complete"):
    summary[col] = dict(Counter("%s|%s" % (r["mode"], r[col]) for r in rows))
summary["derived_dimensions"] = derived
# build 3: witness enrollment and the earlier-segment keys report
summary["enrollment"] = {col: "%d/%d" % (sum(1 for r in rows if r[col] is True), len(rows))
                         for col in ("enrollment_kid_present", "witness_key_equals_pin", "status_enrollment_kid_equals_gateway",
                                     "eval_enrollment_probes_left_no_trace", "probe_enrollment_kid_equals_custody_json",
                                     "probe_witness_pin_equals_saved_witness_key", "status_enrollment_kid_is_gateways_both")}
for col in ("eval_enrollment_probes_refused", "eval_enrollment_probe_answers", "probe_unsigned_registrations", "probe_signed_registrations",
            "status_format_earlier_run", "status_format_segment"):
    summary["enrollment"][col] = dict(Counter(r[col] for r in rows))
summary["enrollment"]["cli_witness_url_enrollment_kid_matches"] = "%d/%d" % (sum(r["cli_witness_url_enrollment_kid_matches"] for r in rows),
                                                                             sum(r["cli_witness_url_enrollment_kid_reported"] for r in rows))
summary["earlier_segment_keys"] = {
    "cli_cells_keys_newest_only": "%d/%d" % (sum(r["cli_cells_keys_newest_only"] for r in rows),
                                             sum(sum(c.values()) for (s2, v, a), c in keys_cells.items() if s2 == "CLI")),
    "eval_cells_keys_newest_only": "%d/%d" % (sum(r["eval_cells_keys_newest_only"] for r in rows),
                                              sum(sum(c.values()) for (s2, v, a), c in keys_cells.items() if s2 == "in-process")),
    "cells_listing_newest_only": [[s2, v, a, dict(c)] for (s2, v, a), c in sorted(keys_cells.items()) if any(k.endswith("newest-only") for k in c)],
    "earlier_keys_probe": {cell: dict(c) for cell, c in earlier_probe.items()},
}
summary["restart_no_new_provider_commit"] = "%d/%d" % (sum(1 for r in rows if r["restart_provider_commits_before"] == r["restart_provider_commits_after"] != ""), len(rows))
json.dump(summary, open(os.path.join(outdir, "summary.json"), "w", encoding="utf-8"), indent=1)
print(json.dumps(summary, indent=1))
for (v, a), c in cli_outcomes.items():
    print("%-80s | %-42s | %s | %s" % (v[:80], a, dict(c), dict(cli_cells[(v, a)])))
