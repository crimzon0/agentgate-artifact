"""Compare the build-3 custody aggregates with build 2, cell by cell (build 3; from build 2's compare_build1.py).

Usage: python compare_build2.py BUILD2_DIR BUILD3_DIR OUT_JSON
  BUILD2_DIR  docs/paper/data/build2/custody   (build 2, 2026-10-10)
  BUILD3_DIR  docs/paper/data/build3/custody   (build 3, 2026-10-20)

Compares, for the files both builds wrote with the same scripts:
  matrix_stability.csv    per (source, variant, anchors): outcome counts and failing checks
  rollback_by_anchor.csv  per (variant, anchors): every count column, assurance and failing checks
  tamper_lab.csv          per (run, attack): naive and anchored verdicts, detected, failing checks
  dimensions_by_cell.csv  per (source, variant, anchors): assurance|head_fresh|run_complete and Missing kinds (new in build 2)
  status_probe_summary.json  per (variant, answer): outcomes, failing checks, head_fresh and run_complete
  repeats_summary.json    every key build 2 has (keys new in build 3 are listed, not compared)
and writes OUT_JSON with the number of equal and differing items and every difference.
The same comparison as compare_build1.py, with the build-2 columns added (dimensions_by_cell.csv, and head_fresh /
run_complete in the relay probe).
"""
import csv, json, os, sys

b2, b3, out = sys.argv[1:4]


def rows(folder, name):
    return list(csv.DictReader(open(os.path.join(folder, name), encoding="utf-8")))


def compare_csv(name, key_cols, skip=()):
    r2 = {tuple(r[k] for k in key_cols): r for r in rows(b2, name)}
    r3 = {tuple(r[k] for k in key_cols): r for r in rows(b3, name)}
    diffs, equal = [], 0
    for key in sorted(set(r2) | set(r3)):
        a, b = r2.get(key), r3.get(key)
        if a is None or b is None:
            diffs.append({"key": list(key), "only_in": "build 2" if b is None else "build 3"})
            continue
        changed = {c: [a.get(c), b.get(c)] for c in a if c not in key_cols and c not in skip and a.get(c) != b.get(c)}
        if changed:
            diffs.append({"key": list(key), "changed": changed})
        else:
            equal += 1
    return {"build2_items": len(r2), "build3_items": len(r3), "equal": equal, "different": len(diffs), "differences": diffs}


result = {
    "matrix_stability.csv": compare_csv("matrix_stability.csv", ["source", "variant", "anchors"]),
    "rollback_by_anchor.csv": compare_csv("rollback_by_anchor.csv", ["variant", "anchors"]),
    "tamper_lab.csv": compare_csv("tamper_lab.csv", ["run", "attack"]),
    "dimensions_by_cell.csv": compare_csv("dimensions_by_cell.csv", ["source", "variant", "anchors"]),
}

s2 = json.load(open(os.path.join(b2, "status_probe_summary.json"), encoding="utf-8"))
s3 = json.load(open(os.path.join(b3, "status_probe_summary.json"), encoding="utf-8"))
c2 = {(c["variant"], c["answer"]): c for c in s2["by_cell"]}
c3 = {(c["variant"], c["answer"]): c for c in s3["by_cell"]}
FIELDS = ("runs", "outcomes", "failing", "head_fresh", "run_complete")
sp = {"build2_items": len(c2), "build3_items": len(c3), "equal": 0, "differences": []}
for key in sorted(set(c2) | set(c3)):
    a, b = c2.get(key), c3.get(key)
    if a is None or b is None:
        sp["differences"].append({"key": list(key), "only_in": "build 2" if b is None else "build 3"})
    elif tuple(a.get(f) for f in FIELDS) != tuple(b.get(f) for f in FIELDS):
        sp["differences"].append({"key": list(key), "build2": {f: a.get(f) for f in FIELDS}, "build3": {f: b.get(f) for f in FIELDS}})
    else:
        sp["equal"] += 1
for k in ("runs", "cells", "witness_copy_unchanged", "relay_requests_per_cell", "replayed_status_age_s"):
    if s2.get(k) != s3.get(k):
        sp["differences"].append({"key": k, "build2": s2.get(k), "build3": s3.get(k)})
sp["different"] = len(sp["differences"])
result["status_probe_summary.json"] = sp

r2 = json.load(open(os.path.join(b2, "repeats_summary.json"), encoding="utf-8"))
r3 = json.load(open(os.path.join(b3, "repeats_summary.json"), encoding="utf-8"))
rs = {"build2_keys": len(r2), "equal": 0, "differences": [], "new_in_build3": sorted(set(r3) - set(r2))}
for k in r2:
    if r2[k] != r3.get(k):
        rs["differences"].append({"key": k, "build2": r2[k], "build3": r3.get(k)})
    else:
        rs["equal"] += 1
rs["different"] = len(rs["differences"])
result["repeats_summary.json"] = rs

json.dump(result, open(out, "w", encoding="utf-8"), indent=1)
for name, r in result.items():
    print("%-28s equal %s, different %s" % (name, r.get("equal"), r.get("different")))
    for d in r["differences"][:60]:
        print("   ", json.dumps(d)[:700])
