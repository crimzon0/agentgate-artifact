"""Enrollment signatures for the witness registration probes (new for build 3).

Build 3 (2026-10-20, commit 8a30fd4): the witness registers a run or a
continuation (POST /runs) only when the request is signed by a gateway
enrollment key it was started with (agentgate-witness -enroll-key;
docs/demo/CONTRACTS.md "Witness enrollment", internal/headwitness
enrollment.go). probe.py sends build 2's registration probes unchanged
(unsigned: what a party without the enrollment key can send) and, as new
rows, the same requests signed with the gateway's enrollment key read from
the run's custody folder (<work>/custody/gateway/enrollment-key.json): what a
holder of that key (the gateway, or any process of the same OS user) can
send. The signed rows show which of build 2's witness rules (run_conflict,
continuity, idempotent re-registration) still decide behind the enrollment
check.

Ed25519 signing (RFC 8032 section 5.1.6) in pure Python, on the curve
arithmetic of status_sig.py; it shares no code with AgentGate. The message is
EnrollmentMessage as documented:

  "AgentGate/WitnessEnrollment/v1" 0x00 run_id 0x00 keys_sha256 0x00
  audit_public_key 0x00 ("1"|"0" keys_file_verified) 0x00
  continues.run_id 0x00 continues.final_head 0x00 continues.keys_sha256

where audit_public_key is the std base64 of the AUDIT_LOG key the witness
registers (given directly or taken from keys_file) and keys_file_verified is
"1" when the request carries keys_file.
"""
import base64, hashlib, json

import status_sig as _c

ENROLLMENT_LABEL = "AgentGate/WitnessEnrollment/v1"


def _compress(P):
    zinv = _c._inv(P[2])
    x, y = P[0] * zinv % _c._p, P[1] * zinv % _c._p
    return (y | ((x & 1) << 255)).to_bytes(32, "little")


def _expand(seed):
    h = hashlib.sha512(seed).digest()
    a = bytearray(h[:32])
    a[0] &= 248
    a[31] &= 127
    a[31] |= 64
    return int.from_bytes(bytes(a), "little"), h[32:]


def public_key(seed):
    a, _ = _expand(seed)
    return _compress(_c._mul(a, _c._G))


def sign(seed, message):
    """Ed25519 signature of message under the 32-byte private seed."""
    a, prefix = _expand(seed)
    A = _compress(_c._mul(a, _c._G))
    r = int.from_bytes(hashlib.sha512(prefix + message).digest(), "little") % _c._q
    R = _compress(_c._mul(r, _c._G))
    k = int.from_bytes(hashlib.sha512(R + A + message).digest(), "little") % _c._q
    S = (r + k * a) % _c._q
    return R + S.to_bytes(32, "little")


def _self_test():
    # RFC 8032 section 7.1, TEST 1 (empty message)
    seed = bytes.fromhex("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60")
    assert public_key(seed).hex() == "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a"
    assert sign(seed, b"").hex() == ("e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b")
    sig = sign(seed, b"enrollment self-test")
    assert _c.ed25519_verify(public_key(seed), b"enrollment self-test", sig)


_self_test()


class EnrollmentKey:
    """The gateway's enrollment key as stored in <custody>/gateway/enrollment-key.json."""

    def __init__(self, path):
        doc = json.load(open(path, encoding="utf-8"))
        assert doc.get("format") == "agentgate-gateway-enrollment-key/v1" and doc.get("role") == "GATEWAY_ENROLLMENT", path
        self.seed = base64.b64decode(doc["private_key_seed"], validate=True)
        self.public = public_key(self.seed)
        assert base64.b64encode(self.public).decode() == doc["public_key"], "enrollment key file: public key does not match its seed"
        self.kid = hashlib.sha256(self.public).hexdigest()
        assert self.kid == doc["kid"], "enrollment key file: kid does not match its key"
        self.public_b64 = doc["public_key"]

    def sign_request(self, request):
        """request (a POST /runs body) with enrollment_kid and enrollment_signature added."""
        if request.get("keys_file"):
            keys = json.loads(base64.b64decode(request["keys_file"]))
            audit = next(k["public_key"] for k in keys["keys"] if k["role"] == "AUDIT_LOG")
            verified = "1"
        else:
            audit, verified = request["audit_public_key"], "0"
        c = request.get("continues") or {}
        fields = [ENROLLMENT_LABEL, request["run_id"], request["keys_sha256"], audit, verified,
                  c.get("run_id", ""), c.get("final_head", ""), c.get("keys_sha256", "")]
        message = "\x00".join(fields).encode()
        signed = dict(request)
        signed["enrollment_kid"] = self.kid
        signed["enrollment_signature"] = base64.b64encode(sign(self.seed, message)).decode()
        return signed
