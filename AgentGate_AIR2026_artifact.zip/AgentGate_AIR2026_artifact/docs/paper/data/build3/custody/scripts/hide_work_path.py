"""Replace the repository-relative work paths in the files written here with <work> (new for build 3).

Usage: python hide_work_path.py EXP RAW_COPY_DIR FILE...
  EXP           the experiment's work root (<repo>/.tools/build3-work/custody): the canonical run's -work
                folder is EXP/canonical/work, each repetition's EXP/runs/<name>/work
  RAW_COPY_DIR  where the unmodified files are kept (outside the repository)
  FILE...       the files of this folder to clean (custody.json, custody.csv, custody.md, repeats.csv)

agentgate-eval replaces the absolute work folder in the texts the demo writes
(self-test check details) with "<work>" (hideWorkDir). Build 2's work folders
were outside the repository, so the demo named them absolutely and every
such text read "<work>/...". Build 3's work folders are inside the
repository (<repo>/.tools/build3-work, as the brief requires), and the demo
names them relative to the repository
(".tools/build3-work/custody/canonical/work/..."), which hideWorkDir does
not match. This script replaces exactly those folder names (relative and
absolute, both slash directions) by "<work>" and nothing else; the
unmodified files are kept in RAW_COPY_DIR. It changes no number.
"""
import os, re, shutil, sys

exp, raw_dir, files = sys.argv[1], sys.argv[2], sys.argv[3:]
os.makedirs(raw_dir, exist_ok=True)
repo = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), *[".."] * 6))
absolute = os.path.abspath(exp)
roots = {absolute, os.path.relpath(absolute, repo)}
patterns = []
for root in roots:
    for form in {root.replace("\\", "/"), root.replace("/", "\\"), root.replace("/", "\\").replace("\\", "\\\\")}:
        sep = re.escape("\\\\") if "\\\\" in form else (re.escape("\\") if "\\" in form else "/")
        patterns.append(re.compile(re.escape(form) + sep + "(?:canonical|runs" + sep + r"[A-Za-z0-9_.-]+)" + sep + "work"))
for path in files:
    raw = open(path, encoding="utf-8", newline="").read()
    shutil.copy(path, os.path.join(raw_dir, os.path.basename(path)))
    text, total = raw, 0
    for pattern in sorted(patterns, key=lambda p: len(p.pattern), reverse=True):
        text, n = pattern.subn("<work>", text)
        total += n
    open(path, "w", encoding="utf-8", newline="").write(text)
    print("%s: %d replacement(s); remaining mentions of build3-work: %d" % (os.path.basename(path), total, text.count("build3-work")))
