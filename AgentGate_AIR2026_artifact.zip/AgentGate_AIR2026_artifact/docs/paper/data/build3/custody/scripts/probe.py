"""Supplementary custody probes on one finished `agentgate-eval custody` work dir.

Usage: python probe.py BIN WORK OUT CUSTODY_JSON
  BIN          folder holding agentgate-witness.exe and agentgate-verify.exe
  WORK         the -work directory of the agentgate-eval custody run
  OUT          where probe.json and cli_crosscheck.csv are written
  CUSTODY_JSON that run's custody.json (pinned values, matrix to compare with)

Uses only the built binaries and file copies (no AgentGate code is changed).

  1. Witness probe: a fresh agentgate-witness process on a COPY of the run's
     witness directory; push a rolled-back head, an earlier genuine cosigned
     head, the latest head again, a head with an altered entry hash, a seq+1
     head without the audit key; re-register the run ID with other keys and
     with its own keys; ask for the continuation segment's latest head and
     both registrations (continued_by / continues); try a second
     continuation of the same run and a continuation naming other keys
     (409 continuity); re-register the segment with its own keys.json.
     Records HTTP status + error code; checks the store copy gained no record.
  2. Extra evidence variants built from genuine files only:
     - "coherent rollback to #k": the earliest cosigned head after the last
       provider effect; log cut to k lines + the genuine audit-signed head for
       seq k from the witness store + the run folder's provider journal (no
       provider commit after the last effect). Also with the journal served by
       the restarted provider process.
     - "continuation segment": the newest evidence folder (the restarted
       gateway's segment), verified with the earlier folder it names.
     - "continuation segment + earlier folder rolled back": a copy of both
       folders where the earlier one is the tamper lab's coherent rollback.
     - "continuation segment withheld": the earlier folder alone, presented as
       the whole run (same bytes as the closed run folder, tampered=True
       because the run's later evidence is hidden).
     - "continuation segment rolled back": both folders, the segment cut to
       its earlier cosigned head with that genuine head (from the witness
       store), i.e. a coherent rollback of the segment.
  3. CLI cross-check: agentgate-verify (separate process) on every variant x
     anchor condition, including the witness's latest head fetched at
     verification time with --witness-url from a witness process restarted on
     the run's own witness directory; compared with custody.json where the
     cell exists.
  4. Witness outage at verification time: --witness-url against the stopped
     witness, and --witness-url on the segment (registered with the witness
     since the 2026-10-08 build: expected exit 0, ANCHORED).

2026-10-08 build: the demo registers the restart segment with the witness as
the run's continuation and pushes its heads (anchors in
<work>/custody/anchors/<segment run id>/); the segment anchors, the segment
rollback and the registration probes were added for it.

2026-10-08 verifier fix (withheld segment): agentgate-verify --witness-url
also reads the witness's run status (GET /runs/{id}) and fails head.anchor
when it names a later segment (continued_by) that is not in the verified
chain. agentgate-eval custody now names the first folder, when a restart
segment exists, "continuation segment withheld (...)" (tampered) instead of
"closed run folder" (clean), and its live-provider-journal copy
"withheld-segment-live-provider-journal". This script follows: when a
segment exists, the first folder alone is only the withheld variant (the
duplicate clean "closed run folder" rows are dropped), and its live-journal
copy is the withheld variant with the provider process's journal (tampered).
Without a segment, the closed run folder is the whole run (clean), as before.

2026-10-08 single build (signed run status): GET /runs/{id} answers the
witness's signed run status (agentgate-witness-run-status/v1: the
registration, continued_by, the latest cosigned head and status_at, signed by
the witness key). This script checks that signature itself (status_sig.py, a
pure-Python RFC 8032 verifier sharing no code with AgentGate), that the status
names the head GET /runs/{id}/latest returned, and how far status_at is from
the fetch; it saves the raw (latest head, status) pairs of both segments in
OUT for status_probe.py, and the CLI rows gain witness_run_status_at (and
"given; INVALID" when the CLI rejected a status).

Build 2 (2026-10-10, commit 86643d7): the verifier reports two derived
dimensions, head_fresh and run_complete, and missing_kinds (the kind of each
Missing entry: unresolved, freshness, issuer_only, other). The only change to
this script: every CLI row gains head_fresh, run_complete (status),
missing_kinds and the two dimensions' reasons; the verify-time checks
(--witness-url on the segment and on the earlier folder alone) record the
same. Nothing else (variants, anchors, outcome rules) changed.

Build 3 (2026-10-20, commit 8a30fd4): agentgate-witness requires -enroll-key
(the gateway enrollment public key) and registers only runs signed with that
key; its run status is format v2 with enrollment_kid. Changes to this script,
nothing else (variants, anchors, outcome rules, the 74 CLI cells):
  - both witness starts (the copy and the live restart) pass -enroll-key with
    the public key from <work>/custody/gateway/enrollment-key.json (the
    witness does not start without it);
  - build 2's registration probes are sent unchanged (unsigned) and, as new
    rows appended after them, the same five requests signed with the
    gateway's enrollment key (enroll_sig.py), so the witness rules behind the
    enrollment check are still measured; a probe answered with an error
    records the witness's code (build 2 replaced the body of the two
    "own keys.json" probes by a message, which hid the code of a refusal it
    never got);
  - the signed status checks (status_sig.py, now v1 and v2) record format and
    enrollment_kid and whether it equals the gateway's enrollment key;
  - every CLI row gains witness_enrollment_kid_matches (the enrollment_kid the
    CLI reports for a checked status equals the gateway's) and
    keys_newest_only (the report lists "Keys anchored for the newest segment
    only");
  - new, outside the 74 cells: "earlier_keys_probe", five CLI verifications
    of the earlier-segment keys pin (--expect-earlier-keys) on the whole run
    and on the first folder alone;
  - probe.json gains "enrollment" (the key, the witness pin file).
"""
import base64, csv, glob, hashlib, json, os, shutil, subprocess, sys, time, urllib.request, urllib.error
from datetime import datetime, timezone
import status_sig
import enroll_sig

bindir, work, out, custody_path = sys.argv[1:5]
binw = os.path.join(bindir, "agentgate-witness.exe")
binv = os.path.join(bindir, "agentgate-verify.exe")
os.makedirs(out, exist_ok=True)
custody = json.load(open(custody_path, encoding="utf-8"))
facts = custody["facts"]
run_id = facts["run_id"]
run_dir = os.path.join(work, "runs", run_id)
assert os.path.isdir(run_dir), run_dir
anchors_dir = os.path.join(work, "custody", "anchors", run_id)
witness_head_file = os.path.join(anchors_dir, "witness-head.json")
witness_key_hex = open(os.path.join(anchors_dir, "witness-key.txt")).read().strip()
probe_dir = os.path.join(work, "probe")
shutil.rmtree(probe_dir, ignore_errors=True)
os.makedirs(probe_dir)
# build 3: the gateway enrollment key of the custody folder and the witness key the gateway pinned
enroll = enroll_sig.EnrollmentKey(os.path.join(work, "custody", "gateway", "enrollment-key.json"))
pin_path = os.path.join(work, "custody", "gateway", "witness-pin.txt")
witness_pin_hex = open(pin_path).read().strip().lower() if os.path.exists(pin_path) else None

def hide(text):
    text = text or ""
    for form, label in ((work, "<work>"), (bindir, "<bin>")):
        for variant in (os.path.abspath(form), form, form.replace("\\", "/"), os.path.abspath(form).replace("\\", "/")):
            text = text.replace(variant, label)
    return text

def read_json(path):
    return json.load(open(path, encoding="utf-8"))

def entries_of(folder):
    return [json.loads(l) for l in open(os.path.join(folder, "audit.jsonl"), encoding="utf-8") if l.strip()]

store_lines = open(os.path.join(work, "custody", "witness", "witness-store.jsonl"), encoding="utf-8").read().splitlines()
store = [json.loads(l) for l in store_lines]
cosigned = {r["head"]["head"]["seq"]: r["head"] for r in store if r["type"] == "head" and r["head"]["head"]["run_id"] == run_id}
witness_runs = sorted({r["head"]["head"]["run_id"] for r in store if r["type"] == "head"})
witness_runs_registered = sorted({r["run"]["run_id"] for r in store if r["type"] == "run"})
final_head = read_json(os.path.join(run_dir, "head.json"))
keys_bytes = open(os.path.join(run_dir, "keys.json"), "rb").read()
keys_sha = hashlib.sha256(keys_bytes).hexdigest()
rollback_dir = os.path.join(work, "variants", "rollback")
rollback_head = read_json(os.path.join(rollback_dir, "head.json"))
# the first folder with the provider process's journal (agentgate-eval names
# it after the withheld segment when a restart segment exists)
first_live_dir = None
for name in ("withheld-segment-live-provider-journal", "closed-run-folder-live-provider-journal"):
    if os.path.exists(os.path.join(work, "variants", name, "provider-journal.json")):
        first_live_dir = os.path.join(work, "variants", name)
        break
live_journal_path = os.path.join(first_live_dir, "provider-journal.json") if first_live_dir else None
have_live_journal = first_live_dir is not None

# the continuation segment(s): run folders whose run.json "continues" names this run
segments = []
for d in sorted(glob.glob(os.path.join(work, "runs", "run-*"))):
    rj = read_json(os.path.join(d, "run.json"))
    if (rj.get("continues") or {}).get("run_id") == run_id:
        segments.append(d)
segment_dir = segments[0] if segments else None
seg_id = os.path.basename(segment_dir) if segment_dir else None
seg_witness_head_file = os.path.join(work, "custody", "anchors", seg_id, "witness-head.json") if seg_id else None
if seg_witness_head_file and not os.path.exists(seg_witness_head_file):
    seg_witness_head_file = None

seg_cosigned = {r["head"]["head"]["seq"]: r["head"] for r in store if r["type"] == "head" and r["head"]["head"]["run_id"] == seg_id} if seg_id else {}

# witness history gaps (outage visibility in the witness's own store)
seqs = sorted(cosigned)
gaps = [b - a for a, b in zip(seqs, seqs[1:])]
all_entries = entries_of(run_dir)
wu = [e["entry"]["seq"] for e in all_entries if e["entry"]["stage"] == "WITNESS_UNAVAILABLE"]
outage_gap = None
if wu:
    before = max([s for s in seqs if s < wu[0]] or [0])
    after = min([s for s in seqs if s >= wu[0]] or [0])
    outage_gap = {"last_cosigned_before_outage": before, "first_cosigned_after": after, "jump": after - before,
                  "max_other_jump": max([g for (a, g) in zip(seqs, gaps) if a != before] or [0])}

# ---- 1. witness probe on a copy of its directory -----------------------------------------
def start_witness(directory):
    proc = subprocess.Popen([binw, "-dir", directory, "-enroll-key", enroll.public_b64, "-stdin-shutdown"], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, text=True)
    ready = json.loads(proc.stdout.readline())
    return proc, ready

def stop_witness(proc):
    proc.stdin.close()
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        proc.kill(); proc.wait()
    return proc.returncode

def call(origin, method, path, body=None):
    data = None if body is None else json.dumps(body).encode()
    req = urllib.request.Request(origin + path, data=data, method=method, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status, json.loads(r.read() or b"null")
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read())
        except Exception:
            return e.code, None

wdir = os.path.join(probe_dir, "witness-copy")
shutil.copytree(os.path.join(work, "custody", "witness"), wdir)
store_before = open(os.path.join(wdir, "witness-store.jsonl"), "rb").read()
proc, ready = start_witness(wdir)
origin = ready["origin"]
probes = []
def record(name, expect, status, body):
    body = body if isinstance(body, dict) else {}
    seq = body["head"].get("seq") if isinstance(body.get("head"), dict) else None
    probes.append({"probe": name, "expected": expect, "http_status": status, "code": body.get("code"),
                   "message": hide(body.get("error") or body.get("message") or ""), "cosigned_seq": seq, "index": body.get("index")})

st, body = call(origin, "GET", "/key")
key_same = isinstance(body, dict) and base64.b64decode(body.get("public_key", "")).hex() == witness_key_hex
record("GET /key (same key as saved anchor)", "200, key equals the saved witness key", st, {"message": "key equal: %s" % key_same})
st, body = call(origin, "GET", "/runs/%s/latest" % run_id); record("GET latest", "200, seq = final head", st, body)
st, body = call(origin, "POST", "/heads", rollback_head); record("push the rollback copy's head.json (seq %d)" % rollback_head["seq"], "409 rollback", st, body)
last_effect = max(e["entry"]["seq"] for e in all_entries if e["entry"]["stage"] == "EFFECT_EXECUTED" or (e["entry"]["stage"] == "RECONCILED" and e["entry"].get("outcome") == "committed"))
k = min(s for s in cosigned if s > last_effect and s < final_head["seq"])
st, body = call(origin, "POST", "/heads", cosigned[k]["head"]); record("push an earlier genuine cosigned head (seq %d)" % k, "409 rollback", st, body)
st, body = call(origin, "POST", "/heads", final_head); record("push the final head again (seq %d)" % final_head["seq"], "200 idempotent, same cosigned head", st, body)
forged = dict(final_head); forged["entry_hash"] = "00" * 32
st, body = call(origin, "POST", "/heads", forged); record("push the final head with another entry_hash (signature unchanged)", "400 invalid_head", st, body)
bumped = dict(final_head); bumped["seq"] = final_head["seq"] + 1
st, body = call(origin, "POST", "/heads", {"head": bumped, "entries": ["{}"]}); record("push seq+1 without the audit key (signature of the old head)", "400 invalid_head", st, body)
other_key = base64.b64encode(hashlib.sha256(b"attacker").digest()).decode()
st, body = call(origin, "POST", "/runs", {"run_id": run_id, "keys_sha256": hashlib.sha256(b"other keys").hexdigest(), "audit_public_key": other_key})
record("re-register this run ID with other keys", "409 run_conflict", st, body)
st, body = call(origin, "POST", "/runs", {"run_id": run_id, "keys_sha256": keys_sha, "keys_file": base64.b64encode(keys_bytes).decode()})
record("re-register this run ID with its own keys.json", "200 (idempotent)", st, {"message": "keys_sha256 %s" % ((body or {}).get("keys_sha256") == keys_sha)} if isinstance(body, dict) and st in (200, 201) else body)
# build 3: the requests of the registration probes, re-sent signed with the gateway's enrollment key (after the unsigned ones)
signed_probes = [("re-register this run ID with other keys", "409 run_conflict",
                  {"run_id": run_id, "keys_sha256": hashlib.sha256(b"other keys").hexdigest(), "audit_public_key": other_key}, None),
                 ("re-register this run ID with its own keys.json", "200 (idempotent)",
                  {"run_id": run_id, "keys_sha256": keys_sha, "keys_file": base64.b64encode(keys_bytes).decode()},
                  lambda b: "keys_sha256 %s; enrollment_kid is the gateway's: %s" % (b.get("keys_sha256") == keys_sha, b.get("enrollment_kid") == enroll.kid))]
registration = {}
if segment_dir:
    seg_keys_bytes = open(os.path.join(segment_dir, "keys.json"), "rb").read()
    seg_audit_key = next(k["public_key"] for k in json.loads(seg_keys_bytes)["keys"] if k["role"] == "AUDIT_LOG")
    seg_run = read_json(os.path.join(segment_dir, "run.json"))
    seg_continues = {k2: seg_run["continues"][k2] for k2 in ("run_id", "final_head", "keys_sha256")}
    st, body = call(origin, "GET", "/runs/%s/latest" % seg_id); record("GET latest for the continuation segment's run ID", "200, seq = the segment's final head", st, body)
    st, body = call(origin, "GET", "/runs/%s" % run_id)
    sig_ok, sig_problem = status_sig.check_run_status(body, witness_key_hex)
    registration["earlier_run"] = {"status": st, "continued_by": body.get("continued_by") if isinstance(body, dict) else None,
                                   "format": body.get("format") if isinstance(body, dict) else None, "signature_ok": sig_ok,
                                   "latest_seq": body.get("latest_seq") if isinstance(body, dict) else None,
                                   "enrollment_kid_is_gateways": isinstance(body, dict) and body.get("enrollment_kid") == enroll.kid}
    record("GET /runs/{run} (signed run status of the earlier run)", "200, signed, continued_by = the segment", st,
           {"message": "continued_by=%s (is the segment: %s); signature %s; latest_seq %s" % (
               registration["earlier_run"]["continued_by"], registration["earlier_run"]["continued_by"] == seg_id,
               "verifies" if sig_ok else "INVALID (" + sig_problem + ")", registration["earlier_run"]["latest_seq"])})
    st, body = call(origin, "GET", "/runs/%s" % seg_id)
    seg_reg_continues = body.get("continues") if isinstance(body, dict) else None
    sig_ok, sig_problem = status_sig.check_run_status(body, witness_key_hex)
    registration["segment"] = {"status": st, "continues": seg_reg_continues, "matches_run_json": seg_reg_continues == seg_continues,
                               "format": body.get("format") if isinstance(body, dict) else None, "signature_ok": sig_ok,
                               "continued_by": body.get("continued_by") if isinstance(body, dict) else None,
                               "enrollment_kid_is_gateways": isinstance(body, dict) and body.get("enrollment_kid") == enroll.kid}
    record("GET /runs/{segment} (signed run status of the segment)", "200, signed, continues = the earlier run's final head and keys", st,
           {"message": "continues matches the segment's run.json: %s; signature %s" % (
               seg_reg_continues == seg_continues, "verifies" if sig_ok else "INVALID (" + sig_problem + ")")})
    second = {"run_id": "run-probe-second-continuation", "keys_sha256": hashlib.sha256(b"probe keys").hexdigest(),
              "audit_public_key": seg_audit_key, "continues": seg_continues}
    st, body = call(origin, "POST", "/runs", second)
    record("register a second continuation of the same run", "409 continuity (already continued)", st, body)
    other_continues = dict(seg_continues); other_continues["keys_sha256"] = hashlib.sha256(b"other keys").hexdigest()
    other_cont = {"run_id": "run-probe-other-keys", "keys_sha256": hashlib.sha256(b"probe keys").hexdigest(),
                  "audit_public_key": seg_audit_key, "continues": other_continues}
    st, body = call(origin, "POST", "/runs", other_cont)
    record("register a continuation naming other keys for the earlier run", "409 continuity", st, body)
    seg_again = {"run_id": seg_id, "keys_sha256": hashlib.sha256(seg_keys_bytes).hexdigest(),
                 "keys_file": base64.b64encode(seg_keys_bytes).decode(), "continues": seg_continues}
    st, body = call(origin, "POST", "/runs", seg_again)
    record("re-register the segment with its own keys.json and continues", "200 (idempotent)", st,
           {"message": "continues equal: %s" % (body.get("continues") == seg_continues)} if isinstance(body, dict) and st in (200, 201) else body)
    signed_probes += [("register a second continuation of the same run", "409 continuity (already continued)", second, None),
                      ("register a continuation naming other keys for the earlier run", "409 continuity", other_cont, None),
                      ("re-register the segment with its own keys.json and continues", "200 (idempotent)", seg_again,
                       lambda b: "continues equal: %s; enrollment_kid is the gateway's: %s" % (b.get("continues") == seg_continues, b.get("enrollment_kid") == enroll.kid))]
# build 3: the same registrations signed with the gateway's enrollment key (what a holder of the key can send)
for pname, pexpect, request, describe in signed_probes:
    st, body = call(origin, "POST", "/runs", enroll.sign_request(request))
    record(pname + " [signed with the gateway's enrollment key]", pexpect, st,
           {"message": describe(body)} if describe and isinstance(body, dict) and st in (200, 201) else body)
witness_copy_exit = stop_witness(proc)
store_after = open(os.path.join(wdir, "witness-store.jsonl"), "rb").read()

# ---- 2. extra variants -------------------------------------------------------------------
variants_dir = os.path.join(work, "variants")
rk = os.path.join(variants_dir, "rollback-to-%d" % k)
shutil.rmtree(rk, ignore_errors=True); os.makedirs(rk)
lines = [l for l in open(os.path.join(run_dir, "audit.jsonl"), "rb").read().split(b"\n") if l]
cut = lines[:k]
assert json.loads(cut[-1])["entry"]["seq"] == k and json.loads(cut[-1])["entry_hash"] == cosigned[k]["head"]["entry_hash"]
open(os.path.join(rk, "audit.jsonl"), "wb").write(b"\n".join(cut) + b"\n")
json.dump(cosigned[k]["head"], open(os.path.join(rk, "head.json"), "w"), indent=2)
for name in ("keys.json", "run.json", "provider-journal.json"):
    shutil.copy(os.path.join(run_dir, name), os.path.join(rk, name))
dropped = [json.loads(l)["entry"]["stage"] for l in lines[k:]]
rk_live = None
if have_live_journal:
    rk_live = rk + "-live-provider-journal"
    shutil.rmtree(rk_live, ignore_errors=True); shutil.copytree(rk, rk_live)
    shutil.copy(live_journal_path, os.path.join(rk_live, "provider-journal.json"))

seg_rb = None
seg_keys_sha = seg_head = None
if segment_dir:
    seg_keys_sha = hashlib.sha256(open(os.path.join(segment_dir, "keys.json"), "rb").read()).hexdigest()
    seg_head = read_json(os.path.join(segment_dir, "head.json"))["entry_hash"]
    # both folders, the earlier one replaced by the tamper lab's coherent rollback
    seg_rb_root = os.path.join(variants_dir, "segment-with-rolled-back-predecessor")
    shutil.rmtree(seg_rb_root, ignore_errors=True); os.makedirs(seg_rb_root)
    for name in ("audit.jsonl", "head.json", "keys.json", "run.json", "provider-journal.json"):
        os.makedirs(os.path.join(seg_rb_root, run_id), exist_ok=True)
        shutil.copy(os.path.join(rollback_dir, name), os.path.join(seg_rb_root, run_id, name))
    seg_rb = os.path.join(seg_rb_root, os.path.basename(segment_dir))
    os.makedirs(seg_rb)
    for name in ("audit.jsonl", "head.json", "keys.json", "run.json", "provider-journal.json"):
        shutil.copy(os.path.join(segment_dir, name), os.path.join(seg_rb, name))

seg_rolled = None
seg_rollback_to = None
seg_dropped = []
if segment_dir and len(seg_cosigned) >= 2:
    seg_final_seq = read_json(os.path.join(segment_dir, "head.json"))["seq"]
    earlier_seg = [q for q in seg_cosigned if q < seg_final_seq]
    if earlier_seg:
        seg_rollback_to = max(earlier_seg)
        root = os.path.join(variants_dir, "segment-rolled-back-to-%d" % seg_rollback_to)
        shutil.rmtree(root, ignore_errors=True)
        shutil.copytree(run_dir, os.path.join(root, run_id))
        seg_rolled = os.path.join(root, seg_id)
        os.makedirs(seg_rolled)
        seg_lines = [l for l in open(os.path.join(segment_dir, "audit.jsonl"), "rb").read().split(b"\n") if l]
        cut_seg = seg_lines[:seg_rollback_to]
        assert json.loads(cut_seg[-1])["entry_hash"] == seg_cosigned[seg_rollback_to]["head"]["entry_hash"]
        open(os.path.join(seg_rolled, "audit.jsonl"), "wb").write(b"\n".join(cut_seg) + b"\n")
        json.dump(seg_cosigned[seg_rollback_to]["head"], open(os.path.join(seg_rolled, "head.json"), "w"), indent=2)
        for name in ("keys.json", "run.json", "provider-journal.json"):
            shutil.copy(os.path.join(segment_dir, name), os.path.join(seg_rolled, name))
        seg_dropped = [json.loads(l)["entry"]["stage"] for l in seg_lines[seg_rollback_to:]]

# ---- 3. CLI cross-check ------------------------------------------------------------------
stale_seq = facts["stale_witness_seq"]
stale_file = os.path.join(probe_dir, "stale-witness-head.json"); json.dump(cosigned[stale_seq], open(stale_file, "w"))
k_file = os.path.join(probe_dir, "witness-head-%d.json" % k); json.dump(cosigned[k], open(k_file, "w"))
keys_pin, head_pin = facts["keys_sha256_pinned"], facts["final_head_hash_pinned"]

live_dir = os.path.join(work, "custody", "witness")
live_before = open(os.path.join(live_dir, "witness-store.jsonl"), "rb").read()
live_proc, live_ready = start_witness(live_dir)
live_origin = live_ready["origin"]
st, latest_live = call(live_origin, "GET", "/runs/%s/latest" % run_id)
live_latest_seq = latest_live["head"]["seq"] if st == 200 else None
live_latest_ok = st == 200 and latest_live == read_json(witness_head_file)
live_st_reg, live_reg = call(live_origin, "GET", "/runs/%s" % run_id)
live_reg_fetched = datetime.now(timezone.utc)
live_continued_by = live_reg.get("continued_by") if isinstance(live_reg, dict) else None
live_seg_latest_seq = None
latest_seg = None
if seg_id:
    st_seg, latest_seg = call(live_origin, "GET", "/runs/%s/latest" % seg_id)
    live_seg_latest_seq = latest_seg["head"]["seq"] if st_seg == 200 else None


def status_facts(status, latest, fetched):
    """The signed run status as checked here: signature (independent code), the head it names, status_at."""
    ok, problem = status_sig.check_run_status(status, witness_key_hex)
    result = {"format": status.get("format") if isinstance(status, dict) else None, "signature_ok": ok, "problem": problem}
    if isinstance(status, dict) and isinstance(latest, dict):
        result["names_latest_head"] = (status.get("latest_seq") == latest["head"]["seq"] and status.get("latest_index") == latest.get("index")
                                       and status.get("latest_entry_hash") == latest["head"]["entry_hash"])
        result["latest_seq"] = status.get("latest_seq")
        result["status_at"] = status.get("status_at")
        result["witnessed_at"] = latest.get("witnessed_at")
        try:
            signed = datetime.fromisoformat(status["status_at"].replace("Z", "+00:00"))
            result["fetch_minus_status_at_ms"] = round((fetched - signed).total_seconds() * 1000, 1)
            result["status_after_cosign"] = signed >= datetime.fromisoformat(latest["witnessed_at"].replace("Z", "+00:00"))
        except Exception as err:  # unreadable time
            result["time_problem"] = str(err)
        result["continued_by"] = status.get("continued_by", "")
        result["enrollment_kid_is_gateways"] = status.get("enrollment_kid") == enroll.kid  # build 3
    return result


live_status = {"earlier_run": status_facts(live_reg, latest_live if st == 200 else None, live_reg_fetched)}
# the (latest head, status) pairs, saved for status_probe.py (a later replay of a genuine pair)
json.dump({"run_id": run_id, "latest": latest_live, "status": live_reg, "fetched_at": live_reg_fetched.isoformat()},
          open(os.path.join(out, "status-pair-earlier-run.json"), "w", encoding="utf-8"), indent=1)
if seg_id:
    st_seg_reg, seg_reg = call(live_origin, "GET", "/runs/%s" % seg_id)
    seg_fetched = datetime.now(timezone.utc)
    live_status["segment"] = status_facts(seg_reg, latest_seg if live_seg_latest_seq is not None else None, seg_fetched)
    json.dump({"run_id": seg_id, "latest": latest_seg, "status": seg_reg, "fetched_at": seg_fetched.isoformat()},
              open(os.path.join(out, "status-pair-segment.json"), "w", encoding="utf-8"), indent=1)

W = ["--witness-key", witness_key_hex]
def std_anchors(kp, hp):
    return [("none", []), ("keys pinned", ["--expect-keys", kp]), ("head pinned", ["--expect-head", hp]),
            ("keys+head pinned", ["--expect-keys", kp, "--expect-head", hp]),
            ("witness latest cosigned head", ["--witness", witness_head_file] + W),
            ("witness latest via --witness-url", ["--witness-url", live_origin] + W),
            ("stale witness head (#%d)" % stale_seq, ["--witness", stale_file] + W),
            ("witness head #%d (probe)" % k, ["--witness", k_file] + W)]

LIVE_TAG = " + provider journal from the provider process"
WITHHELD = "continuation segment withheld (earlier folder presented as the whole run)"
variants = []
if not segment_dir:
    # no restart segment: the first folder is the whole run (clean)
    variants.append(("closed run folder", run_dir, False, std_anchors(keys_pin, head_pin)))
variants.append(("coherent rollback", rollback_dir, True, std_anchors(keys_pin, head_pin)))
if have_live_journal:
    if not segment_dir:
        variants.append(("closed run folder" + LIVE_TAG, first_live_dir, False, std_anchors(keys_pin, head_pin)))
    variants.append(("coherent rollback" + LIVE_TAG, os.path.join(variants_dir, "coherent-rollback-live-provider-journal"), True, std_anchors(keys_pin, head_pin)))
variants.append(("coherent rollback to #%d (no provider effect removed; probe)" % k, rk, True, std_anchors(keys_pin, head_pin)))
if rk_live:
    variants.append(("coherent rollback to #%d + provider journal from the provider process (probe)" % k, rk_live, True, std_anchors(keys_pin, head_pin)))
if segment_dir:
    seg_anchors = [("none", []), ("keys pinned (segment)", ["--expect-keys", seg_keys_sha]), ("head pinned (segment)", ["--expect-head", seg_head]),
                   ("keys+head pinned (segment)", ["--expect-keys", seg_keys_sha, "--expect-head", seg_head]),
                   ("earlier run's witness head (wrong run for the segment)", ["--witness", witness_head_file] + W),
                   ("witness latest via --witness-url", ["--witness-url", live_origin] + W)]
    if seg_witness_head_file:
        seg_anchors.insert(5, ("segment's witness latest cosigned head (saved)", ["--witness", seg_witness_head_file] + W))
    seg_anchors_rb = list(seg_anchors)
    if seg_rollback_to:
        seg_stale_file = os.path.join(probe_dir, "segment-witness-head-%d.json" % seg_rollback_to)
        json.dump(seg_cosigned[seg_rollback_to], open(seg_stale_file, "w"))
        seg_anchors_rb.append(("stale segment witness head (#%d)" % seg_rollback_to, ["--witness", seg_stale_file] + W))
    variants.append(("continuation segment (newest folder; earlier folder followed)", segment_dir, False, seg_anchors))
    variants.append(("continuation segment + earlier folder rolled back (tamper-lab rollback)", seg_rb, True, seg_anchors))
    if seg_rolled:
        variants.append(("continuation segment rolled back to its earlier cosigned head (both folders)", seg_rolled, True, seg_anchors_rb))
    withheld = std_anchors(keys_pin, head_pin)
    withheld.insert(4, ("head pinned = run's final head (segment)", ["--expect-head", seg_head]))
    if seg_witness_head_file:
        withheld.insert(5, ("segment's witness latest cosigned head (saved)", ["--witness", seg_witness_head_file] + W))
    variants.append((WITHHELD, run_dir, True, withheld))
    if have_live_journal:
        # the first folder alone with the provider process's journal: still the
        # withheld segment (the provider journal holds no commit of the segment)
        variants.append((WITHHELD + LIVE_TAG, first_live_dir, True, list(withheld)))

def witness_status(rep, seg):
    """What the CLI report says about the witness's run status (--witness-url only)."""
    w = (rep.get("anchors") or {}).get("witness") if isinstance(rep, dict) else None
    if not isinstance(w, dict):
        return ""
    if not w.get("run_status_checked"):
        return "given; INVALID" if w.get("run_status_given") else "not consulted"
    by = w.get("continued_by") or ""
    if not by:
        return "checked; not continued"
    return "checked; continued_by=" + ("the segment" if by == seg else by)

def dims(rep):
    """Build 2: the derived dimensions and the kinds of the Missing entries of a CLI report.
    Build 3: also anchored_keys, keys_newest_only (the "Keys anchored for the newest segment only" entry) and
    whether the enrollment_kid the CLI reports for a checked run status is the gateway's."""
    d = (rep.get("dimensions") or {}) if isinstance(rep, dict) else {}
    hf, rc = d.get("head_fresh") or {}, d.get("run_complete") or {}
    w = ((rep.get("anchors") or {}).get("witness") or {}) if isinstance(rep, dict) else {}
    ekid = w.get("enrollment_kid") or ""
    return {"head_fresh": hf.get("status", ""), "run_complete": rc.get("status", ""),
            "missing_kinds": " ".join((rep.get("missing_kinds") or []) if isinstance(rep, dict) else []),
            "head_fresh_reason": hide(hf.get("reason", ""))[:300], "run_complete_reason": hide(rc.get("reason", ""))[:300],
            "anchored_keys": (d.get("anchored_keys") or {}).get("status", ""),
            "keys_newest_only": any(m.startswith("Keys anchored for the newest segment only") for m in ((rep.get("missing") or []) if isinstance(rep, dict) else [])),
            "witness_enrollment_kid_matches": (ekid == enroll.kid) if ekid else ""}


eval_cells = {(c["variant"], c["anchors"]): c for c in custody["verification_matrix"]}
rows = []
for vname, vdir, tampered, anchors in variants:
    for aname, args in anchors:
        p = subprocess.run([binv, "--json"] + args + [vdir], capture_output=True, text=True)
        try:
            rep = json.loads(p.stdout)
        except Exception:
            rep = {}
        failing = sorted({f.get("id") for f in (rep.get("failures") or []) if isinstance(f, dict) and f.get("id")})
        cell = eval_cells.get((vname, aname))
        verdict, assurance = rep.get("verdict"), rep.get("assurance")
        if p.returncode == 2:
            outcome = "ERROR (exit 2)"
        elif "wrong run" in aname:
            outcome = "rejected (wrong anchor)" if verdict == "FAILED" else "accepted despite the wrong anchor"
        elif tampered:
            outcome = "detected" if verdict == "FAILED" else "NOT detected"
        else:
            outcome = "accepted" if verdict == "VERIFIED" else "FALSE ALARM"
        rows.append({"variant": vname, "anchors": aname, "tampered": tampered, "cli_exit": p.returncode, "cli_verdict": verdict or "",
                     "cli_assurance": assurance or "", "cli_failing": " ".join(failing), "outcome": outcome,
                     "segments": len(rep.get("segments") or []) or (1 if rep else 0),
                     "eval_verdict": cell["verification"]["verdict"] if cell else "", "eval_assurance": cell["verification"]["assurance"] if cell else "",
                     "agrees_with_eval": (cell["verification"]["verdict"] == verdict and cell["verification"]["assurance"] == assurance) if cell else "",
                     "witness_run_status": witness_status(rep, seg_id),
                     "witness_run_status_at": (((rep.get("anchors") or {}).get("witness") or {}).get("run_status_at") or "") if isinstance(rep, dict) else "",
                     "missing": " | ".join(rep.get("missing") or []), "stderr": hide(p.stderr.strip())[:300], **dims(rep)})

# ---- 4. witness outage at verification time ----------------------------------------------
outage = {}
if segment_dir:
    p = subprocess.run([binv, "--json", "--witness-url", live_origin] + W + [segment_dir], capture_output=True, text=True)
    try:
        rep = json.loads(p.stdout)
    except Exception:
        rep = {}
    outage["segment_witness_url"] = {"exit": p.returncode, "stderr": hide(p.stderr.strip())[:400],
                                     "verdict": rep.get("verdict"), "assurance": rep.get("assurance"), **dims(rep)}
    # the earlier folder alone (segment withheld): head.anchor must fail on the run status
    p = subprocess.run([binv, "--json", "--witness-url", live_origin] + W + [run_dir], capture_output=True, text=True)
    try:
        rep = json.loads(p.stdout)
    except Exception:
        rep = {}
    outage["earlier_folder_witness_url"] = {"exit": p.returncode, "verdict": rep.get("verdict"), "assurance": rep.get("assurance"),
                                            "failing": sorted({f.get("id") for f in (rep.get("failures") or []) if isinstance(f, dict) and f.get("id")}),
                                            "missing": hide(" | ".join(rep.get("missing") or []))[:400], "stderr": hide(p.stderr.strip())[:300],
                                            **dims(rep)}
live_exit = stop_witness(live_proc)
live_after = open(os.path.join(live_dir, "witness-store.jsonl"), "rb").read()
time.sleep(0.2)
t0 = time.perf_counter()
p = subprocess.run([binv, "--json", "--witness-url", live_origin] + W + [run_dir], capture_output=True, text=True)
outage["witness_stopped"] = {"exit": p.returncode, "stdout_bytes": len(p.stdout), "stderr": hide(p.stderr.strip()).replace(live_origin, "<witness>")[:400],
                             "elapsed_s": round(time.perf_counter() - t0, 2)}

# ---- 5. build 3: the earlier-segment keys pin (new; outside the 74 cells) ------------------
earlier_keys_probe = []
if segment_dir:
    wrong_pin = hashlib.sha256(b"other keys").hexdigest()
    ek_cells = [
        ("S0, keys pinned (segment) [= the matrix cell]", segment_dir, ["--expect-keys", seg_keys_sha],
         "VERIFIED CONSISTENT; anchored_keys not_checked; keys.anchor warning; 'Keys anchored for the newest segment only'"),
        ("S0, keys pinned (segment) + earlier keys pinned (the first run's keys)", segment_dir, ["--expect-keys", seg_keys_sha, "--expect-earlier-keys", keys_pin],
         "VERIFIED CONSISTENT; anchored_keys pass; no newest-only entry"),
        ("S0, keys pinned (segment) + earlier keys pinned to another fingerprint", segment_dir, ["--expect-keys", seg_keys_sha, "--expect-earlier-keys", wrong_pin],
         "FAILED keys.anchor"),
        ("S0, earlier keys pinned only (no keys pin for the segment)", segment_dir, ["--expect-earlier-keys", keys_pin],
         "VERIFIED CONSISTENT; anchored_keys not_checked (the newest segment's keys unpinned)"),
        ("S0, keys+head pinned (segment) + earlier keys pinned", segment_dir, ["--expect-keys", seg_keys_sha, "--expect-head", seg_head, "--expect-earlier-keys", keys_pin],
         "VERIFIED ANCHORED; anchored_keys pass"),
        ("first folder alone (R5), keys pinned + earlier keys pinned (a run of one segment)", run_dir, ["--expect-keys", keys_pin, "--expect-earlier-keys", keys_pin],
         "FAILED keys.anchor (earlier-segment pins for a run of one segment)"),
    ]
    for cname, cdir, cargs, cexpect in ek_cells:
        p = subprocess.run([binv, "--json"] + cargs + [cdir], capture_output=True, text=True)
        try:
            rep = json.loads(p.stdout)
        except Exception:
            rep = {}
        ak = ((rep.get("dimensions") or {}).get("anchored_keys") or {})
        ka = [{"status": c.get("status"), "detail": hide(c.get("detail", ""))[:260]} for c in (rep.get("checks") or []) if c.get("id") == "keys.anchor" and c.get("status") != "pass"]
        earlier_keys_probe.append({"cell": cname, "expected": cexpect, "exit": p.returncode, "verdict": rep.get("verdict"), "assurance": rep.get("assurance"),
                                   "anchored_keys": ak.get("status"), "anchored_keys_reason": hide(ak.get("reason", ""))[:300],
                                   "failing": sorted({f.get("id") for f in (rep.get("failures") or []) if isinstance(f, dict) and f.get("id")}),
                                   "keys_anchor_not_pass": ka, "keys_newest_only": dims(rep)["keys_newest_only"],
                                   "missing_kinds": " ".join(rep.get("missing_kinds") or []), "stderr": hide(p.stderr.strip())[:300]})

with open(os.path.join(out, "cli_crosscheck.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
result = {"run_id": run_id, "segment_run_id": os.path.basename(segment_dir) if segment_dir else None,
          "witness_runs_in_store": witness_runs, "witness_runs_registered": witness_runs_registered,
          "witness_probe": {"witness_pid": ready.get("pid"), "witness_kid": ready.get("kid"),
                            "store_unchanged": store_before == store_after, "store_records": len(store_before.splitlines()),
                            "exit_code": witness_copy_exit, "probes": probes},
          "segment_witness": {"registered": bool(seg_id) and seg_id in witness_runs_registered, "cosigned_seqs": sorted(seg_cosigned),
                              "saved_anchor": bool(seg_witness_head_file), "registration": registration,
                              "rollback_to": seg_rollback_to, "rollback_dropped_stages": seg_dropped},
          "live_witness": {"pid": live_ready.get("pid"), "latest_seq": live_latest_seq, "latest_equals_saved_anchor": live_latest_ok,
                           "earlier_run_continued_by": live_continued_by, "segment_latest_seq": live_seg_latest_seq,
                           "signed_status": live_status,
                           "store_unchanged_by_restart_and_queries": live_before == live_after, "exit_code": live_exit},
          "witness_history": {"cosigned_seqs": seqs, "jumps": gaps, "outage": outage_gap},
          "rollback_probe": {"cut_to_seq": k, "last_provider_effect_seq": last_effect, "dropped_stages": dropped},
          "verify_time_outage": outage,
          # build 3
          "enrollment": {"kid": enroll.kid, "equals_custody_json_kid": enroll.kid == facts.get("enrollment_kid"),
                         "witness_pin_equals_saved_witness_key": witness_pin_hex == witness_key_hex.lower() if witness_pin_hex else None,
                         "eval_probes": [{"name": x.get("name"), "refused": x.get("refused")} for x in facts.get("enrollment_probes") or []],
                         "eval_probes_left_no_trace": facts.get("enrollment_probes_left_no_trace")},
          "earlier_keys_probe": earlier_keys_probe,
          "cli_cells": len(rows), "cli_agree": sum(1 for r in rows if r["agrees_with_eval"] is True),
          "cli_compared": sum(1 for r in rows if r["agrees_with_eval"] != "")}
json.dump(result, open(os.path.join(out, "probe.json"), "w", encoding="utf-8"), indent=1)
print(json.dumps({k2: v for k2, v in result.items() if k2 not in ("witness_probe",)}, indent=1)[:3000])
for r in rows:
    print("%-72s | %-42s | %s %s exit=%s | %s | eval %s %s | %s" % (r["variant"][:72], r["anchors"], r["cli_verdict"], r["cli_assurance"], r["cli_exit"], r["outcome"], r["eval_verdict"], r["eval_assurance"], r["cli_failing"]))
