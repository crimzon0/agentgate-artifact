"""Signed run status under an answering intermediary (agentgate-verify --witness-url).

Usage: python status_probe.py BIN EXP CANONICAL_CUSTODY_JSON CANONICAL_WORK CANONICAL_PROBE OUTDIR
  BIN   folder holding agentgate-witness.exe and agentgate-verify.exe
  EXP   EXP/runs/<name>/{out/custody.json, work/, probe/} are the repetitions (repeat.sh)
  the canonical run's custody.json, -work dir and probe dir are given explicitly
Writes OUTDIR/status_probe.csv (one row per run, variant and answer) and
OUTDIR/status_probe_summary.json (counts with denominators).

For every run, after all runs: a fresh agentgate-witness process on a COPY of
the run's witness directory, and in front of it a loopback HTTP relay that
answers agentgate-verify --witness-url in the witness's place. The relay
forwards GET /runs/{id}/latest and GET /runs/{id} and changes the answer as
an intermediary could (it holds no key and signs nothing):

  relay                 both answers unchanged (control)
  strip-continued-by    continued_by removed from the signed status
  unsigned-registration the status replaced by the unsigned registration
                        format that GET /runs/{id} answered before this build
                        (agentgate-witness-run/v1), without continued_by
  other-run-status      the segment's genuine signed status served for the
                        first run
  stale-head            an earlier genuine cosigned head served as the latest
                        (the first run's stale head #168/#159, the segment's
                        #3), the current signed status relayed unchanged
  replayed-pair         a genuine (latest head, signed status) pair fetched by
                        probe.py and served again more than 2 minutes later
                        (the verifier's freshness bound)
  status-withheld       GET /runs/{id} answered 404 unknown_run (no status)
  stale-head+status-withheld  both of the above changes at once

Variants (genuine files only): S0 the newest segment (the whole run, clean),
R5 the first folder alone (restart segment withheld), R1 the tamper lab's
coherent rollback of the first folder (to the stale head's entry). Not every
answer applies to every variant (see APPLIES).

Not testable from outside: an older genuine status of the first run from
before the continuation was registered (no such status was ever fetched, and
one cannot be made after the run without the witness key).

Build 2 (2026-10-10, commit 86643d7): every row also records the verifier's
derived dimensions head_fresh and run_complete and missing_kinds, and the
summary counts them per cell. Nothing else changed.

Build 3 (2026-10-20, commit 8a30fd4): agentgate-witness requires -enroll-key;
the witness copy is started with the gateway enrollment public key from the
run's <work>/custody/gateway/enrollment-key.json (public half only). Every row
gains witness_enrollment_kid_matches (the enrollment_kid the CLI reports for
a checked status equals custody.json's enrollment_kid; empty when no status
was checked). The genuine statuses are now format v2 (enrollment_kid as a
16th signed field); the "unsigned-registration" answer still replaces the
status by the old unsigned agentgate-witness-run/v1 registration (without
enrollment_kid). Nothing else changed.
"""
import csv, glob, json, os, shutil, subprocess, sys, threading, time, urllib.request, urllib.error
from collections import Counter, defaultdict
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

bindir, exp, canonical_json, canonical_work, canonical_probe, outdir = sys.argv[1:7]
binw = os.path.join(bindir, "agentgate-witness.exe")
binv = os.path.join(bindir, "agentgate-verify.exe")
FRESHNESS_S = 120  # internal/auditverify MaxWitnessStatusSkew
MARGIN_S = 15

runs = [("canonical", canonical_json, canonical_work, canonical_probe)]
for d in sorted(glob.glob(os.path.join(exp, "runs", "*", ""))):
    name = os.path.basename(os.path.dirname(d))
    runs.append((name, os.path.join(d, "out", "custody.json"), os.path.join(d, "work"), os.path.join(d, "probe")))

ANSWERS = ["relay", "strip-continued-by", "unsigned-registration", "other-run-status", "stale-head", "replayed-pair",
           "status-withheld", "stale-head+status-withheld"]
APPLIES = {"S0": ["relay", "unsigned-registration", "stale-head", "replayed-pair"],
           "R5": ["relay", "strip-continued-by", "unsigned-registration", "other-run-status", "stale-head", "replayed-pair",
                  "status-withheld"],
           "R1": ["relay", "stale-head", "stale-head+status-withheld"]}
UNKNOWN_RUN = {"error": "headwitness: unknown run", "code": "unknown_run"}
VARIANT_NAMES = {"S0": "newest segment (whole run, clean)", "R5": "first folder alone (segment withheld)",
                 "R1": "coherent rollback of the first folder (tamper lab)"}


class Relay:
    """Loopback HTTP relay in front of one witness; `plan` decides each answer."""

    def __init__(self, witness_origin):
        self.witness = witness_origin
        self.plan = {}       # path -> ("forward" | "body", body)
        self.requests = []
        relay = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                relay.requests.append(self.path)
                how = relay.plan.get(self.path)
                if how is not None and how[0] == "body":
                    status, body = 200, json.dumps(how[1]).encode()
                elif how is not None and how[0] == "error":
                    status, body = 404, json.dumps(how[1]).encode()
                else:
                    try:
                        with urllib.request.urlopen(relay.witness + self.path, timeout=10) as r:
                            status, body = r.status, r.read()
                    except urllib.error.HTTPError as e:
                        status, body = e.code, e.read()
                    if how is not None and how[0] == "transform":
                        body = json.dumps(how[1](json.loads(body))).encode()
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.origin = "http://127.0.0.1:%d" % self.server.server_address[1]
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def close(self):
        self.server.shutdown()
        self.server.server_close()


def start_witness(directory, enroll_public_b64):
    proc = subprocess.Popen([binw, "-dir", directory, "-enroll-key", enroll_public_b64, "-stdin-shutdown"], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, text=True)
    return proc, json.loads(proc.stdout.readline())


def stop_witness(proc):
    proc.stdin.close()
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        proc.kill(); proc.wait()
    return proc.returncode


def get(origin, path):
    with urllib.request.urlopen(origin + path, timeout=10) as r:
        return json.loads(r.read())


def unsigned_registration(status):
    reg = {k: status[k] for k in ("run_id", "keys_sha256", "audit_kid", "audit_public_key", "keys_file_verified", "registered_at") if k in status}
    reg = {"format": "agentgate-witness-run/v1", **reg}
    if status.get("continues"):
        reg["continues"] = status["continues"]
    return reg


rows = []
for name, cj, work, pdir in runs:
    custody = json.load(open(cj, encoding="utf-8"))
    f = custody["facts"]
    run_id, seg_id = f["run_id"], f.get("segment_run_id")
    mode = "deny" if "deny" in name else "flag"
    assert seg_id, "%s: no restart segment" % name
    key_hex = open(os.path.join(work, "custody", "anchors", run_id, "witness-key.txt")).read().strip()
    store = [json.loads(l) for l in open(os.path.join(work, "custody", "witness", "witness-store.jsonl"), encoding="utf-8") if l.strip()]
    cosigned = {(r["head"]["head"]["run_id"], r["head"]["head"]["seq"]): r["head"] for r in store if r["type"] == "head"}
    seg_seqs = sorted(q for (rid, q) in cosigned if rid == seg_id)
    stale = {run_id: cosigned[(run_id, f["stale_witness_seq"])], seg_id: cosigned[(seg_id, seg_seqs[-2])]}
    pairs = {run_id: json.load(open(os.path.join(pdir, "status-pair-earlier-run.json"), encoding="utf-8")),
             seg_id: json.load(open(os.path.join(pdir, "status-pair-segment.json"), encoding="utf-8"))}
    folders = {"S0": os.path.join(work, "runs", seg_id), "R5": os.path.join(work, "runs", run_id),
               "R1": os.path.join(work, "variants", "rollback")}
    folder_run = {"S0": seg_id, "R5": run_id, "R1": run_id}

    wdir = os.path.join(work, "status-probe", "witness-copy")
    shutil.rmtree(os.path.dirname(wdir), ignore_errors=True)
    shutil.copytree(os.path.join(work, "custody", "witness"), wdir)
    store_before = open(os.path.join(wdir, "witness-store.jsonl"), "rb").read()
    enroll_public = json.load(open(os.path.join(work, "custody", "gateway", "enrollment-key.json"), encoding="utf-8"))["public_key"]
    proc, ready = start_witness(wdir, enroll_public)
    relay = Relay(ready["origin"])
    for variant in ("S0", "R5", "R1"):
        rid = folder_run[variant]
        latest_path, status_path = "/runs/%s/latest" % rid, "/runs/%s" % rid
        for answer in APPLIES[variant]:
            plan = {}
            age = None
            if answer == "strip-continued-by":
                plan[status_path] = ("transform", lambda s: {k: v for k, v in s.items() if k != "continued_by"})
            elif answer == "unsigned-registration":
                plan[status_path] = ("transform", unsigned_registration)
            elif answer == "other-run-status":
                plan[status_path] = ("body", get(ready["origin"], "/runs/%s" % seg_id))
            elif answer == "stale-head":
                plan[latest_path] = ("body", stale[rid])
            elif answer == "status-withheld":
                plan[status_path] = ("error", UNKNOWN_RUN)
            elif answer == "stale-head+status-withheld":
                plan[latest_path] = ("body", stale[rid])
                plan[status_path] = ("error", UNKNOWN_RUN)
            elif answer == "replayed-pair":
                pair = pairs[rid]
                fetched = datetime.fromisoformat(pair["fetched_at"])
                wait = FRESHNESS_S + MARGIN_S - (datetime.now(timezone.utc) - fetched).total_seconds()
                if wait > 0:
                    print("  waiting %.0f s until the saved pair of %s is older than %d s" % (wait, name, FRESHNESS_S + MARGIN_S), flush=True)
                    time.sleep(wait)
                plan[latest_path] = ("body", pair["latest"])
                plan[status_path] = ("body", pair["status"])
            relay.plan, relay.requests = plan, []
            if answer == "replayed-pair":
                signed = datetime.fromisoformat(pairs[rid]["status"]["status_at"].replace("Z", "+00:00"))
                age = round((datetime.now(timezone.utc) - signed).total_seconds(), 1)
            p = subprocess.run([binv, "--json", "--witness-url", relay.origin, "--witness-key", key_hex, folders[variant]],
                               capture_output=True, text=True)
            try:
                rep = json.loads(p.stdout)
            except Exception:
                rep = {}
            failures = [x for x in (rep.get("failures") or []) if isinstance(x, dict)]
            failing = sorted({x.get("id") for x in failures if x.get("id")})
            hw = next((x.get("detail", "") for x in failures if x.get("id") == "head.witness"), "")
            w = (rep.get("anchors") or {}).get("witness") or {}
            verdict, assurance = rep.get("verdict", ""), rep.get("assurance", "")
            if p.returncode == 2:
                outcome = "ERROR (exit 2)"
            elif variant == "S0":
                outcome = "accepted, ANCHORED" if (verdict == "VERIFIED" and assurance == "ANCHORED") else (
                    "accepted, " + assurance if verdict == "VERIFIED" else "refused")
            else:
                outcome = "detected" if verdict == "FAILED" else "NOT detected (%s)" % assurance
            rows.append({"run": name, "mode": mode, "variant": variant, "answer": answer, "cli_exit": p.returncode,
                         "cli_verdict": verdict, "cli_assurance": assurance, "cli_failing": " ".join(failing), "outcome": outcome,
                         "run_status_given": w.get("run_status_given", ""), "run_status_checked": w.get("run_status_checked", ""),
                         "continued_by_seen": ("the segment" if w.get("continued_by") == seg_id else w.get("continued_by", "")),
                         "replayed_status_age_s": age if age is not None else "",
                         "relay_requests": len(relay.requests),
                         "head_witness_detail": hw.replace(run_id, "<run>").replace(seg_id, "<segment>")[:400],
                         "stderr": p.stderr.strip().replace(relay.origin, "<relay>").replace(run_id, "<run>").replace(seg_id, "<segment>")[:200],
                         "head_fresh": ((rep.get("dimensions") or {}).get("head_fresh") or {}).get("status", ""),
                         "run_complete": ((rep.get("dimensions") or {}).get("run_complete") or {}).get("status", ""),
                         "missing_kinds": " ".join(rep.get("missing_kinds") or []),
                         "witness_enrollment_kid_matches": (w.get("enrollment_kid") == f.get("enrollment_kid")) if w.get("enrollment_kid") else ""})
            print("%-10s %-3s %-22s exit=%s %s/%s %s | %s" % (name, variant, answer, p.returncode, verdict, assurance, " ".join(failing), outcome), flush=True)
    relay.close()
    exit_code = stop_witness(proc)
    store_after = open(os.path.join(wdir, "witness-store.jsonl"), "rb").read()
    rows.append({"run": name, "mode": mode, "variant": "-", "answer": "witness copy unchanged", "cli_exit": exit_code,
                 "cli_verdict": "", "cli_assurance": "", "cli_failing": "", "outcome": str(store_before == store_after),
                 "run_status_given": "", "run_status_checked": "", "continued_by_seen": "", "replayed_status_age_s": "",
                 "relay_requests": "", "head_witness_detail": "", "stderr": "", "head_fresh": "", "run_complete": "", "missing_kinds": "",
                 "witness_enrollment_kid_matches": ""})

os.makedirs(outdir, exist_ok=True)
with open(os.path.join(outdir, "status_probe.csv"), "w", newline="", encoding="utf-8") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
cells = defaultdict(Counter)
failing = defaultdict(Counter)
fresh = defaultdict(Counter)     # build 2: head_fresh / run_complete per cell
complete = defaultdict(Counter)
for r in rows:
    if r["variant"] == "-":
        continue
    cells[(r["variant"], r["answer"])][r["outcome"]] += 1
    failing[(r["variant"], r["answer"])][r["cli_failing"] or "-"] += 1
    fresh[(r["variant"], r["answer"])][r["head_fresh"] or "-"] += 1
    complete[(r["variant"], r["answer"])][r["run_complete"] or "-"] += 1
summary = {"runs": len(runs), "cells": sum(1 for r in rows if r["variant"] != "-"),
           # build 3: rows whose checked status names the gateway's enrollment key / rows with a checked status
           "enrollment_kid_matches": "%d/%d" % (sum(1 for r in rows if r["witness_enrollment_kid_matches"] is True),
                                                sum(1 for r in rows if r["witness_enrollment_kid_matches"] != "")),
           "witness_copy_unchanged": "%d/%d" % (sum(1 for r in rows if r["variant"] == "-" and r["outcome"] == "True"), len(runs)),
           "replayed_status_age_s": [min((r["replayed_status_age_s"] for r in rows if r["answer"] == "replayed-pair"), default=None),
                                     max((r["replayed_status_age_s"] for r in rows if r["answer"] == "replayed-pair"), default=None)],
           "relay_requests_per_cell": dict(Counter(str(r["relay_requests"]) for r in rows if r["variant"] != "-")),
           "by_cell": [{"variant": v, "variant_name": VARIANT_NAMES[v], "answer": a, "runs": sum(c.values()), "outcomes": dict(c),
                        "failing": dict(failing[(v, a)]), "head_fresh": dict(fresh[(v, a)]), "run_complete": dict(complete[(v, a)])}
                       for (v, a), c in cells.items()]}
json.dump(summary, open(os.path.join(outdir, "status_probe_summary.json"), "w", encoding="utf-8"), indent=1)
print(json.dumps(summary, indent=1))
